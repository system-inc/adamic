#!/usr/bin/env bash
set -euo pipefail
source /workspace/adamic-tools/env.sh
repository=$(git rev-parse --show-toplevel)
scratch=/tmp/wasm-requests-profile
mkdir -p "$scratch"
cd "$repository"
go build -o "$scratch/adamic" ./cmd/adamic
"$scratch/adamic" build --target wasm32-wasi internal/native/wasm/service/service.a -o "$scratch/service.wasm"
"$scratch/adamic" build --target wasm32-wasi internal/native/wasm/service/service.a -o "$scratch/service-counted.wasm" --count
"$scratch/adamic" build cloud/reports/wasm-requests-profile/command.a -o "$scratch/service-native"
"$scratch/adamic" build cloud/reports/wasm-requests-profile/command.a -o "$scratch/service-native-counted" --count
"$scratch/adamic" c cloud/reports/wasm-requests-profile/command.a > "$scratch/command.c"
"$scratch/adamic" c internal/native/wasm/service/service.a > "$scratch/service.c"
handler=$(sed -n 's/^static adamic_string \* \(adamic_function_[0-9]*_handleRequest\)(.*/\1/p' "$scratch/service.c" | head -n 1)
common=(-std=c11 -Wall -Wextra -Werror -pedantic -Wno-unused-variable -Wno-unused-but-set-variable -Wno-unused-function -Wno-unused-parameter -Wno-self-assign -O2 -ffp-contract=off -fno-optimize-sibling-calls -I internal/native/runtime -I "$scratch")
/workspace/adamic-tools/wasi-sdk/bin/clang "${common[@]}" --target=wasm32-wasi --sysroot="$WASI_SYSROOT" -DADAMIC_TARGET_WASI=1 -DADAMIC_COUNT -DPROFILE_HANDLER="$handler" -mexec-model=reactor -Wl,-z,stack-size=1048576 -Wl,--export=malloc -Wl,--export=free -Wl,--export=adamic_release cloud/reports/wasm-requests-profile/diagnostic.c internal/native/runtime/*.c -lm -o "$scratch/service-counted-diagnostic.wasm"
/workspace/adamic-tools/wasi-sdk/bin/llvm-objdump -h "$scratch/service.wasm" > "$scratch/wasm-sections.txt"

clang -std=c11 -Wall -Wextra -Werror -O2 -D_GNU_SOURCE -DPROFILE_SAMPLER -fPIC -shared cloud/reports/wasm-requests-profile/diagnostic.c -ldl -o "$scratch/sampler.so"
