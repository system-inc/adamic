Built a measurement harness for the unchanged f4ec96c service; no compiler or runtime fixes.
Best of five: Wasm 8,542 requests/s, native 11,141 requests/s, Node 50,932 requests/s.
Native takes 4.57 times Node time; Wasm takes 5.96 times Node time and 1.30 times native time.
All three self-time profiles are below; string work, allocation and destruction dominate compiled paths.
Limits: native used PC sampling because perf was unavailable; the extra Wasm time cannot be fully partitioned.

## Baseline and machine

Baseline: `f4ec96cf0a43c0b03b8f99dfcfd3bacb28e80569`. Branch: `codex/wasm-requests-profile`. Claim-only commit `c970f21` was pushed before building. All tracked changes are under this report directory. The accepted service and generator are unchanged. This is a baseline experiment, not a landing or an integration with a newer main.

Debian 13, AMD EPYC 9V74 80-Core Processor; `nproc` returned 5, with cgroup CPU quota `400000 100000` (four CPU equivalents). Cgroup memory limit was 16 GiB. Node v24.19.0, native clang 20.1.8, WASI SDK 27. The container was otherwise idle during the five rounds and each profiling capture: no build, test, analysis or other worker job ran alongside them. Host activity outside this container is not controlled; the one-minute load average is recorded below.

`bash cloud/setup.sh --wasi-sdk` reported Go, clang, Node, WASI SDK and submodules ready at 0s; cache warm and done at 69s. Environment: `/workspace/adamic-tools/env.sh`, including `WASI_SYSROOT`. Full setup output: `/tmp/wasm-requests-profile-setup.log`.

## Method and observations

The exact accepted seeded generator supplies 100,000 requests, including malformed JSON, Unicode and large bodies. The JSONL file is 417,755,377 bytes, SHA-256 `cba64bd86fdd84d7086973a145a4e8419dd31937470728efe8bf8db156a75c39`. Node type-strips and imports the same `service.a`. Expected response length checksum: 7,394,547 UTF-16 units. Wasm warmup compares all 100,000 responses exactly against Node; native verification also compared all 100,000 response lines and the final checksum exactly. Timed loops check the checksum, not every response byte.

Both release executables were produced with `adamic build`, without `--sanitize` or `--count`; Wasm used `--target wasm32-wasi`. The compiler already selects `-O2` (`internal/native/native.go:99`), with `-ffp-contract=off` and `-fno-optimize-sibling-calls`. No missing optimization flag was found. The ordinary release Wasm artifact retains its name section; it supplies named runtime and emitted-function frames without rebuilding it for profiling.

Wasm uses one reactor instance through the existing request ABI. Its measured loop includes JS UTF-8 encoding, malloc and input copy, request decode/handler, response decode, release and free. Linear memory after measurement was 1,638,400 bytes. Node measures calls over the same prepared request strings. Each persistent engine receives a whole-corpus warmup before the rounds.

The native command reads and splits the JSONL file before timing, warms the handler on the whole corpus, then brackets the serve loop with separate stderr writes. The parent times receipt of `serve:start` and `serve:stop`. This excludes process startup, read/split, warmup and teardown; marker scheduling adds small unquantified error. Native whole-process times were 20.34 to 20.75 seconds and are preserved in `results.json`; they include warmup and are not the reported serve rates. Native warmup also preserves lazy caches on its input strings, whereas Wasm decodes a fresh input string on each call. That difference is part of these deployed paths and limits isolation of pure engine cost.

Serial, interleaved, best of five; no profiler or counted build was used for these rates. Load and nproc were collected immediately before and after each round. Rates below are requests per second; load is the one-minute average.

| Round | Order | Load before / after | nproc before / after | Wasm req/s | Native req/s | Node req/s |
|---|---|---:|---:|---:|---:|---:|
| 1 | wasm, native, node | 0.52 / 0.73 | 5 / 5 | 8,409 | 11,101 | 48,668 |
| 2 | node, native, wasm | 0.73 / 0.85 | 5 / 5 | 8,215 | 10,592 | 49,044 |
| 3 | native, wasm, node | 0.85 / 0.92 | 5 / 5 | 8,502 | 10,989 | 50,932 |
| 4 | node, wasm, native | 0.92 / 0.96 | 5 / 5 | 8,542 | 11,141 | 50,654 |
| 5 | wasm, node, native | 0.96 / 0.98 | 5 / 5 | 8,156 | 10,845 | 49,207 |

| Engine | Best serve time for 100,000 | Best req/s | Time relative to Node |
|---|---:|---:|---:|
| Wasm | 11.707478 s | 8,541.55 | 5.96 times |
| Native | 8.976138 s | 11,140.65 | 4.57 times |
| Node | 1.963417 s | 50,931.62 | 1.00 |

## Three profiles, side by side

These are separate profiling runs, not the rate runs. Wasm and Node used `node --cpu-prof` plus an inspector capture gated around the serve batch. Monotonic timestamps trim the capture to the loop, excluding inspector stop/dispatch bookkeeping and startup. Full-process automatic CPU profiles are retained separately. Wasm loop: 15,581.87 ms, 14,280 retained samples; Node loop: 2,087.34 ms. Profiling perturbs execution, so profile self milliseconds must not be treated as components of the best unprofiled times.

`perf` was not installed, and installing it was blocked by apt filesystem permissions for this unprivileged account. Instead, a measurement-only `LD_PRELOAD` adapter sampled the program counter via SIGPROF on the unchanged native release binary, enabled only between the serve markers. The handler stores PCs in a fixed buffer and allocates nothing. Native: 9.009769 CPU seconds, 2,251 samples, about 250 samples per CPU second despite the nominal 1 ms timer. Native self milliseconds are estimates from sample fraction times process CPU time. This is not a perf hardware-counter profile.

Top ten entries are ranked by self time separately. Each cell gives function, estimated self ms, and share of that profile. Native entries are the top ten **resolved** functions; 14.39% of samples were unresolved (12.93% in stripped libc, 0.44% libm, 1.02% executable). Their time remains in the denominator. V8 inlining and builtin attribution differ from C symbol sampling; Node frame names do not prove absence of string or allocation work.

| Rank | Wasm: function, self ms (%) | Native: function, self ms (%) | Node: function, self ms (%) |
|---:|---|---|---|
| 1 | `adamic_release` 2161.8 (13.87%) | `adamic_string_slice` 1340.9 (14.88%) | `serve` 881.3 (42.23%) |
| 2 | `adamic_string_slice` 1776.2 (11.40%) | `adamic_release` 1088.7 (12.08%) | `value` 563.1 (26.98%) |
| 3 | `adamic_allocate` 1276.9 (8.19%) | `adamic_allocate` 604.4 (6.71%) | `string` 485.7 (23.27%) |
| 4 | `adamic_string_share` 1045.5 (6.71%) | `adamic_function_13_Parser_string` 588.4 (6.53%) | `(garbage collector)` 49.4 (2.37%) |
| 5 | `decode` 1001.8 (6.43%) | `adamic_string_locate` 584.4 (6.49%) | `Value` 41.8 (2.00%) |
| 6 | `adamic_function_11_Parser_peek` 926.7 (5.95%) | `adamic_string_char_code` 424.3 (4.71%) | `space` 20.3 (0.97%) |
| 7 | `adamic_string_locate` 866.4 (5.56%) | `adamic_string_at` 384.2 (4.26%) | `handleRequest` 16.2 (0.78%) |
| 8 | `adamic_function_13_Parser_string` 755.7 (4.85%) | `adamic_string_share` 340.2 (3.78%) | `error` 14.0 (0.67%) |
| 9 | `adamic_string_append` 514.5 (3.30%) | `adamic_string_join_halves` 308.2 (3.42%) | `compare` 5.4 (0.26%) |
| 10 | `adamic_string_put` 443.6 (2.85%) | `adamic_string_equal` 284.2 (3.15%) | `peek` 4.3 (0.21%) |

Source mapping for the compiled profile functions (paths relative to the repository):

| Function | Runtime C or emitted source |
|---|---|
| `adamic_release` | `internal/native/runtime/heap.c:320` |
| `adamic_string_slice` | `internal/native/runtime/string_slice_impl.h:13` |
| `adamic_allocate` | `internal/native/runtime/heap.c:188` |
| `adamic_string_share` | `internal/native/runtime/string_share.c:30` |
| `decode` | `internal/native/runtime/input.c:101 (confirmed in Wasm disassembly)` |
| `adamic_function_11_Parser_peek` | `emitted C: Parser_peek` |
| `adamic_string_locate` | `internal/native/runtime/string_index.c:171` |
| `adamic_function_13_Parser_string` | `emitted C: Parser_string` |
| `adamic_string_append` | `internal/native/runtime/string_append.c:33` |
| `adamic_string_put` | `internal/native/runtime/string_build_impl.h:71` |
| `adamic_string_char_code` | `internal/native/runtime/string_decode_impl.h:44` |
| `adamic_string_at` | `internal/native/runtime/string_slice_impl.h:49` |
| `adamic_string_join_halves` | `internal/native/runtime/string_build_impl.h:86` |
| `adamic_string_equal` | `internal/native/runtime/string_build_impl.h:107` |

The emitted `Parser_peek` and `Parser_string` functions implement `Parser.peek` and `Parser.string` at `internal/native/wasm/service/service.a:15` and `:19`. The plain Wasm name `decode` was mapped by matching its profile byte offset to the named disassembly of `adamic_decode_utf8` and its helper. Node source mappings are recorded per frame in `node-profile.json`: `serve:121`, `value:55`, `string:19`, `Value:3`, `space:16`, `handleRequest:185`, `error:105`, `compare:109`, `peek:15`, all in the unchanged service source. The garbage collector is a V8 builtin.

## Runtime counts

The runtime exposes counted allocations, frees, retains and releases, but the standard reactor exports only the narrower counted ABI. A separate diagnostic counted reactor exports the existing runtime counter fields; it includes emitted service C and unchanged runtime sources with the same release flags plus `ADAMIC_COUNT`. Its 100,000 responses were compared exactly to Node. These are counted heap values, not every underlying malloc, slab operation or map/array backing-buffer allocation.

Native uses the ordinary `adamic build --count` command. Its totals subtract a control that performs identical startup/read/split and skips handling. Native input strings remain resident during the loop, so this subtraction removes file/setup ownership; high-water peaks cannot be subtracted and are deliberately omitted from the native delta.

| Counter | Wasm total | Wasm / request | Native serve delta | Native / request |
|---|---:|---:|---:|---:|
| allocations | 157,600,123 | 1576.00123 | 157,500,123 | 1575.00123 |
| frees | 157,600,123 | 1576.00123 | 157,500,123 | 1575.00123 |
| retains | 71,993,082 | 719.93082 | 72,093,084 | 720.93084 |
| releases | 196,943,777 | 1969.43777 | 196,943,779 | 1969.43779 |

Wasm ended with zero live counted values, peak 3,088 and zero statement regions. Native run/control raw totals are preserved in `results.json`; both balance allocations and frees. The one extra allocation per request in Wasm is consistent with fresh request decoding; native receives prebuilt strings. The retain difference is consistent with the native array iteration/binding ownership. These are interpretations of the ABI and emitted loop, not independent cost measurements.

## Where the gap is

**Observations:** Native already takes 4.57 times Node time on the same handler and requests. Both compiled profiles spend substantial self time slicing and traversing strings, allocating values, and releasing/destroying them. Wasm has a visible UTF-8 input decoder hotspot (6.43% of the windowed profile). Node spends most attributed self time in the handwritten service/parser functions `serve`, `value`, and `string`; attributed GC is 2.37%. Each compiled call creates roughly 1,575 counted values and performs about 720 retains and 1,969 releases. The release function includes destruction and cascading frees, so its self share is not simply the cost of decrementing a refcount.

**Inference:** Most of the gap is shared emitted-C/runtime/parser cost, not specifically WebAssembly. Relative to the best Node time, native adds 7.012722 seconds and Wasm adds 9.744061 seconds per corpus. The shared native excess is approximately 72% of the observed Wasm excess. The remaining Wasm-path increment is 2.731340 seconds (28% of the excess), or 30.4% above native. This arithmetic is a comparison of observations, not a causal decomposition with confidence intervals.

The handwritten JSON parser repeatedly requests individual characters and slices. The runtime implements JavaScript-compatible UTF-16 positions over its string representation, sharing/slicing strings and locating units; the native and Wasm hotspots support this as a major shared cost. Allocation and destruction are also shared costs. Retains alone are not a leading self-time hotspot. Map hashing may contribute, but it does not explain the dominant string/allocation entries. There is no evidence here for missing `-O2`.

The additional Wasm-path cost includes input encoding/copy/decode, output decoding and reactor calls, plus differences in generated machine code and engine execution. Its decode hotspot supports a boundary/conversion contribution. This experiment cannot say how much of all 2.73 seconds is boundary cost versus Wasm execution; warmed native input caches are another confounder. It would be incorrect to attribute the whole shared 7.01-second penalty to Wasm, or the whole residual to copies. No fixes or speculative optimizations were made.

## Reproduction, checks and artifacts

Run from the repository root after sourcing the setup environment:

```bash
bash cloud/reports/wasm-requests-profile/build.sh > /tmp/wasm-requests-profile-build.log 2>&1
node --disable-warning=ExperimentalWarning cloud/reports/wasm-requests-profile/measure.mjs prepare > /tmp/wasm-requests-profile/prepare.log 2>&1
node --disable-warning=ExperimentalWarning cloud/reports/wasm-requests-profile/measure.mjs measure > /tmp/wasm-requests-profile/measure.log 2>&1
node --cpu-prof --cpu-prof-dir=/tmp/wasm-requests-profile --cpu-prof-name=wasm-windowed-all.cpuprofile --disable-warning=ExperimentalWarning cloud/reports/wasm-requests-profile/measure.mjs profile-wasm > /tmp/wasm-requests-profile/wasm-windowed-run.log 2>&1
node --cpu-prof --cpu-prof-dir=/tmp/wasm-requests-profile --cpu-prof-name=node-windowed-all.cpuprofile --disable-warning=ExperimentalWarning cloud/reports/wasm-requests-profile/measure.mjs profile-node > /tmp/wasm-requests-profile/node-windowed-run.log 2>&1
PROFILE_SAMPLE_PATH=/tmp/wasm-requests-profile/native-samples.txt LD_PRELOAD=/tmp/wasm-requests-profile/sampler.so /tmp/wasm-requests-profile/service-native /tmp/wasm-requests-profile/requests.jsonl warm > /tmp/wasm-requests-profile/native-profile-run.log 2>&1
node --disable-warning=ExperimentalWarning cloud/reports/wasm-requests-profile/measure.mjs counts > /tmp/wasm-requests-profile/counts.json 2>&1
python3 cloud/reports/wasm-requests-profile/analyze.py > /tmp/wasm-requests-profile/analysis.log 2>&1
```

Run measurement and each profile serially, with no other container work. `command.a` mode `verify` prints the exact native responses followed by the checksum; compare its first 100,000 lines to `responses.jsonl` before using its timings.

Durable artifacts: `results.json` contains all rounds, loads, rates and runtime counters; `wasm-profile.json`, `node-profile.json`, and `native-profile.txt` contain ranked frame summaries and mappings; `measure.mjs`, `analyze.py`, `command.a`, `diagnostic.c`, and `build.sh` reproduce the experiment. Raw CPU profiles, PCs, maps, binaries, generated C and logs are in `/tmp/wasm-requests-profile`. The full automatic CPU profiles include setup; the analyzed `profile-wasm.cpuprofile` and `profile-node.cpuprofile` carry the exact measurement window.

Checksum mutant: a scratch copy wrapped the measured Node handler and appended one response byte on every request, leaving warmup unchanged. It exited 1 at the measurement checksum assertion: actual 7,494,547, expected 7,394,547 (`checksum-mutant.log`). No mutant was committed. The accepted unit's byte-change, retention and Unicode-escape mutants were not rerun; this profile task did not change that service or its correctness test.

Validation: release/count builds and diagnostic C compilation passed; all 100,000 native responses and Wasm warmup/count responses matched Node; all five timed rounds matched the checksum. Syntax checks and `git diff --check` passed. No full repository gate or new filtered oracle was run for this report-only follow-up. Not covered: hardware perf counters, full stripped-library symbol attribution, causal partition of the Wasm residual, other machines or request distributions.
