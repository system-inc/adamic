
/workspace/scratch/parse-branches/ordered:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000072970 <adamic_release>:
adamic_release():
/workspace/scratch/parse-branches/ordered-runtime/heap.c:337
   72970:	48 85 ff             	test   %rdi,%rdi
   72973:	74 27                	je     7299c <adamic_release+0x2c>
/workspace/scratch/parse-branches/ordered-runtime/heap.c:340
   72975:	48 8b 07             	mov    (%rdi),%rax
/workspace/scratch/parse-branches/ordered-runtime/heap.c:341
   72978:	48 83 f8 02          	cmp    $0x2,%rax
   7297c:	72 07                	jb     72985 <adamic_release+0x15>
/workspace/scratch/parse-branches/ordered-runtime/heap.c:342
   7297e:	48 ff c8             	dec    %rax
   72981:	48 89 07             	mov    %rax,(%rdi)
/workspace/scratch/parse-branches/ordered-runtime/heap.c:349
   72984:	c3                   	ret
/workspace/scratch/parse-branches/ordered-runtime/heap.c:345
   72985:	48 83 f8 01          	cmp    $0x1,%rax
   72989:	75 11                	jne    7299c <adamic_release+0x2c>
   7298b:	50                   	push   %rax
/workspace/scratch/parse-branches/ordered-runtime/heap.c:346
   7298c:	48 c7 07 00 00 00 00 	movq   $0x0,(%rdi)
/workspace/scratch/parse-branches/ordered-runtime/heap.c:347
   72993:	e8 08 00 00 00       	call   729a0 <destroy_last_reference>
   72998:	48 83 c4 08          	add    $0x8,%rsp
/workspace/scratch/parse-branches/ordered-runtime/heap.c:349
   7299c:	c3                   	ret

Disassembly of section .fini:
