
/workspace/scratch/parse-branches/old:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000072970 <adamic_release>:
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:318
   72970:	55                   	push   %rbp
   72971:	41 57                	push   %r15
   72973:	41 56                	push   %r14
   72975:	41 55                	push   %r13
   72977:	41 54                	push   %r12
   72979:	53                   	push   %rbx
   7297a:	50                   	push   %rax
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   7297b:	48 85 ff             	test   %rdi,%rdi
   7297e:	74 14                	je     72994 <adamic_release+0x24>
   72980:	48 8b 07             	mov    (%rdi),%rax
   72983:	48 85 c0             	test   %rax,%rax
   72986:	74 0c                	je     72994 <adamic_release+0x24>
   72988:	48 ff c8             	dec    %rax
   7298b:	48 89 07             	mov    %rax,(%rdi)
   7298e:	0f 84 85 04 00 00    	je     72e19 <adamic_release+0x4a9>
/workspace/scratch/parse-branches/old-runtime/heap.c:321
   72994:	80 3d e5 c6 06 00 00 	cmpb   $0x0,0x6c6e5(%rip)        # df080 <draining>
   7299b:	0f 85 69 04 00 00    	jne    72e0a <adamic_release+0x49a>
/workspace/scratch/parse-branches/old-runtime/heap.c:325
   729a1:	c6 05 d8 c6 06 00 01 	movb   $0x1,0x6c6d8(%rip)        # df080 <draining>
/workspace/scratch/parse-branches/old-runtime/heap.c:326
   729a8:	48 8b 1d d9 c6 06 00 	mov    0x6c6d9(%rip),%rbx        # df088 <freeing_count>
   729af:	48 85 db             	test   %rbx,%rbx
   729b2:	0f 84 4b 04 00 00    	je     72e03 <adamic_release+0x493>
   729b8:	4c 8d 25 2d f3 01 00 	lea    0x1f32d(%rip),%r12        # 91cec <codes_add.message+0x11>
   729bf:	eb 27                	jmp    729e8 <adamic_release+0x78>
   729c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   729c8:	0f 1f 84 00 00 00 00 
   729cf:	00 
/workspace/scratch/parse-branches/old-runtime/heap.c:212
   729d0:	4c 89 f7             	mov    %r14,%rdi
   729d3:	e8 68 96 f9 ff       	call   c040 <free@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:326
   729d8:	48 8b 1d a9 c6 06 00 	mov    0x6c6a9(%rip),%rbx        # df088 <freeing_count>
   729df:	48 85 db             	test   %rbx,%rbx
   729e2:	0f 84 1b 04 00 00    	je     72e03 <adamic_release+0x493>
/workspace/scratch/parse-branches/old-runtime/heap.c:327
   729e8:	48 8b 05 a1 c6 06 00 	mov    0x6c6a1(%rip),%rax        # df090 <freeing>
   729ef:	48 8d 6b ff          	lea    -0x1(%rbx),%rbp
   729f3:	48 89 2d 8e c6 06 00 	mov    %rbp,0x6c68e(%rip)        # df088 <freeing_count>
   729fa:	4c 8b 74 d8 f8       	mov    -0x8(%rax,%rbx,8),%r14
/workspace/scratch/parse-branches/old-runtime/heap.c:259
   729ff:	41 8b 4e 08          	mov    0x8(%r14),%ecx
   72a03:	ff c9                	dec    %ecx
   72a05:	83 f9 09             	cmp    $0x9,%ecx
   72a08:	0f 87 22 03 00 00    	ja     72d30 <adamic_release+0x3c0>
   72a0e:	49 63 0c 8c          	movslq (%r12,%rcx,4),%rcx
   72a12:	4c 01 e1             	add    %r12,%rcx
   72a15:	ff e1                	jmp    *%rcx
/workspace/scratch/parse-branches/old-runtime/heap.c:261
   72a17:	4c 89 f7             	mov    %r14,%rdi
   72a1a:	e8 91 61 01 00       	call   88bb0 <adamic_string_free_index>
/workspace/scratch/parse-branches/old-runtime/heap.c:263
   72a1f:	49 8b 5e 30          	mov    0x30(%r14),%rbx
let_go():
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72a23:	48 85 db             	test   %rbx,%rbx
   72a26:	0f 84 04 03 00 00    	je     72d30 <adamic_release+0x3c0>
   72a2c:	48 8b 03             	mov    (%rbx),%rax
   72a2f:	48 85 c0             	test   %rax,%rax
   72a32:	0f 84 f8 02 00 00    	je     72d30 <adamic_release+0x3c0>
   72a38:	48 ff c8             	dec    %rax
   72a3b:	48 89 03             	mov    %rax,(%rbx)
   72a3e:	0f 85 ec 02 00 00    	jne    72d30 <adamic_release+0x3c0>
list():
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72a44:	4c 8b 3d 3d c6 06 00 	mov    0x6c63d(%rip),%r15        # df088 <freeing_count>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72a4b:	48 8b 05 3e c6 06 00 	mov    0x6c63e(%rip),%rax        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72a52:	4c 3b 3d e7 c6 06 00 	cmp    0x6c6e7(%rip),%r15        # df140 <freeing_capacity>
   72a59:	75 37                	jne    72a92 <adamic_release+0x122>
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72a5b:	4f 8d 2c 3f          	lea    (%r15,%r15,1),%r13
   72a5f:	4d 85 ff             	test   %r15,%r15
   72a62:	b9 40 00 00 00       	mov    $0x40,%ecx
   72a67:	4c 0f 44 e9          	cmove  %rcx,%r13
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72a6b:	4a 8d 34 ed 00 00 00 	lea    0x0(,%r13,8),%rsi
   72a72:	00 
   72a73:	48 89 c7             	mov    %rax,%rdi
   72a76:	e8 c5 97 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72a7b:	48 85 c0             	test   %rax,%rax
   72a7e:	0f 84 04 04 00 00    	je     72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72a84:	48 89 05 05 c6 06 00 	mov    %rax,0x6c605(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72a8b:	4c 89 2d ae c6 06 00 	mov    %r13,0x6c6ae(%rip)        # df140 <freeing_capacity>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72a92:	49 8d 4f 01          	lea    0x1(%r15),%rcx
   72a96:	48 89 0d eb c5 06 00 	mov    %rcx,0x6c5eb(%rip)        # df088 <freeing_count>
   72a9d:	4a 89 1c f8          	mov    %rbx,(%rax,%r15,8)
let_go():
/workspace/scratch/parse-branches/old-runtime/heap.c:254
   72aa1:	e9 8a 02 00 00       	jmp    72d30 <adamic_release+0x3c0>
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:293
   72aa6:	49 83 7e 18 00       	cmpq   $0x0,0x18(%r14)
   72aab:	0f 84 7f 02 00 00    	je     72d30 <adamic_release+0x3c0>
   72ab1:	48 8b 1d 88 c6 06 00 	mov    0x6c688(%rip),%rbx        # df140 <freeing_capacity>
   72ab8:	45 31 ed             	xor    %r13d,%r13d
   72abb:	eb 20                	jmp    72add <adamic_release+0x16d>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72abd:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   72ac1:	48 89 0d c0 c5 06 00 	mov    %rcx,0x6c5c0(%rip)        # df088 <freeing_count>
   72ac8:	4c 89 3c e8          	mov    %r15,(%rax,%rbp,8)
   72acc:	48 89 cd             	mov    %rcx,%rbp
   72acf:	90                   	nop
/workspace/scratch/parse-branches/old-runtime/heap.c:293
   72ad0:	49 ff c5             	inc    %r13
   72ad3:	4d 3b 6e 18          	cmp    0x18(%r14),%r13
   72ad7:	0f 83 53 02 00 00    	jae    72d30 <adamic_release+0x3c0>
/workspace/scratch/parse-branches/old-runtime/heap.c:294
   72add:	4f 8b 7c ee 20       	mov    0x20(%r14,%r13,8),%r15
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72ae2:	4d 85 ff             	test   %r15,%r15
   72ae5:	74 e9                	je     72ad0 <adamic_release+0x160>
   72ae7:	49 8b 0f             	mov    (%r15),%rcx
   72aea:	48 85 c9             	test   %rcx,%rcx
   72aed:	74 e1                	je     72ad0 <adamic_release+0x160>
   72aef:	48 ff c9             	dec    %rcx
   72af2:	49 89 0f             	mov    %rcx,(%r15)
   72af5:	75 d9                	jne    72ad0 <adamic_release+0x160>
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72af7:	48 39 dd             	cmp    %rbx,%rbp
   72afa:	75 c1                	jne    72abd <adamic_release+0x14d>
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72afc:	48 8d 1c 6d 00 00 00 	lea    0x0(,%rbp,2),%rbx
   72b03:	00 
   72b04:	48 85 ed             	test   %rbp,%rbp
   72b07:	b9 40 00 00 00       	mov    $0x40,%ecx
   72b0c:	48 0f 44 d9          	cmove  %rcx,%rbx
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72b10:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
   72b17:	00 
   72b18:	48 89 c7             	mov    %rax,%rdi
   72b1b:	e8 20 97 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72b20:	48 85 c0             	test   %rax,%rax
   72b23:	0f 84 5f 03 00 00    	je     72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72b29:	48 89 05 60 c5 06 00 	mov    %rax,0x6c560(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72b30:	48 89 1d 09 c6 06 00 	mov    %rbx,0x6c609(%rip)        # df140 <freeing_capacity>
   72b37:	eb 84                	jmp    72abd <adamic_release+0x14d>
/workspace/scratch/parse-branches/old-runtime/heap.c:267
   72b39:	4c 89 f7             	mov    %r14,%rdi
   72b3c:	48 8d 35 5d 03 00 00 	lea    0x35d(%rip),%rsi        # 72ea0 <let_go>
   72b43:	e8 18 b9 ff ff       	call   6e460 <adamic_object_free_children>
/workspace/scratch/parse-branches/old-runtime/heap.c:283
   72b48:	e9 e3 01 00 00       	jmp    72d30 <adamic_release+0x3c0>
/workspace/scratch/parse-branches/old-runtime/heap.c:307
   72b4d:	4d 8b 7e 10          	mov    0x10(%r14),%r15
   72b51:	49 ff 4f 48          	decq   0x48(%r15)
let_go():
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72b55:	eb 60                	jmp    72bb7 <adamic_release+0x247>
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:302
   72b57:	4c 89 f7             	mov    %r14,%rdi
   72b5a:	e8 81 68 01 00       	call   893e0 <adamic_weak_dropped>
/workspace/scratch/parse-branches/old-runtime/heap.c:303
   72b5f:	e9 cc 01 00 00       	jmp    72d30 <adamic_release+0x3c0>
/workspace/scratch/parse-branches/old-runtime/heap.c:272
   72b64:	41 80 7e 20 01       	cmpb   $0x1,0x20(%r14)
   72b69:	0f 85 3d 01 00 00    	jne    72cac <adamic_release+0x33c>
/workspace/scratch/parse-branches/old-runtime/heap.c:273
   72b6f:	49 8b 4e 10          	mov    0x10(%r14),%rcx
   72b73:	48 85 c9             	test   %rcx,%rcx
   72b76:	0f 84 30 01 00 00    	je     72cac <adamic_release+0x33c>
   72b7c:	48 8b 1d bd c5 06 00 	mov    0x6c5bd(%rip),%rbx        # df140 <freeing_capacity>
   72b83:	45 31 ed             	xor    %r13d,%r13d
   72b86:	e9 cd 00 00 00       	jmp    72c58 <adamic_release+0x2e8>
/workspace/scratch/parse-branches/old-runtime/heap.c:282
   72b8b:	4c 89 f7             	mov    %r14,%rdi
   72b8e:	48 8d 35 0b 03 00 00 	lea    0x30b(%rip),%rsi        # 72ea0 <let_go>
   72b95:	e8 26 7c 00 00       	call   7a7c0 <adamic_map_free_children>
/workspace/scratch/parse-branches/old-runtime/heap.c:283
   72b9a:	e9 91 01 00 00       	jmp    72d30 <adamic_release+0x3c0>
/workspace/scratch/parse-branches/old-runtime/heap.c:286
   72b9f:	41 80 7e 10 01       	cmpb   $0x1,0x10(%r14)
   72ba4:	0f 85 86 01 00 00    	jne    72d30 <adamic_release+0x3c0>
/workspace/scratch/parse-branches/old-runtime/heap.c:287
   72baa:	4d 8b 7e 18          	mov    0x18(%r14),%r15
let_go():
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72bae:	4d 85 ff             	test   %r15,%r15
   72bb1:	0f 84 79 01 00 00    	je     72d30 <adamic_release+0x3c0>
   72bb7:	49 8b 0f             	mov    (%r15),%rcx
   72bba:	48 85 c9             	test   %rcx,%rcx
   72bbd:	0f 84 6d 01 00 00    	je     72d30 <adamic_release+0x3c0>
   72bc3:	48 ff c9             	dec    %rcx
   72bc6:	49 89 0f             	mov    %rcx,(%r15)
   72bc9:	0f 85 61 01 00 00    	jne    72d30 <adamic_release+0x3c0>
list():
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72bcf:	48 3b 2d 6a c5 06 00 	cmp    0x6c56a(%rip),%rbp        # df140 <freeing_capacity>
   72bd6:	75 3b                	jne    72c13 <adamic_release+0x2a3>
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72bd8:	4c 8d 2c 6d 00 00 00 	lea    0x0(,%rbp,2),%r13
   72bdf:	00 
   72be0:	48 85 ed             	test   %rbp,%rbp
   72be3:	b9 40 00 00 00       	mov    $0x40,%ecx
   72be8:	4c 0f 44 e9          	cmove  %rcx,%r13
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72bec:	4a 8d 34 ed 00 00 00 	lea    0x0(,%r13,8),%rsi
   72bf3:	00 
   72bf4:	48 89 c7             	mov    %rax,%rdi
   72bf7:	e8 44 96 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72bfc:	48 85 c0             	test   %rax,%rax
   72bff:	0f 84 83 02 00 00    	je     72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72c05:	48 89 05 84 c4 06 00 	mov    %rax,0x6c484(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72c0c:	4c 89 2d 2d c5 06 00 	mov    %r13,0x6c52d(%rip)        # df140 <freeing_capacity>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72c13:	48 89 1d 6e c4 06 00 	mov    %rbx,0x6c46e(%rip)        # df088 <freeing_count>
   72c1a:	4c 89 7c d8 f8       	mov    %r15,-0x8(%rax,%rbx,8)
   72c1f:	e9 0c 01 00 00       	jmp    72d30 <adamic_release+0x3c0>
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72c24:	48 89 05 65 c4 06 00 	mov    %rax,0x6c465(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72c2b:	48 89 1d 0e c5 06 00 	mov    %rbx,0x6c50e(%rip)        # df140 <freeing_capacity>
/workspace/scratch/parse-branches/old-runtime/heap.c:273
   72c32:	49 8b 4e 10          	mov    0x10(%r14),%rcx
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72c36:	48 8d 55 01          	lea    0x1(%rbp),%rdx
   72c3a:	48 89 15 47 c4 06 00 	mov    %rdx,0x6c447(%rip)        # df088 <freeing_count>
   72c41:	4c 89 3c e8          	mov    %r15,(%rax,%rbp,8)
   72c45:	48 89 d5             	mov    %rdx,%rbp
   72c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   72c4f:	00 
/workspace/scratch/parse-branches/old-runtime/heap.c:273
   72c50:	49 ff c5             	inc    %r13
   72c53:	49 39 cd             	cmp    %rcx,%r13
   72c56:	73 54                	jae    72cac <adamic_release+0x33c>
/workspace/scratch/parse-branches/old-runtime/heap.c:274
   72c58:	49 8b 56 28          	mov    0x28(%r14),%rdx
   72c5c:	4e 8b 3c ea          	mov    (%rdx,%r13,8),%r15
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72c60:	4d 85 ff             	test   %r15,%r15
   72c63:	74 eb                	je     72c50 <adamic_release+0x2e0>
   72c65:	49 8b 17             	mov    (%r15),%rdx
   72c68:	48 85 d2             	test   %rdx,%rdx
   72c6b:	74 e3                	je     72c50 <adamic_release+0x2e0>
   72c6d:	48 ff ca             	dec    %rdx
   72c70:	49 89 17             	mov    %rdx,(%r15)
   72c73:	75 db                	jne    72c50 <adamic_release+0x2e0>
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72c75:	48 39 dd             	cmp    %rbx,%rbp
   72c78:	75 bc                	jne    72c36 <adamic_release+0x2c6>
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72c7a:	48 8d 1c 6d 00 00 00 	lea    0x0(,%rbp,2),%rbx
   72c81:	00 
   72c82:	48 85 ed             	test   %rbp,%rbp
   72c85:	b9 40 00 00 00       	mov    $0x40,%ecx
   72c8a:	48 0f 44 d9          	cmove  %rcx,%rbx
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72c8e:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
   72c95:	00 
   72c96:	48 89 c7             	mov    %rax,%rdi
   72c99:	e8 a2 95 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72c9e:	48 85 c0             	test   %rax,%rax
   72ca1:	0f 85 7d ff ff ff    	jne    72c24 <adamic_release+0x2b4>
   72ca7:	e9 dc 01 00 00       	jmp    72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:277
   72cac:	49 8b 5e 30          	mov    0x30(%r14),%rbx
let_go():
/workspace/scratch/parse-branches/old-runtime/heap.c:252
   72cb0:	48 85 db             	test   %rbx,%rbx
   72cb3:	74 63                	je     72d18 <adamic_release+0x3a8>
   72cb5:	48 8b 0b             	mov    (%rbx),%rcx
   72cb8:	48 85 c9             	test   %rcx,%rcx
   72cbb:	74 5b                	je     72d18 <adamic_release+0x3a8>
   72cbd:	48 ff c9             	dec    %rcx
   72cc0:	48 89 0b             	mov    %rcx,(%rbx)
   72cc3:	75 53                	jne    72d18 <adamic_release+0x3a8>
list():
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72cc5:	48 3b 2d 74 c4 06 00 	cmp    0x6c474(%rip),%rbp        # df140 <freeing_capacity>
   72ccc:	75 3b                	jne    72d09 <adamic_release+0x399>
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72cce:	4c 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%r15
   72cd5:	00 
   72cd6:	48 85 ed             	test   %rbp,%rbp
   72cd9:	b9 40 00 00 00       	mov    $0x40,%ecx
   72cde:	4c 0f 44 f9          	cmove  %rcx,%r15
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72ce2:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
   72ce9:	00 
   72cea:	48 89 c7             	mov    %rax,%rdi
   72ced:	e8 4e 95 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72cf2:	48 85 c0             	test   %rax,%rax
   72cf5:	0f 84 8d 01 00 00    	je     72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72cfb:	48 89 05 8e c3 06 00 	mov    %rax,0x6c38e(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72d02:	4c 89 3d 37 c4 06 00 	mov    %r15,0x6c437(%rip)        # df140 <freeing_capacity>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72d09:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   72d0d:	48 89 0d 74 c3 06 00 	mov    %rcx,0x6c374(%rip)        # df088 <freeing_count>
   72d14:	48 89 1c e8          	mov    %rbx,(%rax,%rbp,8)
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:278
   72d18:	49 8b 7e 28          	mov    0x28(%r14),%rdi
   72d1c:	e8 1f 93 f9 ff       	call   c040 <free@plt>
   72d21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   72d28:	0f 1f 84 00 00 00 00 
   72d2f:	00 
/workspace/scratch/parse-branches/old-runtime/heap.c:313
   72d30:	4c 89 f7             	mov    %r14,%rdi
   72d33:	e8 d8 65 01 00       	call   89310 <adamic_weak_forget>
/workspace/scratch/parse-branches/old-runtime/heap.c:211
   72d38:	41 8b 46 0c          	mov    0xc(%r14),%eax
   72d3c:	85 c0                	test   %eax,%eax
   72d3e:	0f 84 8c fc ff ff    	je     729d0 <adamic_release+0x60>
/workspace/scratch/parse-branches/old-runtime/heap.c:215
   72d44:	ff c8                	dec    %eax
give():
/workspace/scratch/parse-branches/old-runtime/heap.c:165
   72d46:	48 8b 0d eb c3 06 00 	mov    0x6c3eb(%rip),%rcx        # df138 <chunks>
   72d4d:	48 8b 04 c1          	mov    (%rcx,%rax,8),%rax
/workspace/scratch/parse-branches/old-runtime/heap.c:168
   72d51:	48 8b 50 18          	mov    0x18(%rax),%rdx
/workspace/scratch/parse-branches/old-runtime/heap.c:166
   72d55:	48 8b 48 38          	mov    0x38(%rax),%rcx
/workspace/scratch/parse-branches/old-runtime/heap.c:168
   72d59:	49 89 16             	mov    %rdx,(%r14)
/workspace/scratch/parse-branches/old-runtime/heap.c:169
   72d5c:	4c 89 70 18          	mov    %r14,0x18(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:173
   72d60:	48 8b 50 30          	mov    0x30(%rax),%rdx
   72d64:	48 ff ca             	dec    %rdx
   72d67:	48 89 50 30          	mov    %rdx,0x30(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:174
   72d6b:	80 78 10 00          	cmpb   $0x0,0x10(%rax)
   72d6f:	75 2d                	jne    72d9e <adamic_release+0x42e>
list_chunk():
/workspace/scratch/parse-branches/old-runtime/heap.c:85
   72d71:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:86
   72d78:	48 8d 35 21 c3 06 00 	lea    0x6c321(%rip),%rsi        # df0a0 <giving>
   72d7f:	48 8b 34 ce          	mov    (%rsi,%rcx,8),%rsi
   72d83:	48 89 70 08          	mov    %rsi,0x8(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:87
   72d87:	48 85 f6             	test   %rsi,%rsi
   72d8a:	74 03                	je     72d8f <adamic_release+0x41f>
/workspace/scratch/parse-branches/old-runtime/heap.c:88
   72d8c:	48 89 06             	mov    %rax,(%rsi)
/workspace/scratch/parse-branches/old-runtime/heap.c:90
   72d8f:	48 8d 35 0a c3 06 00 	lea    0x6c30a(%rip),%rsi        # df0a0 <giving>
   72d96:	48 89 04 ce          	mov    %rax,(%rsi,%rcx,8)
/workspace/scratch/parse-branches/old-runtime/heap.c:91
   72d9a:	c6 40 10 01          	movb   $0x1,0x10(%rax)
give():
/workspace/scratch/parse-branches/old-runtime/heap.c:177
   72d9e:	48 85 d2             	test   %rdx,%rdx
   72da1:	0f 85 31 fc ff ff    	jne    729d8 <adamic_release+0x68>
   72da7:	48 8d 15 f2 c2 06 00 	lea    0x6c2f2(%rip),%rdx        # df0a0 <giving>
   72dae:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   72db2:	48 31 c6             	xor    %rax,%rsi
   72db5:	48 8b 50 08          	mov    0x8(%rax),%rdx
   72db9:	48 09 d6             	or     %rdx,%rsi
   72dbc:	0f 84 16 fc ff ff    	je     729d8 <adamic_release+0x68>
/workspace/scratch/parse-branches/old-runtime/heap.c:95
   72dc2:	48 8b 30             	mov    (%rax),%rsi
   72dc5:	48 85 f6             	test   %rsi,%rsi
   72dc8:	74 27                	je     72df1 <adamic_release+0x481>
/workspace/scratch/parse-branches/old-runtime/heap.c:96
   72dca:	48 89 56 08          	mov    %rdx,0x8(%rsi)
   72dce:	48 85 d2             	test   %rdx,%rdx
/workspace/scratch/parse-branches/old-runtime/heap.c:100
   72dd1:	74 03                	je     72dd6 <adamic_release+0x466>
/workspace/scratch/parse-branches/old-runtime/heap.c:101
   72dd3:	48 89 32             	mov    %rsi,(%rdx)
/workspace/scratch/parse-branches/old-runtime/heap.c:103
   72dd6:	c6 40 10 00          	movb   $0x0,0x10(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:183
   72dda:	48 8b 0d 3f c3 06 00 	mov    0x6c33f(%rip),%rcx        # df120 <spares>
   72de1:	48 89 48 08          	mov    %rcx,0x8(%rax)
/workspace/scratch/parse-branches/old-runtime/heap.c:184
   72de5:	48 89 05 34 c3 06 00 	mov    %rax,0x6c334(%rip)        # df120 <spares>
   72dec:	e9 e7 fb ff ff       	jmp    729d8 <adamic_release+0x68>
/workspace/scratch/parse-branches/old-runtime/heap.c:98
   72df1:	48 8d 3d a8 c2 06 00 	lea    0x6c2a8(%rip),%rdi        # df0a0 <giving>
   72df8:	48 89 14 cf          	mov    %rdx,(%rdi,%rcx,8)
   72dfc:	48 85 d2             	test   %rdx,%rdx
/workspace/scratch/parse-branches/old-runtime/heap.c:100
   72dff:	75 d2                	jne    72dd3 <adamic_release+0x463>
   72e01:	eb d3                	jmp    72dd6 <adamic_release+0x466>
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:329
   72e03:	c6 05 76 c2 06 00 00 	movb   $0x0,0x6c276(%rip)        # df080 <draining>
/workspace/scratch/parse-branches/old-runtime/heap.c:330
   72e0a:	48 83 c4 08          	add    $0x8,%rsp
   72e0e:	5b                   	pop    %rbx
   72e0f:	41 5c                	pop    %r12
   72e11:	41 5d                	pop    %r13
   72e13:	41 5e                	pop    %r14
   72e15:	41 5f                	pop    %r15
   72e17:	5d                   	pop    %rbp
   72e18:	c3                   	ret
list():
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72e19:	48 8b 1d 68 c2 06 00 	mov    0x6c268(%rip),%rbx        # df088 <freeing_count>
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72e20:	48 8b 05 69 c2 06 00 	mov    0x6c269(%rip),%rax        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:236
   72e27:	48 3b 1d 12 c3 06 00 	cmp    0x6c312(%rip),%rbx        # df140 <freeing_capacity>
   72e2e:	75 3a                	jne    72e6a <adamic_release+0x4fa>
   72e30:	49 89 fe             	mov    %rdi,%r14
/workspace/scratch/parse-branches/old-runtime/heap.c:237
   72e33:	48 8d 0c 1b          	lea    (%rbx,%rbx,1),%rcx
   72e37:	48 85 db             	test   %rbx,%rbx
   72e3a:	41 bf 40 00 00 00    	mov    $0x40,%r15d
   72e40:	4c 0f 45 f9          	cmovne %rcx,%r15
/workspace/scratch/parse-branches/old-runtime/heap.c:238
   72e44:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
   72e4b:	00 
   72e4c:	48 89 c7             	mov    %rax,%rdi
   72e4f:	e8 ec 93 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/old-runtime/heap.c:239
   72e54:	48 85 c0             	test   %rax,%rax
   72e57:	74 2f                	je     72e88 <adamic_release+0x518>
/workspace/scratch/parse-branches/old-runtime/heap.c:243
   72e59:	48 89 05 30 c2 06 00 	mov    %rax,0x6c230(%rip)        # df090 <freeing>
/workspace/scratch/parse-branches/old-runtime/heap.c:244
   72e60:	4c 89 3d d9 c2 06 00 	mov    %r15,0x6c2d9(%rip)        # df140 <freeing_capacity>
   72e67:	4c 89 f7             	mov    %r14,%rdi
/workspace/scratch/parse-branches/old-runtime/heap.c:246
   72e6a:	48 8d 4b 01          	lea    0x1(%rbx),%rcx
   72e6e:	48 89 0d 13 c2 06 00 	mov    %rcx,0x6c213(%rip)        # df088 <freeing_count>
   72e75:	48 89 3c d8          	mov    %rdi,(%rax,%rbx,8)
adamic_release():
/workspace/scratch/parse-branches/old-runtime/heap.c:321
   72e79:	80 3d 00 c2 06 00 00 	cmpb   $0x0,0x6c200(%rip)        # df080 <draining>
   72e80:	0f 84 1b fb ff ff    	je     729a1 <adamic_release+0x31>
   72e86:	eb 82                	jmp    72e0a <adamic_release+0x49a>
   72e88:	48 8d 3d af ee 01 00 	lea    0x1eeaf(%rip),%rdi        # 91d3e <list.message>
   72e8f:	be 0d 00 00 00       	mov    $0xd,%esi
   72e94:	e8 77 89 ff ff       	call   6b810 <adamic_panic>

Disassembly of section .fini:
