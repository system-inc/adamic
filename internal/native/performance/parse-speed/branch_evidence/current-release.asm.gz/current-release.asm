
/workspace/scratch/parse-branches/current:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000072970 <adamic_release>:
adamic_release():
/workspace/scratch/parse-branches/current-runtime/heap.c:337
   72970:	48 85 ff             	test   %rdi,%rdi
   72973:	74 10                	je     72985 <adamic_release+0x15>
   72975:	48 8b 07             	mov    (%rdi),%rax
   72978:	48 85 c0             	test   %rax,%rax
   7297b:	74 08                	je     72985 <adamic_release+0x15>
   7297d:	48 ff c8             	dec    %rax
   72980:	48 89 07             	mov    %rax,(%rdi)
   72983:	74 01                	je     72986 <adamic_release+0x16>
/workspace/scratch/parse-branches/current-runtime/heap.c:340
   72985:	c3                   	ret
   72986:	50                   	push   %rax
/workspace/scratch/parse-branches/current-runtime/heap.c:338
   72987:	e8 14 00 00 00       	call   729a0 <destroy_last_reference>
   7298c:	48 83 c4 08          	add    $0x8,%rsp
/workspace/scratch/parse-branches/current-runtime/heap.c:340
   72990:	c3                   	ret

Disassembly of section .fini:
