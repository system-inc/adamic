
/workspace/scratch/parse-branches/current:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000729a0 <destroy_last_reference>:
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:321
   729a0:	55                   	push   %rbp
   729a1:	41 57                	push   %r15
   729a3:	41 56                	push   %r14
   729a5:	41 55                	push   %r13
   729a7:	41 54                	push   %r12
   729a9:	53                   	push   %rbx
   729aa:	50                   	push   %rax
   729ab:	48 89 fb             	mov    %rdi,%rbx
list():
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   729ae:	4c 8b 35 73 c7 06 00 	mov    0x6c773(%rip),%r14        # df128 <freeing_count>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   729b5:	48 8b 05 74 c7 06 00 	mov    0x6c774(%rip),%rax        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   729bc:	4c 3b 35 75 c7 06 00 	cmp    0x6c775(%rip),%r14        # df138 <freeing_capacity>
   729c3:	75 38                	jne    729fd <destroy_last_reference+0x5d>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   729c5:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
   729c9:	4d 85 f6             	test   %r14,%r14
   729cc:	41 bf 40 00 00 00    	mov    $0x40,%r15d
   729d2:	4c 0f 45 f9          	cmovne %rcx,%r15
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   729d6:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
   729dd:	00 
   729de:	48 89 c7             	mov    %rax,%rdi
   729e1:	e8 5a 98 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   729e6:	48 85 c0             	test   %rax,%rax
   729e9:	0f 84 9a 04 00 00    	je     72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   729ef:	48 89 05 3a c7 06 00 	mov    %rax,0x6c73a(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   729f6:	4c 89 3d 3b c7 06 00 	mov    %r15,0x6c73b(%rip)        # df138 <freeing_capacity>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   729fd:	4d 8d 6e 01          	lea    0x1(%r14),%r13
   72a01:	4c 89 2d 20 c7 06 00 	mov    %r13,0x6c720(%rip)        # df128 <freeing_count>
   72a08:	4a 89 1c f0          	mov    %rbx,(%rax,%r14,8)
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:323
   72a0c:	80 3d 0d c7 06 00 00 	cmpb   $0x0,0x6c70d(%rip)        # df120 <draining>
   72a13:	0f 85 61 04 00 00    	jne    72e7a <destroy_last_reference+0x4da>
/workspace/scratch/parse-branches/current-runtime/heap.c:327
   72a19:	c6 05 00 c7 06 00 01 	movb   $0x1,0x6c700(%rip)        # df120 <draining>
/workspace/scratch/parse-branches/current-runtime/heap.c:328
   72a20:	4d 85 ed             	test   %r13,%r13
   72a23:	0f 84 4a 04 00 00    	je     72e73 <destroy_last_reference+0x4d3>
   72a29:	4c 8d 25 bc f2 01 00 	lea    0x1f2bc(%rip),%r12        # 91cec <codes_add.message+0x11>
   72a30:	eb 26                	jmp    72a58 <destroy_last_reference+0xb8>
   72a32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   72a39:	1f 84 00 00 00 00 00 
/workspace/scratch/parse-branches/current-runtime/heap.c:212
   72a40:	4c 89 f7             	mov    %r14,%rdi
   72a43:	e8 f8 95 f9 ff       	call   c040 <free@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:328
   72a48:	4c 8b 2d d9 c6 06 00 	mov    0x6c6d9(%rip),%r13        # df128 <freeing_count>
   72a4f:	4d 85 ed             	test   %r13,%r13
   72a52:	0f 84 1b 04 00 00    	je     72e73 <destroy_last_reference+0x4d3>
/workspace/scratch/parse-branches/current-runtime/heap.c:329
   72a58:	48 8b 05 d1 c6 06 00 	mov    0x6c6d1(%rip),%rax        # df130 <freeing>
   72a5f:	49 8d 6d ff          	lea    -0x1(%r13),%rbp
   72a63:	48 89 2d be c6 06 00 	mov    %rbp,0x6c6be(%rip)        # df128 <freeing_count>
   72a6a:	4e 8b 74 e8 f8       	mov    -0x8(%rax,%r13,8),%r14
/workspace/scratch/parse-branches/current-runtime/heap.c:259
   72a6f:	41 8b 4e 08          	mov    0x8(%r14),%ecx
   72a73:	ff c9                	dec    %ecx
   72a75:	83 f9 09             	cmp    $0x9,%ecx
   72a78:	0f 87 22 03 00 00    	ja     72da0 <destroy_last_reference+0x400>
   72a7e:	49 63 0c 8c          	movslq (%r12,%rcx,4),%rcx
   72a82:	4c 01 e1             	add    %r12,%rcx
   72a85:	ff e1                	jmp    *%rcx
/workspace/scratch/parse-branches/current-runtime/heap.c:261
   72a87:	4c 89 f7             	mov    %r14,%rdi
   72a8a:	e8 21 61 01 00       	call   88bb0 <adamic_string_free_index>
/workspace/scratch/parse-branches/current-runtime/heap.c:263
   72a8f:	49 8b 5e 30          	mov    0x30(%r14),%rbx
let_go():
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72a93:	48 85 db             	test   %rbx,%rbx
   72a96:	0f 84 04 03 00 00    	je     72da0 <destroy_last_reference+0x400>
   72a9c:	48 8b 03             	mov    (%rbx),%rax
   72a9f:	48 85 c0             	test   %rax,%rax
   72aa2:	0f 84 f8 02 00 00    	je     72da0 <destroy_last_reference+0x400>
   72aa8:	48 ff c8             	dec    %rax
   72aab:	48 89 03             	mov    %rax,(%rbx)
   72aae:	0f 85 ec 02 00 00    	jne    72da0 <destroy_last_reference+0x400>
list():
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72ab4:	4c 8b 3d 6d c6 06 00 	mov    0x6c66d(%rip),%r15        # df128 <freeing_count>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72abb:	48 8b 05 6e c6 06 00 	mov    0x6c66e(%rip),%rax        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72ac2:	4c 3b 3d 6f c6 06 00 	cmp    0x6c66f(%rip),%r15        # df138 <freeing_capacity>
   72ac9:	75 37                	jne    72b02 <destroy_last_reference+0x162>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   72acb:	4f 8d 2c 3f          	lea    (%r15,%r15,1),%r13
   72acf:	4d 85 ff             	test   %r15,%r15
   72ad2:	b9 40 00 00 00       	mov    $0x40,%ecx
   72ad7:	4c 0f 44 e9          	cmove  %rcx,%r13
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   72adb:	4a 8d 34 ed 00 00 00 	lea    0x0(,%r13,8),%rsi
   72ae2:	00 
   72ae3:	48 89 c7             	mov    %rax,%rdi
   72ae6:	e8 55 97 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   72aeb:	48 85 c0             	test   %rax,%rax
   72aee:	0f 84 95 03 00 00    	je     72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   72af4:	48 89 05 35 c6 06 00 	mov    %rax,0x6c635(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   72afb:	4c 89 2d 36 c6 06 00 	mov    %r13,0x6c636(%rip)        # df138 <freeing_capacity>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72b02:	49 8d 4f 01          	lea    0x1(%r15),%rcx
   72b06:	48 89 0d 1b c6 06 00 	mov    %rcx,0x6c61b(%rip)        # df128 <freeing_count>
   72b0d:	4a 89 1c f8          	mov    %rbx,(%rax,%r15,8)
let_go():
/workspace/scratch/parse-branches/current-runtime/heap.c:254
   72b11:	e9 8a 02 00 00       	jmp    72da0 <destroy_last_reference+0x400>
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:293
   72b16:	49 83 7e 18 00       	cmpq   $0x0,0x18(%r14)
   72b1b:	0f 84 7f 02 00 00    	je     72da0 <destroy_last_reference+0x400>
   72b21:	48 8b 1d 10 c6 06 00 	mov    0x6c610(%rip),%rbx        # df138 <freeing_capacity>
   72b28:	45 31 ed             	xor    %r13d,%r13d
   72b2b:	eb 20                	jmp    72b4d <destroy_last_reference+0x1ad>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72b2d:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   72b31:	48 89 0d f0 c5 06 00 	mov    %rcx,0x6c5f0(%rip)        # df128 <freeing_count>
   72b38:	4c 89 3c e8          	mov    %r15,(%rax,%rbp,8)
   72b3c:	48 89 cd             	mov    %rcx,%rbp
   72b3f:	90                   	nop
/workspace/scratch/parse-branches/current-runtime/heap.c:293
   72b40:	49 ff c5             	inc    %r13
   72b43:	4d 3b 6e 18          	cmp    0x18(%r14),%r13
   72b47:	0f 83 53 02 00 00    	jae    72da0 <destroy_last_reference+0x400>
/workspace/scratch/parse-branches/current-runtime/heap.c:294
   72b4d:	4f 8b 7c ee 20       	mov    0x20(%r14,%r13,8),%r15
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72b52:	4d 85 ff             	test   %r15,%r15
   72b55:	74 e9                	je     72b40 <destroy_last_reference+0x1a0>
   72b57:	49 8b 0f             	mov    (%r15),%rcx
   72b5a:	48 85 c9             	test   %rcx,%rcx
   72b5d:	74 e1                	je     72b40 <destroy_last_reference+0x1a0>
   72b5f:	48 ff c9             	dec    %rcx
   72b62:	49 89 0f             	mov    %rcx,(%r15)
   72b65:	75 d9                	jne    72b40 <destroy_last_reference+0x1a0>
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72b67:	48 39 dd             	cmp    %rbx,%rbp
   72b6a:	75 c1                	jne    72b2d <destroy_last_reference+0x18d>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   72b6c:	48 8d 1c 6d 00 00 00 	lea    0x0(,%rbp,2),%rbx
   72b73:	00 
   72b74:	48 85 ed             	test   %rbp,%rbp
   72b77:	b9 40 00 00 00       	mov    $0x40,%ecx
   72b7c:	48 0f 44 d9          	cmove  %rcx,%rbx
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   72b80:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
   72b87:	00 
   72b88:	48 89 c7             	mov    %rax,%rdi
   72b8b:	e8 b0 96 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   72b90:	48 85 c0             	test   %rax,%rax
   72b93:	0f 84 f0 02 00 00    	je     72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   72b99:	48 89 05 90 c5 06 00 	mov    %rax,0x6c590(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   72ba0:	48 89 1d 91 c5 06 00 	mov    %rbx,0x6c591(%rip)        # df138 <freeing_capacity>
   72ba7:	eb 84                	jmp    72b2d <destroy_last_reference+0x18d>
/workspace/scratch/parse-branches/current-runtime/heap.c:267
   72ba9:	4c 89 f7             	mov    %r14,%rdi
   72bac:	48 8d 35 ed 02 00 00 	lea    0x2ed(%rip),%rsi        # 72ea0 <let_go>
   72bb3:	e8 a8 b8 ff ff       	call   6e460 <adamic_object_free_children>
/workspace/scratch/parse-branches/current-runtime/heap.c:283
   72bb8:	e9 e3 01 00 00       	jmp    72da0 <destroy_last_reference+0x400>
/workspace/scratch/parse-branches/current-runtime/heap.c:307
   72bbd:	49 8b 5e 10          	mov    0x10(%r14),%rbx
   72bc1:	48 ff 4b 48          	decq   0x48(%rbx)
let_go():
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72bc5:	eb 5f                	jmp    72c26 <destroy_last_reference+0x286>
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:302
   72bc7:	4c 89 f7             	mov    %r14,%rdi
   72bca:	e8 11 68 01 00       	call   893e0 <adamic_weak_dropped>
/workspace/scratch/parse-branches/current-runtime/heap.c:303
   72bcf:	e9 cc 01 00 00       	jmp    72da0 <destroy_last_reference+0x400>
/workspace/scratch/parse-branches/current-runtime/heap.c:272
   72bd4:	41 80 7e 20 01       	cmpb   $0x1,0x20(%r14)
   72bd9:	0f 85 3d 01 00 00    	jne    72d1c <destroy_last_reference+0x37c>
/workspace/scratch/parse-branches/current-runtime/heap.c:273
   72bdf:	49 8b 4e 10          	mov    0x10(%r14),%rcx
   72be3:	48 85 c9             	test   %rcx,%rcx
   72be6:	0f 84 30 01 00 00    	je     72d1c <destroy_last_reference+0x37c>
   72bec:	4c 8b 2d 45 c5 06 00 	mov    0x6c545(%rip),%r13        # df138 <freeing_capacity>
   72bf3:	31 db                	xor    %ebx,%ebx
   72bf5:	e9 ce 00 00 00       	jmp    72cc8 <destroy_last_reference+0x328>
/workspace/scratch/parse-branches/current-runtime/heap.c:282
   72bfa:	4c 89 f7             	mov    %r14,%rdi
   72bfd:	48 8d 35 9c 02 00 00 	lea    0x29c(%rip),%rsi        # 72ea0 <let_go>
   72c04:	e8 b7 7b 00 00       	call   7a7c0 <adamic_map_free_children>
/workspace/scratch/parse-branches/current-runtime/heap.c:283
   72c09:	e9 92 01 00 00       	jmp    72da0 <destroy_last_reference+0x400>
/workspace/scratch/parse-branches/current-runtime/heap.c:286
   72c0e:	41 80 7e 10 01       	cmpb   $0x1,0x10(%r14)
   72c13:	0f 85 87 01 00 00    	jne    72da0 <destroy_last_reference+0x400>
/workspace/scratch/parse-branches/current-runtime/heap.c:287
   72c19:	49 8b 5e 18          	mov    0x18(%r14),%rbx
let_go():
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72c1d:	48 85 db             	test   %rbx,%rbx
   72c20:	0f 84 7a 01 00 00    	je     72da0 <destroy_last_reference+0x400>
   72c26:	48 8b 0b             	mov    (%rbx),%rcx
   72c29:	48 85 c9             	test   %rcx,%rcx
   72c2c:	0f 84 6e 01 00 00    	je     72da0 <destroy_last_reference+0x400>
   72c32:	48 ff c9             	dec    %rcx
   72c35:	48 89 0b             	mov    %rcx,(%rbx)
   72c38:	0f 85 62 01 00 00    	jne    72da0 <destroy_last_reference+0x400>
list():
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72c3e:	48 3b 2d f3 c4 06 00 	cmp    0x6c4f3(%rip),%rbp        # df138 <freeing_capacity>
   72c45:	75 3b                	jne    72c82 <destroy_last_reference+0x2e2>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   72c47:	4c 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%r15
   72c4e:	00 
   72c4f:	48 85 ed             	test   %rbp,%rbp
   72c52:	b9 40 00 00 00       	mov    $0x40,%ecx
   72c57:	4c 0f 44 f9          	cmove  %rcx,%r15
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   72c5b:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
   72c62:	00 
   72c63:	48 89 c7             	mov    %rax,%rdi
   72c66:	e8 d5 95 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   72c6b:	48 85 c0             	test   %rax,%rax
   72c6e:	0f 84 15 02 00 00    	je     72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   72c74:	48 89 05 b5 c4 06 00 	mov    %rax,0x6c4b5(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   72c7b:	4c 89 3d b6 c4 06 00 	mov    %r15,0x6c4b6(%rip)        # df138 <freeing_capacity>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72c82:	4c 89 2d 9f c4 06 00 	mov    %r13,0x6c49f(%rip)        # df128 <freeing_count>
   72c89:	4a 89 5c e8 f8       	mov    %rbx,-0x8(%rax,%r13,8)
   72c8e:	e9 0d 01 00 00       	jmp    72da0 <destroy_last_reference+0x400>
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   72c93:	48 89 05 96 c4 06 00 	mov    %rax,0x6c496(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   72c9a:	4c 89 2d 97 c4 06 00 	mov    %r13,0x6c497(%rip)        # df138 <freeing_capacity>
/workspace/scratch/parse-branches/current-runtime/heap.c:273
   72ca1:	49 8b 4e 10          	mov    0x10(%r14),%rcx
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72ca5:	48 8d 55 01          	lea    0x1(%rbp),%rdx
   72ca9:	48 89 15 78 c4 06 00 	mov    %rdx,0x6c478(%rip)        # df128 <freeing_count>
   72cb0:	4c 89 3c e8          	mov    %r15,(%rax,%rbp,8)
   72cb4:	48 89 d5             	mov    %rdx,%rbp
   72cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   72cbe:	00 00 
/workspace/scratch/parse-branches/current-runtime/heap.c:273
   72cc0:	48 ff c3             	inc    %rbx
   72cc3:	48 39 cb             	cmp    %rcx,%rbx
   72cc6:	73 54                	jae    72d1c <destroy_last_reference+0x37c>
/workspace/scratch/parse-branches/current-runtime/heap.c:274
   72cc8:	49 8b 56 28          	mov    0x28(%r14),%rdx
   72ccc:	4c 8b 3c da          	mov    (%rdx,%rbx,8),%r15
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72cd0:	4d 85 ff             	test   %r15,%r15
   72cd3:	74 eb                	je     72cc0 <destroy_last_reference+0x320>
   72cd5:	49 8b 17             	mov    (%r15),%rdx
   72cd8:	48 85 d2             	test   %rdx,%rdx
   72cdb:	74 e3                	je     72cc0 <destroy_last_reference+0x320>
   72cdd:	48 ff ca             	dec    %rdx
   72ce0:	49 89 17             	mov    %rdx,(%r15)
   72ce3:	75 db                	jne    72cc0 <destroy_last_reference+0x320>
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72ce5:	4c 39 ed             	cmp    %r13,%rbp
   72ce8:	75 bb                	jne    72ca5 <destroy_last_reference+0x305>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   72cea:	4c 8d 2c 6d 00 00 00 	lea    0x0(,%rbp,2),%r13
   72cf1:	00 
   72cf2:	48 85 ed             	test   %rbp,%rbp
   72cf5:	b9 40 00 00 00       	mov    $0x40,%ecx
   72cfa:	4c 0f 44 e9          	cmove  %rcx,%r13
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   72cfe:	4a 8d 34 ed 00 00 00 	lea    0x0(,%r13,8),%rsi
   72d05:	00 
   72d06:	48 89 c7             	mov    %rax,%rdi
   72d09:	e8 32 95 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   72d0e:	48 85 c0             	test   %rax,%rax
   72d11:	0f 85 7c ff ff ff    	jne    72c93 <destroy_last_reference+0x2f3>
   72d17:	e9 6d 01 00 00       	jmp    72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:277
   72d1c:	49 8b 5e 30          	mov    0x30(%r14),%rbx
let_go():
/workspace/scratch/parse-branches/current-runtime/heap.c:252
   72d20:	48 85 db             	test   %rbx,%rbx
   72d23:	74 63                	je     72d88 <destroy_last_reference+0x3e8>
   72d25:	48 8b 0b             	mov    (%rbx),%rcx
   72d28:	48 85 c9             	test   %rcx,%rcx
   72d2b:	74 5b                	je     72d88 <destroy_last_reference+0x3e8>
   72d2d:	48 ff c9             	dec    %rcx
   72d30:	48 89 0b             	mov    %rcx,(%rbx)
   72d33:	75 53                	jne    72d88 <destroy_last_reference+0x3e8>
list():
/workspace/scratch/parse-branches/current-runtime/heap.c:236
   72d35:	48 3b 2d fc c3 06 00 	cmp    0x6c3fc(%rip),%rbp        # df138 <freeing_capacity>
   72d3c:	75 3b                	jne    72d79 <destroy_last_reference+0x3d9>
/workspace/scratch/parse-branches/current-runtime/heap.c:237
   72d3e:	4c 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%r15
   72d45:	00 
   72d46:	48 85 ed             	test   %rbp,%rbp
   72d49:	b9 40 00 00 00       	mov    $0x40,%ecx
   72d4e:	4c 0f 44 f9          	cmove  %rcx,%r15
/workspace/scratch/parse-branches/current-runtime/heap.c:238
   72d52:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
   72d59:	00 
   72d5a:	48 89 c7             	mov    %rax,%rdi
   72d5d:	e8 de 94 f9 ff       	call   c240 <realloc@plt>
/workspace/scratch/parse-branches/current-runtime/heap.c:239
   72d62:	48 85 c0             	test   %rax,%rax
   72d65:	0f 84 1e 01 00 00    	je     72e89 <destroy_last_reference+0x4e9>
/workspace/scratch/parse-branches/current-runtime/heap.c:243
   72d6b:	48 89 05 be c3 06 00 	mov    %rax,0x6c3be(%rip)        # df130 <freeing>
/workspace/scratch/parse-branches/current-runtime/heap.c:244
   72d72:	4c 89 3d bf c3 06 00 	mov    %r15,0x6c3bf(%rip)        # df138 <freeing_capacity>
/workspace/scratch/parse-branches/current-runtime/heap.c:246
   72d79:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   72d7d:	48 89 0d a4 c3 06 00 	mov    %rcx,0x6c3a4(%rip)        # df128 <freeing_count>
   72d84:	48 89 1c e8          	mov    %rbx,(%rax,%rbp,8)
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:278
   72d88:	49 8b 7e 28          	mov    0x28(%r14),%rdi
   72d8c:	e8 af 92 f9 ff       	call   c040 <free@plt>
   72d91:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   72d98:	0f 1f 84 00 00 00 00 
   72d9f:	00 
/workspace/scratch/parse-branches/current-runtime/heap.c:313
   72da0:	4c 89 f7             	mov    %r14,%rdi
   72da3:	e8 68 65 01 00       	call   89310 <adamic_weak_forget>
/workspace/scratch/parse-branches/current-runtime/heap.c:211
   72da8:	41 8b 46 0c          	mov    0xc(%r14),%eax
   72dac:	85 c0                	test   %eax,%eax
   72dae:	0f 84 8c fc ff ff    	je     72a40 <destroy_last_reference+0xa0>
/workspace/scratch/parse-branches/current-runtime/heap.c:215
   72db4:	ff c8                	dec    %eax
give():
/workspace/scratch/parse-branches/current-runtime/heap.c:165
   72db6:	48 8b 0d 5b c3 06 00 	mov    0x6c35b(%rip),%rcx        # df118 <chunks>
   72dbd:	48 8b 04 c1          	mov    (%rcx,%rax,8),%rax
/workspace/scratch/parse-branches/current-runtime/heap.c:168
   72dc1:	48 8b 50 18          	mov    0x18(%rax),%rdx
/workspace/scratch/parse-branches/current-runtime/heap.c:166
   72dc5:	48 8b 48 38          	mov    0x38(%rax),%rcx
/workspace/scratch/parse-branches/current-runtime/heap.c:168
   72dc9:	49 89 16             	mov    %rdx,(%r14)
/workspace/scratch/parse-branches/current-runtime/heap.c:169
   72dcc:	4c 89 70 18          	mov    %r14,0x18(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:173
   72dd0:	48 8b 50 30          	mov    0x30(%rax),%rdx
   72dd4:	48 ff ca             	dec    %rdx
   72dd7:	48 89 50 30          	mov    %rdx,0x30(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:174
   72ddb:	80 78 10 00          	cmpb   $0x0,0x10(%rax)
   72ddf:	75 2d                	jne    72e0e <destroy_last_reference+0x46e>
list_chunk():
/workspace/scratch/parse-branches/current-runtime/heap.c:85
   72de1:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:86
   72de8:	48 8d 35 91 c2 06 00 	lea    0x6c291(%rip),%rsi        # df080 <giving>
   72def:	48 8b 34 ce          	mov    (%rsi,%rcx,8),%rsi
   72df3:	48 89 70 08          	mov    %rsi,0x8(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:87
   72df7:	48 85 f6             	test   %rsi,%rsi
   72dfa:	74 03                	je     72dff <destroy_last_reference+0x45f>
/workspace/scratch/parse-branches/current-runtime/heap.c:88
   72dfc:	48 89 06             	mov    %rax,(%rsi)
/workspace/scratch/parse-branches/current-runtime/heap.c:90
   72dff:	48 8d 35 7a c2 06 00 	lea    0x6c27a(%rip),%rsi        # df080 <giving>
   72e06:	48 89 04 ce          	mov    %rax,(%rsi,%rcx,8)
/workspace/scratch/parse-branches/current-runtime/heap.c:91
   72e0a:	c6 40 10 01          	movb   $0x1,0x10(%rax)
give():
/workspace/scratch/parse-branches/current-runtime/heap.c:177
   72e0e:	48 85 d2             	test   %rdx,%rdx
   72e11:	0f 85 31 fc ff ff    	jne    72a48 <destroy_last_reference+0xa8>
   72e17:	48 8d 15 62 c2 06 00 	lea    0x6c262(%rip),%rdx        # df080 <giving>
   72e1e:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   72e22:	48 31 c6             	xor    %rax,%rsi
   72e25:	48 8b 50 08          	mov    0x8(%rax),%rdx
   72e29:	48 09 d6             	or     %rdx,%rsi
   72e2c:	0f 84 16 fc ff ff    	je     72a48 <destroy_last_reference+0xa8>
/workspace/scratch/parse-branches/current-runtime/heap.c:95
   72e32:	48 8b 30             	mov    (%rax),%rsi
   72e35:	48 85 f6             	test   %rsi,%rsi
   72e38:	74 27                	je     72e61 <destroy_last_reference+0x4c1>
/workspace/scratch/parse-branches/current-runtime/heap.c:96
   72e3a:	48 89 56 08          	mov    %rdx,0x8(%rsi)
   72e3e:	48 85 d2             	test   %rdx,%rdx
/workspace/scratch/parse-branches/current-runtime/heap.c:100
   72e41:	74 03                	je     72e46 <destroy_last_reference+0x4a6>
/workspace/scratch/parse-branches/current-runtime/heap.c:101
   72e43:	48 89 32             	mov    %rsi,(%rdx)
/workspace/scratch/parse-branches/current-runtime/heap.c:103
   72e46:	c6 40 10 00          	movb   $0x0,0x10(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:183
   72e4a:	48 8b 0d af c2 06 00 	mov    0x6c2af(%rip),%rcx        # df100 <spares>
   72e51:	48 89 48 08          	mov    %rcx,0x8(%rax)
/workspace/scratch/parse-branches/current-runtime/heap.c:184
   72e55:	48 89 05 a4 c2 06 00 	mov    %rax,0x6c2a4(%rip)        # df100 <spares>
   72e5c:	e9 e7 fb ff ff       	jmp    72a48 <destroy_last_reference+0xa8>
/workspace/scratch/parse-branches/current-runtime/heap.c:98
   72e61:	48 8d 3d 18 c2 06 00 	lea    0x6c218(%rip),%rdi        # df080 <giving>
   72e68:	48 89 14 cf          	mov    %rdx,(%rdi,%rcx,8)
   72e6c:	48 85 d2             	test   %rdx,%rdx
/workspace/scratch/parse-branches/current-runtime/heap.c:100
   72e6f:	75 d2                	jne    72e43 <destroy_last_reference+0x4a3>
   72e71:	eb d3                	jmp    72e46 <destroy_last_reference+0x4a6>
destroy_last_reference():
/workspace/scratch/parse-branches/current-runtime/heap.c:331
   72e73:	c6 05 a6 c2 06 00 00 	movb   $0x0,0x6c2a6(%rip)        # df120 <draining>
/workspace/scratch/parse-branches/current-runtime/heap.c:332
   72e7a:	48 83 c4 08          	add    $0x8,%rsp
   72e7e:	5b                   	pop    %rbx
   72e7f:	41 5c                	pop    %r12
   72e81:	41 5d                	pop    %r13
   72e83:	41 5e                	pop    %r14
   72e85:	41 5f                	pop    %r15
   72e87:	5d                   	pop    %rbp
   72e88:	c3                   	ret
   72e89:	48 8d 3d ae ee 01 00 	lea    0x1eeae(%rip),%rdi        # 91d3e <list.message>
   72e90:	be 0d 00 00 00       	mov    $0xd,%esi
   72e95:	e8 76 89 ff ff       	call   6b810 <adamic_panic>

Disassembly of section .fini:
