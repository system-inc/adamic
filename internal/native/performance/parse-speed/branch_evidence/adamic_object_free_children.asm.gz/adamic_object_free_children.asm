
/workspace/scratch/parse-branches/current:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000006e460 <adamic_object_free_children>:
adamic_object_free_children():
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:30
   6e460:	41 57                	push   %r15
   6e462:	41 56                	push   %r14
   6e464:	41 54                	push   %r12
   6e466:	53                   	push   %rbx
   6e467:	50                   	push   %rax
   6e468:	48 89 f3             	mov    %rsi,%rbx
   6e46b:	49 89 fe             	mov    %rdi,%r14
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:31
   6e46e:	4c 8b 7f 18          	mov    0x18(%rdi),%r15
   6e472:	4d 85 ff             	test   %r15,%r15
   6e475:	75 21                	jne    6e498 <adamic_object_free_children+0x38>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:32
   6e477:	49 8b 46 10          	mov    0x10(%r14),%rax
   6e47b:	48 8b 08             	mov    (%rax),%rcx
   6e47e:	48 85 c9             	test   %rcx,%rcx
   6e481:	0f 84 87 00 00 00    	je     6e50e <adamic_object_free_children+0xae>
   6e487:	45 31 ff             	xor    %r15d,%r15d
   6e48a:	eb 5c                	jmp    6e4e8 <adamic_object_free_children+0x88>
   6e48c:	0f 1f 40 00          	nopl   0x0(%rax)
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:38
   6e490:	4d 8b 3f             	mov    (%r15),%r15
   6e493:	4d 85 ff             	test   %r15,%r15
   6e496:	74 76                	je     6e50e <adamic_object_free_children+0xae>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:39
   6e498:	49 8b 47 08          	mov    0x8(%r15),%rax
   6e49c:	4d 8b 67 10          	mov    0x10(%r15),%r12
   6e4a0:	49 39 c4             	cmp    %rax,%r12
   6e4a3:	76 eb                	jbe    6e490 <adamic_object_free_children+0x30>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:25
   6e4a5:	49 8b 4e 10          	mov    0x10(%r14),%rcx
   6e4a9:	48 8b 49 10          	mov    0x10(%rcx),%rcx
   6e4ad:	42 80 7c 21 ff 01    	cmpb   $0x1,-0x1(%rcx,%r12,1)
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:40
   6e4b3:	4d 8d 64 24 ff       	lea    -0x1(%r12),%r12
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:25
   6e4b8:	75 e6                	jne    6e4a0 <adamic_object_free_children+0x40>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:26
   6e4ba:	4b 8b 7c e6 28       	mov    0x28(%r14,%r12,8),%rdi
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:27
   6e4bf:	48 85 ff             	test   %rdi,%rdi
   6e4c2:	74 dc                	je     6e4a0 <adamic_object_free_children+0x40>
   6e4c4:	48 83 3f 00          	cmpq   $0x0,(%rdi)
   6e4c8:	74 d6                	je     6e4a0 <adamic_object_free_children+0x40>
   6e4ca:	ff d3                	call   *%rbx
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:39
   6e4cc:	49 8b 47 08          	mov    0x8(%r15),%rax
   6e4d0:	eb ce                	jmp    6e4a0 <adamic_object_free_children+0x40>
   6e4d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   6e4d9:	1f 84 00 00 00 00 00 
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:32
   6e4e0:	49 ff c7             	inc    %r15
   6e4e3:	49 39 cf             	cmp    %rcx,%r15
   6e4e6:	73 26                	jae    6e50e <adamic_object_free_children+0xae>
release_field():
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:25
   6e4e8:	48 8b 50 10          	mov    0x10(%rax),%rdx
   6e4ec:	42 80 3c 3a 01       	cmpb   $0x1,(%rdx,%r15,1)
   6e4f1:	75 ed                	jne    6e4e0 <adamic_object_free_children+0x80>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:26
   6e4f3:	4b 8b 7c fe 28       	mov    0x28(%r14,%r15,8),%rdi
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:27
   6e4f8:	48 85 ff             	test   %rdi,%rdi
   6e4fb:	74 e3                	je     6e4e0 <adamic_object_free_children+0x80>
   6e4fd:	48 83 3f 00          	cmpq   $0x0,(%rdi)
   6e501:	74 dd                	je     6e4e0 <adamic_object_free_children+0x80>
   6e503:	ff d3                	call   *%rbx
adamic_object_free_children():
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:32
   6e505:	49 8b 46 10          	mov    0x10(%r14),%rax
   6e509:	48 8b 08             	mov    (%rax),%rcx
   6e50c:	eb d2                	jmp    6e4e0 <adamic_object_free_children+0x80>
/workspace/scratch/parse-branches/current-runtime/class_inheritance.c:44
   6e50e:	48 83 c4 08          	add    $0x8,%rsp
   6e512:	5b                   	pop    %rbx
   6e513:	41 5c                	pop    %r12
   6e515:	41 5e                	pop    %r14
   6e517:	41 5f                	pop    %r15
   6e519:	c3                   	ret

Disassembly of section .fini:
