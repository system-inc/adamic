// class_inheritance.c: nominal identity, virtual dispatch and one derived-to-base release chain.
#include "adamic.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static size_t node_objects, node_scalar;
static bool is_parse_node(const adamic_object *object) {
 const adamic_shape *shape=object->shape;
 return shape->count==13 && strcmp(shape->names[0],"kind")==0 && strcmp(shape->names[3],"children")==0 && strcmp(shape->names[12],"multiLine")==0;
}
static size_t scalar_class, scalar_plain, reference_class, reference_plain, object_class, object_plain;
static void report_slot_visits(void) {
 fprintf(stderr, "slot_visits scalar_class=%zu scalar_plain=%zu reference_class=%zu reference_plain=%zu object_class=%zu object_plain=%zu node_objects=%zu node_scalar=%zu\n",scalar_class,scalar_plain,reference_class,reference_plain,object_class,object_plain,node_objects,node_scalar);
}


bool adamic_instanceof(const void *value, const adamic_class *wanted) {
	const adamic_heap *heap = value;
	if (heap == NULL || heap->kind != adamic_kind_object) { return false; }
	const adamic_object *object = value;
	for (const adamic_class *class = object->class; class != NULL; class = class->base) {
		if (class == wanted || (wanted->definition != 0 && class->definition == wanted->definition)) { return true; }
	}
	return false;
}

adamic_virtual_method adamic_virtual(const adamic_object *object, size_t slot) {
	if (object == NULL || object->class == NULL) {
		static const char message[] = "compiler bug: virtual call on an object without class identity";
		adamic_panic(message, sizeof message - 1);
	}
	return object->class->methods[slot];
}

// Arena children and immortal values have no count to drop. Keeping them out of the callback
// preserves the region teardown's counting and avoids treating arena storage as heap-owned.
static void release_field(adamic_object *object, size_t index, void (*release)(void *)) {
	if (!object->shape->references[index]) {
 if(object->class != NULL) scalar_class++; else scalar_plain++;
 if(is_parse_node(object)) node_scalar++;
 return;
 }
 if(object->class != NULL) reference_class++; else reference_plain++;
	adamic_heap *child = object->slots[index].reference;
	if (child != NULL && child->references != 0) { release(child); }
}

void adamic_object_free_children(adamic_object *object, void (*release)(void *)) {
 static bool registered; if(!registered){atexit(report_slot_visits);registered=true;}
 if(object->class != NULL) object_class++; else object_plain++;
 if(is_parse_node(object)) node_objects++;
	if (object->class == NULL) {
		for (size_t index = 0; index < object->shape->count; index++) {
			release_field(object, index, release);
		}
		return;
	}
	// Listing children through the callback keeps heap destruction iterative, even for deep trees.
	for (const adamic_class *class = object->class; class != NULL; class = class->base) {
		for (size_t index = class->count; index > class->own_start; ) {
			index--;
			release_field(object, index, release);
		}
	}
}
