# 1 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1_initialize_04.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 409 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1_initialize_04.c" 2
# 1 "./units.h" 1


# 1 "./adamic.h" 1





# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdbool.h" 1 3
# 7 "./adamic.h" 2
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 1 3
# 84 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_header_macro.h" 1 3
# 85 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3



# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 89 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_size_t.h" 1 3
# 18 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 94 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 103 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_wchar_t.h" 1 3
# 24 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 104 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_null.h" 1 3
# 109 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 123 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_max_align_t.h" 1 3
# 19 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_max_align_t.h" 3
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
# 124 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_offsetof.h" 1 3
# 129 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 8 "./adamic.h" 2
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 1 3
# 56 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 3
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 415 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 416 "/usr/include/features.h" 2 3 4
# 501 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 502 "/usr/include/features.h" 2 3 4
# 523 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 524 "/usr/include/features.h" 2 3 4
# 547 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 548 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 57 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 2 3
# 9 "./adamic.h" 2

# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 28 "/usr/include/math.h" 2 3 4
# 40 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 2 3 4
# 41 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 83 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__)));
# 97 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
typedef __float128 _Float128;
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 44 "/usr/include/math.h" 2 3 4
# 156 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 157 "/usr/include/math.h" 2 3 4
# 167 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 208 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-logb.h" 1 3 4
# 209 "/usr/include/math.h" 2 3 4
# 251 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-fast.h" 1 3 4
# 252 "/usr/include/math.h" 2 3 4
# 275 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-macros.h" 1 3 4
# 276 "/usr/include/math.h" 2 3 4





# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinf (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnan (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsig (double __x, double __y) __attribute__ ((__nothrow__ ));


extern int __issignaling (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 282 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acos (double __x) __attribute__ ((__nothrow__ )); extern double __acos (double __x) __attribute__ ((__nothrow__ ));

 extern double asin (double __x) __attribute__ ((__nothrow__ )); extern double __asin (double __x) __attribute__ ((__nothrow__ ));

 extern double atan (double __x) __attribute__ ((__nothrow__ )); extern double __atan (double __x) __attribute__ ((__nothrow__ ));

 extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__ )); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__ ));


 extern double cos (double __x) __attribute__ ((__nothrow__ )); extern double __cos (double __x) __attribute__ ((__nothrow__ ));

 extern double sin (double __x) __attribute__ ((__nothrow__ )); extern double __sin (double __x) __attribute__ ((__nothrow__ ));

 extern double tan (double __x) __attribute__ ((__nothrow__ )); extern double __tan (double __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double cosh (double __x) __attribute__ ((__nothrow__ )); extern double __cosh (double __x) __attribute__ ((__nothrow__ ));

 extern double sinh (double __x) __attribute__ ((__nothrow__ )); extern double __sinh (double __x) __attribute__ ((__nothrow__ ));

 extern double tanh (double __x) __attribute__ ((__nothrow__ )); extern double __tanh (double __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acosh (double __x) __attribute__ ((__nothrow__ )); extern double __acosh (double __x) __attribute__ ((__nothrow__ ));

 extern double asinh (double __x) __attribute__ ((__nothrow__ )); extern double __asinh (double __x) __attribute__ ((__nothrow__ ));

 extern double atanh (double __x) __attribute__ ((__nothrow__ )); extern double __atanh (double __x) __attribute__ ((__nothrow__ ));





 extern double exp (double __x) __attribute__ ((__nothrow__ )); extern double __exp (double __x) __attribute__ ((__nothrow__ ));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ )); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern double log (double __x) __attribute__ ((__nothrow__ )); extern double __log (double __x) __attribute__ ((__nothrow__ ));


 extern double log10 (double __x) __attribute__ ((__nothrow__ )); extern double __log10 (double __x) __attribute__ ((__nothrow__ ));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double expm1 (double __x) __attribute__ ((__nothrow__ )); extern double __expm1 (double __x) __attribute__ ((__nothrow__ ));


 extern double log1p (double __x) __attribute__ ((__nothrow__ )); extern double __log1p (double __x) __attribute__ ((__nothrow__ ));


extern double logb (double __x) __attribute__ ((__nothrow__ )); extern double __logb (double __x) __attribute__ ((__nothrow__ ));




 extern double exp2 (double __x) __attribute__ ((__nothrow__ )); extern double __exp2 (double __x) __attribute__ ((__nothrow__ ));


 extern double log2 (double __x) __attribute__ ((__nothrow__ )); extern double __log2 (double __x) __attribute__ ((__nothrow__ ));






 extern double pow (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__ ));


extern double sqrt (double __x) __attribute__ ((__nothrow__ )); extern double __sqrt (double __x) __attribute__ ((__nothrow__ ));



 extern double hypot (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__ ));




 extern double cbrt (double __x) __attribute__ ((__nothrow__ )); extern double __cbrt (double __x) __attribute__ ((__nothrow__ ));






extern double ceil (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double copysign (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double nan (const char *__tagb) __attribute__ ((__nothrow__ )); extern double __nan (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double erf (double) __attribute__ ((__nothrow__ )); extern double __erf (double) __attribute__ ((__nothrow__ ));
 extern double erfc (double) __attribute__ ((__nothrow__ )); extern double __erfc (double) __attribute__ ((__nothrow__ ));
extern double lgamma (double) __attribute__ ((__nothrow__ )); extern double __lgamma (double) __attribute__ ((__nothrow__ ));




extern double tgamma (double) __attribute__ ((__nothrow__ )); extern double __tgamma (double) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double rint (double __x) __attribute__ ((__nothrow__ )); extern double __rint (double __x) __attribute__ ((__nothrow__ ));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__ ));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ )); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__ )); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogb (double __x) __attribute__ ((__nothrow__ )); extern int __ilogb (double __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__ )); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__ ));



extern double nearbyint (double __x) __attribute__ ((__nothrow__ )); extern double __nearbyint (double __x) __attribute__ ((__nothrow__ ));



extern double round (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ )); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrint (double __x) __attribute__ ((__nothrow__ )); extern long int __lrint (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrint (double __x) __attribute__ ((__nothrow__ )); extern long long int __llrint (double __x) __attribute__ ((__nothrow__ ));



extern long int lround (double __x) __attribute__ ((__nothrow__ )); extern long int __lround (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llround (double __x) __attribute__ ((__nothrow__ )); extern long long int __llround (double __x) __attribute__ ((__nothrow__ ));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double fmax (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ )); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ ));
# 283 "/usr/include/math.h" 2 3 4
# 298 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinff (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanf (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern int __issignalingf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 299 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acosf (float __x) __attribute__ ((__nothrow__ )); extern float __acosf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinf (float __x) __attribute__ ((__nothrow__ )); extern float __asinf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanf (float __x) __attribute__ ((__nothrow__ )); extern float __atanf (float __x) __attribute__ ((__nothrow__ ));

 extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__ )); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__ ));


 extern float cosf (float __x) __attribute__ ((__nothrow__ )); extern float __cosf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinf (float __x) __attribute__ ((__nothrow__ )); extern float __sinf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanf (float __x) __attribute__ ((__nothrow__ )); extern float __tanf (float __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float coshf (float __x) __attribute__ ((__nothrow__ )); extern float __coshf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinhf (float __x) __attribute__ ((__nothrow__ )); extern float __sinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanhf (float __x) __attribute__ ((__nothrow__ )); extern float __tanhf (float __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acoshf (float __x) __attribute__ ((__nothrow__ )); extern float __acoshf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinhf (float __x) __attribute__ ((__nothrow__ )); extern float __asinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanhf (float __x) __attribute__ ((__nothrow__ )); extern float __atanhf (float __x) __attribute__ ((__nothrow__ ));





 extern float expf (float __x) __attribute__ ((__nothrow__ )); extern float __expf (float __x) __attribute__ ((__nothrow__ ));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ )); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ )); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern float logf (float __x) __attribute__ ((__nothrow__ )); extern float __logf (float __x) __attribute__ ((__nothrow__ ));


 extern float log10f (float __x) __attribute__ ((__nothrow__ )); extern float __log10f (float __x) __attribute__ ((__nothrow__ ));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float expm1f (float __x) __attribute__ ((__nothrow__ )); extern float __expm1f (float __x) __attribute__ ((__nothrow__ ));


 extern float log1pf (float __x) __attribute__ ((__nothrow__ )); extern float __log1pf (float __x) __attribute__ ((__nothrow__ ));


extern float logbf (float __x) __attribute__ ((__nothrow__ )); extern float __logbf (float __x) __attribute__ ((__nothrow__ ));




 extern float exp2f (float __x) __attribute__ ((__nothrow__ )); extern float __exp2f (float __x) __attribute__ ((__nothrow__ ));


 extern float log2f (float __x) __attribute__ ((__nothrow__ )); extern float __log2f (float __x) __attribute__ ((__nothrow__ ));






 extern float powf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern float sqrtf (float __x) __attribute__ ((__nothrow__ )); extern float __sqrtf (float __x) __attribute__ ((__nothrow__ ));



 extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__ ));




 extern float cbrtf (float __x) __attribute__ ((__nothrow__ )); extern float __cbrtf (float __x) __attribute__ ((__nothrow__ ));






extern float ceilf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float nanf (const char *__tagb) __attribute__ ((__nothrow__ )); extern float __nanf (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float erff (float) __attribute__ ((__nothrow__ )); extern float __erff (float) __attribute__ ((__nothrow__ ));
 extern float erfcf (float) __attribute__ ((__nothrow__ )); extern float __erfcf (float) __attribute__ ((__nothrow__ ));
extern float lgammaf (float) __attribute__ ((__nothrow__ )); extern float __lgammaf (float) __attribute__ ((__nothrow__ ));




extern float tgammaf (float) __attribute__ ((__nothrow__ )); extern float __tgammaf (float) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float rintf (float __x) __attribute__ ((__nothrow__ )); extern float __rintf (float __x) __attribute__ ((__nothrow__ ));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__ ));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ )); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__ )); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbf (float __x) __attribute__ ((__nothrow__ )); extern int __ilogbf (float __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ )); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ ));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__ )); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__ ));



extern float roundf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ )); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintf (float __x) __attribute__ ((__nothrow__ )); extern long int __lrintf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__ ));



extern long int lroundf (float __x) __attribute__ ((__nothrow__ )); extern long int __lroundf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__ ));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ )); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ ));
# 300 "/usr/include/math.h" 2 3 4
# 367 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinfl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern int __issignalingl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 368 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ )); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ ));


 extern long double cosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanl (long double __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double coshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __coshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acoshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__ ));





 extern long double expl (long double __x) __attribute__ ((__nothrow__ )); extern long double __expl (long double __x) __attribute__ ((__nothrow__ ));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ )); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern long double logl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logl (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log10l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log10l (long double __x) __attribute__ ((__nothrow__ ));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double expm1l (long double __x) __attribute__ ((__nothrow__ )); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log1pl (long double __x) __attribute__ ((__nothrow__ )); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__ ));


extern long double logbl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logbl (long double __x) __attribute__ ((__nothrow__ ));




 extern long double exp2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log2l (long double __x) __attribute__ ((__nothrow__ ));






 extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__ ));



 extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ ));




 extern long double cbrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__ ));






extern long double ceill (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double nanl (const char *__tagb) __attribute__ ((__nothrow__ )); extern long double __nanl (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double erfl (long double) __attribute__ ((__nothrow__ )); extern long double __erfl (long double) __attribute__ ((__nothrow__ ));
 extern long double erfcl (long double) __attribute__ ((__nothrow__ )); extern long double __erfcl (long double) __attribute__ ((__nothrow__ ));
extern long double lgammal (long double) __attribute__ ((__nothrow__ )); extern long double __lgammal (long double) __attribute__ ((__nothrow__ ));




extern long double tgammal (long double) __attribute__ ((__nothrow__ )); extern long double __tgammal (long double) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double rintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __rintl (long double __x) __attribute__ ((__nothrow__ ));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ ));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ )); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__ )); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ )); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ ));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__ ));



extern long double roundl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ )); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__ ));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__ ));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ )); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ ));
# 369 "/usr/include/math.h" 2 3 4
# 450 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinff128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitef128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigf128 (_Float128 __x, _Float128 __y) __attribute__ ((__nothrow__ ));


extern int __issignalingf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 451 "/usr/include/math.h" 2 3 4
# 903 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 11 "./adamic.h" 2

enum adamic_stream {
 adamic_stdout = 1,
 adamic_stderr = 2,
};




enum adamic_kind {
 adamic_kind_string = 1,
 adamic_kind_object,
 adamic_kind_array,
 adamic_kind_map,
 adamic_kind_cell,
 adamic_kind_closure,
 adamic_kind_map_iterator,
 adamic_kind_number,
 adamic_kind_boolean,
 adamic_kind_weak,
};

typedef struct adamic_heap {
 size_t references;
 enum adamic_kind kind;


 uint32_t slab;
} adamic_heap;


void *adamic_retain(void *value);
void adamic_release(void *value);


void *adamic_allocate(size_t size, enum adamic_kind kind);



typedef union adamic_value {
 double number;
 _Bool boolean;
 void *reference;
} adamic_value;


typedef struct adamic_maybe_number {
 _Bool present;
 double number;
} adamic_maybe_number;


typedef struct adamic_maybe_boolean {
 _Bool present;
 _Bool boolean;
} adamic_maybe_boolean;



typedef struct adamic_cell {
 adamic_heap heap;
 _Bool references;
 adamic_value value;
} adamic_cell;

adamic_cell *adamic_cell_new(adamic_value value, _Bool references);



typedef struct adamic_closure adamic_closure;
typedef adamic_value (*adamic_code)(adamic_closure *self, adamic_value *arguments);
struct adamic_closure {
 adamic_heap heap;
 adamic_code code;
 size_t count;
 adamic_cell *cells[];
};


adamic_closure *adamic_closure_new(adamic_code code, size_t count);


typedef struct adamic_string {
 adamic_heap heap;
 size_t length;
 const char *bytes;




 size_t units;
 struct adamic_string_index *index;



 struct adamic_string *owner;



 size_t capacity;
} adamic_string;

struct adamic_string_index {

 size_t cursor_unit;
 size_t cursor_offset;



 size_t count;


 uint16_t *view;
 uint32_t checkpoints[];
};




extern char adamic_literal_mark;
# 143 "./adamic.h"
typedef struct adamic_methods adamic_methods;
typedef struct adamic_shape {
 size_t count;
 const char *const *names;
 const _Bool *references;
 const adamic_methods *methods;
} adamic_shape;

typedef void (*adamic_virtual_method)(void);
typedef struct adamic_object adamic_object;
typedef struct adamic_accessor {
 const char *name;
 adamic_value (*get)(adamic_object *);
 void (*set)(adamic_object *, adamic_value, int);
 int type;
} adamic_accessor;
typedef struct adamic_class {
 const struct adamic_class *base;
 size_t own_start;
 size_t count;
 const adamic_virtual_method *methods;
 size_t definition;
 const adamic_shape *public_shape;
 const adamic_accessor *accessors;
 size_t accessor_count;
 _Bool is_static;
 size_t static_parent;
 const size_t *static_flags;
} adamic_class;



typedef struct adamic_object {
 adamic_heap heap;
 const adamic_shape *shape;
 const adamic_class *class;
 _Bool frozen;
 adamic_value slots[];
} adamic_object;

_Bool adamic_instanceof(const void *value, const adamic_class *wanted);
adamic_virtual_method adamic_virtual(const adamic_object *object, size_t slot);
void adamic_object_free_children(adamic_object *object, void (*release)(void *));



typedef struct adamic_slot_cache {
 const adamic_shape *shape;
 size_t index;
} adamic_slot_cache;



typedef adamic_value (*adamic_method)(adamic_object *self, adamic_value *arguments);
struct adamic_methods {
 size_t count;
 const char *const *names;
 const adamic_method *code;
};




adamic_closure *adamic_object_callee(const adamic_object *object, const char *name, adamic_slot_cache *cache, adamic_method *method);



adamic_object *adamic_object_new(const adamic_shape *shape);





typedef struct adamic_region_block adamic_region_block;
typedef struct adamic_region {
 adamic_region_block *blocks;
 size_t count;
} adamic_region;

adamic_object *adamic_object_new_in(adamic_region *region, const adamic_shape *shape);
void adamic_region_end(adamic_region *region);


adamic_object *adamic_object_copy(const adamic_object *source);


_Bool adamic_object_has(const adamic_object *object, const adamic_string *name);




adamic_value *adamic_object_find(const adamic_object *object, const char *name, adamic_slot_cache *cache);
adamic_value *adamic_static_field(const adamic_object *object, const char *name, adamic_slot_cache *cache);
adamic_value *adamic_object_write_field(adamic_object *object, const char *name, adamic_slot_cache *cache);

adamic_maybe_number adamic_object_maybe_number(const adamic_object *object, const char *name, adamic_slot_cache *cache);

adamic_value *adamic_object_optional_find(const adamic_object *object, const char *name, adamic_slot_cache *cache);
static inline adamic_value *adamic_object_optional_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (cache->shape != object->shape) {
  return adamic_object_optional_find(object, name, cache);
 }
 if (cache->index == object->shape->count) {
  return ((void*)0);
 }
 return &((adamic_object *)object)->slots[cache->index];
}



static inline adamic_value *adamic_object_data_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (cache->shape == object->shape) {
  return &((adamic_object *)object)->slots[cache->index];
 }
 return adamic_object_find(object, name, cache);
}

static inline adamic_value *adamic_object_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (object->class != ((void*)0) && object->class->is_static) { return adamic_static_field(object, name, cache); }
 return adamic_object_data_field(object, name, cache);
}


_Bool adamic_object_is(const adamic_heap *left, const adamic_heap *right);
_Bool adamic_object_is_frozen(const adamic_heap *value);
adamic_object *adamic_object_freeze(adamic_object *object);
_Bool adamic_object_has_own(const adamic_object *object, const adamic_string *key);
struct adamic_array *adamic_object_keys(const adamic_object *object);
struct adamic_array *adamic_object_values(const adamic_object *object, _Bool references, _Bool entries);
void adamic_object_assign(adamic_object *target, const adamic_object *source);
void adamic_object_check_write(const adamic_object *object, const char *name);

static inline void adamic_object_check_data_write(const adamic_object *object, const char *name) {
 if (object->frozen) {
  adamic_object_check_write(object, name);
 }
}


typedef struct adamic_array {
 adamic_heap heap;
 size_t length;
 size_t capacity;
 _Bool references;
 adamic_value *elements;

 adamic_object *properties;
} adamic_array;

adamic_array *adamic_array_new(size_t capacity, _Bool references);
size_t adamic_public_index(const adamic_shape *shape, size_t position);
adamic_array *adamic_class_object_keys(const adamic_object *object);
const adamic_accessor *adamic_accessor_find(const adamic_object *object, const char *name);
adamic_value adamic_accessor_get(adamic_object *object, const char *name);
void adamic_accessor_set(adamic_object *object, const char *name, adamic_value value, int type);


void adamic_array_push(adamic_array *array, adamic_value value);


typedef struct adamic_map_entry {
 adamic_value key;
 adamic_value value;
 _Bool deleted;
} adamic_map_entry;

typedef struct adamic_map {
 adamic_heap heap;
 size_t count;
 size_t used;
 size_t capacity;
 adamic_map_entry *entries;
 size_t bucket_count;
 size_t *buckets;
 _Bool string_keys;


 _Bool reference_keys;


 _Bool boolean_keys;


 _Bool maybe_number_keys;
 _Bool reference_values;


 size_t iterating;
} adamic_map;




typedef struct adamic_map_iterator {
 adamic_heap heap;
 adamic_map *map;
 size_t next;
 _Bool exhausted;
} adamic_map_iterator;

adamic_map_iterator *adamic_map_iterate(adamic_map *map);
adamic_object *adamic_collection_iterator(adamic_map *collection, int part, int key, int value, _Bool set);


_Bool adamic_map_iterator_next(adamic_map_iterator *iterator, union adamic_value *key, union adamic_value *value);

adamic_map *adamic_map_new(_Bool string_keys, _Bool reference_values);



adamic_map *adamic_map_new_identity(_Bool reference_values);


adamic_map *adamic_map_new_booleans(_Bool reference_values);
_Bool adamic_map_maybe_key_equal(double left, double right);
uint64_t adamic_map_maybe_key_hash(double key);
uint64_t adamic_map_number_hash(double number);


adamic_map *adamic_map_new_maybe_numbers(_Bool reference_values);



void adamic_map_clear(adamic_map *map);



adamic_array *adamic_map_keys(const adamic_map *map);



void adamic_map_add_pairs(adamic_map *map, const adamic_array *pairs);
adamic_array *adamic_map_values(const adamic_map *map);


adamic_value *adamic_map_get(const adamic_map *map, adamic_value key);


void adamic_map_set(adamic_map *map, adamic_value key, adamic_value value);

_Bool adamic_map_delete(adamic_map *map, adamic_value key);



typedef adamic_object adamic_record;
typedef adamic_object adamic_record_iterator;

adamic_record *adamic_record_new(_Bool reference_values);

adamic_value *adamic_record_get_own(const adamic_record *record, const adamic_string *key);
_Bool adamic_record_has_own(const adamic_record *record, const adamic_string *key);



adamic_value *adamic_record_get(const adamic_record *record, const adamic_string *key);
_Bool adamic_record_has(const adamic_record *record, const adamic_string *key);


void adamic_record_define(adamic_record *record, adamic_string *key, adamic_value value);
void adamic_record_set(adamic_record *record, adamic_string *key, adamic_value value);
_Bool adamic_record_delete(adamic_record *record, const adamic_string *key);
size_t adamic_record_size(const adamic_record *record);

adamic_array *adamic_record_keys(const adamic_record *record);


adamic_record_iterator *adamic_record_iterate(adamic_record *record);
_Bool adamic_record_iterator_next(adamic_record_iterator *iterator, adamic_string **key, adamic_value *value);




void adamic_set_add_all(adamic_map *set, const adamic_array *values);
adamic_array *adamic_set_values(const adamic_map *set);


void adamic_map_free_children(adamic_map *map, void (*let_go)(void *));
# 432 "./adamic.h"
static inline adamic_value *adamic_array_at_integer(const adamic_array *array, int64_t index) {
 if (index < 0 || (uint64_t)index >= array->length) {
  return ((void*)0);
 }
 return &array->elements[index];
}

static inline adamic_value *adamic_array_at(const adamic_array *array, double index) {
 if (!(index >= 0) || index >= (double)array->length) {
  return ((void*)0);
 }
 size_t whole = (size_t)index;
 if ((double)whole != index) {
  return ((void*)0);
 }
 return &array->elements[whole];
}



void adamic_array_set(adamic_array *array, double index, adamic_value value);


adamic_value *adamic_array_at_relative(const adamic_array *array, double index);



enum adamic_equality {
 adamic_equal_numbers = 1,
 adamic_equal_booleans,
 adamic_equal_strings,
 adamic_equal_identity,
 adamic_equal_maybe_numbers,
};
double adamic_array_index_of(const adamic_array *array, adamic_value value, enum adamic_equality equality, _Bool same_value_zero);
double adamic_array_search_from(const adamic_array *array, adamic_value value, enum adamic_equality equality, _Bool same_value_zero, double from, _Bool has_from, _Bool last);



size_t adamic_array_from_length(double length);



adamic_array *adamic_array_reverse(adamic_array *array);




adamic_array *adamic_array_filled(double length, adamic_value value, _Bool references);
adamic_array *adamic_array_fill(adamic_array *array, adamic_value value, double start, double end, _Bool has_start, _Bool has_end);



adamic_array *adamic_array_splice(adamic_array *array, double start, double count, _Bool has_count, size_t item_count, const adamic_value *items);


void adamic_array_remove(adamic_array *array, double start, double count, _Bool has_count, size_t item_count, const adamic_value *items);



void adamic_array_append(adamic_array *array, const adamic_array *source);
adamic_array *adamic_array_concat(size_t count, adamic_array *const arrays[]);




adamic_array *adamic_array_slice(const adamic_array *array, double start, double end, _Bool has_end);
void adamic_array_sort(adamic_array *array, int (*compare)(adamic_value, adamic_value, void *), void *context);
int adamic_compare_closure(adamic_value left, adamic_value right, void *context);


_Bool adamic_timsort(adamic_value *work, size_t count, int (*compare)(adamic_value, adamic_value, void *), void *context);



void adamic_array_sort_undefined_last(adamic_array *array, int (*compare)(adamic_value, adamic_value, void *), void *context);


adamic_array *adamic_map_entries(const adamic_map *map, const adamic_shape *pair);


enum adamic_join {
 adamic_join_numbers = 1,
 adamic_join_booleans,
 adamic_join_strings,
 adamic_join_maybe_numbers,
};
struct adamic_string *adamic_array_join(const adamic_array *array, const struct adamic_string *separator, enum adamic_join kind);

struct adamic_string *adamic_array_join_nested(const adamic_array *array, const struct adamic_string *separator, enum adamic_join kind, size_t depth);


adamic_string *adamic_string_from_number(double value);



double adamic_number_parse_int(const adamic_string *text, double radix);
double adamic_number_parse_float(const adamic_string *text);
double adamic_number_from_string(const adamic_string *text);
double adamic_number_from_union(const adamic_heap *value);
_Bool adamic_number_has_own_property(const adamic_string *key, _Bool prototype);
double adamic_math_clz32(double value);
double adamic_math_imul(double left, double right);
double adamic_math_fround(double value);
adamic_string *adamic_string_concat(size_t count, adamic_string *const parts[]);


extern adamic_string adamic_string_empty;
extern adamic_string adamic_string_true;
extern adamic_string adamic_string_false;




extern adamic_string adamic_string_undefined;
adamic_string *adamic_string_from_maybe_number(adamic_maybe_number value);
_Bool adamic_maybe_number_equal(adamic_maybe_number left, adamic_maybe_number right);







double adamic_maybe_number_pack(adamic_maybe_number value);
adamic_maybe_number adamic_maybe_number_unpack(double packed);
_Bool adamic_maybe_boolean_equal(adamic_maybe_boolean left, adamic_maybe_boolean right);






size_t adamic_string_units(const adamic_string *string);
double adamic_string_char_code(const adamic_string *string, double position);
static inline double adamic_string_length(const adamic_string *string) {
 return string->units != 0 ? (double)(string->units - 1) : (double)adamic_string_units(string);
}
static inline double adamic_string_char_code_at(const adamic_string *string, double position) {
 if (string->units == string->length + 1 && position >= 0 && position < (double)string->length) {
  return (double)(unsigned char)string->bytes[(size_t)position];
 }


 if (string->index != ((void*)0) && string->index != ((struct adamic_string_index *)&adamic_literal_mark) && position >= 0 && position < (double)(string->units - 1)) {
  return (double)string->index->view[(size_t)position];
 }
 return adamic_string_char_code(string, position);
}
adamic_string *adamic_string_trim(adamic_string *string);



size_t adamic_string_next(const adamic_string *string, size_t offset);
adamic_string *adamic_string_slice_bytes(const adamic_string *string, size_t offset, size_t size);



adamic_string *adamic_string_share(const adamic_string *string, size_t offset, size_t size);



adamic_string *adamic_string_slice(const adamic_string *string, double start, double end, _Bool has_end);
adamic_maybe_number adamic_string_code_point_at(const adamic_string *string, double position);
int adamic_string_compare(const adamic_string *left, const adamic_string *right);
adamic_string *adamic_string_repeat(const adamic_string *string, double count);
adamic_string *adamic_string_pad(const adamic_string *string, double target, const adamic_string *fill, _Bool at_start);
double adamic_string_index_of(const adamic_string *string, const adamic_string *search);



double adamic_string_index_of_at(const adamic_string *string, const adamic_string *search, size_t from);
double adamic_string_index_of_from(const adamic_string *string, const adamic_string *search, double position);
_Bool adamic_string_starts_with(const adamic_string *string, const adamic_string *search);
_Bool adamic_string_ends_with(const adamic_string *string, const adamic_string *search);
struct adamic_array *adamic_string_code_points(const adamic_string *string);
struct adamic_array *adamic_string_split(const adamic_string *string, const adamic_string *separator);



adamic_string *adamic_string_at(const adamic_string *string, double index);
adamic_string *adamic_string_at_relative(const adamic_string *string, double index);


adamic_string *adamic_string_trim_sides(adamic_string *string, _Bool at_start, _Bool at_end);



double adamic_string_last_index_of(const adamic_string *string, const adamic_string *search);
adamic_string *adamic_string_replace(const adamic_string *string, const adamic_string *search, const adamic_string *replacement, _Bool all);






void adamic_string_check_length(double units);


adamic_string *adamic_string_allocate(size_t length);



adamic_string *adamic_string_to_upper(const adamic_string *string);
adamic_string *adamic_string_to_lower(const adamic_string *string);



adamic_string *adamic_string_normalize(const adamic_string *string, const adamic_string *form);







size_t adamic_string_join_halves(char *bytes, size_t from, size_t length);




size_t adamic_string_put(char *bytes, size_t written, const adamic_string *part);




adamic_string *adamic_string_append(adamic_string *string, size_t count, adamic_string *const parts[]);

size_t adamic_string_units(const adamic_string *string);
size_t adamic_string_locate(const adamic_string *string, size_t unit, _Bool *low);



size_t adamic_string_units_before(const adamic_string *string, size_t offset);
void adamic_string_free_index(adamic_string *string);


int adamic_string_equal(const adamic_string *left, const adamic_string *right);




typedef struct adamic_number_box {
 adamic_heap heap;
 double number;
} adamic_number_box;

typedef struct adamic_boolean_box {
 adamic_heap heap;
 _Bool boolean;
} adamic_boolean_box;

extern adamic_boolean_box adamic_box_true;
extern adamic_boolean_box adamic_box_false;


adamic_heap *adamic_box_number(double number);


_Bool adamic_union_equal(const adamic_heap *left, const adamic_heap *right);



adamic_string *adamic_union_to_string(adamic_heap *value);



adamic_string *adamic_union_typeof(const adamic_heap *value, _Bool null);
extern adamic_string adamic_typeof_number;
extern adamic_string adamic_typeof_string;
extern adamic_string adamic_typeof_boolean;
extern adamic_string adamic_typeof_undefined;
extern adamic_string adamic_typeof_object;
extern adamic_string adamic_typeof_function;







typedef struct adamic_weak adamic_weak;
adamic_weak *adamic_weak_of(void *target);
void *adamic_weak_target(const adamic_weak *handle);
void *adamic_weak_target_present(const adamic_weak *handle);
void adamic_weak_forget(void *target);
void adamic_weak_dropped(adamic_weak *handle);


_Bool adamic_weak_held(const void *target);




extern adamic_object *adamic_thrown;
adamic_object *adamic_error_new(adamic_string *message);
_Noreturn void adamic_uncaught(void);



void adamic_start(int count, char **values);



void adamic_output_flush(void);



void adamic_write_line(enum adamic_stream stream, const adamic_string *string);






size_t adamic_number_format(double value, char buffer[32]);


double adamic_power(double base, double exponent);



double adamic_math_round(double value);
double adamic_math_sign(double value);
double adamic_math_max(double left, double right);
double adamic_math_min(double left, double right);



double adamic_math_acos(double x);
double adamic_math_acosh(double x);
double adamic_math_asin(double x);
double adamic_math_asinh(double x);
double adamic_math_atan(double x);
double adamic_math_atan2(double y, double x);
double adamic_math_atanh(double x);
double adamic_math_cbrt(double x);
double adamic_math_cos(double x);
double adamic_math_cosh(double x);
double adamic_math_exp(double x);
double adamic_math_expm1(double x);
double adamic_math_log(double x);
double adamic_math_log1p(double x);
double adamic_math_log2(double x);
double adamic_math_log10(double x);
double adamic_math_sin(double x);
double adamic_math_sinh(double x);
double adamic_math_tan(double x);
double adamic_math_tanh(double x);
double adamic_math_hypot(size_t count, const double *values);



int adamic_number_shortest_digits(double value, char digits[18], int *point);




adamic_string *adamic_number_to_exponential(double value, double digits, _Bool has_digits);
adamic_string *adamic_number_to_precision(double value, double digits, _Bool has_digits);



double adamic_math_max_of(const adamic_array *values);
double adamic_math_min_of(const adamic_array *values);
double adamic_math_hypot_of(const adamic_array *values);
adamic_string *adamic_string_from_char_codes_of(const adamic_array *values);
adamic_string *adamic_string_from_code_points_of(const adamic_array *values);




double adamic_utf8_length(const adamic_string *text);
double adamic_utf8_at(const adamic_string *text, double index);


double adamic_bitwise_and(double left, double right);
double adamic_bitwise_or(double left, double right);
double adamic_bitwise_xor(double left, double right);
double adamic_bitwise_not(double value);
double adamic_shift_left(double left, double right);
double adamic_shift_right(double left, double right);
double adamic_shift_right_unsigned(double left, double right);




adamic_string *adamic_string_from_char_codes(size_t count, const double values[]);
adamic_string *adamic_string_from_code_points(size_t count, const double values[]);



adamic_string *adamic_number_to_radix(double value, double radix);


adamic_string *adamic_number_to_fixed(double value, double digits);





void adamic_arguments_save(int count, char **values);
adamic_array *adamic_program_arguments(void);
adamic_object *adamic_read_text_file(const adamic_string *path);





adamic_string *adamic_decode_utf8(const unsigned char *bytes, size_t length);
char *adamic_path_bytes(const adamic_string *path);




adamic_object *adamic_read_directory(const adamic_string *path);
adamic_object *adamic_file_status(const adamic_string *path);



adamic_object *adamic_write_text_file(const adamic_string *path, const adamic_string *text);


_Noreturn void adamic_panic(const char *message, size_t length);





extern uintptr_t adamic_stack_limit;
_Noreturn void adamic_stack_overflow(void);
# 887 "./adamic.h"
_Noreturn void adamic_unreachable(void);

# 1 "./regexp.h" 1




typedef struct {
 uint32_t first, last;
} adamic_regex_range;
typedef struct {
 const uint32_t *points;
 size_t count;
} adamic_regex_text;
typedef struct {
 const char *name;
 const size_t *captures;
 size_t count;
} adamic_regex_group;
typedef struct adamic_regex_program adamic_regex_program;
typedef struct {
 int op, x, y, direction;
 unsigned flags;
 int assertion;
 _Bool negative, greedy, unbounded;
 uint64_t minimum, maximum;
 const adamic_regex_range *ranges;
 size_t range_count;
 const adamic_regex_text *strings;
 size_t string_count;
 const size_t *ids;
 size_t id_count;
 const adamic_regex_program *look;
} adamic_regex_instruction;
struct adamic_regex_program {
 const adamic_regex_instruction *code;
 size_t captures, repeats;
 unsigned flags;
 const adamic_regex_group *groups;
 size_t group_count;
 const adamic_shape *group_shape;
 uint64_t first_ascii[2];
 _Bool filter_first;
 const uint16_t *prefix;
 size_t prefix_count;
 _Bool (*fast)(const uint16_t *, size_t, ptrdiff_t *, ptrdiff_t *, uint64_t *);
 _Bool anchored;
 _Bool (*fast_ascii)(const unsigned char *, size_t, ptrdiff_t *, ptrdiff_t *, uint64_t *);
};

adamic_object *adamic_regex_new(const adamic_regex_program *program, adamic_string *source,
        adamic_string *flags);
_Bool adamic_regex_test(adamic_object *regex, adamic_string *input);
adamic_array *adamic_regex_exec(adamic_object *regex, adamic_string *input);
adamic_array *adamic_regex_match(adamic_string *input, adamic_object *regex);
adamic_object *adamic_regex_match_all(adamic_string *input, adamic_object *regex);
adamic_array *adamic_regex_iterator_step(adamic_object *iterator);
adamic_object *adamic_regex_next(adamic_object *iterator);
adamic_string *adamic_regex_replace(adamic_string *input, adamic_object *regex,
         adamic_string *replacement, _Bool require_global);
adamic_array *adamic_regex_split(adamic_string *input, adamic_object *regex, double limit);
double adamic_regex_search(adamic_string *input, adamic_object *regex);
adamic_value adamic_regex_property(adamic_array *array, const char *name);
adamic_maybe_boolean adamic_regex_done(adamic_object *object);
void *adamic_regex_group_lookup(adamic_object *object, const char *name, _Bool optional);
void adamic_regex_set_step_limit(uint64_t limit);
# 890 "./adamic.h" 2


adamic_array *adamic_plain_object_keys(const adamic_object *object);
void *adamic_library_identity(size_t index);
# 4 "./units.h" 2
# 2 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1_initialize_04.c" 2
extern adamic_array * adamic_unit_adamic_global_102315652901119016387637435367297798836_widthRunes33;
extern const char adamic_declaration_99f9fe00ba1b23b94a0bd1d64c967982739a7c1ba8f65aefbe74a491fd69be8e;
extern adamic_array * adamic_unit_adamic_global_131334098209958454326406879330669522509_widthRunes10;
extern const char adamic_declaration_f42e45c2aa8c2e3dd0f6f1e6b2c71b25214cfbda4cd20d1fa380360f98bb9b31;
extern adamic_array * adamic_unit_adamic_global_139202957232633553956639033937476511341_widthRunes13;
extern const char adamic_declaration_858adefff69b0c91f59811024e67186403fac8692238e05abf55b33844b10547;
extern adamic_array * adamic_unit_adamic_global_188271596804135515617788937310774643812_widthRunes26;
extern const char adamic_declaration_612b07d16a884c03c118f1e6e8c6c754cd54bc2b9c0c53a0ccd4ab2ea07dd13f;
extern adamic_array * adamic_unit_adamic_global_207172856599196574990490716352336523230_widthRunes34;
extern const char adamic_declaration_b6a176dc504d372e71369eaae76533193aa67cc00a409afa919707a205e77b3c;
extern adamic_array * adamic_unit_adamic_global_211800373558045748980352781794672789066_widthRunes25;
extern const char adamic_declaration_86567b203f1c49f6dea397eb0786c4d7f064b5b15666fbd753c00ddd2e3db2d8;
extern adamic_array * adamic_unit_adamic_global_214463541296772391131326515213479138595_widthRunes23;
extern const char adamic_declaration_5a9e4006794af1a53b03f2d8def9e7223db5986282a5faacec119c306b450f4a;
extern adamic_array * adamic_unit_adamic_global_256851085953153845188150197069899785748_widthRunes27;
extern const char adamic_declaration_f64dc35d168a4adeef0d560a4edffc8144b456847dd94b23bf61bba12662804f;
extern adamic_array * adamic_unit_adamic_global_318397809913480873069972451752702256895_widthRunes11;
extern const char adamic_declaration_a1e0d64fa4128260950bf18bff2823786896ede4ebb1f7a12a9bb528d2b240e2;
extern adamic_array * adamic_unit_adamic_global_46125770222536611284281190875579638120_widthRunes28;
extern const char adamic_declaration_4b0c66bba42fcc05b562be569af9f4c1961b535092017aec5ee4ea153901ede4;
extern adamic_array * adamic_unit_adamic_global_51464287092569867909644651159452982558_widthRunes31;
extern const char adamic_declaration_fa71f6c512c2b500048e26daa4ebd23aea188f45462f67ff51b8c2f4ed96478f;
extern adamic_array * adamic_unit_adamic_global_64553106260587404428515520870469795332_widthRunes24;
extern const char adamic_declaration_7e5efdb1b49f27b7e54e6f546f1f927f09398df0772e7cd62d6740b3b369d78b;
extern adamic_array * adamic_unit_adamic_global_72149521299507929115661083304217761980_widthRunes32;
extern const char adamic_declaration_7ffdd6826dbcc694ad407256e630de6ef84ba78bad7965986c196792f1e3976c;
extern adamic_array * adamic_unit_adamic_global_72663038920422598132074736220383086080_widthRunes12;
extern const char adamic_declaration_4de9f0b62da0bbec9a7f898d46a09ebf2efc21de14f0c638d362cf063615b77e;
extern adamic_array * adamic_unit_adamic_global_9820095936308330832719044453478594697_widthRunes30;
extern const char adamic_declaration_5d2ed8e6464c63fb8e50149fabd6ba17ec95b291c423244d5b0eb047119e4dab;
extern adamic_array * adamic_unit_adamic_global_98869456272199528218609051815346584243_widthRunes29;
extern const char adamic_declaration_c6ca8392a3cb3ae4c7a345767a9d36c6a80fa7c3a69f69eeacce5f077b39d9d1;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_291663ce58cd939f739c0155c588563b(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_154, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155) __attribute__((noinline));
extern const char adamic_declaration_c009395f1805c47ec552401c68e3e99dc96ea9867fb9a7478f8b99ee92bd0f8a;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_599bc015b550075743e013c6b7293e44(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_64, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95) __attribute__((noinline));
extern const char adamic_declaration_68e03fbdc42126975d157f513343eef3a0b38246cee357a2c4e010df4cf370e3;
adamic_array *adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(size_t count, const double *values) __attribute__((noinline));
extern const char adamic_declaration_03f03a5dea80a2e5305e7614c711f110093605922d140f4ca4a79033ae25914f;
void adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d(adamic_array *array, size_t count, const adamic_value values[][5], const double *numbers, const size_t *offsets) __attribute__((noinline));
extern const char adamic_declaration_09db173b3dd655f0582d3d22deaf51dcb4ed8204b1b5c13c5dccd85655fb77f5;
extern const double adamic_unit_adamic_number_table_data_1829a33a0b13258d4ee31ed35a0f805c[2];
extern const char adamic_declaration_60e39e66b50ccb1967cf1d24f30d0951b37a8f8f7ac40d191d83baaa68ec7759;
extern const double adamic_unit_adamic_number_table_data_1a05b86380d655ba798ddd8fa0ab4134[2];
extern const char adamic_declaration_a046f8b25606caaab839f0330c2af664d5ec961eef07dba8fd1cbe4d149f1b9c;
extern const double adamic_unit_adamic_number_table_data_56f8f9368ae8cf307e81557cf3fa4fa6[10];
extern const char adamic_declaration_e082167f203d3be9ecf7e58c7d0f0aa39d2c8f29b142d07103e80b6348a6575f;
extern const double adamic_unit_adamic_number_table_data_5ea9b0725ba2da0dbd30c79b84a0204d[2];
extern const char adamic_declaration_a11180d7c9048849addc6650486d15b62b864999e5058ae21d9ab0c7f50b436f;
extern const double adamic_unit_adamic_number_table_data_7151a6ef006ecc09a5825bedbe5c62cb[2];
extern const char adamic_declaration_dfd84fbb19afe477b993039123dc9fb7eeeac2b2498317b174789200ac1e5a80;
extern const double adamic_unit_adamic_number_table_data_ae29931712ac8126f78ea6722a2b2d4b[2];
extern const char adamic_declaration_6b826af4153b11c0615244a3f54af501deabb06fbb3e6b832c344f666d461f2a;
extern const double adamic_unit_adamic_number_table_data_ca72590bc8f38a5fafb191aa073efd08[2];
extern const char adamic_declaration_77ff06dcd7c0fee718ea9aa5a37304915f5099362eb863da41d03ffc884a6654;
extern const adamic_value adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a[57][5];
extern const char adamic_declaration_4ad672e9921b9480d9be8e7971a2abc512a226e1ea91d8876bdee2409688748d;
extern const double adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a_numbers[102];
extern const char adamic_declaration_da44a6ffa557d1c3a562b3feb335c07381237d3b7aa282fef64a07a4f679f1b4;
extern const size_t adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a_offsets[58];
extern const char adamic_declaration_b0d3502bf8606e563fca1e94e18a200b1d011d47b59fdd7401ce5a7674ce73c9;
extern const adamic_value adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c[15][5];
extern const char adamic_declaration_e0b3652e00be9483af6af0374280ab7bc0c07ac47e4da9e9891f0c8ce50f68e3;
extern const double adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c_numbers[38];
extern const char adamic_declaration_2c2a975e4dbe383ec36deb772b00e78ca73cb6826c9d43aa188c960052694c5e;
extern const size_t adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c_offsets[16];
extern const char adamic_declaration_1176c8ca03679f6ef59bdc513bd0fbec389ae60eb0e30e632024d1d203557833;
extern const adamic_value adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7[55][5];
extern const char adamic_declaration_ccef815bec6967471af21b607774411a1ed96d9c72dfb83c29aa917e654e9f5c;
extern const double adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7_numbers[98];
extern const char adamic_declaration_99cf26cffea1dd0bfb7c9c40620a03d6412c55b8cd351991d15e07e121f7e182;
extern const size_t adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7_offsets[56];
extern const char adamic_declaration_f69bf81f0cc405b9a96f495e0d70b45199e1dc6d65b9af8b2debda6ede88ba9d;
extern const adamic_value adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485[100][5];
extern const char adamic_declaration_4dc94fc03b0efbd1b0a8160100ff357b8ec432802b283368a47c85d7700e2922;
extern const double adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485_numbers[138];
extern const char adamic_declaration_31b5ccc3cd2100d693698121d333b2ef8f53d67ea9fe3ce8aec2ab38aa6b3aaa;
extern const size_t adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485_offsets[101];
extern const char adamic_declaration_2798ceda69a8a2525d97714c2a89f7855358e19b77d6edcc91fc298f5c926d1d;
extern const adamic_value adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257[26][5];
extern const char adamic_declaration_ea812d2d90a45c06f8faef8dfcfd97fb1255409ee33a9e732a84218696459c95;
extern const double adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257_numbers[36];
extern const char adamic_declaration_d9a0119dea9b74b1675c85031ae35dd96c935e6d1cd0a883ce8ead5debcf3249;
extern const size_t adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257_offsets[27];
extern const char adamic_declaration_4386e4ca68fa6d08608473a43920b35746bef2a7ea3b9e8d87e56d37d422d4cb;
extern const adamic_value adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33[94][5];
extern const char adamic_declaration_3b769f2585867f6e489d6eeee34adf1417abd89eecd4e4fbc489962626d50f25;
extern const double adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33_numbers[140];
extern const char adamic_declaration_40e7e8c21045c6cba4e638daee4243640e14b84f7aafceb742d630666888a066;
extern const size_t adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33_offsets[95];
extern const char adamic_declaration_712a697edb5c3d82bd2ebc5e82b20f1e3b6f757af6fd84fe280ed7cf4d94fa21;
extern const adamic_value adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43[57][5];
extern const char adamic_declaration_3d7b78d5bd6ca2d14bf2ab5786f182d6f57b6df9c5ac70d5597dd9d30a40805b;
extern const double adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43_numbers[102];
extern const char adamic_declaration_f9d384301441933cce40459dc7cc6bf7bdcf176c9aefbf4661223e0b966df5d8;
extern const size_t adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43_offsets[58];
extern const char adamic_declaration_5088c320c2f066653b3bbcf6cbd2a86bffe21629f1128bbd8cf4f5948990cf1d;
extern const adamic_value adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6[62][5];
extern const char adamic_declaration_065d81975a962f950c3f02781b259619a67038af941f15ac7cf3879d995703d8;
extern const double adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6_numbers[100];
extern const char adamic_declaration_1277621bac56a8b66900f58d63619d9feb133ae8e87433264a06c637f8bfd652;
extern const size_t adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6_offsets[63];
extern const char adamic_declaration_62ed50d45e54245517e94cefb1832c47eb63a646d318b01d0273aefb965aa8ab;
extern const adamic_value adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561[57][5];
extern const char adamic_declaration_a6fa976860ed9b77b773156a72a3faa0db2bb239d60283307ae63e7c2c595105;
extern const double adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561_numbers[102];
extern const char adamic_declaration_1dc05bddf95d8d6736d9f6bdf4f9b0f3e9707de9467049f989ea0c5ca33fd952;
extern const size_t adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561_offsets[58];
extern const char adamic_declaration_32bf25d1442998c1576e6def15e965f7fc0254623d661b26bb754abf5b82d250;
extern const adamic_value adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487[54][5];
extern const char adamic_declaration_ce39a5225eef48c694a8d3f5f360a8ca24a9b5cf3dbd2b3cf1cffbbc9d1093be;
extern const double adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487_numbers[92];
extern const char adamic_declaration_d81edc49e645f79cdccd34ffb3d40ed6debdb8bdd6c38cbf0fe7efee4837cb0b;
extern const size_t adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487_offsets[55];
extern const char adamic_declaration_8baeb7e18915ba06b5f2a9137b40b6f7c5d110ac40fe4a514f841a9ca07a35f5;
extern const adamic_value adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668[56][5];
extern const char adamic_declaration_7e968a7659215944f752118c109abdb231551f2a8448e10bd56eb143ea35a105;
extern const double adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668_numbers[96];
extern const char adamic_declaration_f08b1055f65a78ba4745dce02320b0267e3af9b84bb455fc47e09255d9a0fa1c;
extern const size_t adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668_offsets[57];
extern const char adamic_declaration_d2817ddade30f72016dc5127aa96be3960321f105fe82d0a66e6315c9e476868;
extern const adamic_value adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5[16][5];
extern const char adamic_declaration_14ee065ed78249b31840703a0af6d4698706a5f7c035c5e39ea4469815068c02;
extern const double adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5_numbers[22];
extern const char adamic_declaration_2e8196b638af99e0f56ab6326c75dc898ba1804311a8bad78f8fbca0a1c93172;
extern const size_t adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5_offsets[17];
extern const char adamic_declaration_9d2a3d40e30d6191e983d13e5152f913fff76c596389cb9ca1ae80f9bf6c859f;
extern const adamic_shape adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3;
extern const char adamic_declaration_037b05befc2e117bd01a5568a586c43f8bec6abc773410a8bd8beb15ce60f7f5;
extern adamic_string adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5;
extern const char adamic_declaration_8c81852b51e9e271a0f08699d1fdda830c0f6975820f09a84fb92313aadbabe7;
extern adamic_string adamic_unit_adamic_string_literal_ca978112ca1bbdcafac231b39a23dc4d;
extern const char adamic_declaration_58130658fc8e70725e1161819bd6fc608f78632c226f65862f5a3a9ddb301d5c;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_291663ce58cd939f739c0155c588563b(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_154, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155) {

 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_126 = adamic_retain(adamic_unit_adamic_global_214463541296772391131326515213479138595_widthRunes23);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_126;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 62, adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6, adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6_numbers, adamic_unit_adamic_record_table_data_a27a05d8a39700d70363f36eab37d0e6_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_128 = adamic_retain(adamic_unit_adamic_global_64553106260587404428515520870469795332_widthRunes24);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_128;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 56, adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668, adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668_numbers, adamic_unit_adamic_record_table_data_d405957e93a83f92f0eede60c7386668_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_130 = adamic_retain(adamic_unit_adamic_global_211800373558045748980352781794672789066_widthRunes25);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_130;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 57, adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561, adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561_numbers, adamic_unit_adamic_record_table_data_a311fce2e56c5df1e7fa7d4f75429561_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_132 = adamic_retain(adamic_unit_adamic_global_188271596804135515617788937310774643812_widthRunes26);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_132;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 57, adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a, adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a_numbers, adamic_unit_adamic_record_table_data_04aa752667dcdad02d4ff240750d832a_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_134 = adamic_retain(adamic_unit_adamic_global_256851085953153845188150197069899785748_widthRunes27);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_134;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 57, adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43, adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43_numbers, adamic_unit_adamic_record_table_data_916a35d9547030aaca2e4ea0bd6d3c43_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_136 = adamic_retain(adamic_unit_adamic_global_46125770222536611284281190875579638120_widthRunes28);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_136;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 100, adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485, adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485_numbers, adamic_unit_adamic_record_table_data_4d58d9f507dee268a4a9df31e7e44485_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_138 = adamic_retain(adamic_unit_adamic_global_98869456272199528218609051815346584243_widthRunes29);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139)->slots[1].number = (0x1.088p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_138;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_140 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_1829a33a0b13258d4ee31ed35a0f805c);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141)->slots[1].number = (0x1.084p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_140;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_142 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_7151a6ef006ecc09a5825bedbe5c62cb);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_142;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_144 = adamic_array_new(0, 0);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_ca978112ca1bbdcafac231b39a23dc4d);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145)->slots[1].number = (0x1.08p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145)->slots[2].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145)->slots[3].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_144;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_146 = adamic_retain(adamic_unit_adamic_global_9820095936308330832719044453478594697_widthRunes30);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147)->slots[1].number = (0x1.098p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_146;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 16, adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5, adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5_numbers, adamic_unit_adamic_record_table_data_da60de6a9a8463e50187fa6db7776eb5_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_148 = adamic_retain(adamic_unit_adamic_global_51464287092569867909644651159452982558_widthRunes31);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_148;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 26, adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257, adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257_numbers, adamic_unit_adamic_record_table_data_7ecc1244626547ce6a9884814524b257_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_150 = adamic_retain(adamic_unit_adamic_global_72149521299507929115661083304217761980_widthRunes32);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_150;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 54, adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487, adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487_numbers, adamic_unit_adamic_record_table_data_b4e5a2c260ea82a184d5089b2f0cb487_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_152 = adamic_retain(adamic_unit_adamic_global_102315652901119016387637435367297798836_widthRunes33);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_152;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 55, adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7, adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7_numbers, adamic_unit_adamic_record_table_data_3dfa3711c7ac3fb0a7afba2a528feab7_offsets);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_154) = adamic_retain(adamic_unit_adamic_global_207172856599196574990490716352336523230_widthRunes34);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155)->slots[3].number = (0x0p+00);
}
void adamic_unit_adamic_initialize_chunk____widthTables_ts_599bc015b550075743e013c6b7293e44(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_64, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95) {

 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65)->slots[1].number = (0x1.22p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65)->slots[4].reference = (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_64);
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_66 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_5ea9b0725ba2da0dbd30c79b84a0204d);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_66;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_68 = adamic_array_new(0, 0);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_ca978112ca1bbdcafac231b39a23dc4d);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69)->slots[1].number = (0x1.1cp+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69)->slots[2].number = (0x1.1ep+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69)->slots[3].number = (0x1.1ep+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_68;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_70 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_1a05b86380d655ba798ddd8fa0ab4134);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71)->slots[1].number = (0x1.28p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_70;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_72 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_1829a33a0b13258d4ee31ed35a0f805c);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73)->slots[1].number = (0x1.2ap+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_72;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_74 = adamic_retain(adamic_unit_adamic_global_131334098209958454326406879330669522509_widthRunes10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_74;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 15, adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c, adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c_numbers, adamic_unit_adamic_record_table_data_0d50d053a95c81286c0e77509708cf2c_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_76 = adamic_retain(adamic_unit_adamic_global_318397809913480873069972451752702256895_widthRunes11);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_76;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_78 = adamic_array_new(0, 0);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_ca978112ca1bbdcafac231b39a23dc4d);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79)->slots[1].number = (0x1.44p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79)->slots[2].number = (0x1.46p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79)->slots[3].number = (0x1.46p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_78;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_80 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_ae29931712ac8126f78ea6722a2b2d4b);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81)->slots[1].number = (0x1.5p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_80;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_82 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_1829a33a0b13258d4ee31ed35a0f805c);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83)->slots[1].number = (0x1.52p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_82;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_84 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(10, adamic_unit_adamic_number_table_data_56f8f9368ae8cf307e81557cf3fa4fa6);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_84;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_86 = adamic_array_new(0, 0);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_ca978112ca1bbdcafac231b39a23dc4d);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87)->slots[1].number = (0x1.4cp+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87)->slots[2].number = (0x1.4ep+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87)->slots[3].number = (0x1.4ep+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_86;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_88 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_ca72590bc8f38a5fafb191aa073efd08);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89)->slots[1].number = (0x1.58p+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_88;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_90 = adamic_unit_adamic_initialize_number_table_copy_data_f3c7807d475073ba009bf4801b2d934e(2, adamic_unit_adamic_number_table_data_1829a33a0b13258d4ee31ed35a0f805c);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91)->slots[1].number = (0x1.5ap+07);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_90;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91))});
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_92 = adamic_retain(adamic_unit_adamic_global_72663038920422598132074736220383086080_widthRunes12);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93)->slots[1].number = (0x1.6f8p+10);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_92;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93))});
 adamic_unit_adamic_initialize_record_table_copy_data_38c6f964cbd5ece9d78173eb79ddab7d((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), 94, adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33, adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33_numbers, adamic_unit_adamic_record_table_data_80b97199aeb78dca898ee8b57fbb0a33_offsets);
 adamic_array * adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_94 = adamic_retain(adamic_unit_adamic_global_139202957232633553956639033937476511341_widthRunes13);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95) = adamic_object_new(&adamic_unit_adamic_shape_layout_86780e559988d3b1ce924b813aa542a3);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95)->slots[0].reference = adamic_retain(&adamic_unit_adamic_string_literal_454349e422f05297191ead13e21d3db5);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95)->slots[1].number = (0x1.0ep+08);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95)->slots[2].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95)->slots[3].number = (0x0p+00);
 (*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95)->slots[4].reference = adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_94;
 adamic_array_push((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3), (adamic_value){.reference = adamic_retain((*adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95))});
}
const char adamic_declaration_c009395f1805c47ec552401c68e3e99dc96ea9867fb9a7478f8b99ee92bd0f8a = 0;
const char adamic_declaration_68e03fbdc42126975d157f513343eef3a0b38246cee357a2c4e010df4cf370e3 = 0;
const char *const adamic_abi_references_ac6d31945265c5aa9cd69bf50f2fc46a[] = {
0,
&adamic_declaration_99f9fe00ba1b23b94a0bd1d64c967982739a7c1ba8f65aefbe74a491fd69be8e,
&adamic_declaration_f42e45c2aa8c2e3dd0f6f1e6b2c71b25214cfbda4cd20d1fa380360f98bb9b31,
&adamic_declaration_858adefff69b0c91f59811024e67186403fac8692238e05abf55b33844b10547,
&adamic_declaration_612b07d16a884c03c118f1e6e8c6c754cd54bc2b9c0c53a0ccd4ab2ea07dd13f,
&adamic_declaration_b6a176dc504d372e71369eaae76533193aa67cc00a409afa919707a205e77b3c,
&adamic_declaration_86567b203f1c49f6dea397eb0786c4d7f064b5b15666fbd753c00ddd2e3db2d8,
&adamic_declaration_5a9e4006794af1a53b03f2d8def9e7223db5986282a5faacec119c306b450f4a,
&adamic_declaration_f64dc35d168a4adeef0d560a4edffc8144b456847dd94b23bf61bba12662804f,
&adamic_declaration_a1e0d64fa4128260950bf18bff2823786896ede4ebb1f7a12a9bb528d2b240e2,
&adamic_declaration_4b0c66bba42fcc05b562be569af9f4c1961b535092017aec5ee4ea153901ede4,
&adamic_declaration_fa71f6c512c2b500048e26daa4ebd23aea188f45462f67ff51b8c2f4ed96478f,
&adamic_declaration_7e5efdb1b49f27b7e54e6f546f1f927f09398df0772e7cd62d6740b3b369d78b,
&adamic_declaration_7ffdd6826dbcc694ad407256e630de6ef84ba78bad7965986c196792f1e3976c,
&adamic_declaration_4de9f0b62da0bbec9a7f898d46a09ebf2efc21de14f0c638d362cf063615b77e,
&adamic_declaration_5d2ed8e6464c63fb8e50149fabd6ba17ec95b291c423244d5b0eb047119e4dab,
&adamic_declaration_c6ca8392a3cb3ae4c7a345767a9d36c6a80fa7c3a69f69eeacce5f077b39d9d1,
&adamic_declaration_c009395f1805c47ec552401c68e3e99dc96ea9867fb9a7478f8b99ee92bd0f8a,
&adamic_declaration_68e03fbdc42126975d157f513343eef3a0b38246cee357a2c4e010df4cf370e3,
&adamic_declaration_03f03a5dea80a2e5305e7614c711f110093605922d140f4ca4a79033ae25914f,
&adamic_declaration_09db173b3dd655f0582d3d22deaf51dcb4ed8204b1b5c13c5dccd85655fb77f5,
&adamic_declaration_60e39e66b50ccb1967cf1d24f30d0951b37a8f8f7ac40d191d83baaa68ec7759,
&adamic_declaration_a046f8b25606caaab839f0330c2af664d5ec961eef07dba8fd1cbe4d149f1b9c,
&adamic_declaration_e082167f203d3be9ecf7e58c7d0f0aa39d2c8f29b142d07103e80b6348a6575f,
&adamic_declaration_a11180d7c9048849addc6650486d15b62b864999e5058ae21d9ab0c7f50b436f,
&adamic_declaration_dfd84fbb19afe477b993039123dc9fb7eeeac2b2498317b174789200ac1e5a80,
&adamic_declaration_6b826af4153b11c0615244a3f54af501deabb06fbb3e6b832c344f666d461f2a,
&adamic_declaration_77ff06dcd7c0fee718ea9aa5a37304915f5099362eb863da41d03ffc884a6654,
&adamic_declaration_4ad672e9921b9480d9be8e7971a2abc512a226e1ea91d8876bdee2409688748d,
&adamic_declaration_da44a6ffa557d1c3a562b3feb335c07381237d3b7aa282fef64a07a4f679f1b4,
&adamic_declaration_b0d3502bf8606e563fca1e94e18a200b1d011d47b59fdd7401ce5a7674ce73c9,
&adamic_declaration_e0b3652e00be9483af6af0374280ab7bc0c07ac47e4da9e9891f0c8ce50f68e3,
&adamic_declaration_2c2a975e4dbe383ec36deb772b00e78ca73cb6826c9d43aa188c960052694c5e,
&adamic_declaration_1176c8ca03679f6ef59bdc513bd0fbec389ae60eb0e30e632024d1d203557833,
&adamic_declaration_ccef815bec6967471af21b607774411a1ed96d9c72dfb83c29aa917e654e9f5c,
&adamic_declaration_99cf26cffea1dd0bfb7c9c40620a03d6412c55b8cd351991d15e07e121f7e182,
&adamic_declaration_f69bf81f0cc405b9a96f495e0d70b45199e1dc6d65b9af8b2debda6ede88ba9d,
&adamic_declaration_4dc94fc03b0efbd1b0a8160100ff357b8ec432802b283368a47c85d7700e2922,
&adamic_declaration_31b5ccc3cd2100d693698121d333b2ef8f53d67ea9fe3ce8aec2ab38aa6b3aaa,
&adamic_declaration_2798ceda69a8a2525d97714c2a89f7855358e19b77d6edcc91fc298f5c926d1d,
&adamic_declaration_ea812d2d90a45c06f8faef8dfcfd97fb1255409ee33a9e732a84218696459c95,
&adamic_declaration_d9a0119dea9b74b1675c85031ae35dd96c935e6d1cd0a883ce8ead5debcf3249,
&adamic_declaration_4386e4ca68fa6d08608473a43920b35746bef2a7ea3b9e8d87e56d37d422d4cb,
&adamic_declaration_3b769f2585867f6e489d6eeee34adf1417abd89eecd4e4fbc489962626d50f25,
&adamic_declaration_40e7e8c21045c6cba4e638daee4243640e14b84f7aafceb742d630666888a066,
&adamic_declaration_712a697edb5c3d82bd2ebc5e82b20f1e3b6f757af6fd84fe280ed7cf4d94fa21,
&adamic_declaration_3d7b78d5bd6ca2d14bf2ab5786f182d6f57b6df9c5ac70d5597dd9d30a40805b,
&adamic_declaration_f9d384301441933cce40459dc7cc6bf7bdcf176c9aefbf4661223e0b966df5d8,
&adamic_declaration_5088c320c2f066653b3bbcf6cbd2a86bffe21629f1128bbd8cf4f5948990cf1d,
&adamic_declaration_065d81975a962f950c3f02781b259619a67038af941f15ac7cf3879d995703d8,
&adamic_declaration_1277621bac56a8b66900f58d63619d9feb133ae8e87433264a06c637f8bfd652,
&adamic_declaration_62ed50d45e54245517e94cefb1832c47eb63a646d318b01d0273aefb965aa8ab,
&adamic_declaration_a6fa976860ed9b77b773156a72a3faa0db2bb239d60283307ae63e7c2c595105,
&adamic_declaration_1dc05bddf95d8d6736d9f6bdf4f9b0f3e9707de9467049f989ea0c5ca33fd952,
&adamic_declaration_32bf25d1442998c1576e6def15e965f7fc0254623d661b26bb754abf5b82d250,
&adamic_declaration_ce39a5225eef48c694a8d3f5f360a8ca24a9b5cf3dbd2b3cf1cffbbc9d1093be,
&adamic_declaration_d81edc49e645f79cdccd34ffb3d40ed6debdb8bdd6c38cbf0fe7efee4837cb0b,
&adamic_declaration_8baeb7e18915ba06b5f2a9137b40b6f7c5d110ac40fe4a514f841a9ca07a35f5,
&adamic_declaration_7e968a7659215944f752118c109abdb231551f2a8448e10bd56eb143ea35a105,
&adamic_declaration_f08b1055f65a78ba4745dce02320b0267e3af9b84bb455fc47e09255d9a0fa1c,
&adamic_declaration_d2817ddade30f72016dc5127aa96be3960321f105fe82d0a66e6315c9e476868,
&adamic_declaration_14ee065ed78249b31840703a0af6d4698706a5f7c035c5e39ea4469815068c02,
&adamic_declaration_2e8196b638af99e0f56ab6326c75dc898ba1804311a8bad78f8fbca0a1c93172,
&adamic_declaration_9d2a3d40e30d6191e983d13e5152f913fff76c596389cb9ca1ae80f9bf6c859f,
&adamic_declaration_037b05befc2e117bd01a5568a586c43f8bec6abc773410a8bd8beb15ce60f7f5,
&adamic_declaration_8c81852b51e9e271a0f08699d1fdda830c0f6975820f09a84fb92313aadbabe7,
&adamic_declaration_58130658fc8e70725e1161819bd6fc608f78632c226f65862f5a3a9ddb301d5c,
};
