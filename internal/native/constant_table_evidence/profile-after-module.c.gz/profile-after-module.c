# 1 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 409 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1.c" 2
# 1 "./units.h" 1


# 1 "./adamic.h" 1





# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdbool.h" 1 3
# 7 "./adamic.h" 2
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 1 3
# 84 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_header_macro.h" 1 3
# 85 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3



# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 89 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_size_t.h" 1 3
# 18 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 94 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 103 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_wchar_t.h" 1 3
# 24 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 104 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_null.h" 1 3
# 109 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 123 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 3
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_max_align_t.h" 1 3
# 19 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_max_align_t.h" 3
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
# 124 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3




# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/__stddef_offsetof.h" 1 3
# 129 "/workspace/adamic-tools/llvm/lib/clang/20/include/stddef.h" 2 3
# 8 "./adamic.h" 2
# 1 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 1 3
# 56 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 3
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 415 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 416 "/usr/include/features.h" 2 3 4
# 501 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 502 "/usr/include/features.h" 2 3 4
# 523 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 730 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 731 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 732 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 524 "/usr/include/features.h" 2 3 4
# 547 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 548 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 57 "/workspace/adamic-tools/llvm/lib/clang/20/include/stdint.h" 2 3
# 9 "./adamic.h" 2

# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 28 "/usr/include/math.h" 2 3 4
# 40 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 2 3 4
# 41 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 83 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__)));
# 97 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
typedef __float128 _Float128;
# 131 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 132 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 44 "/usr/include/math.h" 2 3 4
# 156 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 157 "/usr/include/math.h" 2 3 4
# 167 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 208 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-logb.h" 1 3 4
# 209 "/usr/include/math.h" 2 3 4
# 251 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-fast.h" 1 3 4
# 252 "/usr/include/math.h" 2 3 4
# 275 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-macros.h" 1 3 4
# 276 "/usr/include/math.h" 2 3 4





# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinf (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnan (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsig (double __x, double __y) __attribute__ ((__nothrow__ ));


extern int __issignaling (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 282 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acos (double __x) __attribute__ ((__nothrow__ )); extern double __acos (double __x) __attribute__ ((__nothrow__ ));

 extern double asin (double __x) __attribute__ ((__nothrow__ )); extern double __asin (double __x) __attribute__ ((__nothrow__ ));

 extern double atan (double __x) __attribute__ ((__nothrow__ )); extern double __atan (double __x) __attribute__ ((__nothrow__ ));

 extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__ )); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__ ));


 extern double cos (double __x) __attribute__ ((__nothrow__ )); extern double __cos (double __x) __attribute__ ((__nothrow__ ));

 extern double sin (double __x) __attribute__ ((__nothrow__ )); extern double __sin (double __x) __attribute__ ((__nothrow__ ));

 extern double tan (double __x) __attribute__ ((__nothrow__ )); extern double __tan (double __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double cosh (double __x) __attribute__ ((__nothrow__ )); extern double __cosh (double __x) __attribute__ ((__nothrow__ ));

 extern double sinh (double __x) __attribute__ ((__nothrow__ )); extern double __sinh (double __x) __attribute__ ((__nothrow__ ));

 extern double tanh (double __x) __attribute__ ((__nothrow__ )); extern double __tanh (double __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acosh (double __x) __attribute__ ((__nothrow__ )); extern double __acosh (double __x) __attribute__ ((__nothrow__ ));

 extern double asinh (double __x) __attribute__ ((__nothrow__ )); extern double __asinh (double __x) __attribute__ ((__nothrow__ ));

 extern double atanh (double __x) __attribute__ ((__nothrow__ )); extern double __atanh (double __x) __attribute__ ((__nothrow__ ));





 extern double exp (double __x) __attribute__ ((__nothrow__ )); extern double __exp (double __x) __attribute__ ((__nothrow__ ));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ )); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern double log (double __x) __attribute__ ((__nothrow__ )); extern double __log (double __x) __attribute__ ((__nothrow__ ));


 extern double log10 (double __x) __attribute__ ((__nothrow__ )); extern double __log10 (double __x) __attribute__ ((__nothrow__ ));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double expm1 (double __x) __attribute__ ((__nothrow__ )); extern double __expm1 (double __x) __attribute__ ((__nothrow__ ));


 extern double log1p (double __x) __attribute__ ((__nothrow__ )); extern double __log1p (double __x) __attribute__ ((__nothrow__ ));


extern double logb (double __x) __attribute__ ((__nothrow__ )); extern double __logb (double __x) __attribute__ ((__nothrow__ ));




 extern double exp2 (double __x) __attribute__ ((__nothrow__ )); extern double __exp2 (double __x) __attribute__ ((__nothrow__ ));


 extern double log2 (double __x) __attribute__ ((__nothrow__ )); extern double __log2 (double __x) __attribute__ ((__nothrow__ ));






 extern double pow (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__ ));


extern double sqrt (double __x) __attribute__ ((__nothrow__ )); extern double __sqrt (double __x) __attribute__ ((__nothrow__ ));



 extern double hypot (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__ ));




 extern double cbrt (double __x) __attribute__ ((__nothrow__ )); extern double __cbrt (double __x) __attribute__ ((__nothrow__ ));






extern double ceil (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double copysign (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double nan (const char *__tagb) __attribute__ ((__nothrow__ )); extern double __nan (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double erf (double) __attribute__ ((__nothrow__ )); extern double __erf (double) __attribute__ ((__nothrow__ ));
 extern double erfc (double) __attribute__ ((__nothrow__ )); extern double __erfc (double) __attribute__ ((__nothrow__ ));
extern double lgamma (double) __attribute__ ((__nothrow__ )); extern double __lgamma (double) __attribute__ ((__nothrow__ ));




extern double tgamma (double) __attribute__ ((__nothrow__ )); extern double __tgamma (double) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double rint (double __x) __attribute__ ((__nothrow__ )); extern double __rint (double __x) __attribute__ ((__nothrow__ ));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__ ));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ )); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__ )); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogb (double __x) __attribute__ ((__nothrow__ )); extern int __ilogb (double __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__ )); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__ ));



extern double nearbyint (double __x) __attribute__ ((__nothrow__ )); extern double __nearbyint (double __x) __attribute__ ((__nothrow__ ));



extern double round (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ )); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrint (double __x) __attribute__ ((__nothrow__ )); extern long int __lrint (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrint (double __x) __attribute__ ((__nothrow__ )); extern long long int __llrint (double __x) __attribute__ ((__nothrow__ ));



extern long int lround (double __x) __attribute__ ((__nothrow__ )); extern long int __lround (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llround (double __x) __attribute__ ((__nothrow__ )); extern long long int __llround (double __x) __attribute__ ((__nothrow__ ));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double fmax (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ )); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ ));
# 283 "/usr/include/math.h" 2 3 4
# 298 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinff (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanf (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern int __issignalingf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 299 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acosf (float __x) __attribute__ ((__nothrow__ )); extern float __acosf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinf (float __x) __attribute__ ((__nothrow__ )); extern float __asinf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanf (float __x) __attribute__ ((__nothrow__ )); extern float __atanf (float __x) __attribute__ ((__nothrow__ ));

 extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__ )); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__ ));


 extern float cosf (float __x) __attribute__ ((__nothrow__ )); extern float __cosf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinf (float __x) __attribute__ ((__nothrow__ )); extern float __sinf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanf (float __x) __attribute__ ((__nothrow__ )); extern float __tanf (float __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float coshf (float __x) __attribute__ ((__nothrow__ )); extern float __coshf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinhf (float __x) __attribute__ ((__nothrow__ )); extern float __sinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanhf (float __x) __attribute__ ((__nothrow__ )); extern float __tanhf (float __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acoshf (float __x) __attribute__ ((__nothrow__ )); extern float __acoshf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinhf (float __x) __attribute__ ((__nothrow__ )); extern float __asinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanhf (float __x) __attribute__ ((__nothrow__ )); extern float __atanhf (float __x) __attribute__ ((__nothrow__ ));





 extern float expf (float __x) __attribute__ ((__nothrow__ )); extern float __expf (float __x) __attribute__ ((__nothrow__ ));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ )); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ )); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern float logf (float __x) __attribute__ ((__nothrow__ )); extern float __logf (float __x) __attribute__ ((__nothrow__ ));


 extern float log10f (float __x) __attribute__ ((__nothrow__ )); extern float __log10f (float __x) __attribute__ ((__nothrow__ ));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float expm1f (float __x) __attribute__ ((__nothrow__ )); extern float __expm1f (float __x) __attribute__ ((__nothrow__ ));


 extern float log1pf (float __x) __attribute__ ((__nothrow__ )); extern float __log1pf (float __x) __attribute__ ((__nothrow__ ));


extern float logbf (float __x) __attribute__ ((__nothrow__ )); extern float __logbf (float __x) __attribute__ ((__nothrow__ ));




 extern float exp2f (float __x) __attribute__ ((__nothrow__ )); extern float __exp2f (float __x) __attribute__ ((__nothrow__ ));


 extern float log2f (float __x) __attribute__ ((__nothrow__ )); extern float __log2f (float __x) __attribute__ ((__nothrow__ ));






 extern float powf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern float sqrtf (float __x) __attribute__ ((__nothrow__ )); extern float __sqrtf (float __x) __attribute__ ((__nothrow__ ));



 extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__ ));




 extern float cbrtf (float __x) __attribute__ ((__nothrow__ )); extern float __cbrtf (float __x) __attribute__ ((__nothrow__ ));






extern float ceilf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float nanf (const char *__tagb) __attribute__ ((__nothrow__ )); extern float __nanf (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float erff (float) __attribute__ ((__nothrow__ )); extern float __erff (float) __attribute__ ((__nothrow__ ));
 extern float erfcf (float) __attribute__ ((__nothrow__ )); extern float __erfcf (float) __attribute__ ((__nothrow__ ));
extern float lgammaf (float) __attribute__ ((__nothrow__ )); extern float __lgammaf (float) __attribute__ ((__nothrow__ ));




extern float tgammaf (float) __attribute__ ((__nothrow__ )); extern float __tgammaf (float) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float rintf (float __x) __attribute__ ((__nothrow__ )); extern float __rintf (float __x) __attribute__ ((__nothrow__ ));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__ ));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ )); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__ )); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbf (float __x) __attribute__ ((__nothrow__ )); extern int __ilogbf (float __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ )); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ ));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__ )); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__ ));



extern float roundf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ )); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintf (float __x) __attribute__ ((__nothrow__ )); extern long int __lrintf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__ ));



extern long int lroundf (float __x) __attribute__ ((__nothrow__ )); extern long int __lroundf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__ ));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ )); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ ));
# 300 "/usr/include/math.h" 2 3 4
# 367 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinfl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern int __issignalingl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 368 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ )); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ ));


 extern long double cosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanl (long double __x) __attribute__ ((__nothrow__ ));
# 89 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double coshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __coshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__ ));
# 103 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acoshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__ ));





 extern long double expl (long double __x) __attribute__ ((__nothrow__ )); extern long double __expl (long double __x) __attribute__ ((__nothrow__ ));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ )); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern long double logl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logl (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log10l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log10l (long double __x) __attribute__ ((__nothrow__ ));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 152 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double expm1l (long double __x) __attribute__ ((__nothrow__ )); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log1pl (long double __x) __attribute__ ((__nothrow__ )); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__ ));


extern long double logbl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logbl (long double __x) __attribute__ ((__nothrow__ ));




 extern long double exp2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log2l (long double __x) __attribute__ ((__nothrow__ ));






 extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__ ));



 extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ ));




 extern long double cbrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__ ));






extern long double ceill (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 231 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double nanl (const char *__tagb) __attribute__ ((__nothrow__ )); extern long double __nanl (const char *__tagb) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double erfl (long double) __attribute__ ((__nothrow__ )); extern long double __erfl (long double) __attribute__ ((__nothrow__ ));
 extern long double erfcl (long double) __attribute__ ((__nothrow__ )); extern long double __erfcl (long double) __attribute__ ((__nothrow__ ));
extern long double lgammal (long double) __attribute__ ((__nothrow__ )); extern long double __lgammal (long double) __attribute__ ((__nothrow__ ));




extern long double tgammal (long double) __attribute__ ((__nothrow__ )); extern long double __tgammal (long double) __attribute__ ((__nothrow__ ));
# 292 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double rintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __rintl (long double __x) __attribute__ ((__nothrow__ ));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ ));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 308 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ )); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__ )); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__ ));
# 326 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ )); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ ));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__ ));



extern long double roundl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ )); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__ ));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__ ));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ )); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ ));
# 369 "/usr/include/math.h" 2 3 4
# 450 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinff128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitef128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigf128 (_Float128 __x, _Float128 __y) __attribute__ ((__nothrow__ ));


extern int __issignalingf128 (_Float128 __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 451 "/usr/include/math.h" 2 3 4
# 903 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 11 "./adamic.h" 2

enum adamic_stream {
 adamic_stdout = 1,
 adamic_stderr = 2,
};




enum adamic_kind {
 adamic_kind_string = 1,
 adamic_kind_object,
 adamic_kind_array,
 adamic_kind_map,
 adamic_kind_cell,
 adamic_kind_closure,
 adamic_kind_map_iterator,
 adamic_kind_number,
 adamic_kind_boolean,
 adamic_kind_weak,
};

typedef struct adamic_heap {
 size_t references;
 enum adamic_kind kind;


 uint32_t slab;
} adamic_heap;


void *adamic_retain(void *value);
void adamic_release(void *value);


void *adamic_allocate(size_t size, enum adamic_kind kind);



typedef union adamic_value {
 double number;
 _Bool boolean;
 void *reference;
} adamic_value;


typedef struct adamic_maybe_number {
 _Bool present;
 double number;
} adamic_maybe_number;


typedef struct adamic_maybe_boolean {
 _Bool present;
 _Bool boolean;
} adamic_maybe_boolean;



typedef struct adamic_cell {
 adamic_heap heap;
 _Bool references;
 adamic_value value;
} adamic_cell;

adamic_cell *adamic_cell_new(adamic_value value, _Bool references);



typedef struct adamic_closure adamic_closure;
typedef adamic_value (*adamic_code)(adamic_closure *self, adamic_value *arguments);
struct adamic_closure {
 adamic_heap heap;
 adamic_code code;
 size_t count;
 adamic_cell *cells[];
};


adamic_closure *adamic_closure_new(adamic_code code, size_t count);


typedef struct adamic_string {
 adamic_heap heap;
 size_t length;
 const char *bytes;




 size_t units;
 struct adamic_string_index *index;



 struct adamic_string *owner;



 size_t capacity;
} adamic_string;

struct adamic_string_index {

 size_t cursor_unit;
 size_t cursor_offset;



 size_t count;


 uint16_t *view;
 uint32_t checkpoints[];
};




extern char adamic_literal_mark;
# 143 "./adamic.h"
typedef struct adamic_methods adamic_methods;
typedef struct adamic_shape {
 size_t count;
 const char *const *names;
 const _Bool *references;
 const adamic_methods *methods;
} adamic_shape;

typedef void (*adamic_virtual_method)(void);
typedef struct adamic_object adamic_object;
typedef struct adamic_accessor {
 const char *name;
 adamic_value (*get)(adamic_object *);
 void (*set)(adamic_object *, adamic_value, int);
 int type;
} adamic_accessor;
typedef struct adamic_class {
 const struct adamic_class *base;
 size_t own_start;
 size_t count;
 const adamic_virtual_method *methods;
 size_t definition;
 const adamic_shape *public_shape;
 const adamic_accessor *accessors;
 size_t accessor_count;
 _Bool is_static;
 size_t static_parent;
 const size_t *static_flags;
} adamic_class;



typedef struct adamic_object {
 adamic_heap heap;
 const adamic_shape *shape;
 const adamic_class *class;
 _Bool frozen;
 adamic_value slots[];
} adamic_object;

_Bool adamic_instanceof(const void *value, const adamic_class *wanted);
adamic_virtual_method adamic_virtual(const adamic_object *object, size_t slot);
void adamic_object_free_children(adamic_object *object, void (*release)(void *));



typedef struct adamic_slot_cache {
 const adamic_shape *shape;
 size_t index;
} adamic_slot_cache;



typedef adamic_value (*adamic_method)(adamic_object *self, adamic_value *arguments);
struct adamic_methods {
 size_t count;
 const char *const *names;
 const adamic_method *code;
};




adamic_closure *adamic_object_callee(const adamic_object *object, const char *name, adamic_slot_cache *cache, adamic_method *method);



adamic_object *adamic_object_new(const adamic_shape *shape);





typedef struct adamic_region_block adamic_region_block;
typedef struct adamic_region {
 adamic_region_block *blocks;
 size_t count;
} adamic_region;

adamic_object *adamic_object_new_in(adamic_region *region, const adamic_shape *shape);
void adamic_region_end(adamic_region *region);


adamic_object *adamic_object_copy(const adamic_object *source);


_Bool adamic_object_has(const adamic_object *object, const adamic_string *name);




adamic_value *adamic_object_find(const adamic_object *object, const char *name, adamic_slot_cache *cache);
adamic_value *adamic_static_field(const adamic_object *object, const char *name, adamic_slot_cache *cache);
adamic_value *adamic_object_write_field(adamic_object *object, const char *name, adamic_slot_cache *cache);

adamic_maybe_number adamic_object_maybe_number(const adamic_object *object, const char *name, adamic_slot_cache *cache);

adamic_value *adamic_object_optional_find(const adamic_object *object, const char *name, adamic_slot_cache *cache);
static inline adamic_value *adamic_object_optional_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (cache->shape != object->shape) {
  return adamic_object_optional_find(object, name, cache);
 }
 if (cache->index == object->shape->count) {
  return ((void*)0);
 }
 return &((adamic_object *)object)->slots[cache->index];
}



static inline adamic_value *adamic_object_data_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (cache->shape == object->shape) {
  return &((adamic_object *)object)->slots[cache->index];
 }
 return adamic_object_find(object, name, cache);
}

static inline adamic_value *adamic_object_field(const adamic_object *object, const char *name, adamic_slot_cache *cache) {
 if (object->class != ((void*)0) && object->class->is_static) { return adamic_static_field(object, name, cache); }
 return adamic_object_data_field(object, name, cache);
}


_Bool adamic_object_is(const adamic_heap *left, const adamic_heap *right);
_Bool adamic_object_is_frozen(const adamic_heap *value);
adamic_object *adamic_object_freeze(adamic_object *object);
_Bool adamic_object_has_own(const adamic_object *object, const adamic_string *key);
struct adamic_array *adamic_object_keys(const adamic_object *object);
struct adamic_array *adamic_object_values(const adamic_object *object, _Bool references, _Bool entries);
void adamic_object_assign(adamic_object *target, const adamic_object *source);
void adamic_object_check_write(const adamic_object *object, const char *name);

static inline void adamic_object_check_data_write(const adamic_object *object, const char *name) {
 if (object->frozen) {
  adamic_object_check_write(object, name);
 }
}


typedef struct adamic_array {
 adamic_heap heap;
 size_t length;
 size_t capacity;
 _Bool references;
 adamic_value *elements;

 adamic_object *properties;
} adamic_array;

adamic_array *adamic_array_new(size_t capacity, _Bool references);
size_t adamic_public_index(const adamic_shape *shape, size_t position);
adamic_array *adamic_class_object_keys(const adamic_object *object);
const adamic_accessor *adamic_accessor_find(const adamic_object *object, const char *name);
adamic_value adamic_accessor_get(adamic_object *object, const char *name);
void adamic_accessor_set(adamic_object *object, const char *name, adamic_value value, int type);


void adamic_array_push(adamic_array *array, adamic_value value);


typedef struct adamic_map_entry {
 adamic_value key;
 adamic_value value;
 _Bool deleted;
} adamic_map_entry;

typedef struct adamic_map {
 adamic_heap heap;
 size_t count;
 size_t used;
 size_t capacity;
 adamic_map_entry *entries;
 size_t bucket_count;
 size_t *buckets;
 _Bool string_keys;


 _Bool reference_keys;


 _Bool boolean_keys;


 _Bool maybe_number_keys;
 _Bool reference_values;


 size_t iterating;
} adamic_map;




typedef struct adamic_map_iterator {
 adamic_heap heap;
 adamic_map *map;
 size_t next;
 _Bool exhausted;
} adamic_map_iterator;

adamic_map_iterator *adamic_map_iterate(adamic_map *map);
adamic_object *adamic_collection_iterator(adamic_map *collection, int part, int key, int value, _Bool set);


_Bool adamic_map_iterator_next(adamic_map_iterator *iterator, union adamic_value *key, union adamic_value *value);

adamic_map *adamic_map_new(_Bool string_keys, _Bool reference_values);



adamic_map *adamic_map_new_identity(_Bool reference_values);


adamic_map *adamic_map_new_booleans(_Bool reference_values);
_Bool adamic_map_maybe_key_equal(double left, double right);
uint64_t adamic_map_maybe_key_hash(double key);
uint64_t adamic_map_number_hash(double number);


adamic_map *adamic_map_new_maybe_numbers(_Bool reference_values);



void adamic_map_clear(adamic_map *map);



adamic_array *adamic_map_keys(const adamic_map *map);



void adamic_map_add_pairs(adamic_map *map, const adamic_array *pairs);
adamic_array *adamic_map_values(const adamic_map *map);


adamic_value *adamic_map_get(const adamic_map *map, adamic_value key);


void adamic_map_set(adamic_map *map, adamic_value key, adamic_value value);

_Bool adamic_map_delete(adamic_map *map, adamic_value key);



typedef adamic_object adamic_record;
typedef adamic_object adamic_record_iterator;

adamic_record *adamic_record_new(_Bool reference_values);

adamic_value *adamic_record_get_own(const adamic_record *record, const adamic_string *key);
_Bool adamic_record_has_own(const adamic_record *record, const adamic_string *key);



adamic_value *adamic_record_get(const adamic_record *record, const adamic_string *key);
_Bool adamic_record_has(const adamic_record *record, const adamic_string *key);


void adamic_record_define(adamic_record *record, adamic_string *key, adamic_value value);
void adamic_record_set(adamic_record *record, adamic_string *key, adamic_value value);
_Bool adamic_record_delete(adamic_record *record, const adamic_string *key);
size_t adamic_record_size(const adamic_record *record);

adamic_array *adamic_record_keys(const adamic_record *record);


adamic_record_iterator *adamic_record_iterate(adamic_record *record);
_Bool adamic_record_iterator_next(adamic_record_iterator *iterator, adamic_string **key, adamic_value *value);




void adamic_set_add_all(adamic_map *set, const adamic_array *values);
adamic_array *adamic_set_values(const adamic_map *set);


void adamic_map_free_children(adamic_map *map, void (*let_go)(void *));
# 432 "./adamic.h"
static inline adamic_value *adamic_array_at_integer(const adamic_array *array, int64_t index) {
 if (index < 0 || (uint64_t)index >= array->length) {
  return ((void*)0);
 }
 return &array->elements[index];
}

static inline adamic_value *adamic_array_at(const adamic_array *array, double index) {
 if (!(index >= 0) || index >= (double)array->length) {
  return ((void*)0);
 }
 size_t whole = (size_t)index;
 if ((double)whole != index) {
  return ((void*)0);
 }
 return &array->elements[whole];
}



void adamic_array_set(adamic_array *array, double index, adamic_value value);


adamic_value *adamic_array_at_relative(const adamic_array *array, double index);



enum adamic_equality {
 adamic_equal_numbers = 1,
 adamic_equal_booleans,
 adamic_equal_strings,
 adamic_equal_identity,
 adamic_equal_maybe_numbers,
};
double adamic_array_index_of(const adamic_array *array, adamic_value value, enum adamic_equality equality, _Bool same_value_zero);
double adamic_array_search_from(const adamic_array *array, adamic_value value, enum adamic_equality equality, _Bool same_value_zero, double from, _Bool has_from, _Bool last);



size_t adamic_array_from_length(double length);



adamic_array *adamic_array_reverse(adamic_array *array);




adamic_array *adamic_array_filled(double length, adamic_value value, _Bool references);
adamic_array *adamic_array_fill(adamic_array *array, adamic_value value, double start, double end, _Bool has_start, _Bool has_end);



adamic_array *adamic_array_splice(adamic_array *array, double start, double count, _Bool has_count, size_t item_count, const adamic_value *items);


void adamic_array_remove(adamic_array *array, double start, double count, _Bool has_count, size_t item_count, const adamic_value *items);



void adamic_array_append(adamic_array *array, const adamic_array *source);
adamic_array *adamic_array_concat(size_t count, adamic_array *const arrays[]);




adamic_array *adamic_array_slice(const adamic_array *array, double start, double end, _Bool has_end);
void adamic_array_sort(adamic_array *array, int (*compare)(adamic_value, adamic_value, void *), void *context);
int adamic_compare_closure(adamic_value left, adamic_value right, void *context);


_Bool adamic_timsort(adamic_value *work, size_t count, int (*compare)(adamic_value, adamic_value, void *), void *context);



void adamic_array_sort_undefined_last(adamic_array *array, int (*compare)(adamic_value, adamic_value, void *), void *context);


adamic_array *adamic_map_entries(const adamic_map *map, const adamic_shape *pair);


enum adamic_join {
 adamic_join_numbers = 1,
 adamic_join_booleans,
 adamic_join_strings,
 adamic_join_maybe_numbers,
};
struct adamic_string *adamic_array_join(const adamic_array *array, const struct adamic_string *separator, enum adamic_join kind);

struct adamic_string *adamic_array_join_nested(const adamic_array *array, const struct adamic_string *separator, enum adamic_join kind, size_t depth);


adamic_string *adamic_string_from_number(double value);



double adamic_number_parse_int(const adamic_string *text, double radix);
double adamic_number_parse_float(const adamic_string *text);
double adamic_number_from_string(const adamic_string *text);
double adamic_number_from_union(const adamic_heap *value);
_Bool adamic_number_has_own_property(const adamic_string *key, _Bool prototype);
double adamic_math_clz32(double value);
double adamic_math_imul(double left, double right);
double adamic_math_fround(double value);
adamic_string *adamic_string_concat(size_t count, adamic_string *const parts[]);


extern adamic_string adamic_string_empty;
extern adamic_string adamic_string_true;
extern adamic_string adamic_string_false;




extern adamic_string adamic_string_undefined;
adamic_string *adamic_string_from_maybe_number(adamic_maybe_number value);
_Bool adamic_maybe_number_equal(adamic_maybe_number left, adamic_maybe_number right);







double adamic_maybe_number_pack(adamic_maybe_number value);
adamic_maybe_number adamic_maybe_number_unpack(double packed);
_Bool adamic_maybe_boolean_equal(adamic_maybe_boolean left, adamic_maybe_boolean right);






size_t adamic_string_units(const adamic_string *string);
double adamic_string_char_code(const adamic_string *string, double position);
static inline double adamic_string_length(const adamic_string *string) {
 return string->units != 0 ? (double)(string->units - 1) : (double)adamic_string_units(string);
}
static inline double adamic_string_char_code_at(const adamic_string *string, double position) {
 if (string->units == string->length + 1 && position >= 0 && position < (double)string->length) {
  return (double)(unsigned char)string->bytes[(size_t)position];
 }


 if (string->index != ((void*)0) && string->index != ((struct adamic_string_index *)&adamic_literal_mark) && position >= 0 && position < (double)(string->units - 1)) {
  return (double)string->index->view[(size_t)position];
 }
 return adamic_string_char_code(string, position);
}
adamic_string *adamic_string_trim(adamic_string *string);



size_t adamic_string_next(const adamic_string *string, size_t offset);
adamic_string *adamic_string_slice_bytes(const adamic_string *string, size_t offset, size_t size);



adamic_string *adamic_string_share(const adamic_string *string, size_t offset, size_t size);



adamic_string *adamic_string_slice(const adamic_string *string, double start, double end, _Bool has_end);
adamic_maybe_number adamic_string_code_point_at(const adamic_string *string, double position);
int adamic_string_compare(const adamic_string *left, const adamic_string *right);
adamic_string *adamic_string_repeat(const adamic_string *string, double count);
adamic_string *adamic_string_pad(const adamic_string *string, double target, const adamic_string *fill, _Bool at_start);
double adamic_string_index_of(const adamic_string *string, const adamic_string *search);



double adamic_string_index_of_at(const adamic_string *string, const adamic_string *search, size_t from);
double adamic_string_index_of_from(const adamic_string *string, const adamic_string *search, double position);
_Bool adamic_string_starts_with(const adamic_string *string, const adamic_string *search);
_Bool adamic_string_ends_with(const adamic_string *string, const adamic_string *search);
struct adamic_array *adamic_string_code_points(const adamic_string *string);
struct adamic_array *adamic_string_split(const adamic_string *string, const adamic_string *separator);



adamic_string *adamic_string_at(const adamic_string *string, double index);
adamic_string *adamic_string_at_relative(const adamic_string *string, double index);


adamic_string *adamic_string_trim_sides(adamic_string *string, _Bool at_start, _Bool at_end);



double adamic_string_last_index_of(const adamic_string *string, const adamic_string *search);
adamic_string *adamic_string_replace(const adamic_string *string, const adamic_string *search, const adamic_string *replacement, _Bool all);






void adamic_string_check_length(double units);


adamic_string *adamic_string_allocate(size_t length);



adamic_string *adamic_string_to_upper(const adamic_string *string);
adamic_string *adamic_string_to_lower(const adamic_string *string);



adamic_string *adamic_string_normalize(const adamic_string *string, const adamic_string *form);







size_t adamic_string_join_halves(char *bytes, size_t from, size_t length);




size_t adamic_string_put(char *bytes, size_t written, const adamic_string *part);




adamic_string *adamic_string_append(adamic_string *string, size_t count, adamic_string *const parts[]);

size_t adamic_string_units(const adamic_string *string);
size_t adamic_string_locate(const adamic_string *string, size_t unit, _Bool *low);



size_t adamic_string_units_before(const adamic_string *string, size_t offset);
void adamic_string_free_index(adamic_string *string);


int adamic_string_equal(const adamic_string *left, const adamic_string *right);




typedef struct adamic_number_box {
 adamic_heap heap;
 double number;
} adamic_number_box;

typedef struct adamic_boolean_box {
 adamic_heap heap;
 _Bool boolean;
} adamic_boolean_box;

extern adamic_boolean_box adamic_box_true;
extern adamic_boolean_box adamic_box_false;


adamic_heap *adamic_box_number(double number);


_Bool adamic_union_equal(const adamic_heap *left, const adamic_heap *right);



adamic_string *adamic_union_to_string(adamic_heap *value);



adamic_string *adamic_union_typeof(const adamic_heap *value, _Bool null);
extern adamic_string adamic_typeof_number;
extern adamic_string adamic_typeof_string;
extern adamic_string adamic_typeof_boolean;
extern adamic_string adamic_typeof_undefined;
extern adamic_string adamic_typeof_object;
extern adamic_string adamic_typeof_function;







typedef struct adamic_weak adamic_weak;
adamic_weak *adamic_weak_of(void *target);
void *adamic_weak_target(const adamic_weak *handle);
void *adamic_weak_target_present(const adamic_weak *handle);
void adamic_weak_forget(void *target);
void adamic_weak_dropped(adamic_weak *handle);


_Bool adamic_weak_held(const void *target);




extern adamic_object *adamic_thrown;
adamic_object *adamic_error_new(adamic_string *message);
_Noreturn void adamic_uncaught(void);



void adamic_start(int count, char **values);



void adamic_output_flush(void);



void adamic_write_line(enum adamic_stream stream, const adamic_string *string);






size_t adamic_number_format(double value, char buffer[32]);


double adamic_power(double base, double exponent);



double adamic_math_round(double value);
double adamic_math_sign(double value);
double adamic_math_max(double left, double right);
double adamic_math_min(double left, double right);



double adamic_math_acos(double x);
double adamic_math_acosh(double x);
double adamic_math_asin(double x);
double adamic_math_asinh(double x);
double adamic_math_atan(double x);
double adamic_math_atan2(double y, double x);
double adamic_math_atanh(double x);
double adamic_math_cbrt(double x);
double adamic_math_cos(double x);
double adamic_math_cosh(double x);
double adamic_math_exp(double x);
double adamic_math_expm1(double x);
double adamic_math_log(double x);
double adamic_math_log1p(double x);
double adamic_math_log2(double x);
double adamic_math_log10(double x);
double adamic_math_sin(double x);
double adamic_math_sinh(double x);
double adamic_math_tan(double x);
double adamic_math_tanh(double x);
double adamic_math_hypot(size_t count, const double *values);



int adamic_number_shortest_digits(double value, char digits[18], int *point);




adamic_string *adamic_number_to_exponential(double value, double digits, _Bool has_digits);
adamic_string *adamic_number_to_precision(double value, double digits, _Bool has_digits);



double adamic_math_max_of(const adamic_array *values);
double adamic_math_min_of(const adamic_array *values);
double adamic_math_hypot_of(const adamic_array *values);
adamic_string *adamic_string_from_char_codes_of(const adamic_array *values);
adamic_string *adamic_string_from_code_points_of(const adamic_array *values);




double adamic_utf8_length(const adamic_string *text);
double adamic_utf8_at(const adamic_string *text, double index);


double adamic_bitwise_and(double left, double right);
double adamic_bitwise_or(double left, double right);
double adamic_bitwise_xor(double left, double right);
double adamic_bitwise_not(double value);
double adamic_shift_left(double left, double right);
double adamic_shift_right(double left, double right);
double adamic_shift_right_unsigned(double left, double right);




adamic_string *adamic_string_from_char_codes(size_t count, const double values[]);
adamic_string *adamic_string_from_code_points(size_t count, const double values[]);



adamic_string *adamic_number_to_radix(double value, double radix);


adamic_string *adamic_number_to_fixed(double value, double digits);





void adamic_arguments_save(int count, char **values);
adamic_array *adamic_program_arguments(void);
adamic_object *adamic_read_text_file(const adamic_string *path);





adamic_string *adamic_decode_utf8(const unsigned char *bytes, size_t length);
char *adamic_path_bytes(const adamic_string *path);




adamic_object *adamic_read_directory(const adamic_string *path);
adamic_object *adamic_file_status(const adamic_string *path);



adamic_object *adamic_write_text_file(const adamic_string *path, const adamic_string *text);


_Noreturn void adamic_panic(const char *message, size_t length);





extern uintptr_t adamic_stack_limit;
_Noreturn void adamic_stack_overflow(void);
# 887 "./adamic.h"
_Noreturn void adamic_unreachable(void);

# 1 "./regexp.h" 1




typedef struct {
 uint32_t first, last;
} adamic_regex_range;
typedef struct {
 const uint32_t *points;
 size_t count;
} adamic_regex_text;
typedef struct {
 const char *name;
 const size_t *captures;
 size_t count;
} adamic_regex_group;
typedef struct adamic_regex_program adamic_regex_program;
typedef struct {
 int op, x, y, direction;
 unsigned flags;
 int assertion;
 _Bool negative, greedy, unbounded;
 uint64_t minimum, maximum;
 const adamic_regex_range *ranges;
 size_t range_count;
 const adamic_regex_text *strings;
 size_t string_count;
 const size_t *ids;
 size_t id_count;
 const adamic_regex_program *look;
} adamic_regex_instruction;
struct adamic_regex_program {
 const adamic_regex_instruction *code;
 size_t captures, repeats;
 unsigned flags;
 const adamic_regex_group *groups;
 size_t group_count;
 const adamic_shape *group_shape;
 uint64_t first_ascii[2];
 _Bool filter_first;
 const uint16_t *prefix;
 size_t prefix_count;
 _Bool (*fast)(const uint16_t *, size_t, ptrdiff_t *, ptrdiff_t *, uint64_t *);
 _Bool anchored;
 _Bool (*fast_ascii)(const unsigned char *, size_t, ptrdiff_t *, ptrdiff_t *, uint64_t *);
};

adamic_object *adamic_regex_new(const adamic_regex_program *program, adamic_string *source,
        adamic_string *flags);
_Bool adamic_regex_test(adamic_object *regex, adamic_string *input);
adamic_array *adamic_regex_exec(adamic_object *regex, adamic_string *input);
adamic_array *adamic_regex_match(adamic_string *input, adamic_object *regex);
adamic_object *adamic_regex_match_all(adamic_string *input, adamic_object *regex);
adamic_array *adamic_regex_iterator_step(adamic_object *iterator);
adamic_object *adamic_regex_next(adamic_object *iterator);
adamic_string *adamic_regex_replace(adamic_string *input, adamic_object *regex,
         adamic_string *replacement, _Bool require_global);
adamic_array *adamic_regex_split(adamic_string *input, adamic_object *regex, double limit);
double adamic_regex_search(adamic_string *input, adamic_object *regex);
adamic_value adamic_regex_property(adamic_array *array, const char *name);
adamic_maybe_boolean adamic_regex_done(adamic_object *object);
void *adamic_regex_group_lookup(adamic_object *object, const char *name, _Bool optional);
void adamic_regex_set_step_limit(uint64_t limit);
# 890 "./adamic.h" 2


adamic_array *adamic_plain_object_keys(const adamic_object *object);
void *adamic_library_identity(size_t index);
# 4 "./units.h" 2
# 2 "module__2e__2e__2f_widthTables_2e_ts_9a9983a619e7fdf13ddd9ca4f1c25ab84372ffced184ad862375bca49e0149a1.c" 2
extern adamic_array * adamic_unit_adamic_global_146498800715071756000196259950243577147_wideRanges;
extern const char adamic_declaration_6a8d18b3e4ac1544fd0fc384989fbfd53a7ceb3bf4038c6220a03ac6ecae9783;
extern _Bool adamic_unit_adamic_global_146498800715071756000196259950243577147_wideRanges_ready;
extern const char adamic_declaration_17180fda0b6c0bab50b67b80adfb9441e0d911a8d842b0e957130b1c6053449d;
extern double adamic_unit_adamic_global_151792679279893729093594970742013293681_emojiStart;
extern const char adamic_declaration_5ea6ac41594cb1e3ee9b54729bda76865f9e1c6f151e97679171b8c7b9c8b140;
extern _Bool adamic_unit_adamic_global_151792679279893729093594970742013293681_emojiStart_ready;
extern const char adamic_declaration_017d2416b5c19577836076b716fbeaa06018720d16677f6770878a9a873f5749;
extern adamic_array * adamic_unit_adamic_global_192968371799965522085944136479175289966_emojiInstructions;
extern const char adamic_declaration_8d95de5c43ef1aef3a9a60d054aabc216d27116c27b72c131394c326c5dea252;
extern _Bool adamic_unit_adamic_global_192968371799965522085944136479175289966_emojiInstructions_ready;
extern const char adamic_declaration_7ffac9a6aa0cdf3ad7092897fcdd4b75c7730e87001a2a13a4ee1530d3670262;
extern adamic_array * adamic_unit_adamic_global_264060708524107954702806568172740178404_narrowInstructions;
extern const char adamic_declaration_d442969f28f0b889617b26213f7bfdacacd149b808bb850696d84c3552e60427;
extern _Bool adamic_unit_adamic_global_264060708524107954702806568172740178404_narrowInstructions_ready;
extern const char adamic_declaration_df182c3d6fba6a632218535e1b90b0d5f5d6c1b19b4ffba3f9a4a160942bdd57;
extern double adamic_unit_adamic_global_42037442971506454171932365986042096182_narrowStart;
extern const char adamic_declaration_2bd90f78e3a8e67a8203f798580be6b22ddabda16d5840500f13164f74179b24;
extern _Bool adamic_unit_adamic_global_42037442971506454171932365986042096182_narrowStart_ready;
extern const char adamic_declaration_7671e265e6012a3892bdb0775dcbe2ad8f0e0ed3f4d9ac06ae87fdbbf3e27b06;
extern adamic_array * adamic_unit_adamic_global_52901113597631254951881550976868039379_emojiStarts;
extern const char adamic_declaration_6e6fa3e2c4ec2654bda25513d24d92ba4a3cbf948582c3a56e1630f1df75da0c;
extern _Bool adamic_unit_adamic_global_52901113597631254951881550976868039379_emojiStarts_ready;
extern const char adamic_declaration_0717cc6b6f07c1ea1a0f872bc45c513b3d87044dd8232b25074ad4e29bcabc21;
void adamic_unit_adamic_initialize____widthTables_ts_68aa0e134d4cd9e872b91b14f358f21a(void) __attribute__((noinline));
extern const char adamic_declaration_079beee0520fc440fd224b3f027b392b3c30cbc26a9dab21e60676e6f253e971;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_02a029e6b1a51e862b2e2c886e8f7827(adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_166, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_167) __attribute__((noinline));
extern const char adamic_declaration_32f91cc635cbb606aa57e3bc9a3965891fda9f580266824df46004b6a5eef251;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_1df513d8e9d185750c5a6568e305dcbb(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_32, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_33, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_35, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_37, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_39, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_41, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_43, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_45, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_47, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_49, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_51, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_53, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_55, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_57, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_59, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_61, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_63, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_64, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65) __attribute__((noinline));
extern const char adamic_declaration_486eb31c34e5e3548551d868ee499a316ebee39f4581aed5804da1990b5688e8;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_291663ce58cd939f739c0155c588563b(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_154, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155) __attribute__((noinline));
extern const char adamic_declaration_c009395f1805c47ec552401c68e3e99dc96ea9867fb9a7478f8b99ee92bd0f8a;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_32986e3d92afc378735cfbfcde934312(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_5, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_7, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_9, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_11, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_13, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_15, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_17, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_19, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_21, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_23, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_25, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_27, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_29, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_31, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_33, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_35, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_37, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_39, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_41, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_43, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_45, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_47, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_49, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_51, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_53, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_55, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_57, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_59, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_61, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_63, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_97, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_99, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_101, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_103, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_105, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_107, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_109, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_111, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_113, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_115, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_117, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_119, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_121, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_123, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_125, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_127, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_129, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_131, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_133, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_135, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_137, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_139, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_141, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_143, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_145, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_147, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_149, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_151, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_153, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_154, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_155, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_166, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_167) __attribute__((noinline));
extern const char adamic_declaration_b9db91599647c65dcec475aafaecf575650a466ff7090d860c717a5d7cedffee;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_405cd4b738fe4de30f6e057528c5a3c1(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_97, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_99, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_101, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_103, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_105, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_107, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_109, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_111, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_113, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_115, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_117, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_119, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_121, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_123, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_125) __attribute__((noinline));
extern const char adamic_declaration_838110b85d6774e70f13974f3a6b6c0d4f06173cea2e8bd618aecf1d9333d688;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_599bc015b550075743e013c6b7293e44(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_64, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_65, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_67, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_69, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_71, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_73, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_75, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_77, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_79, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_81, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_83, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_85, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_87, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_89, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_91, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_93, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_95) __attribute__((noinline));
extern const char adamic_declaration_68e03fbdc42126975d157f513343eef3a0b38246cee357a2c4e010df4cf370e3;
void adamic_unit_adamic_initialize_chunk____widthTables_ts_f48d2cddb7e400a4014dd08791535dcf(adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_3, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_5, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_7, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_9, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_11, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_13, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_15, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_17, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_19, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_21, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_23, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_25, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_27, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_29, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_31, adamic_array * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_32, adamic_object * *adamic_temporary_module____widthTables_ts_9a9983a619e7fdf13ddd9ca4f1c25ab8_33) __attribute__((noinline));
extern const char adamic_declaration_7e55abbc7cc9e9443278bccefba2c96098c9e70ee520098221c20cf9a7b9450a;
adamic_array * adamic_unit_adamic_global_146498800715071756000196259950243577147_wideRanges = ((void*)0);
_Bool adamic_unit_adamic_global_146498800715071756000196259950243577147_wideRanges_ready = 0;
double adamic_unit_adamic_global_151792679279893729093594970742013293681_emojiStart = 0.0;
_Bool adamic_unit_adamic_global_151792679279893729093594970742013293681_emojiStart_ready = 0;
adamic_array * adamic_unit_adamic_global_192968371799965522085944136479175289966_emojiInstructions = ((void*)0);
_Bool adamic_unit_adamic_global_192968371799965522085944136479175289966_emojiInstructions_ready = 0;
adamic_array * adamic_unit_adamic_global_264060708524107954702806568172740178404_narrowInstructions = ((void*)0);
_Bool adamic_unit_adamic_global_264060708524107954702806568172740178404_narrowInstructions_ready = 0;
double adamic_unit_adamic_global_42037442971506454171932365986042096182_narrowStart = 0.0;
_Bool adamic_unit_adamic_global_42037442971506454171932365986042096182_narrowStart_ready = 0;
adamic_array * adamic_unit_adamic_global_52901113597631254951881550976868039379_emojiStarts = ((void*)0);
_Bool adamic_unit_adamic_global_52901113597631254951881550976868039379_emojiStarts_ready = 0;
void adamic_unit_adamic_initialize____widthTables_ts_68aa0e134d4cd9e872b91b14f358f21a(void) {
 adamic_array * adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[5];
 adamic_object * adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[77];
 adamic_unit_adamic_initialize_chunk____widthTables_ts_f48d2cddb7e400a4014dd08791535dcf(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[1], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[2], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[3], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[4], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[5], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[6], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[7], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[8], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[9], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[10], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[11], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[12], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[13], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[1], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[14]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_1df513d8e9d185750c5a6568e305dcbb(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[1], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[14], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[15], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[16], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[17], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[18], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[19], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[20], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[21], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[22], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[23], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[24], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[25], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[26], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[27], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[28], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[29], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[2], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[30]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_599bc015b550075743e013c6b7293e44(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[2], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[30], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[31], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[32], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[33], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[34], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[35], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[36], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[37], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[38], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[39], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[40], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[41], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[42], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[43], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[44], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[45]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_405cd4b738fe4de30f6e057528c5a3c1(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[46], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[47], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[48], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[49], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[50], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[51], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[52], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[53], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[54], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[55], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[56], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[57], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[58], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[59], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[60]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_291663ce58cd939f739c0155c588563b(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[61], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[62], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[63], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[64], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[65], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[66], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[67], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[68], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[69], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[70], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[71], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[72], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[73], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[74], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[3], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[75]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_32986e3d92afc378735cfbfcde934312(&adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[0], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[1], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[2], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[3], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[4], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[5], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[6], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[7], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[8], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[9], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[10], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[11], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[12], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[13], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[14], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[15], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[16], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[17], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[18], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[19], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[20], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[21], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[22], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[23], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[24], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[25], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[26], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[27], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[28], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[29], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[30], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[31], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[32], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[33], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[34], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[35], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[36], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[37], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[38], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[39], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[40], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[41], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[42], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[43], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[44], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[45], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[46], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[47], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[48], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[49], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[50], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[51], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[52], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[53], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[54], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[55], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[56], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[57], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[58], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[59], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[60], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[61], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[62], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[63], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[64], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[65], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[66], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[67], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[68], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[69], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[70], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[71], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[72], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[73], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[74], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[3], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[75], &adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[76], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[4]);
 adamic_unit_adamic_initialize_chunk____widthTables_ts_02a029e6b1a51e862b2e2c886e8f7827(&adamic_init_storage_adamic_object___3153f054208511f1cfd8035244613e3c[76], &adamic_init_storage_adamic_array___b76b76654963a12de628c2e9e6f5c7f8[4]);
}
const char adamic_declaration_6a8d18b3e4ac1544fd0fc384989fbfd53a7ceb3bf4038c6220a03ac6ecae9783 = 0;
const char adamic_declaration_17180fda0b6c0bab50b67b80adfb9441e0d911a8d842b0e957130b1c6053449d = 0;
const char adamic_declaration_5ea6ac41594cb1e3ee9b54729bda76865f9e1c6f151e97679171b8c7b9c8b140 = 0;
const char adamic_declaration_017d2416b5c19577836076b716fbeaa06018720d16677f6770878a9a873f5749 = 0;
const char adamic_declaration_8d95de5c43ef1aef3a9a60d054aabc216d27116c27b72c131394c326c5dea252 = 0;
const char adamic_declaration_7ffac9a6aa0cdf3ad7092897fcdd4b75c7730e87001a2a13a4ee1530d3670262 = 0;
const char adamic_declaration_d442969f28f0b889617b26213f7bfdacacd149b808bb850696d84c3552e60427 = 0;
const char adamic_declaration_df182c3d6fba6a632218535e1b90b0d5f5d6c1b19b4ffba3f9a4a160942bdd57 = 0;
const char adamic_declaration_2bd90f78e3a8e67a8203f798580be6b22ddabda16d5840500f13164f74179b24 = 0;
const char adamic_declaration_7671e265e6012a3892bdb0775dcbe2ad8f0e0ed3f4d9ac06ae87fdbbf3e27b06 = 0;
const char adamic_declaration_6e6fa3e2c4ec2654bda25513d24d92ba4a3cbf948582c3a56e1630f1df75da0c = 0;
const char adamic_declaration_0717cc6b6f07c1ea1a0f872bc45c513b3d87044dd8232b25074ad4e29bcabc21 = 0;
const char adamic_declaration_079beee0520fc440fd224b3f027b392b3c30cbc26a9dab21e60676e6f253e971 = 0;
const char *const adamic_abi_references_9b7900977a77ea44e77769291921ce8d[] = {
0,
&adamic_declaration_6a8d18b3e4ac1544fd0fc384989fbfd53a7ceb3bf4038c6220a03ac6ecae9783,
&adamic_declaration_17180fda0b6c0bab50b67b80adfb9441e0d911a8d842b0e957130b1c6053449d,
&adamic_declaration_5ea6ac41594cb1e3ee9b54729bda76865f9e1c6f151e97679171b8c7b9c8b140,
&adamic_declaration_017d2416b5c19577836076b716fbeaa06018720d16677f6770878a9a873f5749,
&adamic_declaration_8d95de5c43ef1aef3a9a60d054aabc216d27116c27b72c131394c326c5dea252,
&adamic_declaration_7ffac9a6aa0cdf3ad7092897fcdd4b75c7730e87001a2a13a4ee1530d3670262,
&adamic_declaration_d442969f28f0b889617b26213f7bfdacacd149b808bb850696d84c3552e60427,
&adamic_declaration_df182c3d6fba6a632218535e1b90b0d5f5d6c1b19b4ffba3f9a4a160942bdd57,
&adamic_declaration_2bd90f78e3a8e67a8203f798580be6b22ddabda16d5840500f13164f74179b24,
&adamic_declaration_7671e265e6012a3892bdb0775dcbe2ad8f0e0ed3f4d9ac06ae87fdbbf3e27b06,
&adamic_declaration_6e6fa3e2c4ec2654bda25513d24d92ba4a3cbf948582c3a56e1630f1df75da0c,
&adamic_declaration_0717cc6b6f07c1ea1a0f872bc45c513b3d87044dd8232b25074ad4e29bcabc21,
&adamic_declaration_079beee0520fc440fd224b3f027b392b3c30cbc26a9dab21e60676e6f253e971,
&adamic_declaration_32f91cc635cbb606aa57e3bc9a3965891fda9f580266824df46004b6a5eef251,
&adamic_declaration_486eb31c34e5e3548551d868ee499a316ebee39f4581aed5804da1990b5688e8,
&adamic_declaration_c009395f1805c47ec552401c68e3e99dc96ea9867fb9a7478f8b99ee92bd0f8a,
&adamic_declaration_b9db91599647c65dcec475aafaecf575650a466ff7090d860c717a5d7cedffee,
&adamic_declaration_838110b85d6774e70f13974f3a6b6c0d4f06173cea2e8bd618aecf1d9333d688,
&adamic_declaration_68e03fbdc42126975d157f513343eef3a0b38246cee357a2c4e010df4cf370e3,
&adamic_declaration_7e55abbc7cc9e9443278bccefba2c96098c9e70ee520098221c20cf9a7b9450a,
};
