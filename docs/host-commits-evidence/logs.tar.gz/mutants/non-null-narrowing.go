package lower

import (
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/microsoft/TypeScript/tsc/shim/scanner"
	"github.com/system-inc/adamic/internal/ir"
	"strings"
)

// nonNull uses the same nullish test and terminal panic as ?? panic(...).
// Recover presence checks from nullable loads, but keep a checked union narrowing
// in its result representation. Calls may invalidate the original narrowing.
func (l *lowering) nonNull(node *ast.Node) (ir.Expression, error) {
	operand := node.AsNonNullExpression().Expression
	value, err := l.expression(operand)
	if err != nil {
		return nil, err
	}
	return l.nonNullValue(node, value)
}

// nonNullValue also checks an already-held assignment target read.
func (l *lowering) nonNullValue(node *ast.Node, value ir.Expression) (ir.Expression, error) {
	operand := node.AsNonNullExpression().Expression
	var err error
	for {
		switch narrowed := value.(type) {
		case ir.Unwrap:
			value = narrowed.Value
		case ir.Defined:
			value = narrowed.Value
		default:
			// Mutant restores the old look-through of representation-changing narrowing.
			if call, ok := value.(ir.Call); ok && call.Returns == ir.Number && len(call.Arguments) == 1 && call.Arguments[0].Type() == ir.Union { value = call.Arguments[0] }
			goto stored
		}
	}
stored:
	weakOperand := false
	if target, ok := value.(ir.WeakTarget); ok {
		// A narrowed Weak may have cleared since the narrowing. This assertion owns
		// the terminal check and its diagnostic, rather than the generic Weak load.
		target.Present = false
		value, weakOperand = target, true
	}
	if property, ok := value.(ir.Property); ok && ast.SkipParentheses(operand).Kind == ast.KindPropertyAccessExpression {
		if symbol := l.checker.GetSymbolAtLocation(ast.SkipParentheses(operand).Name()); symbol != nil {
			if declared, known := l.representation(l.checker.GetTypeOfSymbol(symbol)); known {
				property.Of = declared
				value = property
			}
		}
	}
	of, err := l.typeOf(node)
	flags := l.checker.GetTypeAtLocation(operand).Flags()
	if err != nil && (flags == checker.TypeFlagsUndefined || flags == checker.TypeFlagsNull) {
		of = ir.Object
		if contextual := l.checker.GetContextualType(node, checker.ContextFlagsNone); contextual != nil {
			if representation, known := l.representation(contextual); known {
				of = representation
			}
		}
		if of.IsMaybe() {
			of = of.Present()
		}
		if of == ir.Weak {
			of = ir.Object
		}
		if of == ir.Number || of == ir.Boolean {
			value = ir.MaybeOf{Of: ir.Maybe(of)}
		} else {
			value = ir.Undefined{Of: of}
		}
		err = nil
	}
	if err != nil {
		return nil, err
	}
	// A checked narrowing helper can already return a plain scalar. Its result
	// has no nullish representation and must never receive a pointer test.
	if value.Type() == ir.Number || value.Type() == ir.Boolean {
		l.recordNonNullCheck(node, true)
		return value, nil
	}
	proven := l.checker.GetTypeAtLocation(operand)
	if !weakOperand && !l.includesUndefined(proven) && !l.includesNull(proven) && !l.narrowedAway(ast.SkipParentheses(operand)) && !value.Type().IsMaybe() {
		if value.Type() == ir.Union && of != ir.Union {
			l.recordNonNullCheck(node, true)
			return ir.Narrow{Value: value, To: of}, nil
		}
		l.recordNonNullCheck(node, true)
		return value, nil
	}
	file := ast.GetSourceFileOfNode(node)
	text := file.Text()[scanner.GetTokenPosOfNode(node, file, false):node.End()]
	message := ir.StringConstant{Index: l.constant("non-null assertion failed at " + l.program.Where(node) + ": " + text + " is null or undefined")}
	result := ir.Expression(ir.Coalesce{Value: value, Panic: message, Of: value.Type().Present()})
	if result.Type() == ir.Union && of != ir.Union {
		result = ir.Narrow{Value: result, To: of}
	}
	l.recordNonNullCheck(node, false)
	return result, nil
}

func (l *lowering) checkedAssertionSource(node *ast.Node) bool {
	return strings.HasSuffix(l.program.FileName(ast.GetSourceFileOfNode(node)), ".ts")
}

func (l *lowering) recordNonNullCheck(node *ast.Node, proven bool) {
	counts := &l.result.NonNullChecks
	if proven {
		counts.Proven++
	} else {
		counts.Checked++
	}
	counts.Sites = append(counts.Sites, ir.NonNullCheck{Where: l.program.Where(node), Expression: sourceExpression(node), Proven: proven})
}
