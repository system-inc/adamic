from pathlib import Path
import json,subprocess,os
root=Path('/workspace/adamic'); out=Path('/tmp/host-commits/stack-mutants'); results=[]
for case in json.loads((out/'cases.json').read_text()):
 command=['go','test','-overlay='+case['overlay'],*case['packages'],'-run',case['pattern'],'-count=1','-timeout','5m','-v']
 with (out/(case['topic']+'.log')).open('w') as log: code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 text=(out/(case['topic']+'.log')).read_text(); caught=code!=0 and '--- FAIL:' in text and '[build failed]' not in text
 results.append({**case,'command':command,'exit':code,'caught':caught})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n'); print(case['topic'],code,'caught',caught,flush=True)
 if not caught: raise SystemExit(1)
