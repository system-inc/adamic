import hashlib,io,json,os,pathlib,subprocess,tarfile
P=pathlib.Path('/workspace/scratch/adapt30-evidence'); R=pathlib.Path('/workspace/scratch/adapt30-current'); E=pathlib.Path('/workspace/scratch/adapt30-evidence-branch/evidence/adapt30-drop-require')
def read(p):return json.loads(pathlib.Path(p).read_text())
code=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip();parent=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD^'],text=True).strip()
whole=read('/workspace/scratch/adapt30-lane-whole/report.json');bundle=read(P/'bundle-comparison.json');byte=read(P/'current-byte-proof.json');source=read(P/'final-source-audit.json');stock=read(P/'stock-tsc.json');checks=read(P/'checkers.json')
assert whole['status']=='pass' and not bundle['changedRoots'];assert all(r['childExit']==0 for r in stock)
assert 'declined site changed: core.ts:992:21' in (P/'check-main-composed-tree.log').read_text()
assert 'declined site changed: core.ts:992:21' in (P/'in-place-full-replay.log').read_text()
selected={}
for folder in ['adapt30-lane-shards','adapt30-shards-project','adapt30-shards-file0']:
 root=pathlib.Path('/workspace/scratch')/folder
 for line in (root/'ledger.jsonl').read_text().splitlines():
  row=json.loads(line)
  if folder=='adapt30-lane-shards' and row['name'].startswith('stage3-lane-file-'):continue
  assert row['exit']==0 and row['status']=='pass' and row['seconds']<30
  selected[row['name']]=(root/row['name'],row)
files=subprocess.check_output(['git','-C',str(R),'diff','--name-only','HEAD^','HEAD'],text=True).splitlines()
report=dict(status='stopped',reason='Actual in-place full replay exits 1 at inherited declined site core.ts:992:21; untouched main check reproduces it. No addRange amendment made. Full shard proof and merge not completed.',codeCommit=code,parent=parent,sourceFilesChanged=files,internalUntouched=True,artifact=read('/workspace/scratch/adapt30-lane-whole/execution.json')['artifact'],checks=[
 dict(check='full apply: untouched main, candidate, final artifact, cache replay',exits=[0,0,0,0]),dict(check='30-after snapshot replay',exit=0,edits=0),dict(check='30-after check, require mutant, restored check',childExits=[0,1,0],wrapperExit=0),
 dict(check='stock tsc 6.0.3 before/after',exits=[r['childExit'] for r in stock],roots=79,diagnostics=[0,0]),dict(check='adamic types before/after',exits=[r['childExit'] for r in checks if r['check']=='adamic-types'],roots=79,diagnostics=[0,0]),dict(check='emitted JS',exit=0,adaptedTsFiles=byte['adaptedTsFiles'],emittingTsFiles=sum(not r.get('declaration',False) for r in byte['rows']),modules=['ESNext','CommonJS'],byteIdentical=True),
 dict(check='cached replay source identity; exact process preservation; no require; untouched internal',exit=0),dict(check='sanctioned API regeneration/compare; shard plan/manifest regeneration',exits=[0,0,0]),dict(check='lane preparation',exit=0),dict(check='whole lane',exit=0,counts=whole['counts'],oracleChildExit=1,seconds=read('/workspace/scratch/adapt30-lane-whole/execution.json')['wall_seconds']),
 dict(check='bundle censuses and comparison',wrapperExits=[0,0,0],roots=79,childExits=bundle['childExits'],changedRoots=[],processFirstStops=bundle['processFirstStops'],processLocation=bundle['processLocation']),
 dict(check='final composed 30 check; unchanged-main control; actual in-place full replay',exits=[1,1,1],message='declined site changed: core.ts:992:21'),dict(check='project-reference shard batch',exit=0,units=24),dict(check='shard collectors stopped',exits=[143,143],reason='bounded-batch reschedule, then reproduced replay blocker'),dict(check='completed unique shard units',completed=len(selected),total=398,childExits=[0],maximumSeconds=max(r['seconds'] for _,r in selected.values()),merge='not run'),dict(check='git diff --check; push dry-run',exits=[0,0])],
 priorAttempts=[dict(check='initial snapshot hash assertion',pythonExit=1,shellExit=0,reason='stored hashes use CRLF, not LF; corrected amendment exit 0'),dict(check='stock without host typings',exit=1,reason='corrected with locked Node typings'),dict(check='literal tsc before ignoreConfig',exits=[1,1],reason='TS5112; corrected CLI exits 0 on both trees'),dict(check='VCS-stamped worktree build',exit=1,reason='linked submodule; -buildvcs=false exact-source build exits 0'),dict(check='duplicate fetch',exit=124,reason='original fetch completed 0'),dict(check='superseded old-main census collector',exit=143,reason='replaced by complete refreshed-main censuses')],completedShards=[r for _,r in sorted(selected.values(),key=lambda x:x[1]['name'])])
E.mkdir(parents=True,exist_ok=True);(E/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
manifest=[]
with tarfile.open(E/'proofs.tar.gz','w:gz') as tar:
 def add(p,name):
  if not p.is_file():return
  assert not name.endswith('.go'),'Go evidence must use .go.txt'
  data=p.read_bytes();manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 for p in sorted(P.rglob('*')):
  if p.is_file():add(p,'proofs/'+str(p.relative_to(P)))
 def results(root,prefix):
  for directory,dirs,names in os.walk(root,followlinks=False):
   dirs[:]=[d for d in dirs if d not in ['adapted-tree','caches','__pycache__']]
   for name in sorted(names):
    p=pathlib.Path(directory)/name
    if p.is_file() and not p.is_symlink():add(p,prefix+'/'+str(p.relative_to(root)))
 results(pathlib.Path('/workspace/scratch/adapt30-lane-whole'),'lane/whole')
 for name,(root,row) in sorted(selected.items()):results(root,'lane/completed-shards/'+name)
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
print(json.dumps(dict(files=len(manifest),archiveBytes=(E/'proofs.tar.gz').stat().st_size,completedShards=len(selected),codeCommit=code)))
