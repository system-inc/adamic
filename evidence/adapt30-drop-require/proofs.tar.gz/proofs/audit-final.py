import hashlib,json,pathlib,re,subprocess,sys
repo,before,after,replay,artifact=sys.argv[1:]
ref='refs/stage3/99-wasm-crypto-import-after'
def git(tree,*args):return subprocess.check_output(['git','-C',tree,*args],text=True).strip()
trees={name:git(tree,'rev-parse',ref) for name,tree in [('candidate',after),('replay',replay),('artifact',artifact)]}
assert len(set(trees.values()))==1,trees
old=(pathlib.Path(before)/'src/compiler/core.ts').read_bytes();new=(pathlib.Path(after)/'src/compiler/core.ts').read_bytes()
assert old.replace(b' declare const require: unknown;',b'')==new
assert len(re.findall(rb'\bdeclare\s+const\s+require\b',old))==1
assert not re.search(rb'\bdeclare\s+const\s+require\b',new)
process=b'declare const process: { nextTick?: unknown; browser?: unknown; } | undefined;'
assert old.count(process)==new.count(process)==1
assert not git(repo,'diff','HEAD^','HEAD','--','internal/')
print(json.dumps(dict(snapshotTrees=trees,fullReplaySourceEdits=0,artifactSourceIdentical=True,coreBeforeSha256=hashlib.sha256(old).hexdigest(),coreAfterSha256=hashlib.sha256(new).hexdigest(),onlyRequireRemoved=True,processDeclarationByteIdentical=True,noAmbientRequire=True,internalUntouched=True),indent=2))
