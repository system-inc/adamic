'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const crypto = require('node:crypto'), ts = require(process.env.CENSUS_TYPESCRIPT || 'typescript');
const [before, after] = process.argv.slice(2);
assert.equal(ts.version, '6.0.3');
const changed = tree => execFileSync('git', ['-C', tree, 'diff', '--name-only', 'HEAD', 'refs/stage3/99-wasm-crypto-import-after', '--', '*.ts'], {encoding:'utf8'}).trim().split('\n').filter(Boolean);
const names = [...new Set([...changed(before), ...changed(after)])].sort();
const rows = [], differences = [];
for (const name of names) {
 const a = fs.readFileSync(path.join(before,name),'utf8'), b = fs.readFileSync(path.join(after,name),'utf8');
 if (a !== b) differences.push(name);
 if (name.endsWith('.d.ts')) { assert.equal(a,b); rows.push({name,declaration:true}); continue; }
 const variants = [];
 for (const module of [ts.ModuleKind.ESNext, ts.ModuleKind.CommonJS]) {
  const options = {fileName:name, compilerOptions:{target:ts.ScriptTarget.ES2024,module}};
  const x = ts.transpileModule(a,options).outputText, y = ts.transpileModule(b,options).outputText;
  assert.equal(x,y, name+' emitted bytes differ');
  variants.push({module:ts.ModuleKind[module], bytes:Buffer.byteLength(x),sha256:crypto.createHash('sha256').update(x).digest('hex')});
 }
 rows.push({name,variants});
}
assert.deepEqual(differences,['src/compiler/core.ts']);
const a=fs.readFileSync(path.join(before,differences[0]),'utf8'),b=fs.readFileSync(path.join(after,differences[0]),'utf8');
assert.equal(a.replace(' declare const require: unknown;',''),b);
console.log(JSON.stringify({typescript:ts.version,adaptedTsFiles:names.length,sourceDifferences:differences,byteIdentical:true,rows},null,2));
