import json,pathlib,sys
before,after=sys.argv[1:]
a=json.loads((pathlib.Path(before)/'report.json').read_text());b=json.loads((pathlib.Path(after)/'report.json').read_text())
assert a['roots']==b['roots']==79
assert [r['root'] for r in a['rows']]==[r['root'] for r in b['rows']]
def outcome(r):return r['childExit'],[s.replace('/workspace/scratch/adapt30-main-tree','TREE').replace('/workspace/scratch/adapt30-current-tree','TREE') for s in r['firstStop']]
changes=[dict(root=x['root'],before=outcome(x),after=outcome(y)) for x,y in zip(a['rows'],b['rows']) if outcome(x)!=outcome(y)]
assert not changes,changes
process=[r['root'] for r in b['rows'] if any('core.ts:2599:15:' in s and 'host binding process' in s for s in r['firstStop'])]
others=[r for r in b['rows'] if r['root'] not in process]
print(json.dumps(dict(roots=79,moduleFormat='commonjs-bundle',changedRoots=changes,processFirstStops=len(process),processLocation='core.ts:2599:15',otherOutcomes=others,childExits=sorted(set(r['childExit'] for r in b['rows'])),maxChildSeconds=max(r['seconds'] for r in a['rows']+b['rows'])),indent=2))
