import json,os,pathlib,subprocess,time
out=pathlib.Path('/workspace/scratch/adapt30-evidence'); repo=pathlib.Path('/workspace/scratch/adapt30-current')
rows=[]
for label,tree in [('before','/workspace/scratch/adapt30-main-tree'),('after','/workspace/scratch/adapt30-current-tree')]:
 roots=sorted((pathlib.Path(tree)/'src/compiler').rglob('*.ts'));assert len(roots)==79
 commands=[('stock-api',['node',str(out/'stock-types.cjs'),tree]),('stock-tsc',['node',str(repo/'stage3/api/node_modules/typescript/lib/tsc.js'),'--strict','--noUncheckedIndexedAccess','--exactOptionalPropertyTypes','--verbatimModuleSyntax','--allowImportingTsExtensions','--noEmit','--module','esnext','--moduleDetection','force','--moduleResolution','bundler','--target','es2024','--lib','es2024','--types','node','--typeRoots',str(repo/'stage3/api/node_modules/@types'),*map(str,roots)]),('adamic-types',['/workspace/scratch/adapt30-current-adamic','types',*map(str,roots)])]
 for name,command in commands:
  start=time.monotonic()
  with (out/(label+'-'+name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1790)
  row=dict(tree=label,check=name,roots=len(roots),childExit=r.returncode,seconds=time.monotonic()-start,command=command)
  rows.append(row);print(json.dumps(row),flush=True)
(out/'checkers.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(any(x['childExit'] for x in rows)))
