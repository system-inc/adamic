import json,pathlib,subprocess,sys,time
binary,tree,out=sys.argv[1:]
out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=False)
roots=sorted((pathlib.Path(tree)/'src/compiler').rglob('*.ts'))
assert len(roots)==79
rows=[]
for root in roots:
 start=time.monotonic()
 result=subprocess.run([binary,'c',str(root),'--module-format','commonjs-bundle'],capture_output=True,text=True,timeout=1790)
 name=str(root.relative_to(pathlib.Path(tree)/'src/compiler'))
 (out/(name.replace('/','_')+'.log')).write_text(result.stdout+result.stderr)
 row=dict(root=name,childExit=result.returncode,seconds=time.monotonic()-start,firstStop=(result.stderr or result.stdout).splitlines()[:6])
 rows.append(row)
 print(json.dumps(row),flush=True)
(out/'report.json').write_text(json.dumps(dict(roots=len(roots),moduleFormat='commonjs-bundle',rows=rows),indent=2)+'\n')
print(json.dumps(dict(wrapperExit=0,childExits=sorted(set(r['childExit'] for r in rows)))))
