Function.prototype['p'] = 0
export {};
