function foo() {} const o = {foo};
export {};
