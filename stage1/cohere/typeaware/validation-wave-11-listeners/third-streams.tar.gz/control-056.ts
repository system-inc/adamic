window.noeval('foo')
export {};
