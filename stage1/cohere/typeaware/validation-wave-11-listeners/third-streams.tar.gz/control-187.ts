function foo() {} [...foo] = [0];
export {};
