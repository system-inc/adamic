var foo = () => { foo = 1; };
export {};
