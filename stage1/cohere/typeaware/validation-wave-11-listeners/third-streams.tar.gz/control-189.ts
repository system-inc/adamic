function foo() {} ({foo} = {});
export {};
