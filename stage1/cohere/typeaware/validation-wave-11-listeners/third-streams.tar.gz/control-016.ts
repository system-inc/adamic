function foo(){}[foo]=[];[...foo]=[];[[...foo]]=[];({foo}={});({x:foo=0}={});({...foo}={});({x:{...foo}}={});[...(foo)]=[];({... (foo)}={});
export {};
