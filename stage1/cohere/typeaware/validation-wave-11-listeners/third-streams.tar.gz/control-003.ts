global.window.eval('x');window.global.eval('x');other.window.eval('x');this.eval('x');class C{eval(){}method(){this.eval()}}const window={eval:(x:string)=>x};window.eval('x');
export {};
