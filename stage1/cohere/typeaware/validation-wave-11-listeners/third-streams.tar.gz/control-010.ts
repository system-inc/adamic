Object[`prototype`]['p']=1;Object[('prototype')].p=1;(Object)['prototype'].p=1;Object['defineProperty'](Array.prototype);Object[`defineProperties`](Array.prototype);
export {};
