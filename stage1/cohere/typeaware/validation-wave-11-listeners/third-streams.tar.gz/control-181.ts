function foo() {} foo = 0; foo = 1;
export {};
