function foo(foo) { foo = bar; }
export {};
