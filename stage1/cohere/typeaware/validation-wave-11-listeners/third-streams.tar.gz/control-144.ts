Object.prototype.p.q = 0
export {};
