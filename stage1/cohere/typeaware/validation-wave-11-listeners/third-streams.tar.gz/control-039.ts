global.global[`eval`]('foo')
export {};
