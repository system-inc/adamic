parseFloat.prototype.x = 1
export {};
