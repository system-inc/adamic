function foo() {} ({b: {c: foo}} = {b: {}});
export {};
