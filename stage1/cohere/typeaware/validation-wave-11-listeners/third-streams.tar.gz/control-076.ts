class A { static field = () => this.eval(); }
export {};
