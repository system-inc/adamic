function \u0066oo(){}foo=1;function f(){function f(){}f=1}declare const other:unknown;eval(other);
export {};
