let a = function hello() { hello = 123;};
export {};
