x.prototype['p'] = 0
export {};
