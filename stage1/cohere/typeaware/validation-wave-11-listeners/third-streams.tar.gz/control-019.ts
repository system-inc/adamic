function foo(){}function foo(x:number):void;foo=1;function foo(){var foo=1;foo=2}
export {};
