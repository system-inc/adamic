function f(){const Object={prototype:{},defineProperty(...args:unknown[]){}};Object.prototype.p=1;Object.defineProperty(Array.prototype)}{let Array={prototype:{}};Array.prototype.p=1}const own=Object;own.prototype.p=1;globalThis.Object.prototype.p=1;
export {};
