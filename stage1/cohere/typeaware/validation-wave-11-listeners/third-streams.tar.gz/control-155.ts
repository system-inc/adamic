JSON.defineProperties(Array.prototype, {})
export {};
