globalThis.globalThis['eval']('foo')
export {};
