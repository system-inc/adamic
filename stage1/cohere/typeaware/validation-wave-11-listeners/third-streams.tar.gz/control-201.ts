function foo() {} foo();
export {};
