Object.defineProperties()
export {};
