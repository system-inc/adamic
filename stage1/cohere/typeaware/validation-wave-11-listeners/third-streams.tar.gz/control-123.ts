Object.defineProperty(x, 'p', {value: 0})
export {};
