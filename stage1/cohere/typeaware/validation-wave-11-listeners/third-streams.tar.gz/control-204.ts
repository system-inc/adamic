function foo() {} if (foo === 0) {}
export {};
