function foo() { var eval = 'foo'; window[eval]('foo') }
export {};
