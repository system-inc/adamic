WeakRef.prototype.p = 0
export {};
