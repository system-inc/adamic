(eval as any)('foo')
export {};
