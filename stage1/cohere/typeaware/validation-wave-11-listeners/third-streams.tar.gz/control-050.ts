(window?.window).eval('foo')
export {};
