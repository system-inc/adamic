Array.prototype.p ??= 0
export {};
