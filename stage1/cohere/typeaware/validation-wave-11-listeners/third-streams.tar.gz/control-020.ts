/* 世界 🌍 */
function é(){}
é=1;
window['eval']('x');
Object.prototype.p=0;

export {};
