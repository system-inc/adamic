interface I{eval():void};type T=typeof eval;declare const other:{eval:unknown};other.eval;({eval:0});declare const box:{[eval]:number};
export {};
