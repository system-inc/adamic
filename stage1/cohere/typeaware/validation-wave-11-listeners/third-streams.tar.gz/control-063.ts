function foo() { 'use strict'; this.eval('foo'); }
export {};
