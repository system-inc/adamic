globalThis.noneval('foo')
export {};
