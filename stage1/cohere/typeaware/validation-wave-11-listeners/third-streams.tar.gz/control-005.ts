const evalValue=eval;function f(x=eval){}class C{x=eval;eval=1;method(){return eval}}const object={eval:eval};const short={eval};enum E{x=eval}
export {};
