eval('Object.prototype.toString = 0')
export {};
