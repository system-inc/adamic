function foo() {} for (const foo of []) {}
export {};
