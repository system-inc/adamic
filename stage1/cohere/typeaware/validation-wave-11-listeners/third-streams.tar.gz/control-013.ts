function foo(){}foo=1;foo+=1;foo++;--foo;foo&&=1;foo||=1;foo??=1;foo();foo.x=1;object.foo=1;
export {};
