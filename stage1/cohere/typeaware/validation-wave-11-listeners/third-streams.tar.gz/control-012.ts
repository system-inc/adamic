parseFloat.prototype.p=1;parseInt.prototype.p=1;undefined.prototype.p=1;globalThis.prototype.p=1;Foo.prototype.p=1;
export {};
