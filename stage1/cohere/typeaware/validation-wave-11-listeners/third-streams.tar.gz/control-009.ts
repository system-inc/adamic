Array.prototype.p&&=0;Array.prototype.p||=0;Array.prototype.p??=0;Array.prototype.p+=1;Array.prototype.p**=2;(Object?.prototype).p=0;Object?.defineProperty(Object.prototype);
export {};
