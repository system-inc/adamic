function foo() {} foo++;
export {};
