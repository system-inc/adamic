eval('x');eval(eval);eval?.(eval);eval!('x');(eval as any)('x');(eval satisfies Function)('x');(<any>eval)('x');(eval)('x');(0,eval)('x');const run=eval;eval.toString();
export {};
