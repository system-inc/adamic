delete Object.prototype.p
export {};
