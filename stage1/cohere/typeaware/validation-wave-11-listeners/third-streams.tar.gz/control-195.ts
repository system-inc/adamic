function foo() {} function bar() {} bar = 0;
export {};
