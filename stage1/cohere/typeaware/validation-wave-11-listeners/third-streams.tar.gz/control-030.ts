(0, eval)('foo')
export {};
