function foo(){}({files=foo}={});({[foo]:other}={});const arr=[...foo];foo(...foo);function f(){for(const foo of []){foo=1}}
export {};
