window.eval('foo')
export {};
