function foo() {} let b = !foo;
export {};
