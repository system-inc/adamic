window.setInterval('foo')
export {};
