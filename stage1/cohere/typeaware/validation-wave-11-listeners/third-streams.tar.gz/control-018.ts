function foo(){}for(foo of []){}for(foo in {}){}for([...foo] of []){}for({...foo} of []){}(foo)=1;(foo as unknown)=1;
export {};
