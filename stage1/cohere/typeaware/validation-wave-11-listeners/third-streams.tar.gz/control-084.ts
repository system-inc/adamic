Array.fromAsync(values, async function (value) { return this.eval(await value); }, context);
export {};
