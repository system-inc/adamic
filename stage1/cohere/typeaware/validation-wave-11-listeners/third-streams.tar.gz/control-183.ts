function foo() {} foo ||= 1;
export {};
