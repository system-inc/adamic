String['prototype'].p = 0
export {};
