function foo() { [foo] = bar; }
export {};
