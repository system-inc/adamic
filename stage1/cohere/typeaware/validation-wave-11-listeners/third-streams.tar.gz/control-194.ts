function foo() { const f = () => { foo = 1; }; }
export {};
