setInterval('foo')
export {};
