Object.toString.bind = 0
export {};
