export {}; this.eval('foo');
export {};
