declare const key:string;window[key]('x');window[`ev${key}al`]('x');window[eval]('x');window['\u0065val']('x');eval('x');
export {};
