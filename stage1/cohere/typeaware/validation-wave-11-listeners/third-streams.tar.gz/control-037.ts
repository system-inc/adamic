global.eval('foo')
export {};
