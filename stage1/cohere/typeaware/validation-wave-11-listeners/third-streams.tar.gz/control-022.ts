eval(foo)
export {};
