Object.prototype.p=0;Function.prototype['p']=0;String['prototype'].p=0;Number['prototype']['p']=0;Object.defineProperty(Array.prototype,'p',{value:0});Object.defineProperties(Array.prototype,{p:{value:0}});
export {};
