FinalizationRegistry.prototype.p = 0
export {};
