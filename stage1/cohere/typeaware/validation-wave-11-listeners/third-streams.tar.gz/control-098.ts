BigInt.prototype.p = 0
export {};
