function foo() {} for (foo of []) {}
export {};
