class A { static { this.eval(); } }
export {};
