o = Object; o.prototype.toString = 0
export {};
