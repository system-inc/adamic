(function(exe){ exe('foo') })(eval);
export {};
