var foo = function() { foo = bar; };
export {};
