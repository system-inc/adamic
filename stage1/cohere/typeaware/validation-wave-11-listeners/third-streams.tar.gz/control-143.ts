Object.prototype = 0
export {};
