(window?.eval)('foo')
export {};
