var EVAL = eval; EVAL('foo')
export {};
