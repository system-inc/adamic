obj.foo = (function() { return function() { this.eval('foo'); }; })()
export {};
