function foo() {} foo.x = 0;
export {};
