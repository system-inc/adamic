class A { static accessor field = () => this.eval(); }
export {};
