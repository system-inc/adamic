global.noeval('foo')
export {};
