function foo() {} for (foo in {}) {}
export {};
