function foo() {} ({...foo} = {});
export {};
