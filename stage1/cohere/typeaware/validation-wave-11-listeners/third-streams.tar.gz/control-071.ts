class A { foo() { this.eval(); } }
export {};
