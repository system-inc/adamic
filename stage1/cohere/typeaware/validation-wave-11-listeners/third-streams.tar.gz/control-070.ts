class C extends function () { this.eval('foo'); } {}
export {};
