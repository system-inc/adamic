Object.defineProperties(Array.prototype, {p: {value: 0}, q: {value: 0}})
export {};
