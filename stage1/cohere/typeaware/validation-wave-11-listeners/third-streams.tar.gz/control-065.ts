var obj = {}; obj.foo = function() { this.eval('foo'); }
export {};
