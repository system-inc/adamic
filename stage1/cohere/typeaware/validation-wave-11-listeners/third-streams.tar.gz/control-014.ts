foo=1;function foo(){}function f(){function g(){}g=1;}const named=function inner(){inner=1;};const anonymous=function(){anonymous=1};const arrow=()=>{};arrow=1;
export {};
