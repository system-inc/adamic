globalThis.eval('foo')
export {};
