function foo(eval) { eval('foo') }
export {};
