function foo() { Object.prototype.p = 0 }
export {};
