function foo() {} --foo;
export {};
