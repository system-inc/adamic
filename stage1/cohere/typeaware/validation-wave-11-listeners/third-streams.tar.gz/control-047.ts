var EVAL = globalThis.eval; EVAL('foo')
export {};
