Object[`prototype`].p = 0
export {};
