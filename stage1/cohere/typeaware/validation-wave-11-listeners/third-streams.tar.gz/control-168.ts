function foo() { var foo = bar; }
export {};
