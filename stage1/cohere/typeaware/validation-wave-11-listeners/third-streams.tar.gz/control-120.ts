Object.p = 0
export {};
