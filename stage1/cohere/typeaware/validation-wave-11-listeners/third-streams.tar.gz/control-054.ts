window.setTimeout('foo')
export {};
