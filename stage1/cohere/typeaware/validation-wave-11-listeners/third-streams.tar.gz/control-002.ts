window.eval('x');window.window.eval('x');window['eval']('x');global.global[`eval`]('x');globalThis.globalThis['eval']('x');(window?.window).eval('x');window[('eval')]('x');
export {};
