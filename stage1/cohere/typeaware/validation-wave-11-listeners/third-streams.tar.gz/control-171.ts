var foo = () => {}; foo = bar;
export {};
