Array.from(values, function (value) { return this.eval(value); }, context);
export {};
