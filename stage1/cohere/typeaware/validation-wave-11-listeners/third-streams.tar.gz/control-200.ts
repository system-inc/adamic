function foo() {} let b; b = foo;
export {};
