window?.eval('foo')
export {};
