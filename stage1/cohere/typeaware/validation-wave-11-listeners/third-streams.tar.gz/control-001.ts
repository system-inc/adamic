function f(eval:(x:string)=>unknown){eval('x');const v=eval;eval?.('x')}function g(){var eval=(x:string)=>x;const v=eval;}function h(){const v=eval;function eval(x:string){return x}}
export {};
