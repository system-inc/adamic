setTimeout('foo')
export {};
