Object.freeze(Array.prototype)
export {};
