(0, globalThis.eval)('foo')
export {};
