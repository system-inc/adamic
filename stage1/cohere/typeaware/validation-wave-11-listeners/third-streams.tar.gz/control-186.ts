function foo() { foo++; }
export {};
