Object.defineProperty()
export {};
