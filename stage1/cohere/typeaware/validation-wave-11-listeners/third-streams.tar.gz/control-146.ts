Object.defineProperty(x, Array.prototype)
export {};
