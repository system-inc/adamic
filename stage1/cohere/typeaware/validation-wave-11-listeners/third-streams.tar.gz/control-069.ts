(function f() { 'use strict'; () => { this.eval('foo') } })
export {};
