Foo.defineProperty(Array.prototype, "p", {value:0})
export {};
