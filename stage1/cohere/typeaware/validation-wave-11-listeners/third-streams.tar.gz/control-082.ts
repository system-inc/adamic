['1+1'].flatMap(function (str) { return this.eval(str); }, new Evaluator);
export {};
