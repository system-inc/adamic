Object.prototype.g = 0
export {};
