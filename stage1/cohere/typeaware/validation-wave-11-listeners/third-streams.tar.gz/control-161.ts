foo = bar; function foo() { };
export {};
