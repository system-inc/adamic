function foo(foo:unknown){foo=1}function other(){var other;other=1}function outer(){}{let outer;outer=1}{function outer(){}outer=1}
export {};
