Object.prototype.p instanceof Foo
export {};
