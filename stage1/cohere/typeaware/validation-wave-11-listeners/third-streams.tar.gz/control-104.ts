Number['prototype']['p'] = 0
export {};
