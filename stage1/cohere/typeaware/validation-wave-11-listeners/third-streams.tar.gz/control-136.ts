{ let Object = function() {}; Object.prototype.p = 0 }
export {};
