Object.prototype.p++
export {};
