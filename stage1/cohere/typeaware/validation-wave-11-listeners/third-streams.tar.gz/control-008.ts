Object.prototype.p++;delete Object.prototype.p;Object.prototype=0;Object.prototype.p.q=0;Object.freeze(Array.prototype);Object.defineProperty({},Array.prototype);Object.defineProperty();
export {};
