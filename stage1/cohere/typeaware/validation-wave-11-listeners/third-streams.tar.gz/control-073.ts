class A { field = this.eval(); }
export {};
