declare function format(x:string):string;declare function format(x:number):number;declare const v:string|number;const x=typeof v==='string'?format(v):format(v);
export {};
