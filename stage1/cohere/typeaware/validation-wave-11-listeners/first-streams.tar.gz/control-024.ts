/* 世界 🌍 */
declare const a:boolean;const 漢=a?42 /* first */:42;

export {};
