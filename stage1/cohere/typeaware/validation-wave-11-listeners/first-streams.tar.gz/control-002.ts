declare const s:string; const r=/x/; let one=/x/; var once=/x/; s.match(r);s.match(one);s.match(once); const pattern='a'+'b'; s.match(pattern);
export {};
