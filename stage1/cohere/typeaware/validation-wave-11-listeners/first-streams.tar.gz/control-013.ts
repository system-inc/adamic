declare const a:{[n:number]:string;length:1};declare const b:{[n:number]:string};declare const c:{length:number};for(const k in a){}for(const k in b){}for(const k in c){}
export {};
