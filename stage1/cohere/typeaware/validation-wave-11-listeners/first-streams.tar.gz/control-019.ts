declare const a:boolean;const x=a?([]):[ ];const y=a?'/* */':'/* */';const z=a?'a  b':'a b';const w=a?'x':"x";
export {};
