declare const s:string; declare const n:number; (`${s}`).match(/x/); (s+n).match(/x/); function generic<T extends string>(s:T){return s.match(/x/);}declare const branded:string & {brand:true};branded.match(/x/);
export {};
