declare const v:string|number;const x=typeof v==='string'?v+1:v+1;declare const a:boolean;declare const n:number;const y=a?n+1:n+1;
export {};
