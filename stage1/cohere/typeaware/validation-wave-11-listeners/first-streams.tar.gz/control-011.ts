for(const key in [1,2]){} for(const key of [1,2]){} for(const key in {x:1}){} for(const key in 'text'){}
export {};
