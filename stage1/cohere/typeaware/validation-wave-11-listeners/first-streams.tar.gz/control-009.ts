declare const s:string; let r=/x/; ({r}={r:/x/g});s.match(r); let a=/x/;[a]=[/x/g];s.match(a);
export {};
