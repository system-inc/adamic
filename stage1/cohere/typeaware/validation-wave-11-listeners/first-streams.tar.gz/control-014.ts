function f(){for(const k in arguments){}}declare const a:readonly number[];for(const k in a){}declare const b:{[n:number]:string;length:string};for(const k in b){}
export {};
