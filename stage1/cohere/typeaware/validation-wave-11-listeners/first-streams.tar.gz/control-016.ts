declare const a:boolean;declare const b:boolean;const x=a?'pro':'pro';const y=a?'pro':'std';const z=a?'x':b?'x':'x';const w=a?'y':b?'x':'x';
export {};
