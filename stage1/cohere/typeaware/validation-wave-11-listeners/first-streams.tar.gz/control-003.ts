declare const s:string; declare const t:string; const dynamic=new RegExp(`^${t}$`); s.match(dynamic); s.match(new RegExp(`^${t}$`)); const r=new RegExp('test','');s.match(r);
export {};
