declare const s:string; s.match('(?=x)x');s.match('(x)\\1');s.match('[^]');s.match('[]');s.match('[z-a]');s.match('[');s.match('a\\/b');s.match('a\n');
export {};
