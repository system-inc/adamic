declare const v:{type:'a';source:string}|{type:'b';source:string};const x=v.type==='a'?v.source:v.source;declare const a:boolean;const y=a?(true?1:2):(true?1:2);
export {};
