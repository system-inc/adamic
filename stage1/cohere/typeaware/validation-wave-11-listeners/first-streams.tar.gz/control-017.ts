declare const a:boolean;declare const b:boolean;declare function f():void;declare function g():void;if(a){f();}else f();if(a)f();else if(b)f();else f();if(a)g();else if(b)f();else f();
export {};
