declare const a:boolean;if(a){}else{} if(a){/* intent */}else{/* other */}if(a);else;function f(){if(a)return;else return;}
export {};
