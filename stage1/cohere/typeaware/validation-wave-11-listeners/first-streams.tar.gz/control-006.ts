declare const s:string; s.match(/x/) || null; !s.match(/x/); (s.match(/x/)) || null; s.match(/x/).length; s?.match(/x/); s.match?.(/x/);
export {};
