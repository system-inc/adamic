declare const s:string; s.match(new RegExp('x')); s.match(RegExp('x','i')); s.match(RegExp('x',undefined)); s.match(`x`);
export {};
