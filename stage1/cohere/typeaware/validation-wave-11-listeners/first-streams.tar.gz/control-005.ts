declare const s:string; let r=/x/; {let r=/x/;r=/x/g;} s.match(r); const p=/x/g; s.match(p); declare const flags:string;s.match(new RegExp('x',flags));
export {};
