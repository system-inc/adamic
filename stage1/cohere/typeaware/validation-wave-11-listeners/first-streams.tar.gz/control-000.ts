declare const s:string; s.match(/x/); s.match(/x/g); s.match('a/b'); s.match(''); s.match('[a-z'); s.match(/x/, 1); s['match'](/x/);
export {};
