declare const t:[number,string];for(const key in t){}declare const rows:string[]|null;for(const key in rows){}function f<T extends any[]>(x:T){for(const k in x){}}
export {};
