/* 世界 🌍 */
declare const rows:number[];for (const k in
 ((rows))
 /* before close */ )
 /* before body */ {}

export {};
