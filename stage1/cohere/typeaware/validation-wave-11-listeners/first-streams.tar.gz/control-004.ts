declare const s:string; let r=/x/;s.match(r);r=/x/g; let other=/x/; function nested(){other=/y/g;}s.match(other);
export {};
