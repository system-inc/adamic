declare function f(...args:[number]|[string,number]):void;declare const v:[number]|[string,number];const x=v.length===1?f(...v):f(...v);
export {};
