declare const s:'a'|'b';s.match(/x/);declare const o:{match:(r:RegExp)=>unknown};o.match(/x/);declare const a:RegExp|string;declare const b:string;a.match(b);
export {};
