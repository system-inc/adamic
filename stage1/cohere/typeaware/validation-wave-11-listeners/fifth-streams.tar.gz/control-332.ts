foo(function() { this; }.call(this));
export {};
