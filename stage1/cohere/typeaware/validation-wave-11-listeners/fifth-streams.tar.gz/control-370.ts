foo(function() { function inner() { arguments; } });
export {};
