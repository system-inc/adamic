qux(function( /* no params */ ) { })
export {};
