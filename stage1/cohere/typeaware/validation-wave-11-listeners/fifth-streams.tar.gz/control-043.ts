throw obj?.foo
export {};
