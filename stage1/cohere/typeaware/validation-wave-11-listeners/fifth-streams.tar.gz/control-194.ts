/((a)\2)/
export {};
