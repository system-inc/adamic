foo(function bar(a) { a; });
export {};
