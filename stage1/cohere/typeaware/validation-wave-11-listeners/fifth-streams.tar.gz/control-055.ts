throw foo &&= 'literal'
export {};
