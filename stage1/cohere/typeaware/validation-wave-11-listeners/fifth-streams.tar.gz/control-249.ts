foo;
new RegExp(
  '\\1(a)'
)
export {};
