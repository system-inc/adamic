new (function() {})();
export {};
