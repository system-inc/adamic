throw 'literal' && 'not an Error';
export {};
