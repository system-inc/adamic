RegExp('(a)\\1[')
export {};
