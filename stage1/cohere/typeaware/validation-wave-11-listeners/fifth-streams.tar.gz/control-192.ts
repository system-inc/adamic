RegExp('(a)\\1(?:b)')
export {};
