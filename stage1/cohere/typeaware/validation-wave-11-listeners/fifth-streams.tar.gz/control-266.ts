foo(function(arguments) { arguments; });
export {};
