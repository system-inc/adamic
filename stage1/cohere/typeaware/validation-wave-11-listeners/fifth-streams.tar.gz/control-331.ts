foo(function() { this; }.bind(obj));
export {};
