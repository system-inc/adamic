/* 世界 🌍 */
foo(function é(){return 1});
throw 'é';
const re=/\1(é)/;
export {};
