/(?=\1(a))./
export {};
