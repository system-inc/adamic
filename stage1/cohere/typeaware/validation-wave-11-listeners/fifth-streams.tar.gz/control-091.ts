RegExp('(a)\\2(b)')
export {};
