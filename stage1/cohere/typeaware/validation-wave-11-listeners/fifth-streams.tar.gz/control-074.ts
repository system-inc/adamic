/a(?<foo>\k<foo>)b/
export {};
