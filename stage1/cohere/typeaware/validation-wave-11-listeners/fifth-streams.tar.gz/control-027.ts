throw foo();
export {};
