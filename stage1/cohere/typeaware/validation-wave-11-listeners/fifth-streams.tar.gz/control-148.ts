/(?<=((?<foo>bar)|(?<foo>baz))\k<foo>)/
export {};
