foo(function bar() { const bar = 1; bar; });
export {};
