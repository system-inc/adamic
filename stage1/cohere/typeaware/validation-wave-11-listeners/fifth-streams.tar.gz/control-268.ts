foo(function() { (() => this); });
export {};
