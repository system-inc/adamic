throw foo ? 'not an Error' : 'literal';
export {};
