throw 1, 2, new Error();
export {};
