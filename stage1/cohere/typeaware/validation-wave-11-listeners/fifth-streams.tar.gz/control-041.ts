function* foo() { var index = 0; throw yield index++; }
export {};
