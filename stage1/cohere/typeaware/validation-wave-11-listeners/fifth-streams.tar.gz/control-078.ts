/a|(b\1c)/
export {};
