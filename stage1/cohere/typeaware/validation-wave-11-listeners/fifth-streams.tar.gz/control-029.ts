throw foo.bar;
export {};
