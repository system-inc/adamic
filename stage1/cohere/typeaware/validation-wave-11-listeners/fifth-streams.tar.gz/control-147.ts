/((?<foo>bar)|(?<foo>baz\k<foo>)|(?<foo>qux\k<foo>))/
export {};
