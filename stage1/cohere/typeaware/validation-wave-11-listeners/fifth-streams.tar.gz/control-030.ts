throw foo[bar];
export {};
