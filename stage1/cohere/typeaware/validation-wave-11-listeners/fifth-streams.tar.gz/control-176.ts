/^\1$/
export {};
