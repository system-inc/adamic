foo(function bar() { arguments; });
export {};
