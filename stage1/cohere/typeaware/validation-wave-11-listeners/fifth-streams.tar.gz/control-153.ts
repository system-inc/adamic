RegExp.foo('\\1(a)', 'u')
export {};
