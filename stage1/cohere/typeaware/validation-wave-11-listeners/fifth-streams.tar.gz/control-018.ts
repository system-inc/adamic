let root=globalThis;const {RegExp}=root;RegExp('\\1(a)');
export {};
