throw foo[bar] ??= 'literal'
export {};
