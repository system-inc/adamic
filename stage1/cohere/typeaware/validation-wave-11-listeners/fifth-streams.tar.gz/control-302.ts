foo(function(a:any) { a; });
export {};
