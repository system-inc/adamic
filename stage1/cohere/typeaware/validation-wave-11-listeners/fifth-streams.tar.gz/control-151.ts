regExp('\\1(a)')
export {};
