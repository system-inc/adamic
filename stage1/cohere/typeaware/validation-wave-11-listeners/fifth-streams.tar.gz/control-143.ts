/\k<foo>((?<foo>bar)|(?<foo>baz)|(?<foo>qux))/
export {};
