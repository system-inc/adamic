throw tag `${foo}`;
export {};
