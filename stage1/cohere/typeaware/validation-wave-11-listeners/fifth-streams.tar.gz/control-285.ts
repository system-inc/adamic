foo?.(function() {});
export {};
