foo(function(){this.x});foo(function(){this.x}.bind(this));foo((function(){this.x}).bind(this));foo((function(){}?.bind)(this));foo(function(){}.bind(this).bind(other));
export {};
