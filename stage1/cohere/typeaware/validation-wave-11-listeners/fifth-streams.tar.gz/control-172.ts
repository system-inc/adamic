RegExp('\1(a)')
export {};
