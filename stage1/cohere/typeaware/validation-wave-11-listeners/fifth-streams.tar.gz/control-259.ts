foo(bar ? function() {} : function() {});
export {};
