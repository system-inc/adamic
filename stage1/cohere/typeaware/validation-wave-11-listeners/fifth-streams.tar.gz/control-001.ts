const object={RegExp};RegExp('\\1(a)');const alias=RegExp;({alias}=other);alias('\\1(a)');
export {};
