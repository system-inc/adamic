var b = new Error(); throw 'a' + b;
export {};
