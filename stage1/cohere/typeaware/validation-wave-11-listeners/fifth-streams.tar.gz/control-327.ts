foo(function*() {});
export {};
