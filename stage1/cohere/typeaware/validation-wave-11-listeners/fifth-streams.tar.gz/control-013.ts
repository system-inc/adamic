foo(function(a,a){});foo(function(this:any){});foo(function*(){});foo(function(){new.target});foo(function(){()=>this});foo(async function(){});
export {};
