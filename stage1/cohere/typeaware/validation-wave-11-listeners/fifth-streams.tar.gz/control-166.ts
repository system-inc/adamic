new RegExp('\\n\\d(a)')
export {};
