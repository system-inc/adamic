new RegExp(`${prefix}\\1(a)`)
export {};
