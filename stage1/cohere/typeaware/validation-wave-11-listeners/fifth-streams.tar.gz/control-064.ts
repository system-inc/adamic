RegExp('(a|bc)|\\1')
export {};
