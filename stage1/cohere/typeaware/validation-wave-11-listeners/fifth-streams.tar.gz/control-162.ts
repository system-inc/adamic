RegExp('(?:a)|(?:b)*')
export {};
