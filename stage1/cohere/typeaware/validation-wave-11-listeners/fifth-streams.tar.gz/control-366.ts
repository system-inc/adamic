foo(function bar() { function bar() {} bar(); });
export {};
