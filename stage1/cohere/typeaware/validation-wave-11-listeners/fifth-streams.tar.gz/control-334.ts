var foo = function foo() {};
export {};
