foo(function(a:string) {});
export {};
