/(?<foo>a)/
export {};
