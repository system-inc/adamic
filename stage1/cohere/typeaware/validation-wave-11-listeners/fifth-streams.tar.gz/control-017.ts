const p='\\1'+'(a)';RegExp(p);const s='a';RegExp(s+'\\1(a)');RegExp('\\1(a){', 'u');RegExp('\\1(a){', flags);
export {};
