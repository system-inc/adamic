/\k<foo>((?<foo>bar)|(?<foo>baz))/
export {};
