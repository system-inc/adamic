throw foo &= new Error();
export {};
