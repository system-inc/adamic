foo(function bar() { bar; });
export {};
