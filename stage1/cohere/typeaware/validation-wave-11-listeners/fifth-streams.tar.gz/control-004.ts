const a=/\1(a)/;const b=/(a\1)/;const c=/(a|\1b)/;const d=/(?<=(a)\1)b/;const e=/(?!(a))\1/;const f=/(a)\1/;
export {};
