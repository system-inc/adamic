throw foo ? 'literal' : new Error();
export {};
