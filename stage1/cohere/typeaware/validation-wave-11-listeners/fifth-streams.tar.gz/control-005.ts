RegExp('\\1(a)');new RegExp('\\1(a)','u');const p='\\1(a)';RegExp(p);let q='\\1(a)';RegExp(q);let r='\\1(a)';r='(a)\\1';RegExp(r);
export {};
