foo(function bar() { new.target; }.bind(this));
export {};
