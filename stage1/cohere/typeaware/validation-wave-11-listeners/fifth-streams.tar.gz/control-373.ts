new Foo(function() { this; });
export {};
