new RegExp('(a)(b)\\3(c)')
export {};
