function foo(undefined) { throw undefined; }
export {};
