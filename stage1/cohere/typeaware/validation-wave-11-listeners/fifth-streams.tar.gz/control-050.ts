throw 'a' + 'b';
export {};
