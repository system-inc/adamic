foo(function(){arguments});foo(function(arguments:any){arguments});foo(function(){()=>arguments});foo(function(){function inner(){arguments}});
export {};
