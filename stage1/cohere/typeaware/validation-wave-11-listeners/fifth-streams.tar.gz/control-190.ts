/(?<foo>a)\k<foo>/
export {};
