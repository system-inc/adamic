foo(function bar() { this; }.bind(this, somethingElse));
export {};
