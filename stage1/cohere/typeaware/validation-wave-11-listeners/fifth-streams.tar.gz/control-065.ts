new RegExp('(?!(?<foo>\\n))\\1')
export {};
