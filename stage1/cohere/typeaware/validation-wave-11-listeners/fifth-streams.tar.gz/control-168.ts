/\0(a)/u
export {};
