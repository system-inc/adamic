foo(a => a);
export {};
