(function foo() {})();
export {};
