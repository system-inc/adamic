/(a).\1/
export {};
