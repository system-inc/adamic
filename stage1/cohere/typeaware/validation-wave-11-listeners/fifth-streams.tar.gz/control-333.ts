foo(a => { (function() {}); });
export {};
