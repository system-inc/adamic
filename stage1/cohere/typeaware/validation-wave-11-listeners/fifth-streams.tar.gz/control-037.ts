throw new Error() || 'literal';
export {};
