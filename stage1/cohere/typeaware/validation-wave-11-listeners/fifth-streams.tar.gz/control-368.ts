foo(function bar() { baz(); });
export {};
