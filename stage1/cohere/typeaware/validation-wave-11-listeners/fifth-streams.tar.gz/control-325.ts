test('foo', function (this: any) {});
export {};
