/(a)|\1b/
export {};
