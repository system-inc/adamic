/(?!\1(a))./
export {};
