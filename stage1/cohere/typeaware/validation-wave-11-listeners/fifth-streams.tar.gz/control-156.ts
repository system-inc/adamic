new RegExp(p, 'u')
export {};
