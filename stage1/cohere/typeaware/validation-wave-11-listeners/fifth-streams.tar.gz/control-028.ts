throw new foo();
export {};
