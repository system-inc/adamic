foo(function(a) { a; });
export {};
