new RegExp('\\1(a){', 'u')
export {};
