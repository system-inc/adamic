function f(RegExp:any){RegExp('\\1(a)')}RegExp('\\1(a)');function g(globalThis:any){globalThis.RegExp('\\1(a)')}
export {};
