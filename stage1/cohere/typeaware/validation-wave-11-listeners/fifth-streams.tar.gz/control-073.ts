/a(?<foo>(.)b\1)/
export {};
