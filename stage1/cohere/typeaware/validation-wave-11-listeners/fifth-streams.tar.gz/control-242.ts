new RegExp('[[]\\1](a)', 'v')
export {};
