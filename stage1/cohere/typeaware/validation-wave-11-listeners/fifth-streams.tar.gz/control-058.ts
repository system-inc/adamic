throw foo && 'literal'
export {};
