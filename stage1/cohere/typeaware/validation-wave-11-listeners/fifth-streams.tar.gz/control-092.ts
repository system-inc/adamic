/(?:a)(b)\2(c)/
export {};
