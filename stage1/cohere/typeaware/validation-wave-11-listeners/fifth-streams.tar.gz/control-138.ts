/(a)\2(b)/; RegExp('(\\1)');
export {};
