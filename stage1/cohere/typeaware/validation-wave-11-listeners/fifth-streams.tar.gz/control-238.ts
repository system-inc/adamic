new RegExp('\\1(a)\\2', 'ug')
export {};
