new RegExp('^(a\\1b)$')
export {};
