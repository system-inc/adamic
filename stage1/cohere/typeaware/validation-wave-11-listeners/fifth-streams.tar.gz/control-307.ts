qux(function(foo:number, bar:number, baz:number) { return foo * bar; }.bind(this))
export {};
