foo(function(a:string) { this; });
export {};
