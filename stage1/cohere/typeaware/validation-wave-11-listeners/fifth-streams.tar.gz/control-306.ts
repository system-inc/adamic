qux(function(foo:string, bar:number, baz:string) { return foo * 2; })
export {};
