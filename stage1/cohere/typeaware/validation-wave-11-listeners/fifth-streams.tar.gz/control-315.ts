qux(async function (foo:number = 1, bar:number = 2, baz:number = 3) { return this; }.bind(this))
export {};
