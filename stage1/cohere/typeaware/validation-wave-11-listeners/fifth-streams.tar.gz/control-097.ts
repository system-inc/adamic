/\1(?<!(a))./
export {};
