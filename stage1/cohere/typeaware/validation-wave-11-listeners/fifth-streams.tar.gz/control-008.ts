RegExp('\\1(a)');RegExp=other;window.RegExp('\\1(a)');const w=window;w.RegExp('\\1(a)');
export {};
