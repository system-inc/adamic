foo(function bar() { arguments; }.bind(this));
export {};
