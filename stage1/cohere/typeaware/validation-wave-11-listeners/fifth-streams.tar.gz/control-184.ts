/\k<foo>(a)/
export {};
