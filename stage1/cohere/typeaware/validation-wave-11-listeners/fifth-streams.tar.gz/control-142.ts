/((?<foo>bar)|\k<foo>(?<foo>baz))/
export {};
