new foo.RegExp('\\1(a)')
export {};
