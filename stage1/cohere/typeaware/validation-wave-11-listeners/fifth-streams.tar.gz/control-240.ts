new RegExp('\\k<foo>(?<foo>a)\\k<bar>')
export {};
