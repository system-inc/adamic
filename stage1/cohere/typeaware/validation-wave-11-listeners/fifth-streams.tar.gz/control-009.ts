let r; r=RegExp;r('\\1(a)');r=other;r('\\1(a)');const a=(x?RegExp:RegExp);a('\\1(a)');
export {};
