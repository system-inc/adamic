/(a)?(b)*(\3)/
export {};
