foo(function() { (function() { this; }); });
export {};
