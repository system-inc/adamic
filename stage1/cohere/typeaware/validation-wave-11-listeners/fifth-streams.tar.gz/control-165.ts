RegExp('(a)|(b)')
export {};
