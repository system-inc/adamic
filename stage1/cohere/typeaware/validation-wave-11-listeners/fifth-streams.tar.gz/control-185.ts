/^(a)\1\\2$/
export {};
