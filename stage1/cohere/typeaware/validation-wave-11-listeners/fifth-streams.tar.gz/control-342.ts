foo((function() {}).bind.bar)
export {};
