var e = new Error(); throw e;
export {};
