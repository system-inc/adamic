foo(function bar() {});
export {};
