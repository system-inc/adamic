foo(async function
(){});foo(function /*keep*/ named (){});foo(function named /*keep*/ (){});foo(function(){}.bind(/*keep*/this));
export {};
