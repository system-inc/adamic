foo((function() { this.bar(); }).bind(obj).bind(this))
export {};
