throw foo = 'error';
export {};
