foo(function(){class C{m(){this.x;arguments;new.target}}});foo(function(){const arguments=1;arguments});
export {};
