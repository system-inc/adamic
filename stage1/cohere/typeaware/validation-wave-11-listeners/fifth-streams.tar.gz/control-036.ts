throw 'literal' && new Error();
export {};
