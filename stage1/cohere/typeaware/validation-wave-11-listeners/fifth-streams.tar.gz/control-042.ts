async function foo() { throw await bar; }
export {};
