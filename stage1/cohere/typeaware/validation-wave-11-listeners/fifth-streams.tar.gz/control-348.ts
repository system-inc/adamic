foo(function bar(a:string) {});
export {};
