qux(function(foo, bar, baz) { return foo * bar; }.bind(this))
export {};
