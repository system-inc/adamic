foo(function() { this; });
export {};
