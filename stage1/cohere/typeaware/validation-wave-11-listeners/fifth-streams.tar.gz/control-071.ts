RegExp('^((\\1))$')
export {};
