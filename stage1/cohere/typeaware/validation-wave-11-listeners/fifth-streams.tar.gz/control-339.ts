foo(function bar() { new.target; });
export {};
