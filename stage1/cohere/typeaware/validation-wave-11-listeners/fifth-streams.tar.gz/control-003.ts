throw a='x';throw a=new Error();throw a&&='x';throw a||='x';throw a??='x';throw a+='x';throw a&&'x';throw a||'x';throw a??'x';throw a?'x':'y';throw a?'x':new Error();throw new Error(),1;
export {};
