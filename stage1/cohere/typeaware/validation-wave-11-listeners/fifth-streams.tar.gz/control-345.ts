foo((a:string) => a);
export {};
