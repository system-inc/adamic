new Foo(function() {});
export {};
