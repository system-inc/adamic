foo(function() { arguments; });
export {};
