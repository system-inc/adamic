foo(native || function(){});foo(x?function(){}:function(){});foo((function(){}));foo(function(){}['bind'](this));
export {};
