test('clean', function (this: any) { this.foo = 'Cleaned!';});
export {};
