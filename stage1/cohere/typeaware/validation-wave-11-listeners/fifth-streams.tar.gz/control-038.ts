throw foo ? new Error() : 'literal';
export {};
