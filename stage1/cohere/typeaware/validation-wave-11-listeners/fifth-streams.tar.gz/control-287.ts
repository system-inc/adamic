foo(function() { return this; }?.bind(this));
export {};
