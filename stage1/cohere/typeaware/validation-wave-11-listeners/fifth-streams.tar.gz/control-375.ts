const x = new Promise(function(resolve) { resolve(); });
export {};
