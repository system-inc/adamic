obj.test('clean', function (foo) { this.foo = 'Cleaned!'; });
export {};
