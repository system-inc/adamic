throw obj?.foo()
export {};
