/(.)(?<!(b|c)\2)d/
export {};
