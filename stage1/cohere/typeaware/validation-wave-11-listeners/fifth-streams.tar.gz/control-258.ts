foo(nativeCb || function() {});
export {};
