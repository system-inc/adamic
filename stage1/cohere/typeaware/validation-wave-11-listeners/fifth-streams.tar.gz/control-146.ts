/((?<foo>bar)|\k<foo>|(?<foo>baz)|(?<foo>qux))/
export {};
