/^(\1)*$/
export {};
