foo(function() {}.bind(this, somethingElse))
export {};
