foo(function() {});
export {};
