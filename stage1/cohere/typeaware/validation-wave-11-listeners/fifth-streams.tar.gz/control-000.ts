RegExp('\\1(a)');({RegExp}={});RegExp('\\1(a)');
export {};
