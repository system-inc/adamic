qux(function(baz:string, baz:string) { })
export {};
