throw 'x';throw undefined;throw new Error();throw (new Error());function f(undefined:any){throw undefined}throw x;throw true;throw null;
export {};
