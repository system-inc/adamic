new RegExp('(\\1)')
export {};
