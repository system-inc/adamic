foo(async function /* c */ () { return 1; });
export {};
