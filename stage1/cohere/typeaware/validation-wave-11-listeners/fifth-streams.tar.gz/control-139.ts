RegExp('\\1(a){', flags);
export {};
