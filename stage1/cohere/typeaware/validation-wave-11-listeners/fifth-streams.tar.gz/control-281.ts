foo(async function
 () { return 1; });
export {};
