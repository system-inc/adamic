/\k<foo>(?<foo>bar)/
export {};
