qux(function(foo, bar, baz) { return foo * this.qux; }.bind(this))
export {};
