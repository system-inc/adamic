class C { #field; foo() { throw foo.#field; } }
export {};
