foo(function():string { return 'foo' });
export {};
