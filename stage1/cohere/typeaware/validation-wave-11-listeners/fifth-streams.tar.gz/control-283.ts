foo((bar || function() {}).bind(this))
export {};
