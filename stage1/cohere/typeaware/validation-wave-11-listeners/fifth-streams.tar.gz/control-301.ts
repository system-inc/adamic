foo(function bar(a:string) { a; });
export {};
