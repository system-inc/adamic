/^a|(b|c)\1/
export {};
