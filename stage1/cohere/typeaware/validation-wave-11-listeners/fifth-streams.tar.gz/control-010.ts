foo(function(){});new Foo(function(){});foo(function bar(){bar()});foo(function bar(){const bar=1;bar});foo(function bar(){function bar(){}bar()});
export {};
