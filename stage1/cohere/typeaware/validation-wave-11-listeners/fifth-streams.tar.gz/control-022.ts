throw Error('error');
export {};
