foo(function(arguments:any) { arguments; });
export {};
