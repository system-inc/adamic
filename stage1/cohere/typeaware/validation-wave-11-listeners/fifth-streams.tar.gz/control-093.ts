/\k<foo>(?<foo>a)/
export {};
