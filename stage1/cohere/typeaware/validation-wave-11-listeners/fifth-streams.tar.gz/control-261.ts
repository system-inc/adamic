foo(function() { this; }.bind(this));
export {};
