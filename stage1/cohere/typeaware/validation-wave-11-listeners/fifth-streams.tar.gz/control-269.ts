qux(function(foo, bar, baz) { return foo * 2; })
export {};
