throw new Error(), 1, 2, 3;
export {};
