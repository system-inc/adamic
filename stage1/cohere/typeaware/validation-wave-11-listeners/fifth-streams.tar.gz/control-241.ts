new RegExp('([[A--B]])\\1', 'v')
export {};
