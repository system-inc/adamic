/(.)(?<=\2(a))b/
export {};
