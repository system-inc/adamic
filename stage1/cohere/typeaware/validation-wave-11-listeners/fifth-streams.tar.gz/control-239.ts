RegExp('\\1(a)\\k<foo>', 'u')
export {};
