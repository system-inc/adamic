const make=RegExp;make('\\1(a)');new make('\\1(a)');const {RegExp:R}=globalThis;R('\\1(a)');globalThis['Reg'+'Exp']('\\1(a)');
export {};
