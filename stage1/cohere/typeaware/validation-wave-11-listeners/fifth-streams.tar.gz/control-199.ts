/a(?<foo>(.)b\2)/
export {};
