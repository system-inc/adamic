declare var process: NodeJS.Process;
declare module "node:process" {
    global {
        var process: NodeJS.Process;
        namespace NodeJS {
            interface WritableStream { write(chunk: string | Uint8Array, callback?: (error?: Error | null) => void): boolean }
            interface WriteStream extends WritableStream { columns: number }
            interface ReadStream { isTTY?: boolean; setRawMode(mode: boolean): this; resume(): this; pause(): this }
            interface Process {
                stdout: WriteStream & { fd: 1 };
                stderr: WriteStream & { fd: 2 };
                stdin: ReadStream & { fd: 0 };
                exitCode: number | string | null | undefined;
                exit(code?: number | string | null): never;
                on(event: string, listener: (...args: any[]) => void): this;
            }
        }
    }
    export = process;
}
declare module "process" {
    import process = require("node:process");
    export = process;
}
declare module "node:console" {
    namespace console {
        interface Console {
            log(...data: any[]): void;
            info(...data: any[]): void;
            debug(...data: any[]): void;
            warn(...data: any[]): void;
            error(...data: any[]): void;
            trace(...data: any[]): void;
            table(tabularData?: any, properties?: string[]): void;
            dir(item?: any): void;
            dirxml(...data: any[]): void;
            group(...data: any[]): void;
            time(label?: string): void;
        }
    }
    var console: console.Console;
    export = console;
}
