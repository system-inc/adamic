function Widget(){const [state,setState]=useState(0);setState(1);return <div/>;}
export {};
