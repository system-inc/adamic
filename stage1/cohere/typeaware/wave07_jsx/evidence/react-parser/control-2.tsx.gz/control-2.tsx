function Widget(){const [state,setState]=useState(0);useEffect(()=>{setState(1);});return <div/>;}
export {};
