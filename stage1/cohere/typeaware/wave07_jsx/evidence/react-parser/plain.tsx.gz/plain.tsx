function Widget(){return 1;}
export {};
