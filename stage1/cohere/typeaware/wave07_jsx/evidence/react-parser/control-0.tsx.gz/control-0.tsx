function Widget(){const Inner=make();return <Inner/>;}
export {};
