declare const React:any;declare const flag:boolean;declare const app:any;
import {Fragment} from "react";const x=<Fragment/>;
export {};
