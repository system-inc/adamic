declare const React:any;declare const flag:boolean;declare const app:any;
const x=<div><App/><App/></div>;
export {};
