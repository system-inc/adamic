declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["\u2029x",foo("a")]);
export {};
