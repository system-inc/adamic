declare const React:any;declare const flag:boolean;declare const app:any;
const {Fragment}=require("preact");const x=<Fragment/>;
export {};
