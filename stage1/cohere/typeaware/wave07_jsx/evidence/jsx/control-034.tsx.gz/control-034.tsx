declare const React:any;declare const flag:boolean;declare const app:any;
const x=<Foo-bar/>;
export {};
