declare const React:any;declare const flag:boolean;declare const app:any;
const F=React.Other;const x=<F/>;
export {};
