declare const React:any;declare const flag:boolean;declare const app:any;
const F:unknown = /* comment */ React.Fragment;const x=<F/>;
export {};
