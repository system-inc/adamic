declare const React:any;declare const flag:boolean;declare const app:any;
import {createElement} from "react";createElement("div",undefined,[foo("a"),foo("span")]);
export {};
