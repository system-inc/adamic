declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,[0x10,foo("a")]);
export {};
