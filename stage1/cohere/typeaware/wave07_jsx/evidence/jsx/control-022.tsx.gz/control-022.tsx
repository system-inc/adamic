declare const React:any;declare const flag:boolean;declare const app:any;
const {Fragment:F}=React;const x=<F/>;
export {};
