declare const React:any;declare const flag:boolean;declare const app:any;
let F;const x=<F/>;
export {};
