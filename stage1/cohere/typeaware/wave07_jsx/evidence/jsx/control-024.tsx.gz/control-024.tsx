declare const React:any;declare const flag:boolean;declare const app:any;
const {Fragment}=require("react");const x=<Fragment/>;
export {};
