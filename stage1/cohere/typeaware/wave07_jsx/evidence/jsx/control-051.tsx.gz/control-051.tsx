declare const React:any;declare const flag:boolean;declare const app:any;
function f<T>(){return <T/>;}
export {};
