declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["\u200ax",foo("a")]);
export {};
