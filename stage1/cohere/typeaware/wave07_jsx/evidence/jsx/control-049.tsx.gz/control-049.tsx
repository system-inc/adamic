declare const React:any;declare const flag:boolean;declare const app:any;
{const App=null;const x=<App/>;}const y=<App/>;
export {};
