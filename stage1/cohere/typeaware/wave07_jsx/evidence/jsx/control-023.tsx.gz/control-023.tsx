declare const React:any;declare const flag:boolean;declare const app:any;
const {Anything}=React;const x=<Anything/>;
export {};
