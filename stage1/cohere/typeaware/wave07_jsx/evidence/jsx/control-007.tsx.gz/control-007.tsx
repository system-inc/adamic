declare const React:any;declare const flag:boolean;declare const app:any;
const x=<A.React.Fragment/>;
export {};
