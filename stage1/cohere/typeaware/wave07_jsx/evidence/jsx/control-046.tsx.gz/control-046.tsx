declare const React:any;declare const flag:boolean;declare const app:any;
enum A{App}var App;const x=<App/>;
export {};
