declare const React:any;declare const flag:boolean;declare const app:any;
const x=<React.Fragment/>;
export {};
