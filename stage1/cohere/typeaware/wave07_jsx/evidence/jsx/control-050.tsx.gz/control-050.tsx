declare const React:any;declare const flag:boolean;declare const app:any;
declare global {var Global:any;}const x=<Global/>;
export {};
