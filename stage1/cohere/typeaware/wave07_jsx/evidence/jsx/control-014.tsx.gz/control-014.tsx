declare const React:any;declare const flag:boolean;declare const app:any;
import {Fragment as F} from "preact";const x=<F/>;
export {};
