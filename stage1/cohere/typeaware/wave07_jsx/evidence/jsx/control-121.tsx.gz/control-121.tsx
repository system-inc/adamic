declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["x\u202f",foo("a")]);
export {};
