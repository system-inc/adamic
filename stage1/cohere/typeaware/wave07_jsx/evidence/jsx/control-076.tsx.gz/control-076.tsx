declare const React:any;declare const flag:boolean;declare const app:any;
const {createElement}=React;createElement("div",undefined,[foo("a"),foo("span")]);
export {};
