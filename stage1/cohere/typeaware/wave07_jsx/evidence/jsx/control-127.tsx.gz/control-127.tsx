declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["x\ufeff",foo("a")]);
export {};
