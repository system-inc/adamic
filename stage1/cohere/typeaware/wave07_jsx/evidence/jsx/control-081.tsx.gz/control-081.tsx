declare const React:any;declare const flag:boolean;declare const app:any;
import {createElement} from "react";declare function createElement(a:string):void;createElement("div",undefined,[foo("a"),foo("span")]);
export {};
