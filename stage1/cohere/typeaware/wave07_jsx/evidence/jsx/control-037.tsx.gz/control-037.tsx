declare const React:any;declare const flag:boolean;declare const app:any;
const x=<테스트/>;
export {};
