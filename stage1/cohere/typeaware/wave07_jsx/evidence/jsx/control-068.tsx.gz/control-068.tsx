declare const React:any;declare const flag:boolean;declare const app:any;
NotReact.createElement("div",undefined,[React.createElement("a"),React.createElement("span")]);
export {};
