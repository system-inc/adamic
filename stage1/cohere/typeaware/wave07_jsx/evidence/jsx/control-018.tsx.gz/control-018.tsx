declare const React:any;declare const flag:boolean;declare const app:any;
const F=require("react");const x=<F/>;
export {};
