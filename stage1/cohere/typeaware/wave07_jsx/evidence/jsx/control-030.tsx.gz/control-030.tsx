declare const React:any;declare const flag:boolean;declare const app:any;
import {Fragment} from "react";declare function Fragment():void;const x=<Fragment/>;
export {};
