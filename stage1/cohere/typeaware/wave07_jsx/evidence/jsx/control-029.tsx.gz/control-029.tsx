declare const React:any;declare const flag:boolean;declare const app:any;
declare function Fragment():void;import {Fragment} from "react";const x=<Fragment/>;
export {};
