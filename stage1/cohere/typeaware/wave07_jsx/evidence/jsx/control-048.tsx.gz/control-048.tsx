declare const React:any;declare const flag:boolean;declare const app:any;
declare namespace Foo {class App{}}import App=Foo.App;const x=<App/>;
export {};
