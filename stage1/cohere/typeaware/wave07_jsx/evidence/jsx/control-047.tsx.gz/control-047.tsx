declare const React:any;declare const flag:boolean;declare const app:any;
import App=require("./app");const x=<App/>;
export {};
