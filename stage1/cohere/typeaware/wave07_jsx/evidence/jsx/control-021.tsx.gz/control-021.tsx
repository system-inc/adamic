declare const React:any;declare const flag:boolean;declare const app:any;
const {Fragment}=React;const x=<Fragment/>;
export {};
