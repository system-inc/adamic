declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["x\r",foo("a")]);
export {};
