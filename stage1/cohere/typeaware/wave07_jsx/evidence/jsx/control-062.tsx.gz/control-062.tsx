declare const React:any;declare const flag:boolean;declare const app:any;
const x=<div><a.b/><a.b/></div>;
export {};
