const x=<GlobalFragment/>;
export {};
