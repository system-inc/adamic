declare const React:any;declare const flag:boolean;declare const app:any;
/*世界 🌍*/
const é=<React.Fragment><a/><span/></React.Fragment>;
export {};
