declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,[123n,foo("a")]);
export {};
