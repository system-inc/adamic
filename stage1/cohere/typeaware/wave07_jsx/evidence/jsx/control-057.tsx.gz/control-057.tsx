declare const React:any;declare const flag:boolean;declare const app:any;
const x=<div><a/>{/*comment*/}<a/></div>;
export {};
