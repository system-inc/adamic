declare const React:any;declare const flag:boolean;declare const app:any;
const {createElement}=require("react");createElement("div",undefined,[foo("a"),foo("span")]);
export {};
