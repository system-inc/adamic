declare const React:any;declare const flag:boolean;declare const app:any;
declare function createElement(a:string):void;import {createElement} from "react";createElement("div",undefined,[foo("a"),foo("span")]);
export {};
