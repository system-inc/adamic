declare const React:any;declare const flag:boolean;declare const app:any;
const F=require("react").Fragment;const x=<F/>;
export {};
