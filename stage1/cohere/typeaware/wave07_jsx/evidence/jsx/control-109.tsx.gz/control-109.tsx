declare const React:any;declare const flag:boolean;declare const app:any;
React.createElement("div",undefined,["x\u00a0",foo("a")]);
export {};
