declare const React:any;declare const flag:boolean;declare const app:any;
const F=React.Fragment;function nested(){const F=null;return <F/>;}
export {};
