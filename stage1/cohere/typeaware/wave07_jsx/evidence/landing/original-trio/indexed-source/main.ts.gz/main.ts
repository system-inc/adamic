import { panic, programArguments, readTextFile, tsgoProgram, tsgoRelease } from 'adamic';
import { written } from '/workspace/adamic/stage1/typescript/parser/nodes.ts';
import { Parser } from '/workspace/adamic/stage1/typescript/parser/parser.ts';
import { Scanner } from '/workspace/adamic/stage1/typescript/scanner/scanner.ts';
import { UnaryMinus, byteOffsets } from './unary_minus.ts';

const args = programArguments();
const config = args[0] ?? panic('usage: main.ts tsconfig manifest [--count]');
const manifest = readTextFile(args[1] ?? panic('missing manifest'));
if(manifest.kind === 'Error') {
    panic(manifest.message);
}
const paths = manifest.text.split('\n').filter((path) => path !== '');
const program = tsgoProgram(config, paths);
let findings = 0;
let queries = 0;
for(const path of paths) {
    const source = readTextFile(path);
    if(source.kind === 'Error') {
        panic(source.message);
    }
    const parser = new Parser(source.text, path);
    const scanner = new Scanner(source.text);
    const linter = new UnaryMinus(program, path, parser, scanner, byteOffsets(source.text));
    linter.run();
    findings += linter.findings.length;
    queries += linter.queries;
    if(!args.includes('--count')) {
        console.log(`file\t${written(path)}`);
        for(const finding of linter.findings) {
            console.log(
                `${finding.start}\t${finding.end}\t${finding.rule}\t${finding.id}\t${written(finding.message)}\t0\t0`,
            );
        }
    }
}
console.log(`findings ${findings} queries ${queries}`);
tsgoRelease(program);
