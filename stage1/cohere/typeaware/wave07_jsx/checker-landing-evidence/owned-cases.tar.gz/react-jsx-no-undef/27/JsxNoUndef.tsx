var React; React.render(<img />);
