var React;
        import { Foo } from './foo';
        import App = Foo.App;
        React.render(<App />);
