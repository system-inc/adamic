var React, app; React.render(<app.foo.Bar />);
