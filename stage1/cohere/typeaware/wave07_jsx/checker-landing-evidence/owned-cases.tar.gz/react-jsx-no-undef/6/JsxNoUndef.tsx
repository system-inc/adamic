let x = <A.B />;
