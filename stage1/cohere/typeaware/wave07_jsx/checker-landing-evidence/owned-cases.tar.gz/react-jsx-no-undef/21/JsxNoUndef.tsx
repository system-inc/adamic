var React; React.render(<Apppp:Foo />);
