var React; React.render(<App />);
