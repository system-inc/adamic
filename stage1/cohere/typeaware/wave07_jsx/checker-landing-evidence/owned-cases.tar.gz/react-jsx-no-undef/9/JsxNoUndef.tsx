var React, A; React.render(<A.B.C.D />);
