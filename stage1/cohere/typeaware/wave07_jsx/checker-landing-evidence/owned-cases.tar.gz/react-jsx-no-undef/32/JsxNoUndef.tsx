var React; React.render(<zzz.Bar />);
