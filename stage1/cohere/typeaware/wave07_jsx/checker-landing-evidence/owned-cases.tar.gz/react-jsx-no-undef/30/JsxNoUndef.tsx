var React; React.render(<this.props.tag />);
