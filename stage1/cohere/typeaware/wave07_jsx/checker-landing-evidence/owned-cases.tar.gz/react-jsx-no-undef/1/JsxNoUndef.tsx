declare var A: any; var React; React.render(<A.B />);
