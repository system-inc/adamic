import Text from './globals'; <Text />;
