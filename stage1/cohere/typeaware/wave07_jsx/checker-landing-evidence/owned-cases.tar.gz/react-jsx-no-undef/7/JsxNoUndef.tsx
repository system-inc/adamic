type App = any; var React; React.render(<App />);
