var React; import App = require('./app'); React.render(<App />);
