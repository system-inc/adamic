export {}; var React: any; React.render(<Text />);
