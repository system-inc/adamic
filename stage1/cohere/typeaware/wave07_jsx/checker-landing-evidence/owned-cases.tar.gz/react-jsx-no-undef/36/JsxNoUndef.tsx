var React; enum A { App }; var App; React.render(<App />);
