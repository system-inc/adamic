var App; var React; enum A { App };  React.render(<App />);
