import Text from "cool-module";
        const TextWrapper = function (props) {
          return (
            <Text />
          );
        };
