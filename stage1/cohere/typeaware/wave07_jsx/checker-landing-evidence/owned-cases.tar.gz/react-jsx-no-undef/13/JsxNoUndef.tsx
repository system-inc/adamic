var React;
        class Hello extends React.Component {
          render() {
            return <this.props.tag />
          }
        }
