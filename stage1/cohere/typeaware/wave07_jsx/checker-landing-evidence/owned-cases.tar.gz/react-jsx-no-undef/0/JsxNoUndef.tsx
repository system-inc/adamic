declare global { var G: any } export {}; <G />;
