var React; React.render(<App></App>);
