var React; React.render(<A.B.C.D />);
