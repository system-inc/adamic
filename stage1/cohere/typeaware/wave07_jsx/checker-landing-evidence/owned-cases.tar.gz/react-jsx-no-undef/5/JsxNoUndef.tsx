interface App {}; var React; React.render(<App />);
