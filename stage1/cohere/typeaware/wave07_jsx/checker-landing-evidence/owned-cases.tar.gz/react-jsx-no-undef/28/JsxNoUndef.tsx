var React; React.render(<my-Element />);
