var React; React.render(<$foo />);
