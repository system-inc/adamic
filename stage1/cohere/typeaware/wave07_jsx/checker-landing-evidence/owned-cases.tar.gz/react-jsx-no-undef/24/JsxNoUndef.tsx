var React; React.render(<_foo />);
