var React; React.render(<appp.Foo />);
