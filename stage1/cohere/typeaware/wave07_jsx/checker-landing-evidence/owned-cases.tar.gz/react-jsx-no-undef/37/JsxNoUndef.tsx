var React; function App() { return null; }; React.render(<App />);
