var React; { const App = null; }; React.render(<App />);
