var React; React.render(<appp.foo.Bar />);
