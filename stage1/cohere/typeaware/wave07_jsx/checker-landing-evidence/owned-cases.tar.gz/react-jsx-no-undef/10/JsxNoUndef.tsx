var React, App; React.render(<App />);
