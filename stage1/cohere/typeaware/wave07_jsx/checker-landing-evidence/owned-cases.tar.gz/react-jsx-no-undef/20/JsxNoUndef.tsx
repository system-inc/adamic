var React; React.render(<Appp.Foo />);
