var React, app; React.render(<app.Foo />);
