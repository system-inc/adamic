var React; React.render(<Foo />);
