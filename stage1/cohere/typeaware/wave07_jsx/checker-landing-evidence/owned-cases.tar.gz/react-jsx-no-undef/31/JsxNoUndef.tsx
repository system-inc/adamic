var React; React.render(<x-gif />);
