var React; React.render(<Foo-bar />);
