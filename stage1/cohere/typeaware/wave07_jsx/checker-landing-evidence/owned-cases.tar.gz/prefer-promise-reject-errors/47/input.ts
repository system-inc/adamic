Promise.reject(new Error('foo'))
