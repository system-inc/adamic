function f() { Promise.reject('x'); var Promise; }
