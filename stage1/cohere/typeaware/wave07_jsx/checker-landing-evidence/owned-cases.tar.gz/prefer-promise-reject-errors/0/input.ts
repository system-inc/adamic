(Promise).reject(new Error());
