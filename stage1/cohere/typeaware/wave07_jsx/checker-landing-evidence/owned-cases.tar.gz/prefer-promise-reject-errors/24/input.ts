Promise.reject(5)
