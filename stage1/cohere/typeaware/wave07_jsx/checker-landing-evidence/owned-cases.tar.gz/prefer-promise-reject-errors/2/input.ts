(Promise?.reject)?.(5)
