class C { #error; foo() { Promise.reject(this.#error); } }
