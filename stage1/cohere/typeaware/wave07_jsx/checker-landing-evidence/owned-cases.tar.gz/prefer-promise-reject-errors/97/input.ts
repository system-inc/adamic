new Promise(function(reject, reject) { reject(5) })
