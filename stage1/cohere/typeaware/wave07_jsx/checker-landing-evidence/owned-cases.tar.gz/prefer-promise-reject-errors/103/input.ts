new Promise(function(resolve, reject) { return function(reject) { reject(5) } })
