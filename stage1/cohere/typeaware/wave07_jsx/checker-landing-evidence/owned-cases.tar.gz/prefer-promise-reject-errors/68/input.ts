declare const error: Error; Promise.reject(error satisfies Error);
