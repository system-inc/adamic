new Promise({ a: 1, b: 2 });
