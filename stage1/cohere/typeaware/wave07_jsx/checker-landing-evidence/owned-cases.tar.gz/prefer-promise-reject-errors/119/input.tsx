Promise.reject(5 as any as string);
