Promise.reject(5 && foo)
