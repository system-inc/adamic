let Promise; Promise.reject('x');
