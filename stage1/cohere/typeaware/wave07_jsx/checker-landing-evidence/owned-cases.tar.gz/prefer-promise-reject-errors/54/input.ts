Promise.reject({ foo: 1 })
