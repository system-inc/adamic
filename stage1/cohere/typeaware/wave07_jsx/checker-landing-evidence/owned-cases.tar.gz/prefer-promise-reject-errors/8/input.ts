Promise.reject(!foo)
