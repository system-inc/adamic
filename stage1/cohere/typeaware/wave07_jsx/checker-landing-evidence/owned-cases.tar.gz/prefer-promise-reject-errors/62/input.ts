async function foo() { Promise.reject(await foo); }
