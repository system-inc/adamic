Promise.reject(foo &&= 5)
