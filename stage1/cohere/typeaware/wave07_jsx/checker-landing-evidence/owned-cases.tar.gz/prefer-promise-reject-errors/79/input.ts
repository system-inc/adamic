function g(Promise) { return new Promise((resolve, reject) => { reject('x'); }); }
