declare const error: unknown; Promise.reject(<Error>error);
