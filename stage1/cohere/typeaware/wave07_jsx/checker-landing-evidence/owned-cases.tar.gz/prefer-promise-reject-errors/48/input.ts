Promise.reject(new Error())
