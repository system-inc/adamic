Object.reject(5);
