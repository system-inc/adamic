Promise.reject(undefined)
