Promise.reject(5 ? 6 : 7);
