Promise.reject('foo')
