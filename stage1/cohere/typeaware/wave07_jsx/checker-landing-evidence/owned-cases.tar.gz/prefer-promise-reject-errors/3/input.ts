/* global Promise:off */ Promise.reject('x');
