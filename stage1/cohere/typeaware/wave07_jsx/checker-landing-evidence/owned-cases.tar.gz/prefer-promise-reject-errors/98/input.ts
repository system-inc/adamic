new Promise(function(resolve, ...rest) { rest[0](5) });
