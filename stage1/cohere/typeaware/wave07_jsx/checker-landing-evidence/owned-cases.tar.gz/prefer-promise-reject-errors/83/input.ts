new Promise((foo, arguments) => arguments(5))
