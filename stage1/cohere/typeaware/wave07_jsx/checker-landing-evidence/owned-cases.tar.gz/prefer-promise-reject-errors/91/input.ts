new Promise(({foo, bar, baz}, reject) => reject(5))
