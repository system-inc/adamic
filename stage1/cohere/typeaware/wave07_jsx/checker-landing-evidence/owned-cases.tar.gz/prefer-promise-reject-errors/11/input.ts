Promise.reject('x' satisfies string);
