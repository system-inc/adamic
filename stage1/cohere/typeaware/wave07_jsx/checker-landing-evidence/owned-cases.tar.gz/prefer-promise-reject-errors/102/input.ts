new Promise(function(resolve, reject) { resolve(5, reject) })
