Promise.resolve(5)
