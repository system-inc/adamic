Promise.reject(void foo)
