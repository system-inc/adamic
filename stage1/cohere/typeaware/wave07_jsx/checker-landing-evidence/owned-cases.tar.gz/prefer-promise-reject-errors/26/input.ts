Promise.reject(<Error>(<unknown>5));
