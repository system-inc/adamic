declare const error: Error | undefined; Promise.reject(error!);
