Promise.reject(foo.bar)
