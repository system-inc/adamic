new Promise((resolve, reject, somethingElse = reject(5)) => {})
