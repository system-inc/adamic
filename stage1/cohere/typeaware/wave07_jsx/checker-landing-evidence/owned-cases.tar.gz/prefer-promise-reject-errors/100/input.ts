new Promise(function(resolve, reject) { if (foo) { const reject = somethingElse; reject(5) } })
