(Promise.reject)(5);
