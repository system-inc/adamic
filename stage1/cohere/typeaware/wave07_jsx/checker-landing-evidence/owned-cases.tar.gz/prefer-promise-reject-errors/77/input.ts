function f(undefined) { Promise.reject(undefined); }
