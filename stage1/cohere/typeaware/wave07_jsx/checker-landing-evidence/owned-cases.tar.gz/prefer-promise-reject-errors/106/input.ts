new Promise(function({}, reject) { reject(5) })
