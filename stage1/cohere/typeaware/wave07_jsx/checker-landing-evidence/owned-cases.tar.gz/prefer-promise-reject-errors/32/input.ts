Promise.reject(foo **= new Error())
