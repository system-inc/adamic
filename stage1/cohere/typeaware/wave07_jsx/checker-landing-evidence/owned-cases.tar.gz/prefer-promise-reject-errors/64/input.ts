class C { #reject: any; foo() { Promise.#reject(5); } }
