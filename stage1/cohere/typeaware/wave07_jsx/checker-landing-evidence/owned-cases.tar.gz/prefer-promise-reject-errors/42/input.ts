Promise.reject(foo)
