declare const error: unknown; Promise.reject((error as Error));
