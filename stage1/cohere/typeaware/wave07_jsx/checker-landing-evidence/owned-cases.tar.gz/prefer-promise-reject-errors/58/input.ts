Promise?.reject?.(5)
