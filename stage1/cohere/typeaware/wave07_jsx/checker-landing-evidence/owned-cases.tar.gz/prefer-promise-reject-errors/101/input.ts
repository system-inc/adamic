new Promise(function(resolve, reject) { reject(5) })
