Promise.reject(obj?.foo())
