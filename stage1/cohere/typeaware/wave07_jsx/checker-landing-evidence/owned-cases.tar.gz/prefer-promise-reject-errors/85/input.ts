new Promise((resolve, reject) => reject(5 as any));
