{ class Promise { static reject(x) { return x; } } Promise.reject('x'); }
