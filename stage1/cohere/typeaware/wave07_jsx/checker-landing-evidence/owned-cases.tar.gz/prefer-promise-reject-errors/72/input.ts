declare const error: unknown; Promise.reject(error as unknown as Error);
