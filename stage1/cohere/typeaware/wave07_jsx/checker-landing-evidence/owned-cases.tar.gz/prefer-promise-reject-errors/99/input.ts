new Promise(function(resolve, [first]) { first(5) });
