JSON.reject(5);
