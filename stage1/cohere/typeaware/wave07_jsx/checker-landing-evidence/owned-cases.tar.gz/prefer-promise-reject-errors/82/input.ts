new Object((resolve: any, reject: any) => reject(5));
