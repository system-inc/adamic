Promise[someName](5);
