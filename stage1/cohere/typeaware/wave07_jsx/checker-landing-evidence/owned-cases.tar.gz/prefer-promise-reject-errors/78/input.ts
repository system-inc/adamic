function f(undefined) { new Promise((resolve, reject) => reject(undefined)); }
