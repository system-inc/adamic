new Promise((resolve, reject) => { reject(5) })
