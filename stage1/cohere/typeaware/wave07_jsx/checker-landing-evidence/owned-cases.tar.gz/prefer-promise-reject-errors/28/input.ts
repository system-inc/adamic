Promise.reject(`foo`)
