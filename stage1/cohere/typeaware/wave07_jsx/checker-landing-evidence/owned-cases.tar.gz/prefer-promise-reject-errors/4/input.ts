Foo.reject(5)
