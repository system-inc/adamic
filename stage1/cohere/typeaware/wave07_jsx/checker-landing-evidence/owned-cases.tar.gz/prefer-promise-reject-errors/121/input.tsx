Promise[`reject`](5);
