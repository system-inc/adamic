Promise.reject(new TypeError)
