Promise.reject(foo.bar())
