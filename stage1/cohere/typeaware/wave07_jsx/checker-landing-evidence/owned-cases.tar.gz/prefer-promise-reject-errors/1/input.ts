(Promise?.reject)(5)
