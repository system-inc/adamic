class Promise2 { static reject(x: string) { return x; } } Promise2.reject('x');
