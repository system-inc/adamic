function f(Promise) { return Promise.reject('x'); }
