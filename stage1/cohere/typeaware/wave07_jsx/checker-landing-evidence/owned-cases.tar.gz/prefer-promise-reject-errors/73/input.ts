declare const error: unknown; new Promise((resolve, reject) => reject(error as Error));
