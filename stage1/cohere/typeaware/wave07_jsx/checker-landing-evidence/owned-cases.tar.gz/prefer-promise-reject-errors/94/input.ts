new Promise([1, 2]);
