Promise.reject(<string>'x');
