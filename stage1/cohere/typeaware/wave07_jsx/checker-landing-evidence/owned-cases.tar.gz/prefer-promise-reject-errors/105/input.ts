new Promise(function(yes, no) { no(5) })
