Promise.reject('foo', somethingElse)
