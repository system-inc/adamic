new Promise(({}, reject) => reject(5))
