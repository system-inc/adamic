new Foo((resolve, reject) => reject(5))
