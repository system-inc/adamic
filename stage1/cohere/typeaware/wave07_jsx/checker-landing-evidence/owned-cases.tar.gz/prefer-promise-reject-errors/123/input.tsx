new Promise((resolve, reject) => { if (true) { reject('x'); } });
