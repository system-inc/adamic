Promise.reject([1, 2, 3])
