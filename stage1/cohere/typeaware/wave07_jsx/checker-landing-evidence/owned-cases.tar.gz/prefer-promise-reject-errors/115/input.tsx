((Promise)).reject(5);
