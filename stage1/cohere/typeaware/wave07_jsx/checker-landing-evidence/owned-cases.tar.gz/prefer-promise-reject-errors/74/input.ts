declare const made: any; new Promise(made.executor);
