Promise.reject(foo ? 5 : bar);
