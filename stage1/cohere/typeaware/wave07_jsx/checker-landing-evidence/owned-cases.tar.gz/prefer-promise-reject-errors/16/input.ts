Promise.reject((foo, bar));
