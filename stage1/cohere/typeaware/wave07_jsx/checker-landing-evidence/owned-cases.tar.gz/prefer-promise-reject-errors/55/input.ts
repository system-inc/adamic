Promise.reject?.(5)
