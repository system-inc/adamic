new Promise(function(foo, arguments) { arguments(5) })
