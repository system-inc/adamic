Promise.reject(5 as unknown as Error);
