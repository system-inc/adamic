Math.reject(5);
