new Promise(function(resolve, {apply}) { apply(5) })
