class C { #reject; foo() { Promise.#reject(5); } }
