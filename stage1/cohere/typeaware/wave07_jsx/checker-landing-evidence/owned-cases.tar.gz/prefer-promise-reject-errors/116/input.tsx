(Promise).reject(5);
