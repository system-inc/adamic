Promise.reject(foo[bar] ??= 5)
