Promise.reject(obj?.foo)
