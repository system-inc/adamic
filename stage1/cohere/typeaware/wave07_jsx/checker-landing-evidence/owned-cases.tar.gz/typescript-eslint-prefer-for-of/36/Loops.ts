for (let i = 0; i < arr.length; i++) {
  delete arr[i];
}
