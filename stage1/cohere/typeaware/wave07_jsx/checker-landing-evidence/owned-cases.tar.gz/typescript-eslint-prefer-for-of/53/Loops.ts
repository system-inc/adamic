for (let i = 0; i < this.item.length; ++i) {
  this.item[i];
}
