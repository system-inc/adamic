for (let i = 0; i < arr.length; i++) {
  const x = typeof arr[i];
}
