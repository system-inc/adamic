for (let i = 0; i < arr.length; i++) {
  const o = { foo: arr[i] };
}
