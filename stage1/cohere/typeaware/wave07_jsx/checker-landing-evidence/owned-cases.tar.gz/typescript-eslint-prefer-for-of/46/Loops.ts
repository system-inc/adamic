for (let i = 0; i < arr.size; i++) {
  console.log(arr[i]);
}
