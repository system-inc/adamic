for (let i = 0; i < test.length; ++i) {
  this[i];
}
