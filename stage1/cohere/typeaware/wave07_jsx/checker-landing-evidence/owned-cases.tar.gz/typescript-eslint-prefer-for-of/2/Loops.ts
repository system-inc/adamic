for (let NOTX = 0; x < arr.length; x++) {}
