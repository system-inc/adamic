var o = 0;
for (; o < arr.length; o++) {
  console.log(arr[o]);
}
