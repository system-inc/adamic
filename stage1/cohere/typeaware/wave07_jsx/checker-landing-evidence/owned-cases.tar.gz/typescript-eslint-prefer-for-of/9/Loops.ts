for (let i = 0; i < arr.length; i++) {
  (arr[i] as unknown as number)++;
}
