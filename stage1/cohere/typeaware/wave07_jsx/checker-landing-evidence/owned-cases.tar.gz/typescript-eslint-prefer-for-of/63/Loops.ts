for (let x = 0; x < arr.length; x += 11) {}
