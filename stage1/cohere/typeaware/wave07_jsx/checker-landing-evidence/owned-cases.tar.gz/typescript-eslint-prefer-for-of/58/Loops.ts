for (let x = 0; true; x++) {}
