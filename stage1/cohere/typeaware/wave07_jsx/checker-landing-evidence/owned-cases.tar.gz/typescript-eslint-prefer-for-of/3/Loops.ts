for (let a = 0; a < arr.length; ++a) {
  arr[a].whatever();
}
