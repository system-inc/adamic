for (var r of arr) {
  console.log(r);
}
