for (var h = 0, len = 1; h < arr.length; h++) {
  console.log(arr[h]);
}
