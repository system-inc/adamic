for (var a = 0; a < obj.arr.length; a++) {
  console.log(obj.arr[a]);
}
