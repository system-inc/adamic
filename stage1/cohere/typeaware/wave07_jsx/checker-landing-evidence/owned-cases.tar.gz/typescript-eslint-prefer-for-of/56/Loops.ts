for (let x = 0; ; x++) {}
