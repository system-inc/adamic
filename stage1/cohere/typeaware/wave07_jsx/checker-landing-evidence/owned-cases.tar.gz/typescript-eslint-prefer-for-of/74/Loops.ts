for (let x = arr.length; x > 1; x -= 1) {}
