for (let i = 0; i < arr1?.length; i++) {
  const x = arr1[i] === arr2[i];
}
