for (let a = 0; a < arr.length; a++) {
  console?.log(arr[a]);
}
