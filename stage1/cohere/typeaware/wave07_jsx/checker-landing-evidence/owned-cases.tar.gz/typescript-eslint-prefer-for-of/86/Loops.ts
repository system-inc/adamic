for (var g = 0; g <= 40; g++) doMath(g);
