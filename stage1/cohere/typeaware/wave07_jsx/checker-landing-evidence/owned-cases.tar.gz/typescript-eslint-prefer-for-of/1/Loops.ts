for (const i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}
