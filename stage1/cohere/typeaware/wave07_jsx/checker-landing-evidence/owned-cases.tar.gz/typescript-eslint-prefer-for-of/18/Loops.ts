for (let i = 0; i < arr.length; i++) {
  ({ foo: arr[i] }) === x;
}
