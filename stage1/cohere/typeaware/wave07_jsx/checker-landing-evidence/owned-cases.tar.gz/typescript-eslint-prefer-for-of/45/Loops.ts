for (let i = 0; i < arr.length; i++) {
  x = { foo: arr[i] };
}
