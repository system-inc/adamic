for (let i = 0; i < arr.length; i++) {
  [obj[arr[i]]] = [1];
}
