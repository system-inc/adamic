for (var c = 0; c < arr.length; c++) {
  doMath(c);
}
