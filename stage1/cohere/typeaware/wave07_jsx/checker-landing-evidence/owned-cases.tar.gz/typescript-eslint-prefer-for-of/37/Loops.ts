for (let i = 0; i < arr.length; i++) {
  delete obj[arr[i]];
}
