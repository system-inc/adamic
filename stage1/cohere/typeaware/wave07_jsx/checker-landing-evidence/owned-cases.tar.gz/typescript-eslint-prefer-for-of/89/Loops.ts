for (var h = 0, len = arr.length; h < len; h++) {}
