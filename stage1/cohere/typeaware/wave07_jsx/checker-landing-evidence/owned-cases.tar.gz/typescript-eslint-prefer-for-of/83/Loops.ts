for (var d = 0; d < arr?.length; d++) doMath(d);
