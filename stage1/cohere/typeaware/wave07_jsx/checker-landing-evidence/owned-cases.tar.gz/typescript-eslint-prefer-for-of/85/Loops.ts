for (var f = 0; f <= 40; f++) {
  doMath(f);
}
