for (var h = 0, k = 0; h < arr.length; h++) {
  console.log(arr[h]);
}
