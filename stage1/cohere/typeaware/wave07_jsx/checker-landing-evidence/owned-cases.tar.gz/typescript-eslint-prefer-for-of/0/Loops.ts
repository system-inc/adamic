for (; x < arr.length; x++) {}
