for (let x = 1; x < arr.length; x++) {}
