var m = 0;
for (;;) {
  if (m > 3) break;
  console.log(m);
  m++;
}
