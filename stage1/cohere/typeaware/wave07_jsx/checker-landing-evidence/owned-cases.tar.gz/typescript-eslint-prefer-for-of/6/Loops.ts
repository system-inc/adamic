for (let i = 0; i < arr.count; i++) {
  console.log(arr[i]);
}
