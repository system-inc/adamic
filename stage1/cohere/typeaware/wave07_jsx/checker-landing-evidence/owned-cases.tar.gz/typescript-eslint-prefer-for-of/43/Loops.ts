for (let i = 0; i < arr.length; i++) {
  other = arr[i];
}
