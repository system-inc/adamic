for (var q in obj) {
  if (obj.hasOwnProperty(q)) {
    console.log(q);
  }
}
