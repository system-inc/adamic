for (var i = 0, len = arr.length; i < len; i++) arr[i];
