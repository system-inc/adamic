for (let i = 0; i < this.array.length; ++i) {
  yield this.array[i];
}
