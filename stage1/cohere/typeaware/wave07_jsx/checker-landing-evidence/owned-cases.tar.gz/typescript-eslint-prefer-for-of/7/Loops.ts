for (let i = 0; i < arr.length; i++) {
  (<number>arr[i])++;
}
