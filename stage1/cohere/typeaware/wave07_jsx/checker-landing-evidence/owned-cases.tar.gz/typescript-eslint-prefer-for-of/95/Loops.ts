var n = 0;
for (; n < 9; n++) {
  console.log(n);
}
