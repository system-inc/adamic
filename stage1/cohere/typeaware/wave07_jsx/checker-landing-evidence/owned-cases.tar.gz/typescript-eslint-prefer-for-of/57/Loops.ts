for (let x = 0; NOTX < arr.length; x++) {}
