for (var b = 0; b < arr.length; b++) console.log(arr[b]);
