for (let x = 0; x < arr.length; x++) {
  let y = arr[x + 1];
}
