function foo() { { let arguments = 1; arguments; } }
