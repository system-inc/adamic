function foo() { arguments[0]; }
