function foo() { arguments.callee; }
