function foo() { arguments[1]; }
