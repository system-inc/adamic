function foo(...args) { args; }
