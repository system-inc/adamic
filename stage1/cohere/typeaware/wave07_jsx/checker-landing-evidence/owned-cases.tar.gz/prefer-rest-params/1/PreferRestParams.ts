class C { m() { arguments; } }
