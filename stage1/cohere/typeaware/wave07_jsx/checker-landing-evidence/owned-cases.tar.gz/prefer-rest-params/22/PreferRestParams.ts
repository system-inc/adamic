var o = { m() { arguments; } };
