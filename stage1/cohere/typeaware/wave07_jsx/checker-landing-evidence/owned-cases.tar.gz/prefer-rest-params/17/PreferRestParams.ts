function foo(arguments) { arguments; }
