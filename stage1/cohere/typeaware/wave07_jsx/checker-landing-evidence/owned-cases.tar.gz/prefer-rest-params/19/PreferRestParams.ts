function outer(arguments) { function inner() { arguments; } }
