function foo() { arguments; }
