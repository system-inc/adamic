var foo = () => arguments;
