function foo() { var bar = () => arguments; }
