function foo() { function bar() { arguments; } }
