function foo() { try {} catch (arguments) { arguments; } }
