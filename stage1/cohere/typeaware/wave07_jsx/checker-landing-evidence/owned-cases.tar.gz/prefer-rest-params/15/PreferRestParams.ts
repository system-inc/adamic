function foo() { { { var arguments; } } arguments; }
