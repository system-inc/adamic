function outer() { arguments; var bar = () => arguments; }
