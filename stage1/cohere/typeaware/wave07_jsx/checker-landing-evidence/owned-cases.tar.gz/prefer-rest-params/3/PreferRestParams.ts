function foo() { arguments.length; }
