function foo() { foo.arguments; }
