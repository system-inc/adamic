var arguments = 1; function foo() { arguments; }
