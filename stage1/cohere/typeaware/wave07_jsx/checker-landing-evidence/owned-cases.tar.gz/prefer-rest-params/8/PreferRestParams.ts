function foo() { arguments[Symbol.iterator]; }
