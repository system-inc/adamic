interface Foo {
  [s: string]: Foo | string;
}
