type Foo = { [key: string]: any };
