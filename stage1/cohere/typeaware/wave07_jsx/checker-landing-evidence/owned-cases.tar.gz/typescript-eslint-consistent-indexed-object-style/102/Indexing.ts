type Foo = { [key: string]: Foo };
