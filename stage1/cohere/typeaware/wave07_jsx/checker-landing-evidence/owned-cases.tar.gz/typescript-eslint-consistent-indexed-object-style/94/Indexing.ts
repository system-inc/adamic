type Foo = {
  bar: string;
};
