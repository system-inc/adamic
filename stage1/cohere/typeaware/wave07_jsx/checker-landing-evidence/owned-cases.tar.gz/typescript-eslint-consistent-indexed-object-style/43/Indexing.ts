interface Foo {
  // preserve me
  [key: string]: number;
}
