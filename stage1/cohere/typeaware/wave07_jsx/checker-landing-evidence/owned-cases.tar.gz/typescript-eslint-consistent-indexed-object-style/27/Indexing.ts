export interface Foo<A = any, B extends string = string> {
  readonly [key: string]: A | B;
}
