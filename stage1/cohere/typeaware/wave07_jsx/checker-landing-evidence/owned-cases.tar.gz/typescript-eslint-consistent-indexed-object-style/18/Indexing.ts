type Foo<T> = Record<string, T>;
