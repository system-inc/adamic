type Foo = Misc<string, unknown>;
