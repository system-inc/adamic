interface Foo {
  [s: string]: Foo[number];
}
