type Foo = {
  [key: string]: any;
  bar: string;
};
