function foo(arg: { [key: string]: any }) {}
