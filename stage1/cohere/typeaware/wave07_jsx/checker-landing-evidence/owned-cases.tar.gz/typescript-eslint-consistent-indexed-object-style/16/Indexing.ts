type Foo = Record<symbol, any>;
