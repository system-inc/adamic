type T = { [key in string]: number };
