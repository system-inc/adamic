namespace Outer {
  export interface Foo {
    [key: string]: number;
  }
}
