type Foo = Generic<{ readonly [key: string]: any }>;
