type Foo = {
  bar: string;
  [key: string]: any;
};
