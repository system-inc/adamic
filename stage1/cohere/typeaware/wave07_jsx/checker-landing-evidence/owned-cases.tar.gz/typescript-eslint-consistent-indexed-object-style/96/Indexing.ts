type Foo = { [k: string]: A.Foo };
