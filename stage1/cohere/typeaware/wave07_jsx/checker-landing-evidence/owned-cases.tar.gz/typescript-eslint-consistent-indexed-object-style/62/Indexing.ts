interface Foo {
  readonly [key: string]: any;
}
