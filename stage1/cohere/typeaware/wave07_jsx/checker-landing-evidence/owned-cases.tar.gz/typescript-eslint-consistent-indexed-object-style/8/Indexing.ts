type Foo = Record;
