function foo(arg: { [key: string]: any; bar: string }) {}
