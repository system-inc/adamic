function foo(arg: Record<string, any>) {}
