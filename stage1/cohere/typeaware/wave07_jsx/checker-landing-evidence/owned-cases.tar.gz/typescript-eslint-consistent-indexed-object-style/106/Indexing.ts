type Foo = { [key: string]: { [key: string]: Foo } };
