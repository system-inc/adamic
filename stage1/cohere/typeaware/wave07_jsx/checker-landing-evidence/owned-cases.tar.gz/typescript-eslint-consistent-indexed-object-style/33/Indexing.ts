function foo(): { readonly [key: string]: any } {}
