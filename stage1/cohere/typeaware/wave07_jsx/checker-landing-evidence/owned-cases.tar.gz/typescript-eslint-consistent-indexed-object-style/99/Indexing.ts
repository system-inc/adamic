type Foo = { [key: string]: /* preserve me */ number };
