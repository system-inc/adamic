interface Foo {
  [key: string];
}
