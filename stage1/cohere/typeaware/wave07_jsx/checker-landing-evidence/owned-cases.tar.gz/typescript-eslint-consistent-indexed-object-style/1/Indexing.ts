function foo(): Record<string, any> {}
