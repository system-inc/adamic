interface Foo {
  [k: string]: { [key: string]: Foo };
}
