type T = { +readonly [key in string]: number };
