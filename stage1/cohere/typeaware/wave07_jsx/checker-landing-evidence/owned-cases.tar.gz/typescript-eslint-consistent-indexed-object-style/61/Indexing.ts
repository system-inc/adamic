interface Foo {
  bar: string;
}
