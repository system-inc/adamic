type Foo = Generic<{
  [key: string]: any;
  bar: string;
}>;
