type Foo = { [key: string]: AnotherFoo };
