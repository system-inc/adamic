type Foo = {
  [k in string];
};
