declare interface Foo {
  [key: string]: number;
}
