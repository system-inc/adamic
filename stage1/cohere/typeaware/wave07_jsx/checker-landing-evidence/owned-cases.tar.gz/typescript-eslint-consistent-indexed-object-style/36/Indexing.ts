function foo(arg: { readonly [key: string]: any }) {}
