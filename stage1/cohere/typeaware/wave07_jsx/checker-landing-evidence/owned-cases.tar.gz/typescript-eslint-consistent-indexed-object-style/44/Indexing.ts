interface Foo {
  [];
}
