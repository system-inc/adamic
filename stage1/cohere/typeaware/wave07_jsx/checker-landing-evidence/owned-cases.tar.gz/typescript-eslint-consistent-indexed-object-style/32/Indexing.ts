function foo(): { [key: string]: any; bar: string } {}
