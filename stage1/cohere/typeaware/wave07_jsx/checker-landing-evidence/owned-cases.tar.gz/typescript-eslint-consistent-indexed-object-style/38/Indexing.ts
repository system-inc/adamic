function foo(e: { [key in PropertyKey]-?: string }) {}
