interface Foo<T> {
  [k: string]: T;
}
