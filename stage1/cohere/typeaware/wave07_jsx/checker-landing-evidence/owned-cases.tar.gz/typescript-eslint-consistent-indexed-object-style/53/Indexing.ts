interface Foo {
  [key: string]: { foo: Foo };
}
