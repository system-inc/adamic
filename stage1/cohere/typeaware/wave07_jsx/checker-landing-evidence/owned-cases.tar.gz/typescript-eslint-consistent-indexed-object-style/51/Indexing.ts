interface Foo {
  [key: string]: any;
  bar: string;
}
