type Foo = {};
