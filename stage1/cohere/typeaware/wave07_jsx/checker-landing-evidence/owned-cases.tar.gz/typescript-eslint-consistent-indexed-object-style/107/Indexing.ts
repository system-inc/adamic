type Foo = { readonly [key: string]: any };
