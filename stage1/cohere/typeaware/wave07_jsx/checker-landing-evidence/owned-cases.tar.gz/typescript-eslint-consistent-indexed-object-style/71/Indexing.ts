interface Foo<A, B> {
  [key: A]: B;
}
