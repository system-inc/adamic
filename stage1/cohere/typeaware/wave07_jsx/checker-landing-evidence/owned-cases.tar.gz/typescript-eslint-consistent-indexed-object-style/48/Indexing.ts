interface Foo {
  [key: string]: Bar;
}

interface Bar {
  [key: string];
}
