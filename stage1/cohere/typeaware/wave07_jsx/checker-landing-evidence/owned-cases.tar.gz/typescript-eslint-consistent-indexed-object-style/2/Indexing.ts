function foo(): { [key: string]: any } {}
