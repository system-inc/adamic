type Foo = Record<Exclude<'a' | 'b' | 'c', 'a'>, any>;
