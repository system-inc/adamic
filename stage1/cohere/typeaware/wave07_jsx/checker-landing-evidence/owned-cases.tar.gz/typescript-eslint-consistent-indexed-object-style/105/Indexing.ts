type Foo = { [key: string]: string } | Foo;
