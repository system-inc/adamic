interface Foo {
  [k: string]: A.Foo;
}
