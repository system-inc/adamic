type Foo = Record<number, any>;
