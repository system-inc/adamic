interface Foo {
  [s: string]: {}[Foo];
}
