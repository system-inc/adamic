interface Foo {
  bar: string;
  [key: string]: any;
}
