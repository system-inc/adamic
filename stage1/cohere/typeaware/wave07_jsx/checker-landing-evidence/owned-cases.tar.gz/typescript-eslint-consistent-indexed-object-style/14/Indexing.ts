type Foo = Record<string, number, unknown>;
