type Foo = { [key: string] };
