type Foo = { [key in string]: Foo };
