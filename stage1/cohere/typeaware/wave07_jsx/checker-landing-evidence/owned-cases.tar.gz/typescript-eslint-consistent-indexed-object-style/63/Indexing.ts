interface Foo {}
