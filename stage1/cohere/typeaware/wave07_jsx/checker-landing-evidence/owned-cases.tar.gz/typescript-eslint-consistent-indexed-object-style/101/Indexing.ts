type Foo = { [key: string]: Foo } | Foo;
