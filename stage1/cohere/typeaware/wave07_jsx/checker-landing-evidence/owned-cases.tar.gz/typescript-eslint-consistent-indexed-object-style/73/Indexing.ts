interface Foo<A> {
  [key: string]: A;
}
