type Foo = { [] };
