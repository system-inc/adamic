interface B extends A {
  [index: number]: unknown;
}
