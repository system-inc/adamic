function foo(e: { readonly [key in PropertyKey]-?: key }) {}
