export /* kept */ interface Foo {
  [key: string]: number;
}
