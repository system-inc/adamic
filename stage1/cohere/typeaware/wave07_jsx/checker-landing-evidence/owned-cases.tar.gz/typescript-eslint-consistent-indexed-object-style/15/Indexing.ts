type Foo = Record<string>;
