type T = Record<string, number>;
