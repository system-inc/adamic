interface Foo {
  [key: string]: Foo[];
}
