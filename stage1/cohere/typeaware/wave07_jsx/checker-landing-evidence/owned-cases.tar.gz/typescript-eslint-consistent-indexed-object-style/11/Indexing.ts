type Foo = Record<string | number, any>;
