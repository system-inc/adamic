interface Foo<A = any> {
  [key: string]: A;
}
