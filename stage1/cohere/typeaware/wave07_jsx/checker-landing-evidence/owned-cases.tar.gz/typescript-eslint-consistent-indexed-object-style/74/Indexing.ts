interface Foo<A> {
  readonly [key: string]: A;
}
