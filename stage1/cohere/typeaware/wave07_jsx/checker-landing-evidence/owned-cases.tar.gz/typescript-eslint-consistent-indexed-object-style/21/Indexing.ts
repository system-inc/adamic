/** The widths. */
export interface Foo {
  [key: string]: number;
}
