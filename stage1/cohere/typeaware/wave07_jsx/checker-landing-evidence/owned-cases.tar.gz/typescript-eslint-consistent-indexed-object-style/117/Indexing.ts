type T = { [key in Foo]: key | number };
