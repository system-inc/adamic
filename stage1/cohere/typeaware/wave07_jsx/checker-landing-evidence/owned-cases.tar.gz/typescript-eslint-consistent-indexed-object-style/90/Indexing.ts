type Foo = {
  // preserve me
  [Key in 'a' | 'b']: number;
};
