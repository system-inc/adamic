interface Foo<A, B> {
  readonly [key: A]: B;
}
