type Foo = Generic<{ [key: string]: any }>;
