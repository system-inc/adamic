type Foo = Record<string, any>;
