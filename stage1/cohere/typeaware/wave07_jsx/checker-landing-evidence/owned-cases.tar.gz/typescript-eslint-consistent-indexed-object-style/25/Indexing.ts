export default interface Foo {
  [key: string]: unknown;
}
