function foo(e: { readonly [key in PropertyKey]-?: string }) {}
