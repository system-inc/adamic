type Foo = Generic<Record<string, any>>;
