export declare interface Foo<T> {
  [key: string]: T;
}
