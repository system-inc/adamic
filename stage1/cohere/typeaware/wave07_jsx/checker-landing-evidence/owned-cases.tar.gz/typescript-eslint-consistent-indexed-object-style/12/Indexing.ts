type Foo = Record<string, /* preserve me */ number>;
