type T = A.B;
