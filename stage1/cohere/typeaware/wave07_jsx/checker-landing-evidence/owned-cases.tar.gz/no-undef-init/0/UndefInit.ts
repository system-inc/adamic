await using foo = undefined
