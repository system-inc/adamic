using a = condition ? getDisposableResource() : undefined;
