let a = /**/undefined;
