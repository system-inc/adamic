var {a} = undefined;
