function f(undefined) { let foo = undefined; return foo; }
