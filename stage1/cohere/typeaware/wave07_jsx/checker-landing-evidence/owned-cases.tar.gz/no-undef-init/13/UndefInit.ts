let a = 1, b: string | undefined = undefined;
