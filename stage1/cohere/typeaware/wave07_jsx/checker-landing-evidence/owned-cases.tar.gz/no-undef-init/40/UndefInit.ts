{ let undefined = 5; var foo = undefined; }
