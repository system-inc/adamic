let a = undefined/* comment */;
