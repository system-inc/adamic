const foo = undefined
