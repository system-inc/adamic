var undefined = 5;
let a = undefined;
