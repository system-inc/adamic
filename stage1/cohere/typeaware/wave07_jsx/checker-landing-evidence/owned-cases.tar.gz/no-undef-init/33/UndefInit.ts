var a = 1, b = undefined, c = 5;
