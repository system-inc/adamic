let a: Array<{x: number}> | undefined = undefined;
