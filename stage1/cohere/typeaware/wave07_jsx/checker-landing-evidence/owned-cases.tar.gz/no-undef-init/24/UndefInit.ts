let a: number | undefined = undefined, b = 1;
