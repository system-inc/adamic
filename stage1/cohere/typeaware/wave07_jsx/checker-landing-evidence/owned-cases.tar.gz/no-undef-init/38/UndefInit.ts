var undefined = 5; var foo = undefined;
