let a /**/ = undefined;
