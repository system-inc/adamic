let a/**/ = undefined;
