var a = undefined, b = 1;
