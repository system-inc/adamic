function f() { let foo = undefined; return foo; }
