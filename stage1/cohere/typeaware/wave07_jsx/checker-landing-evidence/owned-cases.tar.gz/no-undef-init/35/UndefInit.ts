var a = undefined;
