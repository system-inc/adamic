let a = undefined, b = 1;
