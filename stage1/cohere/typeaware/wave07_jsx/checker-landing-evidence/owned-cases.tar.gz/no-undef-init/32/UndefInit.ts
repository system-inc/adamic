var [a] = undefined;
