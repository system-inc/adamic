let aLongName = undefined, b = 1;
