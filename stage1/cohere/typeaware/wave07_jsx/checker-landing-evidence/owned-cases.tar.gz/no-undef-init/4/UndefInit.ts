for(var i in [1,2,3]){var a = undefined; for(var j in [1,2,3]){}}
