let [a] = undefined;
