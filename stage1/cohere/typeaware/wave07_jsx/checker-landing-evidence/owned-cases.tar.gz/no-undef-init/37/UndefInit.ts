var undefined = 5; let foo = undefined;
