let {a} = undefined;
