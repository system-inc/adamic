class C { field = undefined; }
