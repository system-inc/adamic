using foo = undefined
