let /* comment */a = undefined;
