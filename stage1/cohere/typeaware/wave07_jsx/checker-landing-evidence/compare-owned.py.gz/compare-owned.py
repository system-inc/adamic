import pathlib,json,time,subprocess,re,hashlib,shutil,sys
log=pathlib.Path('/workspace/lint-wave07-unpark-final/events.jsonl')
out=pathlib.Path('/workspace/lint-wave07-owned-comparison');out.mkdir(exist_ok=True)
wanted=['no-undef-init','@typescript-eslint/prefer-for-of','@typescript-eslint/consistent-indexed-object-style','prefer-rest-params','prefer-promise-reject-errors','react/jsx-no-undef']
while True:
 for module in pathlib.Path('/tmp/adamic-gate').glob('TestRulesAgree*/*/lint.mjs'):
  shutil.copyfile(module,out/'port.js')
 native=None; root=None
 for line in log.read_text().splitlines():
  e=json.loads(line);s=e.get('Output','')
  if e.get('Test')=='TestRulesAgree':
   m=re.search(r'(/tmp/adamic-gate/adamic-lint-native-[0-9]+/scanner)',s)
   if m:native=m[1]
 for p in pathlib.Path('/tmp/adamic-gate').glob('lint-shared-*/*/overlay.json'):
  try:j=json.loads(p.read_text())
  except:continue
  if any('/workspace/lint-wave07-unpark/stage1/cohere/lint/.generated/registry.go'==v for v in j.get('Replace',{}).values()):root=p.parent.parent;oracle=p.parent/'oracle'
 if native and root and list(root.glob('upstream-1723538042/capture/*.jsonl')):break
 time.sleep(3)
shutil.copy2(native,out/'scanner');shutil.copy2(oracle,out/'oracle')
records={}
for p in root.glob('upstream-1723538042/capture/*.jsonl'):
 shutil.copyfile(p,out/p.name)
 for line in p.read_text().split('\n'):
  if not line:continue
  j={k.capitalize():v for k,v in json.loads(line).items()}
  if j['Rule'] in wanted: records[(j['Rule'],j['File'],json.dumps(j.get('Options'),sort_keys=True),j['Source'])]=j
results=[]
runner='/workspace/lint-wave07-unpark/oracle/node.mjs';entry='/workspace/lint-wave07-unpark/stage1/cohere/lint/main.ts'
for name in wanted:
 cases=[j for k,j in sorted(records.items()) if j['Rule']==name]; verdict={'rule':name,'cases':len(cases),'pass':0,'fail':[],'seconds':{}}
 for i,j in enumerate(cases):
  case=out/name.replace('/','-').replace('@','')/str(i);case.mkdir(parents=True,exist_ok=True)
  source=case/pathlib.Path(j['File']).name;source.write_text(j['Source']);config=case/'tsconfig.json';config.write_text(json.dumps({'compilerOptions':{'strict':True},'files':[str(source)]}))
  manifest=case/'manifest';manifest.write_text('program '+str(config)+'\n'+str(source)+'\t'+name+'\t\t\tfalse\t'+json.dumps(j.get('Options'))+'\t\n');prefix=case/'replay'
  commands={'Go':[str(out/'oracle'),'--manifest',str(manifest)],'native':[str(out/'scanner'),'--manifest',str(manifest),'--record',str(prefix)]}
  outputs={}; failed=None
  for side,cmd in commands.items():
   start=time.monotonic()
   with (case/(side+'.out')).open('w') as stdout,(case/(side+'.err')).open('w') as stderr:run=subprocess.run(cmd,stdout=stdout,stderr=stderr)
   verdict['seconds'][side]=verdict['seconds'].get(side,0)+time.monotonic()-start
   outputs[side]=(case/(side+'.out')).read_bytes()
   if run.returncode or (case/(side+'.err')).stat().st_size:failed=side+' exited '+str(run.returncode);break
  if not failed:
   for side,entrypoint in [('Node',entry),('emitted',str(out/'port.js'))]:
    cmd=['node','--disable-warning=ExperimentalWarning',runner,entrypoint,'--manifest',str(manifest),'--replay',str(prefix)];start=time.monotonic()
    with (case/(side+'.out')).open('w') as stdout,(case/(side+'.err')).open('w') as stderr:run=subprocess.run(cmd,stdout=stdout,stderr=stderr)
    verdict['seconds'][side]=verdict['seconds'].get(side,0)+time.monotonic()-start;outputs[side]=(case/(side+'.out')).read_bytes()
    if run.returncode or (case/(side+'.err')).stat().st_size:failed=side+' exited '+str(run.returncode);break
  if not failed:
   for side,data in outputs.items():
    if data!=outputs['Go']:failed=side+' differs';break
  if failed:verdict['fail'].append({'case':str(case),'reason':failed,'source':j['Source']})
  else:verdict['pass']+=1
  print(name,i+1,len(cases),failed or 'identical',flush=True)
 results.append(verdict);(out/'receipt.json').write_text(json.dumps(results,indent=2)+'\n')
