foo(bar || function() { this; }.bind(this));
