RegExp('\1(a)')
