function f() { throw; }
