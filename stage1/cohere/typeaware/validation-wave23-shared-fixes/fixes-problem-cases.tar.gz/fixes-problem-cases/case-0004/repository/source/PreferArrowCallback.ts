foo(function() {}.bind(this).bind(obj))
