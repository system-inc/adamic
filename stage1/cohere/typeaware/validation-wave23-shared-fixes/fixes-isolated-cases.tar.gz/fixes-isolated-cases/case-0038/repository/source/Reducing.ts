import { Reducable } from './class';

new Reducable().reduce(() => {}, 1 as any);
