[1, 2, 3]?.reduce<number[]>((a, s) => a.concat(s * 2), []);
