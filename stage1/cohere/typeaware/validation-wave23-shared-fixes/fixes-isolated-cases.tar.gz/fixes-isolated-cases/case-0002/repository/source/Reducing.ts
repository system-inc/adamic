['a', 'b'].reduce(
  (accum, name) => ({
    ...accum,
    [name]: true,
  }),
  { a: true, b: false, c: true } as Record<'a' | 'b', boolean>,
);
