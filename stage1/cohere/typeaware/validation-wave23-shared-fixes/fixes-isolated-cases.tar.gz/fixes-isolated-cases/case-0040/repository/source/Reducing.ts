type Reducer = { reduce: (callback: (arg: any) => any, arg: any) => any };
declare const arrayOrReducer: number[] & Reducer;
arrayOrReducer.reduce(a => {
  return a.concat(1);
}, [] as number[]);
