function f<T extends Record<string, boolean>>(t: T) {
  ['a', 'b'].reduce(
    (accum, name) => ({
      ...accum,
      [name]: true,
    }),
    t as Record<string, boolean | number>,
  );
}
