declare const a: number[];
a.reduceRight((x, s) => x.concat(s), [] as number[]);
