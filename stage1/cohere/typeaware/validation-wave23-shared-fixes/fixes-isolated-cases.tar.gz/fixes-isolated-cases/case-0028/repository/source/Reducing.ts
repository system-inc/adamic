declare const a: readonly number[];
a.reduce((x, s) => x.concat(s), [] as number[]);
