['a', 'b'].reduce((accum, name) => `${accum} | hello ${name}!`);
