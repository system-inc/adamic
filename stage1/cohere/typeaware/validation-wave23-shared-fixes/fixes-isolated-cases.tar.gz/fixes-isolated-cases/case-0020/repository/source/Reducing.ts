declare const a: number[];
a.reduce((x, s) => x.concat(s), ([] as number[]));
