declare const arr: string[];
arr.reduce<string | undefined>(acc => acc, arr.shift() as string | undefined);
