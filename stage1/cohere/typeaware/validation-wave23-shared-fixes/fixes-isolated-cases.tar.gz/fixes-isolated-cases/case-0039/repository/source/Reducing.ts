new (class Mine {
  reduce() {}
})().reduce(() => {}, 1 as any);
