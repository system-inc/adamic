[1, 2, 3]['reduce']((sum, num) => sum + num, 0);
