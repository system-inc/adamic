declare const a: number[];
a.reduce((x, s) => x + s);
