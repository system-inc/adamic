function f<T extends Record<string, boolean>>() {
  ['a', 'b'].reduce(
    (accum, name) => ({
      ...accum,
      [name]: true,
    }),
    {} as T,
  );
}
