type Reducer = { reduce: (callback: (arg: any) => any, arg: any) => any };
declare const tuple: [number, number, number] | Reducer;
tuple.reduce(a => {
  return a.concat(1);
}, [] as number[]);
