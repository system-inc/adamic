class Mine {
  reduce() {}
}

new Mine().reduce(() => {}, 1 as any);
