[1, 2, 3]?.reduce((a, s) => a.concat(s * 2), <number[]>[]);
