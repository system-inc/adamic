[1, 2, 3][null]((sum, num) => sum + num, 0);
