declare const a: number[];
const reduceKey = 'reduce';
a[reduceKey]((x, s) => x.concat(s), [] as number[]);
