await new X
export{}