const value=<div><button /><span /></div>;
export {};
