declare const React:any;const value=React.createElement("div",null,[React.createElement("a"),"x",React.createElement("span")]);
export {};
