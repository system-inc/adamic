declare const React:any;const value=React.createElement("div",null,[React.createElement("a"),"\ufeff",React.createElement("span")]);
export {};
