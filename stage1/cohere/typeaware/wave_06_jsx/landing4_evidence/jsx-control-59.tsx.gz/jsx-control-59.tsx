declare const React:any;const value=React.createElement("div",null,[React.createElement("a"),"\u0085",React.createElement("span")]);
export {};
