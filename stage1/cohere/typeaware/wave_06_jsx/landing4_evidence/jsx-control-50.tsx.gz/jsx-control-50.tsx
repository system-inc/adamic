const value=<div><textarea /><span /></div>;
export {};
