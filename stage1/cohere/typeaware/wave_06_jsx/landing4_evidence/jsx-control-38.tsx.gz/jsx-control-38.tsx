const value=<div><img /><span /></div>;
export {};
