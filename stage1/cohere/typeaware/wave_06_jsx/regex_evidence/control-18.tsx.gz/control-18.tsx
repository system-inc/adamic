const value=<this.foo />;
export {};
