declare const React:any;const value=<React.Fragment key="k" />;
export {};
