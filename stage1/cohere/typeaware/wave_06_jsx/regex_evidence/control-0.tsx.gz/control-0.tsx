declare const React:any;const value=<React.Fragment />;
export {};
