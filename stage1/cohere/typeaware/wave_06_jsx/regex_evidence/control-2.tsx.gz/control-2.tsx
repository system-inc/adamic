declare const React:any;const value=<React.Fragment></React.Fragment>;
export {};
