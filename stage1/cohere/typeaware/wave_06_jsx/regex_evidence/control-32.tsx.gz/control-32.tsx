const value=<div><strong /><span /></div>;
export {};
