declare const React:any;declare const require:any;const F=require('react');const value=<F />;
export {};
