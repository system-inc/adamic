declare const React:any;declare const require:any;const {NotFragment:F}=React;const value=<F />;
export {};
