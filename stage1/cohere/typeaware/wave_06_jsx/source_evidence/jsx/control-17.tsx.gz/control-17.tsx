const value=<app.Foo.Bar />;
export {};
