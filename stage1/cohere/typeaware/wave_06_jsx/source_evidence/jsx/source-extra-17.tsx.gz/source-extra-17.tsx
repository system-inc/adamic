declare const React:any;declare const require:any;const value=React.createElement("div",null,[0,React.createElement("span")]);
export {};
