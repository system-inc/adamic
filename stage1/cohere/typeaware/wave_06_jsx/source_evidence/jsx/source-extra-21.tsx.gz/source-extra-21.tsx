declare const React:any;declare const require:any;const value=React.createElement("div",null,[null,React.createElement("span")]);
export {};
