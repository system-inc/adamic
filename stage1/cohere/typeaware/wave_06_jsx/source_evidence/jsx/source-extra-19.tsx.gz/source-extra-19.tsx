declare const React:any;declare const require:any;const value=React.createElement("div",null,[true,React.createElement("span")]);
export {};
