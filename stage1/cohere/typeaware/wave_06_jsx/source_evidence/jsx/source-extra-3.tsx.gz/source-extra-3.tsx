declare const React:any;declare const require:any;import {createElement} from 'other';const value=createElement('div',null,[createElement('a'),createElement('span')]);
export {};
