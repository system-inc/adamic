declare const React:any;declare const require:any;const {Fragment:F}=require('react');const value=<F />;
export {};
