declare const React:any;declare const require:any;const createElement=require('other').createElement;const value=createElement('div',null,[React.createElement('a'),React.createElement('span')]);
export {};
