declare const React:any;declare const require:any;const F=React.Fragment;const value=<F key='k' />;
export {};
