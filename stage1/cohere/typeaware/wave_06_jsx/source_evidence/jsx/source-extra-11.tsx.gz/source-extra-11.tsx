declare const React:any;declare const require:any;const F=React.NotFragment;const value=<F />;
export {};
