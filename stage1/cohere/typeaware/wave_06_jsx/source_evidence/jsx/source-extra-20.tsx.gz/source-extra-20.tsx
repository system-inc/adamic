declare const React:any;declare const require:any;const value=React.createElement("div",null,[false,React.createElement("span")]);
export {};
