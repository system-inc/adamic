declare const React:any;const value=<React.Other />;
export {};
