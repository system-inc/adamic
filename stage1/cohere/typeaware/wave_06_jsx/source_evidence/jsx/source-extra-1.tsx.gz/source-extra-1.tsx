declare const React:any;declare const require:any;import {"createElement" as createElement} from "react";const value=createElement("div",null,[React.createElement("a"),React.createElement("span")]);
export {};
