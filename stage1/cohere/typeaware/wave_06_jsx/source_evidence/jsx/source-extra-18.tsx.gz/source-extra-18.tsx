declare const React:any;declare const require:any;const value=React.createElement("div",null,[1n,React.createElement("span")]);
export {};
