import pathlib,json,subprocess,time
S=pathlib.Path('/workspace/wave-06-jsx-named-kinds');OUT=pathlib.Path('/workspace/wave-06-jsx-final-replay');OUT.mkdir(exist_ok=True);rows=[]
normalize=lambda data:b'\n'.join(line for line in data.splitlines() if not line.startswith((b'cohere:',b'tsgo:',b'go: tsgo:',b'node:')))
for record in ['runs.json','all-source-runs.json','source-runs.json','undef-source-runs.json']:
 for row in json.loads((S/record).read_text()):
  name=row['name'];cmd=row['command']
  if 'build' in name or 'archive' in name or name in ['emit-js','source-js','corpus-js']:continue
  label=record.removesuffix('.json')+'-'+name;start=time.monotonic()
  with (OUT/(label+'.stdout')).open('wb') as out,(OUT/(label+'.stderr')).open('wb') as err:r=subprocess.run(cmd,cwd='/workspace/adamic',stdout=out,stderr=err)
  assert r.returncode==row['exit'],(label,r.returncode,row['exit']);baseline='source-go' if record=='source-runs.json' and name in ['source-go','source-native','source-asan','source-node','source-emitted'] else name;assert (OUT/(label+'.stdout')).read_bytes()==(S/(baseline+'.stdout')).read_bytes(),label
  assert normalize((OUT/(label+'.stderr')).read_bytes())==normalize((S/(name+'.stderr')).read_bytes()),label
  rows.append(dict(name=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-start));print(label,'PASS',flush=True)
(OUT/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS',len(rows),'JSX final-base process comparisons; compiler inputs unchanged since fresh builds',flush=True)
