type Dispatch<S>=(value:S)=>void;declare function useState(v:number):[number,Dispatch<number>];declare function useEffect(fn:()=>void):void;declare function useMemo(fn:()=>number):number;function Component(){const[x,setX]=useState(0);useEffect(()=>{setX(1)});return x;}
export {};
