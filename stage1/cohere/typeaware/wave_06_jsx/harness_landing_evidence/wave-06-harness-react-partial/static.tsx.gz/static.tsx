function Component(){const Inner = () => null;return <Inner/>;}
export {};
