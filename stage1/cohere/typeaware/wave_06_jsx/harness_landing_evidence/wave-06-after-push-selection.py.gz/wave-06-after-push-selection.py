import subprocess,pathlib,json,re
root=pathlib.Path('/workspace/adamic');rank={}
for name in ['compiler','repository']:
 for line in (root/f'stage1/cohere/typeaware/validation-volume/{name}-all.counts').read_text().splitlines():
  fields=line.split('\t')
  if len(fields)==2 and fields[1].isdigit():rank[fields[0]]=rank.get(fields[0],0)+int(fields[1])
refs=subprocess.check_output(['git','for-each-ref','--format=%(refname)','refs/remotes/origin'],text=True,cwd=root).splitlines();blobs={}
for ref in refs:
 for row in subprocess.check_output(['git','ls-tree','-r',ref,'--','stage1/cohere/typeaware/claims/'],text=True,cwd=root).splitlines():
  header,path=row.split('\t',1)
  if path.endswith('.md'):blobs.setdefault(header.split()[2],[]).append((ref,path))
claimed=set()
for sha in blobs:
 text=subprocess.check_output(['git','cat-file','blob',sha],cwd=root).decode('utf-8',errors='replace')
 for key in rank:
  if key in text:claimed.add(key)
ported=set()
for ref in ['origin/main','origin/codex/tsgo-c-library']:
 for row in subprocess.check_output(['git','ls-tree','-r',ref,'--','stage1/cohere/typeaware/'],text=True,cwd=root).splitlines():
  header,path=row.split('\t',1)
  if not path.endswith(('.a','.ts')) or '/testdata/' in path or '/claims/' in path or '/validation' in path:continue
  text=subprocess.check_output(['git','cat-file','blob',header.split()[2]],cwd=root).decode('utf-8',errors='replace')
  for key in rank:
   if re.search(r'[\'\"]'+re.escape(key)+r'[\'\"]',text) or (key.startswith('@typescript-eslint/') and re.search(r'[\'\"]'+re.escape(key.split('/',1)[1])+r'[\'\"]',text)):ported.add(key)
remaining=sorted(set(rank)-claimed-ported,key=lambda key:(-rank[key],key));result=dict(refs=len(refs),claim_blobs=len(blobs),ranked=len(rank),claimed=len(claimed),ported=len(ported),remaining=remaining,ranking={key:rank[key] for key in remaining});pathlib.Path('/workspace/wave-06-after-push-selection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));print('main',subprocess.check_output(['git','rev-parse','origin/main'],text=True,cwd=root).strip());print('own',subprocess.check_output(['git','rev-parse','origin/codex/typeaware-wave-06'],text=True,cwd=root).strip())
