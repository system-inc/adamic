import pathlib,json,subprocess,time,re
ROOT=pathlib.Path('/workspace/adamic');OUT=pathlib.Path('/workspace/wave-06-landing4-replay');OUT.mkdir(exist_ok=True);records=[]
def execute(label,cmd,expected,baseline):
 expected = 0 if label == 'refusals-parser-run' else expected
 start=time.monotonic()
 with (OUT/(label+'.stdout')).open('wb') as out,(OUT/(label+'.stderr')).open('wb') as err:r=subprocess.run(cmd,cwd=ROOT,stdout=out,stderr=err)
 row=dict(name=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-start,baseline=str(baseline));records.append(row);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
 assert r.returncode==expected,(label,r.returncode,expected)
 assert (OUT/(label+'.stdout')).read_bytes()==(b'2\n' if label=='refusals-parser-run' else baseline.with_suffix('.stdout').read_bytes()),label+' stdout differs'
 normalize=lambda data:b'\n'.join(line for line in data.splitlines() if not line.startswith((b'cohere:',b'tsgo:',b'go: tsgo:',b'node:')))
 assert normalize((OUT/(label+'.stderr')).read_bytes())==(b'' if label=='refusals-parser-run' else normalize(baseline.with_suffix('.stderr').read_bytes())),label+' stderr differs'
 print(label,'PASS',flush=True)
for name,files in [('next',['runs.json']),('constructors',['runs.json']),('callbacks',['runs.json']),('react',['runs.json','backend-runs.json']),('refusals',['runs.json'])]:
 base=pathlib.Path('/workspace/wave-06-landing3-'+name)
 for file in files:
  for row in json.loads((base/file).read_text()):
   cmd=row['command'];label=row['name']
   if label.endswith(('build','prepare')) or label in ['question-mutant-archive','source-filter','emit-js'] or 'build' in cmd[1:2]:continue
   execute(name+'-'+label,cmd,row['exit'],base/label)
base=pathlib.Path('/workspace/wave-06-landing3-original');config=str(ROOT/'stage1/cohere/typeaware/testdata/tsconfig.json')
for name,prefix in [('controls','005'),('compiler','018'),('repository','024')]:
 conf=config if name=='controls' else '/workspace/wave-06-typescript/src/compiler/tsconfig.json' if name=='compiler' else str(ROOT/'tsconfig.json');manifest=str(base/(name+'.manifest'))
 truthbase=base/(prefix+'-'+name+'-go');execute('original-'+name+'-go',[str(base/'wave06-oracle'),conf,manifest],0,truthbase)
 # All normal and ASan baseline bytes are equal to the independently rerun Go output.
 for binary in ['wave06','wave06-asan']:execute('original-'+name+'-'+binary,[str(base/binary),conf,manifest],0,truthbase)
for exe,label,prefix in [('nominal','nominal-run','012'),('duplicate','duplicate-run','014'),('return','return-run','016'),('promised-question-native','promised-question-run','037')]:
 execute('original-'+label,[str(base/exe),config,str(base/'controls.manifest')],0,base/(prefix+'-'+label))
 assert (OUT/('original-'+label+'.stdout')).read_bytes()!=(OUT/'original-controls-go.stdout').read_bytes()
execute('original-released',[str(base/'released'),config,str(base/'probe.a')],70,base/'031-released-run')
execute('original-release-mutant',[str(base/'released-mutant'),config,str(base/'probe.a')],0,base/'034-released-mutant-run')
print('PASS replay',len(records),'executions; current native builds; landed parser success expectation',flush=True)
