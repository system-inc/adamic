declare const React:any;declare const require:any;const value=(React.createElement)("div",null,[React.createElement("a"),React.createElement("span")]);
export {};
