declare const React:any;declare const require:any;const {createElement}=React;const value=createElement('div',null,[React.createElement('a'),React.createElement('span')]);
export {};
