declare const React:any;declare const require:any;const {Fragment:F}=require('other');const value=<F />;
export {};
