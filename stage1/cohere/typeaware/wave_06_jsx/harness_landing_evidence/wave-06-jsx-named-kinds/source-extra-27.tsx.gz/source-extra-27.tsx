declare const React:any;declare const require:any;import {createElement} from "react";declare function createElement(a:string):void;const value=createElement("div",null,[React.createElement("a"),React.createElement("span")]);
export {};
