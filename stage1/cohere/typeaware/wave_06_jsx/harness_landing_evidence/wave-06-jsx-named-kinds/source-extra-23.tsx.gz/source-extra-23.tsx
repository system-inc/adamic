declare const React:any;declare const require:any;const value=React.createElement("div",null,[`x`,React.createElement("span")]);
export {};
