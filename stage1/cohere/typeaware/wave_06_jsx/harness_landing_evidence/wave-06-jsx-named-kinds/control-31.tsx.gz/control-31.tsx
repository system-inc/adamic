const value=<div><kbd /><span /></div>;
export {};
