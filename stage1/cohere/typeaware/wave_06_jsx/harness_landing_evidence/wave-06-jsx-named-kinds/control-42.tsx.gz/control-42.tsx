const value=<div><script /><span /></div>;
export {};
