declare const React:any;declare const require:any;/* 🦊한 */const value=<div><a/><span/></div>;
export {};
