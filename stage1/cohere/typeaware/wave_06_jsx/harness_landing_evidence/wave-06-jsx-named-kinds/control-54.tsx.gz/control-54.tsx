declare const React:any;const value=React.createElement("div",null,[React.createElement("a"),"",React.createElement("span")]);
export {};
