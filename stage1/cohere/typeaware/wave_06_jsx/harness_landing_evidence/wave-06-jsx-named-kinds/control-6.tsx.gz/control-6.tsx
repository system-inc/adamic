declare const React:any;const F=React.Fragment;const value=<F />;
export {};
