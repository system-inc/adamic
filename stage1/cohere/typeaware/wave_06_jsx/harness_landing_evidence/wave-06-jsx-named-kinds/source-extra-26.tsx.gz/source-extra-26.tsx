declare const React:any;declare const require:any;declare function createElement(a:string):void;import {createElement} from "react";const value=createElement("div",null,[React.createElement("a"),React.createElement("span")]);
export {};
