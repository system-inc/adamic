declare const React:any;import {Fragment as F} from 'react';const value=<F />;
export {};
