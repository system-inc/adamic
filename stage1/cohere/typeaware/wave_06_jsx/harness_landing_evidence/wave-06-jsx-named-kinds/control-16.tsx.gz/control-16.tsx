const value=<app.Foo />;
export {};
