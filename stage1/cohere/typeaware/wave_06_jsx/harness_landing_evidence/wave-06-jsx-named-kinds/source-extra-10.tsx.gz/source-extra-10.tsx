declare const React:any;declare const require:any;const F=React;const value=<F />;
export {};
