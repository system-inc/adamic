declare const React:any;declare const require:any;import {"Fragment" as F} from "react";const value=<F />;
export {};
