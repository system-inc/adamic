import pathlib,json,subprocess,time,statistics
S=pathlib.Path('/workspace/wave-06-jsx-named-kinds');rows=[]
for corpus,config in [('compiler','/workspace/wave-06-typescript/src/compiler/tsconfig.json'),('repository','/workspace/adamic/tsconfig.json')]:
 manifest=S/(corpus+'-all-source.manifest');truth=(S/(corpus+'-all-source-go.stdout')).read_bytes();values={'go':[],'native':[]}
 for round in range(3):
  for engine in (['go','native'] if round%2==0 else ['native','go']):
   command=[str(S/('oracle' if engine=='go' else 'all-corpus-native')),config,str(manifest)];label=f'timing-{corpus}-{round}-{engine}';start=time.monotonic()
   with (S/(label+'.stdout')).open('wb') as out,(S/(label+'.stderr')).open('wb') as err:result=subprocess.run(command,stdout=out,stderr=err)
   elapsed=time.monotonic()-start;assert result.returncode==0;assert (S/(label+'.stdout')).read_bytes()==truth;values[engine].append(elapsed)
   rows.append(dict(corpus=corpus,engine=engine,round=round,seconds=elapsed,command=command))
 medians={engine:statistics.median(times) for engine,times in values.items()};print(corpus,medians,'native/go',medians['native']/medians['go'],flush=True)
(S/'source-timing.json').write_text(json.dumps(rows,indent=2)+'\n')
