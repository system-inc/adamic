import pathlib,json,subprocess,time,concurrent.futures
ROOT=pathlib.Path('/workspace/adamic');OUT=pathlib.Path('/workspace/wave-06-named-rebuild');OUT.mkdir(exist_ok=True);compiler='/workspace/wave-06-jsx-named-final/adamic';jobs=[]
for suite,logs in [('next',['runs.json']),('constructors',['runs.json']),('callbacks',['runs.json']),('react',['runs.json','backend-runs.json']),('refusals',['runs.json'])]:
 base=pathlib.Path('/workspace/wave-06-landing3-'+suite)
 for log in logs:
  for row in json.loads((base/log).read_text()):
   cmd=row['command']
   if len(cmd)>1 and cmd[1]=='build' and pathlib.Path(cmd[0]).name=='adamic':jobs.append((suite+'-'+row['name'],[compiler]+cmd[1:]))
base=pathlib.Path('/workspace/wave-06-landing3-original');entry=ROOT/'stage1/cohere/typeaware/wave_06_suite.a'
for name,src,archive,sanitize in [('wave06',entry,'checker.a',False),('wave06-asan',entry,'checker-asan.a',True),('nominal',base/'nominal-source/wave_06_suite.a','checker.a',False),('duplicate',base/'duplicate-source/wave_06_suite.a','checker.a',False),('return',base/'return-source/wave_06_suite.a','checker.a',False),('released',base/'released.a','checker.a',False),('released-mutant',base/'released.a','released-registry.a',False),('promised-question-native',entry,'promised-question.a',False)]:jobs.append(('original-'+name,[compiler,'build',str(src),'-o',str(base/name),'--tsgo',str(base/archive)]+(['--sanitize'] if sanitize else [])))
def build(job):
 label,cmd=job;t=time.monotonic()
 with (OUT/(label+'.stdout')).open('wb') as out,(OUT/(label+'.stderr')).open('wb') as err:r=subprocess.run(cmd,cwd=ROOT,stdout=out,stderr=err)
 row=dict(name=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-t)
 print(label,r.returncode,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(build,jobs))
(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');assert all(row['exit']==0 for row in records),[row['name'] for row in records if row['exit']!=0]
print('PASS',len(records),'native rebuilds with current compiler; checker archives and prepared inputs reused',flush=True)
