const value=<_foo />;
export {};
