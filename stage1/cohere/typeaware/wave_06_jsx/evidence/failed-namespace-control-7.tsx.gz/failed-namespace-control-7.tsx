declare const React:any;const {Fragment:F}=React;const value=<F />;
export {};
