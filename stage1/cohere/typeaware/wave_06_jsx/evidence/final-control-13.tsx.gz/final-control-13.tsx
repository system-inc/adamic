const value=<$foo />;
export {};
