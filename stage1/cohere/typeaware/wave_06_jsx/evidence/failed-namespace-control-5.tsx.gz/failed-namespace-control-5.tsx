declare const React:any;import {Fragment as F} from 'preact';const value=<F />;
export {};
