declare const Known:any;const value=<Known />;
export {};
