const value=<div><object /><span /></div>;
export {};
