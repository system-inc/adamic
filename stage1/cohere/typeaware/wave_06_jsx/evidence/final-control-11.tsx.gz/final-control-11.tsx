const value=<Foo-bar />;
export {};
