declare const Ctx:any;function Widget(){return <Ctx.Provider value={{}} />;}
export {};
