const React = {Fragment:()=>null}; function Widget(){return <React.Fragment />;}
export {};
