// Overlay-only oracle exposes the unmodified production index.
package nexus

import (
	"fmt"
	"github.com/system-inc/cohere/internal/lint/rule"
	"sort"
	"strings"
)

func Wave09StreamsIndex(program rule.Program) string {
	index := correctnessRequireBlockingStandardStreamsBuildIndex(program)
	var paths []string
	for path := range index.files {
		if strings.HasPrefix(string(path), "/workspace/wave-09-next/index/") {
			paths = append(paths, string(path))
		}
	}
	sort.Strings(paths)
	var out strings.Builder
	for _, path := range paths {
		var keyPath string
		var imported, canBlock bool
		var targets []string
		for key := range index.files {
			if string(key) == path {
				keyPath = string(key)
				imported = index.imported[key]
				canBlock = index.canBlock[key]
				for _, target := range index.edges[key] {
					targets = append(targets, string(target))
				}
				break
			}
		}
		i, b := 0, 0
		if imported {
			i = 1
		}
		if canBlock {
			b = 1
		}
		fmt.Fprintf(&out, "%s\t%d\t%d\t%s\n", keyPath, i, b, strings.Join(targets, ";"))
	}
	return out.String()
}
