"""Isolated validation; does not modify shared registrations or harness files."""
import hashlib, json, os, pathlib, statistics, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parent
repo = root.parents[4]
work = pathlib.Path(os.environ.get("ADAMIC_WAVE09_NEXT_ARTIFACTS", "/workspace/wave-09-next"))
work.mkdir(parents=True, exist_ok=True)

def run(name, args, cwd=repo, env=None, expected=0):
    start = time.monotonic()
    with (work / (name + ".stdout")).open("wb") as out, (work / (name + ".stderr")).open("wb") as err:
        result = subprocess.run(list(map(str, args)), cwd=cwd, env=env, stdout=out, stderr=err)
    elapsed = time.monotonic() - start
    print(name, "exit", result.returncode, "seconds", round(elapsed, 6), flush=True)
    if result.returncode != expected:
        raise RuntimeError(f"{name}: expected {expected}, got {result.returncode}; see logs")
    return (work / (name + ".stdout")).read_bytes(), elapsed

def write(name, text):
    path = work / name
    path.write_text(text)
    return path

def archive(name, sanitized=False, retained=False, fact_mutant=False):
    shared = repo / "bridge/tsgo/checker/facts.go"
    text = shared.read_text()
    anchor = "switch mode {"
    assert text.count(anchor) == 1
    text = text.replace(anchor, anchor + '\n\tcase "declaration-ancestry": return p.declarationAncestry(c, node, question)')
    replacements = {str(shared): str(write(name + "-dispatch.go", text)),
                    str(repo / "bridge/tsgo/checker/wave09_declaration_ancestry.go"): str(root / "testdata/declaration_ancestry.go")}
    if retained:
        path = repo / "bridge/tsgo/archive/main.go"
        text = path.read_text()
        anchor = "delete(programs.live, uint64(handle))"
        assert text.count(anchor) == 1
        replacements[str(path)] = str(write(name + "-retained.go", text.replace(anchor, "// Mutant retains released handle.")))
    if fact_mutant:
        text = (root / "testdata/declaration_ancestry.go").read_text()
        anchor = "out.yes(file.IsDeclarationFile)"
        assert text.count(anchor) == 1
        replacements[str(repo / "bridge/tsgo/checker/wave09_declaration_ancestry.go")] = str(write(name + "-fact.go", text.replace(anchor, "out.yes(!file.IsDeclarationFile)")))
    overlay = write(name + "-overlay.json", json.dumps({"Replace": replacements}))
    output = work / (name + ".a")
    env = os.environ.copy()
    if sanitized:
        env.update(CC="clang", CGO_CFLAGS="-O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all")
    run(name + "-archive", ["go", "build", "-overlay", overlay, "-buildmode=c-archive", "-o", output, "./bridge/tsgo/archive"], env=env)
    return output

def build(name, source, library, sanitized=False):
    args = [work / "adamic", "build", source, "-o", work / name, "--tsgo", library]
    if sanitized: args.append("--sanitize")
    run(name + "-build", args)
    return work / name

def compare(name, oracle, native, config, manifest):
    want, go_time = run(name + "-go", [oracle, config, manifest])
    got, native_time = run(name + "-native", [native, config, manifest])
    assert not (work / (name + "-native.stderr")).read_bytes(), "native stderr is not empty"
    if got != want:
        diff = next((i for i, (a,b) in enumerate(zip(got,want)) if a != b), min(len(got),len(want)))
        raise AssertionError(f"{name} byte {diff}: native {got[max(0,diff-30):diff+200]!r}; Go {want[max(0,diff-30):diff+200]!r}")
    print(name, "identical bytes", len(want), want.splitlines()[-1], flush=True)
    return want, native_time, go_time

run("stage0", ["go", "build", "-o", work / "adamic", "./cmd/adamic"])
library = archive("checker")
native = build("timeout", root / "main.a", library)
virtual = repo / "cohere/adamic_wave09_next_oracle.go"
overlay = write("oracle-overlay.json", json.dumps({"Replace": {str(virtual): str(root / "testdata/oracle.go")}}))
run("oracle-build", ["go", "build", "-overlay", overlay, "-o", work / "oracle", virtual], cwd=repo / "cohere")
oracle = work / "oracle"
run("fixtures-build", ["go", "build", "-o", work / "fixtures", root / "testdata/fixtures.go"])
fixtures,_ = run("fixtures", [work / "fixtures", repo / "cohere/internal/lint/rules/nexus/correctness_no_uncleared_race_timeout_test.go"])
sources = [source for source in json.loads(fixtures) if "export async function" in source or "export function" in source]
prelude = "declare function work():Promise<string>;declare function use(value:unknown):void;declare function timeoutAfter(ms:number):Promise<never>;declare const milliseconds:number;\n"
sources += [
 "export async function f(){return Promise.race([work(),new Promise((_r,reject)=>setTimeout(reject,1))]);}",
 "export async function f(){const p=new Promise((_r,reject)=>{setTimeout(reject,1);});return Promise.race([p,p]);}",
 "export async function f(){let p=new Promise((_r,reject)=>{setTimeout(reject,1);});return Promise.race([p]);}",
 "export async function f(){let timer;return Promise.race([new Promise((_r,reject)=>{(timer)=setTimeout(reject,1);})]);}",
 "export async function f(){let timer;return Promise.race([new Promise((_r,reject)=>{timer=setTimeout(reject,1);use({timer});})]);}",
 "export async function f(){let timer;return Promise.race([new Promise((_r,reject)=>{timer=setTimeout(reject,1);{const timer=1;use(timer);}})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{const timer=setTimeout(reject,1);use(timer);})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{class C{m(){setTimeout(reject,1);}}})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{let timer;timer=setTimeout(reject,1);timer+=1;})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{let timer;let a;a=timer=setTimeout(reject,1);})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{window.setTimeout(reject,1);globalThis.setTimeout(reject,2);})]);}",
 "/* 世界 🌍 */\r\nexport async function 漢(){return Promise.race([new Promise((_r,reject)=>{void (setTimeout(reject,1));})]);}\r\n",
 "import {setTimeout} from './timers.js';export async function f(){return Promise.race([new Promise((_r,reject)=>{setTimeout(reject,1);})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{return setTimeout(reject,1);})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{const [timer]=[setTimeout(reject,1)];})]);}",
 "export async function f(){return Promise.race([new Promise((_r,reject)=>{setInterval(reject,1);})]);}",
]
write("timers.a", "export function setTimeout(fn:()=>void,ms:number){return ms;}\n")
paths = [str(write(f"control-{i:03}.a", prelude + source + "\nexport {};\n")) for i,source in enumerate(sources)]
config = write("tsconfig.json", json.dumps({"compilerOptions":{"strict":True,"target":"ES2022","module":"NodeNext","moduleResolution":"NodeNext","lib":["es2022","dom"]},"files":["timers.d.ts"]}))
write("timers.d.ts", "export {};declare global {namespace NodeJS {interface Timeout {unref():this}}function setTimeout<T extends any[]>(callback:(...args:T)=>void,delay?:number,...args:T):NodeJS.Timeout;namespace setTimeout {const __promisify__:unknown;}function clearTimeout(timer:unknown):void;}\n")
manifest = write("controls.manifest", "\n".join(paths)+"\n")
valid,_ = run("controls-filter", [oracle, config, manifest, "--valid-sources"])
manifest.write_bytes(valid)
truth,_,_ = compare("controls", oracle,native,config,manifest)
assert b"\tnexus/correctness-no-uncleared-race-timeout\t" in truth
sanitized_library = archive("checker-asan", True)
sanitized = build("timeout-asan",root / "main.a",sanitized_library,True)
compare("controls-asan",oracle,sanitized,config,manifest)

# A compiling semantic mutant that regards read timer handles as lost.
mutant_source = work / "mutant-source"
mutant_source.mkdir(exist_ok=True)
for path in root.glob("*.a"):
    text = path.read_text().replace("from '../../", "from '" + str(repo / "stage1/cohere/typeaware") + "/")
    text = text.replace(str(repo / "stage1/cohere/typeaware") + "/../../typescript/", str(repo / "stage1/typescript") + "/")
    if path.name == "correctness_no_uncleared_race_timeout.a":
        anchor = "this.identity(at) === facts.symbol && !this.assignmentTarget(at)"
        assert text.count(anchor)==1
        text = text.replace(anchor,"this.identity(at) !== facts.symbol && !this.assignmentTarget(at)")
    (mutant_source / path.name).write_text(text)
mutant = build("timeout-mutant",mutant_source / "main.a",library)
got,_ = run("timeout-mutant-run",[mutant,config,manifest])
assert got != truth and not (work / "timeout-mutant-run.stderr").read_bytes()
print("timeout mutant caught only by Go bytes",flush=True)
fact_library = archive("checker-fact-mutant",fact_mutant=True)
fact_mutant = build("fact-mutant",root / "main.a",fact_library)
got,_ = run("fact-mutant-run",[fact_mutant,config,manifest])
assert got != truth and not (work / "fact-mutant-run.stderr").read_bytes()
print("declaration ancestry mutant caught only by Go bytes",flush=True)

released = write("released.a", "import {programArguments,tsgoProgram,tsgoRelease,tsgoInspect} from 'adamic';const args=programArguments();const file=args[1]??'';const program=tsgoProgram(args[0]??'',[file]);tsgoRelease(program);console.log(tsgoInspect(program,file,0,1,'Identifier','declaration-ancestry'));\n")
probe = write("probe.a","x;\n")
stale = build("released",released,library)
run("released-run",[stale,config,probe],expected=70)
assert (work / "released-run.stderr").read_bytes()==b"adamic: panic: invalid or released checker handle\n"
retained = archive("checker-retained",retained=True)
stale_mutant = build("released-mutant",released,retained)
run("released-mutant-run",[stale_mutant,config,probe])
print("retained handle mutant caught by required panic 70",flush=True)
measurements={}
for corpus,corpus_config,corpus_manifest in [
 ("compiler",pathlib.Path('/workspace/TypeScript-050880ce59e30b356b686bd3144efe24f875ebc8/src/compiler/tsconfig.json'),pathlib.Path('/workspace/wave-09-validation/compiler.manifest')),
 ("repository",repo/'tsconfig.json',pathlib.Path('/workspace/wave-09-validation/repository.manifest'))]:
    compare(corpus,oracle,native,corpus_config,corpus_manifest)
    compare(corpus+"-asan",oracle,sanitized,corpus_config,corpus_manifest)
    measurements[corpus]=[]
    for round_ in range(3):
        expected,native_time,go_time=compare(f"{corpus}-bench-{round_}",oracle,native,corpus_config,corpus_manifest)
        measurements[corpus].append({"native":native_time,"go":go_time,"bytes":len(expected),"sha256":hashlib.sha256(expected).hexdigest()})
    print(corpus,"medians",statistics.median(x['native'] for x in measurements[corpus]),statistics.median(x['go'] for x in measurements[corpus]),flush=True)
write("measurements.json",json.dumps(measurements,indent=2)+"\n")
print("PASS timeout independent full bytes, mutants, stale handles, sanitizers",flush=True)
