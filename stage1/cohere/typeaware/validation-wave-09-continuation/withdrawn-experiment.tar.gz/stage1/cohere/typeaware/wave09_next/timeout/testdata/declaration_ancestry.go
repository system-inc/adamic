// Overlay-only checker extension. No lint verdicts or edits.
package checker

import (
	"fmt"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"strings"
)

func (p *Program) declarationAncestry(c *checker.Checker, node *ast.Node, question string) (string, error) {
	if question != "declaration-ancestry" || node.Kind != ast.KindIdentifier {
		return "", fmt.Errorf("declaration-ancestry requires an Identifier")
	}
	out := &fields{}
	out.number(1)
	out.text(question)
	symbol := c.GetSymbolAtLocation(node)
	out.number(p.symbolID(symbol))
	if symbol == nil {
		out.number(0)
		return out.String(), nil
	}
	out.number(uint64(len(symbol.Declarations)))
	for _, declaration := range symbol.Declarations {
		file := ast.GetSourceFileOfNode(declaration)
		out.yes(file != nil)
		if file != nil {
			out.text(file.FileName())
			out.yes(file.IsDeclarationFile)
			out.yes(p.Compiler.IsSourceFileDefaultLibrary(file.Path()))
			out.yes(ast.IsExternalModule(file))
		}
		var chain []*ast.Node
		for current := declaration; current != nil; current = current.Parent {
			chain = append(chain, current)
		}
		out.number(uint64(len(chain)))
		for _, current := range chain {
			out.text(strings.TrimPrefix(current.Kind.String(), "Kind"))
			name := ""
			if declared := current.Name(); declared != nil {
				name = declared.Text()
			}
			out.text(name)
			out.yes(ast.IsGlobalScopeAugmentation(current))
		}
	}
	return out.String(), nil
}
