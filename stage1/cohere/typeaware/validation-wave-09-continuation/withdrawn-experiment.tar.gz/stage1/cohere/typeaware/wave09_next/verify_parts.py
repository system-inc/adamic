"""Partial-implementation checks, not complete lint findings agreement."""
import json, os, pathlib, subprocess, time
base=pathlib.Path(__file__).resolve().parent
repo=base.parents[3]
work=pathlib.Path('/workspace/wave-09-next')

def run(name,args,cwd=repo,expected=0):
    start=time.monotonic()
    with (work/(name+'.stdout')).open('wb') as out,(work/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(list(map(str,args)),cwd=cwd,stdout=out,stderr=err)
    print(name,'exit',result.returncode,'seconds',round(time.monotonic()-start,6),flush=True)
    assert result.returncode==expected,name
    return (work/(name+'.stdout')).read_bytes()
def write(name,text):
    path=work/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text);return path

def compare(name,oracle,source,args=()):
    want=run(name+'-go',oracle)
    binary=work/name
    run(name+'-build',[work/'adamic','build',source,'-o',binary])
    got=run(name+'-native',[binary,*args])
    assert got==want,name+' bytes differ'
    sanitized=work/(name+'-asan')
    run(name+'-asan-build',[work/'adamic','build',source,'-o',sanitized,'--sanitize'])
    assert run(name+'-asan',[sanitized,*args])==want
    assert not (work/(name+'-asan.stderr')).read_bytes()
    javascript=run(name+'-js-build',[work/'adamic','js',source])
    js=work/(name+'.mjs');js.write_bytes(javascript)
    assert run(name+'-node',["node",js,*args])==want
    print(name,'Go/native/ASan/UBSan/LSan/emitted-JS identical bytes',len(want),flush=True)
    return want

replacements={str(repo/'cohere/internal/lint/rules/nexus/wave09_state_shim.go'):str(base/'process_exit/testdata/state_shim.go'),str(repo/'cohere/internal/lint/rules/nexus/wave09_index_shim.go'):str(base/'blocking_streams/testdata/index_shim.go')}
state_virtual=repo/'cohere/adamic_wave09_state.go'
replacements[str(state_virtual)]=str(base/'process_exit/testdata/state_oracle.go')
overlay=write('parts-overlay.json',json.dumps({'Replace':replacements}))
run('state-oracle-build',['go','build','-overlay',overlay,'-o',work/'state-oracle',state_virtual],cwd=repo/'cohere')
want=compare('state',[work/'state-oracle'],base/'process_exit/state_probe.a')
source=(base/'process_exit/correctness_no_process_exit_after_output.a').read_text()
anchor='!chain.includes(`,${tryId},`)';assert source.count(anchor)==1
mutant_dir=work/'state-mutant-source';mutant_dir.mkdir(exist_ok=True)
(mutant_dir/'correctness_no_process_exit_after_output.a').write_text(source.replace(anchor,'chain.includes(`,${tryId},`)'))
(mutant_dir/'state_probe.a').write_text((base/'process_exit/state_probe.a').read_text())
run('state-mutant-build',[work/'adamic','build',mutant_dir/'state_probe.a','-o',work/'state-mutant'])
assert run('state-mutant-run',[work/'state-mutant'])!=want
assert not (work/'state-mutant-run.stderr').read_bytes()
print('process-exit state mutant compiled, caught only by production Go state bytes; not full findings',flush=True)

index=work/'index';index.mkdir(exist_ok=True)
fixtures={
 'entry.js':"import './middle.js';export {};",
 'middle.js':"import './source/system/StandardStreams.js';export * from './source/system/StandardStreams.js';",
 'source/system/StandardStreams.d.ts':"export declare function blockStandardStreams():void;",
 'computed.js':"export const name='./elsewhere.js';import(name);",
 'importer.js':"import './computed.js';export {};",
 'self.js':"import './self.js';export {};",
 'cycle-a.js':"import './cycle-b.js';export {};",
 'cycle-b.js':"import './cycle-a.js';const path='x';require(path);export {};",
 'unrelated.js':"export {};",
}
for name,text in fixtures.items():write('index/'+name,text+'\n')
config=write('index/tsconfig.json',json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'NodeNext','moduleResolution':'NodeNext','allowJs':True,'noEmit':True},'files':list(fixtures)}))
manifest=write('index/roots.manifest','\n'.join(str(index/name) for name in fixtures)+'\n')
index_virtual=repo/'cohere/adamic_wave09_index.go'
replacements[str(index_virtual)]=str(base/'blocking_streams/testdata/index_oracle.go')
overlay=write('parts-overlay.json',json.dumps({'Replace':replacements}))
run('index-oracle-build',['go','build','-overlay',overlay,'-o',work/'index-oracle',index_virtual],cwd=repo/'cohere')
targets={'entry.js':['middle.js'],'middle.js':['source/system/StandardStreams.d.ts','source/system/StandardStreams.d.ts'],'importer.js':['computed.js'],'self.js':['self.js'],'cycle-a.js':['cycle-b.js'],'cycle-b.js':['cycle-a.js']}
rows=[]
for name in fixtures:
    edges=[str(index/t) for t in targets.get(name,[])]
    rows.append('new StreamsModule('+json.dumps(str(index/name))+','+('true' if name.endswith('.d.ts') else 'false')+','+('true' if name in ['computed.js','cycle-b.js'] else 'false')+','+json.dumps(edges)+')')
source="import { StreamsIndex, StreamsModule } from '"+str(base/'blocking_streams/correctness_require_blocking_standard_streams.a')+"';\nconst modules = ["+','.join(rows)+"];\nconsole.log(new StreamsIndex(modules).written().trimEnd());\n"
probe=write('index_probe.a',source)
want=compare('index',[work/'index-oracle',config,manifest,'--index'],probe)
text=(base/'blocking_streams/correctness_require_blocking_standard_streams.a').read_text()
text=text.replace("from '../../../../typescript/", "from '"+str(repo/'stage1/typescript')+'/')
anchor='this.canBlock.add(importer); queue.push(importer);';assert text.count(anchor)==1
mutant=write('index_mutant.a',text.replace(anchor,'queue.push(importer);'))
mutant_probe=write('index_mutant_probe.a',source.replace(str(base/'blocking_streams/correctness_require_blocking_standard_streams.a'),str(mutant)))
run('index-mutant-build',[work/'adamic','build',mutant_probe,'-o',work/'index-mutant'])
assert run('index-mutant-run',[work/'index-mutant'])!=want
assert not (work/'index-mutant-run.stderr').read_bytes()
print('blocking-stream index mutant compiled, caught only by production Go index bytes; not full findings',flush=True)
for name,path,func in [('process-exit',base/'process_exit/correctness_no_process_exit_after_output.a','requireOutputControlFlowAdapter'),('blocking-streams',base/'blocking_streams/correctness_require_blocking_standard_streams.a','requireStreamsProgramAdapter')]:
    refusal=write(name+'-refusal.a',"import { "+func+" } from '"+str(path)+"';"+func+"();\n")
    run(name+'-refusal-build',[work/'adamic','build',refusal,'-o',work/(name+'-refusal')])
    run(name+'-refusal-run',[work/(name+'-refusal')],expected=70)
print('PASS partial state/index checks; two complete lint ports remain blocked',flush=True)
