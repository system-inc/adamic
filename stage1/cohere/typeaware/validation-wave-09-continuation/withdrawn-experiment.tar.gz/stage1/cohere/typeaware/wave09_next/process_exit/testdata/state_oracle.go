package main

import (
	"fmt"
	nexus "github.com/system-inc/cohere/internal/lint/rules/nexus"
	"strings"
)

func main() {
	chains := []string{",", ",0,", ",1,", ",10,", ",0,1,", ",0,10,", ",1,10,", ",0,1,10,"}
	for _, first := range chains {
		for _, second := range chains {
			for _, third := range chains {
				for _, entered := range []int{-1, 0, 1, 10, 11} {
					state := nexus.Wave09WriteState(nil, first, -1)
					state = nexus.Wave09WriteState(state, second, -1)
					state = nexus.Wave09WriteState(state, third, entered)
					fmt.Println(strings.Join(state, ";"))
				}
			}
		}
	}
}
