package main

import (
	"encoding/json"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"strconv"
	"strings"
)

func main() {
	tree, err := parser.ParseFile(token.NewFileSet(), os.Args[1], nil, 0)
	if err != nil {
		panic(err)
	}
	var sources []string
	ast.Inspect(tree, func(node ast.Node) bool {
		lit, ok := node.(*ast.CompositeLit)
		if !ok {
			return true
		}
		array, ok := lit.Type.(*ast.ArrayType)
		if !ok {
			return true
		}
		name, ok := array.Elt.(*ast.Ident)
		if !ok || name.Name != "string" || len(lit.Elts) < 2 {
			return true
		}
		var lines []string
		for _, element := range lit.Elts {
			value, ok := element.(*ast.BasicLit)
			if !ok || value.Kind != token.STRING {
				return true
			}
			text, err := strconv.Unquote(value.Value)
			if err != nil {
				panic(err)
			}
			lines = append(lines, text)
		}
		sources = append(sources, strings.Join(lines, "\n"))
		return true
	})
	if err := json.NewEncoder(os.Stdout).Encode(sources); err != nil {
		panic(err)
	}
}
