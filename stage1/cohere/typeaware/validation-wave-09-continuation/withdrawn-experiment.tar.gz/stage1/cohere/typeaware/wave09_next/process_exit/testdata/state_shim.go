// Overlay-only external oracle exposes production private state methods unchanged.
package nexus

func Wave09WriteState(state []string, chain string, entered int) []string {
	result := correctnessNoProcessExitAfterOutputState(state).with(chain)
	if entered >= 0 {
		result = result.entering(entered)
	}
	return []string(result)
}
