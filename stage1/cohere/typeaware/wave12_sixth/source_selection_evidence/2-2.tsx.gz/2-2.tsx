export {}; declare const React: any; declare const A: any; declare const props: any;
/* 😀 Ω */ const x = <React.Fragment<T> />;
