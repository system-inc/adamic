export {};
/* 😀 Ω */ const x = <Ω />;
