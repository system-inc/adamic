export {}; const F = React.Fragment; const x = <F />;
