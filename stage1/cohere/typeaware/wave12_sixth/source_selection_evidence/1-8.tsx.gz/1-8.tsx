export {};
/* 😀 Ω */ const x = <this />;
