export {};
/* 😀 Ω */ const x = <Missing.Inner.Deep />;
