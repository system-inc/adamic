export {};
/* 😀 Ω */ const x = <lower.Inner />;
