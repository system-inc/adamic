export {};
/* 😀 Ω */ const x = <Missing<T> />;
