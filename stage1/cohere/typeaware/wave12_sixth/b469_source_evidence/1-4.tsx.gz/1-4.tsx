export {};
/* 😀 Ω */ const x = <div />;
