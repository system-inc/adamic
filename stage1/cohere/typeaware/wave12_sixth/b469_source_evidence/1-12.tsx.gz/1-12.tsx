export {};
/* 😀 Ω */ const x = <a-b />;
