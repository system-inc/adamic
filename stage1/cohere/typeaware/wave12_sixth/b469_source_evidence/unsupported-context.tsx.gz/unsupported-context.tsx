export {}; declare const Ctx: any; function C() { const v = {}; return <Ctx.Provider value={v} />; }
