/* 🌍 */ function C({[ o.p]: x={},[ /* a */ 1+2 ]: y=[]}){return <div/>;}
export {};
