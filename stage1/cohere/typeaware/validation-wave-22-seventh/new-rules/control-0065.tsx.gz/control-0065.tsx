default is a regex with flags
export {};
