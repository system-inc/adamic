function C({a = void 0}) { return <div/>; }
export {};
