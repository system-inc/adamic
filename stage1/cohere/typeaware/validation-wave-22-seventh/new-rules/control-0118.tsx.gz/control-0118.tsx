nested destructuring does not recurse
export {};
