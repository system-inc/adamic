names an arrow parent through its binding
export {};
