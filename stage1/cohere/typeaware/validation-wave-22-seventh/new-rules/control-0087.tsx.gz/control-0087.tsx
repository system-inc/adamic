function C({a = ref}) { return <div/>; }
export {};
