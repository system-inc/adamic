
        const propTypes = require('./externalPropTypes')
        const defaultProps = require('./externalDefaultProps')
        const TextFieldLabel = (props) => {
          return <div />;
        };
        TextFieldLabel.propTypes = propTypes;
        TextFieldLabel.defaultProps = defaultProps;
      
export {};
