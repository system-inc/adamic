function ParentComponent() {
  function Nested() { return <div />; }
  return <SomeComponent flag><Nested /></SomeComponent>;
}
export {};
