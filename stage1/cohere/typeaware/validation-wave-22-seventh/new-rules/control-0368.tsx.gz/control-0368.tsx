function ParentComponent() {
  return <SomeComponent title="plain" footer={() => <div />} />;
}
export {};
