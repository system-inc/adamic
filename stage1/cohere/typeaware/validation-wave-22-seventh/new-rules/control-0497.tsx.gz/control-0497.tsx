the identifier route resolves through the checker and must declare it
export {};
