
        export default class ClassWithSpreadInPropTypes extends BaseClass {
          static propTypes = {
            a: PropTypes.string,
            b: PropTypes.string,
            c: PropTypes.string,
            d: PropTypes.string,
            e: PropTypes.string,
            f: PropTypes.string
          }
          static defaultProps = {
            a: "a",
            b: "b",
            ...c.defaultProps,
            e: "e",
            f: "f",
            ...d.defaultProps
          }
        }
      
export {};
