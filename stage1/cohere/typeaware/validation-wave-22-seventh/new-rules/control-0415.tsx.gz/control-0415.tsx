
        class Component extends React.Component {
          static propTypes = {
            a: PropTypes.any,
            b: PropTypes.any,
            c: PropTypes.any
          };
          static defaultProps = {
            a: "a",
            b: "b",
            c: "c"
          };
          render() {
            return <div />;
          }
        }
      
export {};
