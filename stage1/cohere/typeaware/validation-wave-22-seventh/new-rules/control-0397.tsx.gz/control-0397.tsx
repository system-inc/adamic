function ParentComponent() {
  return React.createElement(Some, { footer: () => React.createElement("div", null) });
}
export {};
