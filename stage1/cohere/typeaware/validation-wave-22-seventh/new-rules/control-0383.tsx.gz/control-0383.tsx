string valued attribute
export {};
