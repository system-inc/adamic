
      function Foo({
        bar = 1,
        baz = 'hello',
      }) {
        return null;
      }
    
export {};
