{"ignoreCase": true}
export {};
