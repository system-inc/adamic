finding spans %q, want %q
export {};
