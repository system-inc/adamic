getDefaultProps as an assignment is judged
export {};
