function Parent(){return xs.map(()=> <div/>);}
export {};
