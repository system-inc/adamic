and pass data as props.
export {};
