decoding empty input: %v
export {};
