function C({a = null}) { return <div/>; }
export {};
