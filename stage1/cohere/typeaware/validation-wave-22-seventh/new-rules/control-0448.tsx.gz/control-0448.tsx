a computed key after a lowercase key is silent either way
export {};
