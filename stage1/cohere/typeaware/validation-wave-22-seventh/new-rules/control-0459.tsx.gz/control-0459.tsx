class C extends React.Component { static defaultProps = { c: 1, a: 2, b: 3 }; }
export {};
