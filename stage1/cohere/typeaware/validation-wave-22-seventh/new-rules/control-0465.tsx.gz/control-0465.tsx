a class field holding the object is reached
export {};
