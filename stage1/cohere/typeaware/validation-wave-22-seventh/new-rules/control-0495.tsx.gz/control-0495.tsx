decode returned %T
export {};
