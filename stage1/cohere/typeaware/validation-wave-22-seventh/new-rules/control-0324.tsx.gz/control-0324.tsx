move this component definition out of the parent component
export {};
