function C({a = <Foo/>}) { return <div/>; }
export {};
