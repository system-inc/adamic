%s reported %d findings, want 1
export {};
