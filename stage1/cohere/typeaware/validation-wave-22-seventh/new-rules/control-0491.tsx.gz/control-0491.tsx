an explicit false is case sensitive
export {};
