
      export default function NotAComponent({foo = {}}) {}
    
export {};
