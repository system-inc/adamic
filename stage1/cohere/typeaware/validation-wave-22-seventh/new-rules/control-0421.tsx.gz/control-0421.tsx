
        const defaults = {
          b: "b"
        };
        const types = {
          a: PropTypes.string,
          b: PropTypes.string,
          c: PropTypes.string
        };
        function StatelessComponentWithSpreadInPropTypes({ a, b, c }) {
          return <div>{a}{b}{c}</div>;
        }
        StatelessComponentWithSpreadInPropTypes.propTypes = types;
        StatelessComponentWithSpreadInPropTypes.defaultProps = {
          c: "c",
          ...defaults,
          a: "a"
        };
      
export {};
