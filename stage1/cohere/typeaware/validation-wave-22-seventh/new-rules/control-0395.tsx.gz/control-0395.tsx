arrow component in a method that is not render
export {};
