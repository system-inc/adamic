
        class Hello extends React.Component {
          render() {
            return <div>Hello</div>;
          }
        }
        Hello.propTypes = {
          "a": PropTypes.string,
          "b": PropTypes.string
        };
        Hello.defaultProps = {
          "b": "b",
          "a": "a"
        };
      
export {};
