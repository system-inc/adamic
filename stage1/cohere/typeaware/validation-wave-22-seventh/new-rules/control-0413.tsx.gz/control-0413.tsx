
        class First extends React.Component {
          render() {
            return <div />;
          }
        }
        First.propTypes = {
          a: PropTypes.string,
          z: PropTypes.string
        };
        First.propTypes.justforcheck = PropTypes.string;
        First.defaultProps = {
          a: a,
          z: z
        };
        First.defaultProps.justforcheck = "justforcheck";
      
export {};
