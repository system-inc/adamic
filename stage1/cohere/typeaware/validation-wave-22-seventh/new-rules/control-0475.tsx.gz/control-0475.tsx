an empty object has nothing to compare
export {};
