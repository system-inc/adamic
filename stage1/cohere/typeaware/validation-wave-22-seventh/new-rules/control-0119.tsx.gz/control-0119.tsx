function C({x: {a = {}}}) { return <div/>; }
export {};
