const ParentComponent = () => {
  function Nested() { return <div />; }
  return <div><Nested /></div>;
};
export {};
