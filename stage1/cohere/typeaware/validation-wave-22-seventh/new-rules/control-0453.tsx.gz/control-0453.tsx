class C extends React.Component { static defaultProps = { ...x, b: 1, a: 2 }; }
export {};
