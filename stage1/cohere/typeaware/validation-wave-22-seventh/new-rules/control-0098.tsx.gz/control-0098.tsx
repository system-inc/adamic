default is a double parenthesized object
export {};
