function ParentComponent() {
  const handlers = { [computed]: () => <div /> };
  return <SomeComponent handlers={handlers} />;
}
export {};
