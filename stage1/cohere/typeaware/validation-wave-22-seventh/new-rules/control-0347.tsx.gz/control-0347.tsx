no validated nodes found, so the offender count proves nothing
export {};
