class C extends React.Component { static defaultProps = { a: 1, /* c */ b: 2 }; }
export {};
