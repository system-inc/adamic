
        var First = createReactClass({
          propTypes: {
            a: PropTypes.any,
            z: PropTypes.string
          },
          getDefaultProps: function() {
            return {
              a: "a",
              z: "z"
            };
          },
          render: function() {
            return <div />;
          }
        });
        var Second = createReactClass({
          propTypes: {
            AA: PropTypes.any,
            ZZ: PropTypes.string
          },
          getDefaultProps: function() {
            return {
              AA: "AA",
              ZZ: "ZZ"
            };
          },
          render: function() {
            return <div />;
          }
        });
      
export {};
