function C({a = -1}) { return <div/>; }
export {};
