function ParentComponent() {
  return <Outer footer={<Inner title="x">{() => <div />}</Inner>} />;
}
export {};
