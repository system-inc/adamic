component returning null still counts
export {};
