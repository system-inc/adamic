function C({a}) { return <div/>; }
export {};
