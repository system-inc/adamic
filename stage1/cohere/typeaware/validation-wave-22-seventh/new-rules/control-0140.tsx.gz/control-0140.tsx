function C({a = {}}) { return null; }

export {};
