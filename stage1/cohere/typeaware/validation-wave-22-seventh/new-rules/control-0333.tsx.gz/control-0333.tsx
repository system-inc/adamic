omits the name for a function expression parent
export {};
