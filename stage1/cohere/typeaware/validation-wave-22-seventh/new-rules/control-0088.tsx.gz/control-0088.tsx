default is a plain call
export {};
