a has a/an array literal as default prop. This could lead to potential infinite render loop in React. Use a variable reference instead of array literal.
export {};
