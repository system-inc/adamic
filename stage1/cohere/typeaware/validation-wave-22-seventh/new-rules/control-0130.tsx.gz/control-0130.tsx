function C({a = {}, b = 1}) { return <div/>; }
export {};
