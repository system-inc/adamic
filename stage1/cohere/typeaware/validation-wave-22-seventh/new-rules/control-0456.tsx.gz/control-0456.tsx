a fully descending run reports on each step either way
export {};
