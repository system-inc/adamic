class C extends React.Component { static defaultProps = { B: 1, a: 2 }; }
export {};
