
        export default class ClassWithSpreadInPropTypes extends BaseClass {
          static propTypes = {
            a: PropTypes.string,
            b: PropTypes.string,
            c: PropTypes.string,
            d: PropTypes.string,
            e: PropTypes.string,
            f: PropTypes.string
          }
          static defaultProps = {
            b: "b",
            a: "a",
            ...c.defaultProps,
            f: "f",
            e: "e",
            ...d.defaultProps
          }
        }
      
export {};
