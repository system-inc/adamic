str has a/an object literal
export {};
