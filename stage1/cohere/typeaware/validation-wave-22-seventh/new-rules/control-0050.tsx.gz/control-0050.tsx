function C({a = class {}}) { return <div/>; }
export {};
