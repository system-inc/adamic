function ParentComponent() {
  const rows = [{ notPrefixedWithRender: (props) => <Row {...props} /> }];
  return <Table rows={rows} />;
}
export {};
