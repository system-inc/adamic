Default prop declarations should be sorted alphabetically. A sorted list is one a 
export {};
