
        class Component extends React.Component {
          static propTypes = {
            a: PropTypes.any,
            z: PropTypes.any
          };
          static defaultProps = {
            a: "a",
            Z: "Z",
          };
          render() {
            return <div />;
          }
        }
      
export {};
