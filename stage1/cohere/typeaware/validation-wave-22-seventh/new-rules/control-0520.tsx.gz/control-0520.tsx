function _Parent(){function Child(){return <div/>;}return <Child/>;}
export {};
