function C({a = a.b}) { return <div/>; }
export {};
