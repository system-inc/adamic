class C extends React.Component { static defaultProps = { [x]: 1, A: 2 }; }
export {};
