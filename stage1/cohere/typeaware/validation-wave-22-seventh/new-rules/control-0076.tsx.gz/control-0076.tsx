default is a string
export {};
