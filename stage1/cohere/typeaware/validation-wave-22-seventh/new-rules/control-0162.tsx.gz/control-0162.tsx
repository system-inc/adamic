function C({'str': a = {}}) { return <div/>; }
export {};
