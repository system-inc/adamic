function C({[1 + 1]: a = {}}) { return <div/>; }
export {};
