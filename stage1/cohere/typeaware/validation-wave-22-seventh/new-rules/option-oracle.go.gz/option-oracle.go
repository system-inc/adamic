package main
import("strings";"regexp";"encoding/json";"os")
func main(){cases:=[][2]string{{"render*","renderFooter"},{"render*","render\nFooter"},{"*","🌍"},{"?","🌍"},{"x.y","x.y"},{"x.y","xay"},{"[a]","[a]"},{"use?","useX"},{"","renderFooter"}};e:=json.NewEncoder(os.Stdout);e.SetEscapeHTML(false);for _,c:=range cases{pattern:=c[0];if pattern==""{pattern="render*"};e.Encode([]any{c[0],c[1],buildPropNamePattern(pattern)(c[1])})}}
func buildPropNamePattern(pattern string) func(string) bool {
	var builder strings.Builder
	builder.WriteString("^")
	for _, character := range pattern {
		switch character {
		case '*':
			builder.WriteString(".*")
		case '?':
			builder.WriteString(".")
		default:
			builder.WriteString(regexp.QuoteMeta(string(character)))
		}
	}
	builder.WriteString("$")

	compiled, err := regexp.Compile(builder.String())
	if err != nil {
		// Unreachable for any pattern this builder produces: every literal is escaped and the two
		// metacharacters expand to valid fragments. Declining rather than panicking, because a rule
		// that takes the run down over a configuration string is worse than one that stops matching
		// render props.
		return func(string) bool { return false }
	}
	return compiled.MatchString
}
