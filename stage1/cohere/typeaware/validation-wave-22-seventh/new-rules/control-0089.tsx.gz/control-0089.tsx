function C({a = foo()}) { return <div/>; }
export {};
