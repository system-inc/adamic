
        class Hello extends React.Component {
          render() {
            return <div>Hello</div>;
          }
        }
        Hello.propTypes = {
          "aria-controls": PropTypes.string
        };
        Hello.defaultProps = {
          "aria-controls": "aria-controls"
        };
      
export {};
