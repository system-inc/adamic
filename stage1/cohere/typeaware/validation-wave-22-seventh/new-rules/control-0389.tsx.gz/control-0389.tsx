the finding carried the as-props note: %q
export {};
