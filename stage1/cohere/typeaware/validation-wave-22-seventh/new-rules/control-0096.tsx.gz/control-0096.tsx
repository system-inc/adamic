default is a parenthesized object
export {};
