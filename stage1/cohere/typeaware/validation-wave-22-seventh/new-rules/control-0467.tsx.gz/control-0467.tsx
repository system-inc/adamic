an assignment after the class is reached
export {};
