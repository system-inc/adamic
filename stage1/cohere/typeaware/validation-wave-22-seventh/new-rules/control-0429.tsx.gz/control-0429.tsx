
        class Component extends React.Component {
          static propTypes = {
            a: PropTypes.any,
            b: PropTypes.any
          };
          static defaultProps = {
            Z: "Z",
            a: "a",
          };
          render() {
            return <div />;
          }
        }
      
export {};
