
        function ParentComponent() {
          return (
            <ComponentWithProps footer={() => <div />} />
          );
        }
      
export {};
