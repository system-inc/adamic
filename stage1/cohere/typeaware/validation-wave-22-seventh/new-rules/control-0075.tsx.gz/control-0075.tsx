function C({a = symbol()}) { return <div/>; }
export {};
