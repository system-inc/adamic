
        class Component extends React.Component {
          static propTypes = {
            a: PropTypes.any,
            b: PropTypes.any,
            c: PropTypes.any
          };
          static defaultProps = {
            c: "c",
            b: "b",
            a: "a"
          };
          render() {
            return <div />;
          }
        }
      
export {};
