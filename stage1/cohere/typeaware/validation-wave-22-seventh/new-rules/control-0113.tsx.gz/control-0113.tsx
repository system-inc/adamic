function helper({a = {}}) { return 1; }
export {};
