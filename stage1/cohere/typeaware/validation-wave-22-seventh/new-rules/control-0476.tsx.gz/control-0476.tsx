class C extends React.Component { static defaultProps = {}; }
export {};
