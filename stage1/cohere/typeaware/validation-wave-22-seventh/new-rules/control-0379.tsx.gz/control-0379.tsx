function ParentComponent() {
  const X = 
export {};
