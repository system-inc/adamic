import {forwardRef} from 'react';
const C = forwardRef(({a = {}}, ref) => <div/>);
export {};
