
      const Foo = ({bar = 1}, context) => {
        return null;
      };
    
export {};
