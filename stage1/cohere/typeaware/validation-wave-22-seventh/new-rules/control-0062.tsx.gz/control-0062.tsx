default is a regex
export {};
