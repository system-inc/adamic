function C({a = /x/gi}) { return <div/>; }
export {};
