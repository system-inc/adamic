class C extends React.Component { static defaultProps = { z: 1, a: 2, b: 3, c: 4 }; }
export {};
