class C extends React.Component { static defaultProps = { b: 1, a: 2, c: 3 }; }
export {};
