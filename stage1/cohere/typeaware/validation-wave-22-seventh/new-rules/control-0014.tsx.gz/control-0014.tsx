
      const Foo = () => {
        return null;
      };
    
export {};
