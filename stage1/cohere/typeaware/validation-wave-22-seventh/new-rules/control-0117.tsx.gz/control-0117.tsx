function C(p, {a = {}}) { return <div/>; }
export {};
