
        class First extends React.Component {
          render() {
            return <div />;
          }
        }

        First.defaultProps = {
            a: PropTypes.any,
            z: PropTypes.string,
            onFoo: PropTypes.func,
            onBar: PropTypes.func,
        };
      
export {};
