function C({a = Symbol(1)}) { return <div/>; }
export {};
