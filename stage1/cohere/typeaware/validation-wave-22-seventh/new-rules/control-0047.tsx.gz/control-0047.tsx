function C({a = function(){}}) { return <div/>; }
export {};
