function C({1: a = {}}) { return <div/>; }
export {};
