function ParentComponent() {
  return <SomeComponent {...rest} footer={() => <div />} />;
}
export {};
