a has a/an arrow function as default prop. This could lead to potential infinite render loop in React. Use a variable reference instead of arrow function.
export {};
