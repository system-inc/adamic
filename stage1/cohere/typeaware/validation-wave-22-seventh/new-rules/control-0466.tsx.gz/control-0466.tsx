class C extends React.Component { static defaultProps = { b: 1, a: 2 }; }
export {};
