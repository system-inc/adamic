default is a parenthesized Symbol call
export {};
