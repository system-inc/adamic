an empty object is case sensitive
export {};
