function C({a = `x`}) { return <div/>; }
export {};
