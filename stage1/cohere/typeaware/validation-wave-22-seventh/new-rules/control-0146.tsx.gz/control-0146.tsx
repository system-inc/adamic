function C({[k]: a = {}}) { return <div/>; }
export {};
