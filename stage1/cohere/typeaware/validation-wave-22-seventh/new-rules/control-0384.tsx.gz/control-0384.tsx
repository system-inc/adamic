function ParentComponent() {
  function Nested() { return <div />; }
  return <SomeComponent title="x"><Nested /></SomeComponent>;
}
export {};
