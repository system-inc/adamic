github.com/microsoft/TypeScript/tsc/shim/ast
export {};
