a default in the same week from colliding in the same spot.
export {};
