a spread between two out of order keys clears the comparison
export {};
