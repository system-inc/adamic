a computed key renders as its expression text, not the brackets
export {};
