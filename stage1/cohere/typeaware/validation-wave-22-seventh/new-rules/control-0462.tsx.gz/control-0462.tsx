a single inversion followed by an ordered key reports once
export {};
