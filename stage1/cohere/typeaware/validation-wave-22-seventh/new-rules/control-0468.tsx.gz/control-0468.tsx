class C extends React.Component {}
C.defaultProps = { b: 1, a: 2 };
export {};
