class C extends React.Component { static getDefaultProps = { b: 1, a: 2 }; }
export {};
