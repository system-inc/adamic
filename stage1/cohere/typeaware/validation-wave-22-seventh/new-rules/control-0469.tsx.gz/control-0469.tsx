an identifier naming the object is resolved and reached
export {};
