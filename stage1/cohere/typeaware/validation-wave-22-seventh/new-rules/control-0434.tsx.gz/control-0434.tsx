
        class Hello extends React.Component {
          render() {
            return <div>Hello</div>;
          }
        }
        Hello.propTypes = {
          "a": PropTypes.string,
          "B": PropTypes.string,
        };
        Hello.defaultProps = {
          "B": "B",
          "a": "a",
        };
      
export {};
