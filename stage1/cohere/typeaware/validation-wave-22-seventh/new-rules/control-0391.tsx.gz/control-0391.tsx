function ParentComponent() {
  return <Outer footer={<Inner title="x" render={() => <div />} />} />;
}
export {};
