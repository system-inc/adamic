
      function Foo({
        bar = emptyFunction,
        ...rest
      }) {
        return null;
      }
    
export {};
