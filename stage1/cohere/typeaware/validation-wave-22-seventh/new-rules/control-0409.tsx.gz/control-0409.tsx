
        var First = createReactClass({
          propTypes: {
            A: PropTypes.any,
            Z: PropTypes.string,
            a: PropTypes.any,
            z: PropTypes.string
          },
          getDefaultProps: function() {
            return {
              A: "A",
              Z: "Z",
              a: "a",
              z: "z"
            };
          },
          render: function() {
            return <div />;
          }
        });
      
export {};
