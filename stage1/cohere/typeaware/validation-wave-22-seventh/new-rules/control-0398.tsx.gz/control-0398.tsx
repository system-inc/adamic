a component in a createElement props object must carry the as-props note, got %q
export {};
