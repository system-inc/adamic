function C({a = "s"}) { return <div/>; }
export {};
