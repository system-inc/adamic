const o = { defaultProps: { b: 1, a: 2 } };
export {};
