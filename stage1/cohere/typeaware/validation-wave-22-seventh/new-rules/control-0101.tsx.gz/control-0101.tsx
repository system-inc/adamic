function C({a = (Symbol())}) { return <div/>; }
export {};
