function ParentComponent() {
  return <SomeComponent renderFooter={() => <div />} />;
}
export {};
