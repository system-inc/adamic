a quoted key sorts by its quote, so a then quoted b reports
export {};
