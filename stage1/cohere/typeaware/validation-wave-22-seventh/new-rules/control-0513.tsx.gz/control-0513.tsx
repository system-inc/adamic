class C extends React.Component{static defaultProps={z:1,a:2,b:3,...x,d:1,c:2};render(){return <div/>;}}
export {};
