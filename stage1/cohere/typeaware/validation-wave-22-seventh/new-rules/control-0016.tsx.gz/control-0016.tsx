
      const Foo = ({bar = 1}) => {
        return null;
      };
    
export {};
