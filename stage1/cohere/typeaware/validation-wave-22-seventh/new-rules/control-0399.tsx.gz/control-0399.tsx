compiling a pattern allocated %.0f times; the comparison below cannot fail
export {};
