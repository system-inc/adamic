
        class Hello extends React.Component {
          render() {
            return <div>Hello</div>;
          }
        }
        Hello.propTypes = {
          "a": PropTypes.string,
          "b": PropTypes.string,
          "c": PropTypes.string
        };
        Hello.defaultProps = {
          "c": "c",
          "b": "b",
          "a": "a"
        };
      
export {};
