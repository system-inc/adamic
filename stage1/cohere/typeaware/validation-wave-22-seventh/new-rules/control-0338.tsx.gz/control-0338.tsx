reports through a parenthesized prop value
export {};
