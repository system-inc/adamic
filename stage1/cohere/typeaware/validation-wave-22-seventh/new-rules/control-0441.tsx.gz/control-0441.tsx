class C extends React.Component { static defaultProps = { a: 1, "b": 2 }; }
export {};
