allowAsProps
export {};
