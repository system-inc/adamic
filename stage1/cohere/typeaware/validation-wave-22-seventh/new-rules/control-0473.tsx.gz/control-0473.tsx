a plain object property named defaultProps is not an assignment
export {};
