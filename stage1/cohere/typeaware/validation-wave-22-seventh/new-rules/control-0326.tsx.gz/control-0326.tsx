 If you want to allow component creation in props, set allowAsProps option to true.
export {};
