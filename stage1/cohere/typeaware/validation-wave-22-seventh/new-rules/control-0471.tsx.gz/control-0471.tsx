a getDefaultProps METHOD returning the object is NOT reached
export {};
