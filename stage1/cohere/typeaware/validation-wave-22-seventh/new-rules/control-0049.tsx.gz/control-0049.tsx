default is a class expression
export {};
