default is a function expression
export {};
