
        const defaults = {
          b: "b"
        };
        const First = (props) => <div />;
        export const propTypes = {
            a: PropTypes.string,
            b: PropTypes.string,
            z: PropTypes.string,
        };
        export const defaultProps = {
            ...defaults,
            a: "a",
            z: "z",
        };
        First.propTypes = propTypes;
        First.defaultProps = defaultProps;
      
export {};
