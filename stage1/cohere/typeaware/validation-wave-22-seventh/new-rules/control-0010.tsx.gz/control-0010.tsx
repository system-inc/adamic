
      function Foo(props) {
        return null;
      }
    
export {};
