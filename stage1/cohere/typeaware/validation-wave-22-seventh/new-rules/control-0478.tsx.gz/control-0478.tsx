class C extends React.Component { static defaultProps = { a: 1 }; }
export {};
