function C({a = tag`x`}) { return <div/>; }
export {};
