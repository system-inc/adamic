a sorted object with a comment before a key is silent
export {};
