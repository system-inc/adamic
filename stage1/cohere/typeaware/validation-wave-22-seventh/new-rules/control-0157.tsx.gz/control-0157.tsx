1 + 1 has a/an object literal
export {};
