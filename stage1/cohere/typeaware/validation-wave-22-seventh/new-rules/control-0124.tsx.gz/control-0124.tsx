function C({...rest}) { return <div/>; }
export {};
