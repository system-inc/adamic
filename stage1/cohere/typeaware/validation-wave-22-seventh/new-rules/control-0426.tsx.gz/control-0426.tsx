
        class Component extends React.Component {
          static propTypes = {
            a: PropTypes.any,
            b: PropTypes.any,
            c: PropTypes.any
          };
          static defaultProps = {
            a: "a",
            c: "c",
            b: "b"
          };
          render() {
            return <div />;
          }
        }
      
export {};
