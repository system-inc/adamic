a single property is compared against itself and cannot fail
export {};
