absent configuration is case sensitive
export {};
