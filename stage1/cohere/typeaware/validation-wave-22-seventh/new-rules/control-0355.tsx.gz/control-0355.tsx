decoding a pattern: %v
export {};
