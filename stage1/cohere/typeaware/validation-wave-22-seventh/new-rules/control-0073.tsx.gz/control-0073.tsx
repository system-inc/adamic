function C({a = Symbol.for(1)}) { return <div/>; }
export {};
