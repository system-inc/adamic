const C = ({a = {}}) => <div/>;
export {};
