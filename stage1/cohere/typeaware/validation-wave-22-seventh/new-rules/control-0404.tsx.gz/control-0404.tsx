the kept matcher does not match its own pattern
export {};
