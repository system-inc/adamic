function Parent(){const Child=()=>null;return <div/>;}
export {};
