function C({a={},b=[],c=()=>{},d=function(){},e=class{},f=new Date(),g=<div/>,h=/x/,i=Symbol(),j=<></>,k=Symbol.for(1)}){return <div/>;}
export {};
