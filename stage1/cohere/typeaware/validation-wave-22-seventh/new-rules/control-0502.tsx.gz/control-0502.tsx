getDefaultProps as a class field is judged
export {};
