key has a/an object literal as default prop. This could lead to potential infinite render loop in React. Use a variable reference instead of object literal.
export {};
