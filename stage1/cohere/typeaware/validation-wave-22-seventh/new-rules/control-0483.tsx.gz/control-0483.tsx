reader can scan for a name instead of reading end to end, and it keeps two people adding 
export {};
