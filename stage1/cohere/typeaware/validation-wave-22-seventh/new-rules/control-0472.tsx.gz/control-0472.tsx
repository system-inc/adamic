var C = createReactClass({ getDefaultProps: function(){ return { b: 1, a: 2 }; } });
export {};
