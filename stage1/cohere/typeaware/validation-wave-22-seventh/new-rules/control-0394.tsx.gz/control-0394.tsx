class ParentComponent extends React.Component {
  render() {
    const Nested = () => <div />;
    return <div><Nested /></div>;
  }
}
export {};
