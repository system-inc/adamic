
        function ParentComponent() {
          return <SomeComponent renderers={{ notComponent: () => null }} />;
        }
      
export {};
