default is a Symbol with argument
export {};
