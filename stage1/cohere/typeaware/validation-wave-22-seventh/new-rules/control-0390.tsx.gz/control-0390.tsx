function ParentComponent() {
  return <Outer footer={() => <div />} />;
}
export {};
