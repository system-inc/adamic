getDefaultProps as an object property is not an assignment and is silent
export {};
