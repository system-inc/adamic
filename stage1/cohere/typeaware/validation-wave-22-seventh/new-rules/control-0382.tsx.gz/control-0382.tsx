function ParentComponent() {
  return <SomeComponent someRenderer={() => <div />} />;
}
export {};
