function Parent(){return <Thing renderFooter={()=> <div/>} footer={()=> <div/>}/>;}
export {};
