/repository/source/NoObjectTypeAsDefaultProp.tsx
export {};
