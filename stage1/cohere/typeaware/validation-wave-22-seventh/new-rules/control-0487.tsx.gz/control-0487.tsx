upstream ships no repair for this rule and neither does this port
export {};
