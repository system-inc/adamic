class ParentComponent extends React.Component {
  helper() {
    const Nested = () => <div />;
    return <Nested />;
  }
  render() { return <div>{this.helper()}</div>; }
}
export {};
