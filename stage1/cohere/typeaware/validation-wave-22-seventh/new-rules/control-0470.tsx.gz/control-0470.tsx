const props = { b: 1, a: 2 };
class C extends React.Component {}
C.defaultProps = props;
export {};
