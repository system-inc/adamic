
        class First extends React.Component {
          render() {
            return <div />;
          }
        }
        First.propTypes = {
          a: PropTypes.any,
          A: PropTypes.any,
          z: PropTypes.string,
          Z: PropTypes.string
        };
        First.defaultProps = {
          a: "a",
          A: "A",
          z: "z",
          Z: "Z"
        };
      
export {};
