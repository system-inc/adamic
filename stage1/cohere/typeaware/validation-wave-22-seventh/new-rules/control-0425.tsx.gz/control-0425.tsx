
        class First extends React.Component {
          render() {
            return <div />;
          }
        }

        First.defaultProps = {
            a: PropTypes.any,
            onBar: PropTypes.func,
            onFoo: PropTypes.func,
            z: PropTypes.string,
        };
      
export {};
