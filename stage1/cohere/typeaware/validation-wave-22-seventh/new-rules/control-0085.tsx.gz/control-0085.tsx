function C({a = true}) { return <div/>; }
export {};
