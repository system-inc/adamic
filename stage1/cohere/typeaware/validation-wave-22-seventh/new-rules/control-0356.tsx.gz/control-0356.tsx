pattern %q, want *Renderer
export {};
