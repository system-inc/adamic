Do not define components during render. React will see a new component type on 
export {};
