
        var First = createReactClass({
          propTypes: {
            a: PropTypes.any,
            A: PropTypes.any,
            z: PropTypes.string,
            Z: PropTypes.string
          },
          getDefaultProps: function() {
            return {
              a: "a",
              A: "A",
              z: "z",
              Z: "Z"
            };
          },
          render: function() {
            return <div />;
          }
        });
      
export {};
