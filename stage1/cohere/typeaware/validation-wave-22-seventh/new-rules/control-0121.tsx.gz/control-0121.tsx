function C({key: local = {}}) { return <div/>; }
export {};
