names a function declaration parent
export {};
