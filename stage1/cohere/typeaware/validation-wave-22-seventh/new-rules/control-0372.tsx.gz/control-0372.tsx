function ParentComponent() {
  return <div>{items.map(([first, ...rest]) => <li key={first} />)}</div>;
}
export {};
