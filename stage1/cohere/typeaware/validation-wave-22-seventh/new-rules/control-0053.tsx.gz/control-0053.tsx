function C({a = new Foo()}) { return <div/>; }
export {};
