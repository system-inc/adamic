
        const First = (props) => <div />;
        const propTypes = {
          z: PropTypes.string,
          a: PropTypes.any,
        };
        const defaultProps = {
          z: "z",
          a: "a",
        };
        First.propTypes = propTypes;
        First.defaultProps = defaultProps;
      
export {};
