function C({[ /* keep */ k() ]: x = {},[﻿k()]: y=[]}){return <div/>;}
export {};
