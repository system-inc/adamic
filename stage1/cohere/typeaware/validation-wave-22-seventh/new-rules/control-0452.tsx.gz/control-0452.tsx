a leading spread does not exempt what follows
export {};
