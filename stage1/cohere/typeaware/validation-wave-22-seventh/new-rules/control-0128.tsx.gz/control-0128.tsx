function C({a = {}, b = []}) { return <div/>; }
export {};
