package main
import("go/ast";"go/parser";"go/token";"os";"strconv";"encoding/json")
func main(){var values []string;seen:=map[string]bool{};for _,p:=range os.Args[1:]{t,e:=parser.ParseFile(token.NewFileSet(),p,nil,0);if e!=nil{panic(e)};ast.Inspect(t,func(n ast.Node)bool{if v,ok:=n.(*ast.BasicLit);ok&&v.Kind==token.STRING{s,e:=strconv.Unquote(v.Value);if e==nil&&!seen[s]{values=append(values,s);seen[s]=true}};return true})};json.NewEncoder(os.Stdout).Encode(values)}
