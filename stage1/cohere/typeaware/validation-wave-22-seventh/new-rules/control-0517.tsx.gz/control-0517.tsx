function Parent(){return useMemo(()=>{return ()=> <div/>;},[]);}
export {};
