a sorted object written across lines is silent
export {};
