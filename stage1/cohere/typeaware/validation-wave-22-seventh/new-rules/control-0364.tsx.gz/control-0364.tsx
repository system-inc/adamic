Component.ts
export {};
