(https://reactjs.org/docs/reconciliation.html#elements-of-different-types). Instead, 
export {};
