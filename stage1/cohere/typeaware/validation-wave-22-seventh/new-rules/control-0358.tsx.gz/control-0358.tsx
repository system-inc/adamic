decoding an empty pattern: %v
export {};
