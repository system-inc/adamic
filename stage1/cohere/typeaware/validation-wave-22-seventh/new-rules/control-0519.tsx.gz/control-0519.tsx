function ßParent(){function Child(){return <div/>;}return <Child/>;}
export {};
