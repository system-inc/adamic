o.p has a/an object literal
export {};
