
        var First = createReactClass({
          propTypes: {
            barRequired: PropTypes.func.isRequired,
            onBar: PropTypes.func,
            z: PropTypes.any
          },
          getDefaultProps: function() {
            return {
              barRequired: "barRequired",
              onBar: "onBar",
              z: "z"
            };
          },
          render: function() {
            return <div />;
          }
        });
      
export {};
