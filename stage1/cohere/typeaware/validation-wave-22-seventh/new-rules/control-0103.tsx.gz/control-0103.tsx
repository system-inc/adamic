function C({a = a?{}:{}}) { return <div/>; }
export {};
