forwardRef wrapped component
export {};
