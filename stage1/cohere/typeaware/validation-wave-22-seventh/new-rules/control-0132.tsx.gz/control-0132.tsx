import {memo} from 'react';
const C = memo(({a = {}}) => <div/>);
export {};
