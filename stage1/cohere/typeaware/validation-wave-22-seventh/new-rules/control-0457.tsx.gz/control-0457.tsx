class C extends React.Component { static defaultProps = { c: 1, b: 2, a: 3 }; }
export {};
