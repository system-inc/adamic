quoted a then bare b is silent for the same reason
export {};
