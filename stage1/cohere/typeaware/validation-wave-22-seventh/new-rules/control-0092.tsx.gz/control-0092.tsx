default is a tagged template
export {};
