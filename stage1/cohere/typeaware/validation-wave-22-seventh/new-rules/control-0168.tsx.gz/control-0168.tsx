React. Use a variable reference instead of object literal.
export {};
