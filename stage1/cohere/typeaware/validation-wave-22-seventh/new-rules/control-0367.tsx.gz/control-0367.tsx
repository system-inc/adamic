function ParentComponent() {
  function Nested({ a, b }: Options) { return <div />; }
  return <div><Nested a={1} b={2} /></div>;
}
export {};
