default is a jsx self closing
export {};
