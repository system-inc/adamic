class ParentComponent extends React.Component {
  render() {
    class Nested extends React.Component {
      render() { return <div />; }
    }
    return <div><Nested /></div>;
  }
}
export {};
