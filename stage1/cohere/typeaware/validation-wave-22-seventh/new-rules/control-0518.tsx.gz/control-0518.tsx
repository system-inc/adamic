function ÜParent(){function ÜChild(){return <div/>;}return <ÜChild/>;}
export {};
