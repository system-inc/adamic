function ParentComponent() {
  return <svg xmlns:xlink="x"><use xlink:href="#a" /></svg>;
}
export {};
