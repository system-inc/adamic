function C({a = <div/>}) { return <div/>; }
export {};
