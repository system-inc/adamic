{"propNamePattern":"*Renderer"}
export {};
