installed build reports %d findings, this rule reports %d
export {};
