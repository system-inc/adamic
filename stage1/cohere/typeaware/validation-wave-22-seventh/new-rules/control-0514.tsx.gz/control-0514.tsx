const defaults={z:1,a:2}; C.defaultProps=defaults;
export {};
