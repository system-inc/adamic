function ParentComponent() {
  return <SomeComponent footer={(() => <div />)} />;
}
export {};
