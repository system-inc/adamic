class C extends React.Component { static defaultProps = { b: 1, ...x, a: 2 }; }
export {};
