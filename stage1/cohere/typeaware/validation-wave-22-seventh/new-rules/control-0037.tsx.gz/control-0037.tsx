finding %d renders
  got  %q
  want %q
export {};
