'lit' has a/an object literal
export {};
