github.com/system-inc/cohere/internal/lint/rule
export {};
