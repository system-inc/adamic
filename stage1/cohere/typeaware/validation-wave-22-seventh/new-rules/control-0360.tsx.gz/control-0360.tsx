{"customValidators":["./x"],"allowAsProps":true}
export {};
