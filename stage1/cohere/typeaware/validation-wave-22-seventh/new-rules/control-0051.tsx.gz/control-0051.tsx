a has a/an class expression as default prop. This could lead to potential infinite render loop in React. Use a variable reference instead of class expression.
export {};
