appends the as-props note for a component in a JSX prop
export {};
