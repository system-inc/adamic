arrow component in a render method
export {};
