class C extends React.Component{static defaultProps={Z:1,a:2,İ:3,i:4,Σ:5,σ:6};}
export {};
