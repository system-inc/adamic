
        function ParentComponent() {
          useEffect(() => {
            return () => null;
          });

          return <div />;
        }
      
export {};
