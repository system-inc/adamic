
        function ParentComponent() {
            return (
              <RenderPropComponent children={() => <div />} />
            );
        }
      
export {};
