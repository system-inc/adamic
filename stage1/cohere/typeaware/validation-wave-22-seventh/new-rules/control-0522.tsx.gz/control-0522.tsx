function C({a:renamed={},"string":s=[],[key]:v={},1:n=/x/}){return <div/>;}
export {};
