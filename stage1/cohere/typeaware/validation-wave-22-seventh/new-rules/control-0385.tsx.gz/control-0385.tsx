bare boolean attribute with no value
export {};
