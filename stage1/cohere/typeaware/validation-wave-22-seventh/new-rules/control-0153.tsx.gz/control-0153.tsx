function C({['lit']: a = {}}) { return <div/>; }
export {};
