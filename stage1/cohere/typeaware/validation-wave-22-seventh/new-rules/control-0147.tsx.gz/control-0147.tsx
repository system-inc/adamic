k has a/an object literal
export {};
