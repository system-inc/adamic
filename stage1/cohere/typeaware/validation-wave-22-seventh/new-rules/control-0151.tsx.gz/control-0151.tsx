undefined has a/an object literal
export {};
