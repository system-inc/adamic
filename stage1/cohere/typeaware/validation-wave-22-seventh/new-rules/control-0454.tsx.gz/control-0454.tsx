a trailing spread does not exempt what precedes
export {};
