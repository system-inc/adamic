
      function Foo({
        bar = emptyFunction,
      }) {
        return null;
      }
    
export {};
