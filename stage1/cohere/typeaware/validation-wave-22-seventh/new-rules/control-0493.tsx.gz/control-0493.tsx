an explicit true folds case
export {};
