function C({[o.p]: a = {}}) { return <div/>; }
export {};
