class C extends React.Component { static defaultProps = { b: 1, [x]: 2 }; }
export {};
