const ParentComponent = function () {
  function Nested() { return <div />; }
  return <div><Nested /></div>;
};
export {};
