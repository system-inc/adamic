
        var First = createReactClass({
          render: function() {
            return <div />;
          }
        });
      
export {};
