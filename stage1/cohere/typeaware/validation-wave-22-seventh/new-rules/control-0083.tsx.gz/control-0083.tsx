function C({a = undefined}) { return <div/>; }
export {};
