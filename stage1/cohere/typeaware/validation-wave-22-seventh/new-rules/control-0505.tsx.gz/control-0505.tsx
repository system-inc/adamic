class C extends React.Component {}
C.getDefaultProps = { b: 1, a: 2 };
export {};
