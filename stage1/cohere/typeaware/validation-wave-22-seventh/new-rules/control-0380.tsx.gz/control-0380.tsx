(() => {
    return () => <div />;
  });
  return <div><X /></div>;
}
export {};
