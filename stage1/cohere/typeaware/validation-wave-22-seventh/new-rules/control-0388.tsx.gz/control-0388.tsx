a component declared in the parent body must not be read as a prop, but 
export {};
