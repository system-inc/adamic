var C = createReactClass({ getDefaultProps: { b: 1, a: 2 } });
export {};
