a computed key before an uppercase key reports either way
export {};
