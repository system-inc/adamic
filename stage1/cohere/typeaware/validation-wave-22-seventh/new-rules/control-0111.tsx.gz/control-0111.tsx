function c({a = {}}) { return <div/>; }
export {};
