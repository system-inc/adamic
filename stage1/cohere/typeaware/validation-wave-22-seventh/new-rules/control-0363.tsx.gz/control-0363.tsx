function ParentComponent() {
  const Nested = () => React.createElement("div", null);
  return React.createElement("div", null, React.createElement(Nested, null));
}
export {};
