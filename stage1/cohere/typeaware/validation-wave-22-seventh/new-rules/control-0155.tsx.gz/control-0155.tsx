computed arithmetic key reports, where upstream renders undefined
export {};
