a has a/an object literal
export {};
