package main
import("fmt";"regexp")
func main(){pattern:=regexp.MustCompile(`Effect($|[^a-z])`);for _,name:=range []string{"useEffect","useLayoutEffect","useEffective","useMyEffect2","useMyEffectX","useEffect\n","useEffect\nx","useEffectx","useEffecta","useEffecté","🌍EffectA","","effect","Effect","Effect_","Effect$","xEffectZ","Effectz","Effect\r","Effect "}{if pattern.MatchString(name){fmt.Println("1")}else{fmt.Println("0")}}}
