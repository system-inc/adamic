export {};
import { useEffect } from 'react'

        export const Test = () => {
          const handleFrame = () => {
            setTimeout(handleFrame)
          }

          useEffect(() => {
            setTimeout(handleFrame)
          }, [])

          return (
            <></>
          )
        }
