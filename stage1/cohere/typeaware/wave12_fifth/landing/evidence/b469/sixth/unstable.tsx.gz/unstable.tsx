export {}; declare const React: any; declare const Ctx: any; declare function useMemo<T>(callback: () => T, deps?: any[]): T;
function C() { const dep = {}; const v = useMemo(() => ({a:1}), [dep]); return <Ctx.Provider value={v}/>; }
