export {}; declare const React: any; declare const Ctx: any; declare function useMemo<T>(callback: () => T, deps?: any[]): T;
function C() { const v = {a:1}; return <Ctx.Provider value={v}/>; }
