export {}; declare const React: any; declare const Ctx: any; declare function useMemo<T>(callback: () => T, deps?: any[]): T;
function C() { const a‍b = {}; return <Ctx.Provider value={a‍b}/>; }
