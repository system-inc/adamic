export {}; declare const React: any; declare const Ctx: any; declare function useMemo<T>(callback: () => T, deps?: any[]): T;
function C() { function v() {} return <Ctx.Provider value={v}/>; }
