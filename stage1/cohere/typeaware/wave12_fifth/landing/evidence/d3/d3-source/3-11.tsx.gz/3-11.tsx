export {}; declare const React: any; declare const A: any; declare const props: any;
declare function require(...values: any[]): any; declare const dynamic: string;
/* 😀 Ω */ const F = require(dynamic); const x = <F />;
