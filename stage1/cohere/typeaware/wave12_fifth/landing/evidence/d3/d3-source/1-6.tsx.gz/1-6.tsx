export {};
/* 😀 Ω */ const x = <ns:tag />;
