export {}; declare const React: any; declare const A: any; declare const props: any;
declare const Ctx: any;
/* 😀 Ω */ function C() { return <Ctx.Provider value={<></>} />; };
