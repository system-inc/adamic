export {};
/* 😀 Ω */ const x = <custom-element />;
