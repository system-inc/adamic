export {};
/* 😀 Ω */ const x = <this.Component />;
