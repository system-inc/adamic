export {}; declare const React: any; declare const Ctx: any; declare function useMemo<T>(callback: () => T, deps?: any[]): T;
function C() { const 테스트 = {}; return <Ctx.Provider value={테스트}/>; }
