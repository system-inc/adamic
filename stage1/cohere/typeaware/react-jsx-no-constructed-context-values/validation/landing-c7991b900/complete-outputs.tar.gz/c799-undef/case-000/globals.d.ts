declare var Text: any;
