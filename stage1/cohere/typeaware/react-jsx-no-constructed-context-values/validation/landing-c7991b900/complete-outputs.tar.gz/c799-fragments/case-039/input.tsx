interface Fragment { a: number }
import React, { Fragment } from 'react';
<Fragment><Foo /></Fragment>;