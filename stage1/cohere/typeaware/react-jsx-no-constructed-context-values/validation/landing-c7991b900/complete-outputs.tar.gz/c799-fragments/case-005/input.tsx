
        const { Fragment } = React;
        <Fragment><Foo /></Fragment>;
      