import React, { Fragment } from 'react';
interface Fragment { a: number }
<Fragment><Foo /></Fragment>;