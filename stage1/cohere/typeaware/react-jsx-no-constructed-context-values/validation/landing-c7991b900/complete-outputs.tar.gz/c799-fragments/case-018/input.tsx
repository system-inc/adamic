
        import React, { Fragment } from 'react';
        <Fragment><Foo /></Fragment>;
      