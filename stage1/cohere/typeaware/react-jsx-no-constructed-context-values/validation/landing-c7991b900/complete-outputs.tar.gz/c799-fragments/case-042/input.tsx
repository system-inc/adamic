const { Fragment } = require('preact');
<Fragment><Foo /></Fragment>;