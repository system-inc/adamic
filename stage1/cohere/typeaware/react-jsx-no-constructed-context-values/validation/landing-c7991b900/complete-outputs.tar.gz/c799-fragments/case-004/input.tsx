
        const F = React.Fragment;
        <F><Foo /></F>;
      