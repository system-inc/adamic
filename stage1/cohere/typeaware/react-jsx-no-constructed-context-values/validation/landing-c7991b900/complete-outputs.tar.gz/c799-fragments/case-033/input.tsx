import { Fragment } from 'preact';
<Fragment><Foo /></Fragment>;