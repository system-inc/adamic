
        const { Fragment } = require('react');
        <Fragment><Foo /></Fragment>;
      