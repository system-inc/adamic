const { Fragment } = Preact;
<Fragment><Foo /></Fragment>;