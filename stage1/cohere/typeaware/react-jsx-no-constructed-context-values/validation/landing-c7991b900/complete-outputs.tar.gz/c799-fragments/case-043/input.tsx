const F = Preact.Fragment;
<F><Foo /></F>;