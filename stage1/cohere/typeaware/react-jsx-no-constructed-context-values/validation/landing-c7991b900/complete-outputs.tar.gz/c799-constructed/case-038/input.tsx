
        import React from 'react';

        const MyContext = React.createContext();
        const Component = () => <MyContext value={100}></MyContext>;
      