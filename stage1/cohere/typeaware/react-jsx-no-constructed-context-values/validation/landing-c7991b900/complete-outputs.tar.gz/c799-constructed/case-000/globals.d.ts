// 😀 foreign declaration positions
declare var Text: any;
declare const ExternalF: any;
declare const ExternalFragment = React.Fragment;
declare const ExternalContext = React.createContext();
