
        const SomeContext = createContext();
        const Component = () => <SomeContext value="Some string"></SomeContext>;
      