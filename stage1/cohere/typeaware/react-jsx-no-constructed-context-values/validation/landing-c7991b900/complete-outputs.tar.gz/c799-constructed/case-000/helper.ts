export function build(){return {a:1};}
let old: {a:number}|undefined;
export function cached(){if(old)return old;const v={a:1};old=v;return v;}
export async function load(){return old;}
