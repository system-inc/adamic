declare const count:0;const view=<div>{count && <div/>}</div>;
export {};

export {};
