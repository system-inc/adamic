declare const count:never;const view=<div>{count && <div/>}</div>;
export {};

export {};
