declare const count:number,flag:boolean;const view=<div>{flag && count && <div/>}</div>;
export {};

export {};
