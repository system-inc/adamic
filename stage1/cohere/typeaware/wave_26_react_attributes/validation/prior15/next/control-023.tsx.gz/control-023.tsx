declare const count:any;const view=<div>{count && <div/>}</div>;
export {};

export {};
