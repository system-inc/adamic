declare const count:void;const view=<div>{count && <div/>}</div>;
export {};

export {};
