declare const count:number & {brand:true};const view=<div>{count && <div/>}</div>;
export {};

export {};
