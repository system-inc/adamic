declare const count:unknown;const view=<div>{count && <div/>}</div>;
export {};

export {};
