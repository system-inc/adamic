declare const count:0 | false | null | undefined;const view=<div>{count && <div/>}</div>;
export {};

export {};
