declare const count:number;const view=<div>{count && <div/>}</div>;
export {};

export {};
