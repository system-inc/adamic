declare const count:number | string;const view=<div>{count && <div/>}</div>;
export {};

export {};
