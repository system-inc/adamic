declare const count:boolean;const view=<div>{count && <div/>}</div>;
export {};

export {};
