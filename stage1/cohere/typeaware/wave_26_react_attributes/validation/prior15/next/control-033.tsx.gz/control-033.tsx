declare const count:number,other:number;const view=<div>{(count || other) && <div/>}{(count ?? other) && <div/>}</div>;
export {};

export {};
