function component<T extends number>(count:T){return <div>{count && <div/>}</div>;}
export {};

export {};
