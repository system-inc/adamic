declare const count:0n;const view=<div>{count && <div/>}</div>;
export {};

export {};
