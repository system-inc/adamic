declare const count:1 | 2;const view=<div>{count && <div/>}</div>;
export {};

export {};
