declare const count:number;const view=<div visible={count && true}>{count > 0 && <div/>}</div>;
export {};

export {};
