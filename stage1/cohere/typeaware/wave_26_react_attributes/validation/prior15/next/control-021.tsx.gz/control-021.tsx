declare const count:number | null;const view=<div>{count && <div/>}</div>;
export {};

export {};
