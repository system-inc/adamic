declare const count:bigint;const view=<div>{count && <div/>}</div>;
export {};

export {};
