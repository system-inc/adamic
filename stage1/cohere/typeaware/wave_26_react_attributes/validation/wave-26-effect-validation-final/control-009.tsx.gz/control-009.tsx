import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  const body = () => {
    setState(1);
  };
  useEffect(body);
  return state;
}

export {};
