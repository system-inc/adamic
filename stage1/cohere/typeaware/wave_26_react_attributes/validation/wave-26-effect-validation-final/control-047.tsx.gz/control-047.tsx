import * as React from "./react";

function Component() {
  const [state, setState] = React.useState(0);
  const bump = React.use\u0043allback(() => {
    setState(1);
  }, []);
  React.useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
