import {useEffect, useState} from "./react";
function Component({args}: {args: [() => void]}) {
  const [state, setState] = useState(0);
  useEffect(...args);
  return state;
}

export {};
