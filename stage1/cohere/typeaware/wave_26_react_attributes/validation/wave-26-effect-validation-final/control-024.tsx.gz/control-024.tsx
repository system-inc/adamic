import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useEffect(() => {}, setState);
  return state;
}

export {};
