import {useEffect, useMemo, useState} from "./react";

function Component() {
  const [state, setState] = useState(0);
  const bump = useMemo(() => () => {
    setState(1);
  }, []);
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
