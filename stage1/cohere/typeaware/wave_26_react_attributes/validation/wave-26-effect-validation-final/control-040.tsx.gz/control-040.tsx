import {useEffect, useState} from "./react";

function Component() {
  const [state] = useState(0);
  const value = (function() {
    return 1;
  })();
  useEffect(() => {
    console.info(value);
  }, [value]);
  return state + value;
}

export {};
