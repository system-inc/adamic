import {useEffect, useState} from "./react";

export function notAComponent() {
  const [state, setState] = useState(0);
  useEffect(() => {
    setState(1);
  });
  return state;
}

export {};
