import {use\u{43}allback, useEffect, useState} from "./react";

function Component() {
  const [state, setState] = useState(0);
  const bump = use\u{43}allback(() => {
    setState(1);
  }, []);
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
