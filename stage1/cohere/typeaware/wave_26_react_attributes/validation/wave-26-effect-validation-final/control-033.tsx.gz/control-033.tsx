import {useEffect, useState} from "./react";
function Outer() {
  function useInner() {
    const [state, setState] = useState(0);
    useEffect(() => {
      setState(1);
    });
    return state;
  }
  return useInner;
}

export {};
