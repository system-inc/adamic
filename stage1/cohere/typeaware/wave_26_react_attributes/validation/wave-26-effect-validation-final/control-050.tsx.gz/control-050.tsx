import {useCallback as useCached, useEffect, useState} from "./react";

function Component() {
  const [state, setState] = useState(0);
  const bump = useCached(() => {
    setState(1);
  }, []);
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
