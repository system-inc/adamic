function O() {
  const C = mk();
  return < /*c*/ C />;
}

export {};
