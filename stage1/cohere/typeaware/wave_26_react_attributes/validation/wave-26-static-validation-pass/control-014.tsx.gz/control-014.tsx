const Hoisted = () => <div />;
function Outer() {
  const C = Hoisted;
  return <C />;
}

export {};
