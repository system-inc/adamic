function Outer(){const C=mk();let D=C;let E=D;return <E/>;}

export {};
