function Outer() {
  function Inner() {
    const Component = createComponent();
    return <Component />;
  }
  return <Inner />;
}

export {};
