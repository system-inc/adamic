function Outer() {
  const C = makeIt();
  const render = () => <C />;
  return render();
}

export {};
