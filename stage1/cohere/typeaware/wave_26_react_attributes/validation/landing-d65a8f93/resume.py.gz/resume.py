import os,pathlib,subprocess,json,time
R=pathlib.Path('/workspace/adamic'); G=pathlib.Path('/workspace/wave-26-d65-gate'); A=pathlib.Path('/workspace/wave-26-attributes'); P=R/'stage1/cohere/typeaware/wave_26_react_reporting'; records=json.loads((G/'runs.json').read_text())
env=dict(os.environ,TMPDIR='/workspace/wave-26-bridge-scratch',ADAMIC_TYPESCRIPT_SOURCE='/workspace/wave-26-typescript',ADAMIC_WAVE26_REPOSITORY_MANIFEST='/workspace/wave-26-repository.manifest',ADAMIC_WAVE26_COMPILER_MANIFEST='/workspace/wave-26-compiler.manifest',ADAMIC_TSGO_CORPUS='/workspace/wave-26-typescript')
def run(name,cmd,extra=None):
 print('START',name,flush=True); start=time.monotonic()
 with (G/(name+'.log')).open('wb') as f: result=subprocess.run([str(x) for x in cmd],cwd=R,env=dict(env,**(extra or {})),stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=[str(x) for x in cmd],exit=result.returncode,seconds=time.monotonic()-start));(G/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print('END',name,result.returncode,flush=True);assert result.returncode==0,name
run('bridge-retry',['go','test','./bridge/tsgo/...','-count=1','-v','-timeout','15m'])
run('node-oracle',['go','test','./internal/oracle','-run','^TestRuntimeLastIndexOfMatchesNode$|^TestTheOracleCatchesOneByte$|^TestNativeAgreesWithNode$/internal/oracle/testdata/(maps_and_text|sorting|string_index|lone_surrogates|functions|closures|inherited_static_field_read)\\.a$','-count=1','-timeout','10m','-v'])
run('vet',['go','vet','./...'])
run('cost',['python3',R/'stage1/cohere/typeaware/wave_26_react_attributes/validate_cost.py'])
print('RETRY AND REMAINING CHECKS PASS',flush=True)
