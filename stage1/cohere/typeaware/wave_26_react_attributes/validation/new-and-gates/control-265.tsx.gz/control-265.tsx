
        import { createContext } from 'react';

        var Hello;
        Hello = React.createContext();
        Hello.displayName = "HelloContext";
      
export {};
