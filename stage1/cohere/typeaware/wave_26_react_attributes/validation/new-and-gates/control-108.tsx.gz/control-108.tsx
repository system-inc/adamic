const a = <button type="reset"/>;

export {};
