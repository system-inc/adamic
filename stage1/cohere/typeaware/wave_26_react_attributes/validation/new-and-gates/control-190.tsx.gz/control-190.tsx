declare const input: any;
const element = <input.Nested checked />;

export {};
