
        import React, { createElement } from "react";
        export default (props) => {
          return createElement("div", {}, "hello");
        };
      
export {};
