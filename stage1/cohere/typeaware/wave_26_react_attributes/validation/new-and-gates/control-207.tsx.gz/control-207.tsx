declare const React: any;
React.createElement('input');

export {};
