React.createElement("button", {type: condition ? foo : "button"})
export {};
