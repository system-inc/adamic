
        import React from 'react';

        const Hello = React.createContext();
        Hello.displayName = "HelloContext"
      
export {};
