React.createElement('input', { checked: true, readOnly: true })
export {};
