declare const Preact: any;
const { createElement } = Preact;
createElement('input', { checked: true });

export {};
