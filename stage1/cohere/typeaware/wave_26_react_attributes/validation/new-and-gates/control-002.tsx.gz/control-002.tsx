<button type={foo}/>
export {};
