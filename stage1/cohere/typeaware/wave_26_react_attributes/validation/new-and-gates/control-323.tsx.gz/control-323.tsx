import {memo} from 'react';
const C = memo(() => <div/>);
function f(){ C.displayName = 'x'; }

export {};
