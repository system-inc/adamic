import {memo} from 'react';
const C = memo(() => <div/>);
C.displayName = 'C';

export {};
