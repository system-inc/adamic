const a = <button type={false}/>;

export {};
