declare const a: boolean;
declare const b: string;
const e = <button type={a ? (b) : 'button'}/>;
export {};
