
        module.exports = () => {
          return <div>Hello {props.name}</div>;
        }
      
export {};
