
        let demo = null;
        demo = (a) => {
          if (a == null) return null;
          return f(a);
        };
export {};
