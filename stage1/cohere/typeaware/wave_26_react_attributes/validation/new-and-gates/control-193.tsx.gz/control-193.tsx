createElement of a component name declines
export {};
