const a = <button type={1_0}/>;

export {};
