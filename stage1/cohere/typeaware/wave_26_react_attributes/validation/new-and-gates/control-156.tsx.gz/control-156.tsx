React.createElement('input', { checked: foo, onChange: noop, readOnly: true })
export {};
