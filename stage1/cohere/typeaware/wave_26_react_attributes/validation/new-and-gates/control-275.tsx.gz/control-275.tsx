
        function Hof() {
          return function () {
            return <div />
          }
        }
      
export {};
