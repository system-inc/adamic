<input type="checkbox" checked defaultChecked />
export {};
