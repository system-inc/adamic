enum Kind { Plain = 'button', Odd = 'menu' }
declare const kind: Kind;
const a = <button type={kind} />;

export {};
