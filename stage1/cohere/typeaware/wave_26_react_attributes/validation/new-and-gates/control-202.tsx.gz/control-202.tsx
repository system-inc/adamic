React.createElement('input', { checked: 2 })
export {};
