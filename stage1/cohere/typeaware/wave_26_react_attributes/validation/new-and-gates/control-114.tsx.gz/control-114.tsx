declare const React: any;
React.createElement();

export {};
