declare const kind: string;
const a = <button type={kind} />;

export {};
