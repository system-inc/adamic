interface C{}; const C=React.memo(()=> <div/>); C.displayName='C';
export {};
