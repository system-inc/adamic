class extends React.Component { render(){ return <div/>; } }
export {};
