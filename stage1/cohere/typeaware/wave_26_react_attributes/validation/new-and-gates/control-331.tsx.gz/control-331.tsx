const C = React.createContext();

export {};
