const element = <input CHECKED />;

export {};
