const a = <button type={0x10}/>;

export {};
