React.createElement("input", { checked: false })
export {};
