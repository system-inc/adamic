declare const props: object;
const a = <button {...props} type="button"/>;

export {};
