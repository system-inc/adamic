const a = <button type={'bu' + 'tton'}/>;

export {};
