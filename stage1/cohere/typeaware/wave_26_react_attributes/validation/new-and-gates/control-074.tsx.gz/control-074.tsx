declare const a: string | undefined;
const e = <button type={a ?? 'button'}/>;

export {};
