const kind = 'submit' as const;
const a = <button type={kind} />;

export {};
