var H = createReactClass({ render: function Named(){ return <div/>; } });

export {};
