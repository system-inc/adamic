const b=<input checked defaultChecked/>;
export {};
