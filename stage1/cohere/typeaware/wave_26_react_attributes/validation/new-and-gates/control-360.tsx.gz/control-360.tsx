const a=<button type={'世界🌍'}/>;
export {};
