declare function require(name: string): any;
const createElement = require('react').createElement;
createElement('input', { checked: true });

export {};
