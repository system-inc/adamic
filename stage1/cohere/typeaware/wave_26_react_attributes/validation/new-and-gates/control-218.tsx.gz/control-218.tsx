
        export default class Hello {
          render() {
            return <div>Hello {this.props.name}</div>;
          }
        }
      
export {};
