const C = React.createContext();
C.displayName = "C";

export {};
