enum Kind { Plain = 'button', Send = 'submit' }
declare const kind: Kind;
const a = <button type={kind} />;

export {};
