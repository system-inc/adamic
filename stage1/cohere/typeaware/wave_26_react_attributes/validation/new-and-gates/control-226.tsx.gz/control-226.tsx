
        var Hello = () => {
          return <div>Hello {this.props.name}</div>;
        }
      
export {};
