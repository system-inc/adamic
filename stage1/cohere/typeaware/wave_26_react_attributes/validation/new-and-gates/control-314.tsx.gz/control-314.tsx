createReactClass named
export {};
