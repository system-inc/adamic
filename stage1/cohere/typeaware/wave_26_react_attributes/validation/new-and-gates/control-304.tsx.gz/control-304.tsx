import {memo,forwardRef} from 'react';
const C = memo(x, forwardRef((p,r) => <div/>));

export {};
