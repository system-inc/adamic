declare function require(name: string): any;
const { createElement } = require('react');
createElement('input', { checked: true });

export {};
