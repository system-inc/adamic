declare const React:any;const {createElement}=React;createElement('input',{checked:1});
export {};
