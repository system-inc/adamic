declare const kind:'button'|'submit';const b=<button type={kind}/>;
export {};
