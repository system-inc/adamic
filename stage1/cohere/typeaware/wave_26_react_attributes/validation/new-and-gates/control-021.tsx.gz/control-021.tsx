React.createElement("button", {type: condition ? "button" : "reset"})
export {};
