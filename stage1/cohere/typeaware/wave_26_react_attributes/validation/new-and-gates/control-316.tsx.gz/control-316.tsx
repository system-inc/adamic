createReactClass with displayName
export {};
