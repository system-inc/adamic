const element = <input xlink:href="x" checked readOnly />;

export {};
