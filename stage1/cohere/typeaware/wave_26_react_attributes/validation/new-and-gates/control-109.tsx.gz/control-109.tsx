const a = <button type="nope"/>;

export {};
