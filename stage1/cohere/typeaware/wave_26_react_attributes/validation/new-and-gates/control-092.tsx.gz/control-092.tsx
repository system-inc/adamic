declare const props: object;
const a = <button type="button" {...props}/>;

export {};
