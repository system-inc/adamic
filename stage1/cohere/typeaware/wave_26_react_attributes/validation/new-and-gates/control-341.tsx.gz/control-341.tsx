const Mixin = { Button(){ return <button/>; } };

export {};
