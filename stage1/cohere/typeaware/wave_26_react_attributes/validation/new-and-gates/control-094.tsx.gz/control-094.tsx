declare const React: any;
React.createElement('button', {'type': 'foo'});

export {};
