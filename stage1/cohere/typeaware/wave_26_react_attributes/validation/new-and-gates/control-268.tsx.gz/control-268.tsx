
        import React, { memo, forwardRef } from 'react'

        const MixedNotShadowed = function () {
          const Comp = memo(() => {
            return <div>not shadowed</div>
          })
          const ReactMemo = React.memo(() => null)
          const ReactForward = React.forwardRef((props, ref) => {
            return `${props} ${ref}`
          })
          const OtherComp = forwardRef((props, ref) => `${props} ${ref}`)

          return [Comp, ReactMemo, ReactForward, OtherComp]
        }
      
export {};
