
        module.exports = function Hello() {
          return <div>Hello {this.props.name}</div>;
        }
      
export {};
