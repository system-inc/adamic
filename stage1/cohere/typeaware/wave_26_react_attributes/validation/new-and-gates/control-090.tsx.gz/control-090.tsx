const a = <button TYPE="button"/>;

export {};
