React.createElement('input', { checked: true })
export {};
