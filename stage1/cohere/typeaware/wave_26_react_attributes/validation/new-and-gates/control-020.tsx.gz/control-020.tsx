React.createElement("button", {type: condition ? "button" : "foo"})
export {};
