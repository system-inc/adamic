import {memo} from 'react';
const C = memo(() => <div/>);
function f(){ const C = 1; C.displayName = 'x'; }

export {};
