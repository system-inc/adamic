<button type={`foo`}/>
export {};
