<button type={condition ? "button" : "reset"}/>
export {};
