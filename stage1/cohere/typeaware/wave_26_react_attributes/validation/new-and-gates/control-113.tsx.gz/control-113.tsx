declare const maybe: undefined | ((tag: string) => void);
maybe?.('button');

export {};
