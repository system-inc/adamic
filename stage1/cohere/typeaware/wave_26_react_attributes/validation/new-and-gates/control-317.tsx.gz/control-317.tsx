var Hello = createReactClass({ displayName: "H", render: function(){ return <div/>; } });

export {};
