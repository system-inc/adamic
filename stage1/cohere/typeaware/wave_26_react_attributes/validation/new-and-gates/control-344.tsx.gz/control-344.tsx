import {memo} from 'react';
const C = memo(() => <div/>);
interface C { x: number }
C.displayName = 'C';

export {};
