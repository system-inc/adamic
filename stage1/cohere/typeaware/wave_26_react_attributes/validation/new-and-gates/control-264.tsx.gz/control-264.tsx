
        import { createContext } from 'react';

        var Hello;
        Hello = createContext();
        Hello.displayName = "HelloContext";
      
export {};
