import {memo} from 'react';
export const C = memo(function Hello(){ return <p/>; });

export {};
