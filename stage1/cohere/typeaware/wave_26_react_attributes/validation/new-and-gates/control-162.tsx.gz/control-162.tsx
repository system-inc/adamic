import { createElement } from 'preact';
createElement('input', { checked: true });

export {};
