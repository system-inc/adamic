
        obj._property = (a) => {
          if (a == null) return null;
          return f(a);
        };
      
export {};
