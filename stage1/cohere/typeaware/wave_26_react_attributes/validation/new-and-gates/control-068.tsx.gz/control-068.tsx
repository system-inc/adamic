const a = <button type={-1}/>;

export {};
