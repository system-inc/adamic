function Button({ type = 'button' }: ButtonProperties) { return <button type={type} />; }

export {};
