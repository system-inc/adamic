  const Block = memo(() => <div>shadowed</div>)

export {};
