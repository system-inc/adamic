demo = () => () => null;

export {};
