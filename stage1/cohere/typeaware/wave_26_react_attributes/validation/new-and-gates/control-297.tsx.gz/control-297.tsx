  const memo = (cb) => cb()

export {};
