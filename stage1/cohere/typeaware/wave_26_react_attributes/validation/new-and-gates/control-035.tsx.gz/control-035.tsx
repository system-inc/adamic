<button type={condition ? 'button' : 'submit'}/>
export {};
