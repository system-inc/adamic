declare function require(name: string): any;
const createElement = require('preact').createElement;
createElement('input', { checked: true });

export {};
