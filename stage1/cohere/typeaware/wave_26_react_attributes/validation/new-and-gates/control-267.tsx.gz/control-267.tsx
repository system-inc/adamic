
        import React, { memo, forwardRef } from 'react'

        const Test1 = function () {
          const Comp = memo(() => <div>not param shadowed</div>)
          return Comp
        }

        const Test2 = function () {
          function innerFunction() {
            const Comp = memo(() => <div>nested not shadowed</div>)
            const ForwardComp = React.forwardRef(() => <div>nested</div>)
            return [Comp, ForwardComp]
          }
          return innerFunction()
        }
      
export {};
