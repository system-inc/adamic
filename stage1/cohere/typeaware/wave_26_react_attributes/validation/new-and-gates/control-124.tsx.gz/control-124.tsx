declare const React: { createElement(...a: unknown[]): unknown };
declare const type: 'button' | 'submit';
React.createElement('button', { type });

export {};
