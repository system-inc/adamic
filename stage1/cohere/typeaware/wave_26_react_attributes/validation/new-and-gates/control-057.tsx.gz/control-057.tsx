const a = <button type={42}/>;

export {};
