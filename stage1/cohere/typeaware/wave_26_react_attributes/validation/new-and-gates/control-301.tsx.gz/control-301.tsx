var H = createReactClass({ Hello: function(){ return <div/>; } });

export {};
