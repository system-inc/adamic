declare const props: object;
const a = <div {...props}/>;

export {};
