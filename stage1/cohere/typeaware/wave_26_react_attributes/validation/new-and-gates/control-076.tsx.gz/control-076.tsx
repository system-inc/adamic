declare const a: boolean;
const e = <button type={(a ? 'button' : 'foo')}/>;

export {};
