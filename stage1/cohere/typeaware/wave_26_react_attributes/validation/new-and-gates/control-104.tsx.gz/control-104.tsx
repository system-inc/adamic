import { createElement } from 'react';
createElement('button');

export {};
