declare const React: any;
declare const type: string;
React.createElement("button", {type});
export {};
