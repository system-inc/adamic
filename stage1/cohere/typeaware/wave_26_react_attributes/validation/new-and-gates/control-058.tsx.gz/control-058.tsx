const a = <button type={1.50}/>;

export {};
