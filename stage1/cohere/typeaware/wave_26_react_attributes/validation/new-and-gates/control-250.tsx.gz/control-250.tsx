
        const f = (a) => () => {
          if (a) {
            return null;
          }
          return 1;
        };
      
export {};
