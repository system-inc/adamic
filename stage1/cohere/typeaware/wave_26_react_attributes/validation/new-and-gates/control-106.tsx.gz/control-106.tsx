const a = <button type="button"/>;

export {};
