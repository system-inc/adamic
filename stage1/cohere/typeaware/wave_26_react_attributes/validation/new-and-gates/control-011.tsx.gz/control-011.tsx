<button type={condition ? foo : "button"}/>
export {};
