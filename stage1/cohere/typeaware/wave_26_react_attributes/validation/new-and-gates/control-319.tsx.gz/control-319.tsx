class Hello extends React.Component { static get displayName(){ return "H"; } render(){ return <div/>; } }

export {};
