
        var Hello = function() {
          return <div>Hello {this.props.name}</div>;
        }
      
export {};
