const a = <button type={``}/>;

export {};
