const make = () => (props) => <div/>;

export {};
