class Hello extends React.Component { render(){ return <div/>; } }

export {};
