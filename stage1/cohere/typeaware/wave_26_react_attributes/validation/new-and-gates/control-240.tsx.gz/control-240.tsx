
        module.exports = {
          createElement: tagName => document.createElement(tagName)
        };
      
export {};
