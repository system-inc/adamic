class Hello extends React.Component { static displayName = "H"; render(){ return <div/>; } }

export {};
