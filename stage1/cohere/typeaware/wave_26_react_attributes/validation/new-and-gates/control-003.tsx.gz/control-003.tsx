<button type={"foo"}/>
export {};
