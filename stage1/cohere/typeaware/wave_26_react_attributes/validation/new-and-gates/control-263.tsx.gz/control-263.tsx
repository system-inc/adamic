
        import { createContext } from 'react';

        let Hello;
        Hello = createContext();
        Hello.displayName = "HelloContext";
      
export {};
