declare const React: any;
React.createElement('input', { readonly: true, checked: true });

export {};
