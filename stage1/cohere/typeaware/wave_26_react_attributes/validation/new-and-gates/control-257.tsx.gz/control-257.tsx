
        demo = {
          property: () => () => null
        }
      
export {};
