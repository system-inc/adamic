React.createElement('span')
export {};
