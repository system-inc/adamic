declare const Preact: any;
const createElement = Preact.createElement;
createElement('input', { checked: true });

export {};
