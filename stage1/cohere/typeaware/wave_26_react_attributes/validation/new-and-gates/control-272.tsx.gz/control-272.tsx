
        module.exports = function() {
          return <div>Hello {props.name}</div>;
        }
      
export {};
