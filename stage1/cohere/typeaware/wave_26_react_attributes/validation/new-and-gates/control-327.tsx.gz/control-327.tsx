import {forwardRef} from 'react';
const C = forwardRef((p,r) => <div/>);

export {};
