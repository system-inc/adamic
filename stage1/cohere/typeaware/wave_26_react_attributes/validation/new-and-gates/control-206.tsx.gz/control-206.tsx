declare const factory: { make(): (tag: string) => void };
factory.make()('input');

export {};
