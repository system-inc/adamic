createElement with an untyped shorthand
export {};
