const a=<button type={'\u0085\u00a0\u200b\u{10ffff}'}/>;
export {};
