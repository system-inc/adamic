declare const part: string;
const a = <button type={`bu${part}tton`}/>;

export {};
