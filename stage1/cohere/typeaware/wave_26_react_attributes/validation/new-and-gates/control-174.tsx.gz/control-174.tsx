declare function createElement(a: string): void;
import { createElement } from 'react';
createElement('input', { checked: true });

export {};
