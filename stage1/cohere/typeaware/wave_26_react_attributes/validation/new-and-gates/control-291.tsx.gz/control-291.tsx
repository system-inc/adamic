
        import { createContext } from 'react';

        var Hello;
        Hello = createContext();
      
export {};
