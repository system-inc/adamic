<button type="foo"/>
export {};
