
        const { createElement } = document;
        createElement("a");
      
export {};
