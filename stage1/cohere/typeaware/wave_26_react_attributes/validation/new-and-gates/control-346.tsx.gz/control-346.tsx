memo(() => <div/>)
export {};
