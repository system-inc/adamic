React.createElement('input', { checked: 1 }, React.createElement('input', { checked: 2 }))
export {};
