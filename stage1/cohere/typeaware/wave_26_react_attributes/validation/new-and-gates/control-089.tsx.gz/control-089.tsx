declare const BUTTON: any;
const a = <BUTTON/>;

export {};
