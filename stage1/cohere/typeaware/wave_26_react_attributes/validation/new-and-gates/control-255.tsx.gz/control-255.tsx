
        _variable = (a) => {
          if (a == null) return null;
          return f(a);
        };
      
export {};
