
        const renderer = a => function Component(listItem) {
          return <div>{a} {listItem}</div>;
        };
      
export {};
