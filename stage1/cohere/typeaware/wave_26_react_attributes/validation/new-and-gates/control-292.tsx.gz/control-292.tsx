
        import { createContext } from 'react';

        var Hello;
        Hello = React.createContext();
      
export {};
