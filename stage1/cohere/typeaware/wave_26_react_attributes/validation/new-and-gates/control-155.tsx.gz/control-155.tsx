React.createElement('input', { checked: true, onChange: noop, readOnly: true })
export {};
