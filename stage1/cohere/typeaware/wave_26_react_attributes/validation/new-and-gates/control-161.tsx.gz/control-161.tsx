import { createElement } from 'react';
createElement('input', { checked: true });

export {};
