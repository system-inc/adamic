declare const React: any;
React.createElement('button', {});

export {};
