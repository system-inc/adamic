
        import * as React from 'react';

        const Hello = React.createContext();

        const obj = {};
        obj.displayName = "False positive";

        Hello.displayName = "HelloContext";
      
export {};
