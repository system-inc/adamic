function createElement(tag: string, properties: object) { return tag; }
createElement('input', { checked: true });

export {};
