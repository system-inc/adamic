var Hello = createReactClass({ render: function(){ return <div/>; } });

export {};
