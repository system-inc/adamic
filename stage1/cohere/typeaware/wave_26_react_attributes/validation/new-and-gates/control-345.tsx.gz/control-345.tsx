import {memo} from 'react';
interface C { x: number }
const C = memo(() => <div/>);

export {};
