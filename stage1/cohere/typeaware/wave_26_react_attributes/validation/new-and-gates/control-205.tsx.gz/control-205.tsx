declare const maybe: undefined | ((tag: string) => void);
maybe?.('input');

export {};
