<button type={'foo'}/>
export {};
