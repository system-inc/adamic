declare const foo: string;
const a = <button type={`button${foo}`}/>;
export {};
