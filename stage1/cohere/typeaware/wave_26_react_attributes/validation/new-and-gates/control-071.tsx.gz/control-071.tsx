declare const condition: boolean;
const a = <button type={condition ? 'foo' : 'bar'}/>;

export {};
