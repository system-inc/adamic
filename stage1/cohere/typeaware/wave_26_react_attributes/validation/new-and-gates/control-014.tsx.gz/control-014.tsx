<button type={condition ? "reset" : "button"}/>
export {};
