import {memo} from 'react';
const C = memo(() => <div/>);
D.displayName = 'x';

export {};
