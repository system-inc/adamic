const element = <input checked />;

export {};
