const element = <input {...{ checked: true }} />;

export {};
