function Button({ type }: ButtonProperties) { return <button type={type} />; }

export {};
