
        export const demo = (a) => (b) => {
          if (a == null) return null;
          return b;
        }
      
export {};
