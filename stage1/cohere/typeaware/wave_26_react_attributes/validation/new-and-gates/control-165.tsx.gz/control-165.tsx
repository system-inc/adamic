declare const React: any;
const createElement = React.createElement;
createElement('input', { checked: true });

export {};
