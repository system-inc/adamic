import {forwardRef} from 'react';
foo(forwardRef((p,r) => <div/>));

export {};
