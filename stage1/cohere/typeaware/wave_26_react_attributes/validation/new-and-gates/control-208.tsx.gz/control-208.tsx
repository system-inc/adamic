declare const React: any;
React.createElement('input', null);

export {};
