import { createElement } from 'react';
declare function createElement(a: string): void;
createElement('input', { checked: true });

export {};
