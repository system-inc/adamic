const a = <button type={true}/>;

export {};
