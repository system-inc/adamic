declare const Preact: any;
Preact.createElement('input', { checked: true });

export {};
