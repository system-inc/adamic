const a = <button type={null}/>;

export {};
