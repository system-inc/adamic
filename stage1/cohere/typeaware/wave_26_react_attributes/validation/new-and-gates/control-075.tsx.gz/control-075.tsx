const e = <button type={('foo')}/>;

export {};
