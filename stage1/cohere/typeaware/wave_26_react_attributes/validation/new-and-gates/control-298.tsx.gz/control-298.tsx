  const BlockReactMemo = React.memo(() => <div>shadowed</div>)

export {};
