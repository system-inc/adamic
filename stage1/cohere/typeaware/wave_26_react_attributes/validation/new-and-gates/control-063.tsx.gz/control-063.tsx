const a = <button type={/re/}/>;

export {};
