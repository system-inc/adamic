declare const Button: any;
const a = <Button/>;

export {};
