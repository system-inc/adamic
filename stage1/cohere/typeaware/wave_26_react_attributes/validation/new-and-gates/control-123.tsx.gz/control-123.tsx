createElement with a typed shorthand
export {};
