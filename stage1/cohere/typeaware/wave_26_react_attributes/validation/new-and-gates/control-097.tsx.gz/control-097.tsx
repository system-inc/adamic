declare const React: any;
React.createElement('button', null);

export {};
