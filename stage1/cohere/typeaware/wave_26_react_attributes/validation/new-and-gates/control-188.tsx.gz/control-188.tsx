declare const Checkbox: any;
const element = <Checkbox checked />;

export {};
