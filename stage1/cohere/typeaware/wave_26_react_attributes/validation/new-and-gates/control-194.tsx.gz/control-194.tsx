declare const React: any;
React.createElement('Checkbox', { checked: true });

export {};
