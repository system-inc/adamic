
        export default class {
          render() {
            return <div>Hello {this.props.name}</div>;
          }
        }
      
export {};
