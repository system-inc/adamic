let C;
C = React.createContext();
C.displayName = "C";

export {};
