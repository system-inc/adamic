var H = createReactClass({ Hello: () => <div/> });

export {};
