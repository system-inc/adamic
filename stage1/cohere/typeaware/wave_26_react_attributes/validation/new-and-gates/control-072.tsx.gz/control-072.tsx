declare const condition: boolean;
const a = <button type={condition ? 'button' : 'submit'}/>;

export {};
