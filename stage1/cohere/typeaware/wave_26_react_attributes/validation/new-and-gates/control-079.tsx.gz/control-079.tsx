declare const condition: boolean;
declare const foo: string;
const a = <button type={condition ? "button" : foo}/>;
export {};
