
        import React, { memo, forwardRef } from 'react'

        const TestComponent = function () {
          {
            const BlockReactMemo = React.memo(() => {
              return <div>not shadowed</div>
            })

            const BlockMemo = memo(() => {
              return <div>not shadowed</div>
            })

            const BlockForwardRef = forwardRef((props, ref) => {
              return `${props} ${ref}`
            })
          }

          return null
        }
      
export {};
