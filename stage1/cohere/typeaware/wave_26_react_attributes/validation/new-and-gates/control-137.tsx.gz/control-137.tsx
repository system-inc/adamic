<input type="checkbox" checked={condition ? true : false} />
export {};
