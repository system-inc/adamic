declare const foo: string;
const a = <button type={foo}/>;

export {};
