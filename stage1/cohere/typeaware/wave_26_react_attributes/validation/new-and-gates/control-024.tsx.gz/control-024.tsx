React.createElement("button", {type: condition ? "reset" : "button"})
export {};
