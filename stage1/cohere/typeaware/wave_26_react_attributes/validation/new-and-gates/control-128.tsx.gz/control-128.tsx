declare const kind: 'button' | 'foo';
const a = <button type={kind} />;

export {};
