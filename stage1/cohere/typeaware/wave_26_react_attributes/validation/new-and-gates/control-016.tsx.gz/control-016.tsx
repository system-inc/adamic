React.createElement("button", {type: foo})
export {};
