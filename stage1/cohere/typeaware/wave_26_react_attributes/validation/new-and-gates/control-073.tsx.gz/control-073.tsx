declare const a: boolean;
declare const b: boolean;
const e = <button type={a ? (b ? 'button' : 'foo') : 'reset'}/>;

export {};
