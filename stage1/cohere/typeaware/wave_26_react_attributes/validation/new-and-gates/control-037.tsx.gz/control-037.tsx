React.createElement("span")
export {};
