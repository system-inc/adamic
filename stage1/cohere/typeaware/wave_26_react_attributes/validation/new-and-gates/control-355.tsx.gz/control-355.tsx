// 世界🌍
export default function(){return <div/>;}
export {};
