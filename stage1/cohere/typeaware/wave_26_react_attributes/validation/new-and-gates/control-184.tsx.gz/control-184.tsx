declare const React: any;
declare const rest: object;
React.createElement('input', { checked: true, ...rest });

export {};
