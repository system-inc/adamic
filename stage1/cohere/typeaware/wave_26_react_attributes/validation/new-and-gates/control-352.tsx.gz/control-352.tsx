const b = <button type={c ? 'bad' : 'wrong'} />;
export {};
