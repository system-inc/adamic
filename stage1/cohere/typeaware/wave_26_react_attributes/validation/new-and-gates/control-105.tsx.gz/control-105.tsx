declare const React: any;
React.createElement('button', {type: 'button'}, 'x');

export {};
