const a = <button type={undefined}/>;

export {};
