const a = <button type={1n}/>;

export {};
