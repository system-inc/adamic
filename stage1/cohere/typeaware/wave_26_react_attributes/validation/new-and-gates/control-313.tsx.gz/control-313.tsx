const Hello = class Inner extends React.Component { render(){ return <div/>; } };

export {};
