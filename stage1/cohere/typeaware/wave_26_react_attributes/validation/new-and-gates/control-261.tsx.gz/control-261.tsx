
        import { createContext } from 'react';

        const Hello = createContext();

        const obj = {};
        obj.displayName = "False positive";

        Hello.displayName = "HelloContext"
      
export {};
