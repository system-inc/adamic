React.createElement('input', { checked: true, onChange: noop })
export {};
