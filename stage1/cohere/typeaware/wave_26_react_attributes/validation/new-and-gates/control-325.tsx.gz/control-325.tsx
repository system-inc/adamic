import {memo} from 'react';
const C = memo(() => <div/>);

export {};
