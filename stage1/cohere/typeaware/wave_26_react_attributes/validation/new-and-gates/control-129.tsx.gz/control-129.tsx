declare const kind: any;
const a = <button type={kind} />;

export {};
