declare const button: any;
const a = <button.x/>;

export {};
