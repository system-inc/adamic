declare function load(name: string): any;
const { createElement } = load('react');
createElement('input', { checked: true });

export {};
