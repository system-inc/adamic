declare const createElementSomethingElse: unknown;
createElement('input', { checked: true });

export {};
