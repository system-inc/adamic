declare const React: any;
React.createElement('input', { 'checked': true });

export {};
