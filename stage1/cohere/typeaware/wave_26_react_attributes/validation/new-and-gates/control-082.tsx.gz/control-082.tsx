declare const React: any;
declare const foo: string;
React.createElement("button", {type: foo});
export {};
