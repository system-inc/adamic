React.createElement("button", {type: condition ? 'button' : 'submit'})
export {};
