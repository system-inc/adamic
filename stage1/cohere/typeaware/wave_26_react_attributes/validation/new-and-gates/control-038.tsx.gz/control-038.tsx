React.createElement("span", {type: "foo"})
export {};
