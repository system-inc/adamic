declare const Foo: any;
Foo.createElement("span");

export {};
