var H = createReactClass({ "displayName": "H", render: function(){ return <div/>; } });

export {};
