declare const React: any;
const { createElement } = React;
createElement('input', { checked: true });

export {};
