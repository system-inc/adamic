function memo(f){return f;}
const C = memo(() => <div/>);

export {};
