React.createElement("input", { checked: true, defaultChecked: true })
export {};
