import {memo,forwardRef} from 'react';
const C = memo(forwardRef((p,r) => <div/>));

export {};
