
        import { createContext } from 'react';

        const Hello = createContext();
        Hello.displayName = "HelloContext"
      
export {};
