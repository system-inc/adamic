const C = class extends React.Component { render(){ return <div/>; } };

export {};
