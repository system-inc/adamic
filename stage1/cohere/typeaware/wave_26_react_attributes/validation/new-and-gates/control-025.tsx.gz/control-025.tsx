React.createElement("button", {...extraProps})
export {};
