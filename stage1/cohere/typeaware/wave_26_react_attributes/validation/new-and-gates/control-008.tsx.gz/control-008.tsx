<button type={condition ? "button" : foo}/>
export {};
