var M = { G: { Hello: function(){ return <div/>; } } };
M.G.Hello.displayName = "H";

export {};
