<span type="foo"/>
export {};
