const a = <button type={1e3}/>;

export {};
