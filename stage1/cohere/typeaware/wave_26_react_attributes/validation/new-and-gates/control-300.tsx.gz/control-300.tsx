var H = createReactClass({ render: function(){ return <div/>; } });

export {};
