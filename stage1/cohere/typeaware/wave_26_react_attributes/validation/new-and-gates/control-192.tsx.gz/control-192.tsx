declare const React: any;
React.createElement('select', { checked: true });

export {};
