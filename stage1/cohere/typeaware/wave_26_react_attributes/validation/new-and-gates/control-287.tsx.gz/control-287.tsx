
        const renderer = a => listItem => (
          <div>{a} {listItem}</div>
        );
      
export {};
