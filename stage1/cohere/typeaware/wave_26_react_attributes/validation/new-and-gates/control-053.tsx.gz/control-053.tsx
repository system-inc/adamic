declare const Foo: any;
Foo.createElement("button");

export {};
