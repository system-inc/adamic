declare const React: any;
declare const spread: object;
React.createElement('button', {...spread, type: 'foo'});

export {};
