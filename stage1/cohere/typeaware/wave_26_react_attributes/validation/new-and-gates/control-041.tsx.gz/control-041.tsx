React.createElement("button", {type: `button`})
export {};
