declare const props: object;
const a = <button {...props}/>;

export {};
