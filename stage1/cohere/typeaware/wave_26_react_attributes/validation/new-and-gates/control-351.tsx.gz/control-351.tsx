const C = React.memo(() => <div/>);
export {};
