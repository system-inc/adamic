document.createElement('input');

export {};
