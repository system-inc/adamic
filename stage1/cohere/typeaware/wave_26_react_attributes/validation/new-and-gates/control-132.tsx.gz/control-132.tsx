declare const React: { createElement(...a: unknown[]): unknown };
declare const type: string;
React.createElement('button', { type });

export {};
