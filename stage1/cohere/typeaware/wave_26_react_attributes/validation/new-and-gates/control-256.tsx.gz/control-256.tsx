
        demo = () => () => null;
      
export {};
