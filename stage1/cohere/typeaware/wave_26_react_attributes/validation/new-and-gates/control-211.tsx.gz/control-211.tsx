
        import React, { memo, forwardRef } from 'react'

        const Test1 = function (memo) {
          return memo(() => <div>param shadowed</div>)
        }

        const Test2 = function ({ forwardRef }) {
          return forwardRef(() => <div>destructured param</div>)
        }
      
export {};
