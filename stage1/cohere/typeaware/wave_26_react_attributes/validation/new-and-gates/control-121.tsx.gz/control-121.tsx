declare const condition: boolean;
declare const kind: 'reset' | 'button';
const a = <button type={condition ? 'submit' : kind} />;

export {};
