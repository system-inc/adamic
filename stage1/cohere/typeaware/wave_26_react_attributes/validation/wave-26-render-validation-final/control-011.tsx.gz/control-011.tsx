import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
// @validateNoSetStateInRender
function Component(props) {
  const [x, setX] = useState(0);
  const aliased = setX;

  setX(1);
  aliased(2);

  return x;
}

export {};
