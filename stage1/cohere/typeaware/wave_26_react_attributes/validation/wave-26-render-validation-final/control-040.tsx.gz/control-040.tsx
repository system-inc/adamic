import {useState} from 'react';
export function useThing() {
  const [x, setX] = useState(0);
  setX(1);
  return x;
}

export {};
