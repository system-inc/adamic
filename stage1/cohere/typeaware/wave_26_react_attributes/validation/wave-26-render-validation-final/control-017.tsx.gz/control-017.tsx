import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
// @validateNoSetStateInRender
function Component(props) {
  const [x, setX] = useState(0);

  const foo = () => {
    setX(1);
  };
  foo();

  return [x];
}

export {};
