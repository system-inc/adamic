import {useState} from 'react';
function Component(props: {a: number}) {
  const [x, setX] = useState(0);
  const other = props.a;
  const foo = () => { const t = other; setX(1); return t; };
  foo();
  return x;
}

export {};
