import {useState, useMemo} from 'react';
function Component(props: {c: boolean}) {
  const [x, setX] = useState(0);
  const y = useMemo(() => { if (props.c) { setX(1); } return 1; }, []);
  return y;
}

export {};
