import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
function Component() {
  const setThing = (v: number) => {};
  setThing(1);
  return null;
}

export {};
