import {useState} from 'react';
function helper() {
  const [x, setX] = useState(0);
  setX(1);
  return x;
}

export {};
