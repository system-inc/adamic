import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
function Component() {
  const plain: (value: number) => void = (v) => {};
  plain(1);
  return null;
}

export {};
