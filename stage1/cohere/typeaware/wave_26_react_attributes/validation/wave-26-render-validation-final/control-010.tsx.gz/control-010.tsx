function Component() {
  const setThing = (v: number) => {};
  setThing(1);
  return null;
}

export {};
