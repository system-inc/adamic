import {useState} from 'react';
function Component() {
  const f = () => { const [a, setA] = useState(0); setA(1); };
  f();
  return 1;
}

export {};
