import {useState} from 'react';
function useCustomState(init: number) {
  return useState(init);
}
export function Component() {
  const [state, setState] = useCustomState(0);
  setState(1);
  return state;
}

export {};
