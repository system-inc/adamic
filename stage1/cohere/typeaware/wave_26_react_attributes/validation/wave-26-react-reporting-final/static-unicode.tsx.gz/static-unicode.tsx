function Component(){const Inner = () => '世界🌍';return <Inner/>;}
export {};
