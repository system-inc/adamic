import os,pathlib,subprocess,json,time
R=pathlib.Path('/workspace/adamic'); G=pathlib.Path('/workspace/wave-26-d3a-gate'); A=pathlib.Path('/workspace/wave-26-attributes'); P=R/'stage1/cohere/typeaware/wave_26_react_reporting'; records=[]
env=dict(os.environ,TMPDIR='/workspace/wave-26-bridge-scratch',ADAMIC_TYPESCRIPT_SOURCE='/workspace/wave-26-typescript',ADAMIC_WAVE26_REPOSITORY_MANIFEST='/workspace/wave-26-repository.manifest',ADAMIC_WAVE26_COMPILER_MANIFEST='/workspace/wave-26-compiler.manifest',ADAMIC_TSGO_CORPUS='/workspace/wave-26-typescript')
def run(name,cmd,extra=None):
 print('START',name,flush=True); start=time.monotonic()
 with (G/(name+'.log')).open('wb') as f: result=subprocess.run([str(x) for x in cmd],cwd=R,env=dict(env,**(extra or {})),stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=[str(x) for x in cmd],exit=result.returncode,seconds=time.monotonic()-start));(G/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print('END',name,result.returncode,flush=True);assert result.returncode==0,name
run('proven-lowering',['go','test','./internal/lower','-run','^Test(UnprovenPredicateReturnsAreRefused|PredicateBodiesAreProven|ProvenRelationsRefuse|ProvenRelationsErase)$','-count=1','-v','-timeout','10m'])
run('records',['go','test','./internal/native','-run','^Test(RecordsAgainstNode|RecordMutants|RecordReadMutants)$','-count=1','-v','-timeout','10m'])
run('runtime-paths',['go','test','./internal/native','-run','^TestRuntime(ReleasePaths|StringEquality)$','-count=1','-v','-timeout','10m'])
run('registry',['go','test','./stage1/cohere/lint/registry','-count=1','-v','-timeout','15m'])
run('shared-harness',['go','test','./stage1/cohere/lint','-run','^Test(EmittedJavaScriptMismatch|DotARename|CompleteSuggestionSerialization|SuggestionAlongsideAutomaticFix|WitnessScriptKind)$','-count=1','-v','-timeout','15m'])
run('build-adamic',['go','build','-o',A/'adamic','./cmd/adamic'])
run('build-checker',['go','build','-buildmode=c-archive','-o',A/'checker.a','./bridge/tsgo/archive'])
run('build-server',['go','build','-o',A/'checker-server',R/'stage1/cohere/typeaware/wave_26_react_attributes/testdata/checker_server.go'])
for suffix,label,test in [('', 'first','TestWave26AgreementAndMutants'),('_NEXT','next','TestWave26NextAgreementAndMutants'),('_THIRD','third','TestWave26ThirdAgreementAndMutants'),('_FOURTH','fourth','TestWave26FourthAgreementAndMutants'),('_FIFTH','fifth','TestWave26FifthAgreementAndMutants')]:
 scratch=pathlib.Path('/workspace/wave-26-react-regreen')/label
 run(label,['go','test','./stage1/cohere/typeaware','-run','^'+test+'$','-count=1','-v','-timeout','30m'],{'ADAMIC_WAVE26'+suffix+'_ARTIFACTS':str(scratch)})
 for name in ['checker.a','checker-asan.a','released-registry.a','released','released-mutant','wave26','wave26asan','wave26oracle','wave26-asan','wave26-oracle']:
  p=scratch/name
  if p.exists():p.unlink()
run('raw-hir',['python3',P/'validate_hir.py','--scratch','/workspace/wave-26-rawhir'])
for label,script,scratch,extra in [('static','validate_static.py','/workspace/wave-26-static-validation-pass',[]),('render','validate_state.py','/workspace/wave-26-render-validation-final',['--rule','render']),('effect','validate_state.py','/workspace/wave-26-effect-validation-final',['--rule','effect'])]:
 run(label,['python3',P/script,'--scratch',scratch,'--tools',A,'--compiler-manifest','/workspace/wave-26-compiler.manifest','--repository-manifest','/workspace/wave-26-repository.manifest',*extra])
run('react-node',['python3',P/'validate_node.py','--tools',A,'--scratch','/workspace/wave-26-react-node-landing','--static','/workspace/wave-26-static-validation-pass','--render','/workspace/wave-26-render-validation-final','--effect','/workspace/wave-26-effect-validation-final'])
for label,script in [('attributes','validate.py'),('dependencies','validate_dependencies.py'),('questions','validate_question_mutants.py')]:run(label,['python3',R/'stage1/cohere/typeaware/wave_26_react_attributes'/script])
run('bridge',['go','test','./bridge/tsgo/...','-count=1','-v','-timeout','15m'])
run('node-oracle',['go','test','./internal/oracle','-run','^TestRuntimeLastIndexOfMatchesNode$|^TestTheOracleCatchesOneByte$|^TestNativeAgreesWithNode$/internal/oracle/testdata/(maps_and_text|sorting|string_index|lone_surrogates|functions|closures|inherited_static_field_read|proven_assertions|proven_class_guards|proven_guards|proven_satisfies|proven_upcasts)\\.a$','-count=1','-timeout','10m','-v'])
run('typeof-oracle',['go','test','./internal/oracle','-run','^TestTypeOf(ConstructorMutant|StringLiteralMutant|NullMutant|NullSlotPresenceMutant)$|^TestNativeAgreesWithNode$/internal/oracle/testdata/typeof_(dispatch|null|null_compare|null_roll|null_slots|null_switch|string_literal)\\.a$','-count=1','-v','-timeout','15m'])
run('vet',['go','vet','./...'])
run('decoded-options',['go','test','./stage1/cohere/lint','-run','^TestDecodedOptionsAndMutant$','-count=1','-v','-timeout','15m'])
run('cost',['python3',R/'stage1/cohere/typeaware/wave_26_react_attributes/validate_cost.py'])
print('ALL PASS',flush=True)
