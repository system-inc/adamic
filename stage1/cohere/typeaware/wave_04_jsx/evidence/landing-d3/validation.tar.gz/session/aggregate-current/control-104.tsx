export {};
declare const Ctx: {Provider:any};
declare const c:boolean;
declare const props:any;
declare const cache:any;
declare const store:any;
declare function opaque():any;
declare function createContext<T>(value:T):any;
declare function useMemo<T>(factory:()=>T,dependencies?:readonly unknown[]):T;
declare function useCallback<T>(factory:T,dependencies?:readonly unknown[]):T;
declare namespace React { class Component {} class PureComponent {} function createContext<T>(value:T):any; function memo<T>(value:T):T; function forwardRef<T>(value:T):T; }
function Component(){const dep0={};const dep1=dep0;const dep2=dep1;const dep3=dep2;const dep4=dep3;const dep5=dep4;const dep6=dep5;const dep7=dep6;const dep8=dep7;const value=useMemo(()=>({}),[dep8]);return <Ctx.Provider value={value}/>;}
