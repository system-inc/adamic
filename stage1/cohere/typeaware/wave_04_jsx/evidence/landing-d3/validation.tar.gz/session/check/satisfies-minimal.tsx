declare const Ctx:any;
function Component(){return <Ctx.Provider value={({} satisfies object)}/>;}
