export {};
declare const Ctx: {Provider:any};
declare const c:boolean;
declare const props:any;
declare const cache:any;
declare const store:any;
declare function opaque():any;
declare function createContext<T>(value:T):any;
declare function useMemo<T>(factory:()=>T,dependencies?:readonly unknown[]):T;
declare function useCallback<T>(factory:T,dependencies?:readonly unknown[]):T;
declare namespace React { class Component {} class PureComponent {} function createContext<T>(value:T):any; function memo<T>(value:T):T; function forwardRef<T>(value:T):T; }
function Component(){const dep=new Object();const value=useMemo(()=>({dep}),[dep]);return <Ctx.Provider value={value}/>;}
