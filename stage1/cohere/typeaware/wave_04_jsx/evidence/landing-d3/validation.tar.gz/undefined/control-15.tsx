export {};
declare global { var G:any; } const x=<G />;
