export {};
const x=<this.foo />;
