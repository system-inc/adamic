export {};
const App=null; const x=<App />;
