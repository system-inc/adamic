export {};
enum A {App} const x=<App />;
