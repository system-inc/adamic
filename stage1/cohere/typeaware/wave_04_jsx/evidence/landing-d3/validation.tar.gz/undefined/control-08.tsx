export {};
const x=<app.Foo.Bar />;
