export {};
const x=<ns:Tag />;
