export {};
const x=<테스트 />;
