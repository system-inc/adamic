export {};
const app={Foo:null}; const x=<app.Foo />;
