export {};
const x=<app.Foo />;
