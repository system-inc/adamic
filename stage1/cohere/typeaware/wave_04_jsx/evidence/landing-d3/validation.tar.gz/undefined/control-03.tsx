export {};
const x=<Foo-bar />;
