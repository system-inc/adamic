export {};
const x=<Promise />;
