export {};
const x=<_foo />;
