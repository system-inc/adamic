export {};
const x=<$foo />;
