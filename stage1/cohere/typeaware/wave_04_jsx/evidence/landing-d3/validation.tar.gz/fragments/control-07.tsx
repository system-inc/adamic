export {};
import {Fragment as F} from 'react'; const x=<F />;
