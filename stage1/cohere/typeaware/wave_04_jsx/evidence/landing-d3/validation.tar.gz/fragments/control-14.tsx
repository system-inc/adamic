export {};
const {Other:F}=React; const x=<F />;
