export {};
import {Fragment as F} from 'preact'; const x=<F />;
