export {};
const F=require('react'); const x=<F />;
