export {};
import {Other as F} from 'react'; const x=<F />;
