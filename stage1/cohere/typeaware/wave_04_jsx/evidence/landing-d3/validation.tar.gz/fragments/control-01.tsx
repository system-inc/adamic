export {};
const x=<React.Fragment>hello</React.Fragment>;
