export {};
const x=<React.Fragment {...props} />;
