export {};
const {Fragment:F}=React; const x=<F />;
