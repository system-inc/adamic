export {};
const [F]=React; const x=<F />;
