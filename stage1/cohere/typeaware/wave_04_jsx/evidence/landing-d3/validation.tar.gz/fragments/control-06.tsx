export {};
import {Fragment} from 'react'; const x=<Fragment />;
