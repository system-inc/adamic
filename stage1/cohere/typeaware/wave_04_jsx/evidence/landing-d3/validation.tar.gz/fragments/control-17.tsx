export {};
const x=/* 😀 é */ <React.Fragment />;
