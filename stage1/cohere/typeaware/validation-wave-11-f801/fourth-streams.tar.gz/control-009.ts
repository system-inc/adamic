function f(){const Number=()=>1;new Number}new Number;{const Boolean=()=>false;new Boolean}new Boolean;
export {};
