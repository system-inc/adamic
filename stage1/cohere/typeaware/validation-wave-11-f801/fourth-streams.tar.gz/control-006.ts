function f(Symbol:any,BigInt:any){new Symbol;new BigInt}class Symbol{};new Symbol;const BigInt=()=>1;new BigInt;
export {};
