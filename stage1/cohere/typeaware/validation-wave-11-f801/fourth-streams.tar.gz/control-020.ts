var a = Function.bind(null, "b", "c", "return b+c");
export {};
