var a = new globalThis.String('x');
export {};
