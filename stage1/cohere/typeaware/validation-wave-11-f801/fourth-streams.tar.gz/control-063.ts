var foo = Symbol('foo');
export {};
