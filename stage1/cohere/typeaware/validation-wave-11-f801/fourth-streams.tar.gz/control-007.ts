new String('x');new Number(0);new Boolean(false);new (String)('x');new ((Number))(0);new Boolean;String('x');Number(0);Boolean(false);
export {};
