/* 世界 🌍 */
new Function('x');
new Symbol;
new String('é');

export {};
