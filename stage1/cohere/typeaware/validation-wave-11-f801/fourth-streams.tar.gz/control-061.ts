function bar() { return function Symbol() {}; } var baz = new Symbol('baz');
export {};
