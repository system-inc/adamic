function Boolean() {} new Boolean();
export {};
