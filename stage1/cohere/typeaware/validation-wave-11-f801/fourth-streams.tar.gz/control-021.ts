var a = Function["call"](null, "b", "c", "return b+c");
export {};
