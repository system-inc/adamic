new \u0053ymbol;new \u0053tring;new \u0046unction('x');
export {};
