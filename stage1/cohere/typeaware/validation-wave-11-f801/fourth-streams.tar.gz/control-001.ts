(Function)('x');new ((Function))('x');(Function?.call)(null,'x');(Function)['bind'](null,'x');Function[`apply`](null,[]);Function[('call')](null,'x');
export {};
