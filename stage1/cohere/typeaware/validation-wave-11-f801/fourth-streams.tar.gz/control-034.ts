foo[Function]()
export {};
