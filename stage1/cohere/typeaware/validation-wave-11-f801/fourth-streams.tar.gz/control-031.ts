var x = function Function() { Function(); }
export {};
