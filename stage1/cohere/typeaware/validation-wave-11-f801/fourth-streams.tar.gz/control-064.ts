function bar(Symbol: any) { var baz = new Symbol('baz'); }
export {};
