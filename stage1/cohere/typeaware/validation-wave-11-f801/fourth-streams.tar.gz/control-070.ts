function BigInt() {} new BigInt();
export {};
