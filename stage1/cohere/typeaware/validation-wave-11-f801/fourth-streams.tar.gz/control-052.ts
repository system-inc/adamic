Function[`call`](null, "return 1");
export {};
