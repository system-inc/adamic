function f(String:any,Number:any,Boolean:any){new String;new Number;new Boolean}class String{};new String;
export {};
