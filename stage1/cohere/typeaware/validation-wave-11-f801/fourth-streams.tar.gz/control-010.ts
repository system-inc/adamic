new (Function as any)('x');(Function as any)('x');Function!('x');new (String as any)('x');new (Symbol as any)('x');
export {};
