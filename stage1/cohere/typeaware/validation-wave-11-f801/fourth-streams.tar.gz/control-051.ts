class Function {}; Function["call"](null);
export {};
