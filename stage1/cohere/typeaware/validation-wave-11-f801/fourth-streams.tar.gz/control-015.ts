var a = new Function("b", "c", "return b+c");
export {};
