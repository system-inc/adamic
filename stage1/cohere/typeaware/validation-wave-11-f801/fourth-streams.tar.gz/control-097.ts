var a = new string('x');
export {};
