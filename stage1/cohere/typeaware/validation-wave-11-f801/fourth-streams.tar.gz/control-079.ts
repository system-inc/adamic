
        function test(Number) {
            return new Number;
        }
        
export {};
