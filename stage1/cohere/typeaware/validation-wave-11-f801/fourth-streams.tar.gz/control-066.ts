new foo(Symbol);
export {};
