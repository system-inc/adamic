new Function('return 1');Function('return 2');Function.call(null,'x');Function.apply(null,['x']);Function.bind(null,'x')();new Function.call(null,'x');
export {};
