declare function Function():void;Function();declare const Symbol:unknown;new Symbol;declare class String{};new String;
export {};
