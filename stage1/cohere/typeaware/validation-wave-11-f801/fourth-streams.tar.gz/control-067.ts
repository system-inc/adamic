new foo(bar, Symbol);
export {};
