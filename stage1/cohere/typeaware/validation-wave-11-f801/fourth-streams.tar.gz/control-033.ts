new Class(Function)
export {};
