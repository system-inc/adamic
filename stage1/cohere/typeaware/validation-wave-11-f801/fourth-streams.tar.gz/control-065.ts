function Symbol() {} new Symbol();
export {};
