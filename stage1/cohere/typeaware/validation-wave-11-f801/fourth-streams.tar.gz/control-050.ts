function Function() {}; Function.apply(null, []);
export {};
