var a = new String;
export {};
