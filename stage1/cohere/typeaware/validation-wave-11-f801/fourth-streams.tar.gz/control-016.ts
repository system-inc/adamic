var a = Function("b", "c", "return b+c");
export {};
