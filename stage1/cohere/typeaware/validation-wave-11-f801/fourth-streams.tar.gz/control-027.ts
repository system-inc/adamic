class Function {}; new Function()
export {};
