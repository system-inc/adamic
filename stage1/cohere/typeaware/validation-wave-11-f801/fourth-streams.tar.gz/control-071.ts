new foo(BigInt);
export {};
