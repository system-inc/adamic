function bar(BigInt: any) { var baz = new BigInt(9007199254740991); }
export {};
