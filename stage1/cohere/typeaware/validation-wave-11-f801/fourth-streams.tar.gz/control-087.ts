var a = new (String)('x');
export {};
