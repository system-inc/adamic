Function.notAMethod();
export {};
