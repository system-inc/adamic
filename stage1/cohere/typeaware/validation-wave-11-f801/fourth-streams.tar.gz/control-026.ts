var a = _function("b", "c", "return b+c");
export {};
