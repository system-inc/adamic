var a = String('test'), b = String.fromCharCode(32);
export {};
