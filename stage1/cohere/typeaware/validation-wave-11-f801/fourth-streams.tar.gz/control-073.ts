var a = new String('hello');
export {};
