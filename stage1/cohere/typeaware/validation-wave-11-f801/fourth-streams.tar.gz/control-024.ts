var fn = function () { function Function() {} }; Function('', '')
export {};
