function f(){class Function{};new Function()}new Function('x');{const Function=()=>{};Function('x')}Function('x');
export {};
