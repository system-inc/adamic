Function.bind;
export {};
