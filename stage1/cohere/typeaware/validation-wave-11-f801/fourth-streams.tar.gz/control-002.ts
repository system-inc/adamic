Function.toString();Function.bind;const f=Function;new f('x');globalThis.Function('x');Function.call.call(null,'x');Function[key](null,'x');
export {};
