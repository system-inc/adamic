new foo(bar, BigInt);
export {};
