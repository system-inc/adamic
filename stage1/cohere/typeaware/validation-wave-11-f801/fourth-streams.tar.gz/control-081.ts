new String()
export {};
