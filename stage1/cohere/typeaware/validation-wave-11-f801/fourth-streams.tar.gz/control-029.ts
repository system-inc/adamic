function Function() {}; Function()
export {};
