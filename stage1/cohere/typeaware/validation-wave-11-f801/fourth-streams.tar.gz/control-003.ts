function f(Function:any){new Function('x');Function.call(null,'x')}class Function{};new Function('x');
export {};
