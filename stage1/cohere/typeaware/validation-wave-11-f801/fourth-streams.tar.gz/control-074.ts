var a = new Number(10);
export {};
