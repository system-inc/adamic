var a = Function.apply(null, ["b", "c", "return b+c"]);
export {};
