declare const foo: any;
foo.Function.call(null);

export {};
