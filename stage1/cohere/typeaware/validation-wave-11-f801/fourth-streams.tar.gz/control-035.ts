foo(Function.bind)
export {};
