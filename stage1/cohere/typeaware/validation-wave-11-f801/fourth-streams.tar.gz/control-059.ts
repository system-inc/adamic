var foo = new Symbol('foo');
export {};
