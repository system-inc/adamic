new Function;
export {};
