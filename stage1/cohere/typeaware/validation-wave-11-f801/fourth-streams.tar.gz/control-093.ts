class String {} new String();
export {};
