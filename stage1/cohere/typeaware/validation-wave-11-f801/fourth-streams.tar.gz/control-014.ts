import Function from './missing';Function('x');import Symbol from './missing';new Symbol;import String from './missing';new String;
export {};
