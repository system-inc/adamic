var a = new window.String('x');
export {};
