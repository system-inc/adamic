var a = new _function("b", "c", "return b+c");
export {};
