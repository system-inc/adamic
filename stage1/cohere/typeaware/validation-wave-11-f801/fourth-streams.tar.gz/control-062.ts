function bar() { return function BigInt() {}; } var baz = new BigInt(9007199254740991);
export {};
