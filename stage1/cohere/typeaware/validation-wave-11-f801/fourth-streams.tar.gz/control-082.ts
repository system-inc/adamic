
        /* global Boolean:off */
        assert(new Boolean);
        
export {};
