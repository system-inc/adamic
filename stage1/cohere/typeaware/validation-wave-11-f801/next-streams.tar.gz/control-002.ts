declare const x:number[]|[number];'missing' in x;declare const y:number[]|{value:number};'missing' in y;function generic<T extends number[]>(rows:T){return 'value' in rows;}
export {};
