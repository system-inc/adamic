declare const a:ReadonlyMap<string,number>|ReadonlySet<number>;a.size!==-1;declare const w:WeakMap<object,number>;w.size>=0;class Extra extends Map<string,number>{x=1};new Extra().size<0;
export {};
