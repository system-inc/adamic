interface String{trim():string};declare const s:String;s.trim();interface ReadonlyArray<T>{slice():T[]};declare const a:ReadonlyArray<number>;a.slice();
export {};
