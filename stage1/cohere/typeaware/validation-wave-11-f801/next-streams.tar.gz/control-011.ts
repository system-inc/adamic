declare const s:string;s.trim();s.trimStart();s.trimEnd();s.slice(1);s.replace('x','y');s.match(/x/);s.repeat(2);s.normalize();void s.trim();const saved=s.trim();
export {};
