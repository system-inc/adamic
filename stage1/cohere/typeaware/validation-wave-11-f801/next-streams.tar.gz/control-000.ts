declare const rows:string[]; 'Admin' in rows; '0' in rows; '01' in rows; 'length' in rows; 'map' in rows; '4294967294' in rows; '4294967295' in rows; '-1' in rows;
export {};
