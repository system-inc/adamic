function f(Object:{keys(x:unknown):string[]}){Object.keys(new Map())}Object['keys'](new Map());Object.keys();
export {};
