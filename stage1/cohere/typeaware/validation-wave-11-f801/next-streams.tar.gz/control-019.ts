import type {JsonFileWriteOutcomeType,JsonFileReadOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare function save():JsonFileWriteOutcomeType;save();(save());void save();const result=save();
export {};
