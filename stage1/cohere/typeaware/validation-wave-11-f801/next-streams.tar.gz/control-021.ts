import type {JsonFileWriteOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare const api:{save():JsonFileWriteOutcomeType}|undefined;api?.save();
export {};
