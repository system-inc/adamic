declare const s:string;declare const callback:(x:string)=>string;declare const unknown:unknown;declare const any:any;s.replace('x',callback);s.replace('x',unknown);s.replace('x',any);
export {};
