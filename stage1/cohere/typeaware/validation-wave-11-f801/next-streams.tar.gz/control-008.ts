declare const a:Set<number>|WeakSet<object>;a['value'];a[0];declare const b:Map<string,number>&{extra:number};b['unknown'];class Map<K,V>{size=0};declare const local:Map<string,number>;local['key'];local.size<0;
export {};
