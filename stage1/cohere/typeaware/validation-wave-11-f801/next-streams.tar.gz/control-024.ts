type JsonFileWriteOutcomeType={outcome:'Written'}|{outcome:'Unwritable'};declare function own():JsonFileWriteOutcomeType;own();declare function arbitrary():{outcome:'Written'}|{outcome:'Unwritable'};arbitrary();
export {};
