declare const s:{trim():string};s.trim();class Text{trim(){return ''}}new Text().trim();declare const both:string|string[];both.slice();
export {};
