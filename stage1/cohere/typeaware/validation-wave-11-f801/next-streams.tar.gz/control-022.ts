import type {JsonFileWriteOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare function save():JsonFileWriteOutcomeType|{extra:true};save();declare function partial():Extract<JsonFileWriteOutcomeType,{outcome:'Written'}>;partial();
export {};
