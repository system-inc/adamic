import type {JsonParseOutcomeType} from './nexus/source/structured-text/json/Json.js';import type {JsoncParseOutcomeType} from './nexus/source/structured-text/json/Jsonc.js';declare function both():JsonParseOutcomeType|JsoncParseOutcomeType;both();
export {};
