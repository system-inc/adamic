declare const s:string;declare const replacement:string|((x:string)=>string);s.replace('x',replacement);declare const constrained:never;s.replace('x',constrained);
export {};
