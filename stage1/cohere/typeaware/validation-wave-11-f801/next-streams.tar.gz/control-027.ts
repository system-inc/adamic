/* 世界 🌍 */
import type {JsonFileWriteOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare function save():JsonFileWriteOutcomeType;
(save());

export {};
