declare const s:string;declare const t:Uint8Array;s.length<0;t.length>=0;declare const list:readonly number[]|undefined;list?.length<0;declare const value:{length:number};value.length<0;
export {};
