declare const a:readonly number[];a.slice();a.toSorted();a.toSorted((x,y)=>x-y);a.toReversed();a.with(0,1);declare const s:string;s.replace(/x/g,m=>m);s.replace(/x/g,function(m){return m});
export {};
