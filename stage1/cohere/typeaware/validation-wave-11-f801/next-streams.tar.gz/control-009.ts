Object.keys(new Map());Object.values(new Set());Object.entries(new WeakMap());Object.getOwnPropertyNames(new WeakSet());Object.keys({x:1});
export {};
