declare const rows:readonly number[];declare const k:'missing'|'absent';k in rows;declare const maybe:'missing'|'length';maybe in rows;declare const wide:string;wide in rows;0 in rows;
export {};
