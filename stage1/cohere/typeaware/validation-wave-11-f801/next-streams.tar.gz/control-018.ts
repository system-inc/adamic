/* 世界 🌍 */
declare const s:string;
(s.trim());

export {};
