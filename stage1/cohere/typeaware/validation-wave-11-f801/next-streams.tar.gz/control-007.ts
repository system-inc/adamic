declare const map:Map<string,number>;map['key'];map[1];map[true];map[null];map[undefined];map[1n];map['size'];map['get'];map[Symbol.iterator];declare const wide:string;map[wide];
export {};
