declare const m:Map<string,number>;0>m.size;0<=m.size;-1>=m.size;-1<m.size;-1===m.size;m.size<+0;m.size<(-0x0);m.size<=(-0x1);m.size<=-1_0;m.size<=-1e0;
export {};
