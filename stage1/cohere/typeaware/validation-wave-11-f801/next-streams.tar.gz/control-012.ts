declare const s:string|null;s?.trim();(s?.trim());(s.trim)();(s.trim());declare const a:string[];a.slice(1);a.concat([]);a.join(',');a.map(x=>x);a.push('x');
export {};
