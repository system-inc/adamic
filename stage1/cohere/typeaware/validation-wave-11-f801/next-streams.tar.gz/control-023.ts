import type {JsonFileReadOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare function read():JsonFileReadOutcomeType<{value:string}>;read();
export {};
