import type {JsonFileWriteOutcomeType} from './nexus/source/structured-text/json/JsonFile.js';declare function save():Promise<JsonFileWriteOutcomeType>;save();async function f(){await save();(await (save()));void await save();}
export {};
