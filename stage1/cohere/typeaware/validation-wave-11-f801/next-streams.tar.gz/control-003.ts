declare const a:number[];a.length<0;a.length>=0;a.length<=-1;a.length>-1;a.length===-1;a.length!==-1;a.length==-1;a.length!=-1;a.length===0;a.length>0;a.length<-0;
export {};
