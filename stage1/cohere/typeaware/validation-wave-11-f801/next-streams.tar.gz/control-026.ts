import type {PackageJsonReadOutcomeType} from './nexus/source/system/PackageJson.js';declare function read():PackageJsonReadOutcomeType;read();
export {};
