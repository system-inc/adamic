export interface T{x:number};export const v=1;
