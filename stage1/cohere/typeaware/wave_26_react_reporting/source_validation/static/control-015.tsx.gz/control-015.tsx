function Outer() {
  const c = makeIt();
  return <c.x />;
}

export {};
