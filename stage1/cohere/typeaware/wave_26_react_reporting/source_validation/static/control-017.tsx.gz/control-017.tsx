function Outer(items) {
  let C = Known;
  for (const i of items) { C = makeIt(); }
  return <C />;
}

export {};
