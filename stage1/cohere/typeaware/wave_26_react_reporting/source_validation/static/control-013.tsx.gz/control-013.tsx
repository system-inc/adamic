function widget() {
  const C = mk();
  return <C />;
}

export {};
