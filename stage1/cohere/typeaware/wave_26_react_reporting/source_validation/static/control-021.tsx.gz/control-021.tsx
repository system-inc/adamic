// 世界🌍
function Outer(){const C = () => '世界🌍';return <C/>;}

export {};
