import {useReducer} from 'react';
function Component() {
  const [n, dispatch] = useReducer((s: number, a: number) => s, 0);
  dispatch(1);
  return n;
}

export {};
