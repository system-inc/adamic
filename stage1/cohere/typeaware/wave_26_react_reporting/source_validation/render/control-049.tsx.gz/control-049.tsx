import {useState, useMemo} from 'react';
function Component() {
  const y = useMemo(() => { const [a, setA] = useState(1); setA(2); return a; }, []);
  return y;
}

export {};
