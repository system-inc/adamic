import {useState} from 'react';
function Component() {
  const [x, setX] = useState(0);
  try { setX(1); } catch (e) {}
  return x;
}

export {};
