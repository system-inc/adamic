import {useState} from 'react';
function Component(a: number, b: number, c: number) {
  const [x, setX] = useState(0);
  setX(1);
  return x;
}

export {};
