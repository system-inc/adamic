import {useState} from 'react';
function Component(props: {c: boolean}) {
  const [x, setX] = useState(0);
  if (props.c) { setX(1); }
  return x;
}

export {};
