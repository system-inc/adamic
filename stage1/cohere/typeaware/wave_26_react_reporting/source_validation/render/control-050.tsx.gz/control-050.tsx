import {useState, useMemo} from 'react';
function Component(props: {c: boolean}) {
  const y = useMemo(() => { const [a, setA] = useState(1); if (props.c) { setA(2); } return a; }, []);
  return y;
}

export {};
