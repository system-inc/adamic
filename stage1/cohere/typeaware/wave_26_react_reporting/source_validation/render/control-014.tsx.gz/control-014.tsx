import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
// @validateNoSetStateInRender
function Component(props) {
  const [state, setState] = useState(false);
  for (const _ of props) {
  }
  setState(true);
  return state;
}

export {};
