import {useState} from 'react';
function Component() {
  const [x, setX] = useState(0);
  const a = setX;
  const b = a;
  b(1);
  return x;
}

export {};
