import {useState} from 'react';
function Component(props: {a: number}) {
  const [x, setX] = useState(0);
  const other = props.a;
  const foo = () => { setX(1); };
  const bar = () => { const t = other; foo(); return t; };
  bar();
  return x;
}

export {};
