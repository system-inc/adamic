import {useState, useCallback} from 'react';
function Component() {
  const f = useCallback(() => { const [a, setA] = useState(1); setA(2); }, []);
  return f;
}

export {};
