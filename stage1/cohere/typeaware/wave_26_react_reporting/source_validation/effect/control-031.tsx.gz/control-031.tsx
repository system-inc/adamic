import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  const args: [() => void] = [() => { setState(1); }];
  useEffect(...args);
  return state;
}

export {};
