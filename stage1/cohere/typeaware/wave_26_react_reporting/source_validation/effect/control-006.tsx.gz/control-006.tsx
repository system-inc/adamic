import {useEffect as useFx, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useFx(() => {
    setState(1);
  });
  return state;
}

export {};
