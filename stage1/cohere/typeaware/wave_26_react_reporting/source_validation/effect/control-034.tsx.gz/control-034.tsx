import {useEffect} from "./react";
function Component({onTick}: {onTick: () => void}) {
  useEffect(() => {
    onTick();
  });
  return null;
}

export {};
