import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  const f = () => {
    setState(1);
  };
  useEffect(() => {
    f();
  });
  return state;
}

export {};
