import {useCallback, useEffect, useState} from "./react";

function Component() {
  const [state] = useState(0);
  const log = useCallback(() => {
    console.info("x");
  }, []);
  useEffect(() => {
    log();
  }, [log]);
  return state;
}

export {};
