import {useEffect, useState} from "./react";
function Component({flag}) {
  const [state, setState] = useState(0);
  useEffect(() => {
    if (flag) {
      setState(1);
    }
  });
  return state;
}

export {};
