import {useLayoutEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useLayoutEffect(() => {
    setState(1);
  });
  return state;
}

export {};
