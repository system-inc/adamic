import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useEffect(() => {
    const f = () => {
      setState(1);
    };
    f();
  });
  return state;
}

export {};
