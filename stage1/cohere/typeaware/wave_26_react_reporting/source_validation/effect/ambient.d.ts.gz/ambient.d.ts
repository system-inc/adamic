declare module 'react' {
export type SetStateAction<S> = S | ((prevState: S) => S);
export type Dispatch<A> = (value: A) => void;
export type Destructor = () => void;
export type EffectCallback = () => void | Destructor;
export type DependencyList = readonly unknown[];
export interface RefObject<T> { current: T }
export declare function useState<S>(initialState: S | (() => S)): [S, Dispatch<SetStateAction<S>>];
export declare function useEffect(effect: EffectCallback, deps?: DependencyList): void;
export declare function useLayoutEffect(effect: EffectCallback, deps?: DependencyList): void;
export declare function useInsertionEffect(effect: EffectCallback, deps?: DependencyList): void;
export declare function useEffectEvent<T extends Function>(callback: T): T;
export declare function useRef<T>(initialValue: T): RefObject<T>;
export declare function useCallback<T extends Function>(callback: T, deps: DependencyList): T;
export declare function useMemo<T>(factory: () => T, deps: DependencyList): T;
export type ActionDispatch<A extends unknown[]> = (...args: A) => void;
export declare function useReducer<S, A>(r: (s: S, a: A) => S, i: S): [S, ActionDispatch<[A]>];

}