import * as React from "./react";

function Component() {
  const [state, setState] = React.useState(0);
  const bump = React.useCallback(() => {
    setState(1);
  }, []);
  React.useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
