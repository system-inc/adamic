import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  const aliased = setState;
  useEffect(() => {
    aliased(1);
  });
  return state;
}

export {};
