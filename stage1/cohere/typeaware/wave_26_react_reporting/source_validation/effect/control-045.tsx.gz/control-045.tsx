import {use\u0043allback, useEffect, useState} from "./react";

function Component() {
  const [state, setState] = useState(0);
  const bump = use\u0043allback(() => {
    setState(1);
  }, []);
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
