import {useState} from "./react";
import {useMyEffect2} from "./other";
function Component() {
  const [state, setState] = useState(0);
  useMyEffect2(() => {
    setState(1);
  });
  return state;
}

export {};
