import {useEffect, useState} from "./react";

export function wrapper() {
  function Component() {
    const [state, setState] = useState(0);
    useEffect(() => {
      setState(1);
    });
    return state;
  }
  return Component;
}

export {};
