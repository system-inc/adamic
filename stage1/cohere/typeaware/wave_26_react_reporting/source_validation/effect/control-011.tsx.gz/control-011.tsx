import {useEffect, useState} from "./react";
function useThing() {
  const [value, setValue] = useState(0);
  return [value, setValue] as const;
}
function Component() {
  const [value, setValue] = useThing();
  useEffect(() => {
    setValue(1);
  });
  return value;
}

export {};
