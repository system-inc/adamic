import {useInsertionEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useInsertionEffect(() => {
    setState(1);
  });
  return state;
}

export {};
