import {useEffect} from "./react";
function Component() {
  useEffect();
  return 1;
}

export {};
