import {useEffect, useState} from "./react";

function useWrap<T>(callback: T): T {
  return callback;
}

function Component() {
  const [state, setState] = useState(0);
  const bump = useWrap(() => {
    setState(1);
  });
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
