type Dispatch<S>=(value:S)=>void;interface RefObject<T>{current:T;}declare function useState(v:number):[number,Dispatch<number>];declare function useEffect(fn:()=>void):void;declare function useMemo(fn:()=>number):number;declare function useCallback<T>(fn:T,deps:any[]):T;declare function useRef<T>(v:T):RefObject<T>;function f(x:any){switch(x){case 1:x++;break;default:x=2;}return x;}
export {};
