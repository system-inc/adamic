import {useEffect, useMemo, useState} from "./react";

function Component() {
  const [state] = useState(0);
  const doubled = useMemo(() => state * 2, [state]);
  useEffect(() => {
    console.info(doubled);
  }, [doubled]);
  return doubled;
}

export {};
