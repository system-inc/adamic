export declare function useMyEffect2(cb: () => void): void;
export declare function useEffective(cb: () => void): void;
