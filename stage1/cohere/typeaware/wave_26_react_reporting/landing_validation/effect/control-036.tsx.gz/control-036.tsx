import {useCallback, useEffect, useState} from "./react";

function Component() {
  const [state, setState] = useState(0);
  const load = useCallback(async () => {
    const value = await Promise.resolve(1);
    setState(value);
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  return state;
}

export {};
