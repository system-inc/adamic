import {useEffect, useState} from "./react";
function Component() {
  const [state, setState] = useState(0);
  useEffect(() => {
    setState(1);
  });
  return state;
}

export {};
