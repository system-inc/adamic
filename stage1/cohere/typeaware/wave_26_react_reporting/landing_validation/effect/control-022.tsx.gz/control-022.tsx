import {useEffect, useReducer} from "./react";
function reducer(s: number, a: number) {
  return s + a;
}
function Component() {
  const [state, dispatch] = useReducer(reducer, 0);
  useEffect(() => {
    dispatch(1);
  });
  return state;
}

export {};
