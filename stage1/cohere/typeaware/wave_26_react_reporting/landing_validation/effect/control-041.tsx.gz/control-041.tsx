import {useEffect, useState} from "./react";

function identity<T>(callback: T): T {
  return callback;
}

function Component() {
  const [state, setState] = useState(0);
  const bump = identity(() => {
    setState(1);
  });
  useEffect(() => {
    bump();
  }, [bump]);
  return state;
}

export {};
