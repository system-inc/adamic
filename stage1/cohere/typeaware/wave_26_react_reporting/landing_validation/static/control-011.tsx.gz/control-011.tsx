function Widget() {
  const render = function (item) {
    const Icon = iconFor(item);
    return <Icon />;
  };
  return <div>{render(1)}</div>;
}

export {};
