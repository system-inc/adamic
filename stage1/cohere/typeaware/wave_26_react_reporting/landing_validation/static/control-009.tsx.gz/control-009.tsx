function E() {
  const T = mk();
  return <div><T /></div>;
}

export {};
