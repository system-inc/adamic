function Standalone() {
  const Inner = () => {
    const Component = createComponent();
    return <Component />;
  };
  return Inner;
}

export {};
