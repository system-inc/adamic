function D() {
  const T = mk();
  return <><T /></>;
}

export {};
