function Widget() {
  const C = mk();
  return C;
}

export {};
