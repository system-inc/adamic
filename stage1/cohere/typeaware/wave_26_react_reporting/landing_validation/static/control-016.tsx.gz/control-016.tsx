function Outer() {
  const obj = makeIt();
  return <obj.Inner.Deep />;
}

export {};
