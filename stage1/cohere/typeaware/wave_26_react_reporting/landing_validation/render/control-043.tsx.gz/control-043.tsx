import {useState, useMemo} from 'react';
function Component() {
  const [x, setX] = useState(0);
  const y = useMemo(() => { setX(1); return 1; }, []);
  return y;
}

export {};
