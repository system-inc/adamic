import {useState} from 'react';
export function Bailout(...props: number[]) {
  const [x, setX] = useState(0);
  setX(1);
  return x;
}
export function Control() {
  const [y, setY] = useState(0);
  setY(1);
  return y;
}

export {};
