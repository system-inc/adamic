import {useState} from 'react';
function Component() {
  const [x, setX] = useState(0);
  return setX;
}

export {};
