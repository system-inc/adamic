import {useState, useCallback} from 'react';
function Component() {
  const [x, setX] = useState(0);
  const cb = useCallback(() => { setX(1); }, []);
  return cb;
}

export {};
