import {useState} from 'react';
function Component() {
  const [x, setX] = useState(0);
  const o = {go: setX};
  o.go(1);
  return x;
}

export {};
