import {useState} from 'react';
function Component() {
  const [x, setX] = useState(0);
  const aliased = setX;
  setX(1);
  aliased(2);
  return x;
}

export {};
