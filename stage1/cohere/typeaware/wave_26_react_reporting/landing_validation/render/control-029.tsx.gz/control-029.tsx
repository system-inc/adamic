import {useState} from 'react';
function Component() {
  const s = useState(0);
  s[1](1);
  return s[0];
}

export {};
