import {useState,useMemo,useCallback,useRef,useReducer,useEffect} from 'react';
// @validateNoSetStateInRender @enableTreatSetIdentifiersAsStateSetters
function Component({setX}) {
  const aliased = setX;

  setX(1);
  aliased(2);

  return x;
}

export {};
