
  export type SetStateAction<S> = S | ((prev: S) => S);
  export type Dispatch<A> = (value: A) => void;
  export interface RefObject<T> { current: T }
  export function useState<S>(initial?: S): [S, Dispatch<SetStateAction<S>>];
  export function useRef<T>(initial: T): RefObject<T>;
  export type ActionDispatch<A extends any[]> = (...args: A) => void;
  export function useReducer<S, A>(reducer: (state: S, action: A) => S, initial: S): [S, ActionDispatch<[A]>];
  export function useMemo<T>(compute: () => T, deps: unknown[]): T;
  export function useCallback<T>(callback: T, deps: unknown[]): T;
  export function useEffect(effect: () => void, deps?: unknown[]): void;
