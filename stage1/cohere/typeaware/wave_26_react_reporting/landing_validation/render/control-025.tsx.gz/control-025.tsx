import {useState} from 'react';
function Component(props: {c: boolean}) {
  const [x, setX] = useState(0);
  if (props.c) { return null; }
  setX(1);
  return x;
}

export {};
