function Component() {
  const plain: (value: number) => void = (v) => {};
  plain(1);
  return null;
}

export {};
