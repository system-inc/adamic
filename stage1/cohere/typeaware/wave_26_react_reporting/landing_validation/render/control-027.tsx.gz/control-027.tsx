import {useState} from 'react';
function Component(props: number[]) {
  const [x, setX] = useState(0);
  for (const p of props) { setX(1); }
  return x;
}

export {};
