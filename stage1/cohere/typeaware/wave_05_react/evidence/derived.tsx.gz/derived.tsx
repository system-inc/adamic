import {useState,useEffect} from "./react";export function Component({value}:{value:number}){const [state,setState]=useState(0);useEffect(()=>{setState(value);},[value]);return <div />;}
