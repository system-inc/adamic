let globalCount=0;export function Component(){globalCount=1;return <div />;}
