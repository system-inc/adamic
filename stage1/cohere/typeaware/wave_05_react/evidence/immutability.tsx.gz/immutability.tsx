export function Component(props:{value:number}){props.value=1;return <div />;}
