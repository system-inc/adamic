package main
import("os";"fmt";"regexp")
func main(){args:=os.Args[1:];values:=map[string]string{"propName":args[1],"component":args[1],"pattern":args[2]};regex:=regexp.MustCompile(`\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}`);fmt.Println(regex.ReplaceAllStringFunc(args[0],func(match string)string{key:=regex.FindStringSubmatch(match)[1];if value,ok:=values[key];ok{return value};return match}))}
