function foo() { [foo] = bar; }
