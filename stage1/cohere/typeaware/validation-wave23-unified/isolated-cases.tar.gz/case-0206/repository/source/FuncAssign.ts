function foo() {} for (foo of []) {}
