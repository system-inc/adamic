Object.defineProperty(Object?.prototype, 'p', { value: 0 })
