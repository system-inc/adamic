function foo() {}; foo = bar;
