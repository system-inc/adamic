obj[Object.prototype] = 0
