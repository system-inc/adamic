parseFloat.prototype.x = 1
