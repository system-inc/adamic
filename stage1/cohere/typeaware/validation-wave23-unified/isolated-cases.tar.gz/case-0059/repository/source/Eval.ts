eval(foo)
