let a = function hello() { hello = 123;};
