function foo() {} let b; b = foo;
