Object.defineProperty(Array[`prototype`], "p", {value:0})
