function foo() { foo++; }
