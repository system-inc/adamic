Object.freeze(Array.prototype)
