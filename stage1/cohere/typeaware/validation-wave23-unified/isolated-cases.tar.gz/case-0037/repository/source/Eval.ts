(window?.window).eval('foo')
