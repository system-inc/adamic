class Function {}; Function.call(null, "return 1");
