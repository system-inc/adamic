(window?.eval)('foo')
