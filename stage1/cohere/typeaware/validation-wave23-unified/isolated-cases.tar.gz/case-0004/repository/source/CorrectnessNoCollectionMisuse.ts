type Role = 'Admin' | 'Member';
declare const roles: Role[];
declare const role: Role;
declare const pair: readonly ['first', 'second'];
declare const sparse: (number | undefined)[];
declare const index: number;
declare const wideKey: string;
declare const items: string[];
declare const optionalItems: string[] | undefined;
declare const text: string;
declare const bytes: Uint8Array;
declare const cache: Map<string, number>;
declare const lookup: ReadonlyMap<string, number>;
declare const seen: Set<string>;
declare const weak: WeakMap<object, number>;
declare const record: Record<string, number>;
declare const lengthy: { length: number };
declare const arrayLike: ArrayLike<number>;
declare const count: number;
declare function use(value: unknown): void;
use(cache['size']);
use(cache['get']);
use(cache[Symbol.iterator]);
use(cache[wideKey]);
use(record['total']);
use(Object.keys(record));
use(Object.entries(items));
use(Object.freeze(cache));
class Registry extends Map<string, number> { label = 'registry'; }
declare const registry: Registry;
use(Object.keys(registry));
use(registry[0]);
function shadowedMap() {
    class Map { size = -1; [key: string]: unknown; }
    const local = new Map();
    use(local.size < 0);
    use(local['total']);
    use(Object.keys(local));
}
function objectParameter(Object: ObjectConstructor) { use(Object.keys(cache)); }
function shadowedObject() {
    const Object = { keys(value: unknown): string[] { use(value); return []; } };
    use(Object.keys(cache));
}
