Object.prototype.g = 0
