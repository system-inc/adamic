window.setTimeout('foo')
