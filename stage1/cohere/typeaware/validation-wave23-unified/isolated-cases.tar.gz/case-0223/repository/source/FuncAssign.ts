var foo = () => { foo = 1; };
