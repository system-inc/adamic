function foo() { foo = bar; }
