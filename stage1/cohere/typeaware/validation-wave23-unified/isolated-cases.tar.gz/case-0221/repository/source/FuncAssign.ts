var a = function foo() { foo = 123; };
