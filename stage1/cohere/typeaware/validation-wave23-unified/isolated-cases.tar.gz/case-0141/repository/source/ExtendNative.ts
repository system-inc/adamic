Object.defineProperty(x, Array.prototype)
