foo(Function.bind)
