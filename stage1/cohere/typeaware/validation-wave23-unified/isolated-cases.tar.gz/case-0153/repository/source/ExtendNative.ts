Object.prototype.p.q = 0
