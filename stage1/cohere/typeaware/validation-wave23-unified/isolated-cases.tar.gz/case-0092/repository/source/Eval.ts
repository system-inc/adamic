window.window['eval']('foo')
