(0, globalThis['eval'])('foo')
