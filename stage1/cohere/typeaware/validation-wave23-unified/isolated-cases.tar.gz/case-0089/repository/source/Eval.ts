window.setInterval('foo')
