global.eval('foo')
