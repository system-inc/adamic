var EVAL = globalThis.eval; EVAL('foo')
