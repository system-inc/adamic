Number['prototype']['p'] = 0
