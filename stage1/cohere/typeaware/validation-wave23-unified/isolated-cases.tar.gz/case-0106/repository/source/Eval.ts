function foo() { this.eval('foo') }
