class A { static foo() { this.eval(); } }
