class A { foo() { this.eval(); } }
