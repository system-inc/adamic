declare let name: string;
declare const maybeName: string | undefined;
declare const path: string;
declare let list: string[];
declare const more: string[];
declare const items: readonly string[];
declare const either: string | string[];
declare const pattern: RegExp;
declare const matches: string[];
declare function use(value: unknown): void;
declare function replacer(match: string): string;
export function normalize() {
    name.trim();
    path.replace('/old/', '/new/');
    list.concat(more);
}
