function foo() {} ({b: {c: foo}} = {b: {}});
