if (Object.prototype.p == 0) {}
