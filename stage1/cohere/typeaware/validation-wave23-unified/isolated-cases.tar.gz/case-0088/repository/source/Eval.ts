window.noeval('foo')
