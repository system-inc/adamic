String['prototype'].p = 0
