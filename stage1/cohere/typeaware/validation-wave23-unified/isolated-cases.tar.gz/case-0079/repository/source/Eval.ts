setInterval('foo')
