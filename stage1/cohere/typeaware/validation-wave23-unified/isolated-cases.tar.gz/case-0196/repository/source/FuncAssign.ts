function foo() {} [...foo] = [0];
