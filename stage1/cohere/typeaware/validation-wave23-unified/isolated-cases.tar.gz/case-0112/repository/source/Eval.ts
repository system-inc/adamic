this.eval('foo');
