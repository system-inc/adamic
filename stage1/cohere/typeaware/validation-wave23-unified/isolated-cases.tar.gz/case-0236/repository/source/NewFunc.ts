Function[`call`](null, "return 1");
