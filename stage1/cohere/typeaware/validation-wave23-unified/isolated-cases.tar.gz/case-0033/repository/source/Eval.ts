(eval as any)('foo')
