class A { accessor field = this.eval(); }
