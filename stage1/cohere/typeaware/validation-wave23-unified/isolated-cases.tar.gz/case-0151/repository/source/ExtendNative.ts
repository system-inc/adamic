Object.prototype.p++
