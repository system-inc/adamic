eval?.('foo')
