function foo() { Object.prototype.p = 0 }
