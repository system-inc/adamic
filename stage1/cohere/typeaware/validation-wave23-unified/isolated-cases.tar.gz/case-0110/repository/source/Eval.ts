globalThis.globalThis.eval('foo');
