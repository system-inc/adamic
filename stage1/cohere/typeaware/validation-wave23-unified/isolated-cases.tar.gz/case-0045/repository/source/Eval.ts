callbacks.findLastIndex(function (cb) { return cb(this.eval); }, this);
