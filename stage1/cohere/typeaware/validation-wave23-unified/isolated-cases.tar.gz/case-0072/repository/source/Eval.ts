global.noeval('foo')
