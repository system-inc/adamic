var EVAL = eval; EVAL('foo')
