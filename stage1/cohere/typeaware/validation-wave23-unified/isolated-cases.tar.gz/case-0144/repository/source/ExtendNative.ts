Object.prototype = 0
