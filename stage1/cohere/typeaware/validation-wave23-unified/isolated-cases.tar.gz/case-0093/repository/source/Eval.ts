window?.eval('foo')
