function foo() { globalThis.eval('foo') }
