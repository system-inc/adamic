function foo() {} function f() { function foo() {} foo = 1; }
