this.eval('foo')
