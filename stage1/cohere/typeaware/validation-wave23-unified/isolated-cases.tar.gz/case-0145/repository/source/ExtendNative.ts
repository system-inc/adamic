Object.prototype.p + 0
