global.global.eval('foo')
