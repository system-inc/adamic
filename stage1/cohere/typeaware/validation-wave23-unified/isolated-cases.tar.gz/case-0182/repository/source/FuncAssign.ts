const o = { foo: 1 }; function foo() {} o.foo = 2;
