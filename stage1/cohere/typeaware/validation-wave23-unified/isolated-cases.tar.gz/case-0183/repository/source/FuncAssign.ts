foo = bar; function foo() { };
