globalThis.noneval('foo')
