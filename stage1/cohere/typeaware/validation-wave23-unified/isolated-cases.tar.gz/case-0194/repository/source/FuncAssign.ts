function foo() {} ({foo} = {});
