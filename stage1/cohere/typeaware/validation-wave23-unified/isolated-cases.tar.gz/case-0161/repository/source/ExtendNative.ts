WeakRef.prototype.p = 0
