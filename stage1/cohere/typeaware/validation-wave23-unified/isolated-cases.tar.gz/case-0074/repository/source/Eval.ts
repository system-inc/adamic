globalThis.globalThis.eval('foo')
