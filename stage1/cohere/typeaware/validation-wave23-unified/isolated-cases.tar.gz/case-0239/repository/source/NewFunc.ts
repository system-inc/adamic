class Function {}; Function.bind(null, "return 1");
