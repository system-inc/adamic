(function(exe){ exe('foo') })(eval);
