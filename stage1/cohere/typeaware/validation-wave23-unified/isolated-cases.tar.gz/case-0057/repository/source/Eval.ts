eval('foo')
