window.eval('foo')
