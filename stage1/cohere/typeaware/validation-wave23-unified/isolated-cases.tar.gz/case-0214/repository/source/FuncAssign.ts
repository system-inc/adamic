function foo() {} var a = function foo() { foo = 1; };
