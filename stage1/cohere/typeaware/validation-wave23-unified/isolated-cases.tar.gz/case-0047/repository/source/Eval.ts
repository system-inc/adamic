class A { field = () => this.eval(); }
