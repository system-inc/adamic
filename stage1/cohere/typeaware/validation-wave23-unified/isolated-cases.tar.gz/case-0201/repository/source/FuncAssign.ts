function foo() {} foo();
