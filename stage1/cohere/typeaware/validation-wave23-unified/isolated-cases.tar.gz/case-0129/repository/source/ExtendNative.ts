JSON.defineProperties(Array.prototype, {})
