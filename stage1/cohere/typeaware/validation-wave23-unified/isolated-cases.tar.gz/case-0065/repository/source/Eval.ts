function foo() { var eval = 'foo'; globalThis[eval]('foo') }
