(0, eval)('foo')
