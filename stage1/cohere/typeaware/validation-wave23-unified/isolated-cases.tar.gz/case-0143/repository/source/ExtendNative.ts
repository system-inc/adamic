Object.p = 0
