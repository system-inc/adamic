declare let name: string;
declare const maybeName: string | undefined;
declare const path: string;
declare let list: string[];
declare const more: string[];
declare const items: readonly string[];
declare const either: string | string[];
declare const pattern: RegExp;
declare const matches: string[];
declare function use(value: unknown): void;
declare function replacer(match: string): string;
class Text { trim(): Text { use(this); return this; } }
new Text().trim();
