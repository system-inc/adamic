eval!('foo')
