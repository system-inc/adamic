function foo() {} let b = foo + 1;
