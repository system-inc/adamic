FinalizationRegistry.prototype.p = 0
