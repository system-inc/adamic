const fn = () => { class Function {}; new Function() }
