global.global[`eval`]('foo')
