foo[Function]()
