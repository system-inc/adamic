setTimeout('foo')
