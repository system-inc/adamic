var EVAL = this.eval; EVAL('foo')
