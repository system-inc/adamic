class Function {}; Function["call"](null);
