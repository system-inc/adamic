function foo() {} let b = -foo;
