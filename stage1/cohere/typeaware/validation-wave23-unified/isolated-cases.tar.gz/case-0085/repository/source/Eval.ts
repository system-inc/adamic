var obj = {foo: function() { this.eval('foo'); }}
