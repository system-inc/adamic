function foo() {} if (foo === 0) {}
