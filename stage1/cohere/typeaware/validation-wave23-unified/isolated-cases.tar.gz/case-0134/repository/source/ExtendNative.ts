Object.defineProperties(Array.prototype, {p: {value: 0}})
