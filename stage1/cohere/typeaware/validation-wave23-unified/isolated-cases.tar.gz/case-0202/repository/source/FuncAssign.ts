function foo() {} foo++;
