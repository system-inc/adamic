Object['toString'].bind = 0
