[foo] = bar; function foo() { };
