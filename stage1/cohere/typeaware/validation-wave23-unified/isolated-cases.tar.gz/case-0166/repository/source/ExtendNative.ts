global.Object.prototype.toString = 0
