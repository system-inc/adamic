(0, window['eval'])('foo')
