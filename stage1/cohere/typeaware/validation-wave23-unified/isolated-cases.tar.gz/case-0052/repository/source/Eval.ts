class A { static field = this.eval(); }
