function foo() {} { function foo() {} foo = 1; }
