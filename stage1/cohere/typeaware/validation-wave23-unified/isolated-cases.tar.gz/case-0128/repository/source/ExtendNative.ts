Function.prototype['p'] = 0
