declare const a: any;
a().Function.call(null);
