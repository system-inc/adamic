class A { static { this.eval(); } }
