var foo = () => {}; foo = bar;
