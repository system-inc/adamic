function foo() { var eval = 'foo'; global[eval]('foo') }
