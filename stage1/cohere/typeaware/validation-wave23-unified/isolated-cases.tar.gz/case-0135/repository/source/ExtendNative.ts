Object.defineProperties(x, {p: {value: 0}})
