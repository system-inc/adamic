var a = function foo(foo) { foo = 1; };
