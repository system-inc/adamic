() => { this.eval('foo') }
