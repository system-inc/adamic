window.window.eval('foo')
