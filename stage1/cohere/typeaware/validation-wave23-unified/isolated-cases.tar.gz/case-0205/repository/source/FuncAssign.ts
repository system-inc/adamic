function foo() {} for (foo in {}) {}
