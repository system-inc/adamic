globalThis.globalThis['eval']('foo')
