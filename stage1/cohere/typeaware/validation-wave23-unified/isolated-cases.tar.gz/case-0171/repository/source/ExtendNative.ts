this.Object.prototype.toString = 0
