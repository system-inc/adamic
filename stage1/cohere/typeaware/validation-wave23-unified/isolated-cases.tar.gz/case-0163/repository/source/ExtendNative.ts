eval('Object.prototype.toString = 0')
