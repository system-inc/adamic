function foo(eval) { eval('foo') }
