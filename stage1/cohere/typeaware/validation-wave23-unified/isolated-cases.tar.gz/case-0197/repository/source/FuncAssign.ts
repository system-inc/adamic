function foo() {} const o = {foo};
