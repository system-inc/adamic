function foo() {} --foo;
