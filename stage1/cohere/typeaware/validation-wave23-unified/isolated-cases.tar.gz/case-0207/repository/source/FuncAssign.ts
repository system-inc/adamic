function foo() {} function bar() {} bar = 0;
