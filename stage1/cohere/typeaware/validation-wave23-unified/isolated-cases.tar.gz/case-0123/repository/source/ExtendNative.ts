Array.prototype.p ??= 0
