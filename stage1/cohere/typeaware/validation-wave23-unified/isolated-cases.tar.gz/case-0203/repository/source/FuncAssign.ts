function foo() {} foo.x = 0;
