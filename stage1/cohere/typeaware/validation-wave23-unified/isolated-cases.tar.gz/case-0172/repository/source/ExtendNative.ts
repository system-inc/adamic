with(Object) { prototype.p = 0; }
