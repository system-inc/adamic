delete Object.prototype.p
