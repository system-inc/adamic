Object.prototype.p instanceof Foo
