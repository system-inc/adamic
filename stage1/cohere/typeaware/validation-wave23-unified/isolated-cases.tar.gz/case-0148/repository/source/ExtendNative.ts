Object.prototype.p = 0; Object.prototype.q = 0
