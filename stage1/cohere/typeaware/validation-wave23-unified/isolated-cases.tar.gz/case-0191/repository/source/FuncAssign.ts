function foo() {} ({...foo} = {});
