array.findLast(function (x) { return this.eval.includes(x); }, { eval: ['foo', 'bar'] });
