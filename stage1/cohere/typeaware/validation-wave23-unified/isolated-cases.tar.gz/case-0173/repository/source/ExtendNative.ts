x.prototype.p = 0
