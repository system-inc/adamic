Eval(foo)
