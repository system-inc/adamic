globalThis.eval('foo')
