'use strict'; this.eval('foo');
