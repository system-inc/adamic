Object.defineProperties()
