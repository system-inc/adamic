class Function {}; new Function()
