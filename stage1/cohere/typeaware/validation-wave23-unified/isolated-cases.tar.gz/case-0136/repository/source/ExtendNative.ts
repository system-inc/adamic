Object.defineProperty()
