
for (var foo in []) {
}
      