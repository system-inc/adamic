
export class Foo {}
export class Bar {}
export type FooBar = Foo | Bar;
    