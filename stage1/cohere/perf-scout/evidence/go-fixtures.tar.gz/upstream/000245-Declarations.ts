
namespace myLib {
  let numberOfGreetings: number = 2;
}
      