
const class1 = class NAME {
  static pi: number = 3.14;
};
      