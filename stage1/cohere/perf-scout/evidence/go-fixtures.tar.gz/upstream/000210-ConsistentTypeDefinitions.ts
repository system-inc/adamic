interface Array2<T> {
  foo(): T;
}