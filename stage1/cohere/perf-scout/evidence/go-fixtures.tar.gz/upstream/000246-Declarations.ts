
namespace myLib {
  let numberOfGreetings: number;
}
      