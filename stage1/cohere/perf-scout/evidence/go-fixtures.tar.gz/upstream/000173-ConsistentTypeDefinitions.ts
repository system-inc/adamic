
type Foo = ({
  a: string;
});
      