
interface Test {
  f(value: number): Promise<this | undefined>;
}
      