
const foo = 'a',
  bar = 'b';
interface Foo {}
class Foo {}
    