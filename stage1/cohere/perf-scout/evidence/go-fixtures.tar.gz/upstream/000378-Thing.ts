
interface Test {
  readonly f: (a: string) => number;
}
      