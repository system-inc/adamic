
type Test = { ['f']?<T>(a: T, b: T): T };
      