namespace N {
  export interface Foo { a: string }
}
