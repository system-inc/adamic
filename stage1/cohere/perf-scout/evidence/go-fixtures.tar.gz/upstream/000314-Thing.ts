
interface Foo {
  foo(): one;
  foo(): two;
  foo(): three;
}
      