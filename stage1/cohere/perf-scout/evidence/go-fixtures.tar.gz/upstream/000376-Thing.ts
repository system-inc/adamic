
interface Test {
  f: <T>(a: T) => T;
}
      