
if (true) {
  function foo(s: string);
  function foo(n: number);
  function foo(sn: string | number) {}
}
    