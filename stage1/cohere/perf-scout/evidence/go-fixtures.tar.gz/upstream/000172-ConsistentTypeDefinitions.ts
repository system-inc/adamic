
type Foo = ((({
  a: string;
})))

const bar = 1;
      