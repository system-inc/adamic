
var foo,
  bar = false,
  baz;
      