export /* c */ interface Foo { a: string }
