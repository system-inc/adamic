
                export default function Page() {
                return <div></div>;
                }
                export async function getstatisPath() {};
            