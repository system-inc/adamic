
type Test = { ['f']?: (a: boolean) => void };
      