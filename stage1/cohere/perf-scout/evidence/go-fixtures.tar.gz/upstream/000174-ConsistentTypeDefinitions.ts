
type Foo = {
  a: string;
}
      