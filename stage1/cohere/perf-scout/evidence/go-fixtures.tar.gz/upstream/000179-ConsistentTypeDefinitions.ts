export /* c */ type Foo = { a: string };
