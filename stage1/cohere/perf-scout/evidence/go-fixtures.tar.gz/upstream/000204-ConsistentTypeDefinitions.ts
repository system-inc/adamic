interface A extends B, C {
  x: number;
}