const before = 1;
import { type A, type B } from 'mod';
