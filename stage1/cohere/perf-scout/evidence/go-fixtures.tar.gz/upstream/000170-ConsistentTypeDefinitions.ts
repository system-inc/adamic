
interface A extends B {
  x: number;
}
      