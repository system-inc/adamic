
interface Foo {
  [Symbol.toStringTag](): void;
  [Symbol.iterator](): void;
}
    