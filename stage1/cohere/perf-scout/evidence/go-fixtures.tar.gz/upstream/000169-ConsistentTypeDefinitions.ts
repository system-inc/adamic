
export type W<T> = {
  x: T;
};
      