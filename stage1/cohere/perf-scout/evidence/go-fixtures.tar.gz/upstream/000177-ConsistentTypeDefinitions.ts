/** Doc. */
export type Foo = { a: string };
