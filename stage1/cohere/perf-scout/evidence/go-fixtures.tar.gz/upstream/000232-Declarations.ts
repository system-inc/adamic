var foo;
var bar = 1;
