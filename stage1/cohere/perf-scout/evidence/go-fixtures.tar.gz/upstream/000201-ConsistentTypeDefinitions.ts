declare interface Foo { a: string }
