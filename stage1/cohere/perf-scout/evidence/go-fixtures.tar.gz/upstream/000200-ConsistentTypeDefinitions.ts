declare global {
  interface Array<T> {
    foo(): T;
  }
}