
interface Test {
  ['f']: (a: boolean) => void;
}
      