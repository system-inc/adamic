
function foo() {
  var foo;
  var bar = foo;
}
      