
type Test = { set f(value: number): void };
      