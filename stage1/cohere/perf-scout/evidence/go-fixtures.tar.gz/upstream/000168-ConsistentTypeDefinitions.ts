
export declare type Test = {
  foo: string;
  bar: string;
};
      