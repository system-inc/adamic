
var bar: string = function (): string {
  return 'string';
};
      