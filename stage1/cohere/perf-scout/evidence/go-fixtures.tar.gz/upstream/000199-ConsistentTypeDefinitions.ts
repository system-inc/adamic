/** Doc. */
export interface Foo { a: string }
