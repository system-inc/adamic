
function foo() {
  let a, b;
  if (a) {
    let c, d;
  }
}
      