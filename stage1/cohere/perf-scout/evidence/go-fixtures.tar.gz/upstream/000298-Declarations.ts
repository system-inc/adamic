let { a, b } = obj;
