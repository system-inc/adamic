declare type Foo = { a: string };
