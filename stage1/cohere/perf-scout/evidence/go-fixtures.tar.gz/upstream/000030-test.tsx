const getStaticPropss = () => {};
export default getStaticPropss;