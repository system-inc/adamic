interface A extends B, C, D {
  x: number;
}