
var foo,
  bar = 5,
  baz = 3;
      