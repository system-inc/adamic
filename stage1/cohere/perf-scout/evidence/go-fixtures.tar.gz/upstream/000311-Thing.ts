
declare const Foo: {
  foo(): one;
  foo(): two;
  foo(): three;
}
      