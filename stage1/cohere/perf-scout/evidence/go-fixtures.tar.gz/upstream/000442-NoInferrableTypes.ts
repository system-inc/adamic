
class Foo {
  a?: number = 5;
  b?: boolean = true;
  c?: string = 'foo';
}
      