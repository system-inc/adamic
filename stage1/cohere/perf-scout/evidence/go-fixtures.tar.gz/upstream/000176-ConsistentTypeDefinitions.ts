
type Record<T, U> = {
  [K in T]: U;
};
      