
interface Test {
  get f(): number;
}
    