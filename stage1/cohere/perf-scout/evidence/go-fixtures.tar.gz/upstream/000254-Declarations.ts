for (const { a } of list) {
}
