
export interface Foo {}
export const foo = 'a',
  bar = 'b';
export class Foo {}
    