
function foo() {
  var foo = 0;
  var bar;
}
      