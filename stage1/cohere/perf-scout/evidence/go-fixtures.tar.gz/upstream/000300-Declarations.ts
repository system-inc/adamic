using x = f();
