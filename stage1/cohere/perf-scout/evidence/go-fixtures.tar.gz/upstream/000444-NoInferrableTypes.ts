
class Foo {
  accessor a: number = 5;
}
      