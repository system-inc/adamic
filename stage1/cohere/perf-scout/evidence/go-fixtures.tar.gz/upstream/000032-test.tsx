const getStaticPropss = 1;
export { getStaticPropss };