
var foo = 1,
  bar = false,
  baz = {};
    