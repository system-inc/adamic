import Script from 'next/script';
export const C = () => <Script src="/a.js" />;