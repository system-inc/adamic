
class Foo {
  a = 5;
  b = true;
  c = 'foo';
}
    