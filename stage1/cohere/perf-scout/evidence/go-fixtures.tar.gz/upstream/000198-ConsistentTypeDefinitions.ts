
namespace JSX {
  interface Array<T> {
    foo(x: (x: number) => T): T[];
  }
}
      