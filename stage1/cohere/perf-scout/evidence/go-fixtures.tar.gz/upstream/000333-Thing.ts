
interface Test {
  foo(): this;
  foo(): Promise<this>;
}
      