
function foo() {
  let a = 'foo',
    b;
  if (a) {
    let c, d;
  }
}
      