
interface GreetingSettings {
  greeting: string;
  duration?: number;
  color?: string;
}
      