
type Test = { f?<T>(a?: T): T };
      