
export interface W<T> {
  x: T;
}
      