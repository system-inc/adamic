
declare namespace myLib {
  let numberOfGreetings: number;
}
      