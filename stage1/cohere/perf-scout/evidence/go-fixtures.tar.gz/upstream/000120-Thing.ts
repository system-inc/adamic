
interface Foo {}
const foo = 'a',
  bar = 'b';
class Foo {}
    