
for (var foo in []) {
}
    