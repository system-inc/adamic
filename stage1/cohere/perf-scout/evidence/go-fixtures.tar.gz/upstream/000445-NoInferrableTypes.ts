
class Foo {
  constructor(public a = true) {}
}
      