
export const foo = 'a',
  bar = 'b';
export interface Foo {}
export class Foo {}
    