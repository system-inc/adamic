
interface Test {
  set f(value: number): void;
}
    