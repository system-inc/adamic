const getStaticPropss = () => {};
function getStaticPathss() {};