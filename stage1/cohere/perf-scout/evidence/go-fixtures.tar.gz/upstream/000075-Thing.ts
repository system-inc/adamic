
class Test {
  static test() {}
  untest() {}
  test() {}
}
    