
for (var foo of []) {
}
      