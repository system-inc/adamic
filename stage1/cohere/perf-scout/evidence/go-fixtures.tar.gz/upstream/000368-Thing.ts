
interface Test {
  'f!': </* a */ T>(/* b */ x: any /* c */) => void;
}
      