
const class1 = class NAME {
  constructor() {
    var name1: string = 'hello';
  }
};
      