interface A extends B, C, D, E {
  x: number;
}