let w = 1;
