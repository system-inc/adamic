
export default interface Test {
  bar(): string;
  foo(): number;
}
      