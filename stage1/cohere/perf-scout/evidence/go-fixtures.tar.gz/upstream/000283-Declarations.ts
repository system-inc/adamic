async function g() {
  await using y = f();
}
