
interface MyInterface {
  methodReturningImplicitAny();
}
      