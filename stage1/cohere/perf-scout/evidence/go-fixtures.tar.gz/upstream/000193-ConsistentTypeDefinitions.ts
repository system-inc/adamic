
export declare interface Test {
  foo: string;
  bar: string;
}
      