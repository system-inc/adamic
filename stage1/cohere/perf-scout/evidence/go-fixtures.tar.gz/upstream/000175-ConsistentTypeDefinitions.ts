
type Foo = {
  a: string;
}
type Bar = string;
      