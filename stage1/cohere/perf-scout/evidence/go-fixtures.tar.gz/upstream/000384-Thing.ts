
type Test = { f: (a: string) => number };
      