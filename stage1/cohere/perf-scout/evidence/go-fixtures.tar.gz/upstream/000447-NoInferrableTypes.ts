
class Foo {
  readonly a: number = 5;
}
    