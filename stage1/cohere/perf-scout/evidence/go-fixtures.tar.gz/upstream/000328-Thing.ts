
interface Test {
  f(value: number): this | undefined;
}
      