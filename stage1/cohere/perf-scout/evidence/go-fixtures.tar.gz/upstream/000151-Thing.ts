interface I {
  [
    Symbol.iterator
  ](): void;
  foo(): void;
  [Symbol.iterator](): void;
}