
var bar: string = function (arg1: string): string {
  return 'string';
};
      