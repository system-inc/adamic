
declare global {
  namespace Foo {
    interface Bar {}
  }
}
      