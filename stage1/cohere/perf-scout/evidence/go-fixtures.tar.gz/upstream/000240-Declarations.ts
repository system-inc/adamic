
function foo() {
  let a;
  const b = false;
  var c;
}
      