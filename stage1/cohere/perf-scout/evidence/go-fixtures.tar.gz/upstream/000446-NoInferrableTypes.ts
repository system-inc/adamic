
class Foo {
  constructor(public a: boolean = true) {}
}
      