
function foo() {
  var bar: string;
}
      