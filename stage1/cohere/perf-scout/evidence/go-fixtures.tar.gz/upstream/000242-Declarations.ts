
function foo() {
  var bar;
}
      