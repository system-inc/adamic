
type Foo = ((((((((({
  a: string;
})))))))));
      