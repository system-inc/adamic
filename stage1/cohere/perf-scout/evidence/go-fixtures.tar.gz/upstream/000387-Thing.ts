
type Test = { get f(): number };
      