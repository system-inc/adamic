
class Foo {
  accessor a = 5;
}
    