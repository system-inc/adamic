
interface Test {
  f: (a: string) => number;
}
      