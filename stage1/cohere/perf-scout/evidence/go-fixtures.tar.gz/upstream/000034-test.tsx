export async function getStaticPathss(){};
export async function getStaticPropss(){};