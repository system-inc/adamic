	.file	"stack_forever-before.c"
	.globaltype	__stack_pointer, i32
	.functype	__main_argc_argv (i32, i32) -> (i32)
	.functype	adamic_start (i32, i32) -> ()
	.functype	adamic_write_line (i32, i32) -> ()
	.functype	adamic_function_0_loop (f64) -> ()
	.functype	adamic_string_from_number (f64) -> (i32)
	.functype	adamic_string_concat (i32, i32) -> (i32)
	.functype	adamic_release (i32) -> ()
	.functype	adamic_stack_overflow () -> ()
	.section	.text.__main_argc_argv,"",@
	.hidden	__main_argc_argv                # -- Begin function __main_argc_argv
	.globl	__main_argc_argv
	.type	__main_argc_argv,@function
__main_argc_argv:                       # @__main_argc_argv
	.functype	__main_argc_argv (i32, i32) -> (i32)
	.local  	i32, f64
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	2
	global.set	__stack_pointer
	local.get	0
	local.get	1
	call	adamic_start
	i32.const	1
	i32.const	adamic_string_0
	call	adamic_write_line
	f64.const	0x0p0
	call	adamic_function_0_loop
	local.get	2
	local.get	3
	call	adamic_string_from_number
	local.tee	1
	i32.store	12
	i32.const	1
	i32.const	1
	local.get	2
	i32.const	12
	i32.add 
	call	adamic_string_concat
	local.tee	0
	call	adamic_write_line
	local.get	0
	call	adamic_release
	local.get	1
	call	adamic_release
	local.get	2
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	i32.const	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.adamic_function_0_loop,"",@
	.type	adamic_function_0_loop,@function # -- Begin function adamic_function_0_loop
adamic_function_0_loop:                 # @adamic_function_0_loop
	.functype	adamic_function_0_loop (f64) -> ()
	.local  	i32
# %bb.0:
	global.get	__stack_pointer
	local.set	1
	block   	
	i32.const	0
	i32.load	adamic_stack_limit
	local.get	1
	local.tee	1
	i32.le_u
	br_if   	0                               # 0: down to label0
# %bb.1:
	call	adamic_stack_overflow
	unreachable
.LBB1_2:
	end_block                               # label0:
	local.get	0
	f64.const	0x1p0
	f64.add 
	call	adamic_function_0_loop
	local.get	1
	global.set	__stack_pointer
                                        # fallthrough-return
	end_function
                                        # -- End function
	.type	adamic_string_0,@object         # @adamic_string_0
	.section	.data.adamic_string_0,"",@
	.p2align	2, 0x0
adamic_string_0:
	.int32	0                               # 0x0
	.int32	1                               # 0x1
	.int32	0                               # 0x0
	.int32	5                               # 0x5
	.int32	.L.str
	.int32	0                               # 0x0
	.int32	adamic_literal_mark
	.int32	0
	.int32	0                               # 0x0
	.size	adamic_string_0, 36

	.type	.L.str,@object                  # @.str
	.section	.rodata..L.str,"S",@
.L.str:
	.asciz	"start"
	.size	.L.str, 6

	.ident	"clang version 20.1.8-wasi-sdk (https://github.com/llvm/llvm-project 87f0227cb60147a26a1eeb4fb06e3b505e9c7261)"
	.size	adamic_literal_mark, 1
	.size	adamic_stack_limit, 4
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	5
	.ascii	"clang"
	.int8	95
	.ascii	"20.1.8-wasi-sdk (https://github.com/llvm/llvm-project 87f0227cb60147a26a1eeb4fb06e3b505e9c7261)"
	.section	.rodata..L.str,"S",@
	.section	.custom_section.target_features,"",@
	.int8	8
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.section	.rodata..L.str,"S",@
