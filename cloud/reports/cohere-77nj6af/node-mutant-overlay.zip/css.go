package css
import ("testing"; "path/filepath"; "bytes")
func TestAdamicFormattingMutantsOnNode(t *testing.T) {
 cases, expected := askedCases(t); expected = printerAnswers(t, cases, "default")
 original := portDirectory(t, nil)
 result := onNode(t, filepath.Join(original, "print_main.ts"), cases, "output", "once", "default")
 if result.exitCode != 0 || len(result.stderr) != 0 || !bytes.Equal(result.stdout, []byte(expected)) { t.Fatalf("original Node parity: exit=%d stderr=%s", result.exitCode, result.stderr) }
 for _, mutation := range printerMutants {
  t.Run(mutation.name, func(t *testing.T) {
   
   directory := portDirectory(t, &mutation)
   result := onNode(t, filepath.Join(directory, "print_main.ts"), cases, "output", "once", "default")
   if result.exitCode != 0 || len(result.stderr) != 0 { t.Fatalf("mutant must run: exit=%d stderr=%s", result.exitCode, result.stderr) }
   if bytes.Equal(result.stdout, []byte(expected)) { t.Fatal("mutant survived byte comparison") }
   t.Logf("Node caught: %s", firstDifference(string(result.stdout), expected))
  })
 }
}
