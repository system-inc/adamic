package gitignore
import ("testing"; "path/filepath"; "bytes")
func TestAdamicFormattingMutantsOnNode(t *testing.T) {
 asked := askedCases(t); expected := goCohere(t, asked); cases := casesFile(t, asked)
 original := portDirectory(t, nil)
 result := onNode(t, filepath.Join(original, "main.ts"), cases)
 if result.exitCode != 0 || len(result.stderr) != 0 || !bytes.Equal(result.stdout, []byte(expected)) { t.Fatalf("original Node parity: exit=%d stderr=%s", result.exitCode, result.stderr) }
 for _, mutation := range mutants {
  t.Run(mutation.name, func(t *testing.T) {
   if mutation.needsLargest && !largest() { t.Skip("100 MiB opt-in mutant") }
   directory := portDirectory(t, &mutation)
   result := onNode(t, filepath.Join(directory, "main.ts"), cases)
   if result.exitCode != 0 || len(result.stderr) != 0 { t.Fatalf("mutant must run: exit=%d stderr=%s", result.exitCode, result.stderr) }
   if bytes.Equal(result.stdout, []byte(expected)) { t.Fatal("mutant survived byte comparison") }
   t.Logf("Node caught: %s", firstDifference(string(result.stdout), expected))
  })
 }
}

func TestAdamicFormattingPathMutantsOnNode(t *testing.T) {
 paths := sweepPaths(); _ = paths
 // The existing path sweep also checks native and JS backends; run it separately.
}
