import subprocess,re
from pathlib import Path
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines()
for name in paths:
 p=Path(name);s=p.read_text()
 def resolve(m):
  a,b=m[1],m[2]
  if name=='internal/oracle/counts.md':return a+b
  if name=='internal/lower/refusals.go':
   if 'literalCallableBranch' in a:return a.replace('isRefused {','isRefused && !l.nodeProcessEnvironmentDelete(node) {')
   if 'nodeProcessMethodObservation' in b:return b.replace('!l.methodComparisonUse(node)', '!l.methodComparisonUse(node) && !l.detachedOwnMethod(node)')
  if name=='internal/lower/expression.go':
   if 'methodObservation' in b or 'nodeFSDirectoryValue' in b:return a+'\t}\n'+b
  if name=='internal/native/runtime/node_process.c' and not a:return b
  return a
 s=re.sub(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);p.write_text(s)
subprocess.run(['git','add',*paths],check=True)
