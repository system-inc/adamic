import json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/adamic');out=pathlib.Path('/workspace/stage3-go-followup');out.mkdir(exist_ok=True);rows=[]
env=dict(os.environ,GOMAXPROCS='4',ADAMIC_GATE_UNCACHED='1',PYTHONDONTWRITEBYTECODE='1')
with (out/'prepare.log').open('w') as log:
 subprocess.run(['python3','stage3/meter/build-probes.py','--prepare'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
products=json.loads(subprocess.check_output(['python3','stage3/meter/build-probes.py'],cwd=root,env=env))
(out/'products.json').write_text(json.dumps(products,indent=2)+'\n')
for line in pathlib.Path('/tmp/stage3-packages.txt').read_text().splitlines():
 package=line.split()[0];folder=root/package.removeprefix('github.com/system-inc/adamic/')
 if len(line.split())==1:commands=[('build-only',['go','test','-run','^$','-count=1',package])]
 else:
  binary=pathlib.Path(products[folder.name+'-test'])
  listing=subprocess.check_output([str(binary),'-test.list=.'],cwd=folder,env=env,text=True)
  commands=[(name,[str(binary),'-test.run=^'+name+'$','-test.count=1','-test.parallel=4','-test.timeout=30m']) for name in listing.splitlines() if name.startswith(('Test','Example','Fuzz'))]
 for name,command in commands:
  log=out/(str(len(rows))+'.log');start=time.monotonic()
  with log.open('w') as stream:p=subprocess.run(command,cwd=folder if name!='build-only' else root,env=env,stdout=stream,stderr=subprocess.STDOUT)
  rows.append(dict(unit=package+'::'+name,seconds=round(time.monotonic()-start,3),exit=p.returncode,command=command,log=str(log)))
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
