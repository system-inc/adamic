from pathlib import Path
import re,subprocess
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines()
for name in paths:
 p=Path(name);s=p.read_text()
 def resolve(m):
  a,b=m.group(1),m.group(2)
  if name in ['internal/lower/cast.go','internal/lower/cast_proof.go','internal/lower/invariance.go','docs/0.1.md','internal/lower/optional_widening_census_test.go','internal/lower/optional_widening_test.go','internal/oracle/testdata/field_access_paths.a']:return b
  if name=='internal/oracle/counts.md' or name=='internal/javascript/javascript.go':return a+b
  if name=='internal/lower/refusals.go' and 'checkedCast =' in b:return b
  if name=='internal/lower/refusals.go' and 'nodeBufferUnsupportedUse' in b:return b.replace('!l.nodeProcessMethodObservation(node)', '!l.nodeProcessMethodObservation(node) && !l.detachedOwnMethod(node)')
  return a+'\t}\n'+b
 s=re.sub(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);p.write_text(s)
subprocess.run(['git','add',*paths],check=True)
