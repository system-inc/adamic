from pathlib import Path
import subprocess,json,re,os
root=Path('/workspace/scratch/parser-front30-discovery-final-slice');out=Path('/workspace/scratch/parser-front30-discovery-final');out.mkdir();entry=root/'parser-proof-main.a';compiler='/workspace/scratch/parser-front30-front3-adamic';scratch='/workspace/scratch/parser-front30-scratch';rows=[]
def run(command,stem):
 with (out/(stem+'.stdout')).open('wb') as stdout,(out/(stem+'.stderr')).open('wb') as stderr:
  code=subprocess.run(command,cwd=scratch,stdout=stdout,stderr=stderr).returncode
 return code,(out/(stem+'.stderr')).read_text()
for i in range(15):
 code,text=run([compiler,'c',str(entry)],f'{i+1:02}')
 row={'order':i+1,'exit':code,'all_diagnostics':text};rows.append(row)
 if code==0:row['c_bytes']=(out/f'{i+1:02}.stdout').stat().st_size;break
 m=re.search(r'(?:adamic: )?(/.*?):(\d+):(\d+): (.*)',text)
 if not m:row['stop_reason']='No source coordinate in diagnostic';break
 path,line,col,message=m.groups();p=Path(path);row.update(file=str(p.relative_to(root)),line=int(line),column=int(col),message=message,found_behind_stubs=i>0)
 source=p.read_bytes();edit=None
 if p.name=='parser-proof-main.a' and "node:fs" in message:
  row['minimal']='native-node-fs-import.a';source=source.replace(b"import type {} from 'node:fs';",b'function parserProofMissingNodeTypes(): never { throw "discovery-only missing Node types"; }');edit='Type-only Node activation import replaced by unused throwing declaration; no runtime binding invented.'
 elif p.name=='core.ts' and 'NodeJS' in message:
  row['minimal']='native-nodejs-process-type.a';source=source.replace(b'NodeJS.Process',b'ReturnType<typeof parserProofMissingProcess>');source+=b'\nfunction parserProofMissingProcess(): any { throw "discovery-only NodeJS process placeholder"; }\n';edit='Missing NodeJS.Process substituted by type of a throwing any-return placeholder; scope limited to discovery host type.'
 elif p.name=='performanceCore.ts' and "'require'" in message:
  row['minimal']='native-require-perf-hooks.a';source=source.replace(b'function tryGetPerformance() {',b'function tryGetPerformance(): { shouldWriteNativeEvents: boolean; performance: Performance } | undefined {');p.write_bytes(source)
  code,stub_error=run(['node','/workspace/scratch/parser-front27-stub.cjs',path,line,col],f'{i+1:02}-stub');row['stub_exit']=code
  if code:row['stub_error']=stub_error;break
  row['stub']=json.loads((out/f'{i+1:02}-stub.stdout').read_text());edit='Throwing tryGetPerformance body; original inferred return shape explicit, removes require and perf_hooks type import together.';source=p.read_bytes()
 elif p.name=='tracing.ts' and "'fs'" in message:
  row['minimal']='native-fs-type-import.a';source=source.replace(b'typeof import("fs")',b'ReturnType<typeof parserProofMissingFS>');source+=b'\nfunction parserProofMissingFS(): any { throw "discovery-only fs type placeholder"; }\n';edit='Missing fs module type substituted by type of a throwing any-return placeholder; discovery only.'
 else:
  code,stub_error=run(['node','/workspace/scratch/parser-front27-stub.cjs',path,line,col],f'{i+1:02}-stub');row['stub_exit']=code
  if code:row['stub_error']=stub_error;row['stop_reason']='Cannot replace structural declaration with existing throwing-function placeholder';break
  row['stub']=json.loads((out/f'{i+1:02}-stub.stdout').read_text());source=p.read_bytes();edit='Function body replaced by throwing placeholder; predicate callback annotations may become boolean as recorded.'
 if i==14:row['final_limit']='Fifteen stops reached';break
 if p.name=='tracing.ts' and row.get('stub',{}).get('name')=='startTracing':
  source=source.replace(b'let mode: Mode;',b'let mode: Mode = parserProofMissingTraceMode(); function parserProofMissingTraceMode(): Mode { throw "discovery-only mode assignment removed with startTracing"; }')
  edit+=' Preserve removed mode initialization with a throwing typed initializer to avoid artificial definite-assignment diagnostics.'
 p.write_bytes(source);row['placeholder']=edit
 (out/'report.json').write_text(json.dumps({'warning':'Uncommitted discovery copy only. No Node identity or native acceptance. Host placeholder types intentionally any because Node bindings absent.','rows':rows},indent=2)+'\n')
(out/'report.json').write_text(json.dumps({'warning':'Uncommitted discovery copy only. No Node identity or native acceptance. Host placeholder types intentionally any because Node bindings absent.','rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
