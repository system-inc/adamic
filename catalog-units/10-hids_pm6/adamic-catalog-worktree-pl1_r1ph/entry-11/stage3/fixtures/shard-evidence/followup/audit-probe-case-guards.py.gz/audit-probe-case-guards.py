import contextlib,importlib.util,io,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('shards',Path('/workspace/adamic/stage3/meter/shards.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.GROUPS['meter'];sys.argv=['shards.py','meter','--list']
for label,paths in [('duplicate',original+original),('empty',[])]:
 module.GROUPS['meter']=paths
 try:module.main();raise AssertionError(label+' accepted')
 except SystemExit as error:assert error.code==2;print(label,'case inventory mutant caught')
module.GROUPS['meter']=original;sys.argv=['shards.py','meter','--list','--plant-failure','nonexistent.case']
try:module.main();raise AssertionError('unknown case accepted')
except SystemExit as error:assert error.code==2;print('unknown planted case caught')
