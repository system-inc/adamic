package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/system-inc/adamic/internal/load"
	"github.com/system-inc/adamic/internal/lower"
	"github.com/system-inc/adamic/stage3/census/moduleformat"
	"os"
	"path/filepath"
	"sort"
)

func main() {
	if len(os.Args) != 3 {
		panic("usage: latent source-directory output.json")
	}
	var paths []string
	err := filepath.WalkDir(os.Args[1], func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !entry.IsDir() && (filepath.Ext(path) == ".ts" || filepath.Ext(path) == ".a") {
			paths = append(paths, path)
		}
		return nil
	})
	if err != nil {
		panic(err)
	}
	sort.Strings(paths)
	output, err := os.Create(os.Args[2])
	if err != nil {
		panic(err)
	}
	defer output.Close()
	encoder := json.NewEncoder(output)
	program, err := load.LatentLoad(paths)
	if err != nil {
		panic(err)
	}
	if os.Getenv("LATENT_ASSERT_NO_OUTPUT") != "" {
		output, failure := lower.LowerWithOptions(context.Background(), program, lower.Options{ModuleFormat: moduleformat.Resolve(lower.ModuleFormatCommonJSBundle, lower.ModuleFormatEcmaScript), ProgramRegion: os.Getenv("ADAMIC_PROGRAM_REGION") == "1", OwnershipQuery: os.Getenv("ADAMIC_OWNERSHIP_QUERY") == "1"})
		if output != nil || failure == nil || failure.Error() != "latent census: measurement only; no IR output" {
			panic("measurement returned usable IR")
		}
		outputProgram, failure := load.Load(paths)
		if outputProgram != nil || failure == nil {
			panic("measurement loader exposed an output program")
		}
	}
	diagnostics := program.LatentDiagnostics()
	if diagnostics == nil {
		diagnostics = []string{}
	}
	header := map[string]any{"module_format": moduleformat.Name(), "measurement": lower.LatentMeasurementLabel, "status": "measurement", "latent_mode": censusMode(), "checker_rejected": len(diagnostics) > 0, "diagnostics": diagnostics, "diagnostic_sites": program.LatentDiagnosticSites()}
	writeLatentStream(encoder, header, output.Sync, func(emit func(lower.LatentFile)) lower.LatentRelationReport {
		return lower.Latent(context.Background(), program, func(record lower.LatentFile) {
			emit(record)
			fmt.Fprintln(os.Stderr, record.File, len(record.Units), len(record.Findings), lower.LatentMeasurementLabel)
		})
	})

}

// Flush the header before any lowering. A cutoff cannot manufacture an end
// answer: the relation trailer is written only after the run returns normally.
func writeLatentStream(encoder *json.Encoder, header map[string]any, flush func() error, run func(func(lower.LatentFile)) lower.LatentRelationReport) {
	writeRecord := func(record any) {
		if err := encoder.Encode(record); err != nil {
			panic(err)
		}
		if err := flush(); err != nil {
			panic(err)
		}
	}
	writeRecord(header)
	relations := run(func(record lower.LatentFile) { writeRecord(record) })
	writeRecord(map[string]any{"module_format": moduleformat.Name(), "measurement": lower.LatentMeasurementLabel, "status": "relation_report", "relation_overflow": relations, "findings": relations.Findings})
}

func censusMode() string {
	if os.Getenv("LATENT_SPECULATIVE") == "1" && os.Getenv("LATENT_MUTANT_NO_STUBS") != "1" {
		return "speculative"
	}
	if os.Getenv("LATENT_FULL") == "1" {
		return "full"
	}
	return "first-error"
}
