// Independent body units exist only in the no-output measurement overlay.
package lower

import (
	"context"
	"fmt"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/system-inc/adamic/internal/ir"
	"github.com/system-inc/adamic/internal/load"
	"github.com/system-inc/adamic/stage3/census/moduleformat"
)

type latentCandidate struct {
	node        *ast.Node
	parent, top string
	depth       int
	ancestors   map[*ast.Node]bool
}

func latentCandidates(program *load.Program, file *ast.SourceFile) []latentCandidate {
	result := []latentCandidate{}
	var nested func(*ast.Node, string, string, int, map[*ast.Node]bool)
	nested = func(node *ast.Node, parent, top string, depth int, ancestors map[*ast.Node]bool) {
		result = append(result, latentCandidate{node, parent, top, depth, ancestors})
		next := make(map[*ast.Node]bool, len(ancestors)+1)
		for key, value := range ancestors {
			next[key] = value
		}
		next[node] = true
		latentNestedDeclarations(node.Body(), func(child *ast.Node) bool { nested(child, program.Where(node), top, depth+1, next); return false })
	}
	for _, node := range file.Statements.Nodes {
		if node.Kind == ast.KindFunctionDeclaration {
			nested(node, "", program.Where(node), 0, map[*ast.Node]bool{})
		} else {
			result = append(result, latentCandidate{node, "", program.Where(node), 0, nil})
			latentNestedDeclarations(node, func(child *ast.Node) bool {
				nested(child, program.Where(node), program.Where(node), 0, map[*ast.Node]bool{})
				return false
			})
		}
	}
	return result
}

// Register declarations throughout diagnosed containers without attempting their
// bodies. This establishes sibling names, not a proof that closures can compile.
func (l *lowering) latentRegisterNested(files []*ast.SourceFile) {
	for _, file := range files {
		for _, candidate := range latentCandidates(l.program, file) {
			node := candidate.node
			if node.Kind != ast.KindFunctionDeclaration || node.Name() == nil {
				continue
			}
			symbol := l.symbol(node.Name())
			if symbol == nil {
				continue
			}
			if len(node.TypeParameters()) > 0 {
				l.generics[symbol] = node
				continue
			}
			if _, exists := l.functions[symbol]; exists {
				continue
			}
			index := len(l.result.Functions)
			l.functions[symbol] = index
			l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
			l.latentDeclarations[index] = node
		}
	}
}

// Seed only a read's actual ancestor binding, using its checked type. Unsupported
// representations are still reported at the read; no ancestor initializer runs.
func (l *lowering) latentLexicalLocal(identifier *ast.Node, symbol *ast.Symbol) {
	if symbol == nil || l.latentAncestors == nil {
		return
	}
	if _, exists := l.locals[symbol]; exists {
		return
	}
	declaration := symbol.ValueDeclaration
	if declaration == nil {
		return
	}
	if declaration.Kind != ast.KindVariableDeclaration && declaration.Kind != ast.KindParameter && declaration.Kind != ast.KindBindingElement {
		return
	}
	owner := declaration.Parent
	for owner != nil && owner.Kind != ast.KindFunctionDeclaration && owner.Kind != ast.KindFunctionExpression && owner.Kind != ast.KindArrowFunction {
		owner = owner.Parent
	}
	if !l.latentAncestors[owner] || declaration.Name() == nil || !ast.IsIdentifier(declaration.Name()) {
		return
	}
	outer := l.functionIndex
	l.functionIndex = -1
	if owner.Name() != nil {
		if index, exists := l.functions[l.symbol(owner.Name())]; exists {
			l.functionIndex = index
		}
	}
	_, err := l.declareLocal(declaration.Name())
	l.functionIndex = outer
	if err != nil && l.unlowerable == nil {
		l.unlowerable = err
	}
}

func latentFull(ctx context.Context, program *load.Program, emit func(LatentFile)) {
	latentFullSelected(ctx, program, emit, nil)
}

func latentFullSelected(ctx context.Context, program *load.Program, emit func(LatentFile), selection *latentReplaySelection) {
	var facts *latentProgramFacts
	var modules []*ast.SourceFile
	// One site index for the run, as latentRun's: a function of the program alone, checked against the module order at
	// every view, so sharing it changes no answer (view_sites.go, #q1hyhzc). Each unit is a snapshot of its file's base,
	// which shares the holder, so without it every unit built its own.
	viewSites := &viewSiteIndex{}

	for _, file := range program.Files() {
		if !latentFileSelected(program.FileName(file)) {
			continue
		}
		if selection != nil && file != selection.file {
			continue
		}
		latentFindings = nil
		latentFindingOwner, latentFindingPhase = program.Where(file.AsNode()), "refusal_scan"
		record := LatentFile{Measurement: LatentMeasurementLabel, File: program.FileName(file), Declarations: latentDeclarations(program, file), Units: []LatentUnit{}}
		checker, release := program.Checker(ctx, file)
		fresh := func() *lowering {
			return &lowering{moduleFormat: moduleformat.Resolve(ModuleFormatCommonJSBundle, ModuleFormatEcmaScript), program: program, checker: checker, result: &ir.Program{}, this: -1, functionIndex: -1, viewSites: viewSites}
		}
		if selection == nil {
			func() {
				defer func() {
					if failure := recover(); failure != nil {
						latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(file.AsNode()), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
					}
				}()
				fresh().latentScan(file)
			}()
		}
		// Registration is prepared once per file, then deep-copied per attempted unit.
		base := fresh()
		var orderErr error
		errorPhase := "registration"
		boundaryReason := "module ordering failed; unit not lowered"
		if modules == nil {
			modules, orderErr = base.latentPrepassModules()
		}
		if orderErr != nil {
			latentFindingOwner, latentFindingPhase = program.Where(file.AsNode()), "registration"
			latentRecord(orderErr)
		}
		if orderErr == nil {
			func() {
				defer latentPrepassTimer("collectViewedElements")()
				orderErr = base.collectViewedElements(modules)
			}()
			if orderErr != nil {
				errorPhase = "prepass"
				boundaryReason = "lowering prepass failed; unit not lowered"
				latentFindingOwner, latentFindingPhase = program.Where(file.AsNode()), errorPhase
				latentRecord(orderErr)
			}
		}
		if orderErr == nil {
			func() { defer latentPrepassTimer("noteInheritance")(); base.noteInheritance(modules) }()
			func() { defer latentPrepassTimer("noteAccessorNames")(); base.noteAccessorNames(modules) }()
			if facts == nil {
				func() { defer latentPrepassTimer("noteOmittedOptionals")(); base.noteOmittedOptionals(modules) }()
			}
			base.latentRegister(program.Files())
			base.latentRegisterNested(program.Files())
			base.latentUseProgramFacts(&facts)
		}

		for _, candidate := range latentCandidates(program, file) {
			node := candidate.node
			if selection != nil && node != selection.node {
				continue
			}
			latentFindingOwner, latentFindingPhase = program.Where(node), "lowering"
			unit := LatentUnit{Measurement: LatentMeasurementLabel, Where: program.Where(node), Kind: node.Kind.String(), Status: "attempted", CheckerDiagnostics: []string{}, Parent: candidate.parent, Top: candidate.top, Depth: candidate.depth}
			if node.Name() != nil {
				unit.Name = node.Name().Text()
			}
			// A standalone generic, or a nested unit whose lexical types depend on
			// one, has no concrete call witness. Registration still makes the generic
			// available to nongeneric callers in this census.
			deferred := node.Kind == ast.KindFunctionDeclaration && len(node.TypeParameters()) > 0
			for ancestor := range candidate.ancestors {
				deferred = deferred || len(ancestor.TypeParameters()) > 0
			}
			if node.Kind == ast.KindFunctionDeclaration && node.Body() != nil {
				unit.BodyStart, unit.BodyEnd = node.Body().Pos(), node.Body().End()
				diagnostics := program.LatentOwnDiagnosticsIn(node.Body())
				if len(diagnostics) > 0 {
					unit.CheckerDiagnostics = diagnostics
				}
				if len(diagnostics) > 0 && !deferred {
					unit.Status = "split_checker_body"
					record.Units = append(record.Units, unit)
					continue
				}
			}
			if deferred {
				unit.Status = "deferred_generic_instantiation"
				record.Units = append(record.Units, unit)
				continue
			}
			func() {
				defer latentUnitTimer.Start(record.File, unit.Where)()
				defer func() {
					if failure := recover(); failure != nil {
						unit.Status = "panic"
						latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(node), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
						latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "Boundary", Where: program.Where(node), Reason: "unit panic; continued at next declaration", Text: fmt.Sprint(failure), Start: node.Pos(), End: node.End()})
					}
				}()
				if orderErr != nil {
					latentFindingPhase = errorPhase
					latentRecord(orderErr)
					latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "Boundary", Where: program.Where(node), Reason: boundaryReason, Text: orderErr.Error(), Start: node.Pos(), End: node.End()})
					return
				}
				l := base.latentSnapshot()
				l.latentAncestors = candidate.ancestors
				if l.latentDeferredUnit(node) {
					return
				}
				if node.Kind != ast.KindFunctionDeclaration {
					body, err := l.statement(node)
					l.result.Main = body
					latentRecord(err)
					l.latentFinishUnit(&unit, node)
					return
				}
				if node.Name() == nil {
					latentRecord(l.notYet(node, "an anonymous function declaration"))
					return
				}
				index, exists := l.functions[l.symbol(node.Name())]
				if !exists {
					index = len(l.result.Functions)
					l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
					l.functions[l.symbol(node.Name())] = index
				}
				err := l.lowerFunction(index, node, -1)
				latentRecord(err)
				latentRecord(l.unlowerable)
				l.latentFinishUnit(&unit, node)
				if err != nil {
					start, end := unit.BodyStart, unit.BodyEnd
					if end <= start {
						start, end = node.Pos(), node.End()
					}
					latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "Boundary", Where: program.Where(node), Reason: "function signature or prologue failed; continued at next declaration", Text: err.Error(), Start: start, End: end})
				}
			}()
			latentCheckUnitRelation(program, checker, &unit)
			record.Units = append(record.Units, unit)
		}
		release()
		seen := map[LatentFinding]bool{}
		record.Findings = []LatentFinding{}
		for _, finding := range latentFindings {
			if !seen[finding] {
				seen[finding] = true
				record.Findings = append(record.Findings, finding)
			}
		}
		emit(record)
	}
}
