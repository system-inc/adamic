// Compiled by make_overlay.py against main's real lowering and generated copier.
package lower

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/system-inc/adamic/internal/ir"
	"github.com/system-inc/adamic/internal/load"
)

// This test starts no compiler subprocess. The witness prevents a vacuous pass
// if a production preflight stops registering the predicate's checked field.
func TestLatentDeferredProbeOwnsPredicateRegistrationsHcxsh1k(t *testing.T) {
	t.Parallel()
	path := filepath.Join(t.TempDir(), "main.ts")
	const source = `interface Node { readonly kind: number }
interface Identifier extends Node { readonly kind: 1; readonly text: string }
function isIdentifier(node: Node): node is Identifier { return node.kind === 1; }
`
	if err := os.WriteFile(path, []byte(source), 0600); err != nil {
		t.Fatal(err)
	}
	program, err := load.LatentLoad([]string{path})
	if err != nil {
		t.Fatal(err)
	}
	if diagnostics := program.LatentDiagnostics(); len(diagnostics) != 0 {
		t.Fatal(diagnostics)
	}
	file := program.Files()[0]
	checker, release := program.Checker(context.Background(), file)
	defer release()
	var unit *ast.Node
	for _, node := range file.Statements.Nodes {
		if node.Kind == ast.KindFunctionDeclaration {
			unit = node
		}
	}
	if unit == nil {
		t.Fatal("predicate unit missing")
	}
	l := &lowering{program: program, checker: checker, result: &ir.Program{}, this: -1, functionIndex: -1}
	l.latentRegister(program.Files())
	if len(latentFindings) != 0 {
		t.Fatal("guard requires a fresh measurement invocation")
	}
	l.refusal.deferred = errors.New("unit-owned deferred refusal")
	before := l.latentSnapshot()
	witness := l.latentSnapshot()
	if err := witness.refuseNode(unit); err != nil {
		t.Fatal(err)
	}
	if len(witness.result.CheckedFields) == 0 || len(witness.viewSources) == 0 {
		t.Fatal("fixture preflight did not register a predicate checked field and view source")
	}
	if err := l.latentDeferredStop(unit); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(l.result, before.result) {
		t.Fatalf("deferred probe leaked IR registrations: CheckedFields before=%v after=%v", before.result.CheckedFields, l.result.CheckedFields)
	}
	if !reflect.DeepEqual(l.viewSources, before.viewSources) || !reflect.DeepEqual(l.refusal, before.refusal) {
		t.Fatal("deferred probe leaked view sources or refusal state")
	}
}
