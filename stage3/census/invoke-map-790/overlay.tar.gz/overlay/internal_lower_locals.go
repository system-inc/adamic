// Functions and declarations moved unchanged from lower.go.
package lower

import (
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/system-inc/adamic/internal/ir"
	"slices"
)

// variables lowers const and let declarations, each to a local of its own.
func (l *lowering) variables(list *ast.Node) ([]ir.Statement, error) {
	if list.Flags&ast.NodeFlagsBlockScoped == 0 && !assertionVarList(list) && !namespaceVariable(list) {
		return nil, &Refused{Where: l.program.Where(list), What: "var", Fix: "use const or let"}
	}
	statements := []ir.Statement{}
	for _, declaration := range list.AsVariableDeclarationList().Declarations.Nodes {
		name := declaration.Name()
		if name.Kind == ast.KindArrayBindingPattern || name.Kind == ast.KindObjectBindingPattern {
			// const [a, b] = tuple, and const { x, y } = object (collections.go).
			destructured, err := l.destructure(name, declaration.AsVariableDeclaration().Initializer)
			if err != nil {
				return nil, err
			}
			for index, statement := range destructured {
				if declared, ok := statement.(ir.Declare); ok && l.result.Locals[declared.Local].NamespaceVar {
					destructured[index] = ir.Assign{Local: declared.Local, Value: declared.Value}
				}
			}
			statements = append(statements, destructured...)
			continue
		}
		if !ast.IsIdentifier(name) {
			return nil, l.notYet(name, "a destructuring declaration")
		}
		if initializer := declaration.AsVariableDeclaration().Initializer; initializer != nil && l.function != nil && !l.function.Suspends() {
			// A generator's direct call stored in a local of a function (#qk8rztp S2c-4-1). At a
			// module's top level, or in a function that suspends, the call stops where it's lowered
			// below, as it did before.
			function, isGenerator, err := l.storedGeneratorCallee(initializer)
			if err != nil {
				return nil, err
			}
			if isGenerator {
				stored, err := l.storedGenerator(list, declaration, function)
				if err != nil {
					return nil, err
				}
				statements = append(statements, stored...)
				continue
			}
		}

		if list.Flags&ast.NodeFlagsBlockScoped == 0 && !namespaceVariable(list) {
			if symbol := l.symbol(name); symbol != nil && len(symbol.Declarations) > 1 {
				return nil, &Refused{Where: l.program.Where(declaration), What: "repeated var assertion declarations", Fix: "use one declaration and subsequent assignments"}
			}
		}
		local, err := l.declareLocal(name)
		if err != nil {
			return nil, err
		}
		if list.Flags&ast.NodeFlagsBlockScoped == 0 {
			l.result.Locals[local].Hoisted = true
		}
		if l.result.Locals[local].NamespaceVar && declaration.Initializer() == nil {
			continue // Hoisted storage must not overwrite an earlier assignment.
		}
		if l.uninitializedDeclaration(declaration) {
			l.result.Locals[local].Uninitialized = true
			initializer := declaration.AsVariableDeclaration().Initializer
			declaration := ir.Declare{Local: local, Uninitialized: true}
			if l.result.Locals[local].Placeholder != "" {
				declaration.Value = l.placeholderInitialValue(initializer, l.result.Locals[local].Type)
			}
			statements = append(statements, declaration)
			continue
		}

		var value ir.Expression
		if initializer := declaration.AsVariableDeclaration().Initializer; initializer != nil {
			if l.initializing == nil {
				l.initializing = map[int]*ast.Node{}
			}
			l.initializing[local] = name
			if l.detachedOwnDeclaration(declaration) && l.detachedOwnMethod(initializer) {
				value = ir.BooleanConstant{Value: true}
			} else {
				value, err = l.expression(initializer)
			}
			delete(l.initializing, local)
			if err != nil {
				return nil, err
			}
		} else if !l.result.Locals[local].NamespaceVar && (l.includesUndefined(l.checker.GetTypeAtLocation(name)) || l.evolvingObject(name) != nil) {
			// An optional declaration can be read before assignment. Its first value
			// is undefined, not the backend's unobservable storage placeholder. Namespace
			// var was initialized when hoisted; a later declaration must not reset it.
			value = ir.Undefined{Of: ir.Object}
		}
		if closure, literal := value.(ir.MakeClosure); literal && list.Flags&ast.NodeFlagsConst != 0 {
			l.result.Locals[local].ConstantClosure = closure.Function + 1
		}
		if l.result.Locals[local].NamespaceVar {
			if value != nil {
				statements = append(statements, ir.Assign{Local: local, Value: fit(value, l.result.Locals[local].Type)})
			}
		} else {
			statements = append(statements, l.initializeLocal(local, fit(value, l.result.Locals[local].Type))...)
		}
	}
	return statements, nil
}

// skipped reports whether an element of an array binding pattern is a hole, as in const [, b]: the
// checker's tree has a binding element with no name there.
func skipped(binding *ast.Node) bool {
	return binding.Kind == ast.KindOmittedExpression || binding.Name() == nil
}

// declareLocal makes a new local for a declared name, typed by what the checker proved for it.
func (l *lowering) latentDeclareLocalRaw(name *ast.Node) (int, error) {
	symbol := l.symbol(name)
	if symbol == nil {
		return 0, l.notYet(name, "the checker gave a declaration no symbol")
	}
	valueType := ir.Object
	inferred := l.evolvingObject(name)
	if l.detachedOwnAlias(name) != nil {
		valueType = ir.Boolean
	} else if l.detachedOwnObjectParameter(name) {
		valueType = ir.Object
	} else if !l.alwaysUndefined[symbol] && !l.caught[symbol] {
		var err error
		if valueType, err = l.typeOf(name); err != nil {
			if inferred == nil {
				return 0, err
			}
			valueType = ir.Object
		}
	}
	if origin := l.placeholderOrigin(name); origin != "" {
		valueType = placeholderStorage(valueType)
	}
	unsetField := ""
	if declaration := name.Parent; declaration != nil && declaration.Kind == ast.KindVariableDeclaration && declaration.Type() == nil && declaration.Initializer() != nil && declaration.Parent.Flags&ast.NodeFlagsConst != 0 {
		unsetField = l.savedFactoryOrigin(declaration.Initializer(), map[*ast.Symbol]bool{})
		if unsetField != "" {
			valueType = ir.Union
		}
	}
	if l.locals == nil {
		l.locals = map[*ast.Symbol]int{}
	}
	if local, isDeclared := l.locals[symbol]; isDeclared {
		// A global, registered before anything was lowered.
		return local, nil
	}
	l.locals[symbol] = len(l.result.Locals)
	l.result.Locals = append(l.result.Locals, ir.Local{UnsetField: unsetField, Name: name.Text(), Type: valueType, Function: l.functionIndex, Placeholder: l.placeholderOrigin(name), Uninitialized: l.placeholderOrigin(name) != "" && (name.Parent.Kind != ast.KindParameter || l.uninitializedInitializer(name.Parent.AsParameterDeclaration().Initializer))})
	proven := l.checker.GetTypeAtLocation(name)
	if l.detachedOwnAlias(name) != nil {
		// This local holds only the readiness marker. The intrinsic cannot escape,
		// so cycle analysis must not treat it as a user closure capturing cells.
		proven = l.checker.GetBooleanType()
	} else if inferred != nil {
		proven = inferred
	}
	l.noteLocal(l.locals[symbol], proven, name)
	return l.locals[symbol], nil
}

// noteAlso keeps another checker type a local has: a this shared by more than one instantiation.
func (l *lowering) noteAlso(local int, proven *checker.Type) {
	if l.localAlso == nil {
		l.localAlso = map[int][]*checker.Type{}
	}
	l.localAlso[local] = append(l.localAlso[local], proven)
}

// noteLocal keeps a local's checker type and declaration for the cycle finder.
func (l *lowering) noteLocal(local int, proven *checker.Type, node *ast.Node) {
	if l.localTypes == nil {
		l.localTypes, l.localNodes = map[int]*checker.Type{}, map[int]*ast.Node{}
	}
	l.localTypes[local], l.localNodes[local] = l.concrete(proven), node
	l.result.Locals[local].Source = l.sourceIdentity(node)
	if l.instance != nil {
		l.instance.templates = append(l.instance.templates, template{local: local, proven: proven})
	}
}

// symbol is what a name refers to, the same whichever file names it: an import resolves to what it
// imports, and an exported declaration to its export symbol, so one declaration is one symbol.
func (l *lowering) symbol(node *ast.Node) *ast.Symbol {
	symbol := l.checker.GetSymbolAtLocation(node)
	if symbol == nil {
		return nil
	}
	if symbol.Flags&ast.SymbolFlagsAlias != 0 {
		symbol = l.checker.GetAliasedSymbol(symbol)
	}
	return l.checker.GetExportSymbolOfSymbol(symbol)
}

// local finds the local an identifier refers to, and notes a capture if it belongs to another
// function.
func (l *lowering) local(identifier *ast.Node) (int, bool) {
	return l.localOf(identifier, l.symbol(identifier))
}

// localOf is local for a symbol the identifier refers to other than the one it names: in
// { a } = value, a names the pattern's property, and the variable written is its value symbol.
func (l *lowering) localOf(identifier *ast.Node, symbol *ast.Symbol) (int, bool) {
	if latentFullEnabled() {
		l.latentLexicalLocal(identifier, symbol)
	}
	local, isLocal := l.locals[symbol]
	if isLocal {
		l.touch(local)
		if declared := l.result.Locals[local]; declared.Placeholder != "" && declared.Captured && declared.Preallocated && declared.Ready == 0 && l.unlowerable == nil {
			l.unlowerable = l.notYet(identifier, "an unset-capable capture before its declaration without a separate declaration-readiness cell")
		}
		if declared := l.result.Locals[local]; declared.Captured && !boxedSlot(declared.Type) && l.unlowerable == nil {
			// A Union is one counted heap reference whatever initializes it, a placeholder or a
			// value (#n7sx9gz), and a cell holds one: each write fits its member into the Union, the
			// cell releases what it held, and a read is the Union every closure shares. boolean |
			// undefined has no word of its own in a cell yet, so its capture still stops. Lower
			// says so once it's done, since the capture is found here, where nothing can return
			// an error.
			l.unlowerable = l.notYet(identifier, "a "+typeName(declared.Type)+" variable a function value captures")
		}
	}
	return local, isLocal
}

// touch notes that the function being lowered reads or writes a local. One declared in another
// function, and not a global, is captured: it moves into a cell, and every closure being lowered
// between its function and this one carries that cell in its environment.
func (l *lowering) touch(local int) {
	declared := l.result.Locals[local]
	if declared.Ready != 0 {
		l.touch(declared.Ready - 1)
	}
	if declared.Global || declared.Function == l.functionIndex {
		return
	}
	l.result.Locals[local].Captured = true
	if name, isInitializing := l.initializing[local]; isInitializing && l.unlowerable == nil {
		// const f = () => f(): the function value is made before the variable's cell is, so it has
		// nothing to capture yet.
		l.unlowerable = l.notYet(name, "a function value that captures the variable its own initializer declares")
	}
	start := 0
	for position, closure := range l.closures {
		if closure == declared.Function {
			start = position + 1
		}
	}
	for _, closure := range l.closures[start:] {
		function := &l.result.Functions[closure]
		if !slices.Contains(function.Environment, local) {
			function.Environment = append(function.Environment, local)
		}
	}
}

// checked guards switch lexical bindings, captured cells, and globals reached before initialization.
func (l *lowering) checked(local int) bool {
	return l.result.Locals[local].NamespaceState || l.result.Locals[local].Ready != 0 || (l.result.Locals[local].Global && (l.function != nil || l.cyclicModules)) || (l.function != nil && l.result.Locals[local].Preallocated && l.result.Locals[local].Captured)
}

func (l *lowering) constant(value string) int {
	if l.strings == nil {
		l.strings = map[string]int{}
	}
	if index, isKnown := l.strings[value]; isKnown {
		return index
	}
	l.strings[value] = len(l.result.Strings)
	l.result.Strings = append(l.result.Strings, value)
	return l.strings[value]
}

// localRead preserves checker narrowing for both private and qualified singleton reads.
func (l *lowering) localRead(node *ast.Node, local int) (ir.Expression, error) {
	l.narrowedRead(node, local)
	if origin := l.result.Locals[local].Placeholder; origin != "" {
		return l.placeholderRead(node, ir.Read{Local: local, Of: l.result.Locals[local].Type, Checked: l.result.Locals[local].NamespaceState || l.checkedModuleRead(node, local), Unset: true}, origin), nil
	}
	read := ir.Expression(ir.Read{Local: local, Of: l.result.Locals[local].Type, Checked: l.result.Locals[local].NamespaceState || l.checkedModuleRead(node, local), Readiness: sourceExpression(node)})
	if origin := l.result.Locals[local].UnsetField; origin != "" {
		return l.unsetSpecialization(node, read, l.checker.GetTypeOfSymbol(l.symbol(node)), origin)
	}
	if l.result.Locals[local].Type == ir.Union {
		if l.nullableObjectUnion(l.checker.GetTypeOfSymbol(l.symbol(node))) {
			return l.checkedNullableObject(node, read), nil
		}
		// Where the checker has narrowed it to fewer members held one way, it's read as that.
		parent := node.Parent
		for parent != nil && parent.Kind == ast.KindParenthesizedExpression {
			parent = parent.Parent
		}
		observing := comparedWithUndefined(node) || (parent != nil && parent.Kind == ast.KindTypeOfExpression) || unionEqualityObservation(node) || l.checker.GetTypeAtLocation(node).Flags()&(checker.TypeFlagsUndefined|checker.TypeFlagsNull) != 0
		if narrowed, isKnown := l.representation(l.checker.GetTypeAtLocation(node)); isKnown && narrowed != ir.Union && !observing {
			// Calls and captured writes can invalidate the checker's narrowing. Check the
			// held member before casting it, with ordinary IR shared by both backends.
			name := "object"
			switch narrowed.Present() {
			case ir.Number:
				name = "number"
			case ir.Boolean:
				name = "boolean"
			case ir.String:
				name = "string"
			case ir.Closure:
				name = "function"
			}
			nullable, excludesArray := false, false
			if name == "object" {
				// typeof cannot distinguish object members: null, another class, a typed array
				// or a promise all say object. Beside the narrowed members, only undefined, null
				// (tested for below) and the kinds typeof tells from an object may sit, so any
				// other member, or one whose holding isn't known, stops here. Arrays use their
				// own brand check; a class beside an array also excludes that brand below.
				declared := l.concrete(l.checker.GetTypeOfSymbol(l.symbol(node)))
				members := []*checker.Type{declared}
				if declared.Flags()&checker.TypeFlagsUnion != 0 {
					members = declared.Types()
				}
				observed := l.concrete(l.checker.GetTypeAtLocation(node))
				kept := []*checker.Type{observed}
				if observed.Flags()&checker.TypeFlagsUnion != 0 {
					kept = observed.Types()
				}
				for _, member := range members {
					held, known := l.representation(member)
					if narrowed == ir.Array {
						// Tuples and erased views can hide a layout other than adamic_array.
						if !l.arrayPredicateDomain(member) {
							return nil, l.notYet(node, "a narrowed union member whose object tag cannot be checked with typeof; keep differently held object kinds in separately typed variables")
						}
						continue
					}
					if narrowed == ir.Object && isClassInstance(observed) && known && held == ir.Array {
						excludesArray = true
						continue
					}
					if known && held == narrowed && (slices.Contains(kept, member) || member.Flags()&(checker.TypeFlagsUndefined|checker.TypeFlagsVoid) != 0) {
						// A narrowed member, or undefined held as a missing object, which typeof says
						// undefined for.
						continue
					}
					if known && held == narrowed && member.Flags()&checker.TypeFlagsNull != 0 {
						nullable = true
						continue
					}
					if known {
						switch held.Present() {
						case ir.Number, ir.Boolean, ir.String, ir.Closure, ir.UndefinedRepresentation:
							continue
						}
					}
					return nil, l.notYet(node, "a narrowed union member whose object tag cannot be checked with typeof; keep differently held object kinds in separately typed variables")
				}
			}
			b := l.libraryArrayBuilder([]ir.Expression{read})
			held := b.read(b.parameters[0])
			matches := ir.Expression(ir.Binary{Operator: ir.Equal, Left: ir.TypeOf{Value: held}, Right: ir.StringConstant{Index: l.constant(name)}})
			if narrowed == ir.Array {
				matches = ir.ArrayIsArray{Value: held}
			}
			if excludesArray {
				matches = ir.Binary{Operator: ir.And, Left: matches, Right: ir.Unary{Operator: ir.Not, Operand: ir.ArrayIsArray{Value: held}}}
			}
			if nullable {
				// typeof says object for null too.
				matches = ir.Binary{Operator: ir.And, Left: matches, Right: ir.Unary{Operator: ir.Not, Operand: ir.IsNull{Value: held}}}
			}
			if l.includesUndefined(l.checker.GetTypeAtLocation(node)) {
				matches = ir.Binary{Operator: ir.Or, Left: matches, Right: ir.IsUndefined{Value: held}}
			}
			message := "union member where the checker narrowed it away: a call since the narrowing put it back"
			b.body = append(b.body, ir.If{Condition: ir.Unary{Operator: ir.Not, Operand: matches}, Then: []ir.Statement{ir.Panic{Message: ir.StringConstant{Index: l.constant(message)}}}})
			read = b.finish("narrowed_union_member", ir.Narrow{Value: held, To: narrowed})
			l.result.Functions[b.function].CheckedUnionNarrow = true
		}
	}
	if declared := l.result.Locals[local].Type; declared.IsMaybe() {
		// Where the checker has narrowed it to what it holds, it's read as that.
		if narrowed, _ := l.representation(l.checker.GetTypeAtLocation(node)); narrowed == declared.Present() && !l.acceptsUndefined(node) {
			read = ir.Unwrap{Value: read}
		}
	}
	return l.defined(node, read), nil
}

func (l *lowering) declareLocal(name *ast.Node) (int, error) { return l.latentSpecDeclareLocal(name) }
