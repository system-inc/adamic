"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setTextRange = setTextRange;
exports.canHaveModifiers = canHaveModifiers;
exports.canHaveDecorators = canHaveDecorators;
const ts_js_1 = require("../_namespaces/ts.js");
function setTextRange(range, location) {
    return location ? (0, ts_js_1.setTextRangePosEnd)(range, location.pos, location.end) : range;
}
function canHaveModifiers(node) {
    const kind = node.kind;
    return kind === 169 /* SyntaxKind.TypeParameter */
        || kind === 170 /* SyntaxKind.Parameter */
        || kind === 172 /* SyntaxKind.PropertySignature */
        || kind === 173 /* SyntaxKind.PropertyDeclaration */
        || kind === 174 /* SyntaxKind.MethodSignature */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 177 /* SyntaxKind.Constructor */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 182 /* SyntaxKind.IndexSignature */
        || kind === 186 /* SyntaxKind.ConstructorType */
        || kind === 219 /* SyntaxKind.FunctionExpression */
        || kind === 220 /* SyntaxKind.ArrowFunction */
        || kind === 232 /* SyntaxKind.ClassExpression */
        || kind === 244 /* SyntaxKind.VariableStatement */
        || kind === 263 /* SyntaxKind.FunctionDeclaration */
        || kind === 264 /* SyntaxKind.ClassDeclaration */
        || kind === 265 /* SyntaxKind.InterfaceDeclaration */
        || kind === 266 /* SyntaxKind.TypeAliasDeclaration */
        || kind === 267 /* SyntaxKind.EnumDeclaration */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 272 /* SyntaxKind.ImportEqualsDeclaration */
        || kind === 273 /* SyntaxKind.ImportDeclaration */
        || kind === 278 /* SyntaxKind.ExportAssignment */
        || kind === 279 /* SyntaxKind.ExportDeclaration */;
}
function canHaveDecorators(node) {
    const kind = node.kind;
    return kind === 170 /* SyntaxKind.Parameter */
        || kind === 173 /* SyntaxKind.PropertyDeclaration */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 232 /* SyntaxKind.ClassExpression */
        || kind === 264 /* SyntaxKind.ClassDeclaration */;
}
