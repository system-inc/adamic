"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRuntimeTypeSerializer = createRuntimeTypeSerializer;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function createRuntimeTypeSerializer(context) {
    const { factory, hoistVariableDeclaration, } = context;
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const strictNullChecks = (0, ts_js_1.getStrictOptionValue)(compilerOptions, "strictNullChecks");
    let currentLexicalScope;
    let currentNameScope;
    return {
        serializeTypeNode: (serializerContext, node) => setSerializerContextAnd(serializerContext, serializeTypeNode, node),
        serializeTypeOfNode: (serializerContext, node, container) => setSerializerContextAnd(serializerContext, serializeTypeOfNode, node, container),
        serializeParameterTypesOfNode: (serializerContext, node, container) => setSerializerContextAnd(serializerContext, serializeParameterTypesOfNode, node, container),
        serializeReturnTypeOfNode: (serializerContext, node) => setSerializerContextAnd(serializerContext, serializeReturnTypeOfNode, node),
    };
    function setSerializerContextAnd(serializerContext, cb, node, arg) {
        const savedCurrentLexicalScope = currentLexicalScope;
        const savedCurrentNameScope = currentNameScope;
        currentLexicalScope = serializerContext.currentLexicalScope;
        currentNameScope = serializerContext.currentNameScope;
        const result = arg === undefined ? cb(node) : cb(node, arg);
        currentLexicalScope = savedCurrentLexicalScope;
        currentNameScope = savedCurrentNameScope;
        return result;
    }
    function getAccessorTypeNode(node, container) {
        const accessors = (0, ts_js_1.getAllAccessorDeclarations)(container.members, node);
        return accessors.setAccessor && (0, ts_js_1.getSetAccessorTypeAnnotationNode)(accessors.setAccessor)
            || accessors.getAccessor && (0, ts_js_1.getEffectiveReturnTypeNode)(accessors.getAccessor);
    }
    /**
     * Serializes the type of a node for use with decorator type metadata.
     * @param node The node that should have its type serialized.
     */
    function serializeTypeOfNode(node, container) {
        switch (node.kind) {
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 170 /* SyntaxKind.Parameter */:
                return serializeTypeNode(node.type);
            case 179 /* SyntaxKind.SetAccessor */:
            case 178 /* SyntaxKind.GetAccessor */:
                return serializeTypeNode(getAccessorTypeNode(node, container));
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 232 /* SyntaxKind.ClassExpression */:
            case 175 /* SyntaxKind.MethodDeclaration */:
                return factory.createIdentifier("Function");
            default:
                return factory.createVoidZero();
        }
    }
    /**
     * Serializes the type of a node for use with decorator type metadata.
     * @param node The node that should have its type serialized.
     */
    function serializeParameterTypesOfNode(node, container) {
        const valueDeclaration = (0, ts_js_1.isClassLike)(node)
            ? (0, ts_js_1.getFirstConstructorWithBody)(node)
            : (0, ts_js_1.isFunctionLike)(node) && (0, ts_js_1.nodeIsPresent)(node.body)
                ? node
                : undefined;
        const expressions = [];
        if (valueDeclaration) {
            const parameters = getParametersOfDecoratedDeclaration(valueDeclaration, container);
            const numParameters = parameters.length;
            for (let i = 0; i < numParameters; i++) {
                const parameter = parameters[i];
                if (i === 0 && (0, ts_js_1.isIdentifier)(parameter.name) && parameter.name.escapedText === "this") {
                    continue;
                }
                if (parameter.dotDotDotToken) {
                    expressions.push(serializeTypeNode((0, ts_js_1.getRestParameterElementType)(parameter.type)));
                }
                else {
                    expressions.push(serializeTypeOfNode(parameter, container));
                }
            }
        }
        return factory.createArrayLiteralExpression(expressions);
    }
    function getParametersOfDecoratedDeclaration(node, container) {
        if (container && node.kind === 178 /* SyntaxKind.GetAccessor */) {
            const { setAccessor } = (0, ts_js_1.getAllAccessorDeclarations)(container.members, node);
            if (setAccessor) {
                return setAccessor.parameters;
            }
        }
        return node.parameters;
    }
    /**
     * Serializes the return type of a node for use with decorator type metadata.
     * @param node The node that should have its return type serialized.
     */
    function serializeReturnTypeOfNode(node) {
        if ((0, ts_js_1.isFunctionLike)(node) && node.type) {
            return serializeTypeNode(node.type);
        }
        else if ((0, ts_js_1.isAsyncFunction)(node)) {
            return factory.createIdentifier("Promise");
        }
        return factory.createVoidZero();
    }
    /**
     * Serializes a type node for use with decorator type metadata.
     *
     * Types are serialized in the following fashion:
     * - Void types point to "undefined" (e.g. "void 0")
     * - Function and Constructor types point to the global "Function" constructor.
     * - Interface types with a call or construct signature types point to the global
     *   "Function" constructor.
     * - Array and Tuple types point to the global "Array" constructor.
     * - Type predicates and booleans point to the global "Boolean" constructor.
     * - String literal types and strings point to the global "String" constructor.
     * - Enum and number types point to the global "Number" constructor.
     * - Symbol types point to the global "Symbol" constructor.
     * - Type references to classes (or class-like variables) point to the constructor for the class.
     * - Anything else points to the global "Object" constructor.
     *
     * @param node The type node to serialize.
     */
    function serializeTypeNode(node) {
        if (node === undefined) {
            return factory.createIdentifier("Object");
        }
        node = (0, ts_js_1.skipTypeParentheses)(node);
        switch (node.kind) {
            case 116 /* SyntaxKind.VoidKeyword */:
            case 157 /* SyntaxKind.UndefinedKeyword */:
            case 146 /* SyntaxKind.NeverKeyword */:
                return factory.createVoidZero();
            case 185 /* SyntaxKind.FunctionType */:
            case 186 /* SyntaxKind.ConstructorType */:
                return factory.createIdentifier("Function");
            case 189 /* SyntaxKind.ArrayType */:
            case 190 /* SyntaxKind.TupleType */:
                return factory.createIdentifier("Array");
            case 183 /* SyntaxKind.TypePredicate */:
                return node.assertsModifier ?
                    factory.createVoidZero() :
                    factory.createIdentifier("Boolean");
            case 136 /* SyntaxKind.BooleanKeyword */:
                return factory.createIdentifier("Boolean");
            case 204 /* SyntaxKind.TemplateLiteralType */:
            case 154 /* SyntaxKind.StringKeyword */:
                return factory.createIdentifier("String");
            case 151 /* SyntaxKind.ObjectKeyword */:
                return factory.createIdentifier("Object");
            case 202 /* SyntaxKind.LiteralType */:
                return serializeLiteralOfLiteralTypeNode(node.literal);
            case 150 /* SyntaxKind.NumberKeyword */:
                return factory.createIdentifier("Number");
            case 163 /* SyntaxKind.BigIntKeyword */:
                return getGlobalConstructor("BigInt", 7 /* ScriptTarget.ES2020 */);
            case 155 /* SyntaxKind.SymbolKeyword */:
                return getGlobalConstructor("Symbol", 2 /* ScriptTarget.ES2015 */);
            case 184 /* SyntaxKind.TypeReference */:
                return serializeTypeReferenceNode(node);
            case 194 /* SyntaxKind.IntersectionType */:
                return serializeUnionOrIntersectionConstituents(node.types, /*isIntersection*/ true);
            case 193 /* SyntaxKind.UnionType */:
                return serializeUnionOrIntersectionConstituents(node.types, /*isIntersection*/ false);
            case 195 /* SyntaxKind.ConditionalType */:
                return serializeUnionOrIntersectionConstituents([node.trueType, node.falseType], /*isIntersection*/ false);
            case 199 /* SyntaxKind.TypeOperator */:
                if (node.operator === 148 /* SyntaxKind.ReadonlyKeyword */) {
                    return serializeTypeNode(node.type);
                }
                break;
            case 187 /* SyntaxKind.TypeQuery */:
            case 200 /* SyntaxKind.IndexedAccessType */:
            case 201 /* SyntaxKind.MappedType */:
            case 188 /* SyntaxKind.TypeLiteral */:
            case 133 /* SyntaxKind.AnyKeyword */:
            case 159 /* SyntaxKind.UnknownKeyword */:
            case 198 /* SyntaxKind.ThisType */:
            case 206 /* SyntaxKind.ImportType */:
                break;
            // handle JSDoc types from an invalid parse
            case 313 /* SyntaxKind.JSDocAllType */:
            case 314 /* SyntaxKind.JSDocUnknownType */:
            case 318 /* SyntaxKind.JSDocFunctionType */:
            case 319 /* SyntaxKind.JSDocVariadicType */:
            case 320 /* SyntaxKind.JSDocNamepathType */:
                break;
            case 315 /* SyntaxKind.JSDocNullableType */:
            case 316 /* SyntaxKind.JSDocNonNullableType */:
            case 317 /* SyntaxKind.JSDocOptionalType */:
                return serializeTypeNode(node.type);
            default:
                return ts_js_1.Debug.failBadSyntaxKind(node);
        }
        return factory.createIdentifier("Object");
    }
    function serializeLiteralOfLiteralTypeNode(node) {
        switch (node.kind) {
            case 11 /* SyntaxKind.StringLiteral */:
            case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
                return factory.createIdentifier("String");
            case 225 /* SyntaxKind.PrefixUnaryExpression */: {
                const operand = node.operand;
                switch (operand.kind) {
                    case 9 /* SyntaxKind.NumericLiteral */:
                    case 10 /* SyntaxKind.BigIntLiteral */:
                        return serializeLiteralOfLiteralTypeNode(operand);
                    default:
                        return ts_js_1.Debug.failBadSyntaxKind(operand);
                }
            }
            case 9 /* SyntaxKind.NumericLiteral */:
                return factory.createIdentifier("Number");
            case 10 /* SyntaxKind.BigIntLiteral */:
                return getGlobalConstructor("BigInt", 7 /* ScriptTarget.ES2020 */);
            case 112 /* SyntaxKind.TrueKeyword */:
            case 97 /* SyntaxKind.FalseKeyword */:
                return factory.createIdentifier("Boolean");
            case 106 /* SyntaxKind.NullKeyword */:
                return factory.createVoidZero();
            default:
                return ts_js_1.Debug.failBadSyntaxKind(node);
        }
    }
    function serializeUnionOrIntersectionConstituents(types, isIntersection) {
        // Note when updating logic here also update `getEntityNameForDecoratorMetadata` in checker.ts so that aliases can be marked as referenced
        let serializedType;
        for (let typeNode of types) {
            typeNode = (0, ts_js_1.skipTypeParentheses)(typeNode);
            if (typeNode.kind === 146 /* SyntaxKind.NeverKeyword */) {
                if (isIntersection)
                    return factory.createVoidZero(); // Reduce to `never` in an intersection
                continue; // Elide `never` in a union
            }
            if (typeNode.kind === 159 /* SyntaxKind.UnknownKeyword */) {
                if (!isIntersection)
                    return factory.createIdentifier("Object"); // Reduce to `unknown` in a union
                continue; // Elide `unknown` in an intersection
            }
            if (typeNode.kind === 133 /* SyntaxKind.AnyKeyword */) {
                return factory.createIdentifier("Object"); // Reduce to `any` in a union or intersection
            }
            if (!strictNullChecks && (((0, ts_js_1.isLiteralTypeNode)(typeNode) && typeNode.literal.kind === 106 /* SyntaxKind.NullKeyword */) || typeNode.kind === 157 /* SyntaxKind.UndefinedKeyword */)) {
                continue; // Elide null and undefined from unions for metadata, just like what we did prior to the implementation of strict null checks
            }
            const serializedConstituent = serializeTypeNode(typeNode);
            if ((0, ts_js_1.isIdentifier)(serializedConstituent) && serializedConstituent.escapedText === "Object") {
                // One of the individual is global object, return immediately
                return serializedConstituent;
            }
            // If there exists union that is not `void 0` expression, check if the the common type is identifier.
            // anything more complex and we will just default to Object
            if (serializedType) {
                // Different types
                if (!equateSerializedTypeNodes(serializedType, serializedConstituent)) {
                    return factory.createIdentifier("Object");
                }
            }
            else {
                // Initialize the union type
                serializedType = serializedConstituent;
            }
        }
        // If we were able to find common type, use it
        return serializedType ?? (factory.createVoidZero()); // Fallback is only hit if all union constituents are null/undefined/never
    }
    function equateSerializedTypeNodes(left, right) {
        return (
        // temp vars used in fallback
        (0, ts_js_1.isGeneratedIdentifier)(left) ? (0, ts_js_1.isGeneratedIdentifier)(right) :
            // entity names
            (0, ts_js_1.isIdentifier)(left) ? (0, ts_js_1.isIdentifier)(right)
                && left.escapedText === right.escapedText :
                (0, ts_js_1.isPropertyAccessExpression)(left) ? (0, ts_js_1.isPropertyAccessExpression)(right)
                    && equateSerializedTypeNodes(left.expression, right.expression)
                    && equateSerializedTypeNodes(left.name, right.name) :
                    // `void 0`
                    (0, ts_js_1.isVoidExpression)(left) ? (0, ts_js_1.isVoidExpression)(right)
                        && (0, ts_js_1.isNumericLiteral)(left.expression) && left.expression.text === "0"
                        && (0, ts_js_1.isNumericLiteral)(right.expression) && right.expression.text === "0" :
                        // `"undefined"` or `"function"` in `typeof` checks
                        (0, ts_js_1.isStringLiteral)(left) ? (0, ts_js_1.isStringLiteral)(right)
                            && left.text === right.text :
                            // used in `typeof` checks for fallback
                            (0, ts_js_1.isTypeOfExpression)(left) ? (0, ts_js_1.isTypeOfExpression)(right)
                                && equateSerializedTypeNodes(left.expression, right.expression) :
                                // parens in `typeof` checks with temps
                                (0, ts_js_1.isParenthesizedExpression)(left) ? (0, ts_js_1.isParenthesizedExpression)(right)
                                    && equateSerializedTypeNodes(left.expression, right.expression) :
                                    // conditionals used in fallback
                                    (0, ts_js_1.isConditionalExpression)(left) ? (0, ts_js_1.isConditionalExpression)(right)
                                        && equateSerializedTypeNodes(left.condition, right.condition)
                                        && equateSerializedTypeNodes(left.whenTrue, right.whenTrue)
                                        && equateSerializedTypeNodes(left.whenFalse, right.whenFalse) :
                                        // logical binary and assignments used in fallback
                                        (0, ts_js_1.isBinaryExpression)(left) ? (0, ts_js_1.isBinaryExpression)(right)
                                            && left.operatorToken.kind === right.operatorToken.kind
                                            && equateSerializedTypeNodes(left.left, right.left)
                                            && equateSerializedTypeNodes(left.right, right.right) :
                                            false);
    }
    /**
     * Serializes a TypeReferenceNode to an appropriate JS constructor value for use with decorator type metadata.
     * @param node The type reference node.
     */
    function serializeTypeReferenceNode(node) {
        const kind = resolver.getTypeReferenceSerializationKind(node.typeName, currentNameScope ?? currentLexicalScope);
        switch (kind) {
            case ts_js_1.TypeReferenceSerializationKind.Unknown:
                // From conditional type type reference that cannot be resolved is Similar to any or unknown
                if ((0, ts_js_1.findAncestor)(node, n => n.parent && (0, ts_js_1.isConditionalTypeNode)(n.parent) && (n.parent.trueType === n || n.parent.falseType === n))) {
                    return factory.createIdentifier("Object");
                }
                const serialized = serializeEntityNameAsExpressionFallback(node.typeName);
                const temp = factory.createTempVariable(hoistVariableDeclaration);
                return factory.createConditionalExpression(factory.createTypeCheck(factory.createAssignment(temp, serialized), "function"), 
                /*questionToken*/ undefined, temp, 
                /*colonToken*/ undefined, factory.createIdentifier("Object"));
            case ts_js_1.TypeReferenceSerializationKind.TypeWithConstructSignatureAndValue:
                return serializeEntityNameAsExpression(node.typeName);
            case ts_js_1.TypeReferenceSerializationKind.VoidNullableOrNeverType:
                return factory.createVoidZero();
            case ts_js_1.TypeReferenceSerializationKind.BigIntLikeType:
                return getGlobalConstructor("BigInt", 7 /* ScriptTarget.ES2020 */);
            case ts_js_1.TypeReferenceSerializationKind.BooleanType:
                return factory.createIdentifier("Boolean");
            case ts_js_1.TypeReferenceSerializationKind.NumberLikeType:
                return factory.createIdentifier("Number");
            case ts_js_1.TypeReferenceSerializationKind.StringLikeType:
                return factory.createIdentifier("String");
            case ts_js_1.TypeReferenceSerializationKind.ArrayLikeType:
                return factory.createIdentifier("Array");
            case ts_js_1.TypeReferenceSerializationKind.ESSymbolType:
                return getGlobalConstructor("Symbol", 2 /* ScriptTarget.ES2015 */);
            case ts_js_1.TypeReferenceSerializationKind.TypeWithCallSignature:
                return factory.createIdentifier("Function");
            case ts_js_1.TypeReferenceSerializationKind.Promise:
                return factory.createIdentifier("Promise");
            case ts_js_1.TypeReferenceSerializationKind.ObjectType:
                return factory.createIdentifier("Object");
            default:
                return ts_js_1.Debug.assertNever(kind);
        }
    }
    /**
     * Produces an expression that results in `right` if `left` is not undefined at runtime:
     *
     * ```
     * typeof left !== "undefined" && right
     * ```
     *
     * We use `typeof L !== "undefined"` (rather than `L !== undefined`) since `L` may not be declared.
     * It's acceptable for this expression to result in `false` at runtime, as the result is intended to be
     * further checked by any containing expression.
     */
    function createCheckedValue(left, right) {
        return factory.createLogicalAnd(factory.createStrictInequality(factory.createTypeOfExpression(left), factory.createStringLiteral("undefined")), right);
    }
    /**
     * Serializes an entity name which may not exist at runtime, but whose access shouldn't throw
     * @param node The entity name to serialize.
     */
    function serializeEntityNameAsExpressionFallback(node) {
        if (node.kind === 80 /* SyntaxKind.Identifier */) {
            // A -> typeof A !== "undefined" && A
            const copied = serializeEntityNameAsExpression(node);
            return createCheckedValue(copied, copied);
        }
        if (node.left.kind === 80 /* SyntaxKind.Identifier */) {
            // A.B -> typeof A !== "undefined" && A.B
            return createCheckedValue(serializeEntityNameAsExpression(node.left), serializeEntityNameAsExpression(node));
        }
        // A.B.C -> typeof A !== "undefined" && (_a = A.B) !== void 0 && _a.C
        const left = serializeEntityNameAsExpressionFallback(node.left);
        const temp = factory.createTempVariable(hoistVariableDeclaration);
        return factory.createLogicalAnd(factory.createLogicalAnd(left.left, factory.createStrictInequality(factory.createAssignment(temp, left.right), factory.createVoidZero())), factory.createPropertyAccessExpression(temp, node.right));
    }
    /**
     * Serializes an entity name as an expression for decorator type metadata.
     * @param node The entity name to serialize.
     */
    function serializeEntityNameAsExpression(node) {
        switch (node.kind) {
            case 80 /* SyntaxKind.Identifier */:
                // Create a clone of the name with a new parent, and treat it as if it were
                // a source tree node for the purposes of the checker.
                const name = (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(ts_js_1.parseNodeFactory.cloneNode(node), node), node.parent);
                name.original = undefined;
                (0, ts_js_1.setParent)(name, (0, ts_js_1.getParseTreeNode)(currentLexicalScope)); // ensure the parent is set to a parse tree node.
                return name;
            case 167 /* SyntaxKind.QualifiedName */:
                return serializeQualifiedNameAsExpression(node);
        }
    }
    /**
     * Serializes an qualified name as an expression for decorator type metadata.
     * @param node The qualified name to serialize.
     */
    function serializeQualifiedNameAsExpression(node) {
        return factory.createPropertyAccessExpression(serializeEntityNameAsExpression(node.left), node.right);
    }
    function getGlobalConstructorWithFallback(name) {
        return factory.createConditionalExpression(factory.createTypeCheck(factory.createIdentifier(name), "function"), 
        /*questionToken*/ undefined, factory.createIdentifier(name), 
        /*colonToken*/ undefined, factory.createIdentifier("Object"));
    }
    function getGlobalConstructor(name, minLanguageVersion) {
        return languageVersion < minLanguageVersion ?
            getGlobalConstructorWithFallback(name) :
            factory.createIdentifier(name);
    }
}
