"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supportedLocaleDirectories = exports.unchangedTextChangeRange = exports.targetToLibMap = void 0;
exports.isExternalModuleNameRelative = isExternalModuleNameRelative;
exports.sortAndDeduplicateDiagnostics = sortAndDeduplicateDiagnostics;
exports.getDefaultLibFileName = getDefaultLibFileName;
exports.textSpanEnd = textSpanEnd;
exports.textSpanIsEmpty = textSpanIsEmpty;
exports.textSpanContainsPosition = textSpanContainsPosition;
exports.textRangeContainsPositionInclusive = textRangeContainsPositionInclusive;
exports.textSpanContainsTextSpan = textSpanContainsTextSpan;
exports.textSpanContainsTextRange = textSpanContainsTextRange;
exports.textRangeContainsTextSpan = textRangeContainsTextSpan;
exports.textSpanOverlapsWith = textSpanOverlapsWith;
exports.textSpanOverlap = textSpanOverlap;
exports.textSpanIntersectsWithTextSpan = textSpanIntersectsWithTextSpan;
exports.textSpanIntersectsWith = textSpanIntersectsWith;
exports.decodedTextSpanIntersectsWith = decodedTextSpanIntersectsWith;
exports.textSpanIntersectsWithPosition = textSpanIntersectsWithPosition;
exports.textRangeIntersectsWithTextSpan = textRangeIntersectsWithTextSpan;
exports.textSpanIntersection = textSpanIntersection;
exports.normalizeSpans = normalizeSpans;
exports.createTextSpan = createTextSpan;
exports.createTextSpanFromBounds = createTextSpanFromBounds;
exports.textChangeRangeNewSpan = textChangeRangeNewSpan;
exports.textChangeRangeIsUnchanged = textChangeRangeIsUnchanged;
exports.createTextChangeRange = createTextChangeRange;
exports.collapseTextChangeRangesAcrossMultipleVersions = collapseTextChangeRangesAcrossMultipleVersions;
exports.getTypeParameterOwner = getTypeParameterOwner;
exports.isParameterPropertyDeclaration = isParameterPropertyDeclaration;
exports.isEmptyBindingPattern = isEmptyBindingPattern;
exports.isEmptyBindingElement = isEmptyBindingElement;
exports.walkUpBindingElementsAndPatterns = walkUpBindingElementsAndPatterns;
exports.getCombinedModifierFlags = getCombinedModifierFlags;
exports.getCombinedNodeFlagsAlwaysIncludeJSDoc = getCombinedNodeFlagsAlwaysIncludeJSDoc;
exports.getCombinedNodeFlags = getCombinedNodeFlags;
exports.validateLocaleAndSetLanguage = validateLocaleAndSetLanguage;
exports.getOriginalNode = getOriginalNode;
exports.findAncestor = findAncestor;
exports.isParseTreeNode = isParseTreeNode;
exports.getParseTreeNode = getParseTreeNode;
exports.escapeLeadingUnderscores = escapeLeadingUnderscores;
exports.unescapeLeadingUnderscores = unescapeLeadingUnderscores;
exports.idText = idText;
exports.identifierToKeywordKind = identifierToKeywordKind;
exports.symbolName = symbolName;
exports.nodeHasName = nodeHasName;
exports.getNameOfJSDocTypedef = getNameOfJSDocTypedef;
exports.isNamedDeclaration = isNamedDeclaration;
exports.getNonAssignedNameOfDeclaration = getNonAssignedNameOfDeclaration;
exports.getNameOfDeclaration = getNameOfDeclaration;
exports.getAssignedName = getAssignedName;
exports.getDecorators = getDecorators;
exports.getModifiers = getModifiers;
exports.getJSDocParameterTags = getJSDocParameterTags;
exports.getJSDocParameterTagsNoCache = getJSDocParameterTagsNoCache;
exports.getJSDocTypeParameterTags = getJSDocTypeParameterTags;
exports.getJSDocTypeParameterTagsNoCache = getJSDocTypeParameterTagsNoCache;
exports.hasJSDocParameterTags = hasJSDocParameterTags;
exports.getJSDocAugmentsTag = getJSDocAugmentsTag;
exports.getJSDocImplementsTags = getJSDocImplementsTags;
exports.getJSDocClassTag = getJSDocClassTag;
exports.getJSDocPublicTag = getJSDocPublicTag;
exports.getJSDocPublicTagNoCache = getJSDocPublicTagNoCache;
exports.getJSDocPrivateTag = getJSDocPrivateTag;
exports.getJSDocPrivateTagNoCache = getJSDocPrivateTagNoCache;
exports.getJSDocProtectedTag = getJSDocProtectedTag;
exports.getJSDocProtectedTagNoCache = getJSDocProtectedTagNoCache;
exports.getJSDocReadonlyTag = getJSDocReadonlyTag;
exports.getJSDocReadonlyTagNoCache = getJSDocReadonlyTagNoCache;
exports.getJSDocOverrideTagNoCache = getJSDocOverrideTagNoCache;
exports.getJSDocDeprecatedTag = getJSDocDeprecatedTag;
exports.getJSDocDeprecatedTagNoCache = getJSDocDeprecatedTagNoCache;
exports.getJSDocEnumTag = getJSDocEnumTag;
exports.getJSDocThisTag = getJSDocThisTag;
exports.getJSDocReturnTag = getJSDocReturnTag;
exports.getJSDocTemplateTag = getJSDocTemplateTag;
exports.getJSDocSatisfiesTag = getJSDocSatisfiesTag;
exports.getJSDocTypeTag = getJSDocTypeTag;
exports.getJSDocType = getJSDocType;
exports.getJSDocReturnType = getJSDocReturnType;
exports.getJSDocTags = getJSDocTags;
exports.getAllJSDocTags = getAllJSDocTags;
exports.getAllJSDocTagsOfKind = getAllJSDocTagsOfKind;
exports.getTextOfJSDocComment = getTextOfJSDocComment;
exports.getEffectiveTypeParameterDeclarations = getEffectiveTypeParameterDeclarations;
exports.getEffectiveConstraintOfTypeParameter = getEffectiveConstraintOfTypeParameter;
exports.isMemberName = isMemberName;
exports.isGetOrSetAccessorDeclaration = isGetOrSetAccessorDeclaration;
exports.isPropertyAccessChain = isPropertyAccessChain;
exports.isElementAccessChain = isElementAccessChain;
exports.isCallChain = isCallChain;
exports.isOptionalChain = isOptionalChain;
exports.isOptionalChainRoot = isOptionalChainRoot;
exports.isExpressionOfOptionalChainRoot = isExpressionOfOptionalChainRoot;
exports.isOutermostOptionalChain = isOutermostOptionalChain;
exports.isNullishCoalesce = isNullishCoalesce;
exports.isConstTypeReference = isConstTypeReference;
exports.skipPartiallyEmittedExpressions = skipPartiallyEmittedExpressions;
exports.isNonNullChain = isNonNullChain;
exports.isBreakOrContinueStatement = isBreakOrContinueStatement;
exports.isNamedExportBindings = isNamedExportBindings;
exports.isJSDocPropertyLikeTag = isJSDocPropertyLikeTag;
exports.isNodeKind = isNodeKind;
exports.isTokenKind = isTokenKind;
exports.isToken = isToken;
exports.isNodeArray = isNodeArray;
exports.isLiteralKind = isLiteralKind;
exports.isLiteralExpression = isLiteralExpression;
exports.isLiteralExpressionOfObject = isLiteralExpressionOfObject;
exports.isTemplateLiteralKind = isTemplateLiteralKind;
exports.isTemplateLiteralToken = isTemplateLiteralToken;
exports.isTemplateMiddleOrTemplateTail = isTemplateMiddleOrTemplateTail;
exports.isImportOrExportSpecifier = isImportOrExportSpecifier;
exports.isTypeOnlyImportDeclaration = isTypeOnlyImportDeclaration;
exports.isTypeOnlyExportDeclaration = isTypeOnlyExportDeclaration;
exports.isTypeOnlyImportOrExportDeclaration = isTypeOnlyImportOrExportDeclaration;
exports.isPartOfTypeOnlyImportOrExportDeclaration = isPartOfTypeOnlyImportOrExportDeclaration;
exports.isStringTextContainingNode = isStringTextContainingNode;
exports.isImportAttributeName = isImportAttributeName;
exports.isGeneratedIdentifier = isGeneratedIdentifier;
exports.isGeneratedPrivateIdentifier = isGeneratedPrivateIdentifier;
exports.isFileLevelReservedGeneratedIdentifier = isFileLevelReservedGeneratedIdentifier;
exports.isPrivateIdentifierClassElementDeclaration = isPrivateIdentifierClassElementDeclaration;
exports.isPrivateIdentifierPropertyAccessExpression = isPrivateIdentifierPropertyAccessExpression;
exports.isModifierKind = isModifierKind;
exports.isParameterPropertyModifier = isParameterPropertyModifier;
exports.isClassMemberModifier = isClassMemberModifier;
exports.isModifier = isModifier;
exports.isEntityName = isEntityName;
exports.isPropertyName = isPropertyName;
exports.isBindingName = isBindingName;
exports.isFunctionLike = isFunctionLike;
exports.isFunctionLikeOrClassStaticBlockDeclaration = isFunctionLikeOrClassStaticBlockDeclaration;
exports.isFunctionLikeDeclaration = isFunctionLikeDeclaration;
exports.isBooleanLiteral = isBooleanLiteral;
exports.isFunctionLikeKind = isFunctionLikeKind;
exports.isFunctionOrModuleBlock = isFunctionOrModuleBlock;
exports.isClassElement = isClassElement;
exports.isClassLike = isClassLike;
exports.isAccessor = isAccessor;
exports.isAutoAccessorPropertyDeclaration = isAutoAccessorPropertyDeclaration;
exports.isClassInstanceProperty = isClassInstanceProperty;
exports.isMethodOrAccessor = isMethodOrAccessor;
exports.isModifierLike = isModifierLike;
exports.isTypeElement = isTypeElement;
exports.isClassOrTypeElement = isClassOrTypeElement;
exports.isObjectLiteralElementLike = isObjectLiteralElementLike;
exports.isTypeNode = isTypeNode;
exports.isFunctionOrConstructorTypeNode = isFunctionOrConstructorTypeNode;
exports.isBindingPattern = isBindingPattern;
exports.isAssignmentPattern = isAssignmentPattern;
exports.isArrayBindingElement = isArrayBindingElement;
exports.isDeclarationBindingElement = isDeclarationBindingElement;
exports.isBindingOrAssignmentElement = isBindingOrAssignmentElement;
exports.isBindingOrAssignmentPattern = isBindingOrAssignmentPattern;
exports.isObjectBindingOrAssignmentPattern = isObjectBindingOrAssignmentPattern;
exports.isObjectBindingOrAssignmentElement = isObjectBindingOrAssignmentElement;
exports.isArrayBindingOrAssignmentPattern = isArrayBindingOrAssignmentPattern;
exports.isArrayBindingOrAssignmentElement = isArrayBindingOrAssignmentElement;
exports.isPropertyAccessOrQualifiedNameOrImportTypeNode = isPropertyAccessOrQualifiedNameOrImportTypeNode;
exports.isPropertyAccessOrQualifiedName = isPropertyAccessOrQualifiedName;
exports.isCallLikeOrFunctionLikeExpression = isCallLikeOrFunctionLikeExpression;
exports.isCallLikeExpression = isCallLikeExpression;
exports.isCallOrNewExpression = isCallOrNewExpression;
exports.isTemplateLiteral = isTemplateLiteral;
exports.isLeftHandSideExpression = isLeftHandSideExpression;
exports.isUnaryExpression = isUnaryExpression;
exports.isUnaryExpressionWithWrite = isUnaryExpressionWithWrite;
exports.isLiteralTypeLiteral = isLiteralTypeLiteral;
exports.isExpression = isExpression;
exports.isAssertionExpression = isAssertionExpression;
exports.isIterationStatement = isIterationStatement;
exports.hasScopeMarker = hasScopeMarker;
exports.needsScopeMarker = needsScopeMarker;
exports.isExternalModuleIndicator = isExternalModuleIndicator;
exports.isForInOrOfStatement = isForInOrOfStatement;
exports.isConciseBody = isConciseBody;
exports.isFunctionBody = isFunctionBody;
exports.isForInitializer = isForInitializer;
exports.isModuleBody = isModuleBody;
exports.isNamespaceBody = isNamespaceBody;
exports.isJSDocNamespaceBody = isJSDocNamespaceBody;
exports.isNamedImportBindings = isNamedImportBindings;
exports.isModuleOrEnumDeclaration = isModuleOrEnumDeclaration;
exports.canHaveSymbol = canHaveSymbol;
exports.canHaveLocals = canHaveLocals;
exports.isDeclaration = isDeclaration;
exports.isDeclarationStatement = isDeclarationStatement;
exports.isStatementButNotDeclaration = isStatementButNotDeclaration;
exports.isStatement = isStatement;
exports.isStatementOrBlock = isStatementOrBlock;
exports.isModuleReference = isModuleReference;
exports.isJsxTagNameExpression = isJsxTagNameExpression;
exports.isJsxChild = isJsxChild;
exports.isJsxAttributeLike = isJsxAttributeLike;
exports.isStringLiteralOrJsxExpression = isStringLiteralOrJsxExpression;
exports.isJsxOpeningLikeElement = isJsxOpeningLikeElement;
exports.isJsxCallLike = isJsxCallLike;
exports.isCaseOrDefaultClause = isCaseOrDefaultClause;
exports.isJSDocNode = isJSDocNode;
exports.isJSDocCommentContainingNode = isJSDocCommentContainingNode;
exports.isJSDocTag = isJSDocTag;
exports.isSetAccessor = isSetAccessor;
exports.isGetAccessor = isGetAccessor;
exports.hasJSDocNodes = hasJSDocNodes;
exports.hasType = hasType;
exports.hasInitializer = hasInitializer;
exports.hasOnlyExpressionInitializer = hasOnlyExpressionInitializer;
exports.isObjectLiteralElement = isObjectLiteralElement;
exports.isTypeReferenceType = isTypeReferenceType;
exports.guessIndentation = guessIndentation;
exports.isStringLiteralLike = isStringLiteralLike;
exports.isJSDocLinkLike = isJSDocLinkLike;
exports.hasRestParameter = hasRestParameter;
exports.isRestParameter = isRestParameter;
exports.isInternalDeclaration = isInternalDeclaration;
const ts_js_1 = require("./_namespaces/ts.js");
function isExternalModuleNameRelative(moduleName) {
    // TypeScript 1.0 spec (April 2014): 11.2.1
    // An external module name is "relative" if the first term is "." or "..".
    // Update: We also consider a path like `C:\foo.ts` "relative" because we do not search for it in `node_modules` or treat it as an ambient module.
    return (0, ts_js_1.pathIsRelative)(moduleName) || (0, ts_js_1.isRootedDiskPath)(moduleName);
}
function sortAndDeduplicateDiagnostics(diagnostics) {
    return (0, ts_js_1.sortAndDeduplicate)(diagnostics, ts_js_1.compareDiagnostics, ts_js_1.diagnosticsEqualityComparer);
}
/** @internal */
// NOTE: We must reevaluate the target for upcoming features when each successive TC39 edition is ratified in
//       June of each year. This includes changes to `LanguageFeatureMinimumTarget`, `ScriptTarget`,
//       `ScriptTargetFeatures`, `CommandLineOptionOfCustomType`, transformers/esnext.ts, compiler/commandLineParser.ts,
//       compiler/utilitiesPublic.ts, and the contents of each lib/esnext.*.d.ts file.
exports.targetToLibMap = new Map([
    [99 /* ScriptTarget.ESNext */, "lib.esnext.full.d.ts"],
    [12 /* ScriptTarget.ES2025 */, "lib.es2025.full.d.ts"],
    [11 /* ScriptTarget.ES2024 */, "lib.es2024.full.d.ts"],
    [10 /* ScriptTarget.ES2023 */, "lib.es2023.full.d.ts"],
    [9 /* ScriptTarget.ES2022 */, "lib.es2022.full.d.ts"],
    [8 /* ScriptTarget.ES2021 */, "lib.es2021.full.d.ts"],
    [7 /* ScriptTarget.ES2020 */, "lib.es2020.full.d.ts"],
    [6 /* ScriptTarget.ES2019 */, "lib.es2019.full.d.ts"],
    [5 /* ScriptTarget.ES2018 */, "lib.es2018.full.d.ts"],
    [4 /* ScriptTarget.ES2017 */, "lib.es2017.full.d.ts"],
    [3 /* ScriptTarget.ES2016 */, "lib.es2016.full.d.ts"],
    [2 /* ScriptTarget.ES2015 */, "lib.es6.d.ts"], // We don't use lib.es2015.full.d.ts due to breaking change.
]);
function getDefaultLibFileName(options) {
    const target = (0, ts_js_1.getEmitScriptTarget)(options);
    switch (target) {
        case 99 /* ScriptTarget.ESNext */:
        case 12 /* ScriptTarget.ES2025 */:
        case 11 /* ScriptTarget.ES2024 */:
        case 10 /* ScriptTarget.ES2023 */:
        case 9 /* ScriptTarget.ES2022 */:
        case 8 /* ScriptTarget.ES2021 */:
        case 7 /* ScriptTarget.ES2020 */:
        case 6 /* ScriptTarget.ES2019 */:
        case 5 /* ScriptTarget.ES2018 */:
        case 4 /* ScriptTarget.ES2017 */:
        case 3 /* ScriptTarget.ES2016 */:
        case 2 /* ScriptTarget.ES2015 */:
            return exports.targetToLibMap.get(target);
        default:
            return "lib.d.ts";
    }
}
function textSpanEnd(span) {
    return span.start + span.length;
}
function textSpanIsEmpty(span) {
    return span.length === 0;
}
function textSpanContainsPosition(span, position) {
    return position >= span.start && position < textSpanEnd(span);
}
/** @internal */
function textRangeContainsPositionInclusive(range, position) {
    return position >= range.pos && position <= range.end;
}
// Returns true if 'span' contains 'other'.
function textSpanContainsTextSpan(span, other) {
    return other.start >= span.start && textSpanEnd(other) <= textSpanEnd(span);
}
/** @internal */
function textSpanContainsTextRange(span, range) {
    return range.pos >= span.start && range.end <= textSpanEnd(span);
}
/** @internal */
function textRangeContainsTextSpan(range, span) {
    return span.start >= range.pos && textSpanEnd(span) <= range.end;
}
function textSpanOverlapsWith(span, other) {
    return textSpanOverlap(span, other) !== undefined;
}
function textSpanOverlap(span1, span2) {
    const overlap = textSpanIntersection(span1, span2);
    return overlap && overlap.length === 0 ? undefined : overlap;
}
function textSpanIntersectsWithTextSpan(span, other) {
    return decodedTextSpanIntersectsWith(span.start, span.length, other.start, other.length);
}
function textSpanIntersectsWith(span, start, length) {
    return decodedTextSpanIntersectsWith(span.start, span.length, start, length);
}
function decodedTextSpanIntersectsWith(start1, length1, start2, length2) {
    const end1 = start1 + length1;
    const end2 = start2 + length2;
    return start2 <= end1 && end2 >= start1;
}
function textSpanIntersectsWithPosition(span, position) {
    return position <= textSpanEnd(span) && position >= span.start;
}
/** @internal */
function textRangeIntersectsWithTextSpan(range, span) {
    return textSpanIntersectsWith(span, range.pos, range.end - range.pos);
}
function textSpanIntersection(span1, span2) {
    const start = Math.max(span1.start, span2.start);
    const end = Math.min(textSpanEnd(span1), textSpanEnd(span2));
    return start <= end ? createTextSpanFromBounds(start, end) : undefined;
}
/**
 * Given an array of text spans, returns an equivalent sorted array of text spans
 * where no span overlaps or is adjacent to another span in the array.
 * @internal
 */
function normalizeSpans(spans) {
    spans = spans.filter(span => span.length > 0).sort((a, b) => {
        return a.start !== b.start ? a.start - b.start : a.length - b.length;
    });
    const result = [];
    let i = 0;
    while (i < spans.length) {
        let span = spans[i];
        let j = i + 1;
        while (j < spans.length && textSpanIntersectsWithTextSpan(span, spans[j])) {
            const start = Math.min(span.start, spans[j].start);
            const end = Math.max(textSpanEnd(span), textSpanEnd(spans[j]));
            span = createTextSpanFromBounds(start, end);
            j++;
        }
        i = j;
        result.push(span);
    }
    return result;
}
function createTextSpan(start, length) {
    if (start < 0) {
        throw new Error("start < 0");
    }
    if (length < 0) {
        throw new Error("length < 0");
    }
    return { start, length };
}
function createTextSpanFromBounds(start, end) {
    return createTextSpan(start, end - start);
}
function textChangeRangeNewSpan(range) {
    return createTextSpan(range.span.start, range.newLength);
}
function textChangeRangeIsUnchanged(range) {
    return textSpanIsEmpty(range.span) && range.newLength === 0;
}
function createTextChangeRange(span, newLength) {
    if (newLength < 0) {
        throw new Error("newLength < 0");
    }
    return { span, newLength };
}
exports.unchangedTextChangeRange = createTextChangeRange(createTextSpan(0, 0), 0);
/**
 * Called to merge all the changes that occurred across several versions of a script snapshot
 * into a single change.  i.e. if a user keeps making successive edits to a script we will
 * have a text change from V1 to V2, V2 to V3, ..., Vn.
 *
 * This function will then merge those changes into a single change range valid between V1 and
 * Vn.
 */
function collapseTextChangeRangesAcrossMultipleVersions(changes) {
    if (changes.length === 0) {
        return exports.unchangedTextChangeRange;
    }
    if (changes.length === 1) {
        return changes[0];
    }
    // We change from talking about { { oldStart, oldLength }, newLength } to { oldStart, oldEnd, newEnd }
    // as it makes things much easier to reason about.
    const change0 = changes[0];
    let oldStartN = change0.span.start;
    let oldEndN = textSpanEnd(change0.span);
    let newEndN = oldStartN + change0.newLength;
    for (let i = 1; i < changes.length; i++) {
        const nextChange = changes[i];
        // Consider the following case:
        // i.e. two edits.  The first represents the text change range { { 10, 50 }, 30 }.  i.e. The span starting
        // at 10, with length 50 is reduced to length 30.  The second represents the text change range { { 30, 30 }, 40 }.
        // i.e. the span starting at 30 with length 30 is increased to length 40.
        //
        //      0         10        20        30        40        50        60        70        80        90        100
        //      -------------------------------------------------------------------------------------------------------
        //                |                                                 /
        //                |                                            /----
        //  T1            |                                       /----
        //                |                                  /----
        //                |                             /----
        //      -------------------------------------------------------------------------------------------------------
        //                                     |                            \
        //                                     |                               \
        //   T2                                |                                 \
        //                                     |                                   \
        //                                     |                                      \
        //      -------------------------------------------------------------------------------------------------------
        //
        // Merging these turns out to not be too difficult.  First, determining the new start of the change is trivial
        // it's just the min of the old and new starts.  i.e.:
        //
        //      0         10        20        30        40        50        60        70        80        90        100
        //      ------------------------------------------------------------*------------------------------------------
        //                |                                                 /
        //                |                                            /----
        //  T1            |                                       /----
        //                |                                  /----
        //                |                             /----
        //      ----------------------------------------$-------------------$------------------------------------------
        //                .                    |                            \
        //                .                    |                               \
        //   T2           .                    |                                 \
        //                .                    |                                   \
        //                .                    |                                      \
        //      ----------------------------------------------------------------------*--------------------------------
        //
        // (Note the dots represent the newly inferred start.
        // Determining the new and old end is also pretty simple.  Basically it boils down to paying attention to the
        // absolute positions at the asterisks, and the relative change between the dollar signs. Basically, we see
        // which if the two $'s precedes the other, and we move that one forward until they line up.  in this case that
        // means:
        //
        //      0         10        20        30        40        50        60        70        80        90        100
        //      --------------------------------------------------------------------------------*----------------------
        //                |                                                                     /
        //                |                                                                /----
        //  T1            |                                                           /----
        //                |                                                      /----
        //                |                                                 /----
        //      ------------------------------------------------------------$------------------------------------------
        //                .                    |                            \
        //                .                    |                               \
        //   T2           .                    |                                 \
        //                .                    |                                   \
        //                .                    |                                      \
        //      ----------------------------------------------------------------------*--------------------------------
        //
        // In other words (in this case), we're recognizing that the second edit happened after where the first edit
        // ended with a delta of 20 characters (60 - 40).  Thus, if we go back in time to where the first edit started
        // that's the same as if we started at char 80 instead of 60.
        //
        // As it so happens, the same logic applies if the second edit precedes the first edit.  In that case rather
        // than pushing the first edit forward to match the second, we'll push the second edit forward to match the
        // first.
        //
        // In this case that means we have { oldStart: 10, oldEnd: 80, newEnd: 70 } or, in TextChangeRange
        // semantics: { { start: 10, length: 70 }, newLength: 60 }
        //
        // The math then works out as follows.
        // If we have { oldStart1, oldEnd1, newEnd1 } and { oldStart2, oldEnd2, newEnd2 } then we can compute the
        // final result like so:
        //
        // {
        //      oldStart3: Min(oldStart1, oldStart2),
        //      oldEnd3: Max(oldEnd1, oldEnd1 + (oldEnd2 - newEnd1)),
        //      newEnd3: Max(newEnd2, newEnd2 + (newEnd1 - oldEnd2))
        // }
        const oldStart1 = oldStartN;
        const oldEnd1 = oldEndN;
        const newEnd1 = newEndN;
        const oldStart2 = nextChange.span.start;
        const oldEnd2 = textSpanEnd(nextChange.span);
        const newEnd2 = oldStart2 + nextChange.newLength;
        oldStartN = Math.min(oldStart1, oldStart2);
        oldEndN = Math.max(oldEnd1, oldEnd1 + (oldEnd2 - newEnd1));
        newEndN = Math.max(newEnd2, newEnd2 + (newEnd1 - oldEnd2));
    }
    return createTextChangeRange(createTextSpanFromBounds(oldStartN, oldEndN), /*newLength*/ newEndN - oldStartN);
}
function getTypeParameterOwner(d) {
    if (d && d.kind === 169 /* SyntaxKind.TypeParameter */) {
        for (let current = d; current; current = current.parent) {
            if (isFunctionLike(current) || isClassLike(current) || current.kind === 265 /* SyntaxKind.InterfaceDeclaration */) {
                return current;
            }
        }
    }
}
function isParameterPropertyDeclaration(node, parent) {
    return (0, ts_js_1.isParameter)(node) && (0, ts_js_1.hasSyntacticModifier)(node, 31 /* ModifierFlags.ParameterPropertyModifier */) && parent.kind === 177 /* SyntaxKind.Constructor */;
}
function isEmptyBindingPattern(node) {
    if (isBindingPattern(node)) {
        return (0, ts_js_1.every)(node.elements, isEmptyBindingElement);
    }
    return false;
}
// TODO(jakebailey): It is very weird that we have BindingElement and ArrayBindingElement;
// we should have ObjectBindingElement and ArrayBindingElement, which are both BindingElement,
// just like BindingPattern is a ObjectBindingPattern or a ArrayBindingPattern.
function isEmptyBindingElement(node) {
    if ((0, ts_js_1.isOmittedExpression)(node)) {
        return true;
    }
    return isEmptyBindingPattern(node.name);
}
function walkUpBindingElementsAndPatterns(binding) {
    let node = binding.parent;
    while ((0, ts_js_1.isBindingElement)(node.parent)) {
        node = node.parent.parent;
    }
    return node.parent;
}
function getCombinedFlags(node, getFlags) {
    if ((0, ts_js_1.isBindingElement)(node)) {
        node = walkUpBindingElementsAndPatterns(node);
    }
    let flags = getFlags(node);
    if (node.kind === 261 /* SyntaxKind.VariableDeclaration */) {
        node = node.parent;
    }
    if (node && node.kind === 262 /* SyntaxKind.VariableDeclarationList */) {
        flags |= getFlags(node);
        node = node.parent;
    }
    if (node && node.kind === 244 /* SyntaxKind.VariableStatement */) {
        flags |= getFlags(node);
    }
    return flags;
}
function getCombinedModifierFlags(node) {
    return getCombinedFlags(node, ts_js_1.getEffectiveModifierFlags);
}
/** @internal */
function getCombinedNodeFlagsAlwaysIncludeJSDoc(node) {
    return getCombinedFlags(node, ts_js_1.getEffectiveModifierFlagsAlwaysIncludeJSDoc);
}
// Returns the node flags for this node and all relevant parent nodes.  This is done so that
// nodes like variable declarations and binding elements can returned a view of their flags
// that includes the modifiers from their container.  i.e. flags like export/declare aren't
// stored on the variable declaration directly, but on the containing variable statement
// (if it has one).  Similarly, flags for let/const are stored on the variable declaration
// list.  By calling this function, all those flags are combined so that the client can treat
// the node as if it actually had those flags.
function getCombinedNodeFlags(node) {
    return getCombinedFlags(node, getNodeFlags);
}
function getNodeFlags(node) {
    return node.flags;
}
/** @internal */
exports.supportedLocaleDirectories = ["cs", "de", "es", "fr", "it", "ja", "ko", "pl", "pt-br", "ru", "tr", "zh-cn", "zh-tw"];
/**
 * Checks to see if the locale is in the appropriate format,
 * and if it is, attempts to set the appropriate language.
 */
function validateLocaleAndSetLanguage(locale, sys, errors) {
    const lowerCaseLocale = locale.toLowerCase();
    const matchResult = /^([a-z]+)(?:[_-]([a-z]+))?$/.exec(lowerCaseLocale);
    if (!matchResult) {
        if (errors) {
            errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Locale_must_be_of_the_form_language_or_language_territory_For_example_0_or_1, "en", "ja-jp"));
        }
        return;
    }
    const language = matchResult[1];
    const territory = matchResult[2];
    // First try the entire locale, then fall back to just language if that's all we have.
    // Either ways do not fail, and fallback to the English diagnostic strings.
    if ((0, ts_js_1.contains)(exports.supportedLocaleDirectories, lowerCaseLocale) && !trySetLanguageAndTerritory(language, territory, errors)) {
        trySetLanguageAndTerritory(language, /*territory*/ undefined, errors);
    }
    // Set the UI locale for string collation
    (0, ts_js_1.setUILocale)(locale);
    function trySetLanguageAndTerritory(language, territory, errors) {
        const compilerFilePath = (0, ts_js_1.normalizePath)(sys.getExecutingFilePath());
        const containingDirectoryPath = (0, ts_js_1.getDirectoryPath)(compilerFilePath);
        let filePath = (0, ts_js_1.combinePaths)(containingDirectoryPath, language);
        if (territory) {
            filePath = filePath + "-" + territory;
        }
        filePath = sys.resolvePath((0, ts_js_1.combinePaths)(filePath, "diagnosticMessages.generated.json"));
        if (!sys.fileExists(filePath)) {
            return false;
        }
        // TODO: Add codePage support for readFile?
        let fileContents = "";
        try {
            fileContents = sys.readFile(filePath);
        }
        catch {
            if (errors) {
                errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Unable_to_open_file_0, filePath));
            }
            return false;
        }
        try {
            // this is a global mutation (or live binding update)!
            (0, ts_js_1.setLocalizedDiagnosticMessages)(JSON.parse(fileContents));
        }
        catch {
            if (errors) {
                errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Corrupted_locale_file_0, filePath));
            }
            return false;
        }
        return true;
    }
}
function getOriginalNode(node, nodeTest) {
    if (node) {
        while (node.original !== undefined) {
            node = node.original;
        }
    }
    if (!node || !nodeTest) {
        return node;
    }
    return nodeTest(node) ? node : undefined;
}
function findAncestor(node, callback) {
    while (node) {
        const result = callback(node);
        if (result === "quit") {
            return undefined;
        }
        else if (result) {
            return node;
        }
        node = node.parent;
    }
    return undefined;
}
/**
 * Gets a value indicating whether a node originated in the parse tree.
 *
 * @param node The node to test.
 */
function isParseTreeNode(node) {
    return (node.flags & 16 /* NodeFlags.Synthesized */) === 0;
}
function getParseTreeNode(node, nodeTest) {
    if (node === undefined || isParseTreeNode(node)) {
        return node;
    }
    node = node.original;
    while (node) {
        if (isParseTreeNode(node)) {
            return !nodeTest || nodeTest(node) ? node : undefined;
        }
        node = node.original;
    }
}
/** Add an extra underscore to identifiers that start with two underscores to avoid issues with magic names like '__proto__' */
function escapeLeadingUnderscores(identifier) {
    return (identifier.length >= 2 && identifier.charCodeAt(0) === 95 /* CharacterCodes._ */ && identifier.charCodeAt(1) === 95 /* CharacterCodes._ */ ? "_" + identifier : identifier);
}
/**
 * Remove extra underscore from escaped identifier text content.
 *
 * @param identifier The escaped identifier text.
 * @returns The unescaped identifier text.
 */
function unescapeLeadingUnderscores(identifier) {
    const id = identifier;
    return id.length >= 3 && id.charCodeAt(0) === 95 /* CharacterCodes._ */ && id.charCodeAt(1) === 95 /* CharacterCodes._ */ && id.charCodeAt(2) === 95 /* CharacterCodes._ */ ? id.substr(1) : id;
}
function idText(identifierOrPrivateName) {
    return unescapeLeadingUnderscores(identifierOrPrivateName.escapedText);
}
/**
 * If the text of an Identifier matches a keyword (including contextual and TypeScript-specific keywords), returns the
 * SyntaxKind for the matching keyword.
 */
function identifierToKeywordKind(node) {
    const token = (0, ts_js_1.stringToToken)(node.escapedText);
    return token ? (0, ts_js_1.tryCast)(token, ts_js_1.isKeyword) : undefined;
}
function symbolName(symbol) {
    if (symbol.valueDeclaration && isPrivateIdentifierClassElementDeclaration(symbol.valueDeclaration)) {
        return idText(symbol.valueDeclaration.name);
    }
    return unescapeLeadingUnderscores(symbol.escapedName);
}
/**
 * A JSDocTypedef tag has an _optional_ name field - if a name is not directly present, we should
 * attempt to draw the name from the node the declaration is on (as that declaration is what its' symbol
 * will be merged with)
 */
function nameForNamelessJSDocTypedef(declaration) {
    const hostNode = declaration.parent.parent;
    if (!hostNode) {
        return undefined;
    }
    // Covers classes, functions - any named declaration host node
    if (isDeclaration(hostNode)) {
        return getDeclarationIdentifier(hostNode);
    }
    // Covers remaining cases (returning undefined if none match).
    switch (hostNode.kind) {
        case 244 /* SyntaxKind.VariableStatement */:
            if (hostNode.declarationList && hostNode.declarationList.declarations[0]) {
                return getDeclarationIdentifier(hostNode.declarationList.declarations[0]);
            }
            break;
        case 245 /* SyntaxKind.ExpressionStatement */:
            let expr = hostNode.expression;
            if (expr.kind === 227 /* SyntaxKind.BinaryExpression */ && expr.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */) {
                expr = expr.left;
            }
            switch (expr.kind) {
                case 212 /* SyntaxKind.PropertyAccessExpression */:
                    return expr.name;
                case 213 /* SyntaxKind.ElementAccessExpression */:
                    const arg = expr.argumentExpression;
                    if ((0, ts_js_1.isIdentifier)(arg)) {
                        return arg;
                    }
            }
            break;
        case 218 /* SyntaxKind.ParenthesizedExpression */: {
            return getDeclarationIdentifier(hostNode.expression);
        }
        case 257 /* SyntaxKind.LabeledStatement */: {
            if (isDeclaration(hostNode.statement) || isExpression(hostNode.statement)) {
                return getDeclarationIdentifier(hostNode.statement);
            }
            break;
        }
    }
}
function getDeclarationIdentifier(node) {
    const name = getNameOfDeclaration(node);
    return name && (0, ts_js_1.isIdentifier)(name) ? name : undefined;
}
/** @internal */
function nodeHasName(statement, name) {
    if (isNamedDeclaration(statement) && (0, ts_js_1.isIdentifier)(statement.name) && idText(statement.name) === idText(name)) {
        return true;
    }
    if ((0, ts_js_1.isVariableStatement)(statement) && (0, ts_js_1.some)(statement.declarationList.declarations, d => nodeHasName(d, name))) {
        return true;
    }
    return false;
}
function getNameOfJSDocTypedef(declaration) {
    return declaration.name || nameForNamelessJSDocTypedef(declaration);
}
/** @internal */
function isNamedDeclaration(node) {
    return !!node.name; // A 'name' property should always be a DeclarationName.
}
/** @internal */
function getNonAssignedNameOfDeclaration(declaration) {
    switch (declaration.kind) {
        case 80 /* SyntaxKind.Identifier */:
            return declaration;
        case 349 /* SyntaxKind.JSDocPropertyTag */:
        case 342 /* SyntaxKind.JSDocParameterTag */: {
            const { name } = declaration;
            if (name.kind === 167 /* SyntaxKind.QualifiedName */) {
                return name.right;
            }
            break;
        }
        case 214 /* SyntaxKind.CallExpression */:
        case 227 /* SyntaxKind.BinaryExpression */: {
            const expr = declaration;
            switch ((0, ts_js_1.getAssignmentDeclarationKind)(expr)) {
                case 1 /* AssignmentDeclarationKind.ExportsProperty */:
                case 4 /* AssignmentDeclarationKind.ThisProperty */:
                case 5 /* AssignmentDeclarationKind.Property */:
                case 3 /* AssignmentDeclarationKind.PrototypeProperty */:
                    return (0, ts_js_1.getElementOrPropertyAccessArgumentExpressionOrName)(expr.left);
                case 7 /* AssignmentDeclarationKind.ObjectDefinePropertyValue */:
                case 8 /* AssignmentDeclarationKind.ObjectDefinePropertyExports */:
                case 9 /* AssignmentDeclarationKind.ObjectDefinePrototypeProperty */:
                    return expr.arguments[1];
                default:
                    return undefined;
            }
        }
        case 347 /* SyntaxKind.JSDocTypedefTag */:
            return getNameOfJSDocTypedef(declaration);
        case 341 /* SyntaxKind.JSDocEnumTag */:
            return nameForNamelessJSDocTypedef(declaration);
        case 278 /* SyntaxKind.ExportAssignment */: {
            const { expression } = declaration;
            return (0, ts_js_1.isIdentifier)(expression) ? expression : undefined;
        }
        case 213 /* SyntaxKind.ElementAccessExpression */:
            const expr = declaration;
            if ((0, ts_js_1.isBindableStaticElementAccessExpression)(expr)) {
                return expr.argumentExpression;
            }
    }
    return declaration.name;
}
function getNameOfDeclaration(declaration) {
    if (declaration === undefined)
        return undefined;
    return getNonAssignedNameOfDeclaration(declaration) ||
        ((0, ts_js_1.isFunctionExpression)(declaration) || (0, ts_js_1.isArrowFunction)(declaration) || (0, ts_js_1.isClassExpression)(declaration) ? getAssignedName(declaration) : undefined);
}
/** @internal */
function getAssignedName(node) {
    if (!node.parent) {
        return undefined;
    }
    else if ((0, ts_js_1.isPropertyAssignment)(node.parent) || (0, ts_js_1.isBindingElement)(node.parent)) {
        return node.parent.name;
    }
    else if ((0, ts_js_1.isBinaryExpression)(node.parent) && node === node.parent.right) {
        if ((0, ts_js_1.isIdentifier)(node.parent.left)) {
            return node.parent.left;
        }
        else if ((0, ts_js_1.isAccessExpression)(node.parent.left)) {
            return (0, ts_js_1.getElementOrPropertyAccessArgumentExpressionOrName)(node.parent.left);
        }
    }
    else if ((0, ts_js_1.isVariableDeclaration)(node.parent) && (0, ts_js_1.isIdentifier)(node.parent.name)) {
        return node.parent.name;
    }
}
function getDecorators(node) {
    if ((0, ts_js_1.hasDecorators)(node)) {
        return (0, ts_js_1.filter)(node.modifiers, ts_js_1.isDecorator);
    }
}
function getModifiers(node) {
    if ((0, ts_js_1.hasSyntacticModifier)(node, 98303 /* ModifierFlags.Modifier */)) {
        return (0, ts_js_1.filter)(node.modifiers, isModifier);
    }
}
function getJSDocParameterTagsWorker(param, noCache) {
    if (param.name) {
        if ((0, ts_js_1.isIdentifier)(param.name)) {
            const name = param.name.escapedText;
            return getJSDocTagsWorker(param.parent, noCache).filter((tag) => (0, ts_js_1.isJSDocParameterTag)(tag) && (0, ts_js_1.isIdentifier)(tag.name) && tag.name.escapedText === name);
        }
        else {
            const i = param.parent.parameters.indexOf(param);
            ts_js_1.Debug.assert(i > -1, "Parameters should always be in their parents' parameter list");
            const paramTags = getJSDocTagsWorker(param.parent, noCache).filter(ts_js_1.isJSDocParameterTag);
            if (i < paramTags.length) {
                return [paramTags[i]];
            }
        }
    }
    // return empty array for: out-of-order binding patterns and JSDoc function syntax, which has un-named parameters
    return ts_js_1.emptyArray;
}
/**
 * Gets the JSDoc parameter tags for the node if present.
 *
 * @remarks Returns any JSDoc param tag whose name matches the provided
 * parameter, whether a param tag on a containing function
 * expression, or a param tag on a variable declaration whose
 * initializer is the containing function. The tags closest to the
 * node are returned first, so in the previous example, the param
 * tag on the containing function expression would be first.
 *
 * For binding patterns, parameter tags are matched by position.
 */
function getJSDocParameterTags(param) {
    return getJSDocParameterTagsWorker(param, /*noCache*/ false);
}
/** @internal */
function getJSDocParameterTagsNoCache(param) {
    return getJSDocParameterTagsWorker(param, /*noCache*/ true);
}
function getJSDocTypeParameterTagsWorker(param, noCache) {
    const name = param.name.escapedText;
    return getJSDocTagsWorker(param.parent, noCache).filter((tag) => (0, ts_js_1.isJSDocTemplateTag)(tag) && tag.typeParameters.some(tp => tp.name.escapedText === name));
}
/**
 * Gets the JSDoc type parameter tags for the node if present.
 *
 * @remarks Returns any JSDoc template tag whose names match the provided
 * parameter, whether a template tag on a containing function
 * expression, or a template tag on a variable declaration whose
 * initializer is the containing function. The tags closest to the
 * node are returned first, so in the previous example, the template
 * tag on the containing function expression would be first.
 */
function getJSDocTypeParameterTags(param) {
    return getJSDocTypeParameterTagsWorker(param, /*noCache*/ false);
}
/** @internal */
function getJSDocTypeParameterTagsNoCache(param) {
    return getJSDocTypeParameterTagsWorker(param, /*noCache*/ true);
}
/**
 * Return true if the node has JSDoc parameter tags.
 *
 * @remarks Includes parameter tags that are not directly on the node,
 * for example on a variable declaration whose initializer is a function expression.
 */
function hasJSDocParameterTags(node) {
    return !!getFirstJSDocTag(node, ts_js_1.isJSDocParameterTag);
}
/** Gets the JSDoc augments tag for the node if present */
function getJSDocAugmentsTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocAugmentsTag);
}
/** Gets the JSDoc implements tags for the node if present */
function getJSDocImplementsTags(node) {
    return getAllJSDocTags(node, ts_js_1.isJSDocImplementsTag);
}
/** Gets the JSDoc class tag for the node if present */
function getJSDocClassTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocClassTag);
}
/** Gets the JSDoc public tag for the node if present */
function getJSDocPublicTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocPublicTag);
}
/** @internal */
function getJSDocPublicTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocPublicTag, /*noCache*/ true);
}
/** Gets the JSDoc private tag for the node if present */
function getJSDocPrivateTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocPrivateTag);
}
/** @internal */
function getJSDocPrivateTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocPrivateTag, /*noCache*/ true);
}
/** Gets the JSDoc protected tag for the node if present */
function getJSDocProtectedTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocProtectedTag);
}
/** @internal */
function getJSDocProtectedTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocProtectedTag, /*noCache*/ true);
}
/** Gets the JSDoc protected tag for the node if present */
function getJSDocReadonlyTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocReadonlyTag);
}
/** @internal */
function getJSDocReadonlyTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocReadonlyTag, /*noCache*/ true);
}
function getJSDocOverrideTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocOverrideTag, /*noCache*/ true);
}
/** Gets the JSDoc deprecated tag for the node if present */
function getJSDocDeprecatedTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocDeprecatedTag);
}
/** @internal */
function getJSDocDeprecatedTagNoCache(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocDeprecatedTag, /*noCache*/ true);
}
/** Gets the JSDoc enum tag for the node if present */
function getJSDocEnumTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocEnumTag);
}
/** Gets the JSDoc this tag for the node if present */
function getJSDocThisTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocThisTag);
}
/** Gets the JSDoc return tag for the node if present */
function getJSDocReturnTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocReturnTag);
}
/** Gets the JSDoc template tag for the node if present */
function getJSDocTemplateTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocTemplateTag);
}
function getJSDocSatisfiesTag(node) {
    return getFirstJSDocTag(node, ts_js_1.isJSDocSatisfiesTag);
}
/** Gets the JSDoc type tag for the node if present and valid */
function getJSDocTypeTag(node) {
    // We should have already issued an error if there were multiple type jsdocs, so just use the first one.
    const tag = getFirstJSDocTag(node, ts_js_1.isJSDocTypeTag);
    if (tag && tag.typeExpression && tag.typeExpression.type) {
        return tag;
    }
    return undefined;
}
/**
 * Gets the type node for the node if provided via JSDoc.
 *
 * @remarks The search includes any JSDoc param tag that relates
 * to the provided parameter, for example a type tag on the
 * parameter itself, or a param tag on a containing function
 * expression, or a param tag on a variable declaration whose
 * initializer is the containing function. The tags closest to the
 * node are examined first, so in the previous example, the type
 * tag directly on the node would be returned.
 */
function getJSDocType(node) {
    let tag = getFirstJSDocTag(node, ts_js_1.isJSDocTypeTag);
    if (!tag && (0, ts_js_1.isParameter)(node)) {
        tag = (0, ts_js_1.find)(getJSDocParameterTags(node), tag => !!tag.typeExpression);
    }
    return tag && tag.typeExpression && tag.typeExpression.type;
}
/**
 * Gets the return type node for the node if provided via JSDoc return tag or type tag.
 *
 * @remarks `getJSDocReturnTag` just gets the whole JSDoc tag. This function
 * gets the type from inside the braces, after the fat arrow, etc.
 */
function getJSDocReturnType(node) {
    const returnTag = getJSDocReturnTag(node);
    if (returnTag && returnTag.typeExpression) {
        return returnTag.typeExpression.type;
    }
    const typeTag = getJSDocTypeTag(node);
    if (typeTag && typeTag.typeExpression) {
        const type = typeTag.typeExpression.type;
        if ((0, ts_js_1.isTypeLiteralNode)(type)) {
            const sig = (0, ts_js_1.find)(type.members, ts_js_1.isCallSignatureDeclaration);
            return sig && sig.type;
        }
        if ((0, ts_js_1.isFunctionTypeNode)(type) || (0, ts_js_1.isJSDocFunctionType)(type)) {
            return type.type;
        }
    }
}
function getJSDocTagsWorker(node, noCache) {
    if (!(0, ts_js_1.canHaveJSDoc)(node))
        return ts_js_1.emptyArray;
    let tags = node.jsDoc?.jsDocCache;
    // If cache is 'null', that means we did the work of searching for JSDoc tags and came up with nothing.
    if (tags === undefined || noCache) {
        const comments = (0, ts_js_1.getJSDocCommentsAndTags)(node, noCache);
        ts_js_1.Debug.assert(comments.length < 2 || comments[0] !== comments[1]);
        tags = (0, ts_js_1.flatMap)(comments, j => (0, ts_js_1.isJSDoc)(j) ? j.tags : j);
        if (!noCache) {
            node.jsDoc ?? (node.jsDoc = []);
            node.jsDoc.jsDocCache = tags;
        }
    }
    return tags;
}
/** Get all JSDoc tags related to a node, including those on parent nodes. */
function getJSDocTags(node) {
    return getJSDocTagsWorker(node, /*noCache*/ false);
}
/** Get the first JSDoc tag of a specified kind, or undefined if not present. */
function getFirstJSDocTag(node, predicate, noCache) {
    return (0, ts_js_1.find)(getJSDocTagsWorker(node, noCache), predicate);
}
/** Gets all JSDoc tags that match a specified predicate */
function getAllJSDocTags(node, predicate) {
    return getJSDocTags(node).filter(predicate);
}
/** Gets all JSDoc tags of a specified kind */
function getAllJSDocTagsOfKind(node, kind) {
    return getJSDocTags(node).filter(doc => doc.kind === kind);
}
/** Gets the text of a jsdoc comment, flattening links to their text. */
function getTextOfJSDocComment(comment) {
    return typeof comment === "string" ? comment
        : comment?.map(c => c.kind === 322 /* SyntaxKind.JSDocText */ ? c.text : formatJSDocLink(c)).join("");
}
function formatJSDocLink(link) {
    const kind = link.kind === 325 /* SyntaxKind.JSDocLink */ ? "link"
        : link.kind === 326 /* SyntaxKind.JSDocLinkCode */ ? "linkcode"
            : "linkplain";
    const name = link.name ? (0, ts_js_1.entityNameToString)(link.name) : "";
    const space = link.name && (link.text === "" || link.text.startsWith("://")) ? "" : " ";
    return `{@${kind} ${name}${space}${link.text}}`;
}
/**
 * Gets the effective type parameters. If the node was parsed in a
 * JavaScript file, gets the type parameters from the `@template` tag from JSDoc.
 *
 * This does *not* return type parameters from a jsdoc reference to a generic type, eg
 *
 * type Id = <T>(x: T) => T
 * /** @type {Id} /
 * function id(x) { return x }
 */
function getEffectiveTypeParameterDeclarations(node) {
    if ((0, ts_js_1.isJSDocSignature)(node)) {
        if ((0, ts_js_1.isJSDocOverloadTag)(node.parent)) {
            const jsDoc = (0, ts_js_1.getJSDocRoot)(node.parent);
            if (jsDoc && (0, ts_js_1.length)(jsDoc.tags)) {
                return (0, ts_js_1.flatMap)(jsDoc.tags, tag => (0, ts_js_1.isJSDocTemplateTag)(tag) ? tag.typeParameters : undefined);
            }
        }
        return ts_js_1.emptyArray;
    }
    if ((0, ts_js_1.isJSDocTypeAlias)(node)) {
        ts_js_1.Debug.assert(node.parent.kind === 321 /* SyntaxKind.JSDoc */);
        return (0, ts_js_1.flatMap)(node.parent.tags, tag => (0, ts_js_1.isJSDocTemplateTag)(tag) ? tag.typeParameters : undefined);
    }
    if (node.typeParameters) {
        return node.typeParameters;
    }
    if ((0, ts_js_1.canHaveIllegalTypeParameters)(node) && node.typeParameters) {
        return node.typeParameters;
    }
    if ((0, ts_js_1.isInJSFile)(node)) {
        const decls = (0, ts_js_1.getJSDocTypeParameterDeclarations)(node);
        if (decls.length) {
            return decls;
        }
        const typeTag = getJSDocType(node);
        if (typeTag && (0, ts_js_1.isFunctionTypeNode)(typeTag) && typeTag.typeParameters) {
            return typeTag.typeParameters;
        }
    }
    return ts_js_1.emptyArray;
}
function getEffectiveConstraintOfTypeParameter(node) {
    return node.constraint ? node.constraint :
        (0, ts_js_1.isJSDocTemplateTag)(node.parent) && node === node.parent.typeParameters[0] ? node.parent.constraint :
            undefined;
}
// #region
function isMemberName(node) {
    return node.kind === 80 /* SyntaxKind.Identifier */ || node.kind === 81 /* SyntaxKind.PrivateIdentifier */;
}
/** @internal */
function isGetOrSetAccessorDeclaration(node) {
    return node.kind === 179 /* SyntaxKind.SetAccessor */ || node.kind === 178 /* SyntaxKind.GetAccessor */;
}
function isPropertyAccessChain(node) {
    return (0, ts_js_1.isPropertyAccessExpression)(node) && !!(node.flags & 64 /* NodeFlags.OptionalChain */);
}
function isElementAccessChain(node) {
    return (0, ts_js_1.isElementAccessExpression)(node) && !!(node.flags & 64 /* NodeFlags.OptionalChain */);
}
function isCallChain(node) {
    return (0, ts_js_1.isCallExpression)(node) && !!(node.flags & 64 /* NodeFlags.OptionalChain */);
}
function isOptionalChain(node) {
    const kind = node.kind;
    return !!(node.flags & 64 /* NodeFlags.OptionalChain */) &&
        (kind === 212 /* SyntaxKind.PropertyAccessExpression */
            || kind === 213 /* SyntaxKind.ElementAccessExpression */
            || kind === 214 /* SyntaxKind.CallExpression */
            || kind === 236 /* SyntaxKind.NonNullExpression */);
}
/** @internal */
function isOptionalChainRoot(node) {
    return isOptionalChain(node) && !(0, ts_js_1.isNonNullExpression)(node) && !!node.questionDotToken;
}
/**
 * Determines whether a node is the expression preceding an optional chain (i.e. `a` in `a?.b`).
 *
 * @internal
 */
function isExpressionOfOptionalChainRoot(node) {
    return isOptionalChainRoot(node.parent) && node.parent.expression === node;
}
/**
 * Determines whether a node is the outermost `OptionalChain` in an ECMAScript `OptionalExpression`:
 *
 * 1. For `a?.b.c`, the outermost chain is `a?.b.c` (`c` is the end of the chain starting at `a?.`)
 * 2. For `a?.b!`, the outermost chain is `a?.b` (`b` is the end of the chain starting at `a?.`)
 * 3. For `(a?.b.c).d`, the outermost chain is `a?.b.c` (`c` is the end of the chain starting at `a?.` since parens end the chain)
 * 4. For `a?.b.c?.d`, both `a?.b.c` and `a?.b.c?.d` are outermost (`c` is the end of the chain starting at `a?.`, and `d` is
 *   the end of the chain starting at `c?.`)
 * 5. For `a?.(b?.c).d`, both `b?.c` and `a?.(b?.c)d` are outermost (`c` is the end of the chain starting at `b`, and `d` is
 *   the end of the chain starting at `a?.`)
 *
 * @internal
 */
function isOutermostOptionalChain(node) {
    return !isOptionalChain(node.parent) // cases 1, 2, and 3
        || isOptionalChainRoot(node.parent) // case 4
        || node !== node.parent.expression; // case 5
}
function isNullishCoalesce(node) {
    return node.kind === 227 /* SyntaxKind.BinaryExpression */ && node.operatorToken.kind === 61 /* SyntaxKind.QuestionQuestionToken */;
}
function isConstTypeReference(node) {
    return (0, ts_js_1.isTypeReferenceNode)(node) && (0, ts_js_1.isIdentifier)(node.typeName) &&
        node.typeName.escapedText === "const" && !node.typeArguments;
}
function skipPartiallyEmittedExpressions(node) {
    return (0, ts_js_1.skipOuterExpressions)(node, 8 /* OuterExpressionKinds.PartiallyEmittedExpressions */);
}
function isNonNullChain(node) {
    return (0, ts_js_1.isNonNullExpression)(node) && !!(node.flags & 64 /* NodeFlags.OptionalChain */);
}
function isBreakOrContinueStatement(node) {
    return node.kind === 253 /* SyntaxKind.BreakStatement */ || node.kind === 252 /* SyntaxKind.ContinueStatement */;
}
function isNamedExportBindings(node) {
    return node.kind === 281 /* SyntaxKind.NamespaceExport */ || node.kind === 280 /* SyntaxKind.NamedExports */;
}
function isJSDocPropertyLikeTag(node) {
    return node.kind === 349 /* SyntaxKind.JSDocPropertyTag */ || node.kind === 342 /* SyntaxKind.JSDocParameterTag */;
}
// #endregion
// #region
// Node tests
//
// All node tests in the following list should *not* reference parent pointers so that
// they may be used with transformations.
/** @internal */
function isNodeKind(kind) {
    return kind >= 167 /* SyntaxKind.FirstNode */;
}
/**
 * True if kind is of some token syntax kind.
 * For example, this is true for an IfKeyword but not for an IfStatement.
 * Literals are considered tokens, except TemplateLiteral, but does include TemplateHead/Middle/Tail.
 */
function isTokenKind(kind) {
    return kind >= 0 /* SyntaxKind.FirstToken */ && kind <= 166 /* SyntaxKind.LastToken */;
}
/**
 * True if node is of some token syntax kind.
 * For example, this is true for an IfKeyword but not for an IfStatement.
 * Literals are considered tokens, except TemplateLiteral, but does include TemplateHead/Middle/Tail.
 */
function isToken(n) {
    return isTokenKind(n.kind);
}
// Node Arrays
/** @internal */
function isNodeArray(array) {
    return (0, ts_js_1.hasProperty)(array, "pos") && (0, ts_js_1.hasProperty)(array, "end");
}
// Literals
/** @internal */
function isLiteralKind(kind) {
    return 9 /* SyntaxKind.FirstLiteralToken */ <= kind && kind <= 15 /* SyntaxKind.LastLiteralToken */;
}
function isLiteralExpression(node) {
    return isLiteralKind(node.kind);
}
/** @internal */
function isLiteralExpressionOfObject(node) {
    switch (node.kind) {
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
        case 14 /* SyntaxKind.RegularExpressionLiteral */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 232 /* SyntaxKind.ClassExpression */:
            return true;
    }
    return false;
}
// Pseudo-literals
/** @internal */
function isTemplateLiteralKind(kind) {
    return 15 /* SyntaxKind.FirstTemplateToken */ <= kind && kind <= 18 /* SyntaxKind.LastTemplateToken */;
}
function isTemplateLiteralToken(node) {
    return isTemplateLiteralKind(node.kind);
}
function isTemplateMiddleOrTemplateTail(node) {
    const kind = node.kind;
    return kind === 17 /* SyntaxKind.TemplateMiddle */
        || kind === 18 /* SyntaxKind.TemplateTail */;
}
function isImportOrExportSpecifier(node) {
    return (0, ts_js_1.isImportSpecifier)(node) || (0, ts_js_1.isExportSpecifier)(node);
}
function isTypeOnlyImportDeclaration(node) {
    switch (node.kind) {
        case 277 /* SyntaxKind.ImportSpecifier */:
            return node.isTypeOnly || node.parent.parent.phaseModifier === 156 /* SyntaxKind.TypeKeyword */;
        case 275 /* SyntaxKind.NamespaceImport */:
            return node.parent.phaseModifier === 156 /* SyntaxKind.TypeKeyword */;
        case 274 /* SyntaxKind.ImportClause */:
            return node.phaseModifier === 156 /* SyntaxKind.TypeKeyword */;
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            return node.isTypeOnly;
    }
    return false;
}
function isTypeOnlyExportDeclaration(node) {
    switch (node.kind) {
        case 282 /* SyntaxKind.ExportSpecifier */:
            return node.isTypeOnly || node.parent.parent.isTypeOnly;
        case 279 /* SyntaxKind.ExportDeclaration */:
            return node.isTypeOnly && !!node.moduleSpecifier && !node.exportClause;
        case 281 /* SyntaxKind.NamespaceExport */:
            return node.parent.isTypeOnly;
    }
    return false;
}
function isTypeOnlyImportOrExportDeclaration(node) {
    return isTypeOnlyImportDeclaration(node) || isTypeOnlyExportDeclaration(node);
}
function isPartOfTypeOnlyImportOrExportDeclaration(node) {
    return findAncestor(node, isTypeOnlyImportOrExportDeclaration) !== undefined;
}
function isStringTextContainingNode(node) {
    return node.kind === 11 /* SyntaxKind.StringLiteral */ || isTemplateLiteralKind(node.kind);
}
function isImportAttributeName(node) {
    return (0, ts_js_1.isStringLiteral)(node) || (0, ts_js_1.isIdentifier)(node);
}
// Identifiers
/** @internal */
function isGeneratedIdentifier(node) {
    return (0, ts_js_1.isIdentifier)(node) && node.emitNode?.autoGenerate !== undefined;
}
/** @internal */
function isGeneratedPrivateIdentifier(node) {
    return (0, ts_js_1.isPrivateIdentifier)(node) && node.emitNode?.autoGenerate !== undefined;
}
/** @internal */
function isFileLevelReservedGeneratedIdentifier(node) {
    const flags = node.emitNode.autoGenerate.flags;
    return !!(flags & 32 /* GeneratedIdentifierFlags.FileLevel */)
        && !!(flags & 16 /* GeneratedIdentifierFlags.Optimistic */)
        && !!(flags & 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */);
}
// Private Identifiers
/** @internal */
function isPrivateIdentifierClassElementDeclaration(node) {
    return ((0, ts_js_1.isPropertyDeclaration)(node) || isMethodOrAccessor(node)) && (0, ts_js_1.isPrivateIdentifier)(node.name);
}
/** @internal */
function isPrivateIdentifierPropertyAccessExpression(node) {
    return (0, ts_js_1.isPropertyAccessExpression)(node) && (0, ts_js_1.isPrivateIdentifier)(node.name);
}
// Keywords
/** @internal */
function isModifierKind(token) {
    switch (token) {
        case 128 /* SyntaxKind.AbstractKeyword */:
        case 129 /* SyntaxKind.AccessorKeyword */:
        case 134 /* SyntaxKind.AsyncKeyword */:
        case 87 /* SyntaxKind.ConstKeyword */:
        case 138 /* SyntaxKind.DeclareKeyword */:
        case 90 /* SyntaxKind.DefaultKeyword */:
        case 95 /* SyntaxKind.ExportKeyword */:
        case 103 /* SyntaxKind.InKeyword */:
        case 125 /* SyntaxKind.PublicKeyword */:
        case 123 /* SyntaxKind.PrivateKeyword */:
        case 124 /* SyntaxKind.ProtectedKeyword */:
        case 148 /* SyntaxKind.ReadonlyKeyword */:
        case 126 /* SyntaxKind.StaticKeyword */:
        case 147 /* SyntaxKind.OutKeyword */:
        case 164 /* SyntaxKind.OverrideKeyword */:
            return true;
    }
    return false;
}
/** @internal */
function isParameterPropertyModifier(kind) {
    return !!((0, ts_js_1.modifierToFlag)(kind) & 31 /* ModifierFlags.ParameterPropertyModifier */);
}
/** @internal */
function isClassMemberModifier(idToken) {
    return isParameterPropertyModifier(idToken) ||
        idToken === 126 /* SyntaxKind.StaticKeyword */ ||
        idToken === 164 /* SyntaxKind.OverrideKeyword */ ||
        idToken === 129 /* SyntaxKind.AccessorKeyword */;
}
function isModifier(node) {
    return isModifierKind(node.kind);
}
function isEntityName(node) {
    const kind = node.kind;
    return kind === 167 /* SyntaxKind.QualifiedName */
        || kind === 80 /* SyntaxKind.Identifier */;
}
function isPropertyName(node) {
    const kind = node.kind;
    return kind === 80 /* SyntaxKind.Identifier */
        || kind === 81 /* SyntaxKind.PrivateIdentifier */
        || kind === 11 /* SyntaxKind.StringLiteral */
        || kind === 9 /* SyntaxKind.NumericLiteral */
        || kind === 168 /* SyntaxKind.ComputedPropertyName */;
}
function isBindingName(node) {
    const kind = node.kind;
    return kind === 80 /* SyntaxKind.Identifier */
        || kind === 207 /* SyntaxKind.ObjectBindingPattern */
        || kind === 208 /* SyntaxKind.ArrayBindingPattern */;
}
// Functions
function isFunctionLike(node) {
    return !!node && isFunctionLikeKind(node.kind);
}
/** @internal */
function isFunctionLikeOrClassStaticBlockDeclaration(node) {
    return !!node && (isFunctionLikeKind(node.kind) || (0, ts_js_1.isClassStaticBlockDeclaration)(node));
}
/** @internal */
function isFunctionLikeDeclaration(node) {
    return node && isFunctionLikeDeclarationKind(node.kind);
}
/** @internal */
function isBooleanLiteral(node) {
    return node.kind === 112 /* SyntaxKind.TrueKeyword */ || node.kind === 97 /* SyntaxKind.FalseKeyword */;
}
function isFunctionLikeDeclarationKind(kind) {
    switch (kind) {
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 177 /* SyntaxKind.Constructor */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function isFunctionLikeKind(kind) {
    switch (kind) {
        case 174 /* SyntaxKind.MethodSignature */:
        case 180 /* SyntaxKind.CallSignature */:
        case 324 /* SyntaxKind.JSDocSignature */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 185 /* SyntaxKind.FunctionType */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 186 /* SyntaxKind.ConstructorType */:
            return true;
        default:
            return isFunctionLikeDeclarationKind(kind);
    }
}
/** @internal */
function isFunctionOrModuleBlock(node) {
    return (0, ts_js_1.isSourceFile)(node) || (0, ts_js_1.isModuleBlock)(node) || (0, ts_js_1.isBlock)(node) && isFunctionLike(node.parent);
}
// Classes
function isClassElement(node) {
    const kind = node.kind;
    return kind === 177 /* SyntaxKind.Constructor */
        || kind === 173 /* SyntaxKind.PropertyDeclaration */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 182 /* SyntaxKind.IndexSignature */
        || kind === 176 /* SyntaxKind.ClassStaticBlockDeclaration */
        || kind === 241 /* SyntaxKind.SemicolonClassElement */;
}
function isClassLike(node) {
    return node && (node.kind === 264 /* SyntaxKind.ClassDeclaration */ || node.kind === 232 /* SyntaxKind.ClassExpression */);
}
function isAccessor(node) {
    return node && (node.kind === 178 /* SyntaxKind.GetAccessor */ || node.kind === 179 /* SyntaxKind.SetAccessor */);
}
function isAutoAccessorPropertyDeclaration(node) {
    return (0, ts_js_1.isPropertyDeclaration)(node) && (0, ts_js_1.hasAccessorModifier)(node);
}
/** @internal */
function isClassInstanceProperty(node) {
    if ((0, ts_js_1.isInJSFile)(node) && (0, ts_js_1.isExpandoPropertyDeclaration)(node)) {
        return (!(0, ts_js_1.isBindableStaticAccessExpression)(node) || !(0, ts_js_1.isPrototypeAccess)(node.expression)) && !(0, ts_js_1.isBindableStaticNameExpression)(node, /*excludeThisKeyword*/ true);
    }
    return node.parent && isClassLike(node.parent) && (0, ts_js_1.isPropertyDeclaration)(node) && !(0, ts_js_1.hasAccessorModifier)(node);
}
/** @internal */
function isMethodOrAccessor(node) {
    switch (node.kind) {
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
            return true;
        default:
            return false;
    }
}
// Type members
function isModifierLike(node) {
    return isModifier(node) || (0, ts_js_1.isDecorator)(node);
}
function isTypeElement(node) {
    const kind = node.kind;
    return kind === 181 /* SyntaxKind.ConstructSignature */
        || kind === 180 /* SyntaxKind.CallSignature */
        || kind === 172 /* SyntaxKind.PropertySignature */
        || kind === 174 /* SyntaxKind.MethodSignature */
        || kind === 182 /* SyntaxKind.IndexSignature */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 355 /* SyntaxKind.NotEmittedTypeElement */;
}
function isClassOrTypeElement(node) {
    return isTypeElement(node) || isClassElement(node);
}
function isObjectLiteralElementLike(node) {
    const kind = node.kind;
    return kind === 304 /* SyntaxKind.PropertyAssignment */
        || kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */
        || kind === 306 /* SyntaxKind.SpreadAssignment */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */;
}
// Type
/**
 * Node test that determines whether a node is a valid type node.
 * This differs from the `isPartOfTypeNode` function which determines whether a node is *part*
 * of a TypeNode.
 */
function isTypeNode(node) {
    return (0, ts_js_1.isTypeNodeKind)(node.kind);
}
function isFunctionOrConstructorTypeNode(node) {
    switch (node.kind) {
        case 185 /* SyntaxKind.FunctionType */:
        case 186 /* SyntaxKind.ConstructorType */:
            return true;
    }
    return false;
}
// Binding patterns
/** @internal */
function isBindingPattern(node) {
    if (node) {
        const kind = node.kind;
        return kind === 208 /* SyntaxKind.ArrayBindingPattern */
            || kind === 207 /* SyntaxKind.ObjectBindingPattern */;
    }
    return false;
}
/** @internal */
function isAssignmentPattern(node) {
    const kind = node.kind;
    return kind === 210 /* SyntaxKind.ArrayLiteralExpression */
        || kind === 211 /* SyntaxKind.ObjectLiteralExpression */;
}
function isArrayBindingElement(node) {
    const kind = node.kind;
    return kind === 209 /* SyntaxKind.BindingElement */
        || kind === 233 /* SyntaxKind.OmittedExpression */;
}
/**
 * Determines whether the BindingOrAssignmentElement is a BindingElement-like declaration
 *
 * @internal
 */
function isDeclarationBindingElement(bindingElement) {
    switch (bindingElement.kind) {
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 170 /* SyntaxKind.Parameter */:
        case 209 /* SyntaxKind.BindingElement */:
            return true;
    }
    return false;
}
/** @internal */
function isBindingOrAssignmentElement(node) {
    return (0, ts_js_1.isVariableDeclaration)(node)
        || (0, ts_js_1.isParameter)(node)
        || isObjectBindingOrAssignmentElement(node)
        || isArrayBindingOrAssignmentElement(node);
}
/**
 * Determines whether a node is a BindingOrAssignmentPattern
 *
 * @internal
 */
function isBindingOrAssignmentPattern(node) {
    return isObjectBindingOrAssignmentPattern(node)
        || isArrayBindingOrAssignmentPattern(node);
}
/**
 * Determines whether a node is an ObjectBindingOrAssignmentPattern
 *
 * @internal
 */
function isObjectBindingOrAssignmentPattern(node) {
    switch (node.kind) {
        case 207 /* SyntaxKind.ObjectBindingPattern */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
            return true;
    }
    return false;
}
/** @internal */
function isObjectBindingOrAssignmentElement(node) {
    switch (node.kind) {
        case 209 /* SyntaxKind.BindingElement */:
        case 304 /* SyntaxKind.PropertyAssignment */: // AssignmentProperty
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */: // AssignmentProperty
        case 306 /* SyntaxKind.SpreadAssignment */: // AssignmentRestProperty
            return true;
    }
    return false;
}
/**
 * Determines whether a node is an ArrayBindingOrAssignmentPattern
 *
 * @internal
 */
function isArrayBindingOrAssignmentPattern(node) {
    switch (node.kind) {
        case 208 /* SyntaxKind.ArrayBindingPattern */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
            return true;
    }
    return false;
}
/** @internal */
function isArrayBindingOrAssignmentElement(node) {
    switch (node.kind) {
        case 209 /* SyntaxKind.BindingElement */:
        case 233 /* SyntaxKind.OmittedExpression */: // Elision
        case 231 /* SyntaxKind.SpreadElement */: // AssignmentRestElement
        case 210 /* SyntaxKind.ArrayLiteralExpression */: // ArrayAssignmentPattern
        case 211 /* SyntaxKind.ObjectLiteralExpression */: // ObjectAssignmentPattern
        case 80 /* SyntaxKind.Identifier */: // DestructuringAssignmentTarget
        case 212 /* SyntaxKind.PropertyAccessExpression */: // DestructuringAssignmentTarget
        case 213 /* SyntaxKind.ElementAccessExpression */: // DestructuringAssignmentTarget
            return true;
    }
    return (0, ts_js_1.isAssignmentExpression)(node, /*excludeCompoundAssignment*/ true); // AssignmentElement
}
/** @internal */
function isPropertyAccessOrQualifiedNameOrImportTypeNode(node) {
    const kind = node.kind;
    return kind === 212 /* SyntaxKind.PropertyAccessExpression */
        || kind === 167 /* SyntaxKind.QualifiedName */
        || kind === 206 /* SyntaxKind.ImportType */;
}
// Expression
function isPropertyAccessOrQualifiedName(node) {
    const kind = node.kind;
    return kind === 212 /* SyntaxKind.PropertyAccessExpression */
        || kind === 167 /* SyntaxKind.QualifiedName */;
}
/** @internal */
function isCallLikeOrFunctionLikeExpression(node) {
    return isCallLikeExpression(node) || (0, ts_js_1.isFunctionExpressionOrArrowFunction)(node);
}
function isCallLikeExpression(node) {
    switch (node.kind) {
        case 214 /* SyntaxKind.CallExpression */:
        case 215 /* SyntaxKind.NewExpression */:
        case 216 /* SyntaxKind.TaggedTemplateExpression */:
        case 171 /* SyntaxKind.Decorator */:
        case 287 /* SyntaxKind.JsxOpeningElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
        case 290 /* SyntaxKind.JsxOpeningFragment */:
            return true;
        case 227 /* SyntaxKind.BinaryExpression */:
            return node.operatorToken.kind === 104 /* SyntaxKind.InstanceOfKeyword */;
        default:
            return false;
    }
}
function isCallOrNewExpression(node) {
    return node.kind === 214 /* SyntaxKind.CallExpression */ || node.kind === 215 /* SyntaxKind.NewExpression */;
}
function isTemplateLiteral(node) {
    const kind = node.kind;
    return kind === 229 /* SyntaxKind.TemplateExpression */
        || kind === 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */;
}
function isLeftHandSideExpression(node) {
    return isLeftHandSideExpressionKind(skipPartiallyEmittedExpressions(node).kind);
}
function isLeftHandSideExpressionKind(kind) {
    switch (kind) {
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 215 /* SyntaxKind.NewExpression */:
        case 214 /* SyntaxKind.CallExpression */:
        case 285 /* SyntaxKind.JsxElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
        case 289 /* SyntaxKind.JsxFragment */:
        case 216 /* SyntaxKind.TaggedTemplateExpression */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
        case 218 /* SyntaxKind.ParenthesizedExpression */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 80 /* SyntaxKind.Identifier */:
        case 81 /* SyntaxKind.PrivateIdentifier */: // technically this is only an Expression if it's in a `#field in expr` BinaryExpression
        case 14 /* SyntaxKind.RegularExpressionLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 229 /* SyntaxKind.TemplateExpression */:
        case 97 /* SyntaxKind.FalseKeyword */:
        case 106 /* SyntaxKind.NullKeyword */:
        case 110 /* SyntaxKind.ThisKeyword */:
        case 112 /* SyntaxKind.TrueKeyword */:
        case 108 /* SyntaxKind.SuperKeyword */:
        case 236 /* SyntaxKind.NonNullExpression */:
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
        case 237 /* SyntaxKind.MetaProperty */:
        case 102 /* SyntaxKind.ImportKeyword */: // technically this is only an Expression if it's in a CallExpression
        case 283 /* SyntaxKind.MissingDeclaration */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function isUnaryExpression(node) {
    return isUnaryExpressionKind(skipPartiallyEmittedExpressions(node).kind);
}
function isUnaryExpressionKind(kind) {
    switch (kind) {
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
        case 221 /* SyntaxKind.DeleteExpression */:
        case 222 /* SyntaxKind.TypeOfExpression */:
        case 223 /* SyntaxKind.VoidExpression */:
        case 224 /* SyntaxKind.AwaitExpression */:
        case 217 /* SyntaxKind.TypeAssertionExpression */:
            return true;
        default:
            return isLeftHandSideExpressionKind(kind);
    }
}
/** @internal */
function isUnaryExpressionWithWrite(expr) {
    switch (expr.kind) {
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
            return true;
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
            return expr.operator === 46 /* SyntaxKind.PlusPlusToken */ ||
                expr.operator === 47 /* SyntaxKind.MinusMinusToken */;
        default:
            return false;
    }
}
function isLiteralTypeLiteral(node) {
    switch (node.kind) {
        case 106 /* SyntaxKind.NullKeyword */:
        case 112 /* SyntaxKind.TrueKeyword */:
        case 97 /* SyntaxKind.FalseKeyword */:
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
            return true;
        default:
            return isLiteralExpression(node);
    }
}
/**
 * Determines whether a node is an expression based only on its kind.
 */
function isExpression(node) {
    return isExpressionKind(skipPartiallyEmittedExpressions(node).kind);
}
function isExpressionKind(kind) {
    switch (kind) {
        case 228 /* SyntaxKind.ConditionalExpression */:
        case 230 /* SyntaxKind.YieldExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 227 /* SyntaxKind.BinaryExpression */:
        case 231 /* SyntaxKind.SpreadElement */:
        case 235 /* SyntaxKind.AsExpression */:
        case 233 /* SyntaxKind.OmittedExpression */:
        case 357 /* SyntaxKind.CommaListExpression */:
        case 356 /* SyntaxKind.PartiallyEmittedExpression */:
        case 239 /* SyntaxKind.SatisfiesExpression */:
            return true;
        default:
            return isUnaryExpressionKind(kind);
    }
}
function isAssertionExpression(node) {
    const kind = node.kind;
    return kind === 217 /* SyntaxKind.TypeAssertionExpression */
        || kind === 235 /* SyntaxKind.AsExpression */;
}
function isIterationStatement(node, lookInLabeledStatements) {
    switch (node.kind) {
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 247 /* SyntaxKind.DoStatement */:
        case 248 /* SyntaxKind.WhileStatement */:
            return true;
        case 257 /* SyntaxKind.LabeledStatement */:
            return lookInLabeledStatements && isIterationStatement(node.statement, lookInLabeledStatements);
    }
    return false;
}
function isScopeMarker(node) {
    return (0, ts_js_1.isExportAssignment)(node) || (0, ts_js_1.isExportDeclaration)(node);
}
/** @internal */
function hasScopeMarker(statements) {
    return (0, ts_js_1.some)(statements, isScopeMarker);
}
/** @internal */
function needsScopeMarker(result) {
    return !(0, ts_js_1.isAnyImportOrReExport)(result) && !(0, ts_js_1.isExportAssignment)(result) && !(0, ts_js_1.hasSyntacticModifier)(result, 32 /* ModifierFlags.Export */) && !(0, ts_js_1.isAmbientModule)(result);
}
/** @internal */
function isExternalModuleIndicator(result) {
    // Exported top-level member indicates moduleness
    return (0, ts_js_1.isAnyImportOrReExport)(result) || (0, ts_js_1.isExportAssignment)(result) || (0, ts_js_1.hasSyntacticModifier)(result, 32 /* ModifierFlags.Export */);
}
/** @internal */
function isForInOrOfStatement(node) {
    return node.kind === 250 /* SyntaxKind.ForInStatement */ || node.kind === 251 /* SyntaxKind.ForOfStatement */;
}
// Element
function isConciseBody(node) {
    return (0, ts_js_1.isBlock)(node)
        || isExpression(node);
}
/** @internal */
function isFunctionBody(node) {
    return (0, ts_js_1.isBlock)(node);
}
function isForInitializer(node) {
    return (0, ts_js_1.isVariableDeclarationList)(node)
        || isExpression(node);
}
function isModuleBody(node) {
    const kind = node.kind;
    return kind === 269 /* SyntaxKind.ModuleBlock */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 80 /* SyntaxKind.Identifier */;
}
/** @internal @knipignore */
function isNamespaceBody(node) {
    const kind = node.kind;
    return kind === 269 /* SyntaxKind.ModuleBlock */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */;
}
/** @internal @knipignore */
function isJSDocNamespaceBody(node) {
    const kind = node.kind;
    return kind === 80 /* SyntaxKind.Identifier */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */;
}
function isNamedImportBindings(node) {
    const kind = node.kind;
    return kind === 276 /* SyntaxKind.NamedImports */
        || kind === 275 /* SyntaxKind.NamespaceImport */;
}
/** @internal */
function isModuleOrEnumDeclaration(node) {
    return node.kind === 268 /* SyntaxKind.ModuleDeclaration */ || node.kind === 267 /* SyntaxKind.EnumDeclaration */;
}
/** @internal */
function canHaveSymbol(node) {
    // NOTE: This should cover all possible declarations except MissingDeclaration and SemicolonClassElement
    //       since they aren't actually declarations and can't have a symbol.
    switch (node.kind) {
        case 220 /* SyntaxKind.ArrowFunction */:
        case 227 /* SyntaxKind.BinaryExpression */:
        case 209 /* SyntaxKind.BindingElement */:
        case 214 /* SyntaxKind.CallExpression */:
        case 180 /* SyntaxKind.CallSignature */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
        case 177 /* SyntaxKind.Constructor */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 307 /* SyntaxKind.EnumMember */:
        case 278 /* SyntaxKind.ExportAssignment */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 282 /* SyntaxKind.ExportSpecifier */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 185 /* SyntaxKind.FunctionType */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 80 /* SyntaxKind.Identifier */:
        case 274 /* SyntaxKind.ImportClause */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 277 /* SyntaxKind.ImportSpecifier */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 339 /* SyntaxKind.JSDocCallbackTag */:
        case 341 /* SyntaxKind.JSDocEnumTag */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 342 /* SyntaxKind.JSDocParameterTag */:
        case 349 /* SyntaxKind.JSDocPropertyTag */:
        case 324 /* SyntaxKind.JSDocSignature */:
        case 347 /* SyntaxKind.JSDocTypedefTag */:
        case 323 /* SyntaxKind.JSDocTypeLiteral */:
        case 292 /* SyntaxKind.JsxAttribute */:
        case 293 /* SyntaxKind.JsxAttributes */:
        case 294 /* SyntaxKind.JsxSpreadAttribute */:
        case 201 /* SyntaxKind.MappedType */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 203 /* SyntaxKind.NamedTupleMember */:
        case 281 /* SyntaxKind.NamespaceExport */:
        case 271 /* SyntaxKind.NamespaceExportDeclaration */:
        case 275 /* SyntaxKind.NamespaceImport */:
        case 215 /* SyntaxKind.NewExpression */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 170 /* SyntaxKind.Parameter */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
        case 308 /* SyntaxKind.SourceFile */:
        case 306 /* SyntaxKind.SpreadAssignment */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 188 /* SyntaxKind.TypeLiteral */:
        case 169 /* SyntaxKind.TypeParameter */:
        case 261 /* SyntaxKind.VariableDeclaration */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function canHaveLocals(node) {
    switch (node.kind) {
        case 220 /* SyntaxKind.ArrowFunction */:
        case 242 /* SyntaxKind.Block */:
        case 180 /* SyntaxKind.CallSignature */:
        case 270 /* SyntaxKind.CaseBlock */:
        case 300 /* SyntaxKind.CatchClause */:
        case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
        case 195 /* SyntaxKind.ConditionalType */:
        case 177 /* SyntaxKind.Constructor */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 185 /* SyntaxKind.FunctionType */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 339 /* SyntaxKind.JSDocCallbackTag */:
        case 341 /* SyntaxKind.JSDocEnumTag */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 324 /* SyntaxKind.JSDocSignature */:
        case 347 /* SyntaxKind.JSDocTypedefTag */:
        case 201 /* SyntaxKind.MappedType */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 308 /* SyntaxKind.SourceFile */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
            return true;
        default:
            return false;
    }
}
function isDeclarationKind(kind) {
    return kind === 220 /* SyntaxKind.ArrowFunction */
        || kind === 209 /* SyntaxKind.BindingElement */
        || kind === 264 /* SyntaxKind.ClassDeclaration */
        || kind === 232 /* SyntaxKind.ClassExpression */
        || kind === 176 /* SyntaxKind.ClassStaticBlockDeclaration */
        || kind === 177 /* SyntaxKind.Constructor */
        || kind === 267 /* SyntaxKind.EnumDeclaration */
        || kind === 307 /* SyntaxKind.EnumMember */
        || kind === 282 /* SyntaxKind.ExportSpecifier */
        || kind === 263 /* SyntaxKind.FunctionDeclaration */
        || kind === 219 /* SyntaxKind.FunctionExpression */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 274 /* SyntaxKind.ImportClause */
        || kind === 272 /* SyntaxKind.ImportEqualsDeclaration */
        || kind === 277 /* SyntaxKind.ImportSpecifier */
        || kind === 265 /* SyntaxKind.InterfaceDeclaration */
        || kind === 292 /* SyntaxKind.JsxAttribute */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 174 /* SyntaxKind.MethodSignature */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 271 /* SyntaxKind.NamespaceExportDeclaration */
        || kind === 275 /* SyntaxKind.NamespaceImport */
        || kind === 281 /* SyntaxKind.NamespaceExport */
        || kind === 170 /* SyntaxKind.Parameter */
        || kind === 304 /* SyntaxKind.PropertyAssignment */
        || kind === 173 /* SyntaxKind.PropertyDeclaration */
        || kind === 172 /* SyntaxKind.PropertySignature */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */
        || kind === 266 /* SyntaxKind.TypeAliasDeclaration */
        || kind === 169 /* SyntaxKind.TypeParameter */
        || kind === 261 /* SyntaxKind.VariableDeclaration */
        || kind === 347 /* SyntaxKind.JSDocTypedefTag */
        || kind === 339 /* SyntaxKind.JSDocCallbackTag */
        || kind === 349 /* SyntaxKind.JSDocPropertyTag */
        || kind === 203 /* SyntaxKind.NamedTupleMember */;
}
function isDeclarationStatementKind(kind) {
    return kind === 263 /* SyntaxKind.FunctionDeclaration */
        || kind === 283 /* SyntaxKind.MissingDeclaration */
        || kind === 264 /* SyntaxKind.ClassDeclaration */
        || kind === 265 /* SyntaxKind.InterfaceDeclaration */
        || kind === 266 /* SyntaxKind.TypeAliasDeclaration */
        || kind === 267 /* SyntaxKind.EnumDeclaration */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 273 /* SyntaxKind.ImportDeclaration */
        || kind === 272 /* SyntaxKind.ImportEqualsDeclaration */
        || kind === 279 /* SyntaxKind.ExportDeclaration */
        || kind === 278 /* SyntaxKind.ExportAssignment */
        || kind === 271 /* SyntaxKind.NamespaceExportDeclaration */;
}
function isStatementKindButNotDeclarationKind(kind) {
    return kind === 253 /* SyntaxKind.BreakStatement */
        || kind === 252 /* SyntaxKind.ContinueStatement */
        || kind === 260 /* SyntaxKind.DebuggerStatement */
        || kind === 247 /* SyntaxKind.DoStatement */
        || kind === 245 /* SyntaxKind.ExpressionStatement */
        || kind === 243 /* SyntaxKind.EmptyStatement */
        || kind === 250 /* SyntaxKind.ForInStatement */
        || kind === 251 /* SyntaxKind.ForOfStatement */
        || kind === 249 /* SyntaxKind.ForStatement */
        || kind === 246 /* SyntaxKind.IfStatement */
        || kind === 257 /* SyntaxKind.LabeledStatement */
        || kind === 254 /* SyntaxKind.ReturnStatement */
        || kind === 256 /* SyntaxKind.SwitchStatement */
        || kind === 258 /* SyntaxKind.ThrowStatement */
        || kind === 259 /* SyntaxKind.TryStatement */
        || kind === 244 /* SyntaxKind.VariableStatement */
        || kind === 248 /* SyntaxKind.WhileStatement */
        || kind === 255 /* SyntaxKind.WithStatement */
        || kind === 354 /* SyntaxKind.NotEmittedStatement */;
}
/** @internal */
function isDeclaration(node) {
    if (node.kind === 169 /* SyntaxKind.TypeParameter */) {
        return (node.parent && node.parent.kind !== 346 /* SyntaxKind.JSDocTemplateTag */) || (0, ts_js_1.isInJSFile)(node);
    }
    return isDeclarationKind(node.kind);
}
function isDeclarationStatement(node) {
    return isDeclarationStatementKind(node.kind);
}
/**
 * Determines whether the node is a statement that is not also a declaration
 *
 * @internal
 */
function isStatementButNotDeclaration(node) {
    return isStatementKindButNotDeclarationKind(node.kind);
}
function isStatement(node) {
    const kind = node.kind;
    return isStatementKindButNotDeclarationKind(kind)
        || isDeclarationStatementKind(kind)
        || isBlockStatement(node);
}
function isBlockStatement(node) {
    if (node.kind !== 242 /* SyntaxKind.Block */)
        return false;
    if (node.parent !== undefined) {
        if (node.parent.kind === 259 /* SyntaxKind.TryStatement */ || node.parent.kind === 300 /* SyntaxKind.CatchClause */) {
            return false;
        }
    }
    return !(0, ts_js_1.isFunctionBlock)(node);
}
// TODO(jakebailey): should we be exporting this function and not isStatement?
/**
 * NOTE: This is similar to `isStatement` but does not access parent pointers.
 *
 * @internal
 */
function isStatementOrBlock(node) {
    const kind = node.kind;
    return isStatementKindButNotDeclarationKind(kind)
        || isDeclarationStatementKind(kind)
        || kind === 242 /* SyntaxKind.Block */;
}
// Module references
function isModuleReference(node) {
    const kind = node.kind;
    return kind === 284 /* SyntaxKind.ExternalModuleReference */
        || kind === 167 /* SyntaxKind.QualifiedName */
        || kind === 80 /* SyntaxKind.Identifier */;
}
// JSX
function isJsxTagNameExpression(node) {
    const kind = node.kind;
    return kind === 110 /* SyntaxKind.ThisKeyword */
        || kind === 80 /* SyntaxKind.Identifier */
        || kind === 212 /* SyntaxKind.PropertyAccessExpression */
        || kind === 296 /* SyntaxKind.JsxNamespacedName */;
}
function isJsxChild(node) {
    const kind = node.kind;
    return kind === 285 /* SyntaxKind.JsxElement */
        || kind === 295 /* SyntaxKind.JsxExpression */
        || kind === 286 /* SyntaxKind.JsxSelfClosingElement */
        || kind === 12 /* SyntaxKind.JsxText */
        || kind === 289 /* SyntaxKind.JsxFragment */;
}
function isJsxAttributeLike(node) {
    const kind = node.kind;
    return kind === 292 /* SyntaxKind.JsxAttribute */
        || kind === 294 /* SyntaxKind.JsxSpreadAttribute */;
}
function isStringLiteralOrJsxExpression(node) {
    const kind = node.kind;
    return kind === 11 /* SyntaxKind.StringLiteral */
        || kind === 295 /* SyntaxKind.JsxExpression */;
}
function isJsxOpeningLikeElement(node) {
    const kind = node.kind;
    return kind === 287 /* SyntaxKind.JsxOpeningElement */
        || kind === 286 /* SyntaxKind.JsxSelfClosingElement */;
}
function isJsxCallLike(node) {
    const kind = node.kind;
    return kind === 287 /* SyntaxKind.JsxOpeningElement */
        || kind === 286 /* SyntaxKind.JsxSelfClosingElement */
        || kind === 290 /* SyntaxKind.JsxOpeningFragment */;
}
// Clauses
function isCaseOrDefaultClause(node) {
    const kind = node.kind;
    return kind === 297 /* SyntaxKind.CaseClause */
        || kind === 298 /* SyntaxKind.DefaultClause */;
}
// JSDoc
/**
 * True if node is of some JSDoc syntax kind.
 *
 * @internal
 */
function isJSDocNode(node) {
    return node.kind >= 310 /* SyntaxKind.FirstJSDocNode */ && node.kind <= 352 /* SyntaxKind.LastJSDocNode */;
}
/** True if node is of a kind that may contain comment text. */
function isJSDocCommentContainingNode(node) {
    return node.kind === 321 /* SyntaxKind.JSDoc */
        || node.kind === 320 /* SyntaxKind.JSDocNamepathType */
        || node.kind === 322 /* SyntaxKind.JSDocText */
        || isJSDocLinkLike(node)
        || isJSDocTag(node)
        || (0, ts_js_1.isJSDocTypeLiteral)(node)
        || (0, ts_js_1.isJSDocSignature)(node);
}
// TODO: determine what this does before making it public.
/** @internal */
function isJSDocTag(node) {
    return node.kind >= 328 /* SyntaxKind.FirstJSDocTagNode */ && node.kind <= 352 /* SyntaxKind.LastJSDocTagNode */;
}
function isSetAccessor(node) {
    return node.kind === 179 /* SyntaxKind.SetAccessor */;
}
function isGetAccessor(node) {
    return node.kind === 178 /* SyntaxKind.GetAccessor */;
}
/**
 * True if has jsdoc nodes attached to it.
 *
 * @internal
 */
// TODO: GH#19856 Would like to return `node is Node & { jsDoc: JSDoc[] }` but it causes long compile times
function hasJSDocNodes(node) {
    if (!(0, ts_js_1.canHaveJSDoc)(node))
        return false;
    const { jsDoc } = node;
    return !!jsDoc && jsDoc.length > 0;
}
/**
 * True if has type node attached to it.
 *
 * @internal
 */
function hasType(node) {
    return !!node.type;
}
/**
 * True if has initializer node attached to it.
 *
 * @internal
 */
function hasInitializer(node) {
    return !!node.initializer;
}
/** True if has initializer node attached to it. */
function hasOnlyExpressionInitializer(node) {
    switch (node.kind) {
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 170 /* SyntaxKind.Parameter */:
        case 209 /* SyntaxKind.BindingElement */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 307 /* SyntaxKind.EnumMember */:
            return true;
        default:
            return false;
    }
}
function isObjectLiteralElement(node) {
    return node.kind === 292 /* SyntaxKind.JsxAttribute */ || node.kind === 294 /* SyntaxKind.JsxSpreadAttribute */ || isObjectLiteralElementLike(node);
}
/** @internal */
function isTypeReferenceType(node) {
    return node.kind === 184 /* SyntaxKind.TypeReference */ || node.kind === 234 /* SyntaxKind.ExpressionWithTypeArguments */;
}
const MAX_SMI_X86 = 1073741823;
/** @internal */
function guessIndentation(lines) {
    let indentation = MAX_SMI_X86;
    for (const line of lines) {
        if (!line.length) {
            continue;
        }
        let i = 0;
        for (; i < line.length && i < indentation; i++) {
            if (!(0, ts_js_1.isWhiteSpaceLike)(line.charCodeAt(i))) {
                break;
            }
        }
        if (i < indentation) {
            indentation = i;
        }
        if (indentation === 0) {
            return 0;
        }
    }
    return indentation === MAX_SMI_X86 ? undefined : indentation;
}
function isStringLiteralLike(node) {
    return node.kind === 11 /* SyntaxKind.StringLiteral */ || node.kind === 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */;
}
function isJSDocLinkLike(node) {
    return node.kind === 325 /* SyntaxKind.JSDocLink */ || node.kind === 326 /* SyntaxKind.JSDocLinkCode */ || node.kind === 327 /* SyntaxKind.JSDocLinkPlain */;
}
function hasRestParameter(s) {
    const last = (0, ts_js_1.lastOrUndefined)(s.parameters);
    return !!last && isRestParameter(last);
}
function isRestParameter(node) {
    const type = (0, ts_js_1.isJSDocParameterTag)(node) ? (node.typeExpression && node.typeExpression.type) : node.type;
    return node.dotDotDotToken !== undefined || !!type && type.kind === 319 /* SyntaxKind.JSDocVariadicType */;
}
function hasInternalAnnotation(range, sourceFile) {
    const comment = sourceFile.text.substring(range.pos, range.end);
    return comment.includes("@internal");
}
function isInternalDeclaration(node, sourceFile) {
    sourceFile ?? (sourceFile = (0, ts_js_1.getSourceFileOfNode)(node));
    const parseTreeNode = getParseTreeNode(node);
    if (parseTreeNode && parseTreeNode.kind === 170 /* SyntaxKind.Parameter */) {
        const paramIdx = parseTreeNode.parent.parameters.indexOf(parseTreeNode);
        const previousSibling = paramIdx > 0 ? parseTreeNode.parent.parameters[paramIdx - 1] : undefined;
        const text = sourceFile.text;
        const commentRanges = previousSibling
            ? (0, ts_js_1.concatenate)(
            // to handle
            // ... parameters, /** @internal */
            // public param: string
            (0, ts_js_1.getTrailingCommentRanges)(text, (0, ts_js_1.skipTrivia)(text, previousSibling.end + 1, /*stopAfterLineBreak*/ false, /*stopAtComments*/ true)), (0, ts_js_1.getLeadingCommentRanges)(text, node.pos))
            : (0, ts_js_1.getTrailingCommentRanges)(text, (0, ts_js_1.skipTrivia)(text, node.pos, /*stopAfterLineBreak*/ false, /*stopAtComments*/ true));
        return (0, ts_js_1.some)(commentRanges) && hasInternalAnnotation((0, ts_js_1.last)(commentRanges), sourceFile);
    }
    const leadingCommentRanges = parseTreeNode && (0, ts_js_1.getLeadingCommentRangesOfNode)(parseTreeNode, sourceFile);
    return !!(0, ts_js_1.forEach)(leadingCommentRanges, range => {
        return hasInternalAnnotation(range, sourceFile);
    });
}
