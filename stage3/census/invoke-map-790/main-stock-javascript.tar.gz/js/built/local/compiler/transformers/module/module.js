"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformModule = transformModule;
const ts_js_1 = require("../../_namespaces/ts.js");
/** @internal */
function transformModule(context) {
    function getTransformModuleDelegate(moduleKind) {
        switch (moduleKind) {
            case ts_js_1.ModuleKind.AMD:
                return transformAMDModule;
            case ts_js_1.ModuleKind.UMD:
                return transformUMDModule;
            default:
                return transformCommonJSModule;
        }
    }
    const { factory, getEmitHelperFactory: emitHelpers, startLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const compilerOptions = context.getCompilerOptions();
    const resolver = context.getEmitResolver();
    const host = context.getEmitHost();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const moduleKind = (0, ts_js_1.getEmitModuleKind)(compilerOptions);
    const previousOnSubstituteNode = context.onSubstituteNode;
    const previousOnEmitNode = context.onEmitNode;
    context.onSubstituteNode = onSubstituteNode;
    context.onEmitNode = onEmitNode;
    context.enableSubstitution(214 /* SyntaxKind.CallExpression */); // Substitute calls to imported/exported symbols to avoid incorrect `this`.
    context.enableSubstitution(216 /* SyntaxKind.TaggedTemplateExpression */); // Substitute calls to imported/exported symbols to avoid incorrect `this`.
    context.enableSubstitution(80 /* SyntaxKind.Identifier */); // Substitutes expression identifiers with imported/exported symbols.
    context.enableSubstitution(227 /* SyntaxKind.BinaryExpression */); // Substitutes assignments to exported symbols.
    context.enableSubstitution(305 /* SyntaxKind.ShorthandPropertyAssignment */); // Substitutes shorthand property assignments for imported/exported symbols.
    context.enableEmitNotification(308 /* SyntaxKind.SourceFile */); // Restore state when substituting nodes in a file.
    const moduleInfoMap = []; // The ExternalModuleInfo for each file.
    let currentSourceFile; // The current file.
    let currentModuleInfo; // The ExternalModuleInfo for the current file.
    let importsAndRequiresToRewriteOrShim;
    const noSubstitution = []; // Set of nodes for which substitution rules should be ignored.
    let needUMDDynamicImportHelper;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    /**
     * Transforms the module aspects of a SourceFile.
     *
     * @param node The SourceFile node.
     */
    function transformSourceFile(node) {
        if (node.isDeclarationFile ||
            !((0, ts_js_1.isEffectiveExternalModule)(node, compilerOptions) ||
                node.transformFlags & 8388608 /* TransformFlags.ContainsDynamicImport */ ||
                ((0, ts_js_1.isJsonSourceFile)(node) && (0, ts_js_1.hasJsonModuleEmitEnabled)(compilerOptions) && compilerOptions.outFile))) {
            return node;
        }
        currentSourceFile = node;
        currentModuleInfo = (0, ts_js_1.collectExternalModuleInfo)(context, node);
        moduleInfoMap[(0, ts_js_1.getOriginalNodeId)(node)] = currentModuleInfo;
        if (compilerOptions.rewriteRelativeImportExtensions) {
            (0, ts_js_1.forEachDynamicImportOrRequireCall)(node, /*includeTypeSpaceImports*/ false, /*requireStringLiteralLikeArgument*/ false, node => {
                if (!(0, ts_js_1.isStringLiteralLike)(node.arguments[0]) || (0, ts_js_1.shouldRewriteModuleSpecifier)(node.arguments[0].text, compilerOptions)) {
                    importsAndRequiresToRewriteOrShim = (0, ts_js_1.append)(importsAndRequiresToRewriteOrShim, node);
                }
            });
        }
        // Perform the transformation.
        const transformModule = getTransformModuleDelegate(moduleKind);
        const updated = transformModule(node);
        currentSourceFile = undefined;
        currentModuleInfo = undefined;
        needUMDDynamicImportHelper = false;
        return updated;
    }
    function shouldEmitUnderscoreUnderscoreESModule() {
        if ((0, ts_js_1.hasJSFileExtension)(currentSourceFile.fileName) && currentSourceFile.commonJsModuleIndicator && (!currentSourceFile.externalModuleIndicator || currentSourceFile.externalModuleIndicator === true)) {
            return false;
        }
        if (!currentModuleInfo.exportEquals && (0, ts_js_1.isExternalModule)(currentSourceFile)) {
            return true;
        }
        return false;
    }
    /**
     * Transforms a SourceFile into a CommonJS module.
     *
     * @param node The SourceFile node.
     */
    function transformCommonJSModule(node) {
        startLexicalEnvironment();
        const statements = [];
        const ensureUseStrict = (0, ts_js_1.getAlwaysStrict)(compilerOptions) || (0, ts_js_1.isExternalModule)(currentSourceFile);
        const statementOffset = factory.copyPrologue(node.statements, statements, ensureUseStrict && !(0, ts_js_1.isJsonSourceFile)(node), topLevelVisitor);
        if (shouldEmitUnderscoreUnderscoreESModule()) {
            (0, ts_js_1.append)(statements, createUnderscoreUnderscoreESModule());
        }
        if ((0, ts_js_1.some)(currentModuleInfo.exportedNames)) {
            const chunkSize = 50;
            for (let i = 0; i < currentModuleInfo.exportedNames.length; i += chunkSize) {
                (0, ts_js_1.append)(statements, factory.createExpressionStatement((0, ts_js_1.reduceLeft)(currentModuleInfo.exportedNames.slice(i, i + chunkSize), (prev, nextId) => nextId.kind === 11 /* SyntaxKind.StringLiteral */
                    ? factory.createAssignment(factory.createElementAccessExpression(factory.createIdentifier("exports"), factory.createStringLiteral(nextId.text)), prev)
                    : factory.createAssignment(factory.createPropertyAccessExpression(factory.createIdentifier("exports"), factory.createIdentifier((0, ts_js_1.idText)(nextId))), prev), factory.createVoidZero())));
            }
        }
        for (const f of currentModuleInfo.exportedFunctions) {
            appendExportsOfHoistedDeclaration(statements, f);
        }
        (0, ts_js_1.append)(statements, (0, ts_js_1.visitNode)(currentModuleInfo.externalHelpersImportDeclaration, topLevelVisitor, ts_js_1.isStatement));
        (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(node.statements, topLevelVisitor, ts_js_1.isStatement, statementOffset));
        addExportEqualsIfNeeded(statements, /*emitAsReturn*/ false);
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        const updated = factory.updateSourceFile(node, (0, ts_js_1.setTextRange)(factory.createNodeArray(statements), node.statements));
        (0, ts_js_1.addEmitHelpers)(updated, context.readEmitHelpers());
        return updated;
    }
    /**
     * Transforms a SourceFile into an AMD module.
     *
     * @param node The SourceFile node.
     */
    function transformAMDModule(node) {
        const define = factory.createIdentifier("define");
        const moduleName = (0, ts_js_1.tryGetModuleNameFromFile)(factory, node, host, compilerOptions);
        const jsonSourceFile = (0, ts_js_1.isJsonSourceFile)(node) && node;
        // An AMD define function has the following shape:
        //
        //     define(id?, dependencies?, factory);
        //
        // This has the shape of the following:
        //
        //     define(name, ["module1", "module2"], function (module1Alias) { ... }
        //
        // The location of the alias in the parameter list in the factory function needs to
        // match the position of the module name in the dependency list.
        //
        // To ensure this is true in cases of modules with no aliases, e.g.:
        //
        //     import "module"
        //
        // or
        //
        //     /// <amd-dependency path= "a.css" />
        //
        // we need to add modules without alias names to the end of the dependencies list
        const { aliasedModuleNames, unaliasedModuleNames, importAliasNames } = collectAsynchronousDependencies(node, /*includeNonAmdDependencies*/ true);
        // Create an updated SourceFile:
        //
        //     define(mofactory.updateSourceFile", "module2"], function ...
        const updated = factory.updateSourceFile(node, (0, ts_js_1.setTextRange)(factory.createNodeArray([
            factory.createExpressionStatement(factory.createCallExpression(define, 
            /*typeArguments*/ undefined, [
                // Add the module name (if provided).
                ...(moduleName ? [moduleName] : []),
                // Add the dependency array argument:
                //
                //     ["require", "exports", module1", "module2", ...]
                factory.createArrayLiteralExpression(jsonSourceFile ? ts_js_1.emptyArray : [
                    factory.createStringLiteral("require"),
                    factory.createStringLiteral("exports"),
                    ...aliasedModuleNames,
                    ...unaliasedModuleNames,
                ]),
                // Add the module body function argument:
                //
                //     function (require, exports, module1, module2) ...
                jsonSourceFile ?
                    jsonSourceFile.statements.length ? jsonSourceFile.statements[0].expression : factory.createObjectLiteralExpression() :
                    factory.createFunctionExpression(
                    /*modifiers*/ undefined, 
                    /*asteriskToken*/ undefined, 
                    /*name*/ undefined, 
                    /*typeParameters*/ undefined, [
                        factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, "require"),
                        factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, "exports"),
                        ...importAliasNames,
                    ], 
                    /*type*/ undefined, transformAsynchronousModuleBody(node)),
            ])),
        ]), 
        /*location*/ node.statements));
        (0, ts_js_1.addEmitHelpers)(updated, context.readEmitHelpers());
        return updated;
    }
    /**
     * Transforms a SourceFile into a UMD module.
     *
     * @param node The SourceFile node.
     */
    function transformUMDModule(node) {
        const { aliasedModuleNames, unaliasedModuleNames, importAliasNames } = collectAsynchronousDependencies(node, /*includeNonAmdDependencies*/ false);
        const moduleName = (0, ts_js_1.tryGetModuleNameFromFile)(factory, node, host, compilerOptions);
        const umdHeader = factory.createFunctionExpression(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, "factory")], 
        /*type*/ undefined, (0, ts_js_1.setTextRange)(factory.createBlock([
            factory.createIfStatement(factory.createLogicalAnd(factory.createTypeCheck(factory.createIdentifier("module"), "object"), factory.createTypeCheck(factory.createPropertyAccessExpression(factory.createIdentifier("module"), "exports"), "object")), factory.createBlock([
                factory.createVariableStatement(
                /*modifiers*/ undefined, [
                    factory.createVariableDeclaration("v", 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, factory.createCallExpression(factory.createIdentifier("factory"), 
                    /*typeArguments*/ undefined, [
                        factory.createIdentifier("require"),
                        factory.createIdentifier("exports"),
                    ])),
                ]),
                (0, ts_js_1.setEmitFlags)(factory.createIfStatement(factory.createStrictInequality(factory.createIdentifier("v"), factory.createIdentifier("undefined")), factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(factory.createIdentifier("module"), "exports"), factory.createIdentifier("v")))), 1 /* EmitFlags.SingleLine */),
            ]), factory.createIfStatement(factory.createLogicalAnd(factory.createTypeCheck(factory.createIdentifier("define"), "function"), factory.createPropertyAccessExpression(factory.createIdentifier("define"), "amd")), factory.createBlock([
                factory.createExpressionStatement(factory.createCallExpression(factory.createIdentifier("define"), 
                /*typeArguments*/ undefined, [
                    // Add the module name (if provided).
                    ...(moduleName ? [moduleName] : []),
                    factory.createArrayLiteralExpression([
                        factory.createStringLiteral("require"),
                        factory.createStringLiteral("exports"),
                        ...aliasedModuleNames,
                        ...unaliasedModuleNames,
                    ]),
                    factory.createIdentifier("factory"),
                ])),
            ]))),
        ], 
        /*multiLine*/ true), 
        /*location*/ undefined));
        // Create an updated SourceFile:
        //
        //  (function (factory) {
        //      if (typeof module === "object" && typeof module.exports === "object") {
        //          var v = factory(require, exports);
        //          if (v !== undefined) module.exports = v;
        //      }
        //      else if (typeof define === 'function' && define.amd) {
        //          define(["require", "exports"], factory);
        //      }
        //  })(function ...)
        const updated = factory.updateSourceFile(node, (0, ts_js_1.setTextRange)(factory.createNodeArray([
            factory.createExpressionStatement(factory.createCallExpression(umdHeader, 
            /*typeArguments*/ undefined, [
                // Add the module body function argument:
                //
                //     function (require, exports) ...
                factory.createFunctionExpression(
                /*modifiers*/ undefined, 
                /*asteriskToken*/ undefined, 
                /*name*/ undefined, 
                /*typeParameters*/ undefined, [
                    factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, "require"),
                    factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, "exports"),
                    ...importAliasNames,
                ], 
                /*type*/ undefined, transformAsynchronousModuleBody(node)),
            ])),
        ]), 
        /*location*/ node.statements));
        (0, ts_js_1.addEmitHelpers)(updated, context.readEmitHelpers());
        return updated;
    }
    /**
     * Collect the additional asynchronous dependencies for the module.
     *
     * @param node The source file.
     * @param includeNonAmdDependencies A value indicating whether to include non-AMD dependencies.
     */
    function collectAsynchronousDependencies(node, includeNonAmdDependencies) {
        // names of modules with corresponding parameter in the factory function
        const aliasedModuleNames = [];
        // names of modules with no corresponding parameters in factory function
        const unaliasedModuleNames = [];
        // names of the parameters in the factory function; these
        // parameters need to match the indexes of the corresponding
        // module names in aliasedModuleNames.
        const importAliasNames = [];
        // Fill in amd-dependency tags
        for (const amdDependency of node.amdDependencies) {
            if (amdDependency.name) {
                aliasedModuleNames.push(factory.createStringLiteral(amdDependency.path));
                importAliasNames.push(factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, amdDependency.name));
            }
            else {
                unaliasedModuleNames.push(factory.createStringLiteral(amdDependency.path));
            }
        }
        for (const importNode of currentModuleInfo.externalImports) {
            // Find the name of the external module
            const externalModuleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, importNode, currentSourceFile, host, resolver, compilerOptions);
            // Find the name of the module alias, if there is one
            const importAliasName = (0, ts_js_1.getLocalNameForExternalImport)(factory, importNode, currentSourceFile);
            // It is possible that externalModuleName is undefined if it is not string literal.
            // This can happen in the invalid import syntax.
            // E.g : "import * from alias from 'someLib';"
            if (externalModuleName) {
                if (includeNonAmdDependencies && importAliasName) {
                    // Set emitFlags on the name of the classDeclaration
                    // This is so that when printer will not substitute the identifier
                    (0, ts_js_1.setEmitFlags)(importAliasName, 8 /* EmitFlags.NoSubstitution */);
                    aliasedModuleNames.push(externalModuleName);
                    importAliasNames.push(factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, importAliasName));
                }
                else {
                    unaliasedModuleNames.push(externalModuleName);
                }
            }
        }
        return { aliasedModuleNames, unaliasedModuleNames, importAliasNames };
    }
    function getAMDImportExpressionForImport(node) {
        if ((0, ts_js_1.isImportEqualsDeclaration)(node) || (0, ts_js_1.isExportDeclaration)(node) || !(0, ts_js_1.getExternalModuleNameLiteral)(factory, node, currentSourceFile, host, resolver, compilerOptions)) {
            return undefined;
        }
        const name = (0, ts_js_1.getLocalNameForExternalImport)(factory, node, currentSourceFile); // TODO: GH#18217
        const expr = getHelperExpressionForImport(node, name);
        if (expr === name) {
            return undefined;
        }
        return factory.createExpressionStatement(factory.createAssignment(name, expr));
    }
    /**
     * Transforms a SourceFile into an AMD or UMD module body.
     *
     * @param node The SourceFile node.
     */
    function transformAsynchronousModuleBody(node) {
        startLexicalEnvironment();
        const statements = [];
        const statementOffset = factory.copyPrologue(node.statements, statements, /*ensureUseStrict*/ true, topLevelVisitor);
        if (shouldEmitUnderscoreUnderscoreESModule()) {
            (0, ts_js_1.append)(statements, createUnderscoreUnderscoreESModule());
        }
        if ((0, ts_js_1.some)(currentModuleInfo.exportedNames)) {
            (0, ts_js_1.append)(statements, factory.createExpressionStatement((0, ts_js_1.reduceLeft)(currentModuleInfo.exportedNames, (prev, nextId) => nextId.kind === 11 /* SyntaxKind.StringLiteral */
                ? factory.createAssignment(factory.createElementAccessExpression(factory.createIdentifier("exports"), factory.createStringLiteral(nextId.text)), prev)
                : factory.createAssignment(factory.createPropertyAccessExpression(factory.createIdentifier("exports"), factory.createIdentifier((0, ts_js_1.idText)(nextId))), prev), factory.createVoidZero())));
        }
        for (const f of currentModuleInfo.exportedFunctions) {
            appendExportsOfHoistedDeclaration(statements, f);
        }
        // Visit each statement of the module body.
        (0, ts_js_1.append)(statements, (0, ts_js_1.visitNode)(currentModuleInfo.externalHelpersImportDeclaration, topLevelVisitor, ts_js_1.isStatement));
        if (moduleKind === ts_js_1.ModuleKind.AMD) {
            (0, ts_js_1.addRange)(statements, (0, ts_js_1.mapDefined)(currentModuleInfo.externalImports, getAMDImportExpressionForImport));
        }
        (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(node.statements, topLevelVisitor, ts_js_1.isStatement, statementOffset));
        // Append the 'export =' statement if provided.
        addExportEqualsIfNeeded(statements, /*emitAsReturn*/ true);
        // End the lexical environment for the module body
        // and merge any new lexical declarations.
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        const body = factory.createBlock(statements, /*multiLine*/ true);
        if (needUMDDynamicImportHelper) {
            (0, ts_js_1.addEmitHelper)(body, dynamicImportUMDHelper);
        }
        return body;
    }
    /**
     * Adds the down-level representation of `export=` to the statement list if one exists
     * in the source file.
     *
     * @param statements The Statement list to modify.
     * @param emitAsReturn A value indicating whether to emit the `export=` statement as a
     * return statement.
     */
    function addExportEqualsIfNeeded(statements, emitAsReturn) {
        if (currentModuleInfo.exportEquals) {
            const expressionResult = (0, ts_js_1.visitNode)(currentModuleInfo.exportEquals.expression, visitor, ts_js_1.isExpression);
            if (expressionResult) {
                if (emitAsReturn) {
                    const statement = factory.createReturnStatement(expressionResult);
                    (0, ts_js_1.setTextRange)(statement, currentModuleInfo.exportEquals);
                    (0, ts_js_1.setEmitFlags)(statement, 768 /* EmitFlags.NoTokenSourceMaps */ | 3072 /* EmitFlags.NoComments */);
                    statements.push(statement);
                }
                else {
                    const statement = factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(factory.createIdentifier("module"), "exports"), expressionResult));
                    (0, ts_js_1.setTextRange)(statement, currentModuleInfo.exportEquals);
                    (0, ts_js_1.setEmitFlags)(statement, 3072 /* EmitFlags.NoComments */);
                    statements.push(statement);
                }
            }
        }
    }
    //
    // Top-Level Source Element Visitors
    //
    /**
     * Visits a node at the top level of the source file.
     *
     * @param node The node to visit.
     */
    function topLevelVisitor(node) {
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
                return visitTopLevelImportDeclaration(node);
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                return visitTopLevelImportEqualsDeclaration(node);
            case 279 /* SyntaxKind.ExportDeclaration */:
                return visitTopLevelExportDeclaration(node);
            case 278 /* SyntaxKind.ExportAssignment */:
                return visitTopLevelExportAssignment(node);
            default:
                return topLevelNestedVisitor(node);
        }
    }
    /**
     * Visit nested elements at the top-level of a module.
     *
     * @param node The node to visit.
     */
    function topLevelNestedVisitor(node) {
        switch (node.kind) {
            case 244 /* SyntaxKind.VariableStatement */:
                return visitVariableStatement(node);
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return visitFunctionDeclaration(node);
            case 264 /* SyntaxKind.ClassDeclaration */:
                return visitClassDeclaration(node);
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node, /*isTopLevel*/ true);
            case 250 /* SyntaxKind.ForInStatement */:
                return visitForInStatement(node);
            case 251 /* SyntaxKind.ForOfStatement */:
                return visitForOfStatement(node);
            case 247 /* SyntaxKind.DoStatement */:
                return visitDoStatement(node);
            case 248 /* SyntaxKind.WhileStatement */:
                return visitWhileStatement(node);
            case 257 /* SyntaxKind.LabeledStatement */:
                return visitLabeledStatement(node);
            case 255 /* SyntaxKind.WithStatement */:
                return visitWithStatement(node);
            case 246 /* SyntaxKind.IfStatement */:
                return visitIfStatement(node);
            case 256 /* SyntaxKind.SwitchStatement */:
                return visitSwitchStatement(node);
            case 270 /* SyntaxKind.CaseBlock */:
                return visitCaseBlock(node);
            case 297 /* SyntaxKind.CaseClause */:
                return visitCaseClause(node);
            case 298 /* SyntaxKind.DefaultClause */:
                return visitDefaultClause(node);
            case 259 /* SyntaxKind.TryStatement */:
                return visitTryStatement(node);
            case 300 /* SyntaxKind.CatchClause */:
                return visitCatchClause(node);
            case 242 /* SyntaxKind.Block */:
                return visitBlock(node);
            default:
                return visitor(node);
        }
    }
    function visitorWorker(node, valueIsDiscarded) {
        // This visitor does not need to descend into the tree if there is no dynamic import, destructuring assignment, or update expression
        // as export/import statements are only transformed at the top level of a file.
        if (!(node.transformFlags & (8388608 /* TransformFlags.ContainsDynamicImport */ | 4096 /* TransformFlags.ContainsDestructuringAssignment */ | 268435456 /* TransformFlags.ContainsUpdateExpressionForIdentifier */)) && !importsAndRequiresToRewriteOrShim?.length) {
            return node;
        }
        switch (node.kind) {
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node, /*isTopLevel*/ false);
            case 245 /* SyntaxKind.ExpressionStatement */:
                return visitExpressionStatement(node);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                return visitParenthesizedExpression(node, valueIsDiscarded);
            case 356 /* SyntaxKind.PartiallyEmittedExpression */:
                return visitPartiallyEmittedExpression(node, valueIsDiscarded);
            case 214 /* SyntaxKind.CallExpression */:
                const needsRewrite = node === (0, ts_js_1.firstOrUndefined)(importsAndRequiresToRewriteOrShim);
                if (needsRewrite) {
                    importsAndRequiresToRewriteOrShim.shift();
                }
                if ((0, ts_js_1.isImportCall)(node) && host.shouldTransformImportCall(currentSourceFile)) {
                    return visitImportCallExpression(node, needsRewrite);
                }
                else if (needsRewrite) {
                    return shimOrRewriteImportOrRequireCall(node);
                }
                break;
            case 227 /* SyntaxKind.BinaryExpression */:
                if ((0, ts_js_1.isDestructuringAssignment)(node)) {
                    return visitDestructuringAssignment(node, valueIsDiscarded);
                }
                break;
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                return visitPreOrPostfixUnaryExpression(node, valueIsDiscarded);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitor(node) {
        return visitorWorker(node, /*valueIsDiscarded*/ false);
    }
    function discardedValueVisitor(node) {
        return visitorWorker(node, /*valueIsDiscarded*/ true);
    }
    function destructuringNeedsFlattening(node) {
        if ((0, ts_js_1.isObjectLiteralExpression)(node)) {
            for (const elem of node.properties) {
                switch (elem.kind) {
                    case 304 /* SyntaxKind.PropertyAssignment */:
                        if (destructuringNeedsFlattening(elem.initializer)) {
                            return true;
                        }
                        break;
                    case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
                        if (destructuringNeedsFlattening(elem.name)) {
                            return true;
                        }
                        break;
                    case 306 /* SyntaxKind.SpreadAssignment */:
                        if (destructuringNeedsFlattening(elem.expression)) {
                            return true;
                        }
                        break;
                    case 175 /* SyntaxKind.MethodDeclaration */:
                    case 178 /* SyntaxKind.GetAccessor */:
                    case 179 /* SyntaxKind.SetAccessor */:
                        return false;
                    default:
                        ts_js_1.Debug.assertNever(elem, "Unhandled object member kind");
                }
            }
        }
        else if ((0, ts_js_1.isArrayLiteralExpression)(node)) {
            for (const elem of node.elements) {
                if ((0, ts_js_1.isSpreadElement)(elem)) {
                    if (destructuringNeedsFlattening(elem.expression)) {
                        return true;
                    }
                }
                else if (destructuringNeedsFlattening(elem)) {
                    return true;
                }
            }
        }
        else if ((0, ts_js_1.isIdentifier)(node)) {
            return (0, ts_js_1.length)(getExports(node)) > ((0, ts_js_1.isExportName)(node) ? 1 : 0);
        }
        return false;
    }
    function visitDestructuringAssignment(node, valueIsDiscarded) {
        if (destructuringNeedsFlattening(node.left)) {
            return (0, ts_js_1.flattenDestructuringAssignment)(node, visitor, context, 0 /* FlattenLevel.All */, !valueIsDiscarded, createAllExportExpressions);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitForStatement(node, isTopLevel) {
        if (isTopLevel && node.initializer &&
            (0, ts_js_1.isVariableDeclarationList)(node.initializer) &&
            !(node.initializer.flags & 7 /* NodeFlags.BlockScoped */)) {
            const exportStatements = appendExportsOfVariableDeclarationList(/*statements*/ undefined, node.initializer, /*isForInOrOfInitializer*/ false);
            if (exportStatements) {
                const statements = [];
                const varDeclList = (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isVariableDeclarationList);
                const varStatement = factory.createVariableStatement(/*modifiers*/ undefined, varDeclList);
                statements.push(varStatement);
                (0, ts_js_1.addRange)(statements, exportStatements);
                const condition = (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression);
                const incrementor = (0, ts_js_1.visitNode)(node.incrementor, discardedValueVisitor, ts_js_1.isExpression);
                const body = (0, ts_js_1.visitIterationBody)(node.statement, isTopLevel ? topLevelNestedVisitor : visitor, context);
                statements.push(factory.updateForStatement(node, /*initializer*/ undefined, condition, incrementor, body));
                return statements;
            }
        }
        return factory.updateForStatement(node, (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, discardedValueVisitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, isTopLevel ? topLevelNestedVisitor : visitor, context));
    }
    /**
     * Visits the body of a ForInStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitForInStatement(node) {
        if ((0, ts_js_1.isVariableDeclarationList)(node.initializer) && !(node.initializer.flags & 7 /* NodeFlags.BlockScoped */)) {
            const exportStatements = appendExportsOfVariableDeclarationList(/*statements*/ undefined, node.initializer, /*isForInOrOfInitializer*/ true);
            if ((0, ts_js_1.some)(exportStatements)) {
                const initializer = (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer);
                const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
                const body = (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context);
                const mergedBody = (0, ts_js_1.isBlock)(body) ?
                    factory.updateBlock(body, [...exportStatements, ...body.statements]) :
                    factory.createBlock([...exportStatements, body], /*multiLine*/ true);
                return factory.updateForInStatement(node, initializer, expression, mergedBody);
            }
        }
        return factory.updateForInStatement(node, (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
    }
    /**
     * Visits the body of a ForOfStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitForOfStatement(node) {
        if ((0, ts_js_1.isVariableDeclarationList)(node.initializer) && !(node.initializer.flags & 7 /* NodeFlags.BlockScoped */)) {
            const exportStatements = appendExportsOfVariableDeclarationList(/*statements*/ undefined, node.initializer, /*isForInOrOfInitializer*/ true);
            const initializer = (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer);
            const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
            let body = (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context);
            if ((0, ts_js_1.some)(exportStatements)) {
                body = (0, ts_js_1.isBlock)(body) ?
                    factory.updateBlock(body, [...exportStatements, ...body.statements]) :
                    factory.createBlock([...exportStatements, body], /*multiLine*/ true);
            }
            return factory.updateForOfStatement(node, node.awaitModifier, initializer, expression, body);
        }
        return factory.updateForOfStatement(node, node.awaitModifier, (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
    }
    /**
     * Visits the body of a DoStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitDoStatement(node) {
        return factory.updateDoStatement(node, (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression));
    }
    /**
     * Visits the body of a WhileStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitWhileStatement(node) {
        return factory.updateWhileStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
    }
    /**
     * Visits the body of a LabeledStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitLabeledStatement(node) {
        return factory.updateLabeledStatement(node, node.label, (0, ts_js_1.visitNode)(node.statement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock) ?? (0, ts_js_1.setTextRange)(factory.createEmptyStatement(), node.statement));
    }
    /**
     * Visits the body of a WithStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitWithStatement(node) {
        return factory.updateWithStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.statement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock)));
    }
    /**
     * Visits the body of a IfStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitIfStatement(node) {
        return factory.updateIfStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.thenStatement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock) ?? factory.createBlock([]), (0, ts_js_1.visitNode)(node.elseStatement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock));
    }
    /**
     * Visits the body of a SwitchStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitSwitchStatement(node) {
        return factory.updateSwitchStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.caseBlock, topLevelNestedVisitor, ts_js_1.isCaseBlock)));
    }
    /**
     * Visits the body of a CaseBlock to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCaseBlock(node) {
        return factory.updateCaseBlock(node, (0, ts_js_1.visitNodes)(node.clauses, topLevelNestedVisitor, ts_js_1.isCaseOrDefaultClause));
    }
    /**
     * Visits the body of a CaseClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCaseClause(node) {
        return factory.updateCaseClause(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNodes)(node.statements, topLevelNestedVisitor, ts_js_1.isStatement));
    }
    /**
     * Visits the body of a DefaultClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitDefaultClause(node) {
        return (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
    }
    /**
     * Visits the body of a TryStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitTryStatement(node) {
        return (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
    }
    /**
     * Visits the body of a CatchClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCatchClause(node) {
        return factory.updateCatchClause(node, node.variableDeclaration, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.block, topLevelNestedVisitor, ts_js_1.isBlock)));
    }
    /**
     * Visits the body of a Block to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitBlock(node) {
        node = (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
        return node;
    }
    function visitExpressionStatement(node) {
        return factory.updateExpressionStatement(node, (0, ts_js_1.visitNode)(node.expression, discardedValueVisitor, ts_js_1.isExpression));
    }
    function visitParenthesizedExpression(node, valueIsDiscarded) {
        return factory.updateParenthesizedExpression(node, (0, ts_js_1.visitNode)(node.expression, valueIsDiscarded ? discardedValueVisitor : visitor, ts_js_1.isExpression));
    }
    function visitPartiallyEmittedExpression(node, valueIsDiscarded) {
        return factory.updatePartiallyEmittedExpression(node, (0, ts_js_1.visitNode)(node.expression, valueIsDiscarded ? discardedValueVisitor : visitor, ts_js_1.isExpression));
    }
    function visitPreOrPostfixUnaryExpression(node, valueIsDiscarded) {
        // When we see a prefix or postfix increment expression whose operand is an exported
        // symbol, we should ensure all exports of that symbol are updated with the correct
        // value.
        //
        // - We do not transform generated identifiers for any reason.
        // - We do not transform identifiers tagged with the LocalName flag.
        // - We do not transform identifiers that were originally the name of an enum or
        //   namespace due to how they are transformed in TypeScript.
        // - We only transform identifiers that are exported at the top level.
        if ((node.operator === 46 /* SyntaxKind.PlusPlusToken */ || node.operator === 47 /* SyntaxKind.MinusMinusToken */)
            && (0, ts_js_1.isIdentifier)(node.operand)
            && !(0, ts_js_1.isGeneratedIdentifier)(node.operand)
            && !(0, ts_js_1.isLocalName)(node.operand)
            && !(0, ts_js_1.isDeclarationNameOfEnumOrNamespace)(node.operand)) {
            const exportedNames = getExports(node.operand);
            if (exportedNames) {
                let temp;
                let expression = (0, ts_js_1.visitNode)(node.operand, visitor, ts_js_1.isExpression);
                if ((0, ts_js_1.isPrefixUnaryExpression)(node)) {
                    expression = factory.updatePrefixUnaryExpression(node, expression);
                }
                else {
                    expression = factory.updatePostfixUnaryExpression(node, expression);
                    if (!valueIsDiscarded) {
                        temp = factory.createTempVariable(hoistVariableDeclaration);
                        expression = factory.createAssignment(temp, expression);
                        (0, ts_js_1.setTextRange)(expression, node);
                    }
                    expression = factory.createComma(expression, factory.cloneNode(node.operand));
                    (0, ts_js_1.setTextRange)(expression, node);
                }
                for (const exportName of exportedNames) {
                    noSubstitution[(0, ts_js_1.getNodeId)(expression)] = true;
                    expression = createExportExpression(exportName, expression);
                    (0, ts_js_1.setTextRange)(expression, node);
                }
                if (temp) {
                    noSubstitution[(0, ts_js_1.getNodeId)(expression)] = true;
                    expression = factory.createComma(expression, temp);
                    (0, ts_js_1.setTextRange)(expression, node);
                }
                return expression;
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function shimOrRewriteImportOrRequireCall(node) {
        return factory.updateCallExpression(node, node.expression, 
        /*typeArguments*/ undefined, (0, ts_js_1.visitNodes)(node.arguments, (arg) => {
            if (arg === node.arguments[0]) {
                return (0, ts_js_1.isStringLiteralLike)(arg)
                    ? (0, ts_js_1.rewriteModuleSpecifier)(arg, compilerOptions)
                    : emitHelpers().createRewriteRelativeImportExtensionsHelper(arg);
            }
            return visitor(arg);
        }, ts_js_1.isExpression));
    }
    function visitImportCallExpression(node, rewriteOrShim) {
        if (moduleKind === ts_js_1.ModuleKind.None && languageVersion >= 7 /* ScriptTarget.ES2020 */) {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        const externalModuleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, node, currentSourceFile, host, resolver, compilerOptions);
        const firstArgument = (0, ts_js_1.visitNode)((0, ts_js_1.firstOrUndefined)(node.arguments), visitor, ts_js_1.isExpression);
        // Only use the external module name if it differs from the first argument. This allows us to preserve the quote style of the argument on output.
        const argument = externalModuleName && (!firstArgument || !(0, ts_js_1.isStringLiteral)(firstArgument) || firstArgument.text !== externalModuleName.text)
            ? externalModuleName
            : firstArgument && rewriteOrShim
                ? (0, ts_js_1.isStringLiteral)(firstArgument) ? (0, ts_js_1.rewriteModuleSpecifier)(firstArgument, compilerOptions) : emitHelpers().createRewriteRelativeImportExtensionsHelper(firstArgument)
                : firstArgument;
        const containsLexicalThis = !!(node.transformFlags & 16384 /* TransformFlags.ContainsLexicalThis */);
        switch (compilerOptions.module) {
            case ts_js_1.ModuleKind.AMD:
                return createImportCallExpressionAMD(argument, containsLexicalThis);
            case ts_js_1.ModuleKind.UMD:
                return createImportCallExpressionUMD(argument ?? factory.createVoidZero(), containsLexicalThis);
            case ts_js_1.ModuleKind.CommonJS:
            default:
                return createImportCallExpressionCommonJS(argument);
        }
    }
    function createImportCallExpressionUMD(arg, containsLexicalThis) {
        // (function (factory) {
        //      ... (regular UMD)
        // }
        // })(function (require, exports, useSyncRequire) {
        //      "use strict";
        //      Object.defineProperty(exports, "__esModule", { value: true });
        //      var __syncRequire = typeof module === "object" && typeof module.exports === "object";
        //      var __resolved = new Promise(function (resolve) { resolve(); });
        //      .....
        //      __syncRequire
        //          ? __resolved.then(function () { return require(x); }) /*CommonJs Require*/
        //          : new Promise(function (_a, _b) { require([x], _a, _b); }); /*Amd Require*/
        // });
        needUMDDynamicImportHelper = true;
        if ((0, ts_js_1.isSimpleCopiableExpression)(arg)) {
            const argClone = (0, ts_js_1.isGeneratedIdentifier)(arg) ? arg : (0, ts_js_1.isStringLiteral)(arg) ? factory.createStringLiteralFromNode(arg) : (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.cloneNode(arg), arg), 3072 /* EmitFlags.NoComments */);
            return factory.createConditionalExpression(
            /*condition*/ factory.createIdentifier("__syncRequire"), 
            /*questionToken*/ undefined, 
            /*whenTrue*/ createImportCallExpressionCommonJS(arg), 
            /*colonToken*/ undefined, 
            /*whenFalse*/ createImportCallExpressionAMD(argClone, containsLexicalThis));
        }
        else {
            const temp = factory.createTempVariable(hoistVariableDeclaration);
            return factory.createComma(factory.createAssignment(temp, arg), factory.createConditionalExpression(
            /*condition*/ factory.createIdentifier("__syncRequire"), 
            /*questionToken*/ undefined, 
            /*whenTrue*/ createImportCallExpressionCommonJS(temp, /*isInlineable*/ true), 
            /*colonToken*/ undefined, 
            /*whenFalse*/ createImportCallExpressionAMD(temp, containsLexicalThis)));
        }
    }
    function createImportCallExpressionAMD(arg, containsLexicalThis) {
        // improt("./blah")
        // emit as
        // define(["require", "exports", "blah"], function (require, exports) {
        //     ...
        //     new Promise(function (_a, _b) { require([x], _a, _b); }); /*Amd Require*/
        // });
        const resolve = factory.createUniqueName("resolve");
        const reject = factory.createUniqueName("reject");
        const parameters = [
            factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, /*name*/ resolve),
            factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, /*name*/ reject),
        ];
        const body = factory.createBlock([
            factory.createExpressionStatement(factory.createCallExpression(factory.createIdentifier("require"), 
            /*typeArguments*/ undefined, [factory.createArrayLiteralExpression([arg || factory.createOmittedExpression()]), resolve, reject])),
        ]);
        let func;
        if (languageVersion >= 2 /* ScriptTarget.ES2015 */) {
            func = factory.createArrowFunction(
            /*modifiers*/ undefined, 
            /*typeParameters*/ undefined, parameters, 
            /*type*/ undefined, 
            /*equalsGreaterThanToken*/ undefined, body);
        }
        else {
            func = factory.createFunctionExpression(
            /*modifiers*/ undefined, 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, parameters, 
            /*type*/ undefined, body);
            // if there is a lexical 'this' in the import call arguments, ensure we indicate
            // that this new function expression indicates it captures 'this' so that the
            // es2015 transformer will properly substitute 'this' with '_this'.
            if (containsLexicalThis) {
                (0, ts_js_1.setEmitFlags)(func, 16 /* EmitFlags.CapturesThis */);
            }
        }
        const promise = factory.createNewExpression(factory.createIdentifier("Promise"), /*typeArguments*/ undefined, [func]);
        if ((0, ts_js_1.getESModuleInterop)(compilerOptions)) {
            return factory.createCallExpression(factory.createPropertyAccessExpression(promise, factory.createIdentifier("then")), /*typeArguments*/ undefined, [emitHelpers().createImportStarCallbackHelper()]);
        }
        return promise;
    }
    function createImportCallExpressionCommonJS(arg, isInlineable) {
        // import(x)
        // emit as
        // Promise.resolve(`${x}`).then((s) => require(s)) /*CommonJs Require*/
        // We have to wrap require in then callback so that require is done in asynchronously
        // if we simply do require in resolve callback in Promise constructor. We will execute the loading immediately
        // If the arg is not inlineable, we have to evaluate and ToString() it in the current scope
        // Otherwise, we inline it in require() so that it's statically analyzable
        const needSyncEval = arg && !(0, ts_js_1.isSimpleInlineableExpression)(arg) && !isInlineable;
        const promiseResolveCall = factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("Promise"), "resolve"), 
        /*typeArguments*/ undefined, 
        /*argumentsArray*/ needSyncEval
            ? languageVersion >= 2 /* ScriptTarget.ES2015 */
                ? [
                    factory.createTemplateExpression(factory.createTemplateHead(""), [
                        factory.createTemplateSpan(arg, factory.createTemplateTail("")),
                    ]),
                ]
                : [
                    factory.createCallExpression(factory.createPropertyAccessExpression(factory.createStringLiteral(""), "concat"), 
                    /*typeArguments*/ undefined, [arg]),
                ]
            : []);
        let requireCall = factory.createCallExpression(factory.createIdentifier("require"), 
        /*typeArguments*/ undefined, needSyncEval ? [factory.createIdentifier("s")] : arg ? [arg] : []);
        if ((0, ts_js_1.getESModuleInterop)(compilerOptions)) {
            requireCall = emitHelpers().createImportStarHelper(requireCall);
        }
        const parameters = needSyncEval
            ? [
                factory.createParameterDeclaration(
                /*modifiers*/ undefined, 
                /*dotDotDotToken*/ undefined, 
                /*name*/ "s"),
            ]
            : [];
        let func;
        if (languageVersion >= 2 /* ScriptTarget.ES2015 */) {
            func = factory.createArrowFunction(
            /*modifiers*/ undefined, 
            /*typeParameters*/ undefined, 
            /*parameters*/ parameters, 
            /*type*/ undefined, 
            /*equalsGreaterThanToken*/ undefined, requireCall);
        }
        else {
            func = factory.createFunctionExpression(
            /*modifiers*/ undefined, 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, 
            /*parameters*/ parameters, 
            /*type*/ undefined, factory.createBlock([factory.createReturnStatement(requireCall)]));
        }
        const downleveledImport = factory.createCallExpression(factory.createPropertyAccessExpression(promiseResolveCall, "then"), /*typeArguments*/ undefined, [func]);
        return downleveledImport;
    }
    function getHelperExpressionForExport(node, innerExpr) {
        if (!(0, ts_js_1.getESModuleInterop)(compilerOptions) || (0, ts_js_1.getInternalEmitFlags)(node) & 2 /* InternalEmitFlags.NeverApplyImportHelper */) {
            return innerExpr;
        }
        if ((0, ts_js_1.getExportNeedsImportStarHelper)(node)) {
            return emitHelpers().createImportStarHelper(innerExpr);
        }
        return innerExpr;
    }
    function getHelperExpressionForImport(node, innerExpr) {
        if (!(0, ts_js_1.getESModuleInterop)(compilerOptions) || (0, ts_js_1.getInternalEmitFlags)(node) & 2 /* InternalEmitFlags.NeverApplyImportHelper */) {
            return innerExpr;
        }
        if ((0, ts_js_1.getImportNeedsImportStarHelper)(node)) {
            return emitHelpers().createImportStarHelper(innerExpr);
        }
        if ((0, ts_js_1.getImportNeedsImportDefaultHelper)(node)) {
            return emitHelpers().createImportDefaultHelper(innerExpr);
        }
        return innerExpr;
    }
    /**
     * Visits an ImportDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitTopLevelImportDeclaration(node) {
        let statements;
        const namespaceDeclaration = (0, ts_js_1.getNamespaceDeclarationNode)(node);
        if (moduleKind !== ts_js_1.ModuleKind.AMD) {
            if (!node.importClause) {
                // import "mod";
                return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(createRequireCall(node)), node), node);
            }
            else {
                const variables = [];
                if (namespaceDeclaration && !(0, ts_js_1.isDefaultImport)(node)) {
                    // import * as n from "mod";
                    variables.push(factory.createVariableDeclaration(factory.cloneNode(namespaceDeclaration.name), 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, getHelperExpressionForImport(node, createRequireCall(node))));
                }
                else {
                    // import d from "mod";
                    // import { x, y } from "mod";
                    // import d, { x, y } from "mod";
                    // import d, * as n from "mod";
                    variables.push(factory.createVariableDeclaration(factory.getGeneratedNameForNode(node), 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, getHelperExpressionForImport(node, createRequireCall(node))));
                    if (namespaceDeclaration && (0, ts_js_1.isDefaultImport)(node)) {
                        variables.push(factory.createVariableDeclaration(factory.cloneNode(namespaceDeclaration.name), 
                        /*exclamationToken*/ undefined, 
                        /*type*/ undefined, factory.getGeneratedNameForNode(node)));
                    }
                }
                statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList(variables, languageVersion >= 2 /* ScriptTarget.ES2015 */ ? 2 /* NodeFlags.Const */ : 0 /* NodeFlags.None */)), 
                /*location*/ node), 
                /*original*/ node));
            }
        }
        else if (namespaceDeclaration && (0, ts_js_1.isDefaultImport)(node)) {
            // import d, * as n from "mod";
            statements = (0, ts_js_1.append)(statements, factory.createVariableStatement(
            /*modifiers*/ undefined, factory.createVariableDeclarationList([
                (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableDeclaration(factory.cloneNode(namespaceDeclaration.name), 
                /*exclamationToken*/ undefined, 
                /*type*/ undefined, factory.getGeneratedNameForNode(node)), 
                /*location*/ node), 
                /*original*/ node),
            ], languageVersion >= 2 /* ScriptTarget.ES2015 */ ? 2 /* NodeFlags.Const */ : 0 /* NodeFlags.None */)));
        }
        statements = appendExportsOfImportDeclaration(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Creates a `require()` call to import an external module.
     *
     * @param importNode The declararation to import.
     */
    function createRequireCall(importNode) {
        const moduleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, importNode, currentSourceFile, host, resolver, compilerOptions);
        const args = [];
        if (moduleName) {
            args.push((0, ts_js_1.rewriteModuleSpecifier)(moduleName, compilerOptions));
        }
        return factory.createCallExpression(factory.createIdentifier("require"), /*typeArguments*/ undefined, args);
    }
    /**
     * Visits an ImportEqualsDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitTopLevelImportEqualsDeclaration(node) {
        ts_js_1.Debug.assert((0, ts_js_1.isExternalModuleImportEqualsDeclaration)(node), "import= for internal module references should be handled in an earlier transformer.");
        let statements;
        if (moduleKind !== ts_js_1.ModuleKind.AMD) {
            if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
                statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(createExportExpression(node.name, createRequireCall(node))), node), node));
            }
            else {
                statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList([
                    factory.createVariableDeclaration(factory.cloneNode(node.name), 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, createRequireCall(node)),
                ], 
                /*flags*/ languageVersion >= 2 /* ScriptTarget.ES2015 */ ? 2 /* NodeFlags.Const */ : 0 /* NodeFlags.None */)), node), node));
            }
        }
        else {
            if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
                statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(createExportExpression(factory.getExportName(node), factory.getLocalName(node))), node), node));
            }
        }
        statements = appendExportsOfImportEqualsDeclaration(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Visits an ExportDeclaration node.
     *
     * @param The node to visit.
     */
    function visitTopLevelExportDeclaration(node) {
        if (!node.moduleSpecifier) {
            // Elide export declarations with no module specifier as they are handled
            // elsewhere.
            return undefined;
        }
        const generatedName = factory.getGeneratedNameForNode(node);
        if (node.exportClause && (0, ts_js_1.isNamedExports)(node.exportClause)) {
            const statements = [];
            // export { x, y } from "mod";
            if (moduleKind !== ts_js_1.ModuleKind.AMD) {
                statements.push((0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList([
                    factory.createVariableDeclaration(generatedName, 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, createRequireCall(node)),
                ])), 
                /*location*/ node), 
                /* original */ node));
            }
            for (const specifier of node.exportClause.elements) {
                const specifierName = specifier.propertyName || specifier.name;
                const exportNeedsImportDefault = !!(0, ts_js_1.getESModuleInterop)(compilerOptions) &&
                    !((0, ts_js_1.getInternalEmitFlags)(node) & 2 /* InternalEmitFlags.NeverApplyImportHelper */) &&
                    (0, ts_js_1.moduleExportNameIsDefault)(specifierName);
                const target = exportNeedsImportDefault ? emitHelpers().createImportDefaultHelper(generatedName) : generatedName;
                const exportedValue = specifierName.kind === 11 /* SyntaxKind.StringLiteral */
                    ? factory.createElementAccessExpression(target, specifierName)
                    : factory.createPropertyAccessExpression(target, specifierName);
                statements.push((0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(createExportExpression(specifier.name.kind === 11 /* SyntaxKind.StringLiteral */ ? factory.cloneNode(specifier.name) : factory.getExportName(specifier), exportedValue, 
                /*location*/ undefined, 
                /*liveBinding*/ true)), specifier), specifier));
            }
            return (0, ts_js_1.singleOrMany)(statements);
        }
        else if (node.exportClause) {
            const statements = [];
            // export * as ns from "mod";
            // export * as default from "mod";
            statements.push((0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(createExportExpression(factory.cloneNode(node.exportClause.name), getHelperExpressionForExport(node, moduleKind !== ts_js_1.ModuleKind.AMD ?
                createRequireCall(node) :
                (0, ts_js_1.isExportNamespaceAsDefaultDeclaration)(node) ? generatedName :
                    node.exportClause.name.kind === 11 /* SyntaxKind.StringLiteral */ ? generatedName :
                        factory.createIdentifier((0, ts_js_1.idText)(node.exportClause.name))))), node), node));
            return (0, ts_js_1.singleOrMany)(statements);
        }
        else {
            // export * from "mod";
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(emitHelpers().createExportStarHelper(moduleKind !== ts_js_1.ModuleKind.AMD ? createRequireCall(node) : generatedName)), node), node);
        }
    }
    /**
     * Visits an ExportAssignment node.
     *
     * @param node The node to visit.
     */
    function visitTopLevelExportAssignment(node) {
        if (node.isExportEquals) {
            return undefined;
        }
        return createExportStatement(factory.createIdentifier("default"), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), /*location*/ node, /*allowComments*/ true);
    }
    /**
     * Visits a FunctionDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitFunctionDeclaration(node) {
        let statements;
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createFunctionDeclaration((0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), node.asteriskToken, factory.getDeclarationName(node, /*allowComments*/ true, /*allowSourceMaps*/ true), 
            /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter), 
            /*type*/ undefined, (0, ts_js_1.visitEachChild)(node.body, visitor, context)), 
            /*location*/ node), 
            /*original*/ node));
        }
        else {
            statements = (0, ts_js_1.append)(statements, (0, ts_js_1.visitEachChild)(node, visitor, context));
        }
        // NOTE: CommonJS/AMD/UMD exports are hoisted to the top of the module body and do not need to be added here.
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Visits a ClassDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitClassDeclaration(node) {
        let statements;
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createClassDeclaration((0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifierLike), factory.getDeclarationName(node, /*allowComments*/ true, /*allowSourceMaps*/ true), 
            /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause), (0, ts_js_1.visitNodes)(node.members, visitor, ts_js_1.isClassElement)), node), node));
        }
        else {
            statements = (0, ts_js_1.append)(statements, (0, ts_js_1.visitEachChild)(node, visitor, context));
        }
        statements = appendExportsOfHoistedDeclaration(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Visits a VariableStatement node.
     *
     * @param node The node to visit.
     */
    function visitVariableStatement(node) {
        let statements;
        let variables;
        let expressions;
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            let modifiers;
            let removeCommentsOnExpressions = false;
            // If we're exporting these variables, then these just become assignments to 'exports.x'.
            for (const variable of node.declarationList.declarations) {
                if ((0, ts_js_1.isIdentifier)(variable.name) && (0, ts_js_1.isLocalName)(variable.name)) {
                    // A "local name" generally means a variable declaration that *shouldn't* be
                    // converted to `exports.x = ...`, even if the declaration is exported. This
                    // usually indicates a class or function declaration that was converted into
                    // a variable declaration, as most references to the declaration will remain
                    // untransformed (i.e., `new C` rather than `new exports.C`). In these cases,
                    // an `export { x }` declaration will follow.
                    if (!modifiers) {
                        modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier);
                    }
                    if (variable.initializer) {
                        const updatedVariable = factory.updateVariableDeclaration(variable, variable.name, 
                        /*exclamationToken*/ undefined, 
                        /*type*/ undefined, createExportExpression(variable.name, (0, ts_js_1.visitNode)(variable.initializer, visitor, ts_js_1.isExpression)));
                        variables = (0, ts_js_1.append)(variables, updatedVariable);
                    }
                    else {
                        variables = (0, ts_js_1.append)(variables, variable);
                    }
                }
                else if (variable.initializer) {
                    if (!(0, ts_js_1.isBindingPattern)(variable.name) && ((0, ts_js_1.isArrowFunction)(variable.initializer) || (0, ts_js_1.isFunctionExpression)(variable.initializer) || (0, ts_js_1.isClassExpression)(variable.initializer))) {
                        const expression = factory.createAssignment((0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createIdentifier("exports"), variable.name), 
                        /*location*/ variable.name), factory.createIdentifier((0, ts_js_1.getTextOfIdentifierOrLiteral)(variable.name)));
                        const updatedVariable = factory.createVariableDeclaration(variable.name, variable.exclamationToken, variable.type, (0, ts_js_1.visitNode)(variable.initializer, visitor, ts_js_1.isExpression));
                        variables = (0, ts_js_1.append)(variables, updatedVariable);
                        expressions = (0, ts_js_1.append)(expressions, expression);
                        removeCommentsOnExpressions = true;
                    }
                    else {
                        expressions = (0, ts_js_1.append)(expressions, transformInitializedVariable(variable));
                    }
                }
            }
            if (variables) {
                statements = (0, ts_js_1.append)(statements, factory.updateVariableStatement(node, modifiers, factory.updateVariableDeclarationList(node.declarationList, variables)));
            }
            if (expressions) {
                const statement = (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.inlineExpressions(expressions)), node), node);
                if (removeCommentsOnExpressions) {
                    (0, ts_js_1.removeAllComments)(statement);
                }
                statements = (0, ts_js_1.append)(statements, statement);
            }
        }
        else {
            statements = (0, ts_js_1.append)(statements, (0, ts_js_1.visitEachChild)(node, visitor, context));
        }
        statements = appendExportsOfVariableStatement(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    function createAllExportExpressions(name, value, location) {
        const exportedNames = getExports(name);
        if (exportedNames) {
            // For each additional export of the declaration, apply an export assignment.
            let expression = (0, ts_js_1.isExportName)(name) ? value : factory.createAssignment(name, value);
            for (const exportName of exportedNames) {
                // Mark the node to prevent triggering substitution.
                (0, ts_js_1.setEmitFlags)(expression, 8 /* EmitFlags.NoSubstitution */);
                expression = createExportExpression(exportName, expression, /*location*/ location);
            }
            return expression;
        }
        return factory.createAssignment(name, value);
    }
    /**
     * Transforms an exported variable with an initializer into an expression.
     *
     * @param node The node to transform.
     */
    function transformInitializedVariable(node) {
        if ((0, ts_js_1.isBindingPattern)(node.name)) {
            return (0, ts_js_1.flattenDestructuringAssignment)((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isInitializedVariable), visitor, context, 0 /* FlattenLevel.All */, 
            /*needsValue*/ false, createAllExportExpressions);
        }
        else {
            return factory.createAssignment((0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createIdentifier("exports"), node.name), 
            /*location*/ node.name), node.initializer ? (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression) : factory.createVoidZero());
        }
    }
    /**
     * Appends the exports of an ImportDeclaration to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfImportDeclaration(statements, decl) {
        if (currentModuleInfo.exportEquals) {
            return statements;
        }
        const importClause = decl.importClause;
        if (!importClause) {
            return statements;
        }
        const seen = new ts_js_1.IdentifierNameMap();
        if (importClause.name) {
            statements = appendExportsOfDeclaration(statements, seen, importClause);
        }
        const namedBindings = importClause.namedBindings;
        if (namedBindings) {
            switch (namedBindings.kind) {
                case 275 /* SyntaxKind.NamespaceImport */:
                    statements = appendExportsOfDeclaration(statements, seen, namedBindings);
                    break;
                case 276 /* SyntaxKind.NamedImports */:
                    for (const importBinding of namedBindings.elements) {
                        statements = appendExportsOfDeclaration(statements, seen, importBinding, /*liveBinding*/ true);
                    }
                    break;
            }
        }
        return statements;
    }
    /**
     * Appends the exports of an ImportEqualsDeclaration to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfImportEqualsDeclaration(statements, decl) {
        if (currentModuleInfo.exportEquals) {
            return statements;
        }
        return appendExportsOfDeclaration(statements, new ts_js_1.IdentifierNameMap(), decl);
    }
    /**
     * Appends the exports of a VariableStatement to a statement list, returning the statement
     * list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param node The VariableStatement whose exports are to be recorded.
     */
    function appendExportsOfVariableStatement(statements, node) {
        return appendExportsOfVariableDeclarationList(statements, node.declarationList, /*isForInOrOfInitializer*/ false);
    }
    /**
     * Appends the exports of a VariableDeclarationList to a statement list, returning the statement
     * list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param node The VariableDeclarationList whose exports are to be recorded.
     */
    function appendExportsOfVariableDeclarationList(statements, node, isForInOrOfInitializer) {
        if (currentModuleInfo.exportEquals) {
            return statements;
        }
        for (const decl of node.declarations) {
            statements = appendExportsOfBindingElement(statements, decl, isForInOrOfInitializer);
        }
        return statements;
    }
    /**
     * Appends the exports of a VariableDeclaration or BindingElement to a statement list,
     * returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfBindingElement(statements, decl, isForInOrOfInitializer) {
        if (currentModuleInfo.exportEquals) {
            return statements;
        }
        if ((0, ts_js_1.isBindingPattern)(decl.name)) {
            for (const element of decl.name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    statements = appendExportsOfBindingElement(statements, element, isForInOrOfInitializer);
                }
            }
        }
        else if (!(0, ts_js_1.isGeneratedIdentifier)(decl.name) && (!(0, ts_js_1.isVariableDeclaration)(decl) || decl.initializer || isForInOrOfInitializer)) {
            statements = appendExportsOfDeclaration(statements, new ts_js_1.IdentifierNameMap(), decl);
        }
        return statements;
    }
    /**
     * Appends the exports of a ClassDeclaration or FunctionDeclaration to a statement list,
     * returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfHoistedDeclaration(statements, decl) {
        if (currentModuleInfo.exportEquals) {
            return statements;
        }
        const seen = new ts_js_1.IdentifierNameMap();
        if ((0, ts_js_1.hasSyntacticModifier)(decl, 32 /* ModifierFlags.Export */)) {
            const exportName = (0, ts_js_1.hasSyntacticModifier)(decl, 2048 /* ModifierFlags.Default */) ? factory.createIdentifier("default") : factory.getDeclarationName(decl);
            statements = appendExportStatement(statements, seen, exportName, factory.getLocalName(decl), /*location*/ decl);
        }
        if (decl.name) {
            statements = appendExportsOfDeclaration(statements, seen, decl);
        }
        return statements;
    }
    /**
     * Appends the exports of a declaration to a statement list, returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration to export.
     */
    function appendExportsOfDeclaration(statements, seen, decl, liveBinding) {
        const name = factory.getDeclarationName(decl);
        const exportSpecifiers = currentModuleInfo.exportSpecifiers.get(name);
        if (exportSpecifiers) {
            for (const exportSpecifier of exportSpecifiers) {
                statements = appendExportStatement(statements, seen, exportSpecifier.name, name, /*location*/ exportSpecifier.name, /*allowComments*/ undefined, liveBinding);
            }
        }
        return statements;
    }
    /**
     * Appends the down-level representation of an export to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param exportName The name of the export.
     * @param expression The expression to export.
     * @param location The location to use for source maps and comments for the export.
     * @param allowComments Whether to allow comments on the export.
     */
    function appendExportStatement(statements, seen, exportName, expression, location, allowComments, liveBinding) {
        if (exportName.kind !== 11 /* SyntaxKind.StringLiteral */) {
            if (seen.has(exportName)) {
                return statements;
            }
            seen.set(exportName, true);
        }
        statements = (0, ts_js_1.append)(statements, createExportStatement(exportName, expression, location, allowComments, liveBinding));
        return statements;
    }
    function createUnderscoreUnderscoreESModule() {
        const statement = factory.createExpressionStatement(factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("Object"), "defineProperty"), 
        /*typeArguments*/ undefined, [
            factory.createIdentifier("exports"),
            factory.createStringLiteral("__esModule"),
            factory.createObjectLiteralExpression([
                factory.createPropertyAssignment("value", factory.createTrue()),
            ]),
        ]));
        (0, ts_js_1.setEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
        return statement;
    }
    /**
     * Creates a call to the current file's export function to export a value.
     *
     * @param name The bound name of the export.
     * @param value The exported value.
     * @param location The location to use for source maps and comments for the export.
     * @param allowComments An optional value indicating whether to emit comments for the statement.
     */
    function createExportStatement(name, value, location, allowComments, liveBinding) {
        const statement = (0, ts_js_1.setTextRange)(factory.createExpressionStatement(createExportExpression(name, value, /*location*/ undefined, liveBinding)), location);
        (0, ts_js_1.startOnNewLine)(statement);
        if (!allowComments) {
            (0, ts_js_1.setEmitFlags)(statement, 3072 /* EmitFlags.NoComments */);
        }
        return statement;
    }
    /**
     * Creates a call to the current file's export function to export a value.
     *
     * @param name The bound name of the export.
     * @param value The exported value.
     * @param location The location to use for source maps and comments for the export.
     */
    function createExportExpression(name, value, location, liveBinding) {
        return (0, ts_js_1.setTextRange)(liveBinding ? factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("Object"), "defineProperty"), 
        /*typeArguments*/ undefined, [
            factory.createIdentifier("exports"),
            factory.createStringLiteralFromNode(name),
            factory.createObjectLiteralExpression([
                factory.createPropertyAssignment("enumerable", factory.createTrue()),
                factory.createPropertyAssignment("get", factory.createFunctionExpression(
                /*modifiers*/ undefined, 
                /*asteriskToken*/ undefined, 
                /*name*/ undefined, 
                /*typeParameters*/ undefined, 
                /*parameters*/ [], 
                /*type*/ undefined, factory.createBlock([factory.createReturnStatement(value)]))),
            ]),
        ]) : factory.createAssignment(name.kind === 11 /* SyntaxKind.StringLiteral */
            ? factory.createElementAccessExpression(factory.createIdentifier("exports"), factory.cloneNode(name))
            : factory.createPropertyAccessExpression(factory.createIdentifier("exports"), factory.cloneNode(name)), value), location);
    }
    //
    // Modifier Visitors
    //
    /**
     * Visit nodes to elide module-specific modifiers.
     *
     * @param node The node to visit.
     */
    function modifierVisitor(node) {
        // Elide module-specific modifiers.
        switch (node.kind) {
            case 95 /* SyntaxKind.ExportKeyword */:
            case 90 /* SyntaxKind.DefaultKeyword */:
                return undefined;
        }
        return node;
    }
    //
    // Emit Notification
    //
    /**
     * Hook for node emit notifications.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emit A callback used to emit the node in the printer.
     */
    function onEmitNode(hint, node, emitCallback) {
        if (node.kind === 308 /* SyntaxKind.SourceFile */) {
            currentSourceFile = node;
            currentModuleInfo = moduleInfoMap[(0, ts_js_1.getOriginalNodeId)(currentSourceFile)];
            previousOnEmitNode(hint, node, emitCallback);
            currentSourceFile = undefined;
            currentModuleInfo = undefined;
        }
        else {
            previousOnEmitNode(hint, node, emitCallback);
        }
    }
    //
    // Substitutions
    //
    /**
     * Hooks node substitutions.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (node.id && noSubstitution[node.id]) {
            return node;
        }
        if (hint === 1 /* EmitHint.Expression */) {
            return substituteExpression(node);
        }
        else if ((0, ts_js_1.isShorthandPropertyAssignment)(node)) {
            return substituteShorthandPropertyAssignment(node);
        }
        return node;
    }
    /**
     * Substitution for a ShorthandPropertyAssignment whose declaration name is an imported
     * or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteShorthandPropertyAssignment(node) {
        const name = node.name;
        const exportedOrImportedName = substituteExpressionIdentifier(name);
        if (exportedOrImportedName !== name) {
            // A shorthand property with an assignment initializer is probably part of a
            // destructuring assignment
            if (node.objectAssignmentInitializer) {
                const initializer = factory.createAssignment(exportedOrImportedName, node.objectAssignmentInitializer);
                return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(name, initializer), node);
            }
            return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(name, exportedOrImportedName), node);
        }
        return node;
    }
    /**
     * Substitution for an Expression that may contain an imported or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteExpression(node) {
        switch (node.kind) {
            case 80 /* SyntaxKind.Identifier */:
                return substituteExpressionIdentifier(node);
            case 214 /* SyntaxKind.CallExpression */:
                return substituteCallExpression(node);
            case 216 /* SyntaxKind.TaggedTemplateExpression */:
                return substituteTaggedTemplateExpression(node);
            case 227 /* SyntaxKind.BinaryExpression */:
                return substituteBinaryExpression(node);
        }
        return node;
    }
    function substituteCallExpression(node) {
        if ((0, ts_js_1.isIdentifier)(node.expression)) {
            const expression = substituteExpressionIdentifier(node.expression);
            noSubstitution[(0, ts_js_1.getNodeId)(expression)] = true;
            if (!(0, ts_js_1.isIdentifier)(expression) && !((0, ts_js_1.getEmitFlags)(node.expression) & 8192 /* EmitFlags.HelperName */)) {
                return (0, ts_js_1.addInternalEmitFlags)(factory.updateCallExpression(node, expression, /*typeArguments*/ undefined, node.arguments), 16 /* InternalEmitFlags.IndirectCall */);
            }
        }
        return node;
    }
    function substituteTaggedTemplateExpression(node) {
        if ((0, ts_js_1.isIdentifier)(node.tag)) {
            const tag = substituteExpressionIdentifier(node.tag);
            noSubstitution[(0, ts_js_1.getNodeId)(tag)] = true;
            if (!(0, ts_js_1.isIdentifier)(tag) && !((0, ts_js_1.getEmitFlags)(node.tag) & 8192 /* EmitFlags.HelperName */)) {
                return (0, ts_js_1.addInternalEmitFlags)(factory.updateTaggedTemplateExpression(node, tag, /*typeArguments*/ undefined, node.template), 16 /* InternalEmitFlags.IndirectCall */);
            }
        }
        return node;
    }
    /**
     * Substitution for an Identifier expression that may contain an imported or exported
     * symbol.
     *
     * @param node The node to substitute.
     */
    function substituteExpressionIdentifier(node) {
        if ((0, ts_js_1.getEmitFlags)(node) & 8192 /* EmitFlags.HelperName */) {
            const externalHelpersModuleName = (0, ts_js_1.getExternalHelpersModuleName)(currentSourceFile);
            if (externalHelpersModuleName) {
                return factory.createPropertyAccessExpression(externalHelpersModuleName, node);
            }
            return node;
        }
        else if (!((0, ts_js_1.isGeneratedIdentifier)(node) && !(node.emitNode.autoGenerate.flags & 64 /* GeneratedIdentifierFlags.AllowNameSubstitution */)) && !(0, ts_js_1.isLocalName)(node)) {
            const exportContainer = resolver.getReferencedExportContainer(node, (0, ts_js_1.isExportName)(node));
            if (exportContainer && exportContainer.kind === 308 /* SyntaxKind.SourceFile */) {
                return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createIdentifier("exports"), factory.cloneNode(node)), 
                /*location*/ node);
            }
            const importDeclaration = resolver.getReferencedImportDeclaration(node);
            if (importDeclaration) {
                if ((0, ts_js_1.isImportClause)(importDeclaration)) {
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.getGeneratedNameForNode(importDeclaration.parent), factory.createIdentifier("default")), 
                    /*location*/ node);
                }
                else if ((0, ts_js_1.isImportSpecifier)(importDeclaration)) {
                    const name = importDeclaration.propertyName || importDeclaration.name;
                    const target = factory.getGeneratedNameForNode(importDeclaration.parent?.parent?.parent || importDeclaration);
                    return (0, ts_js_1.setTextRange)(name.kind === 11 /* SyntaxKind.StringLiteral */
                        ? factory.createElementAccessExpression(target, factory.cloneNode(name))
                        : factory.createPropertyAccessExpression(target, factory.cloneNode(name)), 
                    /*location*/ node);
                }
            }
        }
        return node;
    }
    /**
     * Substitution for a BinaryExpression that may contain an imported or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteBinaryExpression(node) {
        // When we see an assignment expression whose left-hand side is an exported symbol,
        // we should ensure all exports of that symbol are updated with the correct value.
        //
        // - We do not substitute generated identifiers unless they are file-level reserved names.
        // - We do not substitute identifiers tagged with the LocalName flag.
        // - We only substitute identifiers that are exported at the top level.
        if ((0, ts_js_1.isAssignmentOperator)(node.operatorToken.kind)
            && (0, ts_js_1.isIdentifier)(node.left)
            && (!(0, ts_js_1.isGeneratedIdentifier)(node.left) || (0, ts_js_1.isFileLevelReservedGeneratedIdentifier)(node.left))
            && !(0, ts_js_1.isLocalName)(node.left)) {
            const exportedNames = getExports(node.left);
            if (exportedNames) {
                // For each additional export of the declaration, apply an export assignment.
                let expression = node;
                for (const exportName of exportedNames) {
                    // Mark the node to prevent triggering this rule again.
                    noSubstitution[(0, ts_js_1.getNodeId)(expression)] = true;
                    expression = createExportExpression(exportName, expression, /*location*/ node);
                }
                return expression;
            }
        }
        return node;
    }
    /**
     * Gets the additional exports of a name.
     *
     * @param name The name.
     */
    function getExports(name) {
        if (!(0, ts_js_1.isGeneratedIdentifier)(name)) {
            const importDeclaration = resolver.getReferencedImportDeclaration(name);
            if (importDeclaration) {
                return currentModuleInfo?.exportedBindings[(0, ts_js_1.getOriginalNodeId)(importDeclaration)];
            }
            // An exported namespace or enum may merge with an ambient declaration, which won't show up in .js emit, so
            // we analyze all value exports of a symbol.
            const bindingsSet = new Set();
            const declarations = resolver.getReferencedValueDeclarations(name);
            if (declarations) {
                for (const declaration of declarations) {
                    const bindings = currentModuleInfo?.exportedBindings[(0, ts_js_1.getOriginalNodeId)(declaration)];
                    if (bindings) {
                        for (const binding of bindings) {
                            bindingsSet.add(binding);
                        }
                    }
                }
                if (bindingsSet.size) {
                    return (0, ts_js_1.arrayFrom)(bindingsSet);
                }
            }
        }
        else if ((0, ts_js_1.isFileLevelReservedGeneratedIdentifier)(name)) {
            const exportSpecifiers = currentModuleInfo?.exportSpecifiers.get(name);
            if (exportSpecifiers) {
                const exportedNames = [];
                for (const exportSpecifier of exportSpecifiers) {
                    exportedNames.push(exportSpecifier.name);
                }
                return exportedNames;
            }
        }
    }
}
// emit helper for dynamic import
const dynamicImportUMDHelper = {
    name: "typescript:dynamicimport-sync-require",
    scoped: true,
    text: `
            var __syncRequire = typeof module === "object" && typeof module.exports === "object";`,
};
