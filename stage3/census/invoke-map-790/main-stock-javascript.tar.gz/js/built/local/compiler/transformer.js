"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.nullTransformationContext = exports.noTransformers = void 0;
exports.getTransformers = getTransformers;
exports.noEmitSubstitution = noEmitSubstitution;
exports.noEmitNotification = noEmitNotification;
exports.transformNodes = transformNodes;
const ts_js_1 = require("./_namespaces/ts.js");
const performance = __importStar(require("./_namespaces/ts.performance.js"));
function getModuleTransformer(moduleKind) {
    switch (moduleKind) {
        case ts_js_1.ModuleKind.Preserve:
            // `transformECMAScriptModule` contains logic for preserving
            // CJS input syntax in `--module preserve`
            return ts_js_1.transformECMAScriptModule;
        case ts_js_1.ModuleKind.ESNext:
        case ts_js_1.ModuleKind.ES2022:
        case ts_js_1.ModuleKind.ES2020:
        case ts_js_1.ModuleKind.ES2015:
        case ts_js_1.ModuleKind.Node16:
        case ts_js_1.ModuleKind.Node18:
        case ts_js_1.ModuleKind.Node20:
        case ts_js_1.ModuleKind.NodeNext:
        case ts_js_1.ModuleKind.CommonJS:
            // Wraps `transformModule` and `transformECMAScriptModule` and
            // selects between them based on the `impliedNodeFormat` of the
            // source file.
            return ts_js_1.transformImpliedNodeFormatDependentModule;
        case ts_js_1.ModuleKind.System:
            return ts_js_1.transformSystemModule;
        default:
            return ts_js_1.transformModule;
    }
}
var TransformationState;
(function (TransformationState) {
    TransformationState[TransformationState["Uninitialized"] = 0] = "Uninitialized";
    TransformationState[TransformationState["Initialized"] = 1] = "Initialized";
    TransformationState[TransformationState["Completed"] = 2] = "Completed";
    TransformationState[TransformationState["Disposed"] = 3] = "Disposed";
})(TransformationState || (TransformationState = {}));
var SyntaxKindFeatureFlags;
(function (SyntaxKindFeatureFlags) {
    SyntaxKindFeatureFlags[SyntaxKindFeatureFlags["Substitution"] = 1] = "Substitution";
    SyntaxKindFeatureFlags[SyntaxKindFeatureFlags["EmitNotifications"] = 2] = "EmitNotifications";
})(SyntaxKindFeatureFlags || (SyntaxKindFeatureFlags = {}));
/** @internal */
exports.noTransformers = { scriptTransformers: ts_js_1.emptyArray, declarationTransformers: ts_js_1.emptyArray };
/** @internal */
function getTransformers(compilerOptions, customTransformers, emitOnly) {
    return {
        scriptTransformers: getScriptTransformers(compilerOptions, customTransformers, emitOnly),
        declarationTransformers: getDeclarationTransformers(customTransformers),
    };
}
function getScriptTransformers(compilerOptions, customTransformers, emitOnly) {
    if (emitOnly)
        return ts_js_1.emptyArray;
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const moduleKind = (0, ts_js_1.getEmitModuleKind)(compilerOptions);
    const useDefineForClassFields = (0, ts_js_1.getUseDefineForClassFields)(compilerOptions);
    const transformers = [];
    (0, ts_js_1.addRange)(transformers, customTransformers && (0, ts_js_1.map)(customTransformers.before, wrapScriptTransformerFactory));
    transformers.push(ts_js_1.transformTypeScript);
    if (compilerOptions.experimentalDecorators) {
        transformers.push(ts_js_1.transformLegacyDecorators);
    }
    if ((0, ts_js_1.getJSXTransformEnabled)(compilerOptions)) {
        transformers.push(ts_js_1.transformJsx);
    }
    if (languageVersion < 99 /* ScriptTarget.ESNext */) {
        transformers.push(ts_js_1.transformESNext);
    }
    if (!compilerOptions.experimentalDecorators && (languageVersion < 99 /* ScriptTarget.ESNext */ || !useDefineForClassFields)) {
        transformers.push(ts_js_1.transformESDecorators);
    }
    transformers.push(ts_js_1.transformClassFields);
    if (languageVersion < 8 /* ScriptTarget.ES2021 */) {
        transformers.push(ts_js_1.transformES2021);
    }
    if (languageVersion < 7 /* ScriptTarget.ES2020 */) {
        transformers.push(ts_js_1.transformES2020);
    }
    if (languageVersion < 6 /* ScriptTarget.ES2019 */) {
        transformers.push(ts_js_1.transformES2019);
    }
    if (languageVersion < 5 /* ScriptTarget.ES2018 */) {
        transformers.push(ts_js_1.transformES2018);
    }
    if (languageVersion < 4 /* ScriptTarget.ES2017 */) {
        transformers.push(ts_js_1.transformES2017);
    }
    if (languageVersion < 3 /* ScriptTarget.ES2016 */) {
        transformers.push(ts_js_1.transformES2016);
    }
    if (languageVersion < 2 /* ScriptTarget.ES2015 */) {
        transformers.push(ts_js_1.transformES2015);
        transformers.push(ts_js_1.transformGenerators);
    }
    transformers.push(getModuleTransformer(moduleKind));
    (0, ts_js_1.addRange)(transformers, customTransformers && (0, ts_js_1.map)(customTransformers.after, wrapScriptTransformerFactory));
    return transformers;
}
function getDeclarationTransformers(customTransformers) {
    const transformers = [];
    transformers.push(ts_js_1.transformDeclarations);
    (0, ts_js_1.addRange)(transformers, customTransformers && (0, ts_js_1.map)(customTransformers.afterDeclarations, wrapDeclarationTransformerFactory));
    return transformers;
}
/**
 * Wrap a custom script or declaration transformer object in a `Transformer` callback with fallback support for transforming bundles.
 */
function wrapCustomTransformer(transformer) {
    return node => (0, ts_js_1.isBundle)(node) ? transformer.transformBundle(node) : transformer.transformSourceFile(node);
}
/**
 * Wrap a transformer factory that may return a custom script or declaration transformer object.
 */
function wrapCustomTransformerFactory(transformer, handleDefault) {
    return context => {
        const customTransformer = transformer(context);
        return typeof customTransformer === "function"
            ? handleDefault(context, customTransformer)
            : wrapCustomTransformer(customTransformer);
    };
}
function wrapScriptTransformerFactory(transformer) {
    return wrapCustomTransformerFactory(transformer, ts_js_1.chainBundle);
}
function wrapDeclarationTransformerFactory(transformer) {
    return wrapCustomTransformerFactory(transformer, (_, node) => node);
}
/** @internal */
function noEmitSubstitution(_hint, node) {
    return node;
}
/** @internal */
function noEmitNotification(hint, node, callback) {
    callback(hint, node);
}
/**
 * Transforms an array of SourceFiles by passing them through each transformer.
 *
 * @param resolver The emit resolver provided by the checker.
 * @param host The emit host object used to interact with the file system.
 * @param options Compiler options to surface in the `TransformationContext`.
 * @param nodes An array of nodes to transform.
 * @param transforms An array of `TransformerFactory` callbacks.
 * @param allowDtsFiles A value indicating whether to allow the transformation of .d.ts files.
 *
 * @internal
 */
function transformNodes(resolver, host, factory, options, nodes, transformers, allowDtsFiles) {
    const enabledSyntaxKindFeatures = new Array(359 /* SyntaxKind.Count */);
    let lexicalEnvironmentVariableDeclarations;
    let lexicalEnvironmentFunctionDeclarations;
    let lexicalEnvironmentStatements;
    let lexicalEnvironmentFlags = 0 /* LexicalEnvironmentFlags.None */;
    let lexicalEnvironmentVariableDeclarationsStack = [];
    let lexicalEnvironmentFunctionDeclarationsStack = [];
    let lexicalEnvironmentStatementsStack = [];
    let lexicalEnvironmentFlagsStack = [];
    let lexicalEnvironmentStackOffset = 0;
    let lexicalEnvironmentSuspended = false;
    let blockScopedVariableDeclarationsStack = [];
    let blockScopeStackOffset = 0;
    let blockScopedVariableDeclarations;
    let emitHelpers;
    let onSubstituteNode = noEmitSubstitution;
    let onEmitNode = noEmitNotification;
    let state = 0 /* TransformationState.Uninitialized */;
    const diagnostics = [];
    // The transformation context is provided to each transformer as part of transformer
    // initialization.
    const context = {
        factory,
        getCompilerOptions: () => options,
        getEmitResolver: () => resolver, // TODO: GH#18217
        getEmitHost: () => host, // TODO: GH#18217
        getEmitHelperFactory: (0, ts_js_1.memoize)(() => (0, ts_js_1.createEmitHelperFactory)(context)),
        startLexicalEnvironment,
        suspendLexicalEnvironment,
        resumeLexicalEnvironment,
        endLexicalEnvironment,
        setLexicalEnvironmentFlags,
        getLexicalEnvironmentFlags,
        hoistVariableDeclaration,
        hoistFunctionDeclaration,
        addInitializationStatement,
        startBlockScope,
        endBlockScope,
        addBlockScopedVariable,
        requestEmitHelper,
        readEmitHelpers,
        enableSubstitution,
        enableEmitNotification,
        isSubstitutionEnabled,
        isEmitNotificationEnabled,
        get onSubstituteNode() {
            return onSubstituteNode;
        },
        set onSubstituteNode(value) {
            ts_js_1.Debug.assert(state < 1 /* TransformationState.Initialized */, "Cannot modify transformation hooks after initialization has completed.");
            ts_js_1.Debug.assert(value !== undefined, "Value must not be 'undefined'");
            onSubstituteNode = value;
        },
        get onEmitNode() {
            return onEmitNode;
        },
        set onEmitNode(value) {
            ts_js_1.Debug.assert(state < 1 /* TransformationState.Initialized */, "Cannot modify transformation hooks after initialization has completed.");
            ts_js_1.Debug.assert(value !== undefined, "Value must not be 'undefined'");
            onEmitNode = value;
        },
        addDiagnostic(diag) {
            diagnostics.push(diag);
        },
    };
    // Ensure the parse tree is clean before applying transformations
    for (const node of nodes) {
        (0, ts_js_1.disposeEmitNodes)((0, ts_js_1.getSourceFileOfNode)((0, ts_js_1.getParseTreeNode)(node)));
    }
    performance.mark("beforeTransform");
    // Chain together and initialize each transformer.
    const transformersWithContext = transformers.map(t => t(context));
    const transformation = (node) => {
        for (const transform of transformersWithContext) {
            node = transform(node);
        }
        return node;
    };
    // prevent modification of transformation hooks.
    state = 1 /* TransformationState.Initialized */;
    // Transform each node.
    const transformed = [];
    for (const node of nodes) {
        ts_js_1.tracing?.push("emit" /* tracing.Phase.Emit */, "transformNodes", node.kind === 308 /* SyntaxKind.SourceFile */ ? { path: node.path } : { kind: node.kind, pos: node.pos, end: node.end });
        transformed.push((allowDtsFiles ? transformation : transformRoot)(node));
        ts_js_1.tracing?.pop();
    }
    // prevent modification of the lexical environment.
    state = 2 /* TransformationState.Completed */;
    performance.mark("afterTransform");
    performance.measure("transformTime", "beforeTransform", "afterTransform");
    return {
        transformed,
        substituteNode,
        emitNodeWithNotification,
        isEmitNotificationEnabled,
        dispose,
        diagnostics,
    };
    function transformRoot(node) {
        return node && (!(0, ts_js_1.isSourceFile)(node) || !node.isDeclarationFile) ? transformation(node) : node;
    }
    /**
     * Enables expression substitutions in the pretty printer for the provided SyntaxKind.
     */
    function enableSubstitution(kind) {
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the transformation context after transformation has completed.");
        enabledSyntaxKindFeatures[kind] = (enabledSyntaxKindFeatures[kind] ?? 0) | 1 /* SyntaxKindFeatureFlags.Substitution */;
    }
    /**
     * Determines whether expression substitutions are enabled for the provided node.
     */
    function isSubstitutionEnabled(node) {
        return ((enabledSyntaxKindFeatures[node.kind] ?? 0) & 1 /* SyntaxKindFeatureFlags.Substitution */) !== 0
            && ((0, ts_js_1.getEmitFlags)(node) & 8 /* EmitFlags.NoSubstitution */) === 0;
    }
    /**
     * Emits a node with possible substitution.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emitCallback The callback used to emit the node or its substitute.
     */
    function substituteNode(hint, node) {
        ts_js_1.Debug.assert(state < 3 /* TransformationState.Disposed */, "Cannot substitute a node after the result is disposed.");
        return node && isSubstitutionEnabled(node) && onSubstituteNode(hint, node) || node;
    }
    /**
     * Enables before/after emit notifications in the pretty printer for the provided SyntaxKind.
     */
    function enableEmitNotification(kind) {
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the transformation context after transformation has completed.");
        enabledSyntaxKindFeatures[kind] = (enabledSyntaxKindFeatures[kind] ?? 0) | 2 /* SyntaxKindFeatureFlags.EmitNotifications */;
    }
    /**
     * Determines whether before/after emit notifications should be raised in the pretty
     * printer when it emits a node.
     */
    function isEmitNotificationEnabled(node) {
        return ((enabledSyntaxKindFeatures[node.kind] ?? 0) & 2 /* SyntaxKindFeatureFlags.EmitNotifications */) !== 0
            || ((0, ts_js_1.getEmitFlags)(node) & 4 /* EmitFlags.AdviseOnEmitNode */) !== 0;
    }
    /**
     * Emits a node with possible emit notification.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emitCallback The callback used to emit the node.
     */
    function emitNodeWithNotification(hint, node, emitCallback) {
        ts_js_1.Debug.assert(state < 3 /* TransformationState.Disposed */, "Cannot invoke TransformationResult callbacks after the result is disposed.");
        if (node) {
            // TODO: Remove check and unconditionally use onEmitNode when API is breakingly changed
            // (see https://github.com/microsoft/TypeScript/pull/36248/files/5062623f39120171b98870c71344b3242eb03d23#r369766739)
            if (isEmitNotificationEnabled(node)) {
                onEmitNode(hint, node, emitCallback);
            }
            else {
                emitCallback(hint, node);
            }
        }
    }
    /**
     * Records a hoisted variable declaration for the provided name within a lexical environment.
     */
    function hoistVariableDeclaration(name) {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        const decl = (0, ts_js_1.setEmitFlags)(factory.createVariableDeclaration(name), 128 /* EmitFlags.NoNestedSourceMaps */);
        if (!lexicalEnvironmentVariableDeclarations) {
            lexicalEnvironmentVariableDeclarations = [decl];
        }
        else {
            lexicalEnvironmentVariableDeclarations.push(decl);
        }
        if (lexicalEnvironmentFlags & 1 /* LexicalEnvironmentFlags.InParameters */) {
            lexicalEnvironmentFlags |= 2 /* LexicalEnvironmentFlags.VariablesHoistedInParameters */;
        }
    }
    /**
     * Records a hoisted function declaration within a lexical environment.
     */
    function hoistFunctionDeclaration(func) {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        (0, ts_js_1.setEmitFlags)(func, 2097152 /* EmitFlags.CustomPrologue */);
        if (!lexicalEnvironmentFunctionDeclarations) {
            lexicalEnvironmentFunctionDeclarations = [func];
        }
        else {
            lexicalEnvironmentFunctionDeclarations.push(func);
        }
    }
    /**
     * Adds an initialization statement to the top of the lexical environment.
     */
    function addInitializationStatement(node) {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        (0, ts_js_1.setEmitFlags)(node, 2097152 /* EmitFlags.CustomPrologue */);
        if (!lexicalEnvironmentStatements) {
            lexicalEnvironmentStatements = [node];
        }
        else {
            lexicalEnvironmentStatements.push(node);
        }
    }
    /**
     * Starts a new lexical environment. Any existing hoisted variable or function declarations
     * are pushed onto a stack, and the related storage variables are reset.
     */
    function startLexicalEnvironment() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        ts_js_1.Debug.assert(!lexicalEnvironmentSuspended, "Lexical environment is suspended.");
        // Save the current lexical environment. Rather than resizing the array we adjust the
        // stack size variable. This allows us to reuse existing array slots we've
        // already allocated between transformations to avoid allocation and GC overhead during
        // transformation.
        lexicalEnvironmentVariableDeclarationsStack[lexicalEnvironmentStackOffset] = lexicalEnvironmentVariableDeclarations;
        lexicalEnvironmentFunctionDeclarationsStack[lexicalEnvironmentStackOffset] = lexicalEnvironmentFunctionDeclarations;
        lexicalEnvironmentStatementsStack[lexicalEnvironmentStackOffset] = lexicalEnvironmentStatements;
        lexicalEnvironmentFlagsStack[lexicalEnvironmentStackOffset] = lexicalEnvironmentFlags;
        lexicalEnvironmentStackOffset++;
        lexicalEnvironmentVariableDeclarations = undefined;
        lexicalEnvironmentFunctionDeclarations = undefined;
        lexicalEnvironmentStatements = undefined;
        lexicalEnvironmentFlags = 0 /* LexicalEnvironmentFlags.None */;
    }
    /** Suspends the current lexical environment, usually after visiting a parameter list. */
    function suspendLexicalEnvironment() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        ts_js_1.Debug.assert(!lexicalEnvironmentSuspended, "Lexical environment is already suspended.");
        lexicalEnvironmentSuspended = true;
    }
    /** Resumes a suspended lexical environment, usually before visiting a function body. */
    function resumeLexicalEnvironment() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        ts_js_1.Debug.assert(lexicalEnvironmentSuspended, "Lexical environment is not suspended.");
        lexicalEnvironmentSuspended = false;
    }
    /**
     * Ends a lexical environment. The previous set of hoisted declarations are restored and
     * any hoisted declarations added in this environment are returned.
     */
    function endLexicalEnvironment() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the lexical environment during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the lexical environment after transformation has completed.");
        ts_js_1.Debug.assert(!lexicalEnvironmentSuspended, "Lexical environment is suspended.");
        let statements;
        if (lexicalEnvironmentVariableDeclarations ||
            lexicalEnvironmentFunctionDeclarations ||
            lexicalEnvironmentStatements) {
            if (lexicalEnvironmentFunctionDeclarations) {
                statements = [...lexicalEnvironmentFunctionDeclarations];
            }
            if (lexicalEnvironmentVariableDeclarations) {
                const statement = factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList(lexicalEnvironmentVariableDeclarations));
                (0, ts_js_1.setEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
                if (!statements) {
                    statements = [statement];
                }
                else {
                    statements.push(statement);
                }
            }
            if (lexicalEnvironmentStatements) {
                if (!statements) {
                    statements = [...lexicalEnvironmentStatements];
                }
                else {
                    statements = [...statements, ...lexicalEnvironmentStatements];
                }
            }
        }
        // Restore the previous lexical environment.
        lexicalEnvironmentStackOffset--;
        lexicalEnvironmentVariableDeclarations = lexicalEnvironmentVariableDeclarationsStack[lexicalEnvironmentStackOffset];
        lexicalEnvironmentFunctionDeclarations = lexicalEnvironmentFunctionDeclarationsStack[lexicalEnvironmentStackOffset];
        lexicalEnvironmentStatements = lexicalEnvironmentStatementsStack[lexicalEnvironmentStackOffset];
        lexicalEnvironmentFlags = lexicalEnvironmentFlagsStack[lexicalEnvironmentStackOffset];
        if (lexicalEnvironmentStackOffset === 0) {
            lexicalEnvironmentVariableDeclarationsStack = [];
            lexicalEnvironmentFunctionDeclarationsStack = [];
            lexicalEnvironmentStatementsStack = [];
            lexicalEnvironmentFlagsStack = [];
        }
        return statements;
    }
    function setLexicalEnvironmentFlags(flags, value) {
        lexicalEnvironmentFlags = value ?
            lexicalEnvironmentFlags | flags :
            lexicalEnvironmentFlags & ~flags;
    }
    function getLexicalEnvironmentFlags() {
        return lexicalEnvironmentFlags;
    }
    /**
     * Starts a block scope. Any existing block hoisted variables are pushed onto the stack and the related storage variables are reset.
     */
    function startBlockScope() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot start a block scope during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot start a block scope after transformation has completed.");
        blockScopedVariableDeclarationsStack[blockScopeStackOffset] = blockScopedVariableDeclarations;
        blockScopeStackOffset++;
        blockScopedVariableDeclarations = undefined;
    }
    /**
     * Ends a block scope. The previous set of block hoisted variables are restored. Any hoisted declarations are returned.
     */
    function endBlockScope() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot end a block scope during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot end a block scope after transformation has completed.");
        const statements = (0, ts_js_1.some)(blockScopedVariableDeclarations) ?
            [
                factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList(blockScopedVariableDeclarations.map(identifier => factory.createVariableDeclaration(identifier)), 1 /* NodeFlags.Let */)),
            ] : undefined;
        blockScopeStackOffset--;
        blockScopedVariableDeclarations = blockScopedVariableDeclarationsStack[blockScopeStackOffset];
        if (blockScopeStackOffset === 0) {
            blockScopedVariableDeclarationsStack = [];
        }
        return statements;
    }
    function addBlockScopedVariable(name) {
        ts_js_1.Debug.assert(blockScopeStackOffset > 0, "Cannot add a block scoped variable outside of an iteration body.");
        (blockScopedVariableDeclarations || (blockScopedVariableDeclarations = [])).push(name);
    }
    function requestEmitHelper(helper) {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the transformation context during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the transformation context after transformation has completed.");
        ts_js_1.Debug.assert(!helper.scoped, "Cannot request a scoped emit helper.");
        if (helper.dependencies) {
            for (const h of helper.dependencies) {
                requestEmitHelper(h);
            }
        }
        emitHelpers = (0, ts_js_1.append)(emitHelpers, helper);
    }
    function readEmitHelpers() {
        ts_js_1.Debug.assert(state > 0 /* TransformationState.Uninitialized */, "Cannot modify the transformation context during initialization.");
        ts_js_1.Debug.assert(state < 2 /* TransformationState.Completed */, "Cannot modify the transformation context after transformation has completed.");
        const helpers = emitHelpers;
        emitHelpers = undefined;
        return helpers;
    }
    function dispose() {
        if (state < 3 /* TransformationState.Disposed */) {
            // Clean up emit nodes on parse tree
            for (const node of nodes) {
                (0, ts_js_1.disposeEmitNodes)((0, ts_js_1.getSourceFileOfNode)((0, ts_js_1.getParseTreeNode)(node)));
            }
            // Release references to external entries for GC purposes.
            lexicalEnvironmentVariableDeclarations = undefined;
            lexicalEnvironmentVariableDeclarationsStack = undefined;
            lexicalEnvironmentFunctionDeclarations = undefined;
            lexicalEnvironmentFunctionDeclarationsStack = undefined;
            onSubstituteNode = undefined;
            onEmitNode = undefined;
            emitHelpers = undefined;
            // Prevent further use of the transformation result.
            state = 3 /* TransformationState.Disposed */;
        }
    }
}
/** @internal */
exports.nullTransformationContext = {
    factory: ts_js_1.factory, // eslint-disable-line object-shorthand
    getCompilerOptions: () => ({}),
    getEmitResolver: ts_js_1.notImplemented,
    getEmitHost: ts_js_1.notImplemented,
    getEmitHelperFactory: ts_js_1.notImplemented,
    startLexicalEnvironment: ts_js_1.noop,
    resumeLexicalEnvironment: ts_js_1.noop,
    suspendLexicalEnvironment: ts_js_1.noop,
    endLexicalEnvironment: ts_js_1.returnUndefined,
    setLexicalEnvironmentFlags: ts_js_1.noop,
    getLexicalEnvironmentFlags: () => 0,
    hoistVariableDeclaration: ts_js_1.noop,
    hoistFunctionDeclaration: ts_js_1.noop,
    addInitializationStatement: ts_js_1.noop,
    startBlockScope: ts_js_1.noop,
    endBlockScope: ts_js_1.returnUndefined,
    addBlockScopedVariable: ts_js_1.noop,
    requestEmitHelper: ts_js_1.noop,
    readEmitHelpers: ts_js_1.notImplemented,
    enableSubstitution: ts_js_1.noop,
    enableEmitNotification: ts_js_1.noop,
    isSubstitutionEnabled: ts_js_1.notImplemented,
    isEmitNotificationEnabled: ts_js_1.notImplemented,
    onSubstituteNode: noEmitSubstitution,
    onEmitNode: noEmitNotification,
    addDiagnostic: ts_js_1.noop,
};
