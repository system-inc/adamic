"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.visitNode = visitNode;
exports.visitNodes = visitNodes;
exports.visitArray = visitArray;
exports.visitLexicalEnvironment = visitLexicalEnvironment;
exports.visitParameterList = visitParameterList;
exports.visitFunctionBody = visitFunctionBody;
exports.visitIterationBody = visitIterationBody;
exports.visitCommaListElements = visitCommaListElements;
exports.visitEachChild = visitEachChild;
const ts_js_1 = require("./_namespaces/ts.js");
function visitNode(node, visitor, test, lift) {
    if (node === undefined) {
        // If the input type is undefined, then the output type can be undefined.
        return node;
    }
    const visited = visitor(node);
    let visitedNode;
    if (visited === undefined) {
        // If the visited node is undefined, then the visitor must have returned undefined,
        // so the visitor must have been declared as able to return undefined, so TOut must be
        // potentially undefined.
        return undefined;
    }
    else if ((0, ts_js_1.isArray)(visited)) {
        visitedNode = (lift || extractSingleNode)(visited);
    }
    else {
        visitedNode = visited;
    }
    ts_js_1.Debug.assertNode(visitedNode, test);
    return visitedNode;
}
function visitNodes(nodes, visitor, test, start, count) {
    if (nodes === undefined) {
        // If the input type is undefined, then the output type can be undefined.
        return nodes;
    }
    // Ensure start and count have valid values
    const length = nodes.length;
    if (start === undefined || start < 0) {
        start = 0;
    }
    if (count === undefined || count > length - start) {
        count = length - start;
    }
    let hasTrailingComma;
    let pos = -1;
    let end = -1;
    if (start > 0 || count < length) {
        // Since this is a fragment of a node array, we do not copy over the previous location
        // and will only copy over `hasTrailingComma` if we are including the last element.
        hasTrailingComma = nodes.hasTrailingComma && start + count === length;
    }
    else {
        pos = nodes.pos;
        end = nodes.end;
        hasTrailingComma = nodes.hasTrailingComma;
    }
    const updated = visitArrayWorker(nodes, visitor, test, start, count);
    if (updated !== nodes) {
        // TODO(rbuckton): Remove dependency on `ts.factory` in favor of a provided factory.
        const updatedArray = ts_js_1.factory.createNodeArray(updated, hasTrailingComma);
        (0, ts_js_1.setTextRangePosEnd)(updatedArray, pos, end);
        return updatedArray;
    }
    // If we are here, updated === nodes. This means that it's still a NodeArray,
    // and also that its contents passed the tests in visitArrayWorker, so has contents
    // of type TOut.
    return nodes;
}
function visitArray(nodes, visitor, test, start, count) {
    if (nodes === undefined) {
        // If the input type is undefined, then the output type can be undefined.
        return nodes;
    }
    // Ensure start and count have valid values
    const length = nodes.length;
    if (start === undefined || start < 0) {
        start = 0;
    }
    if (count === undefined || count > length - start) {
        count = length - start;
    }
    return visitArrayWorker(nodes, visitor, test, start, count);
}
function visitArrayWorker(nodes, visitor, test, start, count) {
    let updated;
    const length = nodes.length;
    if (start > 0 || count < length) {
        // If we are not visiting all of the original nodes, we must always create a new array.
        updated = [];
    }
    // Visit each original node.
    for (let i = 0; i < count; i++) {
        const node = nodes[i + start];
        const visited = node !== undefined ? (visitor ? visitor(node) : node) : undefined;
        if (updated !== undefined || visited === undefined || visited !== node) {
            if (updated === undefined) {
                // Ensure we have a copy of `nodes`, up to the current index.
                updated = nodes.slice(0, i);
                ts_js_1.Debug.assertEachNode(updated, test);
            }
            if (visited) {
                if ((0, ts_js_1.isArray)(visited)) {
                    for (const visitedNode of visited) {
                        ts_js_1.Debug.assertNode(visitedNode, test);
                        updated.push(visitedNode);
                    }
                }
                else {
                    ts_js_1.Debug.assertNode(visited, test);
                    updated.push(visited);
                }
            }
        }
    }
    if (updated) {
        // If we have an updated array, then all items will have been tested.
        return updated;
    }
    // If we are going to return the original array, ensure it passes the test.
    ts_js_1.Debug.assertEachNode(nodes, test);
    return nodes;
}
/**
 * Starts a new lexical environment and visits a statement list, ending the lexical environment
 * and merging hoisted declarations upon completion.
 */
function visitLexicalEnvironment(statements, visitor, context, start, ensureUseStrict, nodesVisitor = visitNodes) {
    context.startLexicalEnvironment();
    statements = nodesVisitor(statements, visitor, ts_js_1.isStatement, start);
    if (ensureUseStrict)
        statements = context.factory.ensureUseStrict(statements);
    return ts_js_1.factory.mergeLexicalEnvironment(statements, context.endLexicalEnvironment());
}
function visitParameterList(nodes, visitor, context, nodesVisitor = visitNodes) {
    let updated;
    context.startLexicalEnvironment();
    if (nodes) {
        context.setLexicalEnvironmentFlags(1 /* LexicalEnvironmentFlags.InParameters */, true);
        updated = nodesVisitor(nodes, visitor, ts_js_1.isParameter);
        // As of ES2015, any runtime execution of that occurs in for a parameter (such as evaluating an
        // initializer or a binding pattern), occurs in its own lexical scope. As a result, any expression
        // that we might transform that introduces a temporary variable would fail as the temporary variable
        // exists in a different lexical scope. To address this, we move any binding patterns and initializers
        // in a parameter list to the body if we detect a variable being hoisted while visiting a parameter list
        // when the emit target is greater than ES2015.
        if (context.getLexicalEnvironmentFlags() & 2 /* LexicalEnvironmentFlags.VariablesHoistedInParameters */ &&
            (0, ts_js_1.getEmitScriptTarget)(context.getCompilerOptions()) >= 2 /* ScriptTarget.ES2015 */) {
            updated = addDefaultValueAssignmentsIfNeeded(updated, context);
        }
        context.setLexicalEnvironmentFlags(1 /* LexicalEnvironmentFlags.InParameters */, false);
    }
    context.suspendLexicalEnvironment();
    return updated;
}
function addDefaultValueAssignmentsIfNeeded(parameters, context) {
    let result;
    for (let i = 0; i < parameters.length; i++) {
        const parameter = parameters[i];
        const updated = addDefaultValueAssignmentIfNeeded(parameter, context);
        if (result || updated !== parameter) {
            if (!result)
                result = parameters.slice(0, i);
            result[i] = updated;
        }
    }
    if (result) {
        return (0, ts_js_1.setTextRange)(context.factory.createNodeArray(result, parameters.hasTrailingComma), parameters);
    }
    return parameters;
}
function addDefaultValueAssignmentIfNeeded(parameter, context) {
    // A rest parameter cannot have a binding pattern or an initializer,
    // so let's just ignore it.
    return parameter.dotDotDotToken ? parameter :
        (0, ts_js_1.isBindingPattern)(parameter.name) ? addDefaultValueAssignmentForBindingPattern(parameter, context) :
            parameter.initializer ? addDefaultValueAssignmentForInitializer(parameter, parameter.name, parameter.initializer, context) :
                parameter;
}
function addDefaultValueAssignmentForBindingPattern(parameter, context) {
    const { factory } = context;
    context.addInitializationStatement(factory.createVariableStatement(
    /*modifiers*/ undefined, factory.createVariableDeclarationList([
        factory.createVariableDeclaration(parameter.name, 
        /*exclamationToken*/ undefined, parameter.type, parameter.initializer ?
            factory.createConditionalExpression(factory.createStrictEquality(factory.getGeneratedNameForNode(parameter), factory.createVoidZero()), 
            /*questionToken*/ undefined, parameter.initializer, 
            /*colonToken*/ undefined, factory.getGeneratedNameForNode(parameter)) :
            factory.getGeneratedNameForNode(parameter)),
    ])));
    return factory.updateParameterDeclaration(parameter, parameter.modifiers, parameter.dotDotDotToken, factory.getGeneratedNameForNode(parameter), parameter.questionToken, parameter.type, /*initializer*/ undefined);
}
function addDefaultValueAssignmentForInitializer(parameter, name, initializer, context) {
    const factory = context.factory;
    context.addInitializationStatement(factory.createIfStatement(factory.createTypeCheck(factory.cloneNode(name), "undefined"), (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createBlock([
        factory.createExpressionStatement((0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createAssignment((0, ts_js_1.setEmitFlags)(factory.cloneNode(name), 96 /* EmitFlags.NoSourceMap */), (0, ts_js_1.setEmitFlags)(initializer, 96 /* EmitFlags.NoSourceMap */ | (0, ts_js_1.getEmitFlags)(initializer) | 3072 /* EmitFlags.NoComments */)), parameter), 3072 /* EmitFlags.NoComments */)),
    ]), parameter), 1 /* EmitFlags.SingleLine */ | 64 /* EmitFlags.NoTrailingSourceMap */ | 768 /* EmitFlags.NoTokenSourceMaps */ | 3072 /* EmitFlags.NoComments */)));
    return factory.updateParameterDeclaration(parameter, parameter.modifiers, parameter.dotDotDotToken, parameter.name, parameter.questionToken, parameter.type, /*initializer*/ undefined);
}
function visitFunctionBody(node, visitor, context, nodeVisitor = visitNode) {
    context.resumeLexicalEnvironment();
    const updated = nodeVisitor(node, visitor, ts_js_1.isConciseBody);
    const declarations = context.endLexicalEnvironment();
    if ((0, ts_js_1.some)(declarations)) {
        if (!updated) {
            return context.factory.createBlock(declarations);
        }
        const block = context.factory.converters.convertToFunctionBlock(updated);
        const statements = ts_js_1.factory.mergeLexicalEnvironment(block.statements, declarations);
        return context.factory.updateBlock(block, statements);
    }
    return updated;
}
function visitIterationBody(body, visitor, context, nodeVisitor = visitNode) {
    context.startBlockScope();
    const updated = nodeVisitor(body, visitor, ts_js_1.isStatement, context.factory.liftToBlock);
    ts_js_1.Debug.assert(updated);
    const declarations = context.endBlockScope();
    if ((0, ts_js_1.some)(declarations)) {
        if ((0, ts_js_1.isBlock)(updated)) {
            declarations.push(...updated.statements);
            return context.factory.updateBlock(updated, declarations);
        }
        declarations.push(updated);
        return context.factory.createBlock(declarations);
    }
    return updated;
}
/**
 * Visits the elements of a {@link CommaListExpression}.
 * @param visitor The visitor to use when visiting expressions whose result will not be discarded at runtime.
 * @param discardVisitor The visitor to use when visiting expressions whose result will be discarded at runtime. Defaults to {@link visitor}.
 */
function visitCommaListElements(elements, visitor, discardVisitor = visitor) {
    if (discardVisitor === visitor || elements.length <= 1) {
        return visitNodes(elements, visitor, ts_js_1.isExpression);
    }
    let i = 0;
    const length = elements.length;
    return visitNodes(elements, node => {
        const discarded = i < length - 1;
        i++;
        return discarded ? discardVisitor(node) : visitor(node);
    }, ts_js_1.isExpression);
}
function visitEachChild(node, visitor, context = ts_js_1.nullTransformationContext, nodesVisitor = visitNodes, tokenVisitor, nodeVisitor = visitNode) {
    if (node === undefined) {
        return undefined;
    }
    const fn = visitEachChildTable[node.kind];
    return fn === undefined ? node : fn(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor);
}
// NOTE: Before you can add a new method to `visitEachChildTable`, you must first ensure the `Node` subtype you
//       wish to add is defined in the `HasChildren` union in types.ts.
const visitEachChildTable = {
    [167 /* SyntaxKind.QualifiedName */]: function visitEachChildOfQualifiedName(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateQualifiedName(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.left, visitor, ts_js_1.isEntityName)), ts_js_1.Debug.checkDefined(nodeVisitor(node.right, visitor, ts_js_1.isIdentifier)));
    },
    [168 /* SyntaxKind.ComputedPropertyName */]: function visitEachChildOfComputedPropertyName(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateComputedPropertyName(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    // Signature elements
    [169 /* SyntaxKind.TypeParameter */]: function visitEachChildOfTypeParameterDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeParameterDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), nodeVisitor(node.constraint, visitor, ts_js_1.isTypeNode), nodeVisitor(node.default, visitor, ts_js_1.isTypeNode));
    },
    [170 /* SyntaxKind.Parameter */]: function visitEachChildOfParameterDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateParameterDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), tokenVisitor ? nodeVisitor(node.dotDotDotToken, tokenVisitor, ts_js_1.isDotDotDotToken) : node.dotDotDotToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isBindingName)), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken) : node.questionToken, nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), nodeVisitor(node.initializer, visitor, ts_js_1.isExpression));
    },
    [171 /* SyntaxKind.Decorator */]: function visitEachChildOfDecorator(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateDecorator(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    // Type elements
    [172 /* SyntaxKind.PropertySignature */]: function visitEachChildOfPropertySignature(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updatePropertySignature(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken) : node.questionToken, nodeVisitor(node.type, visitor, ts_js_1.isTypeNode));
    },
    [173 /* SyntaxKind.PropertyDeclaration */]: function visitEachChildOfPropertyDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updatePropertyDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), 
        // QuestionToken and ExclamationToken are mutually exclusive in PropertyDeclaration
        tokenVisitor ? nodeVisitor(node.questionToken ?? node.exclamationToken, tokenVisitor, ts_js_1.isQuestionOrExclamationToken) : node.questionToken ?? node.exclamationToken, nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), nodeVisitor(node.initializer, visitor, ts_js_1.isExpression));
    },
    [174 /* SyntaxKind.MethodSignature */]: function visitEachChildOfMethodSignature(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateMethodSignature(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken) : node.questionToken, nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode));
    },
    [175 /* SyntaxKind.MethodDeclaration */]: function visitEachChildOfMethodDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateMethodDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), tokenVisitor ? nodeVisitor(node.asteriskToken, tokenVisitor, ts_js_1.isAsteriskToken) : node.asteriskToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken) : node.questionToken, nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), visitParameterList(node.parameters, visitor, context, nodesVisitor), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [177 /* SyntaxKind.Constructor */]: function visitEachChildOfConstructorDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateConstructorDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), visitParameterList(node.parameters, visitor, context, nodesVisitor), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [178 /* SyntaxKind.GetAccessor */]: function visitEachChildOfGetAccessorDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateGetAccessorDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), visitParameterList(node.parameters, visitor, context, nodesVisitor), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [179 /* SyntaxKind.SetAccessor */]: function visitEachChildOfSetAccessorDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateSetAccessorDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), visitParameterList(node.parameters, visitor, context, nodesVisitor), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [176 /* SyntaxKind.ClassStaticBlockDeclaration */]: function visitEachChildOfClassStaticBlockDeclaration(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        context.startLexicalEnvironment();
        context.suspendLexicalEnvironment();
        return context.factory.updateClassStaticBlockDeclaration(node, visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [180 /* SyntaxKind.CallSignature */]: function visitEachChildOfCallSignatureDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateCallSignature(node, nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode));
    },
    [181 /* SyntaxKind.ConstructSignature */]: function visitEachChildOfConstructSignatureDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateConstructSignature(node, nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode));
    },
    [182 /* SyntaxKind.IndexSignature */]: function visitEachChildOfIndexSignatureDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateIndexSignature(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    // Types
    [183 /* SyntaxKind.TypePredicate */]: function visitEachChildOfTypePredicateNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypePredicateNode(node, nodeVisitor(node.assertsModifier, visitor, ts_js_1.isAssertsKeyword), ts_js_1.Debug.checkDefined(nodeVisitor(node.parameterName, visitor, ts_js_1.isIdentifierOrThisTypeNode)), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode));
    },
    [184 /* SyntaxKind.TypeReference */]: function visitEachChildOfTypeReferenceNode(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeReferenceNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.typeName, visitor, ts_js_1.isEntityName)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode));
    },
    [185 /* SyntaxKind.FunctionType */]: function visitEachChildOfFunctionTypeNode(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateFunctionTypeNode(node, nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [186 /* SyntaxKind.ConstructorType */]: function visitEachChildOfConstructorTypeNode(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateConstructorTypeNode(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.parameters, visitor, ts_js_1.isParameter), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [187 /* SyntaxKind.TypeQuery */]: function visitEachChildOfTypeQueryNode(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeQueryNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.exprName, visitor, ts_js_1.isEntityName)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode));
    },
    [188 /* SyntaxKind.TypeLiteral */]: function visitEachChildOfTypeLiteralNode(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeLiteralNode(node, nodesVisitor(node.members, visitor, ts_js_1.isTypeElement));
    },
    [189 /* SyntaxKind.ArrayType */]: function visitEachChildOfArrayTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateArrayTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.elementType, visitor, ts_js_1.isTypeNode)));
    },
    [190 /* SyntaxKind.TupleType */]: function visitEachChildOfTupleTypeNode(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateTupleTypeNode(node, nodesVisitor(node.elements, visitor, ts_js_1.isTypeNode));
    },
    [191 /* SyntaxKind.OptionalType */]: function visitEachChildOfOptionalTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateOptionalTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [192 /* SyntaxKind.RestType */]: function visitEachChildOfRestTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateRestTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [193 /* SyntaxKind.UnionType */]: function visitEachChildOfUnionTypeNode(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateUnionTypeNode(node, nodesVisitor(node.types, visitor, ts_js_1.isTypeNode));
    },
    [194 /* SyntaxKind.IntersectionType */]: function visitEachChildOfIntersectionTypeNode(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateIntersectionTypeNode(node, nodesVisitor(node.types, visitor, ts_js_1.isTypeNode));
    },
    [195 /* SyntaxKind.ConditionalType */]: function visitEachChildOfConditionalTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateConditionalTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.checkType, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.extendsType, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.trueType, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.falseType, visitor, ts_js_1.isTypeNode)));
    },
    [196 /* SyntaxKind.InferType */]: function visitEachChildOfInferTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateInferTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.typeParameter, visitor, ts_js_1.isTypeParameterDeclaration)));
    },
    [206 /* SyntaxKind.ImportType */]: function visitEachChildOfImportTypeNode(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.argument, visitor, ts_js_1.isTypeNode)), nodeVisitor(node.attributes, visitor, ts_js_1.isImportAttributes), nodeVisitor(node.qualifier, visitor, ts_js_1.isEntityName), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), node.isTypeOf);
    },
    [303 /* SyntaxKind.ImportTypeAssertionContainer */]: function visitEachChildOfImportTypeAssertionContainer(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportTypeAssertionContainer(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.assertClause, visitor, ts_js_1.isAssertClause)), node.multiLine);
    },
    [203 /* SyntaxKind.NamedTupleMember */]: function visitEachChildOfNamedTupleMember(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateNamedTupleMember(node, tokenVisitor ? nodeVisitor(node.dotDotDotToken, tokenVisitor, ts_js_1.isDotDotDotToken) : node.dotDotDotToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken) : node.questionToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [197 /* SyntaxKind.ParenthesizedType */]: function visitEachChildOfParenthesizedType(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateParenthesizedType(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [199 /* SyntaxKind.TypeOperator */]: function visitEachChildOfTypeOperatorNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeOperatorNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [200 /* SyntaxKind.IndexedAccessType */]: function visitEachChildOfIndexedAccessType(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateIndexedAccessTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.objectType, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.indexType, visitor, ts_js_1.isTypeNode)));
    },
    [201 /* SyntaxKind.MappedType */]: function visitEachChildOfMappedType(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateMappedTypeNode(node, tokenVisitor ? nodeVisitor(node.readonlyToken, tokenVisitor, ts_js_1.isReadonlyKeywordOrPlusOrMinusToken) : node.readonlyToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.typeParameter, visitor, ts_js_1.isTypeParameterDeclaration)), nodeVisitor(node.nameType, visitor, ts_js_1.isTypeNode), tokenVisitor ? nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionOrPlusOrMinusToken) : node.questionToken, nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), nodesVisitor(node.members, visitor, ts_js_1.isTypeElement));
    },
    [202 /* SyntaxKind.LiteralType */]: function visitEachChildOfLiteralTypeNode(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateLiteralTypeNode(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.literal, visitor, ts_js_1.isLiteralTypeLiteral)));
    },
    [204 /* SyntaxKind.TemplateLiteralType */]: function visitEachChildOfTemplateLiteralType(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTemplateLiteralType(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.head, visitor, ts_js_1.isTemplateHead)), nodesVisitor(node.templateSpans, visitor, ts_js_1.isTemplateLiteralTypeSpan));
    },
    [205 /* SyntaxKind.TemplateLiteralTypeSpan */]: function visitEachChildOfTemplateLiteralTypeSpan(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTemplateLiteralTypeSpan(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.literal, visitor, ts_js_1.isTemplateMiddleOrTemplateTail)));
    },
    // Binding patterns
    [207 /* SyntaxKind.ObjectBindingPattern */]: function visitEachChildOfObjectBindingPattern(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateObjectBindingPattern(node, nodesVisitor(node.elements, visitor, ts_js_1.isBindingElement));
    },
    [208 /* SyntaxKind.ArrayBindingPattern */]: function visitEachChildOfArrayBindingPattern(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateArrayBindingPattern(node, nodesVisitor(node.elements, visitor, ts_js_1.isArrayBindingElement));
    },
    [209 /* SyntaxKind.BindingElement */]: function visitEachChildOfBindingElement(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateBindingElement(node, tokenVisitor ? nodeVisitor(node.dotDotDotToken, tokenVisitor, ts_js_1.isDotDotDotToken) : node.dotDotDotToken, nodeVisitor(node.propertyName, visitor, ts_js_1.isPropertyName), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isBindingName)), nodeVisitor(node.initializer, visitor, ts_js_1.isExpression));
    },
    // Expression
    [210 /* SyntaxKind.ArrayLiteralExpression */]: function visitEachChildOfArrayLiteralExpression(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateArrayLiteralExpression(node, nodesVisitor(node.elements, visitor, ts_js_1.isExpression));
    },
    [211 /* SyntaxKind.ObjectLiteralExpression */]: function visitEachChildOfObjectLiteralExpression(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateObjectLiteralExpression(node, nodesVisitor(node.properties, visitor, ts_js_1.isObjectLiteralElementLike));
    },
    [212 /* SyntaxKind.PropertyAccessExpression */]: function visitEachChildOfPropertyAccessExpression(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return (0, ts_js_1.isPropertyAccessChain)(node) ?
            context.factory.updatePropertyAccessChain(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), tokenVisitor ? nodeVisitor(node.questionDotToken, tokenVisitor, ts_js_1.isQuestionDotToken) : node.questionDotToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isMemberName))) :
            context.factory.updatePropertyAccessExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isMemberName)));
    },
    [213 /* SyntaxKind.ElementAccessExpression */]: function visitEachChildOfElementAccessExpression(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return (0, ts_js_1.isElementAccessChain)(node) ?
            context.factory.updateElementAccessChain(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), tokenVisitor ? nodeVisitor(node.questionDotToken, tokenVisitor, ts_js_1.isQuestionDotToken) : node.questionDotToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.argumentExpression, visitor, ts_js_1.isExpression))) :
            context.factory.updateElementAccessExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.argumentExpression, visitor, ts_js_1.isExpression)));
    },
    [214 /* SyntaxKind.CallExpression */]: function visitEachChildOfCallExpression(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return (0, ts_js_1.isCallChain)(node) ?
            context.factory.updateCallChain(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), tokenVisitor ? nodeVisitor(node.questionDotToken, tokenVisitor, ts_js_1.isQuestionDotToken) : node.questionDotToken, nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), nodesVisitor(node.arguments, visitor, ts_js_1.isExpression)) :
            context.factory.updateCallExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), nodesVisitor(node.arguments, visitor, ts_js_1.isExpression));
    },
    [215 /* SyntaxKind.NewExpression */]: function visitEachChildOfNewExpression(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateNewExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), nodesVisitor(node.arguments, visitor, ts_js_1.isExpression));
    },
    [216 /* SyntaxKind.TaggedTemplateExpression */]: function visitEachChildOfTaggedTemplateExpression(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTaggedTemplateExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.tag, visitor, ts_js_1.isExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), ts_js_1.Debug.checkDefined(nodeVisitor(node.template, visitor, ts_js_1.isTemplateLiteral)));
    },
    [217 /* SyntaxKind.TypeAssertionExpression */]: function visitEachChildOfTypeAssertionExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeAssertion(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)), ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [218 /* SyntaxKind.ParenthesizedExpression */]: function visitEachChildOfParenthesizedExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateParenthesizedExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [219 /* SyntaxKind.FunctionExpression */]: function visitEachChildOfFunctionExpression(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateFunctionExpression(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), tokenVisitor ? nodeVisitor(node.asteriskToken, tokenVisitor, ts_js_1.isAsteriskToken) : node.asteriskToken, nodeVisitor(node.name, visitor, ts_js_1.isIdentifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), visitParameterList(node.parameters, visitor, context, nodesVisitor), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [220 /* SyntaxKind.ArrowFunction */]: function visitEachChildOfArrowFunction(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateArrowFunction(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), visitParameterList(node.parameters, visitor, context, nodesVisitor), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), tokenVisitor ? ts_js_1.Debug.checkDefined(nodeVisitor(node.equalsGreaterThanToken, tokenVisitor, ts_js_1.isEqualsGreaterThanToken)) : node.equalsGreaterThanToken, visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [221 /* SyntaxKind.DeleteExpression */]: function visitEachChildOfDeleteExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateDeleteExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [222 /* SyntaxKind.TypeOfExpression */]: function visitEachChildOfTypeOfExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeOfExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [223 /* SyntaxKind.VoidExpression */]: function visitEachChildOfVoidExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateVoidExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [224 /* SyntaxKind.AwaitExpression */]: function visitEachChildOfAwaitExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateAwaitExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [225 /* SyntaxKind.PrefixUnaryExpression */]: function visitEachChildOfPrefixUnaryExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updatePrefixUnaryExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.operand, visitor, ts_js_1.isExpression)));
    },
    [226 /* SyntaxKind.PostfixUnaryExpression */]: function visitEachChildOfPostfixUnaryExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updatePostfixUnaryExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.operand, visitor, ts_js_1.isExpression)));
    },
    [227 /* SyntaxKind.BinaryExpression */]: function visitEachChildOfBinaryExpression(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateBinaryExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.left, visitor, ts_js_1.isExpression)), tokenVisitor ? ts_js_1.Debug.checkDefined(nodeVisitor(node.operatorToken, tokenVisitor, ts_js_1.isBinaryOperatorToken)) : node.operatorToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.right, visitor, ts_js_1.isExpression)));
    },
    [228 /* SyntaxKind.ConditionalExpression */]: function visitEachChildOfConditionalExpression(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateConditionalExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.condition, visitor, ts_js_1.isExpression)), tokenVisitor ? ts_js_1.Debug.checkDefined(nodeVisitor(node.questionToken, tokenVisitor, ts_js_1.isQuestionToken)) : node.questionToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.whenTrue, visitor, ts_js_1.isExpression)), tokenVisitor ? ts_js_1.Debug.checkDefined(nodeVisitor(node.colonToken, tokenVisitor, ts_js_1.isColonToken)) : node.colonToken, ts_js_1.Debug.checkDefined(nodeVisitor(node.whenFalse, visitor, ts_js_1.isExpression)));
    },
    [229 /* SyntaxKind.TemplateExpression */]: function visitEachChildOfTemplateExpression(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTemplateExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.head, visitor, ts_js_1.isTemplateHead)), nodesVisitor(node.templateSpans, visitor, ts_js_1.isTemplateSpan));
    },
    [230 /* SyntaxKind.YieldExpression */]: function visitEachChildOfYieldExpression(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateYieldExpression(node, tokenVisitor ? nodeVisitor(node.asteriskToken, tokenVisitor, ts_js_1.isAsteriskToken) : node.asteriskToken, nodeVisitor(node.expression, visitor, ts_js_1.isExpression));
    },
    [231 /* SyntaxKind.SpreadElement */]: function visitEachChildOfSpreadElement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateSpreadElement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [232 /* SyntaxKind.ClassExpression */]: function visitEachChildOfClassExpression(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateClassExpression(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), nodeVisitor(node.name, visitor, ts_js_1.isIdentifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.heritageClauses, visitor, ts_js_1.isHeritageClause), nodesVisitor(node.members, visitor, ts_js_1.isClassElement));
    },
    [234 /* SyntaxKind.ExpressionWithTypeArguments */]: function visitEachChildOfExpressionWithTypeArguments(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExpressionWithTypeArguments(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode));
    },
    [235 /* SyntaxKind.AsExpression */]: function visitEachChildOfAsExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateAsExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [239 /* SyntaxKind.SatisfiesExpression */]: function visitEachChildOfSatisfiesExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateSatisfiesExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [236 /* SyntaxKind.NonNullExpression */]: function visitEachChildOfNonNullExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return (0, ts_js_1.isOptionalChain)(node) ?
            context.factory.updateNonNullChain(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression))) :
            context.factory.updateNonNullExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [237 /* SyntaxKind.MetaProperty */]: function visitEachChildOfMetaProperty(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateMetaProperty(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    // Misc
    [240 /* SyntaxKind.TemplateSpan */]: function visitEachChildOfTemplateSpan(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTemplateSpan(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.literal, visitor, ts_js_1.isTemplateMiddleOrTemplateTail)));
    },
    // Element
    [242 /* SyntaxKind.Block */]: function visitEachChildOfBlock(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateBlock(node, nodesVisitor(node.statements, visitor, ts_js_1.isStatement));
    },
    [244 /* SyntaxKind.VariableStatement */]: function visitEachChildOfVariableStatement(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateVariableStatement(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.declarationList, visitor, ts_js_1.isVariableDeclarationList)));
    },
    [245 /* SyntaxKind.ExpressionStatement */]: function visitEachChildOfExpressionStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExpressionStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [246 /* SyntaxKind.IfStatement */]: function visitEachChildOfIfStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateIfStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.thenStatement, visitor, ts_js_1.isStatement, context.factory.liftToBlock)), nodeVisitor(node.elseStatement, visitor, ts_js_1.isStatement, context.factory.liftToBlock));
    },
    [247 /* SyntaxKind.DoStatement */]: function visitEachChildOfDoStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateDoStatement(node, visitIterationBody(node.statement, visitor, context, nodeVisitor), ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [248 /* SyntaxKind.WhileStatement */]: function visitEachChildOfWhileStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateWhileStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), visitIterationBody(node.statement, visitor, context, nodeVisitor));
    },
    [249 /* SyntaxKind.ForStatement */]: function visitEachChildOfForStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateForStatement(node, nodeVisitor(node.initializer, visitor, ts_js_1.isForInitializer), nodeVisitor(node.condition, visitor, ts_js_1.isExpression), nodeVisitor(node.incrementor, visitor, ts_js_1.isExpression), visitIterationBody(node.statement, visitor, context, nodeVisitor));
    },
    [250 /* SyntaxKind.ForInStatement */]: function visitEachChildOfForInStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateForInStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.initializer, visitor, ts_js_1.isForInitializer)), ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), visitIterationBody(node.statement, visitor, context, nodeVisitor));
    },
    [251 /* SyntaxKind.ForOfStatement */]: function visitEachChildOfForOfStatement(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateForOfStatement(node, tokenVisitor ? nodeVisitor(node.awaitModifier, tokenVisitor, ts_js_1.isAwaitKeyword) : node.awaitModifier, ts_js_1.Debug.checkDefined(nodeVisitor(node.initializer, visitor, ts_js_1.isForInitializer)), ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), visitIterationBody(node.statement, visitor, context, nodeVisitor));
    },
    [252 /* SyntaxKind.ContinueStatement */]: function visitEachChildOfContinueStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateContinueStatement(node, nodeVisitor(node.label, visitor, ts_js_1.isIdentifier));
    },
    [253 /* SyntaxKind.BreakStatement */]: function visitEachChildOfBreakStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateBreakStatement(node, nodeVisitor(node.label, visitor, ts_js_1.isIdentifier));
    },
    [254 /* SyntaxKind.ReturnStatement */]: function visitEachChildOfReturnStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateReturnStatement(node, nodeVisitor(node.expression, visitor, ts_js_1.isExpression));
    },
    [255 /* SyntaxKind.WithStatement */]: function visitEachChildOfWithStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateWithStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.statement, visitor, ts_js_1.isStatement, context.factory.liftToBlock)));
    },
    [256 /* SyntaxKind.SwitchStatement */]: function visitEachChildOfSwitchStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateSwitchStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined(nodeVisitor(node.caseBlock, visitor, ts_js_1.isCaseBlock)));
    },
    [257 /* SyntaxKind.LabeledStatement */]: function visitEachChildOfLabeledStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateLabeledStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.label, visitor, ts_js_1.isIdentifier)), ts_js_1.Debug.checkDefined(nodeVisitor(node.statement, visitor, ts_js_1.isStatement, context.factory.liftToBlock)));
    },
    [258 /* SyntaxKind.ThrowStatement */]: function visitEachChildOfThrowStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateThrowStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [259 /* SyntaxKind.TryStatement */]: function visitEachChildOfTryStatement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTryStatement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.tryBlock, visitor, ts_js_1.isBlock)), nodeVisitor(node.catchClause, visitor, ts_js_1.isCatchClause), nodeVisitor(node.finallyBlock, visitor, ts_js_1.isBlock));
    },
    [261 /* SyntaxKind.VariableDeclaration */]: function visitEachChildOfVariableDeclaration(node, visitor, context, _nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateVariableDeclaration(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isBindingName)), tokenVisitor ? nodeVisitor(node.exclamationToken, tokenVisitor, ts_js_1.isExclamationToken) : node.exclamationToken, nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), nodeVisitor(node.initializer, visitor, ts_js_1.isExpression));
    },
    [262 /* SyntaxKind.VariableDeclarationList */]: function visitEachChildOfVariableDeclarationList(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateVariableDeclarationList(node, nodesVisitor(node.declarations, visitor, ts_js_1.isVariableDeclaration));
    },
    [263 /* SyntaxKind.FunctionDeclaration */]: function visitEachChildOfFunctionDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, tokenVisitor) {
        return context.factory.updateFunctionDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifier), tokenVisitor ? nodeVisitor(node.asteriskToken, tokenVisitor, ts_js_1.isAsteriskToken) : node.asteriskToken, nodeVisitor(node.name, visitor, ts_js_1.isIdentifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), visitParameterList(node.parameters, visitor, context, nodesVisitor), nodeVisitor(node.type, visitor, ts_js_1.isTypeNode), visitFunctionBody(node.body, visitor, context, nodeVisitor));
    },
    [264 /* SyntaxKind.ClassDeclaration */]: function visitEachChildOfClassDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateClassDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), nodeVisitor(node.name, visitor, ts_js_1.isIdentifier), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.heritageClauses, visitor, ts_js_1.isHeritageClause), nodesVisitor(node.members, visitor, ts_js_1.isClassElement));
    },
    [265 /* SyntaxKind.InterfaceDeclaration */]: function visitEachChildOfInterfaceDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateInterfaceDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), nodesVisitor(node.heritageClauses, visitor, ts_js_1.isHeritageClause), nodesVisitor(node.members, visitor, ts_js_1.isTypeElement));
    },
    [266 /* SyntaxKind.TypeAliasDeclaration */]: function visitEachChildOfTypeAliasDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateTypeAliasDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), nodesVisitor(node.typeParameters, visitor, ts_js_1.isTypeParameterDeclaration), ts_js_1.Debug.checkDefined(nodeVisitor(node.type, visitor, ts_js_1.isTypeNode)));
    },
    [267 /* SyntaxKind.EnumDeclaration */]: function visitEachChildOfEnumDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateEnumDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), nodesVisitor(node.members, visitor, ts_js_1.isEnumMember));
    },
    [268 /* SyntaxKind.ModuleDeclaration */]: function visitEachChildOfModuleDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateModuleDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isModuleName)), nodeVisitor(node.body, visitor, ts_js_1.isModuleBody));
    },
    [269 /* SyntaxKind.ModuleBlock */]: function visitEachChildOfModuleBlock(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateModuleBlock(node, nodesVisitor(node.statements, visitor, ts_js_1.isStatement));
    },
    [270 /* SyntaxKind.CaseBlock */]: function visitEachChildOfCaseBlock(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateCaseBlock(node, nodesVisitor(node.clauses, visitor, ts_js_1.isCaseOrDefaultClause));
    },
    [271 /* SyntaxKind.NamespaceExportDeclaration */]: function visitEachChildOfNamespaceExportDeclaration(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateNamespaceExportDeclaration(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    [272 /* SyntaxKind.ImportEqualsDeclaration */]: function visitEachChildOfImportEqualsDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportEqualsDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), node.isTypeOnly, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), ts_js_1.Debug.checkDefined(nodeVisitor(node.moduleReference, visitor, ts_js_1.isModuleReference)));
    },
    [273 /* SyntaxKind.ImportDeclaration */]: function visitEachChildOfImportDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), nodeVisitor(node.importClause, visitor, ts_js_1.isImportClause), ts_js_1.Debug.checkDefined(nodeVisitor(node.moduleSpecifier, visitor, ts_js_1.isExpression)), nodeVisitor(node.attributes, visitor, ts_js_1.isImportAttributes));
    },
    [301 /* SyntaxKind.ImportAttributes */]: function visitEachChildOfImportAttributes(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportAttributes(node, nodesVisitor(node.elements, visitor, ts_js_1.isImportAttribute), node.multiLine);
    },
    [302 /* SyntaxKind.ImportAttribute */]: function visitEachChildOfImportAttribute(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportAttribute(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isImportAttributeName)), ts_js_1.Debug.checkDefined(nodeVisitor(node.value, visitor, ts_js_1.isExpression)));
    },
    [274 /* SyntaxKind.ImportClause */]: function visitEachChildOfImportClause(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportClause(node, node.phaseModifier, nodeVisitor(node.name, visitor, ts_js_1.isIdentifier), nodeVisitor(node.namedBindings, visitor, ts_js_1.isNamedImportBindings));
    },
    [275 /* SyntaxKind.NamespaceImport */]: function visitEachChildOfNamespaceImport(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateNamespaceImport(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    [281 /* SyntaxKind.NamespaceExport */]: function visitEachChildOfNamespaceExport(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateNamespaceExport(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    [276 /* SyntaxKind.NamedImports */]: function visitEachChildOfNamedImports(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateNamedImports(node, nodesVisitor(node.elements, visitor, ts_js_1.isImportSpecifier));
    },
    [277 /* SyntaxKind.ImportSpecifier */]: function visitEachChildOfImportSpecifier(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateImportSpecifier(node, node.isTypeOnly, nodeVisitor(node.propertyName, visitor, ts_js_1.isModuleExportName), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    [278 /* SyntaxKind.ExportAssignment */]: function visitEachChildOfExportAssignment(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExportAssignment(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [279 /* SyntaxKind.ExportDeclaration */]: function visitEachChildOfExportDeclaration(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExportDeclaration(node, nodesVisitor(node.modifiers, visitor, ts_js_1.isModifierLike), node.isTypeOnly, nodeVisitor(node.exportClause, visitor, ts_js_1.isNamedExportBindings), nodeVisitor(node.moduleSpecifier, visitor, ts_js_1.isExpression), nodeVisitor(node.attributes, visitor, ts_js_1.isImportAttributes));
    },
    [280 /* SyntaxKind.NamedExports */]: function visitEachChildOfNamedExports(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateNamedExports(node, nodesVisitor(node.elements, visitor, ts_js_1.isExportSpecifier));
    },
    [282 /* SyntaxKind.ExportSpecifier */]: function visitEachChildOfExportSpecifier(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExportSpecifier(node, node.isTypeOnly, nodeVisitor(node.propertyName, visitor, ts_js_1.isModuleExportName), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isModuleExportName)));
    },
    // Module references
    [284 /* SyntaxKind.ExternalModuleReference */]: function visitEachChildOfExternalModuleReference(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateExternalModuleReference(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    // JSX
    [285 /* SyntaxKind.JsxElement */]: function visitEachChildOfJsxElement(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxElement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.openingElement, visitor, ts_js_1.isJsxOpeningElement)), nodesVisitor(node.children, visitor, ts_js_1.isJsxChild), ts_js_1.Debug.checkDefined(nodeVisitor(node.closingElement, visitor, ts_js_1.isJsxClosingElement)));
    },
    [286 /* SyntaxKind.JsxSelfClosingElement */]: function visitEachChildOfJsxSelfClosingElement(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxSelfClosingElement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.tagName, visitor, ts_js_1.isJsxTagNameExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), ts_js_1.Debug.checkDefined(nodeVisitor(node.attributes, visitor, ts_js_1.isJsxAttributes)));
    },
    [287 /* SyntaxKind.JsxOpeningElement */]: function visitEachChildOfJsxOpeningElement(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxOpeningElement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.tagName, visitor, ts_js_1.isJsxTagNameExpression)), nodesVisitor(node.typeArguments, visitor, ts_js_1.isTypeNode), ts_js_1.Debug.checkDefined(nodeVisitor(node.attributes, visitor, ts_js_1.isJsxAttributes)));
    },
    [288 /* SyntaxKind.JsxClosingElement */]: function visitEachChildOfJsxClosingElement(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxClosingElement(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.tagName, visitor, ts_js_1.isJsxTagNameExpression)));
    },
    [296 /* SyntaxKind.JsxNamespacedName */]: function forEachChildInJsxNamespacedName(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxNamespacedName(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.namespace, visitor, ts_js_1.isIdentifier)), ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)));
    },
    [289 /* SyntaxKind.JsxFragment */]: function visitEachChildOfJsxFragment(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxFragment(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.openingFragment, visitor, ts_js_1.isJsxOpeningFragment)), nodesVisitor(node.children, visitor, ts_js_1.isJsxChild), ts_js_1.Debug.checkDefined(nodeVisitor(node.closingFragment, visitor, ts_js_1.isJsxClosingFragment)));
    },
    [292 /* SyntaxKind.JsxAttribute */]: function visitEachChildOfJsxAttribute(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxAttribute(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isJsxAttributeName)), nodeVisitor(node.initializer, visitor, ts_js_1.isStringLiteralOrJsxExpression));
    },
    [293 /* SyntaxKind.JsxAttributes */]: function visitEachChildOfJsxAttributes(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxAttributes(node, nodesVisitor(node.properties, visitor, ts_js_1.isJsxAttributeLike));
    },
    [294 /* SyntaxKind.JsxSpreadAttribute */]: function visitEachChildOfJsxSpreadAttribute(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxSpreadAttribute(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [295 /* SyntaxKind.JsxExpression */]: function visitEachChildOfJsxExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateJsxExpression(node, nodeVisitor(node.expression, visitor, ts_js_1.isExpression));
    },
    // Clauses
    [297 /* SyntaxKind.CaseClause */]: function visitEachChildOfCaseClause(node, visitor, context, nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateCaseClause(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)), nodesVisitor(node.statements, visitor, ts_js_1.isStatement));
    },
    [298 /* SyntaxKind.DefaultClause */]: function visitEachChildOfDefaultClause(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateDefaultClause(node, nodesVisitor(node.statements, visitor, ts_js_1.isStatement));
    },
    [299 /* SyntaxKind.HeritageClause */]: function visitEachChildOfHeritageClause(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateHeritageClause(node, nodesVisitor(node.types, visitor, ts_js_1.isExpressionWithTypeArguments));
    },
    [300 /* SyntaxKind.CatchClause */]: function visitEachChildOfCatchClause(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateCatchClause(node, nodeVisitor(node.variableDeclaration, visitor, ts_js_1.isVariableDeclaration), ts_js_1.Debug.checkDefined(nodeVisitor(node.block, visitor, ts_js_1.isBlock)));
    },
    // Property assignments
    [304 /* SyntaxKind.PropertyAssignment */]: function visitEachChildOfPropertyAssignment(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updatePropertyAssignment(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), ts_js_1.Debug.checkDefined(nodeVisitor(node.initializer, visitor, ts_js_1.isExpression)));
    },
    [305 /* SyntaxKind.ShorthandPropertyAssignment */]: function visitEachChildOfShorthandPropertyAssignment(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateShorthandPropertyAssignment(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isIdentifier)), nodeVisitor(node.objectAssignmentInitializer, visitor, ts_js_1.isExpression));
    },
    [306 /* SyntaxKind.SpreadAssignment */]: function visitEachChildOfSpreadAssignment(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateSpreadAssignment(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    // Enum
    [307 /* SyntaxKind.EnumMember */]: function visitEachChildOfEnumMember(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updateEnumMember(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.name, visitor, ts_js_1.isPropertyName)), nodeVisitor(node.initializer, visitor, ts_js_1.isExpression));
    },
    // Top-level nodes
    [308 /* SyntaxKind.SourceFile */]: function visitEachChildOfSourceFile(node, visitor, context, _nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateSourceFile(node, visitLexicalEnvironment(node.statements, visitor, context));
    },
    // Transformation nodes
    [356 /* SyntaxKind.PartiallyEmittedExpression */]: function visitEachChildOfPartiallyEmittedExpression(node, visitor, context, _nodesVisitor, nodeVisitor, _tokenVisitor) {
        return context.factory.updatePartiallyEmittedExpression(node, ts_js_1.Debug.checkDefined(nodeVisitor(node.expression, visitor, ts_js_1.isExpression)));
    },
    [357 /* SyntaxKind.CommaListExpression */]: function visitEachChildOfCommaListExpression(node, visitor, context, nodesVisitor, _nodeVisitor, _tokenVisitor) {
        return context.factory.updateCommaListExpression(node, nodesVisitor(node.elements, visitor, ts_js_1.isExpression));
    },
};
/**
 * Extracts the single node from a NodeArray.
 *
 * @param nodes The NodeArray.
 */
function extractSingleNode(nodes) {
    ts_js_1.Debug.assert(nodes.length <= 1, "Too many nodes written to output.");
    return (0, ts_js_1.singleOrUndefined)(nodes);
}
