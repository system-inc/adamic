"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSemanticDiagnosticsBuilderProgram = createSemanticDiagnosticsBuilderProgram;
exports.createEmitAndSemanticDiagnosticsBuilderProgram = createEmitAndSemanticDiagnosticsBuilderProgram;
exports.createAbstractBuilder = createAbstractBuilder;
const ts_js_1 = require("./_namespaces/ts.js");
function createSemanticDiagnosticsBuilderProgram(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences) {
    return (0, ts_js_1.createBuilderProgram)(ts_js_1.BuilderProgramKind.SemanticDiagnosticsBuilderProgram, (0, ts_js_1.getBuilderCreationParameters)(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences));
}
function createEmitAndSemanticDiagnosticsBuilderProgram(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences) {
    return (0, ts_js_1.createBuilderProgram)(ts_js_1.BuilderProgramKind.EmitAndSemanticDiagnosticsBuilderProgram, (0, ts_js_1.getBuilderCreationParameters)(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences));
}
function createAbstractBuilder(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences) {
    const { newProgram, configFileParsingDiagnostics: newConfigFileParsingDiagnostics } = (0, ts_js_1.getBuilderCreationParameters)(newProgramOrRootNames, hostOrOptions, oldProgramOrHost, configFileParsingDiagnosticsOrOldProgram, configFileParsingDiagnostics, projectReferences);
    return (0, ts_js_1.createRedirectedBuilderProgram)({ program: newProgram, compilerOptions: newProgram.getCompilerOptions() }, newConfigFileParsingDiagnostics);
}
