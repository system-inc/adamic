"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOrCreateEmitNode = getOrCreateEmitNode;
exports.disposeEmitNodes = disposeEmitNodes;
exports.removeAllComments = removeAllComments;
exports.setEmitFlags = setEmitFlags;
exports.addEmitFlags = addEmitFlags;
exports.setInternalEmitFlags = setInternalEmitFlags;
exports.addInternalEmitFlags = addInternalEmitFlags;
exports.getSourceMapRange = getSourceMapRange;
exports.setSourceMapRange = setSourceMapRange;
exports.getTokenSourceMapRange = getTokenSourceMapRange;
exports.setTokenSourceMapRange = setTokenSourceMapRange;
exports.getStartsOnNewLine = getStartsOnNewLine;
exports.setStartsOnNewLine = setStartsOnNewLine;
exports.getCommentRange = getCommentRange;
exports.setCommentRange = setCommentRange;
exports.getSyntheticLeadingComments = getSyntheticLeadingComments;
exports.setSyntheticLeadingComments = setSyntheticLeadingComments;
exports.addSyntheticLeadingComment = addSyntheticLeadingComment;
exports.getSyntheticTrailingComments = getSyntheticTrailingComments;
exports.setSyntheticTrailingComments = setSyntheticTrailingComments;
exports.addSyntheticTrailingComment = addSyntheticTrailingComment;
exports.moveSyntheticComments = moveSyntheticComments;
exports.getConstantValue = getConstantValue;
exports.setConstantValue = setConstantValue;
exports.addEmitHelper = addEmitHelper;
exports.addEmitHelpers = addEmitHelpers;
exports.removeEmitHelper = removeEmitHelper;
exports.getEmitHelpers = getEmitHelpers;
exports.moveEmitHelpers = moveEmitHelpers;
exports.getSnippetElement = getSnippetElement;
exports.setSnippetElement = setSnippetElement;
exports.ignoreSourceNewlines = ignoreSourceNewlines;
exports.setTypeNode = setTypeNode;
exports.getTypeNode = getTypeNode;
exports.setIdentifierTypeArguments = setIdentifierTypeArguments;
exports.getIdentifierTypeArguments = getIdentifierTypeArguments;
exports.setIdentifierAutoGenerate = setIdentifierAutoGenerate;
exports.getIdentifierAutoGenerate = getIdentifierAutoGenerate;
exports.setIdentifierGeneratedImportReference = setIdentifierGeneratedImportReference;
exports.getIdentifierGeneratedImportReference = getIdentifierGeneratedImportReference;
const ts_js_1 = require("../_namespaces/ts.js");
/**
 * Associates a node with the current transformation, initializing
 * various transient transformation properties.
 * @internal
 */
function getOrCreateEmitNode(node) {
    if (!node.emitNode) {
        if ((0, ts_js_1.isParseTreeNode)(node)) {
            // To avoid holding onto transformation artifacts, we keep track of any
            // parse tree node we are annotating. This allows us to clean them up after
            // all transformations have completed.
            if (node.kind === 308 /* SyntaxKind.SourceFile */) {
                return node.emitNode = { annotatedNodes: [node] };
            }
            const sourceFile = (0, ts_js_1.getSourceFileOfNode)((0, ts_js_1.getParseTreeNode)((0, ts_js_1.getSourceFileOfNode)(node))) ?? ts_js_1.Debug.fail("Could not determine parsed source file.");
            getOrCreateEmitNode(sourceFile).annotatedNodes.push(node);
        }
        node.emitNode = {};
    }
    else {
        ts_js_1.Debug.assert(!(node.emitNode.internalFlags & 8 /* InternalEmitFlags.Immutable */), "Invalid attempt to mutate an immutable node.");
    }
    return node.emitNode;
}
/**
 * Clears any `EmitNode` entries from parse-tree nodes.
 * @param sourceFile A source file.
 */
function disposeEmitNodes(sourceFile) {
    // During transformation we may need to annotate a parse tree node with transient
    // transformation properties. As parse tree nodes live longer than transformation
    // nodes, we need to make sure we reclaim any memory allocated for custom ranges
    // from these nodes to ensure we do not hold onto entire subtrees just for position
    // information. We also need to reset these nodes to a pre-transformation state
    // for incremental parsing scenarios so that we do not impact later emit.
    const annotatedNodes = (0, ts_js_1.getSourceFileOfNode)((0, ts_js_1.getParseTreeNode)(sourceFile))?.emitNode?.annotatedNodes;
    if (annotatedNodes) {
        for (const node of annotatedNodes) {
            node.emitNode = undefined;
        }
    }
}
/**
 * Sets `EmitFlags.NoComments` on a node and removes any leading and trailing synthetic comments.
 * @internal
 */
function removeAllComments(node) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.flags |= 3072 /* EmitFlags.NoComments */;
    emitNode.leadingComments = undefined;
    emitNode.trailingComments = undefined;
    return node;
}
/**
 * Sets flags that control emit behavior of a node.
 */
function setEmitFlags(node, emitFlags) {
    getOrCreateEmitNode(node).flags = emitFlags;
    return node;
}
/**
 * Sets flags that control emit behavior of a node.
 *
 * @internal
 */
function addEmitFlags(node, emitFlags) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.flags = emitNode.flags | emitFlags;
    return node;
}
/**
 * Sets flags that control emit behavior of a node.
 *
 * @internal
 */
function setInternalEmitFlags(node, emitFlags) {
    getOrCreateEmitNode(node).internalFlags = emitFlags;
    return node;
}
/**
 * Sets flags that control emit behavior of a node.
 *
 * @internal
 */
function addInternalEmitFlags(node, emitFlags) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.internalFlags = emitNode.internalFlags | emitFlags;
    return node;
}
/**
 * Gets a custom text range to use when emitting source maps.
 */
function getSourceMapRange(node) {
    return node.emitNode?.sourceMapRange ?? node;
}
/**
 * Sets a custom text range to use when emitting source maps.
 */
function setSourceMapRange(node, range) {
    getOrCreateEmitNode(node).sourceMapRange = range;
    return node;
}
/**
 * Gets the TextRange to use for source maps for a token of a node.
 */
function getTokenSourceMapRange(node, token) {
    return node.emitNode?.tokenSourceMapRanges?.[token];
}
/**
 * Sets the TextRange to use for source maps for a token of a node.
 */
function setTokenSourceMapRange(node, token, range) {
    const emitNode = getOrCreateEmitNode(node);
    const tokenSourceMapRanges = emitNode.tokenSourceMapRanges ?? (emitNode.tokenSourceMapRanges = []);
    tokenSourceMapRanges[token] = range;
    return node;
}
/**
 * Gets a custom text range to use when emitting comments.
 *
 * @internal
 */
function getStartsOnNewLine(node) {
    return node.emitNode?.startsOnNewLine;
}
/**
 * Sets a custom text range to use when emitting comments.
 *
 * @internal
 */
function setStartsOnNewLine(node, newLine) {
    getOrCreateEmitNode(node).startsOnNewLine = newLine;
    return node;
}
/**
 * Gets a custom text range to use when emitting comments.
 */
function getCommentRange(node) {
    return node.emitNode?.commentRange ?? node;
}
/**
 * Sets a custom text range to use when emitting comments.
 */
function setCommentRange(node, range) {
    getOrCreateEmitNode(node).commentRange = range;
    return node;
}
function getSyntheticLeadingComments(node) {
    return node.emitNode?.leadingComments;
}
function setSyntheticLeadingComments(node, comments) {
    getOrCreateEmitNode(node).leadingComments = comments;
    return node;
}
function addSyntheticLeadingComment(node, kind, text, hasTrailingNewLine) {
    return setSyntheticLeadingComments(node, (0, ts_js_1.append)(getSyntheticLeadingComments(node), { kind, pos: -1, end: -1, hasTrailingNewLine, text }));
}
function getSyntheticTrailingComments(node) {
    return node.emitNode?.trailingComments;
}
function setSyntheticTrailingComments(node, comments) {
    getOrCreateEmitNode(node).trailingComments = comments;
    return node;
}
function addSyntheticTrailingComment(node, kind, text, hasTrailingNewLine) {
    return setSyntheticTrailingComments(node, (0, ts_js_1.append)(getSyntheticTrailingComments(node), { kind, pos: -1, end: -1, hasTrailingNewLine, text }));
}
function moveSyntheticComments(node, original) {
    setSyntheticLeadingComments(node, getSyntheticLeadingComments(original));
    setSyntheticTrailingComments(node, getSyntheticTrailingComments(original));
    const emit = getOrCreateEmitNode(original);
    emit.leadingComments = undefined;
    emit.trailingComments = undefined;
    return node;
}
/**
 * Gets the constant value to emit for an expression representing an enum.
 */
function getConstantValue(node) {
    return node.emitNode?.constantValue;
}
/**
 * Sets the constant value to emit for an expression.
 */
function setConstantValue(node, value) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.constantValue = value;
    return node;
}
/**
 * Adds an EmitHelper to a node.
 */
function addEmitHelper(node, helper) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.helpers = (0, ts_js_1.append)(emitNode.helpers, helper);
    return node;
}
/**
 * Add EmitHelpers to a node.
 */
function addEmitHelpers(node, helpers) {
    if ((0, ts_js_1.some)(helpers)) {
        const emitNode = getOrCreateEmitNode(node);
        for (const helper of helpers) {
            emitNode.helpers = (0, ts_js_1.appendIfUnique)(emitNode.helpers, helper);
        }
    }
    return node;
}
/**
 * Removes an EmitHelper from a node.
 */
function removeEmitHelper(node, helper) {
    const helpers = node.emitNode?.helpers;
    if (helpers) {
        return (0, ts_js_1.orderedRemoveItem)(helpers, helper);
    }
    return false;
}
/**
 * Gets the EmitHelpers of a node.
 */
function getEmitHelpers(node) {
    return node.emitNode?.helpers;
}
/**
 * Moves matching emit helpers from a source node to a target node.
 */
function moveEmitHelpers(source, target, predicate) {
    const sourceEmitNode = source.emitNode;
    const sourceEmitHelpers = sourceEmitNode && sourceEmitNode.helpers;
    if (!(0, ts_js_1.some)(sourceEmitHelpers))
        return;
    const targetEmitNode = getOrCreateEmitNode(target);
    let helpersRemoved = 0;
    for (let i = 0; i < sourceEmitHelpers.length; i++) {
        const helper = sourceEmitHelpers[i];
        if (predicate(helper)) {
            helpersRemoved++;
            targetEmitNode.helpers = (0, ts_js_1.appendIfUnique)(targetEmitNode.helpers, helper);
        }
        else if (helpersRemoved > 0) {
            sourceEmitHelpers[i - helpersRemoved] = helper;
        }
    }
    if (helpersRemoved > 0) {
        sourceEmitHelpers.length -= helpersRemoved;
    }
}
/**
 * Gets the SnippetElement of a node.
 *
 * @internal
 */
function getSnippetElement(node) {
    return node.emitNode?.snippetElement;
}
/**
 * Sets the SnippetElement of a node.
 *
 * @internal
 */
function setSnippetElement(node, snippet) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.snippetElement = snippet;
    return node;
}
/** @internal */
function ignoreSourceNewlines(node) {
    getOrCreateEmitNode(node).internalFlags |= 4 /* InternalEmitFlags.IgnoreSourceNewlines */;
    return node;
}
/** @internal */
function setTypeNode(node, type) {
    const emitNode = getOrCreateEmitNode(node);
    emitNode.typeNode = type;
    return node;
}
/** @internal */
function getTypeNode(node) {
    return node.emitNode?.typeNode;
}
/** @internal */
function setIdentifierTypeArguments(node, typeArguments) {
    getOrCreateEmitNode(node).identifierTypeArguments = typeArguments;
    return node;
}
/** @internal */
function getIdentifierTypeArguments(node) {
    return node.emitNode?.identifierTypeArguments;
}
/** @internal */
function setIdentifierAutoGenerate(node, autoGenerate) {
    getOrCreateEmitNode(node).autoGenerate = autoGenerate;
    return node;
}
/** @internal @knipignore */
function getIdentifierAutoGenerate(node) {
    return node.emitNode?.autoGenerate;
}
/** @internal */
function setIdentifierGeneratedImportReference(node, value) {
    getOrCreateEmitNode(node).generatedImportReference = value;
    return node;
}
/** @internal */
function getIdentifierGeneratedImportReference(node) {
    return node.emitNode?.generatedImportReference;
}
