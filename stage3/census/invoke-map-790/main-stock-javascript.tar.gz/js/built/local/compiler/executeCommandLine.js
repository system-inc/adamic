"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatisticType = void 0;
exports.isBuildCommand = isBuildCommand;
exports.executeCommandLine = executeCommandLine;
const ts_js_1 = require("./_namespaces/ts.js");
const performance = __importStar(require("./performance.js"));
/** @internal */
var StatisticType;
(function (StatisticType) {
    StatisticType[StatisticType["time"] = 0] = "time";
    StatisticType[StatisticType["count"] = 1] = "count";
    StatisticType[StatisticType["memory"] = 2] = "memory";
})(StatisticType || (exports.StatisticType = StatisticType = {}));
function countLines(program) {
    const counts = getCountsMap();
    (0, ts_js_1.forEach)(program.getSourceFiles(), file => {
        const key = getCountKey(program, file);
        const lineCount = (0, ts_js_1.getLineStarts)(file).length;
        counts.set(key, counts.get(key) + lineCount);
    });
    return counts;
}
function getCountsMap() {
    const counts = new Map();
    counts.set("Library", 0);
    counts.set("Definitions", 0);
    counts.set("TypeScript", 0);
    counts.set("JavaScript", 0);
    counts.set("JSON", 0);
    counts.set("Other", 0);
    return counts;
}
function getCountKey(program, file) {
    if (program.isSourceFileDefaultLibrary(file)) {
        return "Library";
    }
    else if (file.isDeclarationFile) {
        return "Definitions";
    }
    const path = file.path;
    if ((0, ts_js_1.fileExtensionIsOneOf)(path, ts_js_1.supportedTSExtensionsFlat)) {
        return "TypeScript";
    }
    else if ((0, ts_js_1.fileExtensionIsOneOf)(path, ts_js_1.supportedJSExtensionsFlat)) {
        return "JavaScript";
    }
    else if ((0, ts_js_1.fileExtensionIs)(path, ".json" /* Extension.Json */)) {
        return "JSON";
    }
    else {
        return "Other";
    }
}
function updateReportDiagnostic(sys, existing, options) {
    return shouldBePretty(sys, options) ?
        (0, ts_js_1.createDiagnosticReporter)(sys, /*pretty*/ true) :
        existing;
}
function defaultIsPretty(sys) {
    if (sys.getEnvironmentVariable("NO_COLOR")) {
        return false;
    }
    if (sys.getEnvironmentVariable("FORCE_COLOR")) {
        return true;
    }
    return !!sys.writeOutputIsTTY && sys.writeOutputIsTTY();
}
function shouldBePretty(sys, options) {
    if (!options || typeof options.pretty === "undefined") {
        return defaultIsPretty(sys);
    }
    return options.pretty;
}
function getOptionsForHelp(commandLine) {
    const helpOptions = (0, ts_js_1.filter)(ts_js_1.optionDeclarations.concat(ts_js_1.tscBuildOption), option => option.showInHelp !== false);
    // Sort our options by their names, (e.g. "--noImplicitAny" comes before "--watch")
    return !!commandLine.options.all ?
        (0, ts_js_1.toSorted)(helpOptions, (a, b) => (0, ts_js_1.compareStringsCaseInsensitive)(a.name, b.name)) :
        (0, ts_js_1.filter)(helpOptions, v => !!v.showInSimplifiedHelpView);
}
function printVersion(sys) {
    sys.write((0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.Version_0, ts_js_1.version) + sys.newLine);
}
function createColors(sys) {
    const showColors = defaultIsPretty(sys);
    if (!showColors) {
        return {
            bold: (str) => str,
            blue: (str) => str,
            blueBackground: (str) => str,
            brightWhite: (str) => str,
        };
    }
    function bold(str) {
        return `\x1b[1m${str}\x1b[22m`;
    }
    const isWindows = sys.getEnvironmentVariable("OS") && sys.getEnvironmentVariable("OS").toLowerCase().includes("windows");
    const isWindowsTerminal = sys.getEnvironmentVariable("WT_SESSION");
    const isVSCode = sys.getEnvironmentVariable("TERM_PROGRAM") && sys.getEnvironmentVariable("TERM_PROGRAM") === "vscode";
    function blue(str) {
        // Effectively Powershell and Command prompt users use cyan instead
        // of blue because the default theme doesn't show blue with enough contrast.
        if (isWindows && !isWindowsTerminal && !isVSCode) {
            return brightWhite(str);
        }
        return `\x1b[94m${str}\x1b[39m`;
    }
    // There are ~3 types of terminal color support: 16 colors, 256 and 16m colors
    // If there is richer color support, e.g. 256+ we can use extended ANSI codes which are not just generic 'blue'
    // but a 'lighter blue' which is closer to the blue in the TS logo.
    const supportsRicherColors = sys.getEnvironmentVariable("COLORTERM") === "truecolor" || sys.getEnvironmentVariable("TERM") === "xterm-256color";
    function blueBackground(str) {
        if (supportsRicherColors) {
            return `\x1B[48;5;68m${str}\x1B[39;49m`;
        }
        else {
            return `\x1b[44m${str}\x1B[39;49m`;
        }
    }
    function brightWhite(str) {
        return `\x1b[97m${str}\x1b[39m`;
    }
    return {
        bold,
        blue,
        brightWhite,
        blueBackground,
    };
}
function getDisplayNameTextOfOption(option) {
    return `--${option.name}${option.shortName ? `, -${option.shortName}` : ""}`;
}
function generateOptionOutput(sys, option, rightAlignOfLeft, leftAlignOfRight) {
    const text = [];
    const colors = createColors(sys);
    // name and description
    const name = getDisplayNameTextOfOption(option);
    // value type and possible value
    const valueCandidates = getValueCandidate(option);
    const defaultValueDescription = typeof option.defaultValueDescription === "object"
        ? (0, ts_js_1.getDiagnosticText)(option.defaultValueDescription)
        : formatDefaultValue(option.defaultValueDescription, option.type === "list" || option.type === "listOrElement" ? option.element.type : option.type);
    const terminalWidth = sys.getWidthOfTerminal?.() ?? 0;
    // Note: child_process might return `terminalWidth` as undefined.
    if (terminalWidth >= 80) {
        let description = "";
        if (option.description) {
            description = (0, ts_js_1.getDiagnosticText)(option.description);
        }
        text.push(...getPrettyOutput(name, description, rightAlignOfLeft, leftAlignOfRight, terminalWidth, /*colorLeft*/ true), sys.newLine);
        if (showAdditionalInfoOutput(valueCandidates, option)) {
            if (valueCandidates) {
                text.push(...getPrettyOutput(valueCandidates.valueType, valueCandidates.possibleValues, rightAlignOfLeft, leftAlignOfRight, terminalWidth, /*colorLeft*/ false), sys.newLine);
            }
            if (defaultValueDescription) {
                text.push(...getPrettyOutput((0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.default_Colon), defaultValueDescription, rightAlignOfLeft, leftAlignOfRight, terminalWidth, /*colorLeft*/ false), sys.newLine);
            }
        }
        text.push(sys.newLine);
    }
    else {
        text.push(colors.blue(name), sys.newLine);
        if (option.description) {
            const description = (0, ts_js_1.getDiagnosticText)(option.description);
            text.push(description);
        }
        text.push(sys.newLine);
        if (showAdditionalInfoOutput(valueCandidates, option)) {
            if (valueCandidates) {
                text.push(`${valueCandidates.valueType} ${valueCandidates.possibleValues}`);
            }
            if (defaultValueDescription) {
                if (valueCandidates)
                    text.push(sys.newLine);
                const diagType = (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.default_Colon);
                text.push(`${diagType} ${defaultValueDescription}`);
            }
            text.push(sys.newLine);
        }
        text.push(sys.newLine);
    }
    return text;
    function formatDefaultValue(defaultValue, type) {
        return defaultValue !== undefined && typeof type === "object"
            // e.g. ScriptTarget.ES2015 -> "es6/es2015"
            ? (0, ts_js_1.arrayFrom)(type.entries())
                .filter(([, value]) => value === defaultValue)
                .map(([name]) => name)
                .join("/")
            : String(defaultValue);
    }
    function showAdditionalInfoOutput(valueCandidates, option) {
        const ignoreValues = ["string"];
        const ignoredDescriptions = [undefined, "false", "n/a"];
        const defaultValueDescription = option.defaultValueDescription;
        if (option.category === ts_js_1.Diagnostics.Command_line_Options)
            return false;
        if ((0, ts_js_1.contains)(ignoreValues, valueCandidates?.possibleValues) && (0, ts_js_1.contains)(ignoredDescriptions, defaultValueDescription)) {
            return false;
        }
        return true;
    }
    function getPrettyOutput(left, right, rightAlignOfLeft, leftAlignOfRight, terminalWidth, colorLeft) {
        const res = [];
        let isFirstLine = true;
        let remainRight = right;
        const rightCharacterNumber = terminalWidth - leftAlignOfRight;
        while (remainRight.length > 0) {
            let curLeft = "";
            if (isFirstLine) {
                curLeft = left.padStart(rightAlignOfLeft);
                curLeft = curLeft.padEnd(leftAlignOfRight);
                curLeft = colorLeft ? colors.blue(curLeft) : curLeft;
            }
            else {
                curLeft = "".padStart(leftAlignOfRight);
            }
            const curRight = remainRight.substr(0, rightCharacterNumber);
            remainRight = remainRight.slice(rightCharacterNumber);
            res.push(`${curLeft}${curRight}`);
            isFirstLine = false;
        }
        return res;
    }
    function getValueCandidate(option) {
        // option.type might be "string" | "number" | "boolean" | "object" | "list" | Map<string, number | string>
        // string -- any of: string
        // number -- any of: number
        // boolean -- any of: boolean
        // object -- null
        // list -- one or more: , content depends on `option.element.type`, the same as others
        // Map<string, number | string> -- any of: key1, key2, ....
        if (option.type === "object") {
            return undefined;
        }
        return {
            valueType: getValueType(option),
            possibleValues: getPossibleValues(option),
        };
        function getValueType(option) {
            ts_js_1.Debug.assert(option.type !== "listOrElement");
            switch (option.type) {
                case "string":
                case "number":
                case "boolean":
                    return (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.type_Colon);
                case "list":
                    return (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.one_or_more_Colon);
                default:
                    return (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.one_of_Colon);
            }
        }
        function getPossibleValues(option) {
            let possibleValues;
            switch (option.type) {
                case "string":
                case "number":
                case "boolean":
                    possibleValues = option.type;
                    break;
                case "list":
                case "listOrElement":
                    possibleValues = getPossibleValues(option.element);
                    break;
                case "object":
                    possibleValues = "";
                    break;
                default:
                    // Map<string, number | string>
                    // Group synonyms: es6/es2015
                    const inverted = {};
                    option.type.forEach((value, name) => {
                        if (!option.deprecatedKeys?.has(name)) {
                            (inverted[value] || (inverted[value] = [])).push(name);
                        }
                    });
                    return Object.entries(inverted)
                        .map(([, synonyms]) => synonyms.join("/"))
                        .join(", ");
            }
            return possibleValues;
        }
    }
}
function generateGroupOptionOutput(sys, optionsList) {
    let maxLength = 0;
    for (const option of optionsList) {
        const curLength = getDisplayNameTextOfOption(option).length;
        maxLength = maxLength > curLength ? maxLength : curLength;
    }
    // left part should be right align, right part should be left align
    // assume 2 space between left margin and left part.
    const rightAlignOfLeftPart = maxLength + 2;
    // assume 2 space between left and right part
    const leftAlignOfRightPart = rightAlignOfLeftPart + 2;
    let lines = [];
    for (const option of optionsList) {
        const tmp = generateOptionOutput(sys, option, rightAlignOfLeftPart, leftAlignOfRightPart);
        lines = [...lines, ...tmp];
    }
    // make sure always a blank line in the end.
    if (lines[lines.length - 2] !== sys.newLine) {
        lines.push(sys.newLine);
    }
    return lines;
}
function generateSectionOptionsOutput(sys, sectionName, options, subCategory, beforeOptionsDescription, afterOptionsDescription) {
    let res = [];
    res.push(createColors(sys).bold(sectionName) + sys.newLine + sys.newLine);
    if (beforeOptionsDescription) {
        res.push(beforeOptionsDescription + sys.newLine + sys.newLine);
    }
    if (!subCategory) {
        res = [...res, ...generateGroupOptionOutput(sys, options)];
        if (afterOptionsDescription) {
            res.push(afterOptionsDescription + sys.newLine + sys.newLine);
        }
        return res;
    }
    const categoryMap = new Map();
    for (const option of options) {
        if (!option.category) {
            continue;
        }
        const curCategory = (0, ts_js_1.getDiagnosticText)(option.category);
        const optionsOfCurCategory = categoryMap.get(curCategory) ?? [];
        optionsOfCurCategory.push(option);
        categoryMap.set(curCategory, optionsOfCurCategory);
    }
    categoryMap.forEach((value, key) => {
        res.push(`### ${key}${sys.newLine}${sys.newLine}`);
        res = [...res, ...generateGroupOptionOutput(sys, value)];
    });
    if (afterOptionsDescription) {
        res.push(afterOptionsDescription + sys.newLine + sys.newLine);
    }
    return res;
}
function printEasyHelp(sys, simpleOptions) {
    const colors = createColors(sys);
    let output = [...getHeader(sys, `${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.tsc_Colon_The_TypeScript_Compiler)} - ${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.Version_0, ts_js_1.version)}`)];
    output.push(colors.bold((0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.COMMON_COMMANDS)) + sys.newLine + sys.newLine);
    example("tsc", ts_js_1.Diagnostics.Compiles_the_current_project_tsconfig_json_in_the_working_directory);
    example("tsc app.ts util.ts", ts_js_1.Diagnostics.Ignoring_tsconfig_json_compiles_the_specified_files_with_default_compiler_options);
    example("tsc -b", ts_js_1.Diagnostics.Build_a_composite_project_in_the_working_directory);
    example("tsc --init", ts_js_1.Diagnostics.Creates_a_tsconfig_json_with_the_recommended_settings_in_the_working_directory);
    example("tsc -p ./path/to/tsconfig.json", ts_js_1.Diagnostics.Compiles_the_TypeScript_project_located_at_the_specified_path);
    example("tsc --help --all", ts_js_1.Diagnostics.An_expanded_version_of_this_information_showing_all_possible_compiler_options);
    example(["tsc --noEmit", "tsc --target esnext"], ts_js_1.Diagnostics.Compiles_the_current_project_with_additional_settings);
    const cliCommands = simpleOptions.filter(opt => opt.isCommandLineOnly || opt.category === ts_js_1.Diagnostics.Command_line_Options);
    const configOpts = simpleOptions.filter(opt => !(0, ts_js_1.contains)(cliCommands, opt));
    output = [
        ...output,
        ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.COMMAND_LINE_FLAGS), cliCommands, /*subCategory*/ false, /*beforeOptionsDescription*/ undefined, /*afterOptionsDescription*/ undefined),
        ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.COMMON_COMPILER_OPTIONS), configOpts, /*subCategory*/ false, /*beforeOptionsDescription*/ undefined, (0, ts_js_1.formatMessage)(ts_js_1.Diagnostics.You_can_learn_about_all_of_the_compiler_options_at_0, "https://aka.ms/tsc")),
    ];
    for (const line of output) {
        sys.write(line);
    }
    function example(ex, desc) {
        const examples = typeof ex === "string" ? [ex] : ex;
        for (const example of examples) {
            output.push("  " + colors.blue(example) + sys.newLine);
        }
        output.push("  " + (0, ts_js_1.getDiagnosticText)(desc) + sys.newLine + sys.newLine);
    }
}
function printAllHelp(sys, compilerOptions, buildOptions, watchOptions) {
    let output = [...getHeader(sys, `${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.tsc_Colon_The_TypeScript_Compiler)} - ${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.Version_0, ts_js_1.version)}`)];
    output = [...output, ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.ALL_COMPILER_OPTIONS), compilerOptions, /*subCategory*/ true, /*beforeOptionsDescription*/ undefined, (0, ts_js_1.formatMessage)(ts_js_1.Diagnostics.You_can_learn_about_all_of_the_compiler_options_at_0, "https://aka.ms/tsc"))];
    output = [...output, ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.WATCH_OPTIONS), (0, ts_js_1.filter)(watchOptions, option => option.showInHelp !== false), /*subCategory*/ false, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.Including_watch_w_will_start_watching_the_current_project_for_the_file_changes_Once_set_you_can_config_watch_mode_with_Colon))];
    output = [...output, ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.BUILD_OPTIONS), (0, ts_js_1.filter)(buildOptions, option => option !== ts_js_1.tscBuildOption && option.showInHelp !== false), /*subCategory*/ false, (0, ts_js_1.formatMessage)(ts_js_1.Diagnostics.Using_build_b_will_make_tsc_behave_more_like_a_build_orchestrator_than_a_compiler_This_is_used_to_trigger_building_composite_projects_which_you_can_learn_more_about_at_0, "https://aka.ms/tsc-composite-builds"))];
    for (const line of output) {
        sys.write(line);
    }
}
function printBuildHelp(sys, buildOptions) {
    let output = [...getHeader(sys, `${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.tsc_Colon_The_TypeScript_Compiler)} - ${(0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.Version_0, ts_js_1.version)}`)];
    output = [...output, ...generateSectionOptionsOutput(sys, (0, ts_js_1.getDiagnosticText)(ts_js_1.Diagnostics.BUILD_OPTIONS), (0, ts_js_1.filter)(buildOptions, option => option !== ts_js_1.tscBuildOption && option.showInHelp !== false), /*subCategory*/ false, (0, ts_js_1.formatMessage)(ts_js_1.Diagnostics.Using_build_b_will_make_tsc_behave_more_like_a_build_orchestrator_than_a_compiler_This_is_used_to_trigger_building_composite_projects_which_you_can_learn_more_about_at_0, "https://aka.ms/tsc-composite-builds"))];
    for (const line of output) {
        sys.write(line);
    }
}
function getHeader(sys, message) {
    const colors = createColors(sys);
    const header = [];
    const terminalWidth = sys.getWidthOfTerminal?.() ?? 0;
    const tsIconLength = 5;
    const tsIconFirstLine = colors.blueBackground("".padStart(tsIconLength));
    const tsIconSecondLine = colors.blueBackground(colors.brightWhite("TS ".padStart(tsIconLength)));
    // If we have enough space, print TS icon.
    if (terminalWidth >= message.length + tsIconLength) {
        // right align of the icon is 120 at most.
        const rightAlign = terminalWidth > 120 ? 120 : terminalWidth;
        const leftAlign = rightAlign - tsIconLength;
        header.push(message.padEnd(leftAlign) + tsIconFirstLine + sys.newLine);
        header.push("".padStart(leftAlign) + tsIconSecondLine + sys.newLine);
    }
    else {
        header.push(message + sys.newLine);
        header.push(sys.newLine);
    }
    return header;
}
function printHelp(sys, commandLine) {
    if (!commandLine.options.all) {
        printEasyHelp(sys, getOptionsForHelp(commandLine));
    }
    else {
        printAllHelp(sys, getOptionsForHelp(commandLine), ts_js_1.optionsForBuild, ts_js_1.optionsForWatch);
    }
}
function executeCommandLineWorker(sys, cb, commandLine) {
    let reportDiagnostic = (0, ts_js_1.createDiagnosticReporter)(sys);
    // Configuration file name (if any)
    let configFileName;
    if (commandLine.options.locale) {
        (0, ts_js_1.validateLocaleAndSetLanguage)(commandLine.options.locale, sys, commandLine.errors);
    }
    // If there are any errors due to command line parsing and/or
    // setting up localization, report them and quit.
    if (commandLine.errors.length > 0) {
        commandLine.errors.forEach(reportDiagnostic);
        return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
    }
    if (commandLine.options.init) {
        writeConfigFile(sys, reportDiagnostic, commandLine.options);
        return sys.exit(ts_js_1.ExitStatus.Success);
    }
    if (commandLine.options.version) {
        printVersion(sys);
        return sys.exit(ts_js_1.ExitStatus.Success);
    }
    if (commandLine.options.help || commandLine.options.all) {
        printHelp(sys, commandLine);
        return sys.exit(ts_js_1.ExitStatus.Success);
    }
    if (commandLine.options.watch && commandLine.options.listFilesOnly) {
        reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Options_0_and_1_cannot_be_combined, "watch", "listFilesOnly"));
        return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
    }
    if (commandLine.options.project) {
        if (commandLine.fileNames.length !== 0) {
            reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Option_project_cannot_be_mixed_with_source_files_on_a_command_line));
            return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
        }
        const fileOrDirectory = (0, ts_js_1.normalizePath)(commandLine.options.project);
        if (!fileOrDirectory /* current directory "." */ || sys.directoryExists(fileOrDirectory)) {
            configFileName = (0, ts_js_1.combinePaths)(fileOrDirectory, "tsconfig.json");
            if (!sys.fileExists(configFileName)) {
                reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Cannot_find_a_tsconfig_json_file_at_the_specified_directory_Colon_0, commandLine.options.project));
                return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
            }
        }
        else {
            configFileName = fileOrDirectory;
            if (!sys.fileExists(configFileName)) {
                reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.The_specified_path_does_not_exist_Colon_0, commandLine.options.project));
                return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
            }
        }
    }
    else if (!commandLine.options.ignoreConfig || commandLine.fileNames.length === 0) {
        const searchPath = (0, ts_js_1.normalizePath)(sys.getCurrentDirectory());
        configFileName = (0, ts_js_1.findConfigFile)(searchPath, fileName => sys.fileExists(fileName));
        // if (!commandLine.options.ignoreConfig) {
        if (commandLine.fileNames.length !== 0) {
            if (configFileName) {
                // Error to not specify config file
                reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.tsconfig_json_is_present_but_will_not_be_loaded_if_files_are_specified_on_commandline_Use_ignoreConfig_to_skip_this_error));
                return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
            }
        }
        else if (!configFileName) {
            if (commandLine.options.showConfig) {
                reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Cannot_find_a_tsconfig_json_file_at_the_current_directory_Colon_0, (0, ts_js_1.normalizePath)(sys.getCurrentDirectory())));
            }
            else {
                printVersion(sys);
                printHelp(sys, commandLine);
            }
            return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
        }
    }
    const currentDirectory = sys.getCurrentDirectory();
    const commandLineOptions = (0, ts_js_1.convertToOptionsWithAbsolutePaths)(commandLine.options, fileName => (0, ts_js_1.getNormalizedAbsolutePath)(fileName, currentDirectory));
    if (configFileName) {
        const extendedConfigCache = new Map();
        const configParseResult = (0, ts_js_1.parseConfigFileWithSystem)(configFileName, commandLineOptions, extendedConfigCache, commandLine.watchOptions, sys, reportDiagnostic); // TODO: GH#18217
        if (commandLineOptions.showConfig) {
            if (configParseResult.errors.length !== 0) {
                reportDiagnostic = updateReportDiagnostic(sys, reportDiagnostic, configParseResult.options);
                configParseResult.errors.forEach(reportDiagnostic);
                return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
            }
            // eslint-disable-next-line no-restricted-syntax
            sys.write(JSON.stringify((0, ts_js_1.convertToTSConfig)(configParseResult, configFileName, sys), null, 4) + sys.newLine);
            return sys.exit(ts_js_1.ExitStatus.Success);
        }
        reportDiagnostic = updateReportDiagnostic(sys, reportDiagnostic, configParseResult.options);
        if ((0, ts_js_1.isWatchSet)(configParseResult.options)) {
            if (reportWatchModeWithoutSysSupport(sys, reportDiagnostic))
                return;
            return createWatchOfConfigFile(sys, cb, reportDiagnostic, configParseResult, commandLineOptions, commandLine.watchOptions, extendedConfigCache);
        }
        else if ((0, ts_js_1.isIncrementalCompilation)(configParseResult.options)) {
            performIncrementalCompilation(sys, cb, reportDiagnostic, configParseResult);
        }
        else {
            performCompilation(sys, cb, reportDiagnostic, configParseResult);
        }
    }
    else {
        if (commandLineOptions.showConfig) {
            // eslint-disable-next-line no-restricted-syntax
            sys.write(JSON.stringify((0, ts_js_1.convertToTSConfig)(commandLine, (0, ts_js_1.combinePaths)(currentDirectory, "tsconfig.json"), sys), null, 4) + sys.newLine);
            return sys.exit(ts_js_1.ExitStatus.Success);
        }
        reportDiagnostic = updateReportDiagnostic(sys, reportDiagnostic, commandLineOptions);
        if ((0, ts_js_1.isWatchSet)(commandLineOptions)) {
            if (reportWatchModeWithoutSysSupport(sys, reportDiagnostic))
                return;
            return createWatchOfFilesAndCompilerOptions(sys, cb, reportDiagnostic, commandLine.fileNames, commandLineOptions, commandLine.watchOptions);
        }
        else if ((0, ts_js_1.isIncrementalCompilation)(commandLineOptions)) {
            performIncrementalCompilation(sys, cb, reportDiagnostic, { ...commandLine, options: commandLineOptions });
        }
        else {
            performCompilation(sys, cb, reportDiagnostic, { ...commandLine, options: commandLineOptions });
        }
    }
}
/** Returns true if commandline is --build and needs to be parsed useing parseBuildCommand */
function isBuildCommand(commandLineArgs) {
    if (commandLineArgs.length > 0 && commandLineArgs[0].charCodeAt(0) === 45 /* CharacterCodes.minus */) {
        const firstOption = commandLineArgs[0].slice(commandLineArgs[0].charCodeAt(1) === 45 /* CharacterCodes.minus */ ? 2 : 1).toLowerCase();
        return firstOption === ts_js_1.tscBuildOption.name || firstOption === ts_js_1.tscBuildOption.shortName;
    }
    return false;
}
/** @internal */
function executeCommandLine(system, cb, commandLineArgs) {
    if (isBuildCommand(commandLineArgs)) {
        const { buildOptions, watchOptions, projects, errors } = (0, ts_js_1.parseBuildCommand)(commandLineArgs);
        if (buildOptions.generateCpuProfile && system.enableCPUProfiler) {
            system.enableCPUProfiler(buildOptions.generateCpuProfile, () => performBuild(system, cb, buildOptions, watchOptions, projects, errors));
        }
        else {
            return performBuild(system, cb, buildOptions, watchOptions, projects, errors);
        }
    }
    const commandLine = (0, ts_js_1.parseCommandLine)(commandLineArgs, path => system.readFile(path));
    if (commandLine.options.generateCpuProfile && system.enableCPUProfiler) {
        system.enableCPUProfiler(commandLine.options.generateCpuProfile, () => executeCommandLineWorker(system, cb, commandLine));
    }
    else {
        return executeCommandLineWorker(system, cb, commandLine);
    }
}
function reportWatchModeWithoutSysSupport(sys, reportDiagnostic) {
    if (!sys.watchFile || !sys.watchDirectory) {
        reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.The_current_host_does_not_support_the_0_option, "--watch"));
        sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
        return true;
    }
    return false;
}
// This could be inlined everywhere, but this is convenient for debugging and patching.
const defaultJSDocParsingMode = 2 /* JSDocParsingMode.ParseForTypeErrors */;
function performBuild(sys, cb, buildOptions, watchOptions, projects, errors) {
    // Update to pretty if host supports it
    const reportDiagnostic = updateReportDiagnostic(sys, (0, ts_js_1.createDiagnosticReporter)(sys), buildOptions);
    if (buildOptions.locale) {
        (0, ts_js_1.validateLocaleAndSetLanguage)(buildOptions.locale, sys, errors);
    }
    if (errors.length > 0) {
        errors.forEach(reportDiagnostic);
        return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
    }
    if (buildOptions.help) {
        printVersion(sys);
        printBuildHelp(sys, ts_js_1.buildOpts);
        return sys.exit(ts_js_1.ExitStatus.Success);
    }
    if (projects.length === 0) {
        printVersion(sys);
        printBuildHelp(sys, ts_js_1.buildOpts);
        return sys.exit(ts_js_1.ExitStatus.Success);
    }
    if (!sys.getModifiedTime || !sys.setModifiedTime || (buildOptions.clean && !sys.deleteFile)) {
        reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.The_current_host_does_not_support_the_0_option, "--build"));
        return sys.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
    }
    if (buildOptions.watch) {
        if (reportWatchModeWithoutSysSupport(sys, reportDiagnostic))
            return;
        const buildHost = (0, ts_js_1.createSolutionBuilderWithWatchHost)(sys, 
        /*createProgram*/ undefined, reportDiagnostic, (0, ts_js_1.createBuilderStatusReporter)(sys, shouldBePretty(sys, buildOptions)), createWatchStatusReporter(sys, buildOptions));
        buildHost.jsDocParsingMode = defaultJSDocParsingMode;
        const solutionPerformance = enableSolutionPerformance(sys, buildOptions);
        updateSolutionBuilderHost(sys, cb, buildHost, solutionPerformance);
        const onWatchStatusChange = buildHost.onWatchStatusChange;
        let reportBuildStatistics = false;
        buildHost.onWatchStatusChange = (d, newLine, options, errorCount) => {
            onWatchStatusChange?.(d, newLine, options, errorCount);
            if (reportBuildStatistics && (d.code === ts_js_1.Diagnostics.Found_0_errors_Watching_for_file_changes.code ||
                d.code === ts_js_1.Diagnostics.Found_1_error_Watching_for_file_changes.code)) {
                reportSolutionBuilderTimes(builder, solutionPerformance);
            }
        };
        const builder = (0, ts_js_1.createSolutionBuilderWithWatch)(buildHost, projects, buildOptions, watchOptions);
        builder.build();
        reportSolutionBuilderTimes(builder, solutionPerformance);
        reportBuildStatistics = true;
        return builder;
    }
    const buildHost = (0, ts_js_1.createSolutionBuilderHost)(sys, 
    /*createProgram*/ undefined, reportDiagnostic, (0, ts_js_1.createBuilderStatusReporter)(sys, shouldBePretty(sys, buildOptions)), createReportErrorSummary(sys, buildOptions));
    buildHost.jsDocParsingMode = defaultJSDocParsingMode;
    const solutionPerformance = enableSolutionPerformance(sys, buildOptions);
    updateSolutionBuilderHost(sys, cb, buildHost, solutionPerformance);
    const builder = (0, ts_js_1.createSolutionBuilder)(buildHost, projects, buildOptions);
    const exitStatus = buildOptions.clean ? builder.clean() : builder.build();
    reportSolutionBuilderTimes(builder, solutionPerformance);
    (0, ts_js_1.dumpTracingLegend)(); // Will no-op if there hasn't been any tracing
    return sys.exit(exitStatus);
}
function createReportErrorSummary(sys, options) {
    return shouldBePretty(sys, options) ?
        (errorCount, filesInError) => sys.write((0, ts_js_1.getErrorSummaryText)(errorCount, filesInError, sys.newLine, sys)) :
        undefined;
}
function performCompilation(sys, cb, reportDiagnostic, config) {
    const { fileNames, options, projectReferences } = config;
    const host = (0, ts_js_1.createCompilerHostWorker)(options, /*setParentNodes*/ undefined, sys);
    host.jsDocParsingMode = defaultJSDocParsingMode;
    const currentDirectory = host.getCurrentDirectory();
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames());
    (0, ts_js_1.changeCompilerHostLikeToUseCache)(host, fileName => (0, ts_js_1.toPath)(fileName, currentDirectory, getCanonicalFileName));
    enableStatisticsAndTracing(sys, options, /*isBuildMode*/ false);
    const programOptions = {
        rootNames: fileNames,
        options,
        projectReferences,
        host,
        configFileParsingDiagnostics: (0, ts_js_1.getConfigFileParsingDiagnostics)(config),
    };
    const program = (0, ts_js_1.createProgram)(programOptions);
    const exitStatus = (0, ts_js_1.emitFilesAndReportErrorsAndGetExitStatus)(program, reportDiagnostic, s => sys.write(s + sys.newLine), createReportErrorSummary(sys, options));
    reportStatistics(sys, program, /*solutionPerformance*/ undefined);
    cb(program);
    return sys.exit(exitStatus);
}
function performIncrementalCompilation(sys, cb, reportDiagnostic, config) {
    const { options, fileNames, projectReferences } = config;
    enableStatisticsAndTracing(sys, options, /*isBuildMode*/ false);
    const host = (0, ts_js_1.createIncrementalCompilerHost)(options, sys);
    host.jsDocParsingMode = defaultJSDocParsingMode;
    const exitStatus = (0, ts_js_1.performIncrementalCompilation)({
        host,
        system: sys,
        rootNames: fileNames,
        options,
        configFileParsingDiagnostics: (0, ts_js_1.getConfigFileParsingDiagnostics)(config),
        projectReferences,
        reportDiagnostic,
        reportErrorSummary: createReportErrorSummary(sys, options),
        afterProgramEmitAndDiagnostics: builderProgram => {
            reportStatistics(sys, builderProgram.getProgram(), /*solutionPerformance*/ undefined);
            cb(builderProgram);
        },
    });
    return sys.exit(exitStatus);
}
function updateSolutionBuilderHost(sys, cb, buildHost, solutionPerformance) {
    updateCreateProgram(sys, buildHost, /*isBuildMode*/ true);
    buildHost.afterProgramEmitAndDiagnostics = program => {
        reportStatistics(sys, program.getProgram(), solutionPerformance);
        cb(program);
    };
}
function updateCreateProgram(sys, host, isBuildMode) {
    const compileUsingBuilder = host.createProgram;
    host.createProgram = (rootNames, options, host, oldProgram, configFileParsingDiagnostics, projectReferences) => {
        ts_js_1.Debug.assert(rootNames !== undefined || (options === undefined && !!oldProgram));
        if (options !== undefined) {
            enableStatisticsAndTracing(sys, options, isBuildMode);
        }
        return compileUsingBuilder(rootNames, options, host, oldProgram, configFileParsingDiagnostics, projectReferences);
    };
}
function updateWatchCompilationHost(sys, cb, watchCompilerHost) {
    watchCompilerHost.jsDocParsingMode = defaultJSDocParsingMode;
    updateCreateProgram(sys, watchCompilerHost, /*isBuildMode*/ false);
    const emitFilesUsingBuilder = watchCompilerHost.afterProgramCreate; // TODO: GH#18217
    watchCompilerHost.afterProgramCreate = builderProgram => {
        emitFilesUsingBuilder(builderProgram);
        reportStatistics(sys, builderProgram.getProgram(), /*solutionPerformance*/ undefined);
        cb(builderProgram);
    };
}
function createWatchStatusReporter(sys, options) {
    return (0, ts_js_1.createWatchStatusReporter)(sys, shouldBePretty(sys, options));
}
function createWatchOfConfigFile(system, cb, reportDiagnostic, configParseResult, optionsToExtend, watchOptionsToExtend, extendedConfigCache) {
    const watchCompilerHost = (0, ts_js_1.createWatchCompilerHostOfConfigFile)({
        configFileName: configParseResult.options.configFilePath,
        optionsToExtend,
        watchOptionsToExtend,
        system,
        reportDiagnostic,
        reportWatchStatus: createWatchStatusReporter(system, configParseResult.options),
    });
    updateWatchCompilationHost(system, cb, watchCompilerHost);
    watchCompilerHost.configFileParsingResult = configParseResult;
    watchCompilerHost.extendedConfigCache = extendedConfigCache;
    return (0, ts_js_1.createWatchProgram)(watchCompilerHost);
}
function createWatchOfFilesAndCompilerOptions(system, cb, reportDiagnostic, rootFiles, options, watchOptions) {
    const watchCompilerHost = (0, ts_js_1.createWatchCompilerHostOfFilesAndCompilerOptions)({
        rootFiles,
        options,
        watchOptions,
        system,
        reportDiagnostic,
        reportWatchStatus: createWatchStatusReporter(system, options),
    });
    updateWatchCompilationHost(system, cb, watchCompilerHost);
    return (0, ts_js_1.createWatchProgram)(watchCompilerHost);
}
function enableSolutionPerformance(system, options) {
    if (system === ts_js_1.sys && options.extendedDiagnostics) {
        performance.enable();
        return createSolutionPerfomrance();
    }
}
function createSolutionPerfomrance() {
    let statistics;
    return {
        addAggregateStatistic,
        forEachAggregateStatistics: forEachAggreateStatistics,
        clear,
    };
    function addAggregateStatistic(s) {
        const existing = statistics?.get(s.name);
        if (existing) {
            if (existing.type === StatisticType.memory)
                existing.value = Math.max(existing.value, s.value);
            else
                existing.value += s.value;
        }
        else {
            (statistics ?? (statistics = new Map())).set(s.name, s);
        }
    }
    function forEachAggreateStatistics(cb) {
        statistics?.forEach(cb);
    }
    function clear() {
        statistics = undefined;
    }
}
function reportSolutionBuilderTimes(builder, solutionPerformance) {
    if (!solutionPerformance)
        return;
    if (!performance.isEnabled()) {
        ts_js_1.sys.write(ts_js_1.Diagnostics.Performance_timings_for_diagnostics_or_extendedDiagnostics_are_not_available_in_this_session_A_native_implementation_of_the_Web_Performance_API_could_not_be_found.message + "\n");
        return;
    }
    const statistics = [];
    statistics.push({ name: "Projects in scope", value: (0, ts_js_1.getBuildOrderFromAnyBuildOrder)(builder.getBuildOrder()).length, type: StatisticType.count });
    reportSolutionBuilderCountStatistic("SolutionBuilder::Projects built");
    reportSolutionBuilderCountStatistic("SolutionBuilder::Timestamps only updates");
    reportSolutionBuilderCountStatistic("SolutionBuilder::Bundles updated");
    solutionPerformance.forEachAggregateStatistics(s => {
        s.name = `Aggregate ${s.name}`;
        statistics.push(s);
    });
    performance.forEachMeasure((name, duration) => {
        if (isSolutionMarkOrMeasure(name))
            statistics.push({ name: `${getNameFromSolutionBuilderMarkOrMeasure(name)} time`, value: duration, type: StatisticType.time });
    });
    performance.disable();
    performance.enable();
    solutionPerformance.clear();
    reportAllStatistics(ts_js_1.sys, statistics);
    function reportSolutionBuilderCountStatistic(name) {
        const value = performance.getCount(name);
        if (value) {
            statistics.push({ name: getNameFromSolutionBuilderMarkOrMeasure(name), value, type: StatisticType.count });
        }
    }
    function getNameFromSolutionBuilderMarkOrMeasure(name) {
        return name.replace("SolutionBuilder::", "");
    }
}
function canReportDiagnostics(system, compilerOptions) {
    return system === ts_js_1.sys && (compilerOptions.diagnostics || compilerOptions.extendedDiagnostics);
}
function canTrace(system, compilerOptions) {
    return system === ts_js_1.sys && compilerOptions.generateTrace;
}
function enableStatisticsAndTracing(system, compilerOptions, isBuildMode) {
    if (canReportDiagnostics(system, compilerOptions)) {
        performance.enable(system);
    }
    if (canTrace(system, compilerOptions)) {
        (0, ts_js_1.startTracing)(isBuildMode ? "build" : "project", compilerOptions.generateTrace, compilerOptions.configFilePath);
    }
}
function isSolutionMarkOrMeasure(name) {
    return (0, ts_js_1.startsWith)(name, "SolutionBuilder::");
}
function reportStatistics(sys, program, solutionPerformance) {
    const compilerOptions = program.getCompilerOptions();
    if (canTrace(sys, compilerOptions)) {
        ts_js_1.tracing?.stopTracing();
    }
    let statistics;
    if (canReportDiagnostics(sys, compilerOptions)) {
        statistics = [];
        const memoryUsed = sys.getMemoryUsage ? sys.getMemoryUsage() : -1;
        reportCountStatistic("Files", program.getSourceFiles().length);
        const lineCounts = countLines(program);
        if (compilerOptions.extendedDiagnostics) {
            for (const [key, value] of lineCounts.entries()) {
                reportCountStatistic("Lines of " + key, value);
            }
        }
        else {
            reportCountStatistic("Lines", (0, ts_js_1.reduceLeftIterator)(lineCounts.values(), (sum, count) => sum + count, 0));
        }
        reportCountStatistic("Identifiers", program.getIdentifierCount());
        reportCountStatistic("Symbols", program.getSymbolCount());
        reportCountStatistic("Types", program.getTypeCount());
        reportCountStatistic("Instantiations", program.getInstantiationCount());
        if (memoryUsed >= 0) {
            reportStatisticalValue({ name: "Memory used", value: memoryUsed, type: StatisticType.memory }, /*aggregate*/ true);
        }
        const isPerformanceEnabled = performance.isEnabled();
        const programTime = isPerformanceEnabled ? performance.getDuration("Program") : 0;
        const bindTime = isPerformanceEnabled ? performance.getDuration("Bind") : 0;
        const checkTime = isPerformanceEnabled ? performance.getDuration("Check") : 0;
        const emitTime = isPerformanceEnabled ? performance.getDuration("Emit") : 0;
        if (compilerOptions.extendedDiagnostics) {
            const caches = program.getRelationCacheSizes();
            reportCountStatistic("Assignability cache size", caches.assignable);
            reportCountStatistic("Identity cache size", caches.identity);
            reportCountStatistic("Subtype cache size", caches.subtype);
            reportCountStatistic("Strict subtype cache size", caches.strictSubtype);
            if (isPerformanceEnabled) {
                performance.forEachMeasure((name, duration) => {
                    if (!isSolutionMarkOrMeasure(name))
                        reportTimeStatistic(`${name} time`, duration, /*aggregate*/ true);
                });
            }
        }
        else if (isPerformanceEnabled) {
            // Individual component times.
            // Note: To match the behavior of previous versions of the compiler, the reported parse time includes
            // I/O read time and processing time for triple-slash references and module imports, and the reported
            // emit time includes I/O write time. We preserve this behavior so we can accurately compare times.
            reportTimeStatistic("I/O read", performance.getDuration("I/O Read"), /*aggregate*/ true);
            reportTimeStatistic("I/O write", performance.getDuration("I/O Write"), /*aggregate*/ true);
            reportTimeStatistic("Parse time", programTime, /*aggregate*/ true);
            reportTimeStatistic("Bind time", bindTime, /*aggregate*/ true);
            reportTimeStatistic("Check time", checkTime, /*aggregate*/ true);
            reportTimeStatistic("Emit time", emitTime, /*aggregate*/ true);
        }
        if (isPerformanceEnabled) {
            reportTimeStatistic("Total time", programTime + bindTime + checkTime + emitTime, /*aggregate*/ false);
        }
        reportAllStatistics(sys, statistics);
        if (!isPerformanceEnabled) {
            sys.write(ts_js_1.Diagnostics.Performance_timings_for_diagnostics_or_extendedDiagnostics_are_not_available_in_this_session_A_native_implementation_of_the_Web_Performance_API_could_not_be_found.message + "\n");
        }
        else {
            if (solutionPerformance) {
                // Clear selected marks and measures
                performance.forEachMeasure(name => {
                    if (!isSolutionMarkOrMeasure(name))
                        performance.clearMeasures(name);
                });
                performance.forEachMark(name => {
                    if (!isSolutionMarkOrMeasure(name))
                        performance.clearMarks(name);
                });
            }
            else {
                performance.disable();
            }
        }
    }
    function reportStatisticalValue(s, aggregate) {
        statistics.push(s);
        if (aggregate)
            solutionPerformance?.addAggregateStatistic(s);
    }
    function reportCountStatistic(name, count) {
        reportStatisticalValue({ name, value: count, type: StatisticType.count }, /*aggregate*/ true);
    }
    function reportTimeStatistic(name, time, aggregate) {
        reportStatisticalValue({ name, value: time, type: StatisticType.time }, aggregate);
    }
}
function reportAllStatistics(sys, statistics) {
    let nameSize = 0;
    let valueSize = 0;
    for (const s of statistics) {
        if (s.name.length > nameSize) {
            nameSize = s.name.length;
        }
        const value = statisticValue(s);
        if (value.length > valueSize) {
            valueSize = value.length;
        }
    }
    for (const s of statistics) {
        sys.write(`${s.name}:`.padEnd(nameSize + 2) + statisticValue(s).toString().padStart(valueSize) + sys.newLine);
    }
}
function statisticValue(s) {
    switch (s.type) {
        case StatisticType.count:
            return "" + s.value;
        case StatisticType.time:
            return (s.value / 1000).toFixed(2) + "s";
        case StatisticType.memory:
            return Math.round(s.value / 1000) + "K";
        default:
            ts_js_1.Debug.assertNever(s.type);
    }
}
function writeConfigFile(sys, reportDiagnostic, options) {
    const currentDirectory = sys.getCurrentDirectory();
    const file = (0, ts_js_1.normalizePath)((0, ts_js_1.combinePaths)(currentDirectory, "tsconfig.json"));
    if (sys.fileExists(file)) {
        reportDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.A_tsconfig_json_file_is_already_defined_at_Colon_0, file));
    }
    else {
        sys.writeFile(file, (0, ts_js_1.generateTSConfig)(options, sys.newLine));
        const output = [sys.newLine, ...getHeader(sys, "Created a new tsconfig.json")];
        output.push(`You can learn more at https://aka.ms/tsconfig` + sys.newLine);
        for (const line of output) {
            sys.write(line);
        }
    }
    return;
}
