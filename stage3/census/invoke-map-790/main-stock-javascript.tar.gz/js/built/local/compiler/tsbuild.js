"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpToDateStatusType = void 0;
exports.resolveConfigFileProjectName = resolveConfigFileProjectName;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
var UpToDateStatusType;
(function (UpToDateStatusType) {
    UpToDateStatusType[UpToDateStatusType["Unbuildable"] = 0] = "Unbuildable";
    UpToDateStatusType[UpToDateStatusType["UpToDate"] = 1] = "UpToDate";
    /**
     * The project appears out of date because its upstream inputs are newer than its outputs,
     * but all of its outputs are actually newer than the previous identical outputs of its (.d.ts) inputs.
     * This means we can Pseudo-build (just touch timestamps), as if we had actually built this project.
     */
    UpToDateStatusType[UpToDateStatusType["UpToDateWithUpstreamTypes"] = 2] = "UpToDateWithUpstreamTypes";
    UpToDateStatusType[UpToDateStatusType["OutputMissing"] = 3] = "OutputMissing";
    UpToDateStatusType[UpToDateStatusType["ErrorReadingFile"] = 4] = "ErrorReadingFile";
    UpToDateStatusType[UpToDateStatusType["OutOfDateWithSelf"] = 5] = "OutOfDateWithSelf";
    UpToDateStatusType[UpToDateStatusType["OutOfDateWithUpstream"] = 6] = "OutOfDateWithUpstream";
    UpToDateStatusType[UpToDateStatusType["OutOfDateBuildInfoWithPendingEmit"] = 7] = "OutOfDateBuildInfoWithPendingEmit";
    UpToDateStatusType[UpToDateStatusType["OutOfDateBuildInfoWithErrors"] = 8] = "OutOfDateBuildInfoWithErrors";
    UpToDateStatusType[UpToDateStatusType["OutOfDateOptions"] = 9] = "OutOfDateOptions";
    UpToDateStatusType[UpToDateStatusType["OutOfDateRoots"] = 10] = "OutOfDateRoots";
    UpToDateStatusType[UpToDateStatusType["UpstreamOutOfDate"] = 11] = "UpstreamOutOfDate";
    UpToDateStatusType[UpToDateStatusType["UpstreamBlocked"] = 12] = "UpstreamBlocked";
    UpToDateStatusType[UpToDateStatusType["ComputingUpstream"] = 13] = "ComputingUpstream";
    UpToDateStatusType[UpToDateStatusType["TsVersionOutputOfDate"] = 14] = "TsVersionOutputOfDate";
    UpToDateStatusType[UpToDateStatusType["UpToDateWithInputFileText"] = 15] = "UpToDateWithInputFileText";
    /**
     * Projects with no outputs (i.e. "solution" files)
     */
    UpToDateStatusType[UpToDateStatusType["ContainerOnly"] = 16] = "ContainerOnly";
    UpToDateStatusType[UpToDateStatusType["ForceBuild"] = 17] = "ForceBuild";
})(UpToDateStatusType || (exports.UpToDateStatusType = UpToDateStatusType = {}));
/** @internal */
function resolveConfigFileProjectName(project) {
    if ((0, ts_js_1.fileExtensionIs)(project, ".json" /* Extension.Json */)) {
        return project;
    }
    return (0, ts_js_1.combinePaths)(project, "tsconfig.json");
}
