"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WatchType = exports.returnNoopFileWatcher = exports.noopFileWatcher = void 0;
exports.createDiagnosticReporter = createDiagnosticReporter;
exports.getLocaleTimeString = getLocaleTimeString;
exports.createWatchStatusReporter = createWatchStatusReporter;
exports.parseConfigFileWithSystem = parseConfigFileWithSystem;
exports.getErrorCountForSummary = getErrorCountForSummary;
exports.getFilesInErrorForSummary = getFilesInErrorForSummary;
exports.getWatchErrorSummaryDiagnosticMessage = getWatchErrorSummaryDiagnosticMessage;
exports.getErrorSummaryText = getErrorSummaryText;
exports.isBuilderProgram = isBuilderProgram;
exports.explainFiles = explainFiles;
exports.explainIfFileIsRedirectAndImpliedFormat = explainIfFileIsRedirectAndImpliedFormat;
exports.getMatchedFileSpec = getMatchedFileSpec;
exports.getMatchedIncludeSpec = getMatchedIncludeSpec;
exports.fileIncludeReasonToDiagnostics = fileIncludeReasonToDiagnostics;
exports.emitFilesAndReportErrors = emitFilesAndReportErrors;
exports.emitFilesAndReportErrorsAndGetExitStatus = emitFilesAndReportErrorsAndGetExitStatus;
exports.createWatchHost = createWatchHost;
exports.createWatchFactory = createWatchFactory;
exports.createCompilerHostFromProgramHost = createCompilerHostFromProgramHost;
exports.getSourceFileVersionAsHashFromText = getSourceFileVersionAsHashFromText;
exports.setGetSourceFileAsHashVersioned = setGetSourceFileAsHashVersioned;
exports.createProgramHost = createProgramHost;
exports.createWatchCompilerHostOfConfigFile = createWatchCompilerHostOfConfigFile;
exports.createWatchCompilerHostOfFilesAndCompilerOptions = createWatchCompilerHostOfFilesAndCompilerOptions;
exports.performIncrementalCompilation = performIncrementalCompilation;
const ts_js_1 = require("./_namespaces/ts.js");
const sysFormatDiagnosticsHost = ts_js_1.sys ? {
    getCurrentDirectory: () => ts_js_1.sys.getCurrentDirectory(),
    getNewLine: () => ts_js_1.sys.newLine,
    getCanonicalFileName: (0, ts_js_1.createGetCanonicalFileName)(ts_js_1.sys.useCaseSensitiveFileNames),
} : undefined;
/**
 * Create a function that reports error by writing to the system and handles the formatting of the diagnostic
 *
 * @internal
 */
function createDiagnosticReporter(system, pretty) {
    const host = system === ts_js_1.sys && sysFormatDiagnosticsHost ? sysFormatDiagnosticsHost : {
        getCurrentDirectory: () => system.getCurrentDirectory(),
        getNewLine: () => system.newLine,
        getCanonicalFileName: (0, ts_js_1.createGetCanonicalFileName)(system.useCaseSensitiveFileNames),
    };
    if (!pretty) {
        return diagnostic => system.write((0, ts_js_1.formatDiagnostic)(diagnostic, host));
    }
    const diagnostics = new Array(1);
    return diagnostic => {
        diagnostics[0] = diagnostic;
        system.write((0, ts_js_1.formatDiagnosticsWithColorAndContext)(diagnostics, host) + host.getNewLine());
        diagnostics[0] = undefined; // TODO: GH#18217
    };
}
/**
 * @returns Whether the screen was cleared.
 */
function clearScreenIfNotWatchingForFileChanges(system, diagnostic, options) {
    if (system.clearScreen &&
        !options.preserveWatchOutput &&
        !options.extendedDiagnostics &&
        !options.diagnostics &&
        (0, ts_js_1.contains)(screenStartingMessageCodes, diagnostic.code)) {
        system.clearScreen();
        return true;
    }
    return false;
}
const screenStartingMessageCodes = [
    ts_js_1.Diagnostics.Starting_compilation_in_watch_mode.code,
    ts_js_1.Diagnostics.File_change_detected_Starting_incremental_compilation.code,
];
function getPlainDiagnosticFollowingNewLines(diagnostic, newLine) {
    return (0, ts_js_1.contains)(screenStartingMessageCodes, diagnostic.code)
        ? newLine + newLine
        : newLine;
}
/**
 * Get locale specific time based on whether we are in test mode
 *
 * @internal
 */
function getLocaleTimeString(system) {
    return !system.now ?
        new Date().toLocaleTimeString() :
        // On some systems / builds of Node, there's a non-breaking space between the time and AM/PM.
        // This branch is solely for testing, so just switch it to a normal space for baseline stability.
        // See:
        //     - https://github.com/nodejs/node/issues/45171
        //     - https://github.com/nodejs/node/issues/45753
        system.now().toLocaleTimeString("en-US", { timeZone: "UTC" }).replace("\u202f", " ");
}
/**
 * Create a function that reports watch status by writing to the system and handles the formatting of the diagnostic
 *
 * @internal
 */
function createWatchStatusReporter(system, pretty) {
    return pretty ?
        (diagnostic, newLine, options) => {
            clearScreenIfNotWatchingForFileChanges(system, diagnostic, options);
            let output = `[${(0, ts_js_1.formatColorAndReset)(getLocaleTimeString(system), ts_js_1.ForegroundColorEscapeSequences.Grey)}] `;
            output += `${(0, ts_js_1.flattenDiagnosticMessageText)(diagnostic.messageText, system.newLine)}${newLine + newLine}`;
            system.write(output);
        } :
        (diagnostic, newLine, options) => {
            let output = "";
            if (!clearScreenIfNotWatchingForFileChanges(system, diagnostic, options)) {
                output += newLine;
            }
            output += `${getLocaleTimeString(system)} - `;
            output += `${(0, ts_js_1.flattenDiagnosticMessageText)(diagnostic.messageText, system.newLine)}${getPlainDiagnosticFollowingNewLines(diagnostic, newLine)}`;
            system.write(output);
        };
}
/**
 * Parses config file using System interface
 *
 * @internal
 */
function parseConfigFileWithSystem(configFileName, optionsToExtend, extendedConfigCache, watchOptionsToExtend, system, reportDiagnostic) {
    const host = system;
    host.onUnRecoverableConfigFileDiagnostic = diagnostic => reportUnrecoverableDiagnostic(system, reportDiagnostic, diagnostic);
    const result = (0, ts_js_1.getParsedCommandLineOfConfigFile)(configFileName, optionsToExtend, host, extendedConfigCache, watchOptionsToExtend);
    host.onUnRecoverableConfigFileDiagnostic = undefined; // TODO: GH#18217
    return result;
}
/** @internal */
function getErrorCountForSummary(diagnostics) {
    return (0, ts_js_1.countWhere)(diagnostics, diagnostic => diagnostic.category === ts_js_1.DiagnosticCategory.Error);
}
/** @internal */
function getFilesInErrorForSummary(diagnostics) {
    const filesInError = (0, ts_js_1.filter)(diagnostics, diagnostic => diagnostic.category === ts_js_1.DiagnosticCategory.Error)
        .map(errorDiagnostic => {
        if (errorDiagnostic.file === undefined)
            return;
        return `${errorDiagnostic.file.fileName}`;
    });
    return filesInError.map(fileName => {
        if (fileName === undefined) {
            return undefined;
        }
        const diagnosticForFileName = (0, ts_js_1.find)(diagnostics, diagnostic => diagnostic.file !== undefined && diagnostic.file.fileName === fileName);
        if (diagnosticForFileName !== undefined) {
            const { line } = (0, ts_js_1.getLineAndCharacterOfPosition)(diagnosticForFileName.file, diagnosticForFileName.start);
            return {
                fileName,
                line: line + 1,
            };
        }
    });
}
/** @internal */
function getWatchErrorSummaryDiagnosticMessage(errorCount) {
    return errorCount === 1 ?
        ts_js_1.Diagnostics.Found_1_error_Watching_for_file_changes :
        ts_js_1.Diagnostics.Found_0_errors_Watching_for_file_changes;
}
function prettyPathForFileError(error, cwd) {
    const line = (0, ts_js_1.formatColorAndReset)(":" + error.line, ts_js_1.ForegroundColorEscapeSequences.Grey);
    if ((0, ts_js_1.pathIsAbsolute)(error.fileName) && (0, ts_js_1.pathIsAbsolute)(cwd)) {
        return (0, ts_js_1.getRelativePathFromDirectory)(cwd, error.fileName, /*ignoreCase*/ false) + line;
    }
    return error.fileName + line;
}
/** @internal */
function getErrorSummaryText(errorCount, filesInError, newLine, host) {
    if (errorCount === 0)
        return "";
    const nonNilFiles = filesInError.filter(fileInError => fileInError !== undefined);
    const distinctFileNamesWithLines = nonNilFiles.map(fileInError => `${fileInError.fileName}:${fileInError.line}`)
        .filter((value, index, self) => self.indexOf(value) === index);
    const firstFileReference = nonNilFiles[0] && prettyPathForFileError(nonNilFiles[0], host.getCurrentDirectory());
    let messageAndArgs;
    if (errorCount === 1) {
        messageAndArgs = filesInError[0] !== undefined ? [ts_js_1.Diagnostics.Found_1_error_in_0, firstFileReference] : [ts_js_1.Diagnostics.Found_1_error];
    }
    else {
        messageAndArgs = distinctFileNamesWithLines.length === 0 ? [ts_js_1.Diagnostics.Found_0_errors, errorCount] :
            distinctFileNamesWithLines.length === 1 ? [ts_js_1.Diagnostics.Found_0_errors_in_the_same_file_starting_at_Colon_1, errorCount, firstFileReference] :
                [ts_js_1.Diagnostics.Found_0_errors_in_1_files, errorCount, distinctFileNamesWithLines.length];
    }
    const d = (0, ts_js_1.createCompilerDiagnostic)(...messageAndArgs);
    const suffix = distinctFileNamesWithLines.length > 1 ? createTabularErrorsDisplay(nonNilFiles, host) : "";
    return `${newLine}${(0, ts_js_1.flattenDiagnosticMessageText)(d.messageText, newLine)}${newLine}${newLine}${suffix}`;
}
function createTabularErrorsDisplay(filesInError, host) {
    const distinctFiles = filesInError.filter((value, index, self) => index === self.findIndex(file => file?.fileName === value?.fileName));
    if (distinctFiles.length === 0)
        return "";
    const numberLength = (num) => Math.log(num) * Math.LOG10E + 1;
    const fileToErrorCount = distinctFiles.map(file => [file, (0, ts_js_1.countWhere)(filesInError, fileInError => fileInError.fileName === file.fileName)]);
    const maxErrors = (0, ts_js_1.maxBy)(fileToErrorCount, 0, value => value[1]);
    const headerRow = ts_js_1.Diagnostics.Errors_Files.message;
    const leftColumnHeadingLength = headerRow.split(" ")[0].length;
    const leftPaddingGoal = Math.max(leftColumnHeadingLength, numberLength(maxErrors));
    const headerPadding = Math.max(numberLength(maxErrors) - leftColumnHeadingLength, 0);
    let tabularData = "";
    tabularData += " ".repeat(headerPadding) + headerRow + "\n";
    fileToErrorCount.forEach(row => {
        const [file, errorCount] = row;
        const errorCountDigitsLength = Math.log(errorCount) * Math.LOG10E + 1 | 0;
        const leftPadding = errorCountDigitsLength < leftPaddingGoal ?
            " ".repeat(leftPaddingGoal - errorCountDigitsLength)
            : "";
        const fileRef = prettyPathForFileError(file, host.getCurrentDirectory());
        tabularData += `${leftPadding}${errorCount}  ${fileRef}\n`;
    });
    return tabularData;
}
/** @internal */
function isBuilderProgram(program) {
    return !!program.state;
}
function listFiles(program, write) {
    const options = program.getCompilerOptions();
    if (options.explainFiles) {
        explainFiles(isBuilderProgram(program) ? program.getProgram() : program, write);
    }
    else if (options.listFiles || options.listFilesOnly) {
        (0, ts_js_1.forEach)(program.getSourceFiles(), file => {
            write(file.fileName);
        });
    }
}
/** @internal */
function explainFiles(program, write) {
    const reasons = program.getFileIncludeReasons();
    const relativeFileName = (fileName) => (0, ts_js_1.convertToRelativePath)(fileName, program.getCurrentDirectory(), program.getCanonicalFileName);
    for (const file of program.getSourceFiles()) {
        write(`${toFileName(file, relativeFileName)}`);
        reasons.get(file.path)?.forEach(reason => write(`  ${fileIncludeReasonToDiagnostics(program, reason, relativeFileName).messageText}`));
        explainIfFileIsRedirectAndImpliedFormat(file, program.getCompilerOptionsForFile(file), relativeFileName)?.forEach(d => write(`  ${d.messageText}`));
    }
}
/** @internal */
function explainIfFileIsRedirectAndImpliedFormat(file, options, fileNameConvertor) {
    let result;
    if (file.path !== file.resolvedPath) {
        (result ?? (result = [])).push((0, ts_js_1.chainDiagnosticMessages)(
        /*details*/ undefined, ts_js_1.Diagnostics.File_is_output_of_project_reference_source_0, toFileName(file.originalFileName, fileNameConvertor)));
    }
    if (file.redirectInfo) {
        (result ?? (result = [])).push((0, ts_js_1.chainDiagnosticMessages)(
        /*details*/ undefined, ts_js_1.Diagnostics.File_redirects_to_file_0, toFileName(file.redirectInfo.redirectTarget, fileNameConvertor)));
    }
    if ((0, ts_js_1.isExternalOrCommonJsModule)(file)) {
        switch ((0, ts_js_1.getImpliedNodeFormatForEmitWorker)(file, options)) {
            case ts_js_1.ModuleKind.ESNext:
                if (file.packageJsonScope) {
                    (result ?? (result = [])).push((0, ts_js_1.chainDiagnosticMessages)(
                    /*details*/ undefined, ts_js_1.Diagnostics.File_is_ECMAScript_module_because_0_has_field_type_with_value_module, toFileName((0, ts_js_1.last)(file.packageJsonLocations), fileNameConvertor)));
                }
                break;
            case ts_js_1.ModuleKind.CommonJS:
                if (file.packageJsonScope) {
                    (result ?? (result = [])).push((0, ts_js_1.chainDiagnosticMessages)(
                    /*details*/ undefined, file.packageJsonScope.contents.packageJsonContent.type ?
                        ts_js_1.Diagnostics.File_is_CommonJS_module_because_0_has_field_type_whose_value_is_not_module :
                        ts_js_1.Diagnostics.File_is_CommonJS_module_because_0_does_not_have_field_type, toFileName((0, ts_js_1.last)(file.packageJsonLocations), fileNameConvertor)));
                }
                else if (file.packageJsonLocations?.length) {
                    (result ?? (result = [])).push((0, ts_js_1.chainDiagnosticMessages)(
                    /*details*/ undefined, ts_js_1.Diagnostics.File_is_CommonJS_module_because_package_json_was_not_found));
                }
                break;
        }
    }
    return result;
}
/** @internal */
function getMatchedFileSpec(program, fileName) {
    const configFile = program.getCompilerOptions().configFile;
    if (!configFile?.configFileSpecs?.validatedFilesSpec)
        return undefined;
    const filePath = program.getCanonicalFileName(fileName);
    const basePath = (0, ts_js_1.getDirectoryPath)((0, ts_js_1.getNormalizedAbsolutePath)(configFile.fileName, program.getCurrentDirectory()));
    const index = (0, ts_js_1.findIndex)(configFile.configFileSpecs.validatedFilesSpec, fileSpec => program.getCanonicalFileName((0, ts_js_1.getNormalizedAbsolutePath)(fileSpec, basePath)) === filePath);
    return index !== -1 ? configFile.configFileSpecs.validatedFilesSpecBeforeSubstitution[index] : undefined;
}
/** @internal */
function getMatchedIncludeSpec(program, fileName) {
    const configFile = program.getCompilerOptions().configFile;
    if (!configFile?.configFileSpecs?.validatedIncludeSpecs)
        return undefined;
    // Return true if its default include spec
    if (configFile.configFileSpecs.isDefaultIncludeSpec)
        return true;
    const isJsonFile = (0, ts_js_1.fileExtensionIs)(fileName, ".json" /* Extension.Json */);
    const basePath = (0, ts_js_1.getDirectoryPath)((0, ts_js_1.getNormalizedAbsolutePath)(configFile.fileName, program.getCurrentDirectory()));
    const useCaseSensitiveFileNames = program.useCaseSensitiveFileNames();
    const index = (0, ts_js_1.findIndex)(configFile?.configFileSpecs?.validatedIncludeSpecs, includeSpec => {
        if (isJsonFile && !(0, ts_js_1.endsWith)(includeSpec, ".json" /* Extension.Json */))
            return false;
        const pattern = (0, ts_js_1.getPatternFromSpec)(includeSpec, basePath, "files");
        return !!pattern && (0, ts_js_1.getRegexFromPattern)(`(?:${pattern})$`, useCaseSensitiveFileNames).test(fileName);
    });
    return index !== -1 ? configFile.configFileSpecs.validatedIncludeSpecsBeforeSubstitution[index] : undefined;
}
/** @internal */
function fileIncludeReasonToDiagnostics(program, reason, fileNameConvertor) {
    const options = program.getCompilerOptions();
    if ((0, ts_js_1.isReferencedFile)(reason)) {
        const referenceLocation = (0, ts_js_1.getReferencedFileLocation)(program, reason);
        const referenceText = (0, ts_js_1.isReferenceFileLocation)(referenceLocation) ? referenceLocation.file.text.substring(referenceLocation.pos, referenceLocation.end) : `"${referenceLocation.text}"`;
        let message;
        ts_js_1.Debug.assert((0, ts_js_1.isReferenceFileLocation)(referenceLocation) || reason.kind === ts_js_1.FileIncludeKind.Import, "Only synthetic references are imports");
        switch (reason.kind) {
            case ts_js_1.FileIncludeKind.Import:
                if ((0, ts_js_1.isReferenceFileLocation)(referenceLocation)) {
                    message = referenceLocation.packageId ?
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1_with_packageId_2 :
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1;
                }
                else if (referenceLocation.text === ts_js_1.externalHelpersModuleNameText) {
                    message = referenceLocation.packageId ?
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1_with_packageId_2_to_import_importHelpers_as_specified_in_compilerOptions :
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1_to_import_importHelpers_as_specified_in_compilerOptions;
                }
                else {
                    message = referenceLocation.packageId ?
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1_with_packageId_2_to_import_jsx_and_jsxs_factory_functions :
                        ts_js_1.Diagnostics.Imported_via_0_from_file_1_to_import_jsx_and_jsxs_factory_functions;
                }
                break;
            case ts_js_1.FileIncludeKind.ReferenceFile:
                ts_js_1.Debug.assert(!referenceLocation.packageId);
                message = ts_js_1.Diagnostics.Referenced_via_0_from_file_1;
                break;
            case ts_js_1.FileIncludeKind.TypeReferenceDirective:
                message = referenceLocation.packageId ?
                    ts_js_1.Diagnostics.Type_library_referenced_via_0_from_file_1_with_packageId_2 :
                    ts_js_1.Diagnostics.Type_library_referenced_via_0_from_file_1;
                break;
            case ts_js_1.FileIncludeKind.LibReferenceDirective:
                ts_js_1.Debug.assert(!referenceLocation.packageId);
                message = ts_js_1.Diagnostics.Library_referenced_via_0_from_file_1;
                break;
            default:
                ts_js_1.Debug.assertNever(reason);
        }
        return (0, ts_js_1.chainDiagnosticMessages)(
        /*details*/ undefined, message, referenceText, toFileName(referenceLocation.file, fileNameConvertor), (referenceLocation.packageId && (0, ts_js_1.packageIdToString)(referenceLocation.packageId)));
    }
    switch (reason.kind) {
        case ts_js_1.FileIncludeKind.RootFile:
            if (!options.configFile?.configFileSpecs)
                return (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Root_file_specified_for_compilation);
            const fileName = (0, ts_js_1.getNormalizedAbsolutePath)(program.getRootFileNames()[reason.index], program.getCurrentDirectory());
            const matchedByFiles = getMatchedFileSpec(program, fileName);
            if (matchedByFiles)
                return (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Part_of_files_list_in_tsconfig_json);
            const matchedByInclude = getMatchedIncludeSpec(program, fileName);
            return (0, ts_js_1.isString)(matchedByInclude) ?
                (0, ts_js_1.chainDiagnosticMessages)(
                /*details*/ undefined, ts_js_1.Diagnostics.Matched_by_include_pattern_0_in_1, matchedByInclude, toFileName(options.configFile, fileNameConvertor)) :
                // Could be additional files specified as roots or matched by default include
                (0, ts_js_1.chainDiagnosticMessages)(
                /*details*/ undefined, matchedByInclude ?
                    ts_js_1.Diagnostics.Matched_by_default_include_pattern_Asterisk_Asterisk_Slash_Asterisk :
                    ts_js_1.Diagnostics.Root_file_specified_for_compilation);
        case ts_js_1.FileIncludeKind.SourceFromProjectReference:
        case ts_js_1.FileIncludeKind.OutputFromProjectReference:
            const isOutput = reason.kind === ts_js_1.FileIncludeKind.OutputFromProjectReference;
            const referencedResolvedRef = ts_js_1.Debug.checkDefined(program.getResolvedProjectReferences()?.[reason.index]);
            return (0, ts_js_1.chainDiagnosticMessages)(
            /*details*/ undefined, options.outFile ?
                isOutput ?
                    ts_js_1.Diagnostics.Output_from_referenced_project_0_included_because_1_specified :
                    ts_js_1.Diagnostics.Source_from_referenced_project_0_included_because_1_specified :
                isOutput ?
                    ts_js_1.Diagnostics.Output_from_referenced_project_0_included_because_module_is_specified_as_none :
                    ts_js_1.Diagnostics.Source_from_referenced_project_0_included_because_module_is_specified_as_none, toFileName(referencedResolvedRef.sourceFile.fileName, fileNameConvertor), options.outFile ? "--outFile" : "--out");
        case ts_js_1.FileIncludeKind.AutomaticTypeDirectiveFile: {
            const messageAndArgs = !(0, ts_js_1.usesWildcardTypes)(options) ?
                reason.packageId ?
                    [ts_js_1.Diagnostics.Entry_point_of_type_library_0_specified_in_compilerOptions_with_packageId_1, reason.typeReference, (0, ts_js_1.packageIdToString)(reason.packageId)] :
                    [ts_js_1.Diagnostics.Entry_point_of_type_library_0_specified_in_compilerOptions, reason.typeReference] :
                reason.packageId ?
                    [ts_js_1.Diagnostics.Entry_point_for_implicit_type_library_0_with_packageId_1, reason.typeReference, (0, ts_js_1.packageIdToString)(reason.packageId)] :
                    [ts_js_1.Diagnostics.Entry_point_for_implicit_type_library_0, reason.typeReference];
            return (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ...messageAndArgs);
        }
        case ts_js_1.FileIncludeKind.LibFile: {
            if (reason.index !== undefined)
                return (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Library_0_specified_in_compilerOptions, options.lib[reason.index]);
            const target = (0, ts_js_1.getNameOfScriptTarget)((0, ts_js_1.getEmitScriptTarget)(options));
            const messageAndArgs = target ? [ts_js_1.Diagnostics.Default_library_for_target_0, target] : [ts_js_1.Diagnostics.Default_library];
            return (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ...messageAndArgs);
        }
        default:
            ts_js_1.Debug.assertNever(reason);
    }
}
function toFileName(file, fileNameConvertor) {
    const fileName = (0, ts_js_1.isString)(file) ? file : file.fileName;
    return fileNameConvertor ? fileNameConvertor(fileName) : fileName;
}
/**
 * Helper that emit files, report diagnostics and lists emitted and/or source files depending on compiler options
 *
 * @internal
 */
function emitFilesAndReportErrors(program, reportDiagnostic, write, reportSummary, writeFile, cancellationToken, emitOnlyDtsFiles, customTransformers) {
    const options = program.getCompilerOptions();
    // First get and report any syntactic errors.
    const allDiagnostics = program.getConfigFileParsingDiagnostics().slice();
    const configFileParsingDiagnosticsLength = allDiagnostics.length;
    (0, ts_js_1.addRange)(allDiagnostics, program.getSyntacticDiagnostics(/*sourceFile*/ undefined, cancellationToken));
    // If we didn't have any syntactic errors, then also try getting the global and
    // semantic errors.
    if (allDiagnostics.length === configFileParsingDiagnosticsLength) {
        (0, ts_js_1.addRange)(allDiagnostics, program.getOptionsDiagnostics(cancellationToken));
        if (!options.listFilesOnly) {
            (0, ts_js_1.addRange)(allDiagnostics, program.getGlobalDiagnostics(cancellationToken));
            if (allDiagnostics.length === configFileParsingDiagnosticsLength) {
                (0, ts_js_1.addRange)(allDiagnostics, program.getSemanticDiagnostics(/*sourceFile*/ undefined, cancellationToken));
            }
            if (options.noEmit &&
                (0, ts_js_1.getEmitDeclarations)(options) &&
                allDiagnostics.length === configFileParsingDiagnosticsLength) {
                (0, ts_js_1.addRange)(allDiagnostics, program.getDeclarationDiagnostics(/*sourceFile*/ undefined, cancellationToken));
            }
        }
    }
    // Emit and report any errors we ran into.
    const emitResult = options.listFilesOnly
        ? { emitSkipped: true, diagnostics: ts_js_1.emptyArray }
        : program.emit(/*targetSourceFile*/ undefined, writeFile, cancellationToken, emitOnlyDtsFiles, customTransformers);
    (0, ts_js_1.addRange)(allDiagnostics, emitResult.diagnostics);
    const diagnostics = (0, ts_js_1.sortAndDeduplicateDiagnostics)(allDiagnostics);
    diagnostics.forEach(reportDiagnostic);
    if (write) {
        const currentDir = program.getCurrentDirectory();
        (0, ts_js_1.forEach)(emitResult.emittedFiles, file => {
            const filepath = (0, ts_js_1.getNormalizedAbsolutePath)(file, currentDir);
            write(`TSFILE: ${filepath}`);
        });
        listFiles(program, write);
    }
    if (reportSummary) {
        reportSummary(getErrorCountForSummary(diagnostics), getFilesInErrorForSummary(diagnostics));
    }
    return {
        emitResult,
        diagnostics,
    };
}
/** @internal */
function emitFilesAndReportErrorsAndGetExitStatus(program, reportDiagnostic, write, reportSummary, writeFile, cancellationToken, emitOnlyDtsFiles, customTransformers) {
    const { emitResult, diagnostics } = emitFilesAndReportErrors(program, reportDiagnostic, write, reportSummary, writeFile, cancellationToken, emitOnlyDtsFiles, customTransformers);
    if (emitResult.emitSkipped && diagnostics.length > 0) {
        // If the emitter didn't emit anything, then pass that value along.
        return ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped;
    }
    else if (diagnostics.length > 0) {
        // The emitter emitted something, inform the caller if that happened in the presence
        // of diagnostics or not.
        return ts_js_1.ExitStatus.DiagnosticsPresent_OutputsGenerated;
    }
    return ts_js_1.ExitStatus.Success;
}
/** @internal */
exports.noopFileWatcher = { close: ts_js_1.noop };
/** @internal */
const returnNoopFileWatcher = () => exports.noopFileWatcher;
exports.returnNoopFileWatcher = returnNoopFileWatcher;
/** @internal */
function createWatchHost(system = ts_js_1.sys, reportWatchStatus) {
    const onWatchStatusChange = reportWatchStatus || createWatchStatusReporter(system);
    return {
        onWatchStatusChange,
        watchFile: system.watchFile?.bind(system) || exports.returnNoopFileWatcher,
        watchDirectory: system.watchDirectory?.bind(system) || exports.returnNoopFileWatcher,
        setTimeout: system.setTimeout?.bind(system) || ts_js_1.noop,
        clearTimeout: system.clearTimeout?.bind(system) || ts_js_1.noop,
        preferNonRecursiveWatch: system.preferNonRecursiveWatch,
    };
}
/** @internal */
exports.WatchType = {
    ConfigFile: "Config file",
    ExtendedConfigFile: "Extended config file",
    SourceFile: "Source file",
    MissingFile: "Missing file",
    WildcardDirectory: "Wild card directory",
    FailedLookupLocations: "Failed Lookup Locations",
    AffectingFileLocation: "File location affecting resolution",
    TypeRoots: "Type roots",
    ConfigFileOfReferencedProject: "Config file of referened project",
    ExtendedConfigOfReferencedProject: "Extended config file of referenced project",
    WildcardDirectoryOfReferencedProject: "Wild card directory of referenced project",
    PackageJson: "package.json file",
    ClosedScriptInfo: "Closed Script info",
    ConfigFileForInferredRoot: "Config file for the inferred project root",
    NodeModules: "node_modules for closed script infos and package.jsons affecting module specifier cache",
    MissingSourceMapFile: "Missing source map file",
    NoopConfigFileForInferredRoot: "Noop Config file for the inferred project root",
    MissingGeneratedFile: "Missing generated file",
    NodeModulesForModuleSpecifierCache: "node_modules for module specifier cache invalidation",
    TypingInstallerLocationFile: "File location for typing installer",
    TypingInstallerLocationDirectory: "Directory location for typing installer",
};
/** @internal */
function createWatchFactory(host, options) {
    const watchLogLevel = host.trace ? options.extendedDiagnostics ? ts_js_1.WatchLogLevel.Verbose : options.diagnostics ? ts_js_1.WatchLogLevel.TriggerOnly : ts_js_1.WatchLogLevel.None : ts_js_1.WatchLogLevel.None;
    const writeLog = watchLogLevel !== ts_js_1.WatchLogLevel.None ? (s => host.trace(s)) : ts_js_1.noop;
    const result = (0, ts_js_1.getWatchFactory)(host, watchLogLevel, writeLog);
    result.writeLog = writeLog;
    return result;
}
/** @internal */
function createCompilerHostFromProgramHost(host, getCompilerOptions, directoryStructureHost = host) {
    const useCaseSensitiveFileNames = host.useCaseSensitiveFileNames();
    const compilerHost = {
        getSourceFile: (0, ts_js_1.createGetSourceFile)((fileName, encoding) => !encoding ? compilerHost.readFile(fileName) : host.readFile(fileName, encoding), 
        /*setParentNodes*/ undefined),
        getDefaultLibLocation: host.getDefaultLibLocation?.bind(host),
        getDefaultLibFileName: options => host.getDefaultLibFileName(options),
        writeFile: (0, ts_js_1.createWriteFileMeasuringIO)((path, data, writeByteOrderMark) => host.writeFile(path, data, writeByteOrderMark), path => host.createDirectory(path), path => host.directoryExists(path)),
        getCurrentDirectory: (0, ts_js_1.memoize)(() => host.getCurrentDirectory()),
        useCaseSensitiveFileNames: () => useCaseSensitiveFileNames,
        getCanonicalFileName: (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames),
        getNewLine: () => (0, ts_js_1.getNewLineCharacter)(getCompilerOptions()),
        fileExists: f => host.fileExists(f),
        readFile: f => host.readFile(f),
        trace: host.trace?.bind(host),
        directoryExists: directoryStructureHost.directoryExists?.bind(directoryStructureHost),
        getDirectories: directoryStructureHost.getDirectories?.bind(directoryStructureHost),
        realpath: host.realpath?.bind(host),
        getEnvironmentVariable: host.getEnvironmentVariable?.bind(host) || (() => ""),
        createHash: host.createHash?.bind(host),
        readDirectory: host.readDirectory?.bind(host),
        storeSignatureInfo: host.storeSignatureInfo,
        jsDocParsingMode: host.jsDocParsingMode,
    };
    return compilerHost;
}
/** @internal */
function getSourceFileVersionAsHashFromText(host, text) {
    // If text can contain the sourceMapUrl ignore sourceMapUrl for calcualting hash
    if (text.match(ts_js_1.sourceMapCommentRegExpDontCareLineStart)) {
        let lineEnd = text.length;
        let lineStart = lineEnd;
        for (let pos = lineEnd - 1; pos >= 0; pos--) {
            const ch = text.charCodeAt(pos);
            switch (ch) {
                case 10 /* CharacterCodes.lineFeed */:
                    if (pos && text.charCodeAt(pos - 1) === 13 /* CharacterCodes.carriageReturn */) {
                        pos--;
                    }
                // falls through
                case 13 /* CharacterCodes.carriageReturn */:
                    break;
                default:
                    if (ch < 127 /* CharacterCodes.maxAsciiCharacter */ || !(0, ts_js_1.isLineBreak)(ch)) {
                        lineStart = pos;
                        continue;
                    }
                    break;
            }
            // This is start of the line
            const line = text.substring(lineStart, lineEnd);
            if (line.match(ts_js_1.sourceMapCommentRegExp)) {
                text = text.substring(0, lineStart);
                break;
            }
            // If we see a non-whitespace/map comment-like line, break, to avoid scanning up the entire file
            else if (!line.match(ts_js_1.whitespaceOrMapCommentRegExp)) {
                break;
            }
            lineEnd = lineStart;
        }
    }
    return (host.createHash || ts_js_1.generateDjb2Hash)(text);
}
/** @internal */
function setGetSourceFileAsHashVersioned(compilerHost) {
    const originalGetSourceFile = compilerHost.getSourceFile;
    compilerHost.getSourceFile = (...args) => {
        const result = originalGetSourceFile.call(compilerHost, ...args);
        if (result) {
            result.version = getSourceFileVersionAsHashFromText(compilerHost, result.text);
        }
        return result;
    };
}
/**
 * Creates the watch compiler host that can be extended with config file or root file names and options host
 *
 * @internal
 */
function createProgramHost(system, createProgram) {
    const getDefaultLibLocation = (0, ts_js_1.memoize)(() => (0, ts_js_1.getDirectoryPath)((0, ts_js_1.normalizePath)(system.getExecutingFilePath())));
    return {
        useCaseSensitiveFileNames: () => system.useCaseSensitiveFileNames,
        getNewLine: () => system.newLine,
        getCurrentDirectory: (0, ts_js_1.memoize)(() => system.getCurrentDirectory()),
        getDefaultLibLocation,
        getDefaultLibFileName: options => (0, ts_js_1.combinePaths)(getDefaultLibLocation(), (0, ts_js_1.getDefaultLibFileName)(options)),
        fileExists: path => system.fileExists(path),
        readFile: (path, encoding) => system.readFile(path, encoding),
        directoryExists: path => system.directoryExists(path),
        getDirectories: path => system.getDirectories(path),
        readDirectory: (path, extensions, exclude, include, depth) => system.readDirectory(path, extensions, exclude, include, depth),
        realpath: system.realpath?.bind(system),
        getEnvironmentVariable: system.getEnvironmentVariable?.bind(system),
        trace: s => system.write(s + system.newLine),
        createDirectory: path => system.createDirectory(path),
        writeFile: (path, data, writeByteOrderMark) => system.writeFile(path, data, writeByteOrderMark),
        createHash: system.createHash?.bind(system),
        createProgram: createProgram || ts_js_1.createEmitAndSemanticDiagnosticsBuilderProgram,
        storeSignatureInfo: system.storeSignatureInfo,
        now: system.now?.bind(system),
    };
}
/**
 * Creates the watch compiler host that can be extended with config file or root file names and options host
 */
function createWatchCompilerHost(system = ts_js_1.sys, createProgram, reportDiagnostic, reportWatchStatus) {
    const write = (s) => system.write(s + system.newLine);
    const result = createProgramHost(system, createProgram);
    (0, ts_js_1.copyProperties)(result, createWatchHost(system, reportWatchStatus));
    result.afterProgramCreate = builderProgram => {
        const compilerOptions = builderProgram.getCompilerOptions();
        const newLine = (0, ts_js_1.getNewLineCharacter)(compilerOptions);
        emitFilesAndReportErrors(builderProgram, reportDiagnostic, write, errorCount => result.onWatchStatusChange((0, ts_js_1.createCompilerDiagnostic)(getWatchErrorSummaryDiagnosticMessage(errorCount), errorCount), newLine, compilerOptions, errorCount));
    };
    return result;
}
/**
 * Report error and exit
 */
function reportUnrecoverableDiagnostic(system, reportDiagnostic, diagnostic) {
    reportDiagnostic(diagnostic);
    system.exit(ts_js_1.ExitStatus.DiagnosticsPresent_OutputsSkipped);
}
/**
 * Creates the watch compiler host from system for config file in watch mode
 *
 * @internal
 */
function createWatchCompilerHostOfConfigFile({ configFileName, optionsToExtend, watchOptionsToExtend, extraFileExtensions, system, createProgram, reportDiagnostic, reportWatchStatus, }) {
    const diagnosticReporter = reportDiagnostic || createDiagnosticReporter(system);
    const host = createWatchCompilerHost(system, createProgram, diagnosticReporter, reportWatchStatus);
    host.onUnRecoverableConfigFileDiagnostic = diagnostic => reportUnrecoverableDiagnostic(system, diagnosticReporter, diagnostic);
    host.configFileName = configFileName;
    host.optionsToExtend = optionsToExtend;
    host.watchOptionsToExtend = watchOptionsToExtend;
    host.extraFileExtensions = extraFileExtensions;
    return host;
}
/**
 * Creates the watch compiler host from system for compiling root files and options in watch mode
 *
 * @internal
 */
function createWatchCompilerHostOfFilesAndCompilerOptions({ rootFiles, options, watchOptions, projectReferences, system, createProgram, reportDiagnostic, reportWatchStatus, }) {
    const host = createWatchCompilerHost(system, createProgram, reportDiagnostic || createDiagnosticReporter(system), reportWatchStatus);
    host.rootFiles = rootFiles;
    host.options = options;
    host.watchOptions = watchOptions;
    host.projectReferences = projectReferences;
    return host;
}
/** @internal */
function performIncrementalCompilation(input) {
    const system = input.system || ts_js_1.sys;
    const host = input.host || (input.host = (0, ts_js_1.createIncrementalCompilerHost)(input.options, system));
    const builderProgram = (0, ts_js_1.createIncrementalProgram)(input);
    const exitStatus = emitFilesAndReportErrorsAndGetExitStatus(builderProgram, input.reportDiagnostic || createDiagnosticReporter(system), s => host.trace && host.trace(s), input.reportErrorSummary || input.options.pretty ? (errorCount, filesInError) => system.write(getErrorSummaryText(errorCount, filesInError, system.newLine, host)) : undefined);
    if (input.afterProgramEmitAndDiagnostics)
        input.afterProgramEmitAndDiagnostics(builderProgram);
    return exitStatus;
}
