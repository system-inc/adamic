"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isNumericLiteral = isNumericLiteral;
exports.isBigIntLiteral = isBigIntLiteral;
exports.isStringLiteral = isStringLiteral;
exports.isJsxText = isJsxText;
exports.isRegularExpressionLiteral = isRegularExpressionLiteral;
exports.isNoSubstitutionTemplateLiteral = isNoSubstitutionTemplateLiteral;
exports.isTemplateHead = isTemplateHead;
exports.isTemplateMiddle = isTemplateMiddle;
exports.isTemplateTail = isTemplateTail;
exports.isDotDotDotToken = isDotDotDotToken;
exports.isCommaToken = isCommaToken;
exports.isPlusToken = isPlusToken;
exports.isMinusToken = isMinusToken;
exports.isAsteriskToken = isAsteriskToken;
exports.isExclamationToken = isExclamationToken;
exports.isQuestionToken = isQuestionToken;
exports.isColonToken = isColonToken;
exports.isQuestionDotToken = isQuestionDotToken;
exports.isEqualsGreaterThanToken = isEqualsGreaterThanToken;
exports.isIdentifier = isIdentifier;
exports.isPrivateIdentifier = isPrivateIdentifier;
exports.isExportModifier = isExportModifier;
exports.isDefaultModifier = isDefaultModifier;
exports.isAsyncModifier = isAsyncModifier;
exports.isAssertsKeyword = isAssertsKeyword;
exports.isAwaitKeyword = isAwaitKeyword;
exports.isReadonlyKeyword = isReadonlyKeyword;
exports.isStaticModifier = isStaticModifier;
exports.isAbstractModifier = isAbstractModifier;
exports.isOverrideModifier = isOverrideModifier;
exports.isAccessorModifier = isAccessorModifier;
exports.isSuperKeyword = isSuperKeyword;
exports.isImportKeyword = isImportKeyword;
exports.isCaseKeyword = isCaseKeyword;
exports.isQualifiedName = isQualifiedName;
exports.isComputedPropertyName = isComputedPropertyName;
exports.isTypeParameterDeclaration = isTypeParameterDeclaration;
exports.isParameter = isParameter;
exports.isDecorator = isDecorator;
exports.isPropertySignature = isPropertySignature;
exports.isPropertyDeclaration = isPropertyDeclaration;
exports.isMethodSignature = isMethodSignature;
exports.isMethodDeclaration = isMethodDeclaration;
exports.isClassStaticBlockDeclaration = isClassStaticBlockDeclaration;
exports.isConstructorDeclaration = isConstructorDeclaration;
exports.isGetAccessorDeclaration = isGetAccessorDeclaration;
exports.isSetAccessorDeclaration = isSetAccessorDeclaration;
exports.isCallSignatureDeclaration = isCallSignatureDeclaration;
exports.isConstructSignatureDeclaration = isConstructSignatureDeclaration;
exports.isIndexSignatureDeclaration = isIndexSignatureDeclaration;
exports.isTypePredicateNode = isTypePredicateNode;
exports.isTypeReferenceNode = isTypeReferenceNode;
exports.isFunctionTypeNode = isFunctionTypeNode;
exports.isConstructorTypeNode = isConstructorTypeNode;
exports.isTypeQueryNode = isTypeQueryNode;
exports.isTypeLiteralNode = isTypeLiteralNode;
exports.isArrayTypeNode = isArrayTypeNode;
exports.isTupleTypeNode = isTupleTypeNode;
exports.isNamedTupleMember = isNamedTupleMember;
exports.isOptionalTypeNode = isOptionalTypeNode;
exports.isRestTypeNode = isRestTypeNode;
exports.isUnionTypeNode = isUnionTypeNode;
exports.isIntersectionTypeNode = isIntersectionTypeNode;
exports.isConditionalTypeNode = isConditionalTypeNode;
exports.isInferTypeNode = isInferTypeNode;
exports.isParenthesizedTypeNode = isParenthesizedTypeNode;
exports.isThisTypeNode = isThisTypeNode;
exports.isTypeOperatorNode = isTypeOperatorNode;
exports.isIndexedAccessTypeNode = isIndexedAccessTypeNode;
exports.isMappedTypeNode = isMappedTypeNode;
exports.isLiteralTypeNode = isLiteralTypeNode;
exports.isImportTypeNode = isImportTypeNode;
exports.isTemplateLiteralTypeSpan = isTemplateLiteralTypeSpan;
exports.isTemplateLiteralTypeNode = isTemplateLiteralTypeNode;
exports.isObjectBindingPattern = isObjectBindingPattern;
exports.isArrayBindingPattern = isArrayBindingPattern;
exports.isBindingElement = isBindingElement;
exports.isArrayLiteralExpression = isArrayLiteralExpression;
exports.isObjectLiteralExpression = isObjectLiteralExpression;
exports.isPropertyAccessExpression = isPropertyAccessExpression;
exports.isElementAccessExpression = isElementAccessExpression;
exports.isCallExpression = isCallExpression;
exports.isNewExpression = isNewExpression;
exports.isTaggedTemplateExpression = isTaggedTemplateExpression;
exports.isTypeAssertionExpression = isTypeAssertionExpression;
exports.isParenthesizedExpression = isParenthesizedExpression;
exports.isFunctionExpression = isFunctionExpression;
exports.isArrowFunction = isArrowFunction;
exports.isDeleteExpression = isDeleteExpression;
exports.isTypeOfExpression = isTypeOfExpression;
exports.isVoidExpression = isVoidExpression;
exports.isAwaitExpression = isAwaitExpression;
exports.isPrefixUnaryExpression = isPrefixUnaryExpression;
exports.isPostfixUnaryExpression = isPostfixUnaryExpression;
exports.isBinaryExpression = isBinaryExpression;
exports.isConditionalExpression = isConditionalExpression;
exports.isTemplateExpression = isTemplateExpression;
exports.isYieldExpression = isYieldExpression;
exports.isSpreadElement = isSpreadElement;
exports.isClassExpression = isClassExpression;
exports.isOmittedExpression = isOmittedExpression;
exports.isExpressionWithTypeArguments = isExpressionWithTypeArguments;
exports.isAsExpression = isAsExpression;
exports.isSatisfiesExpression = isSatisfiesExpression;
exports.isNonNullExpression = isNonNullExpression;
exports.isMetaProperty = isMetaProperty;
exports.isSyntheticExpression = isSyntheticExpression;
exports.isPartiallyEmittedExpression = isPartiallyEmittedExpression;
exports.isCommaListExpression = isCommaListExpression;
exports.isTemplateSpan = isTemplateSpan;
exports.isSemicolonClassElement = isSemicolonClassElement;
exports.isBlock = isBlock;
exports.isVariableStatement = isVariableStatement;
exports.isEmptyStatement = isEmptyStatement;
exports.isExpressionStatement = isExpressionStatement;
exports.isIfStatement = isIfStatement;
exports.isDoStatement = isDoStatement;
exports.isWhileStatement = isWhileStatement;
exports.isForStatement = isForStatement;
exports.isForInStatement = isForInStatement;
exports.isForOfStatement = isForOfStatement;
exports.isContinueStatement = isContinueStatement;
exports.isBreakStatement = isBreakStatement;
exports.isReturnStatement = isReturnStatement;
exports.isWithStatement = isWithStatement;
exports.isSwitchStatement = isSwitchStatement;
exports.isLabeledStatement = isLabeledStatement;
exports.isThrowStatement = isThrowStatement;
exports.isTryStatement = isTryStatement;
exports.isDebuggerStatement = isDebuggerStatement;
exports.isVariableDeclaration = isVariableDeclaration;
exports.isVariableDeclarationList = isVariableDeclarationList;
exports.isFunctionDeclaration = isFunctionDeclaration;
exports.isClassDeclaration = isClassDeclaration;
exports.isInterfaceDeclaration = isInterfaceDeclaration;
exports.isTypeAliasDeclaration = isTypeAliasDeclaration;
exports.isEnumDeclaration = isEnumDeclaration;
exports.isModuleDeclaration = isModuleDeclaration;
exports.isModuleBlock = isModuleBlock;
exports.isCaseBlock = isCaseBlock;
exports.isNamespaceExportDeclaration = isNamespaceExportDeclaration;
exports.isImportEqualsDeclaration = isImportEqualsDeclaration;
exports.isImportDeclaration = isImportDeclaration;
exports.isImportClause = isImportClause;
exports.isImportTypeAssertionContainer = isImportTypeAssertionContainer;
exports.isAssertClause = isAssertClause;
exports.isAssertEntry = isAssertEntry;
exports.isImportAttributes = isImportAttributes;
exports.isImportAttribute = isImportAttribute;
exports.isNamespaceImport = isNamespaceImport;
exports.isNamespaceExport = isNamespaceExport;
exports.isNamedImports = isNamedImports;
exports.isImportSpecifier = isImportSpecifier;
exports.isExportAssignment = isExportAssignment;
exports.isExportDeclaration = isExportDeclaration;
exports.isNamedExports = isNamedExports;
exports.isExportSpecifier = isExportSpecifier;
exports.isModuleExportName = isModuleExportName;
exports.isMissingDeclaration = isMissingDeclaration;
exports.isNotEmittedStatement = isNotEmittedStatement;
exports.isSyntheticReference = isSyntheticReference;
exports.isExternalModuleReference = isExternalModuleReference;
exports.isJsxElement = isJsxElement;
exports.isJsxSelfClosingElement = isJsxSelfClosingElement;
exports.isJsxOpeningElement = isJsxOpeningElement;
exports.isJsxClosingElement = isJsxClosingElement;
exports.isJsxFragment = isJsxFragment;
exports.isJsxOpeningFragment = isJsxOpeningFragment;
exports.isJsxClosingFragment = isJsxClosingFragment;
exports.isJsxAttribute = isJsxAttribute;
exports.isJsxAttributes = isJsxAttributes;
exports.isJsxSpreadAttribute = isJsxSpreadAttribute;
exports.isJsxExpression = isJsxExpression;
exports.isJsxNamespacedName = isJsxNamespacedName;
exports.isCaseClause = isCaseClause;
exports.isDefaultClause = isDefaultClause;
exports.isHeritageClause = isHeritageClause;
exports.isCatchClause = isCatchClause;
exports.isPropertyAssignment = isPropertyAssignment;
exports.isShorthandPropertyAssignment = isShorthandPropertyAssignment;
exports.isSpreadAssignment = isSpreadAssignment;
exports.isEnumMember = isEnumMember;
exports.isSourceFile = isSourceFile;
exports.isBundle = isBundle;
exports.isJSDocTypeExpression = isJSDocTypeExpression;
exports.isJSDocNameReference = isJSDocNameReference;
exports.isJSDocMemberName = isJSDocMemberName;
exports.isJSDocLink = isJSDocLink;
exports.isJSDocLinkCode = isJSDocLinkCode;
exports.isJSDocLinkPlain = isJSDocLinkPlain;
exports.isJSDocAllType = isJSDocAllType;
exports.isJSDocUnknownType = isJSDocUnknownType;
exports.isJSDocNullableType = isJSDocNullableType;
exports.isJSDocNonNullableType = isJSDocNonNullableType;
exports.isJSDocOptionalType = isJSDocOptionalType;
exports.isJSDocFunctionType = isJSDocFunctionType;
exports.isJSDocVariadicType = isJSDocVariadicType;
exports.isJSDocNamepathType = isJSDocNamepathType;
exports.isJSDoc = isJSDoc;
exports.isJSDocTypeLiteral = isJSDocTypeLiteral;
exports.isJSDocSignature = isJSDocSignature;
exports.isJSDocAugmentsTag = isJSDocAugmentsTag;
exports.isJSDocAuthorTag = isJSDocAuthorTag;
exports.isJSDocClassTag = isJSDocClassTag;
exports.isJSDocCallbackTag = isJSDocCallbackTag;
exports.isJSDocPublicTag = isJSDocPublicTag;
exports.isJSDocPrivateTag = isJSDocPrivateTag;
exports.isJSDocProtectedTag = isJSDocProtectedTag;
exports.isJSDocReadonlyTag = isJSDocReadonlyTag;
exports.isJSDocOverrideTag = isJSDocOverrideTag;
exports.isJSDocOverloadTag = isJSDocOverloadTag;
exports.isJSDocDeprecatedTag = isJSDocDeprecatedTag;
exports.isJSDocSeeTag = isJSDocSeeTag;
exports.isJSDocEnumTag = isJSDocEnumTag;
exports.isJSDocParameterTag = isJSDocParameterTag;
exports.isJSDocReturnTag = isJSDocReturnTag;
exports.isJSDocThisTag = isJSDocThisTag;
exports.isJSDocTypeTag = isJSDocTypeTag;
exports.isJSDocTemplateTag = isJSDocTemplateTag;
exports.isJSDocTypedefTag = isJSDocTypedefTag;
exports.isJSDocUnknownTag = isJSDocUnknownTag;
exports.isJSDocPropertyTag = isJSDocPropertyTag;
exports.isJSDocImplementsTag = isJSDocImplementsTag;
exports.isJSDocSatisfiesTag = isJSDocSatisfiesTag;
exports.isJSDocThrowsTag = isJSDocThrowsTag;
exports.isJSDocImportTag = isJSDocImportTag;
exports.isSyntaxList = isSyntaxList;
// Literals
function isNumericLiteral(node) {
    return node.kind === 9 /* SyntaxKind.NumericLiteral */;
}
function isBigIntLiteral(node) {
    return node.kind === 10 /* SyntaxKind.BigIntLiteral */;
}
function isStringLiteral(node) {
    return node.kind === 11 /* SyntaxKind.StringLiteral */;
}
function isJsxText(node) {
    return node.kind === 12 /* SyntaxKind.JsxText */;
}
function isRegularExpressionLiteral(node) {
    return node.kind === 14 /* SyntaxKind.RegularExpressionLiteral */;
}
function isNoSubstitutionTemplateLiteral(node) {
    return node.kind === 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */;
}
// Pseudo-literals
function isTemplateHead(node) {
    return node.kind === 16 /* SyntaxKind.TemplateHead */;
}
function isTemplateMiddle(node) {
    return node.kind === 17 /* SyntaxKind.TemplateMiddle */;
}
function isTemplateTail(node) {
    return node.kind === 18 /* SyntaxKind.TemplateTail */;
}
// Punctuation
function isDotDotDotToken(node) {
    return node.kind === 26 /* SyntaxKind.DotDotDotToken */;
}
/** @internal */
function isCommaToken(node) {
    return node.kind === 28 /* SyntaxKind.CommaToken */;
}
function isPlusToken(node) {
    return node.kind === 40 /* SyntaxKind.PlusToken */;
}
function isMinusToken(node) {
    return node.kind === 41 /* SyntaxKind.MinusToken */;
}
function isAsteriskToken(node) {
    return node.kind === 42 /* SyntaxKind.AsteriskToken */;
}
function isExclamationToken(node) {
    return node.kind === 54 /* SyntaxKind.ExclamationToken */;
}
function isQuestionToken(node) {
    return node.kind === 58 /* SyntaxKind.QuestionToken */;
}
function isColonToken(node) {
    return node.kind === 59 /* SyntaxKind.ColonToken */;
}
function isQuestionDotToken(node) {
    return node.kind === 29 /* SyntaxKind.QuestionDotToken */;
}
function isEqualsGreaterThanToken(node) {
    return node.kind === 39 /* SyntaxKind.EqualsGreaterThanToken */;
}
// Identifiers
function isIdentifier(node) {
    return node.kind === 80 /* SyntaxKind.Identifier */;
}
function isPrivateIdentifier(node) {
    return node.kind === 81 /* SyntaxKind.PrivateIdentifier */;
}
// Reserved Words
/** @internal */
function isExportModifier(node) {
    return node.kind === 95 /* SyntaxKind.ExportKeyword */;
}
/** @internal */
function isDefaultModifier(node) {
    return node.kind === 90 /* SyntaxKind.DefaultKeyword */;
}
/** @internal */
function isAsyncModifier(node) {
    return node.kind === 134 /* SyntaxKind.AsyncKeyword */;
}
function isAssertsKeyword(node) {
    return node.kind === 131 /* SyntaxKind.AssertsKeyword */;
}
function isAwaitKeyword(node) {
    return node.kind === 135 /* SyntaxKind.AwaitKeyword */;
}
/** @internal */
function isReadonlyKeyword(node) {
    return node.kind === 148 /* SyntaxKind.ReadonlyKeyword */;
}
/** @internal */
function isStaticModifier(node) {
    return node.kind === 126 /* SyntaxKind.StaticKeyword */;
}
/** @internal */
function isAbstractModifier(node) {
    return node.kind === 128 /* SyntaxKind.AbstractKeyword */;
}
/** @internal */
function isOverrideModifier(node) {
    return node.kind === 164 /* SyntaxKind.OverrideKeyword */;
}
/** @internal */
function isAccessorModifier(node) {
    return node.kind === 129 /* SyntaxKind.AccessorKeyword */;
}
/** @internal */
function isSuperKeyword(node) {
    return node.kind === 108 /* SyntaxKind.SuperKeyword */;
}
/** @internal */
function isImportKeyword(node) {
    return node.kind === 102 /* SyntaxKind.ImportKeyword */;
}
/** @internal */
function isCaseKeyword(node) {
    return node.kind === 84 /* SyntaxKind.CaseKeyword */;
}
// Names
function isQualifiedName(node) {
    return node.kind === 167 /* SyntaxKind.QualifiedName */;
}
function isComputedPropertyName(node) {
    return node.kind === 168 /* SyntaxKind.ComputedPropertyName */;
}
// Signature elements
function isTypeParameterDeclaration(node) {
    return node.kind === 169 /* SyntaxKind.TypeParameter */;
}
// TODO(rbuckton): Rename to 'isParameterDeclaration'
function isParameter(node) {
    return node.kind === 170 /* SyntaxKind.Parameter */;
}
function isDecorator(node) {
    return node.kind === 171 /* SyntaxKind.Decorator */;
}
// TypeMember
function isPropertySignature(node) {
    return node.kind === 172 /* SyntaxKind.PropertySignature */;
}
function isPropertyDeclaration(node) {
    return node.kind === 173 /* SyntaxKind.PropertyDeclaration */;
}
function isMethodSignature(node) {
    return node.kind === 174 /* SyntaxKind.MethodSignature */;
}
function isMethodDeclaration(node) {
    return node.kind === 175 /* SyntaxKind.MethodDeclaration */;
}
function isClassStaticBlockDeclaration(node) {
    return node.kind === 176 /* SyntaxKind.ClassStaticBlockDeclaration */;
}
function isConstructorDeclaration(node) {
    return node.kind === 177 /* SyntaxKind.Constructor */;
}
function isGetAccessorDeclaration(node) {
    return node.kind === 178 /* SyntaxKind.GetAccessor */;
}
function isSetAccessorDeclaration(node) {
    return node.kind === 179 /* SyntaxKind.SetAccessor */;
}
function isCallSignatureDeclaration(node) {
    return node.kind === 180 /* SyntaxKind.CallSignature */;
}
function isConstructSignatureDeclaration(node) {
    return node.kind === 181 /* SyntaxKind.ConstructSignature */;
}
function isIndexSignatureDeclaration(node) {
    return node.kind === 182 /* SyntaxKind.IndexSignature */;
}
// Type
function isTypePredicateNode(node) {
    return node.kind === 183 /* SyntaxKind.TypePredicate */;
}
function isTypeReferenceNode(node) {
    return node.kind === 184 /* SyntaxKind.TypeReference */;
}
function isFunctionTypeNode(node) {
    return node.kind === 185 /* SyntaxKind.FunctionType */;
}
function isConstructorTypeNode(node) {
    return node.kind === 186 /* SyntaxKind.ConstructorType */;
}
function isTypeQueryNode(node) {
    return node.kind === 187 /* SyntaxKind.TypeQuery */;
}
function isTypeLiteralNode(node) {
    return node.kind === 188 /* SyntaxKind.TypeLiteral */;
}
function isArrayTypeNode(node) {
    return node.kind === 189 /* SyntaxKind.ArrayType */;
}
function isTupleTypeNode(node) {
    return node.kind === 190 /* SyntaxKind.TupleType */;
}
function isNamedTupleMember(node) {
    return node.kind === 203 /* SyntaxKind.NamedTupleMember */;
}
function isOptionalTypeNode(node) {
    return node.kind === 191 /* SyntaxKind.OptionalType */;
}
function isRestTypeNode(node) {
    return node.kind === 192 /* SyntaxKind.RestType */;
}
function isUnionTypeNode(node) {
    return node.kind === 193 /* SyntaxKind.UnionType */;
}
function isIntersectionTypeNode(node) {
    return node.kind === 194 /* SyntaxKind.IntersectionType */;
}
function isConditionalTypeNode(node) {
    return node.kind === 195 /* SyntaxKind.ConditionalType */;
}
function isInferTypeNode(node) {
    return node.kind === 196 /* SyntaxKind.InferType */;
}
function isParenthesizedTypeNode(node) {
    return node.kind === 197 /* SyntaxKind.ParenthesizedType */;
}
function isThisTypeNode(node) {
    return node.kind === 198 /* SyntaxKind.ThisType */;
}
function isTypeOperatorNode(node) {
    return node.kind === 199 /* SyntaxKind.TypeOperator */;
}
function isIndexedAccessTypeNode(node) {
    return node.kind === 200 /* SyntaxKind.IndexedAccessType */;
}
function isMappedTypeNode(node) {
    return node.kind === 201 /* SyntaxKind.MappedType */;
}
function isLiteralTypeNode(node) {
    return node.kind === 202 /* SyntaxKind.LiteralType */;
}
function isImportTypeNode(node) {
    return node.kind === 206 /* SyntaxKind.ImportType */;
}
function isTemplateLiteralTypeSpan(node) {
    return node.kind === 205 /* SyntaxKind.TemplateLiteralTypeSpan */;
}
function isTemplateLiteralTypeNode(node) {
    return node.kind === 204 /* SyntaxKind.TemplateLiteralType */;
}
// Binding patterns
function isObjectBindingPattern(node) {
    return node.kind === 207 /* SyntaxKind.ObjectBindingPattern */;
}
function isArrayBindingPattern(node) {
    return node.kind === 208 /* SyntaxKind.ArrayBindingPattern */;
}
function isBindingElement(node) {
    return node.kind === 209 /* SyntaxKind.BindingElement */;
}
// Expression
function isArrayLiteralExpression(node) {
    return node.kind === 210 /* SyntaxKind.ArrayLiteralExpression */;
}
function isObjectLiteralExpression(node) {
    return node.kind === 211 /* SyntaxKind.ObjectLiteralExpression */;
}
function isPropertyAccessExpression(node) {
    return node.kind === 212 /* SyntaxKind.PropertyAccessExpression */;
}
function isElementAccessExpression(node) {
    return node.kind === 213 /* SyntaxKind.ElementAccessExpression */;
}
function isCallExpression(node) {
    return node.kind === 214 /* SyntaxKind.CallExpression */;
}
function isNewExpression(node) {
    return node.kind === 215 /* SyntaxKind.NewExpression */;
}
function isTaggedTemplateExpression(node) {
    return node.kind === 216 /* SyntaxKind.TaggedTemplateExpression */;
}
function isTypeAssertionExpression(node) {
    return node.kind === 217 /* SyntaxKind.TypeAssertionExpression */;
}
function isParenthesizedExpression(node) {
    return node.kind === 218 /* SyntaxKind.ParenthesizedExpression */;
}
function isFunctionExpression(node) {
    return node.kind === 219 /* SyntaxKind.FunctionExpression */;
}
function isArrowFunction(node) {
    return node.kind === 220 /* SyntaxKind.ArrowFunction */;
}
function isDeleteExpression(node) {
    return node.kind === 221 /* SyntaxKind.DeleteExpression */;
}
function isTypeOfExpression(node) {
    return node.kind === 222 /* SyntaxKind.TypeOfExpression */;
}
function isVoidExpression(node) {
    return node.kind === 223 /* SyntaxKind.VoidExpression */;
}
function isAwaitExpression(node) {
    return node.kind === 224 /* SyntaxKind.AwaitExpression */;
}
function isPrefixUnaryExpression(node) {
    return node.kind === 225 /* SyntaxKind.PrefixUnaryExpression */;
}
function isPostfixUnaryExpression(node) {
    return node.kind === 226 /* SyntaxKind.PostfixUnaryExpression */;
}
function isBinaryExpression(node) {
    return node.kind === 227 /* SyntaxKind.BinaryExpression */;
}
function isConditionalExpression(node) {
    return node.kind === 228 /* SyntaxKind.ConditionalExpression */;
}
function isTemplateExpression(node) {
    return node.kind === 229 /* SyntaxKind.TemplateExpression */;
}
function isYieldExpression(node) {
    return node.kind === 230 /* SyntaxKind.YieldExpression */;
}
function isSpreadElement(node) {
    return node.kind === 231 /* SyntaxKind.SpreadElement */;
}
function isClassExpression(node) {
    return node.kind === 232 /* SyntaxKind.ClassExpression */;
}
function isOmittedExpression(node) {
    return node.kind === 233 /* SyntaxKind.OmittedExpression */;
}
function isExpressionWithTypeArguments(node) {
    return node.kind === 234 /* SyntaxKind.ExpressionWithTypeArguments */;
}
function isAsExpression(node) {
    return node.kind === 235 /* SyntaxKind.AsExpression */;
}
function isSatisfiesExpression(node) {
    return node.kind === 239 /* SyntaxKind.SatisfiesExpression */;
}
function isNonNullExpression(node) {
    return node.kind === 236 /* SyntaxKind.NonNullExpression */;
}
function isMetaProperty(node) {
    return node.kind === 237 /* SyntaxKind.MetaProperty */;
}
function isSyntheticExpression(node) {
    return node.kind === 238 /* SyntaxKind.SyntheticExpression */;
}
function isPartiallyEmittedExpression(node) {
    return node.kind === 356 /* SyntaxKind.PartiallyEmittedExpression */;
}
function isCommaListExpression(node) {
    return node.kind === 357 /* SyntaxKind.CommaListExpression */;
}
// Misc
function isTemplateSpan(node) {
    return node.kind === 240 /* SyntaxKind.TemplateSpan */;
}
function isSemicolonClassElement(node) {
    return node.kind === 241 /* SyntaxKind.SemicolonClassElement */;
}
// Elements
function isBlock(node) {
    return node.kind === 242 /* SyntaxKind.Block */;
}
function isVariableStatement(node) {
    return node.kind === 244 /* SyntaxKind.VariableStatement */;
}
function isEmptyStatement(node) {
    return node.kind === 243 /* SyntaxKind.EmptyStatement */;
}
function isExpressionStatement(node) {
    return node.kind === 245 /* SyntaxKind.ExpressionStatement */;
}
function isIfStatement(node) {
    return node.kind === 246 /* SyntaxKind.IfStatement */;
}
function isDoStatement(node) {
    return node.kind === 247 /* SyntaxKind.DoStatement */;
}
function isWhileStatement(node) {
    return node.kind === 248 /* SyntaxKind.WhileStatement */;
}
function isForStatement(node) {
    return node.kind === 249 /* SyntaxKind.ForStatement */;
}
function isForInStatement(node) {
    return node.kind === 250 /* SyntaxKind.ForInStatement */;
}
function isForOfStatement(node) {
    return node.kind === 251 /* SyntaxKind.ForOfStatement */;
}
function isContinueStatement(node) {
    return node.kind === 252 /* SyntaxKind.ContinueStatement */;
}
function isBreakStatement(node) {
    return node.kind === 253 /* SyntaxKind.BreakStatement */;
}
function isReturnStatement(node) {
    return node.kind === 254 /* SyntaxKind.ReturnStatement */;
}
function isWithStatement(node) {
    return node.kind === 255 /* SyntaxKind.WithStatement */;
}
function isSwitchStatement(node) {
    return node.kind === 256 /* SyntaxKind.SwitchStatement */;
}
function isLabeledStatement(node) {
    return node.kind === 257 /* SyntaxKind.LabeledStatement */;
}
function isThrowStatement(node) {
    return node.kind === 258 /* SyntaxKind.ThrowStatement */;
}
function isTryStatement(node) {
    return node.kind === 259 /* SyntaxKind.TryStatement */;
}
function isDebuggerStatement(node) {
    return node.kind === 260 /* SyntaxKind.DebuggerStatement */;
}
function isVariableDeclaration(node) {
    return node.kind === 261 /* SyntaxKind.VariableDeclaration */;
}
function isVariableDeclarationList(node) {
    return node.kind === 262 /* SyntaxKind.VariableDeclarationList */;
}
function isFunctionDeclaration(node) {
    return node.kind === 263 /* SyntaxKind.FunctionDeclaration */;
}
function isClassDeclaration(node) {
    return node.kind === 264 /* SyntaxKind.ClassDeclaration */;
}
function isInterfaceDeclaration(node) {
    return node.kind === 265 /* SyntaxKind.InterfaceDeclaration */;
}
function isTypeAliasDeclaration(node) {
    return node.kind === 266 /* SyntaxKind.TypeAliasDeclaration */;
}
function isEnumDeclaration(node) {
    return node.kind === 267 /* SyntaxKind.EnumDeclaration */;
}
function isModuleDeclaration(node) {
    return node.kind === 268 /* SyntaxKind.ModuleDeclaration */;
}
function isModuleBlock(node) {
    return node.kind === 269 /* SyntaxKind.ModuleBlock */;
}
function isCaseBlock(node) {
    return node.kind === 270 /* SyntaxKind.CaseBlock */;
}
function isNamespaceExportDeclaration(node) {
    return node.kind === 271 /* SyntaxKind.NamespaceExportDeclaration */;
}
function isImportEqualsDeclaration(node) {
    return node.kind === 272 /* SyntaxKind.ImportEqualsDeclaration */;
}
function isImportDeclaration(node) {
    return node.kind === 273 /* SyntaxKind.ImportDeclaration */;
}
function isImportClause(node) {
    return node.kind === 274 /* SyntaxKind.ImportClause */;
}
function isImportTypeAssertionContainer(node) {
    return node.kind === 303 /* SyntaxKind.ImportTypeAssertionContainer */;
}
/** @deprecated */
function isAssertClause(node) {
    return node.kind === 301 /* SyntaxKind.AssertClause */;
}
/** @deprecated */
function isAssertEntry(node) {
    return node.kind === 302 /* SyntaxKind.AssertEntry */;
}
function isImportAttributes(node) {
    return node.kind === 301 /* SyntaxKind.ImportAttributes */;
}
function isImportAttribute(node) {
    return node.kind === 302 /* SyntaxKind.ImportAttribute */;
}
function isNamespaceImport(node) {
    return node.kind === 275 /* SyntaxKind.NamespaceImport */;
}
function isNamespaceExport(node) {
    return node.kind === 281 /* SyntaxKind.NamespaceExport */;
}
function isNamedImports(node) {
    return node.kind === 276 /* SyntaxKind.NamedImports */;
}
function isImportSpecifier(node) {
    return node.kind === 277 /* SyntaxKind.ImportSpecifier */;
}
function isExportAssignment(node) {
    return node.kind === 278 /* SyntaxKind.ExportAssignment */;
}
function isExportDeclaration(node) {
    return node.kind === 279 /* SyntaxKind.ExportDeclaration */;
}
function isNamedExports(node) {
    return node.kind === 280 /* SyntaxKind.NamedExports */;
}
function isExportSpecifier(node) {
    return node.kind === 282 /* SyntaxKind.ExportSpecifier */;
}
function isModuleExportName(node) {
    return node.kind === 80 /* SyntaxKind.Identifier */ || node.kind === 11 /* SyntaxKind.StringLiteral */;
}
function isMissingDeclaration(node) {
    return node.kind === 283 /* SyntaxKind.MissingDeclaration */;
}
function isNotEmittedStatement(node) {
    return node.kind === 354 /* SyntaxKind.NotEmittedStatement */;
}
/** @internal */
function isSyntheticReference(node) {
    return node.kind === 358 /* SyntaxKind.SyntheticReferenceExpression */;
}
// Module References
function isExternalModuleReference(node) {
    return node.kind === 284 /* SyntaxKind.ExternalModuleReference */;
}
// JSX
function isJsxElement(node) {
    return node.kind === 285 /* SyntaxKind.JsxElement */;
}
function isJsxSelfClosingElement(node) {
    return node.kind === 286 /* SyntaxKind.JsxSelfClosingElement */;
}
function isJsxOpeningElement(node) {
    return node.kind === 287 /* SyntaxKind.JsxOpeningElement */;
}
function isJsxClosingElement(node) {
    return node.kind === 288 /* SyntaxKind.JsxClosingElement */;
}
function isJsxFragment(node) {
    return node.kind === 289 /* SyntaxKind.JsxFragment */;
}
function isJsxOpeningFragment(node) {
    return node.kind === 290 /* SyntaxKind.JsxOpeningFragment */;
}
function isJsxClosingFragment(node) {
    return node.kind === 291 /* SyntaxKind.JsxClosingFragment */;
}
function isJsxAttribute(node) {
    return node.kind === 292 /* SyntaxKind.JsxAttribute */;
}
function isJsxAttributes(node) {
    return node.kind === 293 /* SyntaxKind.JsxAttributes */;
}
function isJsxSpreadAttribute(node) {
    return node.kind === 294 /* SyntaxKind.JsxSpreadAttribute */;
}
function isJsxExpression(node) {
    return node.kind === 295 /* SyntaxKind.JsxExpression */;
}
function isJsxNamespacedName(node) {
    return node.kind === 296 /* SyntaxKind.JsxNamespacedName */;
}
// Clauses
function isCaseClause(node) {
    return node.kind === 297 /* SyntaxKind.CaseClause */;
}
function isDefaultClause(node) {
    return node.kind === 298 /* SyntaxKind.DefaultClause */;
}
function isHeritageClause(node) {
    return node.kind === 299 /* SyntaxKind.HeritageClause */;
}
function isCatchClause(node) {
    return node.kind === 300 /* SyntaxKind.CatchClause */;
}
// Property assignments
function isPropertyAssignment(node) {
    return node.kind === 304 /* SyntaxKind.PropertyAssignment */;
}
function isShorthandPropertyAssignment(node) {
    return node.kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */;
}
function isSpreadAssignment(node) {
    return node.kind === 306 /* SyntaxKind.SpreadAssignment */;
}
// Enum
function isEnumMember(node) {
    return node.kind === 307 /* SyntaxKind.EnumMember */;
}
// Top-level nodes
function isSourceFile(node) {
    return node.kind === 308 /* SyntaxKind.SourceFile */;
}
function isBundle(node) {
    return node.kind === 309 /* SyntaxKind.Bundle */;
}
// TODO(rbuckton): isInputFiles
// JSDoc Elements
function isJSDocTypeExpression(node) {
    return node.kind === 310 /* SyntaxKind.JSDocTypeExpression */;
}
function isJSDocNameReference(node) {
    return node.kind === 311 /* SyntaxKind.JSDocNameReference */;
}
function isJSDocMemberName(node) {
    return node.kind === 312 /* SyntaxKind.JSDocMemberName */;
}
function isJSDocLink(node) {
    return node.kind === 325 /* SyntaxKind.JSDocLink */;
}
function isJSDocLinkCode(node) {
    return node.kind === 326 /* SyntaxKind.JSDocLinkCode */;
}
function isJSDocLinkPlain(node) {
    return node.kind === 327 /* SyntaxKind.JSDocLinkPlain */;
}
function isJSDocAllType(node) {
    return node.kind === 313 /* SyntaxKind.JSDocAllType */;
}
function isJSDocUnknownType(node) {
    return node.kind === 314 /* SyntaxKind.JSDocUnknownType */;
}
function isJSDocNullableType(node) {
    return node.kind === 315 /* SyntaxKind.JSDocNullableType */;
}
function isJSDocNonNullableType(node) {
    return node.kind === 316 /* SyntaxKind.JSDocNonNullableType */;
}
function isJSDocOptionalType(node) {
    return node.kind === 317 /* SyntaxKind.JSDocOptionalType */;
}
function isJSDocFunctionType(node) {
    return node.kind === 318 /* SyntaxKind.JSDocFunctionType */;
}
function isJSDocVariadicType(node) {
    return node.kind === 319 /* SyntaxKind.JSDocVariadicType */;
}
function isJSDocNamepathType(node) {
    return node.kind === 320 /* SyntaxKind.JSDocNamepathType */;
}
function isJSDoc(node) {
    return node.kind === 321 /* SyntaxKind.JSDoc */;
}
function isJSDocTypeLiteral(node) {
    return node.kind === 323 /* SyntaxKind.JSDocTypeLiteral */;
}
function isJSDocSignature(node) {
    return node.kind === 324 /* SyntaxKind.JSDocSignature */;
}
// JSDoc Tags
function isJSDocAugmentsTag(node) {
    return node.kind === 329 /* SyntaxKind.JSDocAugmentsTag */;
}
function isJSDocAuthorTag(node) {
    return node.kind === 331 /* SyntaxKind.JSDocAuthorTag */;
}
function isJSDocClassTag(node) {
    return node.kind === 333 /* SyntaxKind.JSDocClassTag */;
}
function isJSDocCallbackTag(node) {
    return node.kind === 339 /* SyntaxKind.JSDocCallbackTag */;
}
function isJSDocPublicTag(node) {
    return node.kind === 334 /* SyntaxKind.JSDocPublicTag */;
}
function isJSDocPrivateTag(node) {
    return node.kind === 335 /* SyntaxKind.JSDocPrivateTag */;
}
function isJSDocProtectedTag(node) {
    return node.kind === 336 /* SyntaxKind.JSDocProtectedTag */;
}
function isJSDocReadonlyTag(node) {
    return node.kind === 337 /* SyntaxKind.JSDocReadonlyTag */;
}
function isJSDocOverrideTag(node) {
    return node.kind === 338 /* SyntaxKind.JSDocOverrideTag */;
}
function isJSDocOverloadTag(node) {
    return node.kind === 340 /* SyntaxKind.JSDocOverloadTag */;
}
function isJSDocDeprecatedTag(node) {
    return node.kind === 332 /* SyntaxKind.JSDocDeprecatedTag */;
}
function isJSDocSeeTag(node) {
    return node.kind === 348 /* SyntaxKind.JSDocSeeTag */;
}
function isJSDocEnumTag(node) {
    return node.kind === 341 /* SyntaxKind.JSDocEnumTag */;
}
function isJSDocParameterTag(node) {
    return node.kind === 342 /* SyntaxKind.JSDocParameterTag */;
}
function isJSDocReturnTag(node) {
    return node.kind === 343 /* SyntaxKind.JSDocReturnTag */;
}
function isJSDocThisTag(node) {
    return node.kind === 344 /* SyntaxKind.JSDocThisTag */;
}
function isJSDocTypeTag(node) {
    return node.kind === 345 /* SyntaxKind.JSDocTypeTag */;
}
function isJSDocTemplateTag(node) {
    return node.kind === 346 /* SyntaxKind.JSDocTemplateTag */;
}
function isJSDocTypedefTag(node) {
    return node.kind === 347 /* SyntaxKind.JSDocTypedefTag */;
}
function isJSDocUnknownTag(node) {
    return node.kind === 328 /* SyntaxKind.JSDocTag */;
}
function isJSDocPropertyTag(node) {
    return node.kind === 349 /* SyntaxKind.JSDocPropertyTag */;
}
function isJSDocImplementsTag(node) {
    return node.kind === 330 /* SyntaxKind.JSDocImplementsTag */;
}
function isJSDocSatisfiesTag(node) {
    return node.kind === 351 /* SyntaxKind.JSDocSatisfiesTag */;
}
function isJSDocThrowsTag(node) {
    return node.kind === 350 /* SyntaxKind.JSDocThrowsTag */;
}
function isJSDocImportTag(node) {
    return node.kind === 352 /* SyntaxKind.JSDocImportTag */;
}
// Synthesized list
/** @internal */
function isSyntaxList(n) {
    return n.kind === 353 /* SyntaxKind.SyntaxList */;
}
