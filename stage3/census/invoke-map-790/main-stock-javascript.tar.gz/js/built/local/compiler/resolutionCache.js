"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeIgnoredPath = removeIgnoredPath;
exports.canWatchDirectoryOrFile = canWatchDirectoryOrFile;
exports.canWatchDirectoryOrFilePath = canWatchDirectoryOrFilePath;
exports.canWatchAtTypes = canWatchAtTypes;
exports.canWatchAffectingLocation = canWatchAffectingLocation;
exports.getDirectoryToWatchFailedLookupLocation = getDirectoryToWatchFailedLookupLocation;
exports.getDirectoryToWatchFailedLookupLocationFromTypeRoot = getDirectoryToWatchFailedLookupLocationFromTypeRoot;
exports.getRootDirectoryOfResolutionCache = getRootDirectoryOfResolutionCache;
exports.createModuleResolutionLoaderUsingGlobalCache = createModuleResolutionLoaderUsingGlobalCache;
exports.createResolutionCache = createResolutionCache;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
function removeIgnoredPath(path) {
    // Consider whole staging folder as if node_modules changed.
    if ((0, ts_js_1.endsWith)(path, "/node_modules/.staging")) {
        return (0, ts_js_1.removeSuffix)(path, "/.staging");
    }
    return (0, ts_js_1.some)(ts_js_1.ignoredPaths, searchPath => path.includes(searchPath)) ?
        undefined :
        path;
}
function perceivedOsRootLengthForWatching(pathComponents, length) {
    // Ignore "/", "c:/"
    if (length <= 1)
        return 1;
    let indexAfterOsRoot = 1;
    let isDosStyle = pathComponents[0].search(/[a-z]:/i) === 0;
    if (pathComponents[0] !== ts_js_1.directorySeparator &&
        !isDosStyle && // Non dos style paths
        pathComponents[1].search(/[a-z]\$$/i) === 0 // Dos style nextPart
    ) {
        // ignore "//vda1cs4850/c$/folderAtRoot"
        if (length === 2)
            return 2;
        indexAfterOsRoot = 2;
        isDosStyle = true;
    }
    if (isDosStyle &&
        !pathComponents[indexAfterOsRoot].match(/^users$/i)) {
        // Paths like c:/notUsers
        return indexAfterOsRoot;
    }
    if (pathComponents[indexAfterOsRoot].match(/^workspaces$/i)) {
        // Paths like: /workspaces as codespaces hoist the repos in /workspaces so we have to exempt these from "2" level from root rule
        return indexAfterOsRoot + 1;
    }
    // Paths like: c:/users/username or /home/username
    return indexAfterOsRoot + 2;
}
/**
 * Filter out paths like
 * "/", "/user", "/user/username", "/user/username/folderAtRoot",
 * "c:/", "c:/users", "c:/users/username", "c:/users/username/folderAtRoot", "c:/folderAtRoot"
 * @param dirPath
 *
 * @internal
 */
function canWatchDirectoryOrFile(pathComponents, length) {
    if (length === undefined)
        length = pathComponents.length;
    // Ignore "/", "c:/"
    // ignore "/user", "c:/users" or "c:/folderAtRoot"
    if (length <= 2)
        return false;
    const perceivedOsRootLength = perceivedOsRootLengthForWatching(pathComponents, length);
    return length > perceivedOsRootLength + 1;
}
/** @internal */
function canWatchDirectoryOrFilePath(path) {
    return canWatchDirectoryOrFile((0, ts_js_1.getPathComponents)(path));
}
/** @internal */
function canWatchAtTypes(atTypes) {
    // Otherwise can watch directory only if we can watch the parent directory of node_modules/@types
    return canWatchAffectedPackageJsonOrNodeModulesOfAtTypes((0, ts_js_1.getDirectoryPath)(atTypes));
}
function isInDirectoryPath(dirComponents, fileOrDirComponents) {
    if (fileOrDirComponents.length < dirComponents.length)
        return false;
    for (let i = 0; i < dirComponents.length; i++) {
        if (fileOrDirComponents[i] !== dirComponents[i])
            return false;
    }
    return true;
}
function canWatchAffectedPackageJsonOrNodeModulesOfAtTypes(fileOrDirPath) {
    return canWatchDirectoryOrFilePath(fileOrDirPath);
}
/** @internal */
function canWatchAffectingLocation(filePath) {
    return canWatchAffectedPackageJsonOrNodeModulesOfAtTypes(filePath);
}
/** @internal */
function getDirectoryToWatchFailedLookupLocation(failedLookupLocation, failedLookupLocationPath, rootDir, rootPath, rootPathComponents, isRootWatchable, getCurrentDirectory, preferNonRecursiveWatch) {
    const failedLookupPathComponents = (0, ts_js_1.getPathComponents)(failedLookupLocationPath);
    // Ensure failed look up is normalized path
    failedLookupLocation = (0, ts_js_1.isRootedDiskPath)(failedLookupLocation) ? (0, ts_js_1.normalizePath)(failedLookupLocation) : (0, ts_js_1.getNormalizedAbsolutePath)(failedLookupLocation, getCurrentDirectory());
    const failedLookupComponents = (0, ts_js_1.getPathComponents)(failedLookupLocation);
    const perceivedOsRootLength = perceivedOsRootLengthForWatching(failedLookupPathComponents, failedLookupPathComponents.length);
    if (failedLookupPathComponents.length <= perceivedOsRootLength + 1)
        return undefined;
    // If directory path contains node module, get the most parent node_modules directory for watching
    const nodeModulesIndex = failedLookupPathComponents.indexOf("node_modules");
    if (nodeModulesIndex !== -1 && nodeModulesIndex + 1 <= perceivedOsRootLength + 1)
        return undefined; // node_modules not at position where it can be watched
    const lastNodeModulesIndex = failedLookupPathComponents.lastIndexOf("node_modules");
    if (isRootWatchable && isInDirectoryPath(rootPathComponents, failedLookupPathComponents)) {
        if (failedLookupPathComponents.length > rootPathComponents.length + 1) {
            // Instead of watching root, watch directory in root to avoid watching excluded directories not needed for module resolution
            return getDirectoryOfFailedLookupWatch(failedLookupComponents, failedLookupPathComponents, Math.max(rootPathComponents.length + 1, perceivedOsRootLength + 1), lastNodeModulesIndex);
        }
        else {
            // Always watch root directory non recursively
            return {
                dir: rootDir,
                dirPath: rootPath,
                nonRecursive: true,
            };
        }
    }
    return getDirectoryToWatchFromFailedLookupLocationDirectory(failedLookupComponents, failedLookupPathComponents, failedLookupPathComponents.length - 1, perceivedOsRootLength, nodeModulesIndex, rootPathComponents, lastNodeModulesIndex, preferNonRecursiveWatch);
}
function getDirectoryToWatchFromFailedLookupLocationDirectory(dirComponents, dirPathComponents, dirPathComponentsLength, perceivedOsRootLength, nodeModulesIndex, rootPathComponents, lastNodeModulesIndex, preferNonRecursiveWatch) {
    // If directory path contains node module, get the most parent node_modules directory for watching
    if (nodeModulesIndex !== -1) {
        // If the directory is node_modules use it to watch, always watch it recursively
        return getDirectoryOfFailedLookupWatch(dirComponents, dirPathComponents, nodeModulesIndex + 1, lastNodeModulesIndex);
    }
    // Use some ancestor of the root directory
    let nonRecursive = true;
    let length = dirPathComponentsLength;
    if (!preferNonRecursiveWatch) {
        for (let i = 0; i < dirPathComponentsLength; i++) {
            if (dirPathComponents[i] !== rootPathComponents[i]) {
                nonRecursive = false;
                length = Math.max(i + 1, perceivedOsRootLength + 1);
                break;
            }
        }
    }
    return getDirectoryOfFailedLookupWatch(dirComponents, dirPathComponents, length, lastNodeModulesIndex, nonRecursive);
}
function getDirectoryOfFailedLookupWatch(dirComponents, dirPathComponents, length, lastNodeModulesIndex, nonRecursive) {
    let packageDirLength;
    if (lastNodeModulesIndex !== -1 && lastNodeModulesIndex + 1 >= length && lastNodeModulesIndex + 2 < dirPathComponents.length) {
        if (!(0, ts_js_1.startsWith)(dirPathComponents[lastNodeModulesIndex + 1], "@")) {
            packageDirLength = lastNodeModulesIndex + 2;
        }
        else if (lastNodeModulesIndex + 3 < dirPathComponents.length) {
            packageDirLength = lastNodeModulesIndex + 3;
        }
    }
    return {
        dir: (0, ts_js_1.getPathFromPathComponents)(dirComponents, length),
        dirPath: (0, ts_js_1.getPathFromPathComponents)(dirPathComponents, length),
        nonRecursive,
        packageDir: packageDirLength !== undefined ? (0, ts_js_1.getPathFromPathComponents)(dirComponents, packageDirLength) : undefined,
        packageDirPath: packageDirLength !== undefined ? (0, ts_js_1.getPathFromPathComponents)(dirPathComponents, packageDirLength) : undefined,
    };
}
/** @internal */
function getDirectoryToWatchFailedLookupLocationFromTypeRoot(typeRoot, typeRootPath, rootPath, rootPathComponents, isRootWatchable, getCurrentDirectory, preferNonRecursiveWatch, filterCustomPath) {
    const typeRootPathComponents = (0, ts_js_1.getPathComponents)(typeRootPath);
    if (isRootWatchable && isInDirectoryPath(rootPathComponents, typeRootPathComponents)) {
        // Because this is called when we are watching typeRoot, we dont need additional check whether typeRoot is not say c:/users/node_modules/@types when root is c:/
        return rootPath;
    }
    typeRoot = (0, ts_js_1.isRootedDiskPath)(typeRoot) ? (0, ts_js_1.normalizePath)(typeRoot) : (0, ts_js_1.getNormalizedAbsolutePath)(typeRoot, getCurrentDirectory());
    const toWatch = getDirectoryToWatchFromFailedLookupLocationDirectory((0, ts_js_1.getPathComponents)(typeRoot), typeRootPathComponents, typeRootPathComponents.length, perceivedOsRootLengthForWatching(typeRootPathComponents, typeRootPathComponents.length), typeRootPathComponents.indexOf("node_modules"), rootPathComponents, typeRootPathComponents.lastIndexOf("node_modules"), preferNonRecursiveWatch);
    return toWatch && filterCustomPath(toWatch.dirPath) ? toWatch.dirPath : undefined;
}
/** @internal */
function getRootDirectoryOfResolutionCache(rootDirForResolution, getCurrentDirectory) {
    const normalized = (0, ts_js_1.getNormalizedAbsolutePath)(rootDirForResolution, getCurrentDirectory());
    return !(0, ts_js_1.isDiskPathRoot)(normalized) ?
        (0, ts_js_1.removeTrailingDirectorySeparator)(normalized) :
        normalized;
}
function getModuleResolutionHost(resolutionHost) {
    return resolutionHost.getCompilerHost?.() || resolutionHost;
}
/** @internal */
function createModuleResolutionLoaderUsingGlobalCache(containingFile, redirectedReference, options, resolutionHost, moduleResolutionCache) {
    return {
        nameAndMode: ts_js_1.moduleResolutionNameAndModeGetter,
        resolve: (moduleName, resoluionMode) => resolveModuleNameUsingGlobalCache(resolutionHost, moduleResolutionCache, moduleName, containingFile, options, redirectedReference, resoluionMode),
    };
}
function resolveModuleNameUsingGlobalCache(resolutionHost, moduleResolutionCache, moduleName, containingFile, compilerOptions, redirectedReference, mode) {
    const host = getModuleResolutionHost(resolutionHost);
    const primaryResult = (0, ts_js_1.resolveModuleName)(moduleName, containingFile, compilerOptions, host, moduleResolutionCache, redirectedReference, mode);
    // return result immediately only if global cache support is not enabled or if it is .ts, .tsx or .d.ts
    if (!resolutionHost.getGlobalTypingsCacheLocation) {
        return primaryResult;
    }
    // otherwise try to load typings from @types
    const globalCache = resolutionHost.getGlobalTypingsCacheLocation();
    if (globalCache !== undefined && !(0, ts_js_1.isExternalModuleNameRelative)(moduleName) && !(primaryResult.resolvedModule && (0, ts_js_1.extensionIsTS)(primaryResult.resolvedModule.extension))) {
        // create different collection of failed lookup locations for second pass
        // if it will fail and we've already found something during the first pass - we don't want to pollute its results
        const { resolvedModule, failedLookupLocations, affectingLocations, resolutionDiagnostics } = (0, ts_js_1.loadModuleFromGlobalCache)(ts_js_1.Debug.checkDefined(resolutionHost.globalCacheResolutionModuleName)(moduleName), resolutionHost.projectName, compilerOptions, host, globalCache, moduleResolutionCache);
        if (resolvedModule) {
            // Modify existing resolution so its saved in the directory cache as well
            primaryResult.resolvedModule = resolvedModule;
            primaryResult.failedLookupLocations = (0, ts_js_1.updateResolutionField)(primaryResult.failedLookupLocations, failedLookupLocations);
            primaryResult.affectingLocations = (0, ts_js_1.updateResolutionField)(primaryResult.affectingLocations, affectingLocations);
            primaryResult.resolutionDiagnostics = (0, ts_js_1.updateResolutionField)(primaryResult.resolutionDiagnostics, resolutionDiagnostics);
            return primaryResult;
        }
    }
    // Default return the result from the first pass
    return primaryResult;
}
/** @internal */
function createResolutionCache(resolutionHost, rootDirForResolution, logChangesWhenResolvingModule) {
    let filesWithChangedSetOfUnresolvedImports;
    let filesWithInvalidatedResolutions;
    let filesWithInvalidatedNonRelativeUnresolvedImports;
    const nonRelativeExternalModuleResolutions = new Set();
    const resolutionsWithFailedLookups = new Set();
    const resolutionsWithOnlyAffectingLocations = new Set();
    const resolvedFileToResolution = new Map();
    const impliedFormatPackageJsons = new Map();
    let hasChangedAutomaticTypeDirectiveNames = false;
    let affectingPathChecksForFile;
    let affectingPathChecks;
    let failedLookupChecks;
    let startsWithPathChecks;
    let isInDirectoryChecks;
    let allModuleAndTypeResolutionsAreInvalidated = false;
    const getCurrentDirectory = (0, ts_js_1.memoize)(() => resolutionHost.getCurrentDirectory());
    const cachedDirectoryStructureHost = resolutionHost.getCachedDirectoryStructureHost();
    // The resolvedModuleNames and resolvedTypeReferenceDirectives are the cache of resolutions per file.
    // The key in the map is source file's path.
    // The values are Map of resolutions with key being name lookedup.
    const resolvedModuleNames = new Map();
    const moduleResolutionCache = (0, ts_js_1.createModuleResolutionCache)(getCurrentDirectory(), resolutionHost.getCanonicalFileName, resolutionHost.getCompilationSettings());
    const resolvedTypeReferenceDirectives = new Map();
    const typeReferenceDirectiveResolutionCache = (0, ts_js_1.createTypeReferenceDirectiveResolutionCache)(getCurrentDirectory(), resolutionHost.getCanonicalFileName, resolutionHost.getCompilationSettings(), moduleResolutionCache.getPackageJsonInfoCache(), moduleResolutionCache.optionsToRedirectsKey);
    const resolvedLibraries = new Map();
    const libraryResolutionCache = (0, ts_js_1.createModuleResolutionCache)(getCurrentDirectory(), resolutionHost.getCanonicalFileName, (0, ts_js_1.getOptionsForLibraryResolution)(resolutionHost.getCompilationSettings()), moduleResolutionCache.getPackageJsonInfoCache());
    const directoryWatchesOfFailedLookups = new Map();
    const fileWatchesOfAffectingLocations = new Map();
    const rootDir = getRootDirectoryOfResolutionCache(rootDirForResolution, getCurrentDirectory);
    const rootPath = resolutionHost.toPath(rootDir);
    const rootPathComponents = (0, ts_js_1.getPathComponents)(rootPath);
    const isRootWatchable = canWatchDirectoryOrFile(rootPathComponents);
    const isSymlinkCache = new Map();
    const packageDirWatchers = new Map(); // Watching packageDir if symlink otherwise watching dirPath
    const dirPathToSymlinkPackageRefCount = new Map(); // Refcount for dirPath watches when watching symlinked packageDir
    // TypeRoot watches for the types that get added as part of getAutomaticTypeDirectiveNames
    const typeRootsWatches = new Map();
    return {
        rootDirForResolution,
        resolvedModuleNames,
        resolvedTypeReferenceDirectives,
        resolvedLibraries,
        resolvedFileToResolution,
        resolutionsWithFailedLookups,
        resolutionsWithOnlyAffectingLocations,
        directoryWatchesOfFailedLookups,
        fileWatchesOfAffectingLocations,
        packageDirWatchers,
        dirPathToSymlinkPackageRefCount,
        watchFailedLookupLocationsOfExternalModuleResolutions,
        getModuleResolutionCache: () => moduleResolutionCache,
        startRecordingFilesWithChangedResolutions,
        finishRecordingFilesWithChangedResolutions,
        // perDirectoryResolvedModuleNames and perDirectoryResolvedTypeReferenceDirectives could be non empty if there was exception during program update
        // (between startCachingPerDirectoryResolution and finishCachingPerDirectoryResolution)
        startCachingPerDirectoryResolution,
        finishCachingPerDirectoryResolution,
        resolveModuleNameLiterals,
        resolveTypeReferenceDirectiveReferences,
        resolveLibrary,
        resolveSingleModuleNameWithoutWatching,
        removeResolutionsFromProjectReferenceRedirects,
        removeResolutionsOfFile,
        hasChangedAutomaticTypeDirectiveNames: () => hasChangedAutomaticTypeDirectiveNames,
        invalidateResolutionOfFile,
        invalidateResolutionsOfFailedLookupLocations,
        setFilesWithInvalidatedNonRelativeUnresolvedImports,
        createHasInvalidatedResolutions,
        isFileWithInvalidatedNonRelativeUnresolvedImports,
        updateTypeRootsWatch,
        closeTypeRootsWatch,
        clear,
        onChangesAffectModuleResolution,
    };
    function clear() {
        (0, ts_js_1.clearMap)(directoryWatchesOfFailedLookups, ts_js_1.closeFileWatcherOf);
        (0, ts_js_1.clearMap)(fileWatchesOfAffectingLocations, ts_js_1.closeFileWatcherOf);
        isSymlinkCache.clear();
        packageDirWatchers.clear();
        dirPathToSymlinkPackageRefCount.clear();
        nonRelativeExternalModuleResolutions.clear();
        closeTypeRootsWatch();
        resolvedModuleNames.clear();
        resolvedTypeReferenceDirectives.clear();
        resolvedFileToResolution.clear();
        resolutionsWithFailedLookups.clear();
        resolutionsWithOnlyAffectingLocations.clear();
        failedLookupChecks = undefined;
        startsWithPathChecks = undefined;
        isInDirectoryChecks = undefined;
        affectingPathChecks = undefined;
        affectingPathChecksForFile = undefined;
        allModuleAndTypeResolutionsAreInvalidated = false;
        moduleResolutionCache.clear();
        typeReferenceDirectiveResolutionCache.clear();
        moduleResolutionCache.update(resolutionHost.getCompilationSettings());
        typeReferenceDirectiveResolutionCache.update(resolutionHost.getCompilationSettings());
        libraryResolutionCache.clear();
        impliedFormatPackageJsons.clear();
        resolvedLibraries.clear();
        hasChangedAutomaticTypeDirectiveNames = false;
    }
    function onChangesAffectModuleResolution() {
        allModuleAndTypeResolutionsAreInvalidated = true;
        moduleResolutionCache.clearAllExceptPackageJsonInfoCache();
        typeReferenceDirectiveResolutionCache.clearAllExceptPackageJsonInfoCache();
        moduleResolutionCache.update(resolutionHost.getCompilationSettings());
        typeReferenceDirectiveResolutionCache.update(resolutionHost.getCompilationSettings());
    }
    function startRecordingFilesWithChangedResolutions() {
        filesWithChangedSetOfUnresolvedImports = [];
    }
    function finishRecordingFilesWithChangedResolutions() {
        const collected = filesWithChangedSetOfUnresolvedImports;
        filesWithChangedSetOfUnresolvedImports = undefined;
        return collected;
    }
    function isFileWithInvalidatedNonRelativeUnresolvedImports(path) {
        if (!filesWithInvalidatedNonRelativeUnresolvedImports) {
            return false;
        }
        // Invalidated if file has unresolved imports
        const value = filesWithInvalidatedNonRelativeUnresolvedImports.get(path);
        return !!value && !!value.length;
    }
    function createHasInvalidatedResolutions(customHasInvalidatedResolutions, customHasInvalidatedLibResolutions) {
        // Ensure pending resolutions are applied
        invalidateResolutionsOfFailedLookupLocations();
        const collected = filesWithInvalidatedResolutions;
        filesWithInvalidatedResolutions = undefined;
        return {
            hasInvalidatedResolutions: path => customHasInvalidatedResolutions(path) ||
                allModuleAndTypeResolutionsAreInvalidated ||
                !!collected?.has(path) ||
                isFileWithInvalidatedNonRelativeUnresolvedImports(path),
            hasInvalidatedLibResolutions: libFileName => customHasInvalidatedLibResolutions(libFileName) ||
                !!resolvedLibraries?.get(libFileName)?.isInvalidated,
        };
    }
    function startCachingPerDirectoryResolution() {
        moduleResolutionCache.isReadonly = undefined;
        typeReferenceDirectiveResolutionCache.isReadonly = undefined;
        libraryResolutionCache.isReadonly = undefined;
        moduleResolutionCache.getPackageJsonInfoCache().isReadonly = undefined;
        moduleResolutionCache.clearAllExceptPackageJsonInfoCache();
        typeReferenceDirectiveResolutionCache.clearAllExceptPackageJsonInfoCache();
        libraryResolutionCache.clearAllExceptPackageJsonInfoCache();
        // perDirectoryResolvedModuleNames and perDirectoryResolvedTypeReferenceDirectives could be non empty if there was exception during program update
        // (between startCachingPerDirectoryResolution and finishCachingPerDirectoryResolution)
        watchFailedLookupLocationOfNonRelativeModuleResolutions();
        isSymlinkCache.clear();
    }
    function cleanupLibResolutionWatching(newProgram) {
        resolvedLibraries.forEach((resolution, libFileName) => {
            if (!newProgram?.resolvedLibReferences?.has(libFileName)) {
                stopWatchFailedLookupLocationOfResolution(resolution, resolutionHost.toPath((0, ts_js_1.getInferredLibraryNameResolveFrom)(resolutionHost.getCompilationSettings(), getCurrentDirectory(), libFileName)), ts_js_1.getResolvedModuleFromResolution);
                resolvedLibraries.delete(libFileName);
            }
        });
    }
    function finishCachingPerDirectoryResolution(newProgram, oldProgram) {
        filesWithInvalidatedNonRelativeUnresolvedImports = undefined;
        allModuleAndTypeResolutionsAreInvalidated = false;
        watchFailedLookupLocationOfNonRelativeModuleResolutions();
        // Update file watches
        if (newProgram !== oldProgram) {
            cleanupLibResolutionWatching(newProgram);
            newProgram?.getSourceFiles().forEach(newFile => {
                const expected = newFile.packageJsonLocations?.length ?? 0;
                const existing = impliedFormatPackageJsons.get(newFile.resolvedPath) ?? ts_js_1.emptyArray;
                for (let i = existing.length; i < expected; i++) {
                    createFileWatcherOfAffectingLocation(newFile.packageJsonLocations[i], /*forResolution*/ false);
                }
                if (existing.length > expected) {
                    for (let i = expected; i < existing.length; i++) {
                        fileWatchesOfAffectingLocations.get(existing[i]).files--;
                    }
                }
                if (expected)
                    impliedFormatPackageJsons.set(newFile.resolvedPath, newFile.packageJsonLocations);
                else
                    impliedFormatPackageJsons.delete(newFile.resolvedPath);
            });
            impliedFormatPackageJsons.forEach((existing, path) => {
                const newFile = newProgram?.getSourceFileByPath(path);
                if (!newFile || newFile.resolvedPath !== path) {
                    existing.forEach(location => fileWatchesOfAffectingLocations.get(location).files--);
                    impliedFormatPackageJsons.delete(path);
                }
            });
        }
        directoryWatchesOfFailedLookups.forEach(closeDirectoryWatchesOfFailedLookup);
        fileWatchesOfAffectingLocations.forEach(closeFileWatcherOfAffectingLocation);
        packageDirWatchers.forEach(closePackageDirWatcher);
        hasChangedAutomaticTypeDirectiveNames = false;
        moduleResolutionCache.isReadonly = true;
        typeReferenceDirectiveResolutionCache.isReadonly = true;
        libraryResolutionCache.isReadonly = true;
        moduleResolutionCache.getPackageJsonInfoCache().isReadonly = true;
        isSymlinkCache.clear();
    }
    function closePackageDirWatcher(watcher, packageDirPath) {
        if (watcher.dirPathToWatcher.size === 0) {
            packageDirWatchers.delete(packageDirPath);
        }
    }
    function closeDirectoryWatchesOfFailedLookup(watcher, path) {
        if (watcher.refCount === 0) {
            directoryWatchesOfFailedLookups.delete(path);
            watcher.watcher.close();
        }
    }
    function closeFileWatcherOfAffectingLocation(watcher, path) {
        if (watcher.files === 0 && watcher.resolutions === 0 && !watcher.symlinks?.size) {
            fileWatchesOfAffectingLocations.delete(path);
            watcher.watcher.close();
        }
    }
    function resolveNamesWithLocalCache({ entries, containingFile, containingSourceFile, redirectedReference, options, perFileCache, reusedNames, loader, getResolutionWithResolvedFileName, deferWatchingNonRelativeResolution, shouldRetryResolution, logChanges, }) {
        const path = resolutionHost.toPath(containingFile);
        const resolutionsInFile = perFileCache.get(path) || perFileCache.set(path, (0, ts_js_1.createModeAwareCache)()).get(path);
        const resolvedModules = [];
        const hasInvalidatedNonRelativeUnresolvedImport = logChanges && isFileWithInvalidatedNonRelativeUnresolvedImports(path);
        // All the resolutions in this file are invalidated if this file wasn't resolved using same redirect
        const program = resolutionHost.getCurrentProgram();
        const oldRedirect = program && program.getRedirectFromSourceFile(containingFile)?.resolvedRef;
        const unmatchedRedirects = oldRedirect ?
            !redirectedReference || redirectedReference.sourceFile.path !== oldRedirect.sourceFile.path :
            !!redirectedReference;
        const seenNamesInFile = (0, ts_js_1.createModeAwareCache)();
        for (const entry of entries) {
            const name = loader.nameAndMode.getName(entry);
            const mode = loader.nameAndMode.getMode(entry, containingSourceFile, redirectedReference?.commandLine.options || options);
            let resolution = resolutionsInFile.get(name, mode);
            // Resolution is valid if it is present and not invalidated
            if (!seenNamesInFile.has(name, mode) &&
                (allModuleAndTypeResolutionsAreInvalidated || unmatchedRedirects || !resolution || resolution.isInvalidated ||
                    // If the name is unresolved import that was invalidated, recalculate
                    (hasInvalidatedNonRelativeUnresolvedImport && !(0, ts_js_1.isExternalModuleNameRelative)(name) && shouldRetryResolution(resolution)))) {
                const existingResolution = resolution;
                resolution = loader.resolve(name, mode);
                if (resolutionHost.onDiscoveredSymlink && resolutionIsSymlink(resolution)) {
                    resolutionHost.onDiscoveredSymlink();
                }
                resolutionsInFile.set(name, mode, resolution);
                if (resolution !== existingResolution && !resolutionHost.skipWatchingFailedLookups?.(path)) {
                    watchFailedLookupLocationsOfExternalModuleResolutions(name, resolution, path, getResolutionWithResolvedFileName, deferWatchingNonRelativeResolution);
                    if (existingResolution) {
                        stopWatchFailedLookupLocationOfResolution(existingResolution, path, getResolutionWithResolvedFileName);
                    }
                }
                if (logChanges && filesWithChangedSetOfUnresolvedImports && !resolutionIsEqualTo(existingResolution, resolution)) {
                    filesWithChangedSetOfUnresolvedImports.push(path);
                    // reset log changes to avoid recording the same file multiple times
                    logChanges = false;
                }
            }
            else {
                const host = getModuleResolutionHost(resolutionHost);
                if ((0, ts_js_1.isTraceEnabled)(options, host) && !seenNamesInFile.has(name, mode)) {
                    const resolved = getResolutionWithResolvedFileName(resolution);
                    (0, ts_js_1.trace)(host, perFileCache === resolvedModuleNames ?
                        resolved?.resolvedFileName ?
                            resolved.packageId ?
                                ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                                ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2 :
                            ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_not_resolved :
                        resolved?.resolvedFileName ?
                            resolved.packageId ?
                                ts_js_1.Diagnostics.Reusing_resolution_of_type_reference_directive_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                                ts_js_1.Diagnostics.Reusing_resolution_of_type_reference_directive_0_from_1_of_old_program_it_was_successfully_resolved_to_2 :
                            ts_js_1.Diagnostics.Reusing_resolution_of_type_reference_directive_0_from_1_of_old_program_it_was_not_resolved, name, containingFile, resolved?.resolvedFileName, resolved?.packageId && (0, ts_js_1.packageIdToString)(resolved.packageId));
                }
            }
            ts_js_1.Debug.assert(resolution !== undefined && !resolution.isInvalidated);
            seenNamesInFile.set(name, mode, true);
            resolvedModules.push(resolution);
        }
        reusedNames?.forEach(entry => seenNamesInFile.set(loader.nameAndMode.getName(entry), loader.nameAndMode.getMode(entry, containingSourceFile, redirectedReference?.commandLine.options || options), true));
        if (resolutionsInFile.size() !== seenNamesInFile.size()) {
            // Stop watching and remove the unused name
            resolutionsInFile.forEach((resolution, name, mode) => {
                if (!seenNamesInFile.has(name, mode)) {
                    if (!resolutionHost.skipWatchingFailedLookups?.(path)) {
                        stopWatchFailedLookupLocationOfResolution(resolution, path, getResolutionWithResolvedFileName);
                    }
                    resolutionsInFile.delete(name, mode);
                }
            });
        }
        return resolvedModules;
        function resolutionIsEqualTo(oldResolution, newResolution) {
            if (oldResolution === newResolution) {
                return true;
            }
            if (!oldResolution || !newResolution) {
                return false;
            }
            const oldResult = getResolutionWithResolvedFileName(oldResolution);
            const newResult = getResolutionWithResolvedFileName(newResolution);
            if (oldResult === newResult) {
                return true;
            }
            if (!oldResult || !newResult) {
                return false;
            }
            return oldResult.resolvedFileName === newResult.resolvedFileName;
        }
    }
    function resolveTypeReferenceDirectiveReferences(typeDirectiveReferences, containingFile, redirectedReference, options, containingSourceFile, reusedNames) {
        return resolveNamesWithLocalCache({
            entries: typeDirectiveReferences,
            containingFile,
            containingSourceFile,
            redirectedReference,
            options,
            reusedNames,
            perFileCache: resolvedTypeReferenceDirectives,
            loader: (0, ts_js_1.createTypeReferenceResolutionLoader)(containingFile, redirectedReference, options, getModuleResolutionHost(resolutionHost), typeReferenceDirectiveResolutionCache),
            getResolutionWithResolvedFileName: ts_js_1.getResolvedTypeReferenceDirectiveFromResolution,
            shouldRetryResolution: resolution => resolution.resolvedTypeReferenceDirective === undefined,
            deferWatchingNonRelativeResolution: false,
        });
    }
    function resolveModuleNameLiterals(moduleLiterals, containingFile, redirectedReference, options, containingSourceFile, reusedNames) {
        return resolveNamesWithLocalCache({
            entries: moduleLiterals,
            containingFile,
            containingSourceFile,
            redirectedReference,
            options,
            reusedNames,
            perFileCache: resolvedModuleNames,
            loader: createModuleResolutionLoaderUsingGlobalCache(containingFile, redirectedReference, options, resolutionHost, moduleResolutionCache),
            getResolutionWithResolvedFileName: ts_js_1.getResolvedModuleFromResolution,
            shouldRetryResolution: resolution => !resolution.resolvedModule || !(0, ts_js_1.resolutionExtensionIsTSOrJson)(resolution.resolvedModule.extension),
            logChanges: logChangesWhenResolvingModule,
            deferWatchingNonRelativeResolution: true, // Defer non relative resolution watch because we could be using ambient modules
        });
    }
    function resolveLibrary(libraryName, resolveFrom, options, libFileName) {
        const host = getModuleResolutionHost(resolutionHost);
        let resolution = resolvedLibraries?.get(libFileName);
        if (!resolution || resolution.isInvalidated) {
            const existingResolution = resolution;
            resolution = (0, ts_js_1.resolveLibrary)(libraryName, resolveFrom, options, host, libraryResolutionCache);
            const path = resolutionHost.toPath(resolveFrom);
            watchFailedLookupLocationsOfExternalModuleResolutions(libraryName, resolution, path, ts_js_1.getResolvedModuleFromResolution, /*deferWatchingNonRelativeResolution*/ false);
            resolvedLibraries.set(libFileName, resolution);
            if (existingResolution) {
                stopWatchFailedLookupLocationOfResolution(existingResolution, path, ts_js_1.getResolvedModuleFromResolution);
            }
        }
        else {
            if ((0, ts_js_1.isTraceEnabled)(options, host)) {
                const resolved = (0, ts_js_1.getResolvedModuleFromResolution)(resolution);
                (0, ts_js_1.trace)(host, resolved?.resolvedFileName ?
                    resolved.packageId ?
                        ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                        ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2 :
                    ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_not_resolved, libraryName, resolveFrom, resolved?.resolvedFileName, resolved?.packageId && (0, ts_js_1.packageIdToString)(resolved.packageId));
            }
        }
        return resolution;
    }
    function resolveSingleModuleNameWithoutWatching(moduleName, containingFile) {
        const path = resolutionHost.toPath(containingFile);
        const resolutionsInFile = resolvedModuleNames.get(path);
        const resolution = resolutionsInFile?.get(moduleName, /*mode*/ undefined);
        if (resolution && !resolution.isInvalidated)
            return resolution;
        const data = resolutionHost.beforeResolveSingleModuleNameWithoutWatching?.(moduleResolutionCache);
        const host = getModuleResolutionHost(resolutionHost);
        // We are not resolving d.ts so just normal resolution instead of doing resolution pass to global cache
        const result = (0, ts_js_1.resolveModuleName)(moduleName, containingFile, resolutionHost.getCompilationSettings(), host, moduleResolutionCache);
        resolutionHost.afterResolveSingleModuleNameWithoutWatching?.(moduleResolutionCache, moduleName, containingFile, result, data);
        return result;
    }
    function isNodeModulesAtTypesDirectory(dirPath) {
        return (0, ts_js_1.endsWith)(dirPath, "/node_modules/@types");
    }
    function watchFailedLookupLocationsOfExternalModuleResolutions(name, resolution, filePath, getResolutionWithResolvedFileName, deferWatchingNonRelativeResolution) {
        (resolution.files ?? (resolution.files = new Set())).add(filePath);
        if (resolution.files.size !== 1)
            return;
        if (!deferWatchingNonRelativeResolution || (0, ts_js_1.isExternalModuleNameRelative)(name)) {
            watchFailedLookupLocationOfResolution(resolution);
        }
        else {
            nonRelativeExternalModuleResolutions.add(resolution);
        }
        const resolved = getResolutionWithResolvedFileName(resolution);
        if (resolved && resolved.resolvedFileName) {
            const key = resolutionHost.toPath(resolved.resolvedFileName);
            let resolutions = resolvedFileToResolution.get(key);
            if (!resolutions)
                resolvedFileToResolution.set(key, resolutions = new Set());
            resolutions.add(resolution);
        }
    }
    function watchFailedLookupLocation(failedLookupLocation, setAtRoot) {
        const failedLookupLocationPath = resolutionHost.toPath(failedLookupLocation);
        const toWatch = getDirectoryToWatchFailedLookupLocation(failedLookupLocation, failedLookupLocationPath, rootDir, rootPath, rootPathComponents, isRootWatchable, getCurrentDirectory, resolutionHost.preferNonRecursiveWatch);
        if (toWatch) {
            const { dir, dirPath, nonRecursive, packageDir, packageDirPath } = toWatch;
            if (dirPath === rootPath) {
                ts_js_1.Debug.assert(nonRecursive);
                ts_js_1.Debug.assert(!packageDir);
                setAtRoot = true;
            }
            else {
                setDirectoryWatcher(dir, dirPath, packageDir, packageDirPath, nonRecursive);
            }
        }
        return setAtRoot;
    }
    function watchFailedLookupLocationOfResolution(resolution) {
        ts_js_1.Debug.assert(!!resolution.files?.size);
        const { failedLookupLocations, affectingLocations, alternateResult } = resolution;
        if (!failedLookupLocations?.length && !affectingLocations?.length && !alternateResult)
            return;
        if (failedLookupLocations?.length || alternateResult)
            resolutionsWithFailedLookups.add(resolution);
        let setAtRoot = false;
        if (failedLookupLocations) {
            for (const failedLookupLocation of failedLookupLocations) {
                setAtRoot = watchFailedLookupLocation(failedLookupLocation, setAtRoot);
            }
        }
        if (alternateResult)
            setAtRoot = watchFailedLookupLocation(alternateResult, setAtRoot);
        if (setAtRoot) {
            // This is always non recursive
            setDirectoryWatcher(rootDir, rootPath, /*packageDir*/ undefined, /*packageDirPath*/ undefined, /*nonRecursive*/ true);
        }
        watchAffectingLocationsOfResolution(resolution, !failedLookupLocations?.length && !alternateResult);
    }
    function watchAffectingLocationsOfResolution(resolution, addToResolutionsWithOnlyAffectingLocations) {
        ts_js_1.Debug.assert(!!resolution.files?.size);
        const { affectingLocations } = resolution;
        if (!affectingLocations?.length)
            return;
        if (addToResolutionsWithOnlyAffectingLocations)
            resolutionsWithOnlyAffectingLocations.add(resolution);
        // Watch package json
        for (const affectingLocation of affectingLocations) {
            createFileWatcherOfAffectingLocation(affectingLocation, /*forResolution*/ true);
        }
    }
    function createFileWatcherOfAffectingLocation(affectingLocation, forResolution) {
        const fileWatcher = fileWatchesOfAffectingLocations.get(affectingLocation);
        if (fileWatcher) {
            if (forResolution)
                fileWatcher.resolutions++;
            else
                fileWatcher.files++;
            return;
        }
        let locationToWatch = affectingLocation;
        let isSymlink = false;
        let symlinkWatcher;
        if (resolutionHost.realpath) {
            locationToWatch = resolutionHost.realpath(affectingLocation);
            if (affectingLocation !== locationToWatch) {
                isSymlink = true;
                symlinkWatcher = fileWatchesOfAffectingLocations.get(locationToWatch);
            }
        }
        const resolutions = forResolution ? 1 : 0;
        const files = forResolution ? 0 : 1;
        if (!isSymlink || !symlinkWatcher) {
            const watcher = {
                watcher: canWatchAffectingLocation(resolutionHost.toPath(locationToWatch)) ?
                    resolutionHost.watchAffectingFileLocation(locationToWatch, (fileName, eventKind) => {
                        cachedDirectoryStructureHost?.addOrDeleteFile(fileName, resolutionHost.toPath(locationToWatch), eventKind);
                        invalidateAffectingFileWatcher(locationToWatch, moduleResolutionCache.getPackageJsonInfoCache().getInternalMap());
                        resolutionHost.scheduleInvalidateResolutionsOfFailedLookupLocations();
                    }) : ts_js_1.noopFileWatcher,
                resolutions: isSymlink ? 0 : resolutions,
                files: isSymlink ? 0 : files,
                symlinks: undefined,
            };
            fileWatchesOfAffectingLocations.set(locationToWatch, watcher);
            if (isSymlink)
                symlinkWatcher = watcher;
        }
        if (isSymlink) {
            ts_js_1.Debug.assert(!!symlinkWatcher);
            const watcher = {
                watcher: {
                    close: () => {
                        const symlinkWatcher = fileWatchesOfAffectingLocations.get(locationToWatch);
                        // Close symlink watcher if no ref
                        if (symlinkWatcher?.symlinks?.delete(affectingLocation) && !symlinkWatcher.symlinks.size && !symlinkWatcher.resolutions && !symlinkWatcher.files) {
                            fileWatchesOfAffectingLocations.delete(locationToWatch);
                            symlinkWatcher.watcher.close();
                        }
                    },
                },
                resolutions,
                files,
                symlinks: undefined,
            };
            fileWatchesOfAffectingLocations.set(affectingLocation, watcher);
            (symlinkWatcher.symlinks ?? (symlinkWatcher.symlinks = new Set())).add(affectingLocation);
        }
    }
    function invalidateAffectingFileWatcher(path, packageJsonMap) {
        const watcher = fileWatchesOfAffectingLocations.get(path);
        if (watcher?.resolutions)
            (affectingPathChecks ?? (affectingPathChecks = new Set())).add(path);
        if (watcher?.files)
            (affectingPathChecksForFile ?? (affectingPathChecksForFile = new Set())).add(path);
        watcher?.symlinks?.forEach(path => invalidateAffectingFileWatcher(path, packageJsonMap));
        packageJsonMap?.delete(resolutionHost.toPath(path));
    }
    function watchFailedLookupLocationOfNonRelativeModuleResolutions() {
        nonRelativeExternalModuleResolutions.forEach(watchFailedLookupLocationOfResolution);
        nonRelativeExternalModuleResolutions.clear();
    }
    function createDirectoryWatcherForPackageDir(dir, dirPath, packageDir, packageDirPath, nonRecursive) {
        ts_js_1.Debug.assert(!nonRecursive);
        // Check if this is symlink:
        let isSymlink = isSymlinkCache.get(packageDirPath);
        let packageDirWatcher = packageDirWatchers.get(packageDirPath);
        if (isSymlink === undefined) {
            const realPath = resolutionHost.realpath(packageDir);
            isSymlink = realPath !== packageDir && resolutionHost.toPath(realPath) !== packageDirPath;
            isSymlinkCache.set(packageDirPath, isSymlink);
            if (!packageDirWatcher) {
                packageDirWatchers.set(packageDirPath, packageDirWatcher = {
                    dirPathToWatcher: new Map(),
                    isSymlink,
                });
            }
            else if (packageDirWatcher.isSymlink !== isSymlink) {
                // Handle the change
                packageDirWatcher.dirPathToWatcher.forEach(watcher => {
                    removeDirectoryWatcher(packageDirWatcher.isSymlink ? packageDirPath : dirPath);
                    watcher.watcher = createDirPathToWatcher();
                });
                packageDirWatcher.isSymlink = isSymlink;
            }
        }
        else {
            ts_js_1.Debug.assertIsDefined(packageDirWatcher);
            ts_js_1.Debug.assert(isSymlink === packageDirWatcher.isSymlink);
        }
        const forDirPath = packageDirWatcher.dirPathToWatcher.get(dirPath);
        if (forDirPath) {
            forDirPath.refCount++;
        }
        else {
            packageDirWatcher.dirPathToWatcher.set(dirPath, {
                watcher: createDirPathToWatcher(),
                refCount: 1,
            });
            if (isSymlink)
                dirPathToSymlinkPackageRefCount.set(dirPath, (dirPathToSymlinkPackageRefCount.get(dirPath) ?? 0) + 1);
        }
        function createDirPathToWatcher() {
            return isSymlink ?
                createOrAddRefToDirectoryWatchOfFailedLookups(packageDir, packageDirPath, nonRecursive) :
                createOrAddRefToDirectoryWatchOfFailedLookups(dir, dirPath, nonRecursive);
        }
    }
    function setDirectoryWatcher(dir, dirPath, packageDir, packageDirPath, nonRecursive) {
        if (!packageDirPath || !resolutionHost.realpath) {
            createOrAddRefToDirectoryWatchOfFailedLookups(dir, dirPath, nonRecursive);
        }
        else {
            createDirectoryWatcherForPackageDir(dir, dirPath, packageDir, packageDirPath, nonRecursive);
        }
    }
    function createOrAddRefToDirectoryWatchOfFailedLookups(dir, dirPath, nonRecursive) {
        let dirWatcher = directoryWatchesOfFailedLookups.get(dirPath);
        if (dirWatcher) {
            ts_js_1.Debug.assert(!!nonRecursive === !!dirWatcher.nonRecursive);
            dirWatcher.refCount++;
        }
        else {
            directoryWatchesOfFailedLookups.set(dirPath, dirWatcher = { watcher: createDirectoryWatcher(dir, dirPath, nonRecursive), refCount: 1, nonRecursive });
        }
        return dirWatcher;
    }
    function stopWatchFailedLookupLocation(failedLookupLocation, removeAtRoot) {
        const failedLookupLocationPath = resolutionHost.toPath(failedLookupLocation);
        const toWatch = getDirectoryToWatchFailedLookupLocation(failedLookupLocation, failedLookupLocationPath, rootDir, rootPath, rootPathComponents, isRootWatchable, getCurrentDirectory, resolutionHost.preferNonRecursiveWatch);
        if (toWatch) {
            const { dirPath, packageDirPath } = toWatch;
            if (dirPath === rootPath) {
                removeAtRoot = true;
            }
            else if (packageDirPath && resolutionHost.realpath) {
                const packageDirWatcher = packageDirWatchers.get(packageDirPath);
                const forDirPath = packageDirWatcher.dirPathToWatcher.get(dirPath);
                forDirPath.refCount--;
                if (forDirPath.refCount === 0) {
                    removeDirectoryWatcher(packageDirWatcher.isSymlink ? packageDirPath : dirPath);
                    packageDirWatcher.dirPathToWatcher.delete(dirPath);
                    if (packageDirWatcher.isSymlink) {
                        const refCount = dirPathToSymlinkPackageRefCount.get(dirPath) - 1;
                        if (refCount === 0) {
                            dirPathToSymlinkPackageRefCount.delete(dirPath);
                        }
                        else {
                            dirPathToSymlinkPackageRefCount.set(dirPath, refCount);
                        }
                    }
                }
            }
            else {
                removeDirectoryWatcher(dirPath);
            }
        }
        return removeAtRoot;
    }
    function stopWatchFailedLookupLocationOfResolution(resolution, filePath, getResolutionWithResolvedFileName) {
        ts_js_1.Debug.checkDefined(resolution.files).delete(filePath);
        if (resolution.files.size)
            return;
        resolution.files = undefined;
        const resolved = getResolutionWithResolvedFileName(resolution);
        if (resolved && resolved.resolvedFileName) {
            const key = resolutionHost.toPath(resolved.resolvedFileName);
            const resolutions = resolvedFileToResolution.get(key);
            if (resolutions?.delete(resolution) && !resolutions.size)
                resolvedFileToResolution.delete(key);
        }
        const { failedLookupLocations, affectingLocations, alternateResult } = resolution;
        if (resolutionsWithFailedLookups.delete(resolution)) {
            let removeAtRoot = false;
            if (failedLookupLocations) {
                for (const failedLookupLocation of failedLookupLocations) {
                    removeAtRoot = stopWatchFailedLookupLocation(failedLookupLocation, removeAtRoot);
                }
            }
            if (alternateResult)
                removeAtRoot = stopWatchFailedLookupLocation(alternateResult, removeAtRoot);
            if (removeAtRoot)
                removeDirectoryWatcher(rootPath);
        }
        else if (affectingLocations?.length) {
            resolutionsWithOnlyAffectingLocations.delete(resolution);
        }
        if (affectingLocations) {
            for (const affectingLocation of affectingLocations) {
                const watcher = fileWatchesOfAffectingLocations.get(affectingLocation);
                watcher.resolutions--;
            }
        }
    }
    function removeDirectoryWatcher(dirPath) {
        const dirWatcher = directoryWatchesOfFailedLookups.get(dirPath);
        // Do not close the watcher yet since it might be needed by other failed lookup locations.
        dirWatcher.refCount--;
    }
    function createDirectoryWatcher(directory, dirPath, nonRecursive) {
        return resolutionHost.watchDirectoryOfFailedLookupLocation(directory, fileOrDirectory => {
            const fileOrDirectoryPath = resolutionHost.toPath(fileOrDirectory);
            if (cachedDirectoryStructureHost) {
                // Since the file existence changed, update the sourceFiles cache
                cachedDirectoryStructureHost.addOrDeleteFileOrDirectory(fileOrDirectory, fileOrDirectoryPath);
            }
            scheduleInvalidateResolutionOfFailedLookupLocation(fileOrDirectoryPath, dirPath === fileOrDirectoryPath);
        }, nonRecursive ? 0 /* WatchDirectoryFlags.None */ : 1 /* WatchDirectoryFlags.Recursive */);
    }
    function removeResolutionsOfFileFromCache(cache, filePath, getResolutionWithResolvedFileName) {
        // Deleted file, stop watching failed lookups for all the resolutions in the file
        const resolutions = cache.get(filePath);
        if (resolutions) {
            if (!resolutionHost.skipWatchingFailedLookups?.(filePath)) {
                resolutions.forEach(resolution => stopWatchFailedLookupLocationOfResolution(resolution, filePath, getResolutionWithResolvedFileName));
            }
            cache.delete(filePath);
        }
    }
    function removeResolutionsFromProjectReferenceRedirects(filePath) {
        if (!(0, ts_js_1.fileExtensionIs)(filePath, ".json" /* Extension.Json */))
            return;
        const program = resolutionHost.getCurrentProgram();
        if (!program)
            return;
        // If this file is input file for the referenced project, get it
        const resolvedProjectReference = program.getResolvedProjectReferenceByPath(filePath);
        if (!resolvedProjectReference)
            return;
        // filePath is for the projectReference and the containing file is from this project reference, invalidate the resolution
        resolvedProjectReference.commandLine.fileNames.forEach(f => removeResolutionsOfFile(resolutionHost.toPath(f)));
    }
    function removeResolutionsOfFile(filePath) {
        removeResolutionsOfFileFromCache(resolvedModuleNames, filePath, ts_js_1.getResolvedModuleFromResolution);
        removeResolutionsOfFileFromCache(resolvedTypeReferenceDirectives, filePath, ts_js_1.getResolvedTypeReferenceDirectiveFromResolution);
    }
    function invalidateResolutions(resolutions, canInvalidate) {
        if (!resolutions)
            return false;
        let invalidated = false;
        resolutions.forEach(resolution => {
            if (resolution.isInvalidated || !canInvalidate(resolution))
                return;
            resolution.isInvalidated = invalidated = true;
            for (const containingFilePath of ts_js_1.Debug.checkDefined(resolution.files)) {
                (filesWithInvalidatedResolutions ?? (filesWithInvalidatedResolutions = new Set())).add(containingFilePath);
                // When its a file with inferred types resolution, invalidate type reference directive resolution
                hasChangedAutomaticTypeDirectiveNames = hasChangedAutomaticTypeDirectiveNames || (0, ts_js_1.endsWith)(containingFilePath, ts_js_1.inferredTypesContainingFile);
            }
        });
        return invalidated;
    }
    function invalidateResolutionOfFile(filePath) {
        removeResolutionsOfFile(filePath);
        // Resolution is invalidated if the resulting file name is same as the deleted file path
        const prevHasChangedAutomaticTypeDirectiveNames = hasChangedAutomaticTypeDirectiveNames;
        if (invalidateResolutions(resolvedFileToResolution.get(filePath), ts_js_1.returnTrue) &&
            hasChangedAutomaticTypeDirectiveNames &&
            !prevHasChangedAutomaticTypeDirectiveNames) {
            resolutionHost.onChangedAutomaticTypeDirectiveNames();
        }
    }
    function setFilesWithInvalidatedNonRelativeUnresolvedImports(filesMap) {
        ts_js_1.Debug.assert(filesWithInvalidatedNonRelativeUnresolvedImports === filesMap || filesWithInvalidatedNonRelativeUnresolvedImports === undefined);
        filesWithInvalidatedNonRelativeUnresolvedImports = filesMap;
    }
    function scheduleInvalidateResolutionOfFailedLookupLocation(fileOrDirectoryPath, isCreatingWatchedDirectory) {
        if (isCreatingWatchedDirectory) {
            // Watching directory is created
            // Invalidate any resolution has failed lookup in this directory
            (isInDirectoryChecks || (isInDirectoryChecks = new Set())).add(fileOrDirectoryPath);
        }
        else {
            // If something to do with folder/file starting with "." in node_modules folder, skip it
            const updatedPath = removeIgnoredPath(fileOrDirectoryPath);
            if (!updatedPath)
                return false;
            fileOrDirectoryPath = updatedPath;
            // prevent saving an open file from over-eagerly triggering invalidation
            if (resolutionHost.fileIsOpen(fileOrDirectoryPath)) {
                return false;
            }
            // Some file or directory in the watching directory is created
            // Return early if it does not have any of the watching extension or not the custom failed lookup path
            const dirOfFileOrDirectory = (0, ts_js_1.getDirectoryPath)(fileOrDirectoryPath);
            if (isNodeModulesAtTypesDirectory(fileOrDirectoryPath) || (0, ts_js_1.isNodeModulesDirectory)(fileOrDirectoryPath) ||
                isNodeModulesAtTypesDirectory(dirOfFileOrDirectory) || (0, ts_js_1.isNodeModulesDirectory)(dirOfFileOrDirectory)) {
                // Invalidate any resolution from this directory
                (failedLookupChecks || (failedLookupChecks = new Set())).add(fileOrDirectoryPath);
                (startsWithPathChecks || (startsWithPathChecks = new Set())).add(fileOrDirectoryPath);
            }
            else {
                // Ignore emits from the program
                if ((0, ts_js_1.isEmittedFileOfProgram)(resolutionHost.getCurrentProgram(), fileOrDirectoryPath)) {
                    return false;
                }
                // Ignore .map files
                if ((0, ts_js_1.fileExtensionIs)(fileOrDirectoryPath, ".map")) {
                    return false;
                }
                // Resolution need to be invalidated if failed lookup location is same as the file or directory getting created
                (failedLookupChecks || (failedLookupChecks = new Set())).add(fileOrDirectoryPath);
                // Also any path that starts with this path should be added just in case if this is directory notification
                // and we dont get any notification for file
                (startsWithPathChecks || (startsWithPathChecks = new Set())).add(fileOrDirectoryPath);
                // If the invalidated file is from a node_modules package, invalidate everything else
                // in the package since we might not get notifications for other files in the package.
                // This hardens our logic against unreliable file watchers.
                const packagePath = (0, ts_js_1.parseNodeModuleFromPath)(fileOrDirectoryPath, /*isFolder*/ true);
                if (packagePath)
                    (startsWithPathChecks || (startsWithPathChecks = new Set())).add(packagePath);
            }
        }
        resolutionHost.scheduleInvalidateResolutionsOfFailedLookupLocations();
    }
    function invalidatePackageJsonMap() {
        const packageJsonMap = moduleResolutionCache.getPackageJsonInfoCache().getInternalMap();
        if (packageJsonMap && (failedLookupChecks || startsWithPathChecks || isInDirectoryChecks)) {
            packageJsonMap.forEach((_value, path) => isInvalidatedFailedLookup(path) ? packageJsonMap.delete(path) : undefined);
        }
    }
    function invalidateResolutionsOfFailedLookupLocations() {
        if (allModuleAndTypeResolutionsAreInvalidated) {
            affectingPathChecksForFile = undefined;
            invalidatePackageJsonMap();
            if (failedLookupChecks || startsWithPathChecks || isInDirectoryChecks || affectingPathChecks) {
                invalidateResolutions(resolvedLibraries, canInvalidateFailedLookupResolution);
            }
            failedLookupChecks = undefined;
            startsWithPathChecks = undefined;
            isInDirectoryChecks = undefined;
            affectingPathChecks = undefined;
            return true;
        }
        let invalidated = false;
        if (affectingPathChecksForFile) {
            resolutionHost.getCurrentProgram()?.getSourceFiles().forEach(f => {
                if ((0, ts_js_1.some)(f.packageJsonLocations, location => affectingPathChecksForFile.has(location))) {
                    (filesWithInvalidatedResolutions ?? (filesWithInvalidatedResolutions = new Set())).add(f.path);
                    invalidated = true;
                }
            });
            affectingPathChecksForFile = undefined;
        }
        if (!failedLookupChecks && !startsWithPathChecks && !isInDirectoryChecks && !affectingPathChecks) {
            return invalidated;
        }
        invalidated = invalidateResolutions(resolutionsWithFailedLookups, canInvalidateFailedLookupResolution) || invalidated;
        invalidatePackageJsonMap();
        failedLookupChecks = undefined;
        startsWithPathChecks = undefined;
        isInDirectoryChecks = undefined;
        invalidated = invalidateResolutions(resolutionsWithOnlyAffectingLocations, canInvalidatedFailedLookupResolutionWithAffectingLocation) || invalidated;
        affectingPathChecks = undefined;
        return invalidated;
    }
    function canInvalidateFailedLookupResolution(resolution) {
        if (canInvalidatedFailedLookupResolutionWithAffectingLocation(resolution))
            return true;
        if (!failedLookupChecks && !startsWithPathChecks && !isInDirectoryChecks)
            return false;
        return resolution.failedLookupLocations?.some(location => isInvalidatedFailedLookup(resolutionHost.toPath(location))) ||
            (!!resolution.alternateResult && isInvalidatedFailedLookup(resolutionHost.toPath(resolution.alternateResult)));
    }
    function isInvalidatedFailedLookup(locationPath) {
        return failedLookupChecks?.has(locationPath) ||
            (0, ts_js_1.firstDefinedIterator)(startsWithPathChecks?.keys() || [], fileOrDirectoryPath => (0, ts_js_1.startsWith)(locationPath, fileOrDirectoryPath) ? true : undefined) ||
            (0, ts_js_1.firstDefinedIterator)(isInDirectoryChecks?.keys() || [], dirPath => locationPath.length > dirPath.length &&
                (0, ts_js_1.startsWith)(locationPath, dirPath) && ((0, ts_js_1.isDiskPathRoot)(dirPath) || locationPath[dirPath.length] === ts_js_1.directorySeparator) ? true : undefined);
    }
    function canInvalidatedFailedLookupResolutionWithAffectingLocation(resolution) {
        return !!affectingPathChecks && resolution.affectingLocations?.some(location => affectingPathChecks.has(location));
    }
    function closeTypeRootsWatch() {
        (0, ts_js_1.clearMap)(typeRootsWatches, ts_js_1.closeFileWatcher);
    }
    function createTypeRootsWatch(typeRoot) {
        // Create new watch and recursive info
        return canWatchTypeRootPath(typeRoot) ?
            resolutionHost.watchTypeRootsDirectory(typeRoot, fileOrDirectory => {
                const fileOrDirectoryPath = resolutionHost.toPath(fileOrDirectory);
                if (cachedDirectoryStructureHost) {
                    // Since the file existence changed, update the sourceFiles cache
                    cachedDirectoryStructureHost.addOrDeleteFileOrDirectory(fileOrDirectory, fileOrDirectoryPath);
                }
                // For now just recompile
                // We could potentially store more data here about whether it was/would be really be used or not
                // and with that determine to trigger compilation but for now this is enough
                hasChangedAutomaticTypeDirectiveNames = true;
                resolutionHost.onChangedAutomaticTypeDirectiveNames();
                // Since directory watchers invoked are flaky, the failed lookup location events might not be triggered
                // So handle to failed lookup locations here as well to ensure we are invalidating resolutions
                const dirPath = getDirectoryToWatchFailedLookupLocationFromTypeRoot(typeRoot, resolutionHost.toPath(typeRoot), rootPath, rootPathComponents, isRootWatchable, getCurrentDirectory, resolutionHost.preferNonRecursiveWatch, dirPath => directoryWatchesOfFailedLookups.has(dirPath) || dirPathToSymlinkPackageRefCount.has(dirPath));
                if (dirPath) {
                    scheduleInvalidateResolutionOfFailedLookupLocation(fileOrDirectoryPath, dirPath === fileOrDirectoryPath);
                }
            }, 1 /* WatchDirectoryFlags.Recursive */) :
            ts_js_1.noopFileWatcher;
    }
    /**
     * Watches the types that would get added as part of getAutomaticTypeDirectiveNames
     * To be called when compiler options change
     */
    function updateTypeRootsWatch() {
        const options = resolutionHost.getCompilationSettings();
        if (!(0, ts_js_1.usesWildcardTypes)(options)) {
            // No need to do any watch since resolution cache is going to handle the failed lookups
            // for the types added by this
            closeTypeRootsWatch();
            return;
        }
        // if this is inferred project with non watchable root or current directory that is lib location, skip watching type roots
        if (!isRootWatchable || resolutionHost.skipWatchingTypeRoots?.()) {
            closeTypeRootsWatch();
            return;
        }
        // we need to assume the directories exist to ensure that we can get all the type root directories that get included
        // But filter directories that are at root level to say directory doesnt exist, so that we arent watching them
        const typeRoots = (0, ts_js_1.getEffectiveTypeRoots)(options, { getCurrentDirectory });
        if (typeRoots) {
            (0, ts_js_1.mutateMap)(typeRootsWatches, new Set(typeRoots), {
                createNewValue: createTypeRootsWatch,
                onDeleteValue: ts_js_1.closeFileWatcher,
            });
        }
        else {
            closeTypeRootsWatch();
        }
    }
    function canWatchTypeRootPath(typeRoot) {
        // If type roots is specified, watch that path
        if (resolutionHost.getCompilationSettings().typeRoots)
            return true;
        // Otherwise can watch directory only if we can watch the parent directory of node_modules/@types
        return canWatchAtTypes(resolutionHost.toPath(typeRoot));
    }
}
function resolutionIsSymlink(resolution) {
    return !!(resolution.resolvedModule?.originalPath ||
        resolution.resolvedTypeReferenceDirective?.originalPath);
}
