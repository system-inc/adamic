"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNodeChildren = getNodeChildren;
exports.setNodeChildren = setNodeChildren;
exports.unsetNodeChildren = unsetNodeChildren;
exports.transferSourceFileChildren = transferSourceFileChildren;
const ts_js_1 = require("../_namespaces/ts.js");
const sourceFileToNodeChildren = new WeakMap();
/** @internal */
function getNodeChildren(node, sourceFile) {
    const kind = node.kind;
    if (!(0, ts_js_1.isNodeKind)(kind)) {
        return ts_js_1.emptyArray;
    }
    if (kind === 353 /* SyntaxKind.SyntaxList */) {
        return node._children;
    }
    return sourceFileToNodeChildren.get(sourceFile)?.get(node);
}
/** @internal */
function setNodeChildren(node, sourceFile, children) {
    if (node.kind === 353 /* SyntaxKind.SyntaxList */) {
        // SyntaxList children are always eagerly created in the process of
        // creating their parent's `children` list. We shouldn't need to set them here.
        ts_js_1.Debug.fail("Should not need to re-set the children of a SyntaxList.");
    }
    let map = sourceFileToNodeChildren.get(sourceFile);
    if (map === undefined) {
        map = new WeakMap();
        sourceFileToNodeChildren.set(sourceFile, map);
    }
    map.set(node, children);
    return children;
}
/** @internal */
function unsetNodeChildren(node, origSourceFile) {
    if (node.kind === 353 /* SyntaxKind.SyntaxList */) {
        // Syntax lists are synthesized and we store their children directly on them.
        // They are a special case where we expect incremental parsing to toss them away entirely
        // if a change intersects with their containing parents.
        ts_js_1.Debug.fail("Did not expect to unset the children of a SyntaxList.");
    }
    sourceFileToNodeChildren.get(origSourceFile)?.delete(node);
}
/** @internal */
function transferSourceFileChildren(sourceFile, targetSourceFile) {
    const map = sourceFileToNodeChildren.get(sourceFile);
    if (map !== undefined) {
        sourceFileToNodeChildren.delete(sourceFile);
        sourceFileToNodeChildren.set(targetSourceFile, map);
    }
}
