"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformESNext = transformESNext;
const ts_js_1 = require("../_namespaces/ts.js");
var UsingKind;
(function (UsingKind) {
    UsingKind[UsingKind["None"] = 0] = "None";
    UsingKind[UsingKind["Sync"] = 1] = "Sync";
    UsingKind[UsingKind["Async"] = 2] = "Async";
})(UsingKind || (UsingKind = {}));
/** @internal */
function transformESNext(context) {
    // NOTE: We must reevaluate the target for upcoming features when each successive TC39 edition is ratified in
    //       June of each year. This includes changes to `LanguageFeatureMinimumTarget`, `ScriptTarget`,
    //       `ScriptTargetFeatures`, `CommandLineOptionOfCustomType`, transformers/esnext.ts, compiler/commandLineParser.ts,
    //       compiler/utilitiesPublic.ts, and the contents of each lib/esnext.*.d.ts file.
    const { factory, getEmitHelperFactory: emitHelpers, hoistVariableDeclaration, startLexicalEnvironment, endLexicalEnvironment, } = context;
    let exportBindings;
    let exportVars;
    let defaultExportBinding;
    let exportEqualsBinding;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        const visited = (0, ts_js_1.visitNode)(node, visitor, ts_js_1.isSourceFile);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        exportVars = undefined;
        exportBindings = undefined;
        defaultExportBinding = undefined;
        return visited;
    }
    function visitor(node) {
        if ((node.transformFlags & 4 /* TransformFlags.ContainsESNext */) === 0) {
            return node;
        }
        switch (node.kind) {
            case 308 /* SyntaxKind.SourceFile */:
                return visitSourceFile(node);
            case 242 /* SyntaxKind.Block */:
                return visitBlock(node);
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node);
            case 251 /* SyntaxKind.ForOfStatement */:
                return visitForOfStatement(node);
            default:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function visitSourceFile(node) {
        const usingKind = getUsingKindOfStatements(node.statements);
        if (usingKind) {
            // Imports and exports must stay at the top level. This means we must hoist all imports, exports, and
            // top-level function declarations and bindings out of the `try` statements we generate. For example:
            //
            // given:
            //
            //  import { w } from "mod";
            //  const x = expr1;
            //  using y = expr2;
            //  const z = expr3;
            //  export function f() {
            //    console.log(z);
            //  }
            //
            // produces:
            //
            //  import { x } from "mod";        // <-- preserved
            //  const x = expr1;                // <-- preserved
            //  var y, z;                       // <-- hoisted
            //  export function f() {           // <-- hoisted
            //    console.log(z);
            //  }
            //  const env_1 = { stack: [], error: void 0, hasError: false };
            //  try {
            //    y = __addDisposableResource(env_1, expr2, false);
            //    z = expr3;
            //  }
            //  catch (e_1) {
            //    env_1.error = e_1;
            //    env_1.hasError = true;
            //  }
            //  finally {
            //    __disposeResource(env_1);
            //  }
            //
            // In this transformation, we hoist `y`, `z`, and `f` to a new outer statement list while moving all other
            // statements in the source file into the `try` block, which is the same approach we use for System module
            // emit. Unlike System module emit, we attempt to preserve all statements prior to the first top-level
            // `using` to isolate the complexity of the transformed output to only where it is necessary.
            startLexicalEnvironment();
            exportBindings = new ts_js_1.IdentifierNameMap();
            exportVars = [];
            const prologueCount = countPrologueStatements(node.statements);
            const topLevelStatements = [];
            (0, ts_js_1.addRange)(topLevelStatements, (0, ts_js_1.visitArray)(node.statements, visitor, ts_js_1.isStatement, 0, prologueCount));
            // Collect and transform any leading statements up to the first `using` or `await using`. This preserves
            // the original statement order much as is possible.
            let pos = prologueCount;
            while (pos < node.statements.length) {
                const statement = node.statements[pos];
                if (getUsingKind(statement) !== 0 /* UsingKind.None */) {
                    if (pos > prologueCount) {
                        (0, ts_js_1.addRange)(topLevelStatements, (0, ts_js_1.visitNodes)(node.statements, visitor, ts_js_1.isStatement, prologueCount, pos - prologueCount));
                    }
                    break;
                }
                pos++;
            }
            ts_js_1.Debug.assert(pos < node.statements.length, "Should have encountered at least one 'using' statement.");
            // transform the rest of the body
            const envBinding = createEnvBinding();
            const bodyStatements = transformUsingDeclarations(node.statements, pos, node.statements.length, envBinding, topLevelStatements);
            // add `export {}` declarations for any hoisted bindings.
            if (exportBindings.size) {
                (0, ts_js_1.append)(topLevelStatements, factory.createExportDeclaration(
                /*modifiers*/ undefined, 
                /*isTypeOnly*/ false, factory.createNamedExports((0, ts_js_1.arrayFrom)(exportBindings.values()))));
            }
            (0, ts_js_1.addRange)(topLevelStatements, endLexicalEnvironment());
            if (exportVars.length) {
                topLevelStatements.push(factory.createVariableStatement(factory.createModifiersFromModifierFlags(32 /* ModifierFlags.Export */), factory.createVariableDeclarationList(exportVars, 1 /* NodeFlags.Let */)));
            }
            (0, ts_js_1.addRange)(topLevelStatements, createDownlevelUsingStatements(bodyStatements, envBinding, usingKind === 2 /* UsingKind.Async */));
            if (exportEqualsBinding) {
                topLevelStatements.push(factory.createExportAssignment(
                /*modifiers*/ undefined, 
                /*isExportEquals*/ true, exportEqualsBinding));
            }
            return factory.updateSourceFile(node, topLevelStatements);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitBlock(node) {
        const usingKind = getUsingKindOfStatements(node.statements);
        if (usingKind) {
            const prologueCount = countPrologueStatements(node.statements);
            const envBinding = createEnvBinding();
            return factory.updateBlock(node, [
                ...(0, ts_js_1.visitArray)(node.statements, visitor, ts_js_1.isStatement, 0, prologueCount),
                ...createDownlevelUsingStatements(transformUsingDeclarations(node.statements, prologueCount, node.statements.length, envBinding, /*topLevelStatements*/ undefined), envBinding, usingKind === 2 /* UsingKind.Async */),
            ]);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitForStatement(node) {
        if (node.initializer && isUsingVariableDeclarationList(node.initializer)) {
            // given:
            //
            //  for (using x = expr; cond; incr) { ... }
            //
            // produces a shallow transformation to:
            //
            //  {
            //    using x = expr;
            //    for (; cond; incr) { ... }
            //  }
            //
            // before handing the shallow transformation back to the visitor for an in-depth transformation.
            return (0, ts_js_1.visitNode)(factory.createBlock([
                factory.createVariableStatement(/*modifiers*/ undefined, node.initializer),
                factory.updateForStatement(node, 
                /*initializer*/ undefined, node.condition, node.incrementor, node.statement),
            ]), visitor, ts_js_1.isStatement);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitForOfStatement(node) {
        if (isUsingVariableDeclarationList(node.initializer)) {
            // given:
            //
            //  for (using x of y) { ... }
            //
            // produces a shallow transformation to:
            //
            //  for (const x_1 of y) {
            //    using x = x;
            //    ...
            //  }
            //
            // before handing the shallow transformation back to the visitor for an in-depth transformation.
            const forInitializer = node.initializer;
            const forDecl = (0, ts_js_1.firstOrUndefined)(forInitializer.declarations) || factory.createVariableDeclaration(factory.createTempVariable(/*recordTempVariable*/ undefined));
            const isAwaitUsing = getUsingKindOfVariableDeclarationList(forInitializer) === 2 /* UsingKind.Async */;
            const temp = factory.getGeneratedNameForNode(forDecl.name);
            const usingVar = factory.updateVariableDeclaration(forDecl, forDecl.name, /*exclamationToken*/ undefined, /*type*/ undefined, temp);
            const usingVarList = factory.createVariableDeclarationList([usingVar], isAwaitUsing ? 6 /* NodeFlags.AwaitUsing */ : 4 /* NodeFlags.Using */);
            const usingVarStatement = factory.createVariableStatement(/*modifiers*/ undefined, usingVarList);
            return (0, ts_js_1.visitNode)(factory.updateForOfStatement(node, node.awaitModifier, factory.createVariableDeclarationList([
                factory.createVariableDeclaration(temp),
            ], 2 /* NodeFlags.Const */), node.expression, (0, ts_js_1.isBlock)(node.statement) ?
                factory.updateBlock(node.statement, [
                    usingVarStatement,
                    ...node.statement.statements,
                ]) :
                factory.createBlock([
                    usingVarStatement,
                    node.statement,
                ], /*multiLine*/ true)), visitor, ts_js_1.isStatement);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Transform `using` declarations in a statement list.
     */
    function transformUsingDeclarations(statementsIn, start, end, envBinding, topLevelStatements) {
        const statements = [];
        for (let i = start; i < end; i++) {
            const statement = statementsIn[i];
            const usingKind = getUsingKind(statement);
            if (usingKind) {
                ts_js_1.Debug.assertNode(statement, ts_js_1.isVariableStatement);
                const declarations = [];
                for (let declaration of statement.declarationList.declarations) {
                    if (!(0, ts_js_1.isIdentifier)(declaration.name)) {
                        // Since binding patterns are a grammar error, we reset `declarations` so we don't process this as a `using`.
                        declarations.length = 0;
                        break;
                    }
                    // perform a shallow transform for any named evaluation
                    if ((0, ts_js_1.isNamedEvaluation)(declaration)) {
                        declaration = (0, ts_js_1.transformNamedEvaluation)(context, declaration);
                    }
                    const initializer = (0, ts_js_1.visitNode)(declaration.initializer, visitor, ts_js_1.isExpression) ?? factory.createVoidZero();
                    declarations.push(factory.updateVariableDeclaration(declaration, declaration.name, 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, emitHelpers().createAddDisposableResourceHelper(envBinding, initializer, usingKind === 2 /* UsingKind.Async */)));
                }
                // Only replace the statement if it was valid.
                if (declarations.length) {
                    const varList = factory.createVariableDeclarationList(declarations, 2 /* NodeFlags.Const */);
                    (0, ts_js_1.setOriginalNode)(varList, statement.declarationList);
                    (0, ts_js_1.setTextRange)(varList, statement.declarationList);
                    hoistOrAppendNode(factory.updateVariableStatement(statement, /*modifiers*/ undefined, varList));
                    continue;
                }
            }
            const result = visitor(statement);
            if ((0, ts_js_1.isArray)(result)) {
                result.forEach(hoistOrAppendNode);
            }
            else if (result) {
                hoistOrAppendNode(result);
            }
        }
        return statements;
        function hoistOrAppendNode(node) {
            ts_js_1.Debug.assertNode(node, ts_js_1.isStatement);
            (0, ts_js_1.append)(statements, hoist(node));
        }
        function hoist(node) {
            if (!topLevelStatements)
                return node;
            switch (node.kind) {
                case 273 /* SyntaxKind.ImportDeclaration */:
                case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                case 279 /* SyntaxKind.ExportDeclaration */:
                case 263 /* SyntaxKind.FunctionDeclaration */:
                    return hoistImportOrExportOrHoistedDeclaration(node, topLevelStatements);
                case 278 /* SyntaxKind.ExportAssignment */:
                    return hoistExportAssignment(node);
                case 264 /* SyntaxKind.ClassDeclaration */:
                    return hoistClassDeclaration(node);
                case 244 /* SyntaxKind.VariableStatement */:
                    return hoistVariableStatement(node);
            }
            return node;
        }
    }
    function hoistImportOrExportOrHoistedDeclaration(node, topLevelStatements) {
        // NOTE: `node` has already been visited
        topLevelStatements.push(node);
        return undefined;
    }
    function hoistExportAssignment(node) {
        return node.isExportEquals ? hoistExportEquals(node) : hoistExportDefault(node);
    }
    function hoistExportDefault(node) {
        // NOTE: `node` has already been visited
        if (defaultExportBinding) {
            // invalid case of multiple `export default` declarations. Don't assert here, just pass it through
            return node;
        }
        // given:
        //
        //   export default expr;
        //
        // produces:
        //
        //   // top level
        //   var default_1;
        //   export { default_1 as default };
        //
        //   // body
        //   default_1 = expr;
        defaultExportBinding = factory.createUniqueName("_default", 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */ | 32 /* GeneratedIdentifierFlags.FileLevel */ | 16 /* GeneratedIdentifierFlags.Optimistic */);
        hoistBindingIdentifier(defaultExportBinding, /*isExport*/ true, "default", node);
        // give a class or function expression an assigned name, if needed.
        let expression = node.expression;
        let innerExpression = (0, ts_js_1.skipOuterExpressions)(expression);
        if ((0, ts_js_1.isNamedEvaluation)(innerExpression)) {
            innerExpression = (0, ts_js_1.transformNamedEvaluation)(context, innerExpression, /*ignoreEmptyStringLiteral*/ false, "default");
            expression = factory.restoreOuterExpressions(expression, innerExpression);
        }
        const assignment = factory.createAssignment(defaultExportBinding, expression);
        return factory.createExpressionStatement(assignment);
    }
    function hoistExportEquals(node) {
        // NOTE: `node` has already been visited
        if (exportEqualsBinding) {
            // invalid case of multiple `export default` declarations. Don't assert here, just pass it through
            return node;
        }
        // given:
        //
        //   export = expr;
        //
        // produces:
        //
        //   // top level
        //   var default_1;
        //
        //   try {
        //       // body
        //       default_1 = expr;
        //   } ...
        //
        //   // top level suffix
        //   export = default_1;
        exportEqualsBinding = factory.createUniqueName("_default", 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */ | 32 /* GeneratedIdentifierFlags.FileLevel */ | 16 /* GeneratedIdentifierFlags.Optimistic */);
        hoistVariableDeclaration(exportEqualsBinding);
        // give a class or function expression an assigned name, if needed.
        const assignment = factory.createAssignment(exportEqualsBinding, node.expression);
        return factory.createExpressionStatement(assignment);
    }
    function hoistClassDeclaration(node) {
        // NOTE: `node` has already been visited
        if (!node.name && defaultExportBinding) {
            // invalid case of multiple `export default` declarations. Don't assert here, just pass it through
            return node;
        }
        const isExported = (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
        const isDefault = (0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */);
        // When hoisting a class declaration at the top level of a file containing a top-level `using` statement, we
        // must first convert it to a class expression so that we can hoist the binding outside of the `try`.
        let expression = factory.converters.convertToClassExpression(node);
        if (node.name) {
            // given:
            //
            //  using x = expr;
            //  class C {}
            //
            // produces:
            //
            //  var x, C;
            //  const env_1 = { ... };
            //  try {
            //    x = __addDisposableResource(env_1, expr, false);
            //    C = class {};
            //  }
            //  catch (e_1) {
            //    env_1.error = e_1;
            //    env_1.hasError = true;
            //  }
            //  finally {
            //    __disposeResources(env_1);
            //  }
            //
            // If the class is exported, we also produce an `export { C };`
            hoistBindingIdentifier(factory.getLocalName(node), isExported && !isDefault, /*exportAlias*/ undefined, node);
            expression = factory.createAssignment(factory.getDeclarationName(node), expression);
            if ((0, ts_js_1.isNamedEvaluation)(expression)) {
                expression = (0, ts_js_1.transformNamedEvaluation)(context, expression, /*ignoreEmptyStringLiteral*/ false);
            }
            (0, ts_js_1.setOriginalNode)(expression, node);
            (0, ts_js_1.setSourceMapRange)(expression, node);
            (0, ts_js_1.setCommentRange)(expression, node);
        }
        if (isDefault && !defaultExportBinding) {
            // In the case of a default export, we create a temporary variable that we export as the default and then
            // assign to that variable.
            //
            // given:
            //
            //  using x = expr;
            //  export default class C {}
            //
            // produces:
            //
            //  export { default_1 as default };
            //  var x, C, default_1;
            //  const env_1 = { ... };
            //  try {
            //    x = __addDisposableResource(env_1, expr, false);
            //    default_1 = C = class {};
            //  }
            //  catch (e_1) {
            //    env_1.error = e_1;
            //    env_1.hasError = true;
            //  }
            //  finally {
            //    __disposeResources(env_1);
            //  }
            //
            // Though we will never reassign `default_1`, this most closely matches the specified runtime semantics.
            defaultExportBinding = factory.createUniqueName("_default", 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */ | 32 /* GeneratedIdentifierFlags.FileLevel */ | 16 /* GeneratedIdentifierFlags.Optimistic */);
            hoistBindingIdentifier(defaultExportBinding, /*isExport*/ true, "default", node);
            expression = factory.createAssignment(defaultExportBinding, expression);
            if ((0, ts_js_1.isNamedEvaluation)(expression)) {
                expression = (0, ts_js_1.transformNamedEvaluation)(context, expression, /*ignoreEmptyStringLiteral*/ false, "default");
            }
            (0, ts_js_1.setOriginalNode)(expression, node);
        }
        return factory.createExpressionStatement(expression);
    }
    function hoistVariableStatement(node) {
        // NOTE: `node` has already been visited
        let expressions;
        const isExported = (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
        for (const variable of node.declarationList.declarations) {
            hoistBindingElement(variable, isExported, variable);
            if (variable.initializer) {
                expressions = (0, ts_js_1.append)(expressions, hoistInitializedVariable(variable));
            }
        }
        if (expressions) {
            const statement = factory.createExpressionStatement(factory.inlineExpressions(expressions));
            (0, ts_js_1.setOriginalNode)(statement, node);
            (0, ts_js_1.setCommentRange)(statement, node);
            (0, ts_js_1.setSourceMapRange)(statement, node);
            return statement;
        }
        return undefined;
    }
    function hoistInitializedVariable(node) {
        // NOTE: `node` has already been visited
        ts_js_1.Debug.assertIsDefined(node.initializer);
        let target;
        if ((0, ts_js_1.isIdentifier)(node.name)) {
            target = factory.cloneNode(node.name);
            (0, ts_js_1.setEmitFlags)(target, (0, ts_js_1.getEmitFlags)(target) & ~(32768 /* EmitFlags.LocalName */ | 16384 /* EmitFlags.ExportName */ | 65536 /* EmitFlags.InternalName */));
        }
        else {
            target = factory.converters.convertToAssignmentPattern(node.name);
        }
        const assignment = factory.createAssignment(target, node.initializer);
        (0, ts_js_1.setOriginalNode)(assignment, node);
        (0, ts_js_1.setCommentRange)(assignment, node);
        (0, ts_js_1.setSourceMapRange)(assignment, node);
        return assignment;
    }
    function hoistBindingElement(node, isExportedDeclaration, original) {
        // NOTE: `node` has already been visited
        if ((0, ts_js_1.isBindingPattern)(node.name)) {
            for (const element of node.name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    hoistBindingElement(element, isExportedDeclaration, original);
                }
            }
        }
        else {
            hoistBindingIdentifier(node.name, isExportedDeclaration, /*exportAlias*/ undefined, original);
        }
    }
    function hoistBindingIdentifier(node, isExport, exportAlias, original) {
        // NOTE: `node` has already been visited
        const name = (0, ts_js_1.isGeneratedIdentifier)(node) ? node : factory.cloneNode(node);
        if (isExport) {
            if (exportAlias === undefined && !(0, ts_js_1.isLocalName)(name)) {
                const varDecl = factory.createVariableDeclaration(name);
                if (original) {
                    (0, ts_js_1.setOriginalNode)(varDecl, original);
                }
                exportVars.push(varDecl);
                return;
            }
            const localName = exportAlias !== undefined ? name : undefined;
            const exportName = exportAlias !== undefined ? exportAlias : name;
            const specifier = factory.createExportSpecifier(/*isTypeOnly*/ false, localName, exportName);
            if (original) {
                (0, ts_js_1.setOriginalNode)(specifier, original);
            }
            exportBindings.set(name, specifier);
        }
        hoistVariableDeclaration(name);
    }
    function createEnvBinding() {
        return factory.createUniqueName("env");
    }
    function createDownlevelUsingStatements(bodyStatements, envBinding, async) {
        const statements = [];
        // produces:
        //
        //  const env_1 = { stack: [], error: void 0, hasError: false };
        //
        const envObject = factory.createObjectLiteralExpression([
            factory.createPropertyAssignment("stack", factory.createArrayLiteralExpression()),
            factory.createPropertyAssignment("error", factory.createVoidZero()),
            factory.createPropertyAssignment("hasError", factory.createFalse()),
        ]);
        const envVar = factory.createVariableDeclaration(envBinding, /*exclamationToken*/ undefined, /*type*/ undefined, envObject);
        const envVarList = factory.createVariableDeclarationList([envVar], 2 /* NodeFlags.Const */);
        const envVarStatement = factory.createVariableStatement(/*modifiers*/ undefined, envVarList);
        statements.push(envVarStatement);
        // when `async` is `false`, produces:
        //
        //  try {
        //    <bodyStatements>
        //  }
        //  catch (e_1) {
        //      env_1.error = e_1;
        //      env_1.hasError = true;
        //  }
        //  finally {
        //    __disposeResources(env_1);
        //  }
        // when `async` is `true`, produces:
        //
        //  try {
        //    <bodyStatements>
        //  }
        //  catch (e_1) {
        //      env_1.error = e_1;
        //      env_1.hasError = true;
        //  }
        //  finally {
        //    const result_1 = __disposeResources(env_1);
        //    if (result_1) {
        //      await result_1;
        //    }
        //  }
        // Unfortunately, it is necessary to use two properties to indicate an error because `throw undefined` is legal
        // JavaScript.
        const tryBlock = factory.createBlock(bodyStatements, /*multiLine*/ true);
        const bodyCatchBinding = factory.createUniqueName("e");
        const catchClause = factory.createCatchClause(bodyCatchBinding, factory.createBlock([
            factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(envBinding, "error"), bodyCatchBinding)),
            factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(envBinding, "hasError"), factory.createTrue())),
        ], /*multiLine*/ true));
        let finallyBlock;
        if (async) {
            const result = factory.createUniqueName("result");
            finallyBlock = factory.createBlock([
                factory.createVariableStatement(
                /*modifiers*/ undefined, factory.createVariableDeclarationList([
                    factory.createVariableDeclaration(result, 
                    /*exclamationToken*/ undefined, 
                    /*type*/ undefined, emitHelpers().createDisposeResourcesHelper(envBinding)),
                ], 2 /* NodeFlags.Const */)),
                factory.createIfStatement(result, factory.createExpressionStatement(factory.createAwaitExpression(result))),
            ], /*multiLine*/ true);
        }
        else {
            finallyBlock = factory.createBlock([
                factory.createExpressionStatement(emitHelpers().createDisposeResourcesHelper(envBinding)),
            ], /*multiLine*/ true);
        }
        const tryStatement = factory.createTryStatement(tryBlock, catchClause, finallyBlock);
        statements.push(tryStatement);
        return statements;
    }
}
function countPrologueStatements(statements) {
    for (let i = 0; i < statements.length; i++) {
        if (!(0, ts_js_1.isPrologueDirective)(statements[i]) && !(0, ts_js_1.isCustomPrologue)(statements[i])) {
            return i;
        }
    }
    return 0;
}
function isUsingVariableDeclarationList(node) {
    return (0, ts_js_1.isVariableDeclarationList)(node) && getUsingKindOfVariableDeclarationList(node) !== 0 /* UsingKind.None */;
}
function getUsingKindOfVariableDeclarationList(node) {
    return (node.flags & 7 /* NodeFlags.BlockScoped */) === 6 /* NodeFlags.AwaitUsing */ ? 2 /* UsingKind.Async */ :
        (node.flags & 7 /* NodeFlags.BlockScoped */) === 4 /* NodeFlags.Using */ ? 1 /* UsingKind.Sync */ :
            0 /* UsingKind.None */;
}
function getUsingKindOfVariableStatement(node) {
    return getUsingKindOfVariableDeclarationList(node.declarationList);
}
function getUsingKind(statement) {
    return (0, ts_js_1.isVariableStatement)(statement) ? getUsingKindOfVariableStatement(statement) : 0 /* UsingKind.None */;
}
function getUsingKindOfStatements(statements) {
    let result = 0 /* UsingKind.None */;
    for (const statement of statements) {
        const usingKind = getUsingKind(statement);
        if (usingKind === 2 /* UsingKind.Async */)
            return 2 /* UsingKind.Async */;
        if (usingKind > result)
            result = usingKind;
    }
    return result;
}
