"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformESDecorators = transformESDecorators;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function transformESDecorators(context) {
    const { factory, getEmitHelperFactory: emitHelpers, startLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(context.getCompilerOptions());
    let top;
    let classInfo;
    let classThis;
    let classSuper;
    let pendingExpressions;
    let shouldTransformPrivateStaticElementsInFile;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        top = undefined;
        shouldTransformPrivateStaticElementsInFile = false;
        const visited = (0, ts_js_1.visitEachChild)(node, visitor, context);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        if (shouldTransformPrivateStaticElementsInFile) {
            (0, ts_js_1.addInternalEmitFlags)(visited, 32 /* InternalEmitFlags.TransformPrivateStaticElements */);
            shouldTransformPrivateStaticElementsInFile = false;
        }
        return visited;
    }
    function updateState() {
        classInfo = undefined;
        classThis = undefined;
        classSuper = undefined;
        switch (top?.kind) {
            case "class":
                classInfo = top.classInfo;
                break;
            case "class-element":
                classInfo = top.next.classInfo;
                classThis = top.classThis;
                classSuper = top.classSuper;
                break;
            case "name":
                const grandparent = top.next.next.next;
                if (grandparent?.kind === "class-element") {
                    classInfo = grandparent.next.classInfo;
                    classThis = grandparent.classThis;
                    classSuper = grandparent.classSuper;
                }
                break;
        }
    }
    function enterClass(classInfo) {
        top = { kind: "class", next: top, classInfo, savedPendingExpressions: pendingExpressions };
        pendingExpressions = undefined;
        updateState();
    }
    function exitClass() {
        ts_js_1.Debug.assert(top?.kind === "class", "Incorrect value for top.kind.", () => `Expected top.kind to be 'class' but got '${top?.kind}' instead.`);
        pendingExpressions = top.savedPendingExpressions;
        top = top.next;
        updateState();
    }
    function enterClassElement(node) {
        ts_js_1.Debug.assert(top?.kind === "class", "Incorrect value for top.kind.", () => `Expected top.kind to be 'class' but got '${top?.kind}' instead.`);
        top = { kind: "class-element", next: top };
        if ((0, ts_js_1.isClassStaticBlockDeclaration)(node) || (0, ts_js_1.isPropertyDeclaration)(node) && (0, ts_js_1.hasStaticModifier)(node)) {
            top.classThis = top.next.classInfo?.classThis;
            top.classSuper = top.next.classInfo?.classSuper;
        }
        updateState();
    }
    function exitClassElement() {
        ts_js_1.Debug.assert(top?.kind === "class-element", "Incorrect value for top.kind.", () => `Expected top.kind to be 'class-element' but got '${top?.kind}' instead.`);
        ts_js_1.Debug.assert(top.next?.kind === "class", "Incorrect value for top.next.kind.", () => `Expected top.next.kind to be 'class' but got '${top.next?.kind}' instead.`);
        top = top.next;
        updateState();
    }
    function enterName() {
        ts_js_1.Debug.assert(top?.kind === "class-element", "Incorrect value for top.kind.", () => `Expected top.kind to be 'class-element' but got '${top?.kind}' instead.`);
        top = { kind: "name", next: top };
        updateState();
    }
    function exitName() {
        ts_js_1.Debug.assert(top?.kind === "name", "Incorrect value for top.kind.", () => `Expected top.kind to be 'name' but got '${top?.kind}' instead.`);
        top = top.next;
        updateState();
    }
    function enterOther() {
        if (top?.kind === "other") {
            ts_js_1.Debug.assert(!pendingExpressions);
            top.depth++;
        }
        else {
            top = { kind: "other", next: top, depth: 0, savedPendingExpressions: pendingExpressions };
            pendingExpressions = undefined;
            updateState();
        }
    }
    function exitOther() {
        ts_js_1.Debug.assert(top?.kind === "other", "Incorrect value for top.kind.", () => `Expected top.kind to be 'other' but got '${top?.kind}' instead.`);
        if (top.depth > 0) {
            ts_js_1.Debug.assert(!pendingExpressions);
            top.depth--;
        }
        else {
            pendingExpressions = top.savedPendingExpressions;
            top = top.next;
            updateState();
        }
    }
    function shouldVisitNode(node) {
        return !!(node.transformFlags & 33554432 /* TransformFlags.ContainsDecorators */)
            || !!classThis && !!(node.transformFlags & 16384 /* TransformFlags.ContainsLexicalThis */)
            || !!classThis && !!classSuper && !!(node.transformFlags & 134217728 /* TransformFlags.ContainsLexicalSuper */);
    }
    function visitor(node) {
        if (!shouldVisitNode(node)) {
            return node;
        }
        switch (node.kind) {
            case 171 /* SyntaxKind.Decorator */: // elided, will be emitted as part of `visitClassDeclaration`
                return ts_js_1.Debug.fail("Use `modifierVisitor` instead.");
            case 264 /* SyntaxKind.ClassDeclaration */:
                return visitClassDeclaration(node);
            case 232 /* SyntaxKind.ClassExpression */:
                return visitClassExpression(node);
            case 177 /* SyntaxKind.Constructor */:
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return ts_js_1.Debug.fail("Not supported outside of a class. Use 'classElementVisitor' instead.");
            case 170 /* SyntaxKind.Parameter */:
                return visitParameterDeclaration(node);
            // Support NamedEvaluation to ensure the correct class name for class expressions.
            case 227 /* SyntaxKind.BinaryExpression */:
                return visitBinaryExpression(node, /*discarded*/ false);
            case 304 /* SyntaxKind.PropertyAssignment */:
                return visitPropertyAssignment(node);
            case 261 /* SyntaxKind.VariableDeclaration */:
                return visitVariableDeclaration(node);
            case 209 /* SyntaxKind.BindingElement */:
                return visitBindingElement(node);
            case 278 /* SyntaxKind.ExportAssignment */:
                return visitExportAssignment(node);
            case 110 /* SyntaxKind.ThisKeyword */:
                return visitThisExpression(node);
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node);
            case 245 /* SyntaxKind.ExpressionStatement */:
                return visitExpressionStatement(node);
            case 357 /* SyntaxKind.CommaListExpression */:
                return visitCommaListExpression(node, /*discarded*/ false);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                return visitParenthesizedExpression(node, /*discarded*/ false);
            case 356 /* SyntaxKind.PartiallyEmittedExpression */:
                return visitPartiallyEmittedExpression(node, /*discarded*/ false);
            case 214 /* SyntaxKind.CallExpression */:
                return visitCallExpression(node);
            case 216 /* SyntaxKind.TaggedTemplateExpression */:
                return visitTaggedTemplateExpression(node);
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                return visitPreOrPostfixUnaryExpression(node, /*discarded*/ false);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                return visitPropertyAccessExpression(node);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return visitElementAccessExpression(node);
            case 168 /* SyntaxKind.ComputedPropertyName */:
                return visitComputedPropertyName(node);
            case 175 /* SyntaxKind.MethodDeclaration */: // object literal methods and accessors
            case 179 /* SyntaxKind.SetAccessor */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 219 /* SyntaxKind.FunctionExpression */:
            case 263 /* SyntaxKind.FunctionDeclaration */: {
                enterOther();
                const result = (0, ts_js_1.visitEachChild)(node, fallbackVisitor, context);
                exitOther();
                return result;
            }
            default:
                return (0, ts_js_1.visitEachChild)(node, fallbackVisitor, context);
        }
    }
    function fallbackVisitor(node) {
        switch (node.kind) {
            case 171 /* SyntaxKind.Decorator */:
                return undefined;
            default:
                return visitor(node);
        }
    }
    function modifierVisitor(node) {
        switch (node.kind) {
            case 171 /* SyntaxKind.Decorator */: // elided, will be emitted as part of `visitClassDeclaration`
                return undefined;
            default:
                return node;
        }
    }
    function classElementVisitor(node) {
        switch (node.kind) {
            case 177 /* SyntaxKind.Constructor */:
                return visitConstructorDeclaration(node);
            case 175 /* SyntaxKind.MethodDeclaration */:
                return visitMethodDeclaration(node);
            case 178 /* SyntaxKind.GetAccessor */:
                return visitGetAccessorDeclaration(node);
            case 179 /* SyntaxKind.SetAccessor */:
                return visitSetAccessorDeclaration(node);
            case 173 /* SyntaxKind.PropertyDeclaration */:
                return visitPropertyDeclaration(node);
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return visitClassStaticBlockDeclaration(node);
            default:
                return visitor(node);
        }
    }
    function discardedValueVisitor(node) {
        switch (node.kind) {
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                return visitPreOrPostfixUnaryExpression(node, /*discarded*/ true);
            case 227 /* SyntaxKind.BinaryExpression */:
                return visitBinaryExpression(node, /*discarded*/ true);
            case 357 /* SyntaxKind.CommaListExpression */:
                return visitCommaListExpression(node, /*discarded*/ true);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                return visitParenthesizedExpression(node, /*discarded*/ true);
            default:
                return visitor(node);
        }
    }
    function getHelperVariableName(node) {
        let declarationName = node.name && (0, ts_js_1.isIdentifier)(node.name) && !(0, ts_js_1.isGeneratedIdentifier)(node.name) ? (0, ts_js_1.idText)(node.name) :
            node.name && (0, ts_js_1.isPrivateIdentifier)(node.name) && !(0, ts_js_1.isGeneratedIdentifier)(node.name) ? (0, ts_js_1.idText)(node.name).slice(1) :
                node.name && (0, ts_js_1.isStringLiteral)(node.name) && (0, ts_js_1.isIdentifierText)(node.name.text, 99 /* ScriptTarget.ESNext */) ? node.name.text :
                    (0, ts_js_1.isClassLike)(node) ? "class" : "member";
        if ((0, ts_js_1.isGetAccessor)(node))
            declarationName = `get_${declarationName}`;
        if ((0, ts_js_1.isSetAccessor)(node))
            declarationName = `set_${declarationName}`;
        if (node.name && (0, ts_js_1.isPrivateIdentifier)(node.name))
            declarationName = `private_${declarationName}`;
        if ((0, ts_js_1.isStatic)(node))
            declarationName = `static_${declarationName}`;
        return "_" + declarationName;
    }
    function createHelperVariable(node, suffix) {
        return factory.createUniqueName(`${getHelperVariableName(node)}_${suffix}`, 16 /* GeneratedIdentifierFlags.Optimistic */ | 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */);
    }
    function createLet(name, initializer) {
        return factory.createVariableStatement(
        /*modifiers*/ undefined, factory.createVariableDeclarationList([
            factory.createVariableDeclaration(name, 
            /*exclamationToken*/ undefined, 
            /*type*/ undefined, initializer),
        ], 1 /* NodeFlags.Let */));
    }
    function createClassInfo(node) {
        const metadataReference = factory.createUniqueName("_metadata", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
        let instanceMethodExtraInitializersName;
        let staticMethodExtraInitializersName;
        let hasStaticInitializers = false;
        let hasNonAmbientInstanceFields = false;
        let hasStaticPrivateClassElements = false;
        let classThis;
        let pendingStaticInitializers;
        let pendingInstanceInitializers;
        // Before visiting we perform a first pass to collect information we'll need
        // as we descend.
        if ((0, ts_js_1.nodeIsDecorated)(/*useLegacyDecorators*/ false, node)) {
            // We do not mark _classThis as FileLevel if it may be reused by class private fields, which requires the
            // ability access the captured `_classThis` of outer scopes.
            const needsUniqueClassThis = (0, ts_js_1.some)(node.members, member => ((0, ts_js_1.isPrivateIdentifierClassElementDeclaration)(member) || (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member)) && (0, ts_js_1.hasStaticModifier)(member));
            classThis = factory.createUniqueName("_classThis", needsUniqueClassThis ?
                16 /* GeneratedIdentifierFlags.Optimistic */ | 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */ :
                16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
        }
        for (const member of node.members) {
            if ((0, ts_js_1.isMethodOrAccessor)(member) && (0, ts_js_1.nodeOrChildIsDecorated)(/*useLegacyDecorators*/ false, member, node)) {
                if ((0, ts_js_1.hasStaticModifier)(member)) {
                    if (!staticMethodExtraInitializersName) {
                        staticMethodExtraInitializersName = factory.createUniqueName("_staticExtraInitializers", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
                        const initializer = emitHelpers().createRunInitializersHelper(classThis ?? factory.createThis(), staticMethodExtraInitializersName);
                        (0, ts_js_1.setSourceMapRange)(initializer, node.name ?? (0, ts_js_1.moveRangePastDecorators)(node));
                        pendingStaticInitializers ?? (pendingStaticInitializers = []);
                        pendingStaticInitializers.push(initializer);
                    }
                }
                else {
                    if (!instanceMethodExtraInitializersName) {
                        instanceMethodExtraInitializersName = factory.createUniqueName("_instanceExtraInitializers", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
                        const initializer = emitHelpers().createRunInitializersHelper(factory.createThis(), instanceMethodExtraInitializersName);
                        (0, ts_js_1.setSourceMapRange)(initializer, node.name ?? (0, ts_js_1.moveRangePastDecorators)(node));
                        pendingInstanceInitializers ?? (pendingInstanceInitializers = []);
                        pendingInstanceInitializers.push(initializer);
                    }
                    instanceMethodExtraInitializersName ?? (instanceMethodExtraInitializersName = factory.createUniqueName("_instanceExtraInitializers", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */));
                }
            }
            if ((0, ts_js_1.isClassStaticBlockDeclaration)(member)) {
                if (!(0, ts_js_1.isClassNamedEvaluationHelperBlock)(member)) {
                    hasStaticInitializers = true;
                }
            }
            else if ((0, ts_js_1.isPropertyDeclaration)(member)) {
                if ((0, ts_js_1.hasStaticModifier)(member)) {
                    hasStaticInitializers || (hasStaticInitializers = !!member.initializer || (0, ts_js_1.hasDecorators)(member));
                }
                else {
                    hasNonAmbientInstanceFields || (hasNonAmbientInstanceFields = !(0, ts_js_1.isAmbientPropertyDeclaration)(member));
                }
            }
            if (((0, ts_js_1.isPrivateIdentifierClassElementDeclaration)(member) || (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member)) && (0, ts_js_1.hasStaticModifier)(member)) {
                hasStaticPrivateClassElements = true;
            }
            // exit early if possible
            if (staticMethodExtraInitializersName &&
                instanceMethodExtraInitializersName &&
                hasStaticInitializers &&
                hasNonAmbientInstanceFields &&
                hasStaticPrivateClassElements) {
                break;
            }
        }
        return {
            class: node,
            classThis,
            metadataReference,
            instanceMethodExtraInitializersName,
            staticMethodExtraInitializersName,
            hasStaticInitializers,
            hasNonAmbientInstanceFields,
            hasStaticPrivateClassElements,
            pendingStaticInitializers,
            pendingInstanceInitializers,
        };
    }
    function transformClassLike(node) {
        startLexicalEnvironment();
        // When a class has class decorators we end up transforming it into a statement that would otherwise give it an
        // assigned name. If the class doesn't have an assigned name, we'll give it an assigned name of `""`)
        if (!(0, ts_js_1.classHasDeclaredOrExplicitlyAssignedName)(node) && (0, ts_js_1.classOrConstructorParameterIsDecorated)(/*useLegacyDecorators*/ false, node)) {
            node = (0, ts_js_1.injectClassNamedEvaluationHelperBlockIfMissing)(context, node, factory.createStringLiteral(""));
        }
        const classReference = factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ false, /*ignoreAssignedName*/ true);
        const classInfo = createClassInfo(node);
        const classDefinitionStatements = [];
        let leadingBlockStatements;
        let trailingBlockStatements;
        let syntheticConstructor;
        let heritageClauses;
        let shouldTransformPrivateStaticElementsInClass = false;
        // 1. Class decorators are evaluated outside of the private name scope of the class.
        const classDecorators = transformAllDecoratorsOfDeclaration((0, ts_js_1.getAllDecoratorsOfClass)(node, /*useLegacyDecorators*/ false));
        if (classDecorators) {
            // - Since class decorators don't have privileged access to private names defined inside the class,
            //   they must be evaluated outside of the class body.
            // - Since a class decorator can replace the class constructor, we must define a variable to keep track
            //   of the mutated class.
            // - Since a class decorator can add extra initializers, we must define a variable to keep track of
            //   extra initializers.
            classInfo.classDecoratorsName = factory.createUniqueName("_classDecorators", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            classInfo.classDescriptorName = factory.createUniqueName("_classDescriptor", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            classInfo.classExtraInitializersName = factory.createUniqueName("_classExtraInitializers", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            ts_js_1.Debug.assertIsDefined(classInfo.classThis);
            classDefinitionStatements.push(createLet(classInfo.classDecoratorsName, factory.createArrayLiteralExpression(classDecorators)), createLet(classInfo.classDescriptorName), createLet(classInfo.classExtraInitializersName, factory.createArrayLiteralExpression()), createLet(classInfo.classThis));
            if (classInfo.hasStaticPrivateClassElements) {
                shouldTransformPrivateStaticElementsInClass = true;
                shouldTransformPrivateStaticElementsInFile = true;
            }
        }
        // Rewrite `super` in static initializers so that we can use the correct `this`.
        const extendsClause = (0, ts_js_1.getHeritageClause)(node.heritageClauses, 96 /* SyntaxKind.ExtendsKeyword */);
        const extendsElement = extendsClause && (0, ts_js_1.firstOrUndefined)(extendsClause.types);
        const extendsExpression = extendsElement && (0, ts_js_1.visitNode)(extendsElement.expression, visitor, ts_js_1.isExpression);
        if (extendsExpression) {
            classInfo.classSuper = factory.createUniqueName("_classSuper", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            // Ensure we do not give the class or function an assigned name due to the variable by prefixing it
            // with `0, `.
            const unwrapped = (0, ts_js_1.skipOuterExpressions)(extendsExpression);
            const safeExtendsExpression = (0, ts_js_1.isClassExpression)(unwrapped) && !unwrapped.name ||
                (0, ts_js_1.isFunctionExpression)(unwrapped) && !unwrapped.name ||
                (0, ts_js_1.isArrowFunction)(unwrapped) ?
                factory.createComma(factory.createNumericLiteral(0), extendsExpression) :
                extendsExpression;
            classDefinitionStatements.push(createLet(classInfo.classSuper, safeExtendsExpression));
            const updatedExtendsElement = factory.updateExpressionWithTypeArguments(extendsElement, classInfo.classSuper, /*typeArguments*/ undefined);
            const updatedExtendsClause = factory.updateHeritageClause(extendsClause, [updatedExtendsElement]);
            heritageClauses = factory.createNodeArray([updatedExtendsClause]);
        }
        const renamedClassThis = classInfo.classThis ?? factory.createThis();
        // 3. The name of the class is assigned.
        //
        // If the class did not have a name, the caller should have performed injectClassNamedEvaluationHelperBlockIfMissing
        // prior to calling this function if a name was needed.
        // 4. For each member:
        //    a. Member Decorators are evaluated
        //    b. Computed Property Name is evaluated, if present
        // We visit members in two passes:
        // - The first pass visits methods, accessors, and fields to collect decorators and computed property names.
        // - The second pass visits the constructor to add instance initializers.
        //
        // NOTE: If there are no constructors, but there are instance initializers, a synthetic constructor is added.
        enterClass(classInfo);
        leadingBlockStatements = (0, ts_js_1.append)(leadingBlockStatements, createMetadata(classInfo.metadataReference, classInfo.classSuper));
        // Since the constructor can appear anywhere in the class body and its transform depends on other class elements,
        // we must first visit all non-constructor members, then visit the constructor, all while maintaining document order.
        let members = node.members;
        members = (0, ts_js_1.visitNodes)(members, node => (0, ts_js_1.isConstructorDeclaration)(node) ? node : classElementVisitor(node), ts_js_1.isClassElement);
        members = (0, ts_js_1.visitNodes)(members, node => (0, ts_js_1.isConstructorDeclaration)(node) ? classElementVisitor(node) : node, ts_js_1.isClassElement);
        if (pendingExpressions) {
            let outerThis;
            for (let expression of pendingExpressions) {
                // If a pending expression contains a lexical `this`, we'll need to capture the lexical `this` of the
                // container and transform it in the expression. This ensures we use the correct `this` in the resulting
                // class `static` block. We don't use substitution here because the size of the tree we are visiting
                // is likely to be small and doesn't justify the complexity of introducing substitution.
                expression = (0, ts_js_1.visitNode)(expression, function thisVisitor(node) {
                    if (!(node.transformFlags & 16384 /* TransformFlags.ContainsLexicalThis */)) {
                        return node;
                    }
                    switch (node.kind) {
                        case 110 /* SyntaxKind.ThisKeyword */:
                            if (!outerThis) {
                                outerThis = factory.createUniqueName("_outerThis", 16 /* GeneratedIdentifierFlags.Optimistic */);
                                classDefinitionStatements.unshift(createLet(outerThis, factory.createThis()));
                            }
                            return outerThis;
                        default:
                            return (0, ts_js_1.visitEachChild)(node, thisVisitor, context);
                    }
                }, ts_js_1.isExpression);
                const statement = factory.createExpressionStatement(expression);
                leadingBlockStatements = (0, ts_js_1.append)(leadingBlockStatements, statement);
            }
            pendingExpressions = undefined;
        }
        exitClass();
        if ((0, ts_js_1.some)(classInfo.pendingInstanceInitializers) && !(0, ts_js_1.getFirstConstructorWithBody)(node)) {
            const initializerStatements = prepareConstructor(node, classInfo);
            if (initializerStatements) {
                const extendsClauseElement = (0, ts_js_1.getEffectiveBaseTypeNode)(node);
                const isDerivedClass = !!(extendsClauseElement && (0, ts_js_1.skipOuterExpressions)(extendsClauseElement.expression).kind !== 106 /* SyntaxKind.NullKeyword */);
                const constructorStatements = [];
                if (isDerivedClass) {
                    const spreadArguments = factory.createSpreadElement(factory.createIdentifier("arguments"));
                    const superCall = factory.createCallExpression(factory.createSuper(), /*typeArguments*/ undefined, [spreadArguments]);
                    constructorStatements.push(factory.createExpressionStatement(superCall));
                }
                (0, ts_js_1.addRange)(constructorStatements, initializerStatements);
                const constructorBody = factory.createBlock(constructorStatements, /*multiLine*/ true);
                syntheticConstructor = factory.createConstructorDeclaration(/*modifiers*/ undefined, [], constructorBody);
            }
        }
        // Used in class definition steps 5, 7, and 11
        if (classInfo.staticMethodExtraInitializersName) {
            classDefinitionStatements.push(createLet(classInfo.staticMethodExtraInitializersName, factory.createArrayLiteralExpression()));
        }
        // Used in class definition steps 6, 8, and during construction
        if (classInfo.instanceMethodExtraInitializersName) {
            classDefinitionStatements.push(createLet(classInfo.instanceMethodExtraInitializersName, factory.createArrayLiteralExpression()));
        }
        // Used in class definition steps 7, 8, 12, and construction
        if (classInfo.memberInfos) {
            (0, ts_js_1.forEachEntry)(classInfo.memberInfos, (memberInfo, member) => {
                if ((0, ts_js_1.isStatic)(member)) {
                    classDefinitionStatements.push(createLet(memberInfo.memberDecoratorsName));
                    if (memberInfo.memberInitializersName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberInitializersName, factory.createArrayLiteralExpression()));
                    }
                    if (memberInfo.memberExtraInitializersName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberExtraInitializersName, factory.createArrayLiteralExpression()));
                    }
                    if (memberInfo.memberDescriptorName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberDescriptorName));
                    }
                }
            });
        }
        // Used in class definition steps 7, 8, 12, and construction
        if (classInfo.memberInfos) {
            (0, ts_js_1.forEachEntry)(classInfo.memberInfos, (memberInfo, member) => {
                if (!(0, ts_js_1.isStatic)(member)) {
                    classDefinitionStatements.push(createLet(memberInfo.memberDecoratorsName));
                    if (memberInfo.memberInitializersName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberInitializersName, factory.createArrayLiteralExpression()));
                    }
                    if (memberInfo.memberExtraInitializersName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberExtraInitializersName, factory.createArrayLiteralExpression()));
                    }
                    if (memberInfo.memberDescriptorName) {
                        classDefinitionStatements.push(createLet(memberInfo.memberDescriptorName));
                    }
                }
            });
        }
        // 5. Static non-field element decorators are applied
        leadingBlockStatements = (0, ts_js_1.addRange)(leadingBlockStatements, classInfo.staticNonFieldDecorationStatements);
        // 6. Non-static non-field element decorators are applied
        leadingBlockStatements = (0, ts_js_1.addRange)(leadingBlockStatements, classInfo.nonStaticNonFieldDecorationStatements);
        // 7. Static field element decorators are applied
        leadingBlockStatements = (0, ts_js_1.addRange)(leadingBlockStatements, classInfo.staticFieldDecorationStatements);
        // 8. Non-static field element decorators are applied
        leadingBlockStatements = (0, ts_js_1.addRange)(leadingBlockStatements, classInfo.nonStaticFieldDecorationStatements);
        // 9. Class decorators are applied
        // 10. Class binding is initialized
        if (classInfo.classDescriptorName && classInfo.classDecoratorsName && classInfo.classExtraInitializersName && classInfo.classThis) {
            leadingBlockStatements ?? (leadingBlockStatements = []);
            // produces:
            //  __esDecorate(null, _classDescriptor = { value: this }, _classDecorators, { kind: "class", name: this.name, metadata }, _classExtraInitializers);
            const valueProperty = factory.createPropertyAssignment("value", renamedClassThis);
            const classDescriptor = factory.createObjectLiteralExpression([valueProperty]);
            const classDescriptorAssignment = factory.createAssignment(classInfo.classDescriptorName, classDescriptor);
            const classNameReference = factory.createPropertyAccessExpression(renamedClassThis, "name");
            const esDecorateHelper = emitHelpers().createESDecorateHelper(factory.createNull(), classDescriptorAssignment, classInfo.classDecoratorsName, { kind: "class", name: classNameReference, metadata: classInfo.metadataReference }, factory.createNull(), classInfo.classExtraInitializersName);
            const esDecorateStatement = factory.createExpressionStatement(esDecorateHelper);
            (0, ts_js_1.setSourceMapRange)(esDecorateStatement, (0, ts_js_1.moveRangePastDecorators)(node));
            leadingBlockStatements.push(esDecorateStatement);
            // produces:
            //  C = _classThis = _classDescriptor.value;
            const classDescriptorValueReference = factory.createPropertyAccessExpression(classInfo.classDescriptorName, "value");
            const classThisAssignment = factory.createAssignment(classInfo.classThis, classDescriptorValueReference);
            const classReferenceAssignment = factory.createAssignment(classReference, classThisAssignment);
            leadingBlockStatements.push(factory.createExpressionStatement(classReferenceAssignment));
        }
        // produces:
        //  if (metadata) Object.defineProperty(C, Symbol.metadata, { configurable: true, writable: true, value: metadata });
        leadingBlockStatements.push(createSymbolMetadata(renamedClassThis, classInfo.metadataReference));
        // 11. Static extra initializers are evaluated
        // 12. Static fields are initialized (incl. extra initializers) and static blocks are evaluated
        if ((0, ts_js_1.some)(classInfo.pendingStaticInitializers)) {
            for (const initializer of classInfo.pendingStaticInitializers) {
                const initializerStatement = factory.createExpressionStatement(initializer);
                (0, ts_js_1.setSourceMapRange)(initializerStatement, (0, ts_js_1.getSourceMapRange)(initializer));
                trailingBlockStatements = (0, ts_js_1.append)(trailingBlockStatements, initializerStatement);
            }
            classInfo.pendingStaticInitializers = undefined;
        }
        // 13. Class extra initializers are evaluated
        if (classInfo.classExtraInitializersName) {
            const runClassInitializersHelper = emitHelpers().createRunInitializersHelper(renamedClassThis, classInfo.classExtraInitializersName);
            const runClassInitializersStatement = factory.createExpressionStatement(runClassInitializersHelper);
            (0, ts_js_1.setSourceMapRange)(runClassInitializersStatement, node.name ?? (0, ts_js_1.moveRangePastDecorators)(node));
            trailingBlockStatements = (0, ts_js_1.append)(trailingBlockStatements, runClassInitializersStatement);
        }
        // If there are no other static initializers to run, combine the leading and trailing block statements
        if (leadingBlockStatements && trailingBlockStatements && !classInfo.hasStaticInitializers) {
            (0, ts_js_1.addRange)(leadingBlockStatements, trailingBlockStatements);
            trailingBlockStatements = undefined;
        }
        // prepare a leading `static {}` block, if necessary
        //
        // produces:
        //  class C {
        //      static { ... }
        //      ...
        //  }
        const leadingStaticBlock = leadingBlockStatements &&
            factory.createClassStaticBlockDeclaration(factory.createBlock(leadingBlockStatements, /*multiLine*/ true));
        if (leadingStaticBlock && shouldTransformPrivateStaticElementsInClass) {
            // We use `InternalEmitFlags.TransformPrivateStaticElements` as a marker on a class static block
            // to inform the classFields transform that it shouldn't rename `this` to `_classThis` in the
            // transformed class static block.
            (0, ts_js_1.setInternalEmitFlags)(leadingStaticBlock, 32 /* InternalEmitFlags.TransformPrivateStaticElements */);
        }
        // prepare a trailing `static {}` block, if necessary
        //
        // produces:
        //  class C {
        //      ...
        //      static { ... }
        //  }
        const trailingStaticBlock = trailingBlockStatements &&
            factory.createClassStaticBlockDeclaration(factory.createBlock(trailingBlockStatements, /*multiLine*/ true));
        if (leadingStaticBlock || syntheticConstructor || trailingStaticBlock) {
            const newMembers = [];
            // add the NamedEvaluation helper block, if needed
            const existingNamedEvaluationHelperBlockIndex = members.findIndex(ts_js_1.isClassNamedEvaluationHelperBlock);
            // add the leading `static {}` block
            if (leadingStaticBlock) {
                // add the `static {}` block after any existing NamedEvaluation helper block, if one exists.
                (0, ts_js_1.addRange)(newMembers, members, 0, existingNamedEvaluationHelperBlockIndex + 1);
                newMembers.push(leadingStaticBlock);
                (0, ts_js_1.addRange)(newMembers, members, existingNamedEvaluationHelperBlockIndex + 1);
            }
            else {
                (0, ts_js_1.addRange)(newMembers, members);
            }
            // append the synthetic constructor, if necessary
            if (syntheticConstructor) {
                newMembers.push(syntheticConstructor);
            }
            // append a trailing `static {}` block, if necessary
            if (trailingStaticBlock) {
                newMembers.push(trailingStaticBlock);
            }
            members = (0, ts_js_1.setTextRange)(factory.createNodeArray(newMembers), members);
        }
        const lexicalEnvironment = endLexicalEnvironment();
        let classExpression;
        if (classDecorators) {
            // We use `var` instead of `let` so we can leverage NamedEvaluation to define the class name
            // and still be able to ensure it is initialized prior to any use in `static {}`.
            // produces:
            //  (() => {
            //      let _classDecorators = [...];
            //      let _classDescriptor;
            //      let _classExtraInitializers = [];
            //      let _classThis;
            //      ...
            //      var C = class {
            //          static {
            //              __esDecorate(null, _classDescriptor = { value: this }, _classDecorators, ...);
            //              // `C` is initialized here
            //              C = _classThis = _classDescriptor.value;
            //          }
            //          static x = 1;
            //          static y = C.x; // `C` will already be defined here.
            //          static { ... }
            //      };
            //      return C;
            //  })();
            classExpression = factory.createClassExpression(/*modifiers*/ undefined, /*name*/ undefined, /*typeParameters*/ undefined, heritageClauses, members);
            if (classInfo.classThis) {
                classExpression = (0, ts_js_1.injectClassThisAssignmentIfMissing)(factory, classExpression, classInfo.classThis);
            }
            const classReferenceDeclaration = factory.createVariableDeclaration(classReference, /*exclamationToken*/ undefined, /*type*/ undefined, classExpression);
            const classReferenceVarDeclList = factory.createVariableDeclarationList([classReferenceDeclaration]);
            const returnExpr = classInfo.classThis ? factory.createAssignment(classReference, classInfo.classThis) : classReference;
            classDefinitionStatements.push(factory.createVariableStatement(/*modifiers*/ undefined, classReferenceVarDeclList), factory.createReturnStatement(returnExpr));
        }
        else {
            // produces:
            //  return <classExpression>;
            classExpression = factory.createClassExpression(/*modifiers*/ undefined, node.name, /*typeParameters*/ undefined, heritageClauses, members);
            classDefinitionStatements.push(factory.createReturnStatement(classExpression));
        }
        if (shouldTransformPrivateStaticElementsInClass) {
            (0, ts_js_1.addInternalEmitFlags)(classExpression, 32 /* InternalEmitFlags.TransformPrivateStaticElements */);
            for (const member of classExpression.members) {
                if (((0, ts_js_1.isPrivateIdentifierClassElementDeclaration)(member) || (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member)) && (0, ts_js_1.hasStaticModifier)(member)) {
                    (0, ts_js_1.addInternalEmitFlags)(member, 32 /* InternalEmitFlags.TransformPrivateStaticElements */);
                }
            }
        }
        (0, ts_js_1.setOriginalNode)(classExpression, node);
        return factory.createImmediatelyInvokedArrowFunction(factory.mergeLexicalEnvironment(classDefinitionStatements, lexicalEnvironment));
    }
    function isDecoratedClassLike(node) {
        return (0, ts_js_1.classOrConstructorParameterIsDecorated)(/*useLegacyDecorators*/ false, node) ||
            (0, ts_js_1.childIsDecorated)(/*useLegacyDecorators*/ false, node);
    }
    function visitClassDeclaration(node) {
        if (isDecoratedClassLike(node)) {
            const statements = [];
            const originalClass = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isClassLike) ?? node;
            const className = originalClass.name ? factory.createStringLiteralFromNode(originalClass.name) : factory.createStringLiteral("default");
            const isExport = (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
            const isDefault = (0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */);
            if (!node.name) {
                node = (0, ts_js_1.injectClassNamedEvaluationHelperBlockIfMissing)(context, node, className);
            }
            if (isExport && isDefault) {
                const iife = transformClassLike(node);
                if (node.name) {
                    //  let C = (() => { ... })();
                    //  export default C;
                    const varDecl = factory.createVariableDeclaration(factory.getLocalName(node), /*exclamationToken*/ undefined, /*type*/ undefined, iife);
                    (0, ts_js_1.setOriginalNode)(varDecl, node);
                    const varDecls = factory.createVariableDeclarationList([varDecl], 1 /* NodeFlags.Let */);
                    const varStatement = factory.createVariableStatement(/*modifiers*/ undefined, varDecls);
                    statements.push(varStatement);
                    const exportStatement = factory.createExportDefault(factory.getDeclarationName(node));
                    (0, ts_js_1.setOriginalNode)(exportStatement, node);
                    (0, ts_js_1.setCommentRange)(exportStatement, (0, ts_js_1.getCommentRange)(node));
                    (0, ts_js_1.setSourceMapRange)(exportStatement, (0, ts_js_1.moveRangePastDecorators)(node));
                    statements.push(exportStatement);
                }
                else {
                    //  export default (() => { ... })();
                    const exportStatement = factory.createExportDefault(iife);
                    (0, ts_js_1.setOriginalNode)(exportStatement, node);
                    (0, ts_js_1.setCommentRange)(exportStatement, (0, ts_js_1.getCommentRange)(node));
                    (0, ts_js_1.setSourceMapRange)(exportStatement, (0, ts_js_1.moveRangePastDecorators)(node));
                    statements.push(exportStatement);
                }
            }
            else {
                //  let C = (() => { ... })();
                ts_js_1.Debug.assertIsDefined(node.name, "A class declaration that is not a default export must have a name.");
                const iife = transformClassLike(node);
                const modifierVisitorNoExport = isExport ? ((node) => (0, ts_js_1.isExportModifier)(node) ? undefined : modifierVisitor(node)) : modifierVisitor;
                const modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitorNoExport, ts_js_1.isModifier);
                const declName = factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ true);
                const varDecl = factory.createVariableDeclaration(declName, /*exclamationToken*/ undefined, /*type*/ undefined, iife);
                (0, ts_js_1.setOriginalNode)(varDecl, node);
                const varDecls = factory.createVariableDeclarationList([varDecl], 1 /* NodeFlags.Let */);
                const varStatement = factory.createVariableStatement(modifiers, varDecls);
                (0, ts_js_1.setOriginalNode)(varStatement, node);
                (0, ts_js_1.setCommentRange)(varStatement, (0, ts_js_1.getCommentRange)(node));
                statements.push(varStatement);
                if (isExport) {
                    //  export { C };
                    const exportStatement = factory.createExternalModuleExport(declName);
                    (0, ts_js_1.setOriginalNode)(exportStatement, node);
                    statements.push(exportStatement);
                }
            }
            return (0, ts_js_1.singleOrMany)(statements);
        }
        else {
            const modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier);
            const heritageClauses = (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause);
            enterClass(/*classInfo*/ undefined);
            const members = (0, ts_js_1.visitNodes)(node.members, classElementVisitor, ts_js_1.isClassElement);
            exitClass();
            return factory.updateClassDeclaration(node, modifiers, node.name, /*typeParameters*/ undefined, heritageClauses, members);
        }
    }
    function visitClassExpression(node) {
        if (isDecoratedClassLike(node)) {
            const iife = transformClassLike(node);
            (0, ts_js_1.setOriginalNode)(iife, node);
            return iife;
        }
        else {
            const modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier);
            const heritageClauses = (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause);
            enterClass(/*classInfo*/ undefined);
            const members = (0, ts_js_1.visitNodes)(node.members, classElementVisitor, ts_js_1.isClassElement);
            exitClass();
            return factory.updateClassExpression(node, modifiers, node.name, /*typeParameters*/ undefined, heritageClauses, members);
        }
    }
    function prepareConstructor(_parent, classInfo) {
        // Decorated instance members can add "extra" initializers to the instance. If a class contains any instance
        // fields, we'll inject the `__runInitializers()` call for these extra initializers into the initializer of
        // the first class member that will be initialized. However, if the class does not contain any fields that
        // we can piggyback on, we need to synthesize a `__runInitializers()` call in the constructor instead.
        if ((0, ts_js_1.some)(classInfo.pendingInstanceInitializers)) {
            // If there are instance extra initializers we need to add them to the body along with any
            // field initializers
            const statements = [];
            statements.push(factory.createExpressionStatement(factory.inlineExpressions(classInfo.pendingInstanceInitializers)));
            classInfo.pendingInstanceInitializers = undefined;
            return statements;
        }
    }
    function transformConstructorBodyWorker(statementsOut, statementsIn, statementOffset, superPath, superPathDepth, initializerStatements) {
        const superStatementIndex = superPath[superPathDepth];
        const superStatement = statementsIn[superStatementIndex];
        (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, statementOffset, superStatementIndex - statementOffset));
        if ((0, ts_js_1.isTryStatement)(superStatement)) {
            const tryBlockStatements = [];
            transformConstructorBodyWorker(tryBlockStatements, superStatement.tryBlock.statements, 
            /*statementOffset*/ 0, superPath, superPathDepth + 1, initializerStatements);
            const tryBlockStatementsArray = factory.createNodeArray(tryBlockStatements);
            (0, ts_js_1.setTextRange)(tryBlockStatementsArray, superStatement.tryBlock.statements);
            statementsOut.push(factory.updateTryStatement(superStatement, factory.updateBlock(superStatement.tryBlock, tryBlockStatements), (0, ts_js_1.visitNode)(superStatement.catchClause, visitor, ts_js_1.isCatchClause), (0, ts_js_1.visitNode)(superStatement.finallyBlock, visitor, ts_js_1.isBlock)));
        }
        else {
            (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, superStatementIndex, 1));
            (0, ts_js_1.addRange)(statementsOut, initializerStatements);
        }
        (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, superStatementIndex + 1));
    }
    function visitConstructorDeclaration(node) {
        enterClassElement(node);
        const modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier);
        const parameters = (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter);
        let body;
        if (node.body && classInfo) {
            // If there are instance extra initializers we need to add them to the body along with any
            // field initializers
            const initializerStatements = prepareConstructor(classInfo.class, classInfo);
            if (initializerStatements) {
                const statements = [];
                const nonPrologueStart = factory.copyPrologue(node.body.statements, statements, /*ensureUseStrict*/ false, visitor);
                const superStatementIndices = (0, ts_js_1.findSuperStatementIndexPath)(node.body.statements, nonPrologueStart);
                if (superStatementIndices.length > 0) {
                    transformConstructorBodyWorker(statements, node.body.statements, nonPrologueStart, superStatementIndices, 0, initializerStatements);
                }
                else {
                    (0, ts_js_1.addRange)(statements, initializerStatements);
                    (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(node.body.statements, visitor, ts_js_1.isStatement));
                }
                body = factory.createBlock(statements, /*multiLine*/ true);
                (0, ts_js_1.setOriginalNode)(body, node.body);
                (0, ts_js_1.setTextRange)(body, node.body);
            }
        }
        body ?? (body = (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock));
        exitClassElement();
        return factory.updateConstructorDeclaration(node, modifiers, parameters, body);
    }
    function finishClassElement(updated, original) {
        if (updated !== original) {
            // While we emit the source map for the node after skipping decorators and modifiers,
            // we need to emit the comments for the original range.
            (0, ts_js_1.setCommentRange)(updated, original);
            (0, ts_js_1.setSourceMapRange)(updated, (0, ts_js_1.moveRangePastDecorators)(original));
        }
        return updated;
    }
    function partialTransformClassElement(member, classInfo, createDescriptor) {
        let referencedName;
        let name;
        let initializersName;
        let extraInitializersName;
        let thisArg;
        let descriptorName;
        if (!classInfo) {
            const modifiers = (0, ts_js_1.visitNodes)(member.modifiers, modifierVisitor, ts_js_1.isModifier);
            enterName();
            name = visitPropertyName(member.name);
            exitName();
            return { modifiers, referencedName, name, initializersName, descriptorName, thisArg };
        }
        // Member decorators require privileged access to private names. However, computed property
        // evaluation occurs interspersed with decorator evaluation. This means that if we encounter
        // a computed property name we must inline decorator evaluation.
        const memberDecorators = transformAllDecoratorsOfDeclaration((0, ts_js_1.getAllDecoratorsOfClassElement)(member, classInfo.class, /*useLegacyDecorators*/ false));
        const modifiers = (0, ts_js_1.visitNodes)(member.modifiers, modifierVisitor, ts_js_1.isModifier);
        if (memberDecorators) {
            const memberDecoratorsName = createHelperVariable(member, "decorators");
            const memberDecoratorsArray = factory.createArrayLiteralExpression(memberDecorators);
            const memberDecoratorsAssignment = factory.createAssignment(memberDecoratorsName, memberDecoratorsArray);
            const memberInfo = { memberDecoratorsName };
            classInfo.memberInfos ?? (classInfo.memberInfos = new Map());
            classInfo.memberInfos.set(member, memberInfo);
            pendingExpressions ?? (pendingExpressions = []);
            pendingExpressions.push(memberDecoratorsAssignment);
            // 5. Static non-field (method/getter/setter/auto-accessor) element decorators are applied
            // 6. Non-static non-field (method/getter/setter/auto-accessor) element decorators are applied
            // 7. Static field (excl. auto-accessor) element decorators are applied
            // 8. Non-static field (excl. auto-accessor) element decorators are applied
            const statements = (0, ts_js_1.isMethodOrAccessor)(member) || (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member) ?
                (0, ts_js_1.isStatic)(member) ? classInfo.staticNonFieldDecorationStatements ?? (classInfo.staticNonFieldDecorationStatements = []) : classInfo.nonStaticNonFieldDecorationStatements ?? (classInfo.nonStaticNonFieldDecorationStatements = []) :
                (0, ts_js_1.isPropertyDeclaration)(member) && !(0, ts_js_1.isAutoAccessorPropertyDeclaration)(member) ?
                    (0, ts_js_1.isStatic)(member) ? classInfo.staticFieldDecorationStatements ?? (classInfo.staticFieldDecorationStatements = []) : classInfo.nonStaticFieldDecorationStatements ?? (classInfo.nonStaticFieldDecorationStatements = []) :
                    ts_js_1.Debug.fail();
            const kind = (0, ts_js_1.isGetAccessorDeclaration)(member) ? "getter" :
                (0, ts_js_1.isSetAccessorDeclaration)(member) ? "setter" :
                    (0, ts_js_1.isMethodDeclaration)(member) ? "method" :
                        (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member) ? "accessor" :
                            (0, ts_js_1.isPropertyDeclaration)(member) ? "field" :
                                ts_js_1.Debug.fail();
            let propertyName;
            if ((0, ts_js_1.isIdentifier)(member.name) || (0, ts_js_1.isPrivateIdentifier)(member.name)) {
                propertyName = { computed: false, name: member.name };
            }
            else if ((0, ts_js_1.isPropertyNameLiteral)(member.name)) {
                propertyName = { computed: true, name: factory.createStringLiteralFromNode(member.name) };
            }
            else {
                const expression = member.name.expression;
                if ((0, ts_js_1.isPropertyNameLiteral)(expression) && !(0, ts_js_1.isIdentifier)(expression)) {
                    propertyName = { computed: true, name: factory.createStringLiteralFromNode(expression) };
                }
                else {
                    enterName();
                    ({ referencedName, name } = visitReferencedPropertyName(member.name));
                    propertyName = { computed: true, name: referencedName };
                    exitName();
                }
            }
            const context = {
                kind,
                name: propertyName,
                static: (0, ts_js_1.isStatic)(member),
                private: (0, ts_js_1.isPrivateIdentifier)(member.name),
                access: {
                    // 15.7.3 CreateDecoratorAccessObject (kind, name)
                    // 2. If _kind_ is ~field~, ~method~, ~accessor~, or ~getter~, then ...
                    get: (0, ts_js_1.isPropertyDeclaration)(member) || (0, ts_js_1.isGetAccessorDeclaration)(member) || (0, ts_js_1.isMethodDeclaration)(member),
                    // 3. If _kind_ is ~field~, ~accessor~, or ~setter~, then ...
                    set: (0, ts_js_1.isPropertyDeclaration)(member) || (0, ts_js_1.isSetAccessorDeclaration)(member),
                },
                metadata: classInfo.metadataReference,
            };
            if ((0, ts_js_1.isMethodOrAccessor)(member)) {
                // produces (public elements):
                //  __esDecorate(this, null, _static_member_decorators, { kind: "method", name: "...", static: true, private: false, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, null, _member_decorators, { kind: "method", name: "...", static: false, private: false, access: { ... } }, _instanceExtraInitializers);
                //  __esDecorate(this, null, _static_member_decorators, { kind: "getter", name: "...", static: true, private: false, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, null, _member_decorators, { kind: "getter", name: "...", static: false, private: false, access: { ... } }, _instanceExtraInitializers);
                //  __esDecorate(this, null, _static_member_decorators, { kind: "setter", name: "...", static: true, private: false, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, null, _member_decorators, { kind: "setter", name: "...", static: false, private: false, access: { ... } }, _instanceExtraInitializers);
                // produces (private elements):
                //  __esDecorate(this, _static_member_descriptor = { value() { ... } }, _static_member_decorators, { kind: "method", name: "...", static: true, private: true, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, _member_descriptor = { value() { ... } }, _member_decorators, { kind: "method", name: "...", static: false, private: true, access: { ... } }, _instanceExtraInitializers);
                //  __esDecorate(this, _static_member_descriptor = { get() { ... } }, _static_member_decorators, { kind: "getter", name: "...", static: true, private: true, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, _member_descriptor = { get() { ... } }, _member_decorators, { kind: "getter", name: "...", static: false, private: true, access: { ... } }, _instanceExtraInitializers);
                //  __esDecorate(this, _static_member_descriptor = { set() { ... } }, _static_member_decorators, { kind: "setter", name: "...", static: true, private: true, access: { ... } }, _staticExtraInitializers);
                //  __esDecorate(this, _member_descriptor = { set() { ... } }, _member_decorators, { kind: "setter", name: "...", static: false, private: true, access: { ... } }, _instanceExtraInitializers);
                const methodExtraInitializersName = (0, ts_js_1.isStatic)(member) ? classInfo.staticMethodExtraInitializersName : classInfo.instanceMethodExtraInitializersName;
                ts_js_1.Debug.assertIsDefined(methodExtraInitializersName);
                let descriptor;
                if ((0, ts_js_1.isPrivateIdentifierClassElementDeclaration)(member) && createDescriptor) {
                    descriptor = createDescriptor(member, (0, ts_js_1.visitNodes)(modifiers, node => (0, ts_js_1.tryCast)(node, ts_js_1.isAsyncModifier), ts_js_1.isModifier));
                    memberInfo.memberDescriptorName = descriptorName = createHelperVariable(member, "descriptor");
                    descriptor = factory.createAssignment(descriptorName, descriptor);
                }
                const esDecorateExpression = emitHelpers().createESDecorateHelper(factory.createThis(), descriptor ?? factory.createNull(), memberDecoratorsName, context, factory.createNull(), methodExtraInitializersName);
                const esDecorateStatement = factory.createExpressionStatement(esDecorateExpression);
                (0, ts_js_1.setSourceMapRange)(esDecorateStatement, (0, ts_js_1.moveRangePastDecorators)(member));
                statements.push(esDecorateStatement);
            }
            else if ((0, ts_js_1.isPropertyDeclaration)(member)) {
                initializersName = memberInfo.memberInitializersName ?? (memberInfo.memberInitializersName = createHelperVariable(member, "initializers"));
                extraInitializersName = memberInfo.memberExtraInitializersName ?? (memberInfo.memberExtraInitializersName = createHelperVariable(member, "extraInitializers"));
                if ((0, ts_js_1.isStatic)(member)) {
                    thisArg = classInfo.classThis;
                }
                let descriptor;
                if ((0, ts_js_1.isPrivateIdentifierClassElementDeclaration)(member) && (0, ts_js_1.hasAccessorModifier)(member) && createDescriptor) {
                    descriptor = createDescriptor(member, /*modifiers*/ undefined);
                    memberInfo.memberDescriptorName = descriptorName = createHelperVariable(member, "descriptor");
                    descriptor = factory.createAssignment(descriptorName, descriptor);
                }
                // produces:
                //  _static_field_initializers = __esDecorate(null, null, _static_member_decorators, { kind: "field", name: "...", static: true, private: ..., access: { ... } }, _staticExtraInitializers);
                //  _field_initializers = __esDecorate(null, null, _member_decorators, { kind: "field", name: "...", static: false, private: ..., access: { ... } }, _instanceExtraInitializers);
                const esDecorateExpression = emitHelpers().createESDecorateHelper((0, ts_js_1.isAutoAccessorPropertyDeclaration)(member) ?
                    factory.createThis() :
                    factory.createNull(), descriptor ?? factory.createNull(), memberDecoratorsName, context, initializersName, extraInitializersName);
                const esDecorateStatement = factory.createExpressionStatement(esDecorateExpression);
                (0, ts_js_1.setSourceMapRange)(esDecorateStatement, (0, ts_js_1.moveRangePastDecorators)(member));
                statements.push(esDecorateStatement);
            }
        }
        if (name === undefined) {
            enterName();
            name = visitPropertyName(member.name);
            exitName();
        }
        if (!(0, ts_js_1.some)(modifiers) && ((0, ts_js_1.isMethodDeclaration)(member) || (0, ts_js_1.isPropertyDeclaration)(member))) {
            // Don't emit leading comments on the name for methods and properties without modifiers, otherwise we
            // will end up printing duplicate comments.
            (0, ts_js_1.setEmitFlags)(name, 1024 /* EmitFlags.NoLeadingComments */);
        }
        return { modifiers, referencedName, name, initializersName, extraInitializersName, descriptorName, thisArg };
    }
    function visitMethodDeclaration(node) {
        enterClassElement(node);
        const { modifiers, name, descriptorName } = partialTransformClassElement(node, classInfo, createMethodDescriptorObject);
        if (descriptorName) {
            exitClassElement();
            return finishClassElement(createMethodDescriptorForwarder(modifiers, name, descriptorName), node);
        }
        else {
            const parameters = (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter);
            const body = (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock);
            exitClassElement();
            return finishClassElement(factory.updateMethodDeclaration(node, modifiers, node.asteriskToken, name, /*questionToken*/ undefined, /*typeParameters*/ undefined, parameters, /*type*/ undefined, body), node);
        }
    }
    function visitGetAccessorDeclaration(node) {
        enterClassElement(node);
        const { modifiers, name, descriptorName } = partialTransformClassElement(node, classInfo, createGetAccessorDescriptorObject);
        if (descriptorName) {
            exitClassElement();
            return finishClassElement(createGetAccessorDescriptorForwarder(modifiers, name, descriptorName), node);
        }
        else {
            const parameters = (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter);
            const body = (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock);
            exitClassElement();
            return finishClassElement(factory.updateGetAccessorDeclaration(node, modifiers, name, parameters, /*type*/ undefined, body), node);
        }
    }
    function visitSetAccessorDeclaration(node) {
        enterClassElement(node);
        const { modifiers, name, descriptorName } = partialTransformClassElement(node, classInfo, createSetAccessorDescriptorObject);
        if (descriptorName) {
            exitClassElement();
            return finishClassElement(createSetAccessorDescriptorForwarder(modifiers, name, descriptorName), node);
        }
        else {
            const parameters = (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter);
            const body = (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock);
            exitClassElement();
            return finishClassElement(factory.updateSetAccessorDeclaration(node, modifiers, name, parameters, body), node);
        }
    }
    function visitClassStaticBlockDeclaration(node) {
        enterClassElement(node);
        let result;
        if ((0, ts_js_1.isClassNamedEvaluationHelperBlock)(node)) {
            result = (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        else if ((0, ts_js_1.isClassThisAssignmentBlock)(node)) {
            const savedClassThis = classThis;
            classThis = undefined;
            result = (0, ts_js_1.visitEachChild)(node, visitor, context);
            classThis = savedClassThis;
        }
        else {
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
            result = node;
            if (classInfo) {
                classInfo.hasStaticInitializers = true;
                if ((0, ts_js_1.some)(classInfo.pendingStaticInitializers)) {
                    // If we tried to inject the pending initializers into the current block, we might run into
                    // variable name collisions due to sharing this blocks scope. To avoid this, we inject a new
                    // static block that contains the pending initializers that precedes this block.
                    const statements = [];
                    for (const initializer of classInfo.pendingStaticInitializers) {
                        const initializerStatement = factory.createExpressionStatement(initializer);
                        (0, ts_js_1.setSourceMapRange)(initializerStatement, (0, ts_js_1.getSourceMapRange)(initializer));
                        statements.push(initializerStatement);
                    }
                    const body = factory.createBlock(statements, /*multiLine*/ true);
                    const staticBlock = factory.createClassStaticBlockDeclaration(body);
                    result = [staticBlock, result];
                    classInfo.pendingStaticInitializers = undefined;
                }
            }
        }
        exitClassElement();
        return result;
    }
    function visitPropertyDeclaration(node) {
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.initializer));
        }
        enterClassElement(node);
        // TODO(rbuckton): We support decorating `declare x` fields with legacyDecorators, but we currently don't
        //                 support them with esDecorators. We need to consider whether we will support them in the
        //                 future, and how. For now, these should be elided by the `ts` transform.
        ts_js_1.Debug.assert(!(0, ts_js_1.isAmbientPropertyDeclaration)(node), "Not yet implemented.");
        // 10.2.1.3 RS: EvaluateBody
        //   Initializer : `=` AssignmentExpression
        //     ...
        //     3. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true*, then
        //        a. Let _value_ be ? NamedEvaluation of |Initializer| with argument _functionObject_.[[ClassFieldInitializerName]].
        //     ...
        const { modifiers, name, initializersName, extraInitializersName, descriptorName, thisArg } = partialTransformClassElement(node, classInfo, (0, ts_js_1.hasAccessorModifier)(node) ? createAccessorPropertyDescriptorObject : undefined);
        startLexicalEnvironment();
        let initializer = (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression);
        if (initializersName) {
            initializer = emitHelpers().createRunInitializersHelper(thisArg ?? factory.createThis(), initializersName, initializer ?? factory.createVoidZero());
        }
        if ((0, ts_js_1.isStatic)(node) && classInfo && initializer) {
            classInfo.hasStaticInitializers = true;
        }
        const declarations = endLexicalEnvironment();
        if ((0, ts_js_1.some)(declarations)) {
            initializer = factory.createImmediatelyInvokedArrowFunction([
                ...declarations,
                factory.createReturnStatement(initializer),
            ]);
        }
        if (classInfo) {
            if ((0, ts_js_1.isStatic)(node)) {
                initializer = injectPendingInitializers(classInfo, /*isStatic*/ true, initializer);
                if (extraInitializersName) {
                    classInfo.pendingStaticInitializers ?? (classInfo.pendingStaticInitializers = []);
                    classInfo.pendingStaticInitializers.push(emitHelpers().createRunInitializersHelper(classInfo.classThis ?? factory.createThis(), extraInitializersName));
                }
            }
            else {
                initializer = injectPendingInitializers(classInfo, /*isStatic*/ false, initializer);
                if (extraInitializersName) {
                    classInfo.pendingInstanceInitializers ?? (classInfo.pendingInstanceInitializers = []);
                    classInfo.pendingInstanceInitializers.push(emitHelpers().createRunInitializersHelper(factory.createThis(), extraInitializersName));
                }
            }
        }
        exitClassElement();
        if ((0, ts_js_1.hasAccessorModifier)(node) && descriptorName) {
            // given:
            //  accessor #x = 1;
            //
            // emits:
            //  static {
            //      _esDecorate(null, _private_x_descriptor = { get() { return this.#x_1; }, set(value) { this.#x_1 = value; } }, ...)
            //  }
            //  ...
            //  #x_1 = 1;
            //  get #x() { return _private_x_descriptor.get.call(this); }
            //  set #x(value) { _private_x_descriptor.set.call(this, value); }
            const commentRange = (0, ts_js_1.getCommentRange)(node);
            const sourceMapRange = (0, ts_js_1.getSourceMapRange)(node);
            // Since we're creating two declarations where there was previously one, cache
            // the expression for any computed property names.
            const name = node.name;
            let getterName = name;
            let setterName = name;
            if ((0, ts_js_1.isComputedPropertyName)(name) && !(0, ts_js_1.isSimpleInlineableExpression)(name.expression)) {
                const cacheAssignment = (0, ts_js_1.findComputedPropertyNameCacheAssignment)(name);
                if (cacheAssignment) {
                    getterName = factory.updateComputedPropertyName(name, (0, ts_js_1.visitNode)(name.expression, visitor, ts_js_1.isExpression));
                    setterName = factory.updateComputedPropertyName(name, cacheAssignment.left);
                }
                else {
                    const temp = factory.createTempVariable(hoistVariableDeclaration);
                    (0, ts_js_1.setSourceMapRange)(temp, name.expression);
                    const expression = (0, ts_js_1.visitNode)(name.expression, visitor, ts_js_1.isExpression);
                    const assignment = factory.createAssignment(temp, expression);
                    (0, ts_js_1.setSourceMapRange)(assignment, name.expression);
                    getterName = factory.updateComputedPropertyName(name, assignment);
                    setterName = factory.updateComputedPropertyName(name, temp);
                }
            }
            const modifiersWithoutAccessor = (0, ts_js_1.visitNodes)(modifiers, node => node.kind !== 129 /* SyntaxKind.AccessorKeyword */ ? node : undefined, ts_js_1.isModifier);
            const backingField = (0, ts_js_1.createAccessorPropertyBackingField)(factory, node, modifiersWithoutAccessor, initializer);
            (0, ts_js_1.setOriginalNode)(backingField, node);
            (0, ts_js_1.setEmitFlags)(backingField, 3072 /* EmitFlags.NoComments */);
            (0, ts_js_1.setSourceMapRange)(backingField, sourceMapRange);
            (0, ts_js_1.setSourceMapRange)(backingField.name, node.name);
            const getter = createGetAccessorDescriptorForwarder(modifiersWithoutAccessor, getterName, descriptorName);
            (0, ts_js_1.setOriginalNode)(getter, node);
            (0, ts_js_1.setCommentRange)(getter, commentRange);
            (0, ts_js_1.setSourceMapRange)(getter, sourceMapRange);
            const setter = createSetAccessorDescriptorForwarder(modifiersWithoutAccessor, setterName, descriptorName);
            (0, ts_js_1.setOriginalNode)(setter, node);
            (0, ts_js_1.setEmitFlags)(setter, 3072 /* EmitFlags.NoComments */);
            (0, ts_js_1.setSourceMapRange)(setter, sourceMapRange);
            return [backingField, getter, setter];
        }
        return finishClassElement(factory.updatePropertyDeclaration(node, modifiers, name, /*questionOrExclamationToken*/ undefined, /*type*/ undefined, initializer), node);
    }
    function visitThisExpression(node) {
        return classThis ?? node;
    }
    function visitCallExpression(node) {
        if ((0, ts_js_1.isSuperProperty)(node.expression) && classThis) {
            const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
            const argumentsList = (0, ts_js_1.visitNodes)(node.arguments, visitor, ts_js_1.isExpression);
            const invocation = factory.createFunctionCallCall(expression, classThis, argumentsList);
            (0, ts_js_1.setOriginalNode)(invocation, node);
            (0, ts_js_1.setTextRange)(invocation, node);
            return invocation;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitTaggedTemplateExpression(node) {
        if ((0, ts_js_1.isSuperProperty)(node.tag) && classThis) {
            const tag = (0, ts_js_1.visitNode)(node.tag, visitor, ts_js_1.isExpression);
            const boundTag = factory.createFunctionBindCall(tag, classThis, []);
            (0, ts_js_1.setOriginalNode)(boundTag, node);
            (0, ts_js_1.setTextRange)(boundTag, node);
            const template = (0, ts_js_1.visitNode)(node.template, visitor, ts_js_1.isTemplateLiteral);
            return factory.updateTaggedTemplateExpression(node, boundTag, /*typeArguments*/ undefined, template);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitPropertyAccessExpression(node) {
        if ((0, ts_js_1.isSuperProperty)(node) && (0, ts_js_1.isIdentifier)(node.name) && classThis && classSuper) {
            const propertyName = factory.createStringLiteralFromNode(node.name);
            const superProperty = factory.createReflectGetCall(classSuper, propertyName, classThis);
            (0, ts_js_1.setOriginalNode)(superProperty, node.expression);
            (0, ts_js_1.setTextRange)(superProperty, node.expression);
            return superProperty;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitElementAccessExpression(node) {
        if ((0, ts_js_1.isSuperProperty)(node) && classThis && classSuper) {
            const propertyName = (0, ts_js_1.visitNode)(node.argumentExpression, visitor, ts_js_1.isExpression);
            const superProperty = factory.createReflectGetCall(classSuper, propertyName, classThis);
            (0, ts_js_1.setOriginalNode)(superProperty, node.expression);
            (0, ts_js_1.setTextRange)(superProperty, node.expression);
            return superProperty;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitParameterDeclaration(node) {
        // 8.6.3 RS: IteratorBindingInitialization
        //   SingleNameBinding : BindingIdentifier Initializer?
        //     ...
        //     5. If |Initializer| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //           i. Set _v_ to ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        //
        // 14.3.3.3 RS: KeyedBindingInitialization
        //   SingleNameBinding : BindingIdentifier Initializer?
        //     ...
        //     4. If |Initializer| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //           i. Set _v_ to ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.initializer));
        }
        const updated = factory.updateParameterDeclaration(node, 
        /*modifiers*/ undefined, node.dotDotDotToken, (0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isBindingName), 
        /*questionToken*/ undefined, 
        /*type*/ undefined, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression));
        if (updated !== node) {
            // While we emit the source map for the node after skipping decorators and modifiers,
            // we need to emit the comments for the original range.
            (0, ts_js_1.setCommentRange)(updated, node);
            (0, ts_js_1.setTextRange)(updated, (0, ts_js_1.moveRangePastModifiers)(node));
            (0, ts_js_1.setSourceMapRange)(updated, (0, ts_js_1.moveRangePastModifiers)(node));
            (0, ts_js_1.setEmitFlags)(updated.name, 64 /* EmitFlags.NoTrailingSourceMap */);
        }
        return updated;
    }
    function isAnonymousClassNeedingAssignedName(node) {
        return (0, ts_js_1.isClassExpression)(node) && !node.name && isDecoratedClassLike(node);
    }
    function canIgnoreEmptyStringLiteralInAssignedName(node) {
        // The IIFE produced for `(@dec class {})` will result in an assigned name of the form
        // `var class_1 = class { };`, and thus the empty string cannot be ignored. However, The IIFE
        // produced for `(class { @dec x; })` will not result in an assigned name since it
        // transforms to `return class { };`, and thus the empty string *can* be ignored.
        const innerExpression = (0, ts_js_1.skipOuterExpressions)(node);
        return (0, ts_js_1.isClassExpression)(innerExpression) && !innerExpression.name && !(0, ts_js_1.classOrConstructorParameterIsDecorated)(/*useLegacyDecorators*/ false, innerExpression);
    }
    function visitForStatement(node) {
        return factory.updateForStatement(node, (0, ts_js_1.visitNode)(node.initializer, discardedValueVisitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, discardedValueVisitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, visitor, context));
    }
    function visitExpressionStatement(node) {
        return (0, ts_js_1.visitEachChild)(node, discardedValueVisitor, context);
    }
    function visitBinaryExpression(node, discarded) {
        if ((0, ts_js_1.isDestructuringAssignment)(node)) {
            const left = visitAssignmentPattern(node.left);
            const right = (0, ts_js_1.visitNode)(node.right, visitor, ts_js_1.isExpression);
            return factory.updateBinaryExpression(node, left, node.operatorToken, right);
        }
        if ((0, ts_js_1.isAssignmentExpression)(node)) {
            // 13.15.2 RS: Evaluation
            //   AssignmentExpression : LeftHandSideExpression `=` AssignmentExpression
            //     1. If |LeftHandSideExpression| is neither an |ObjectLiteral| nor an |ArrayLiteral|, then
            //        a. Let _lref_ be ? Evaluation of |LeftHandSideExpression|.
            //        b. If IsAnonymousFunctionDefinition(|AssignmentExpression|) and IsIdentifierRef of |LeftHandSideExpression| are both *true*, then
            //           i. Let _rval_ be ? NamedEvaluation of |AssignmentExpression| with argument _lref_.[[ReferencedName]].
            //     ...
            //
            //   AssignmentExpression : LeftHandSideExpression `&&=` AssignmentExpression
            //     ...
            //     5. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true* and IsIdentifierRef of |LeftHandSideExpression| is *true*, then
            //        a. Let _rval_ be ? NamedEvaluation of |AssignmentExpression| with argument _lref_.[[ReferencedName]].
            //     ...
            //
            //   AssignmentExpression : LeftHandSideExpression `||=` AssignmentExpression
            //     ...
            //     5. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true* and IsIdentifierRef of |LeftHandSideExpression| is *true*, then
            //        a. Let _rval_ be ? NamedEvaluation of |AssignmentExpression| with argument _lref_.[[ReferencedName]].
            //     ...
            //
            //   AssignmentExpression : LeftHandSideExpression `??=` AssignmentExpression
            //     ...
            //     4. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true* and IsIdentifierRef of |LeftHandSideExpression| is *true*, then
            //        a. Let _rval_ be ? NamedEvaluation of |AssignmentExpression| with argument _lref_.[[ReferencedName]].
            //     ...
            if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
                node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.right));
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            }
            if ((0, ts_js_1.isSuperProperty)(node.left) && classThis && classSuper) {
                let setterName = (0, ts_js_1.isElementAccessExpression)(node.left) ? (0, ts_js_1.visitNode)(node.left.argumentExpression, visitor, ts_js_1.isExpression) :
                    (0, ts_js_1.isIdentifier)(node.left.name) ? factory.createStringLiteralFromNode(node.left.name) :
                        undefined;
                if (setterName) {
                    // super.x = ...
                    // super.x += ...
                    // super[x] = ...
                    // super[x] += ...
                    let expression = (0, ts_js_1.visitNode)(node.right, visitor, ts_js_1.isExpression);
                    if ((0, ts_js_1.isCompoundAssignment)(node.operatorToken.kind)) {
                        let getterName = setterName;
                        if (!(0, ts_js_1.isSimpleInlineableExpression)(setterName)) {
                            getterName = factory.createTempVariable(hoistVariableDeclaration);
                            setterName = factory.createAssignment(getterName, setterName);
                        }
                        const superPropertyGet = factory.createReflectGetCall(classSuper, getterName, classThis);
                        (0, ts_js_1.setOriginalNode)(superPropertyGet, node.left);
                        (0, ts_js_1.setTextRange)(superPropertyGet, node.left);
                        expression = factory.createBinaryExpression(superPropertyGet, (0, ts_js_1.getNonAssignmentOperatorForCompoundAssignment)(node.operatorToken.kind), expression);
                        (0, ts_js_1.setTextRange)(expression, node);
                    }
                    const temp = discarded ? undefined : factory.createTempVariable(hoistVariableDeclaration);
                    if (temp) {
                        expression = factory.createAssignment(temp, expression);
                        (0, ts_js_1.setTextRange)(temp, node);
                    }
                    expression = factory.createReflectSetCall(classSuper, setterName, expression, classThis);
                    (0, ts_js_1.setOriginalNode)(expression, node);
                    (0, ts_js_1.setTextRange)(expression, node);
                    if (temp) {
                        expression = factory.createComma(expression, temp);
                        (0, ts_js_1.setTextRange)(expression, node);
                    }
                    return expression;
                }
            }
        }
        if (node.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
            const left = (0, ts_js_1.visitNode)(node.left, discardedValueVisitor, ts_js_1.isExpression);
            const right = (0, ts_js_1.visitNode)(node.right, discarded ? discardedValueVisitor : visitor, ts_js_1.isExpression);
            return factory.updateBinaryExpression(node, left, node.operatorToken, right);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitPreOrPostfixUnaryExpression(node, discarded) {
        if (node.operator === 46 /* SyntaxKind.PlusPlusToken */ ||
            node.operator === 47 /* SyntaxKind.MinusMinusToken */) {
            const operand = (0, ts_js_1.skipParentheses)(node.operand);
            if ((0, ts_js_1.isSuperProperty)(operand) && classThis && classSuper) {
                let setterName = (0, ts_js_1.isElementAccessExpression)(operand) ? (0, ts_js_1.visitNode)(operand.argumentExpression, visitor, ts_js_1.isExpression) :
                    (0, ts_js_1.isIdentifier)(operand.name) ? factory.createStringLiteralFromNode(operand.name) :
                        undefined;
                if (setterName) {
                    let getterName = setterName;
                    if (!(0, ts_js_1.isSimpleInlineableExpression)(setterName)) {
                        getterName = factory.createTempVariable(hoistVariableDeclaration);
                        setterName = factory.createAssignment(getterName, setterName);
                    }
                    let expression = factory.createReflectGetCall(classSuper, getterName, classThis);
                    (0, ts_js_1.setOriginalNode)(expression, node);
                    (0, ts_js_1.setTextRange)(expression, node);
                    // If the result of this expression is discarded (i.e., it's in a position where the result
                    // will be otherwise unused, such as in an expression statement or the left side of a comma), we
                    // don't need to create an extra temp variable to hold the result:
                    //
                    //  source (discarded):
                    //    super.x++;
                    //  generated:
                    //    _a = Reflect.get(_super, "x"), _a++, Reflect.set(_super, "x", _a);
                    //
                    // Above, the temp variable `_a` is used to perform the correct coercion (i.e., number or
                    // bigint). Since the result of the postfix unary is discarded, we don't need to capture the
                    // result of the expression.
                    //
                    //  source (not discarded):
                    //    y = super.x++;
                    //  generated:
                    //    y = (_a = Reflect.get(_super, "x"), _b = _a++, Reflect.set(_super, "x", _a), _b);
                    //
                    // When the result isn't discarded, we introduce a new temp variable (`_b`) to capture the
                    // result of the operation so that we can provide it to `y` when the assignment is complete.
                    const temp = discarded ? undefined : factory.createTempVariable(hoistVariableDeclaration);
                    expression = (0, ts_js_1.expandPreOrPostfixIncrementOrDecrementExpression)(factory, node, expression, hoistVariableDeclaration, temp);
                    expression = factory.createReflectSetCall(classSuper, setterName, expression, classThis);
                    (0, ts_js_1.setOriginalNode)(expression, node);
                    (0, ts_js_1.setTextRange)(expression, node);
                    if (temp) {
                        expression = factory.createComma(expression, temp);
                        (0, ts_js_1.setTextRange)(expression, node);
                    }
                    return expression;
                }
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitCommaListExpression(node, discarded) {
        const elements = discarded ?
            (0, ts_js_1.visitCommaListElements)(node.elements, discardedValueVisitor) :
            (0, ts_js_1.visitCommaListElements)(node.elements, visitor, discardedValueVisitor);
        return factory.updateCommaListExpression(node, elements);
    }
    function visitReferencedPropertyName(node) {
        if ((0, ts_js_1.isPropertyNameLiteral)(node) || (0, ts_js_1.isPrivateIdentifier)(node)) {
            const referencedName = factory.createStringLiteralFromNode(node);
            const name = (0, ts_js_1.visitNode)(node, visitor, ts_js_1.isPropertyName);
            return { referencedName, name };
        }
        if ((0, ts_js_1.isPropertyNameLiteral)(node.expression) && !(0, ts_js_1.isIdentifier)(node.expression)) {
            const referencedName = factory.createStringLiteralFromNode(node.expression);
            const name = (0, ts_js_1.visitNode)(node, visitor, ts_js_1.isPropertyName);
            return { referencedName, name };
        }
        const referencedName = factory.getGeneratedNameForNode(node);
        hoistVariableDeclaration(referencedName);
        const key = emitHelpers().createPropKeyHelper((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression));
        const assignment = factory.createAssignment(referencedName, key);
        const name = factory.updateComputedPropertyName(node, injectPendingExpressions(assignment));
        return { referencedName, name };
    }
    function visitPropertyName(node) {
        if ((0, ts_js_1.isComputedPropertyName)(node)) {
            return visitComputedPropertyName(node);
        }
        return (0, ts_js_1.visitNode)(node, visitor, ts_js_1.isPropertyName);
    }
    function visitComputedPropertyName(node) {
        let expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        if (!(0, ts_js_1.isSimpleInlineableExpression)(expression)) {
            expression = injectPendingExpressions(expression);
        }
        return factory.updateComputedPropertyName(node, expression);
    }
    function visitPropertyAssignment(node) {
        // 13.2.5.5 RS: PropertyDefinitionEvaluation
        //   PropertyAssignment : PropertyName `:` AssignmentExpression
        //     ...
        //     5. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true* and _isProtoSetter_ is *false*, then
        //        a. Let _popValue_ be ? NamedEvaluation of |AssignmentExpression| with argument _propKey_.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.initializer));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitVariableDeclaration(node) {
        // 14.3.1.2 RS: Evaluation
        //   LexicalBinding : BindingIdentifier Initializer
        //     ...
        //     3. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //        a. Let _value_ be ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        //
        // 14.3.2.1 RS: Evaluation
        //   VariableDeclaration : BindingIdentifier Initializer
        //     ...
        //     3. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //        a. Let _value_ be ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.initializer));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitBindingElement(node) {
        // 8.6.3 RS: IteratorBindingInitialization
        //   SingleNameBinding : BindingIdentifier Initializer?
        //     ...
        //     5. If |Initializer| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //           i. Set _v_ to ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        //
        // 14.3.3.3 RS: KeyedBindingInitialization
        //   SingleNameBinding : BindingIdentifier Initializer?
        //     ...
        //     4. If |Initializer| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //           i. Set _v_ to ? NamedEvaluation of |Initializer| with argument _bindingId_.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.initializer));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitDestructuringAssignmentTarget(node) {
        if ((0, ts_js_1.isObjectLiteralExpression)(node) || (0, ts_js_1.isArrayLiteralExpression)(node)) {
            return visitAssignmentPattern(node);
        }
        if ((0, ts_js_1.isSuperProperty)(node) && classThis && classSuper) {
            const propertyName = (0, ts_js_1.isElementAccessExpression)(node) ? (0, ts_js_1.visitNode)(node.argumentExpression, visitor, ts_js_1.isExpression) :
                (0, ts_js_1.isIdentifier)(node.name) ? factory.createStringLiteralFromNode(node.name) :
                    undefined;
            if (propertyName) {
                const paramName = factory.createTempVariable(/*recordTempVariable*/ undefined);
                const expression = factory.createAssignmentTargetWrapper(paramName, factory.createReflectSetCall(classSuper, propertyName, paramName, classThis));
                (0, ts_js_1.setOriginalNode)(expression, node);
                (0, ts_js_1.setTextRange)(expression, node);
                return expression;
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitAssignmentElement(node) {
        // 13.15.5.5 RS: IteratorDestructuringAssignmentEvaluation
        //   AssignmentElement : DestructuringAssignmentTarget Initializer?
        //     ...
        //     4. If |Initializer| is present and _value_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) and IsIdentifierRef of |DestructuringAssignmentTarget| are both *true*, then
        //           i. Let _v_ be ? NamedEvaluation of |Initializer| with argument _lref_.[[ReferencedName]].
        //     ...
        if ((0, ts_js_1.isAssignmentExpression)(node, /*excludeCompoundAssignment*/ true)) {
            if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
                node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.right));
            }
            const assignmentTarget = visitDestructuringAssignmentTarget(node.left);
            const initializer = (0, ts_js_1.visitNode)(node.right, visitor, ts_js_1.isExpression);
            return factory.updateBinaryExpression(node, assignmentTarget, node.operatorToken, initializer);
        }
        else {
            return visitDestructuringAssignmentTarget(node);
        }
    }
    function visitAssignmentRestElement(node) {
        if ((0, ts_js_1.isLeftHandSideExpression)(node.expression)) {
            const expression = visitDestructuringAssignmentTarget(node.expression);
            return factory.updateSpreadElement(node, expression);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitArrayAssignmentElement(node) {
        ts_js_1.Debug.assertNode(node, ts_js_1.isArrayBindingOrAssignmentElement);
        if ((0, ts_js_1.isSpreadElement)(node))
            return visitAssignmentRestElement(node);
        if (!(0, ts_js_1.isOmittedExpression)(node))
            return visitAssignmentElement(node);
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitAssignmentProperty(node) {
        // AssignmentProperty : PropertyName `:` AssignmentElement
        // AssignmentElement : DestructuringAssignmentTarget Initializer?
        // 13.15.5.6 RS: KeyedDestructuringAssignmentEvaluation
        //   AssignmentElement : DestructuringAssignmentTarget Initializer?
        //     ...
        //     3. If |Initializer| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousfunctionDefinition(|Initializer|) and IsIdentifierRef of |DestructuringAssignmentTarget| are both *true*, then
        //           i. Let _rhsValue_ be ? NamedEvaluation of |Initializer| with argument _lref_.[[ReferencedName]].
        //     ...
        const name = (0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isPropertyName);
        if ((0, ts_js_1.isAssignmentExpression)(node.initializer, /*excludeCompoundAssignment*/ true)) {
            const assignmentElement = visitAssignmentElement(node.initializer);
            return factory.updatePropertyAssignment(node, name, assignmentElement);
        }
        if ((0, ts_js_1.isLeftHandSideExpression)(node.initializer)) {
            const assignmentElement = visitDestructuringAssignmentTarget(node.initializer);
            return factory.updatePropertyAssignment(node, name, assignmentElement);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitShorthandAssignmentProperty(node) {
        // AssignmentProperty : IdentifierReference Initializer?
        // 13.15.5.3 RS: PropertyDestructuringAssignmentEvaluation
        //   AssignmentProperty : IdentifierReference Initializer?
        //     ...
        //     4. If |Initializer?| is present and _v_ is *undefined*, then
        //        a. If IsAnonymousFunctionDefinition(|Initializer|) is *true*, then
        //           i. Set _v_ to ? NamedEvaluation of |Initializer| with argument _P_.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.objectAssignmentInitializer));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitAssignmentRestProperty(node) {
        if ((0, ts_js_1.isLeftHandSideExpression)(node.expression)) {
            const expression = visitDestructuringAssignmentTarget(node.expression);
            return factory.updateSpreadAssignment(node, expression);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitObjectAssignmentElement(node) {
        ts_js_1.Debug.assertNode(node, ts_js_1.isObjectBindingOrAssignmentElement);
        if ((0, ts_js_1.isSpreadAssignment)(node))
            return visitAssignmentRestProperty(node);
        if ((0, ts_js_1.isShorthandPropertyAssignment)(node))
            return visitShorthandAssignmentProperty(node);
        if ((0, ts_js_1.isPropertyAssignment)(node))
            return visitAssignmentProperty(node);
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitAssignmentPattern(node) {
        if ((0, ts_js_1.isArrayLiteralExpression)(node)) {
            const elements = (0, ts_js_1.visitNodes)(node.elements, visitArrayAssignmentElement, ts_js_1.isExpression);
            return factory.updateArrayLiteralExpression(node, elements);
        }
        else {
            const properties = (0, ts_js_1.visitNodes)(node.properties, visitObjectAssignmentElement, ts_js_1.isObjectLiteralElementLike);
            return factory.updateObjectLiteralExpression(node, properties);
        }
    }
    function visitExportAssignment(node) {
        // 16.2.3.7 RS: Evaluation
        //   ExportDeclaration : `export` `default` AssignmentExpression `;`
        //     1. If IsAnonymousFunctionDefinition(|AssignmentExpression|) is *true*, then
        //        a. Let _value_ be ? NamedEvaluation of |AssignmentExpression| with argument `"default"`.
        //     ...
        if ((0, ts_js_1.isNamedEvaluation)(node, isAnonymousClassNeedingAssignedName)) {
            node = (0, ts_js_1.transformNamedEvaluation)(context, node, canIgnoreEmptyStringLiteralInAssignedName(node.expression));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitParenthesizedExpression(node, discarded) {
        // 8.4.5 RS: NamedEvaluation
        //   ParenthesizedExpression : `(` Expression `)`
        //     ...
        //     2. Return ? NamedEvaluation of |Expression| with argument _name_.
        const visitorFunc = discarded ? discardedValueVisitor : visitor;
        const expression = (0, ts_js_1.visitNode)(node.expression, visitorFunc, ts_js_1.isExpression);
        return factory.updateParenthesizedExpression(node, expression);
    }
    function visitPartiallyEmittedExpression(node, discarded) {
        // Emulates 8.4.5 RS: NamedEvaluation
        const visitorFunc = discarded ? discardedValueVisitor : visitor;
        const expression = (0, ts_js_1.visitNode)(node.expression, visitorFunc, ts_js_1.isExpression);
        return factory.updatePartiallyEmittedExpression(node, expression);
    }
    function injectPendingExpressionsCommon(pendingExpressions, expression) {
        if ((0, ts_js_1.some)(pendingExpressions)) {
            if (expression) {
                if ((0, ts_js_1.isParenthesizedExpression)(expression)) {
                    pendingExpressions.push(expression.expression);
                    expression = factory.updateParenthesizedExpression(expression, factory.inlineExpressions(pendingExpressions));
                }
                else {
                    pendingExpressions.push(expression);
                    expression = factory.inlineExpressions(pendingExpressions);
                }
            }
            else {
                expression = factory.inlineExpressions(pendingExpressions);
            }
        }
        return expression;
    }
    function injectPendingExpressions(expression) {
        const result = injectPendingExpressionsCommon(pendingExpressions, expression);
        ts_js_1.Debug.assertIsDefined(result);
        if (result !== expression) {
            pendingExpressions = undefined;
        }
        return result;
    }
    function injectPendingInitializers(classInfo, isStatic, expression) {
        const result = injectPendingExpressionsCommon(isStatic ? classInfo.pendingStaticInitializers : classInfo.pendingInstanceInitializers, expression);
        if (result !== expression) {
            if (isStatic) {
                classInfo.pendingStaticInitializers = undefined;
            }
            else {
                classInfo.pendingInstanceInitializers = undefined;
            }
        }
        return result;
    }
    /**
     * Transforms all of the decorators for a declaration into an array of expressions.
     *
     * @param allDecorators An object containing all of the decorators for the declaration.
     */
    function transformAllDecoratorsOfDeclaration(allDecorators) {
        if (!allDecorators) {
            return undefined;
        }
        const decoratorExpressions = [];
        (0, ts_js_1.addRange)(decoratorExpressions, (0, ts_js_1.map)(allDecorators.decorators, transformDecorator));
        return decoratorExpressions;
    }
    /**
     * Transforms a decorator into an expression.
     *
     * @param decorator The decorator node.
     */
    function transformDecorator(decorator) {
        const expression = (0, ts_js_1.visitNode)(decorator.expression, visitor, ts_js_1.isExpression);
        (0, ts_js_1.setEmitFlags)(expression, 3072 /* EmitFlags.NoComments */);
        // preserve the 'this' binding for an access expression
        const innerExpression = (0, ts_js_1.skipOuterExpressions)(expression);
        if ((0, ts_js_1.isAccessExpression)(innerExpression)) {
            const { target, thisArg } = factory.createCallBinding(expression, hoistVariableDeclaration, languageVersion, /*cacheIdentifiers*/ true);
            return factory.restoreOuterExpressions(expression, factory.createFunctionBindCall(target, thisArg, []));
        }
        return expression;
    }
    /**
     * Creates a `value`, `get`, or `set` method for a pseudo-{@link PropertyDescriptor} object created for a private element.
     */
    function createDescriptorMethod(original, name, modifiers, asteriskToken, kind, parameters, body) {
        const func = factory.createFunctionExpression(modifiers, asteriskToken, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, parameters, 
        /*type*/ undefined, body ?? factory.createBlock([]));
        (0, ts_js_1.setOriginalNode)(func, original);
        (0, ts_js_1.setSourceMapRange)(func, (0, ts_js_1.moveRangePastDecorators)(original));
        (0, ts_js_1.setEmitFlags)(func, 3072 /* EmitFlags.NoComments */);
        const prefix = kind === "get" || kind === "set" ? kind : undefined;
        const functionName = factory.createStringLiteralFromNode(name, /*isSingleQuote*/ undefined);
        const namedFunction = emitHelpers().createSetFunctionNameHelper(func, functionName, prefix);
        const method = factory.createPropertyAssignment(factory.createIdentifier(kind), namedFunction);
        (0, ts_js_1.setOriginalNode)(method, original);
        (0, ts_js_1.setSourceMapRange)(method, (0, ts_js_1.moveRangePastDecorators)(original));
        (0, ts_js_1.setEmitFlags)(method, 3072 /* EmitFlags.NoComments */);
        return method;
    }
    /**
     * Creates a pseudo-{@link PropertyDescriptor} object used when decorating a private {@link MethodDeclaration}.
     */
    function createMethodDescriptorObject(node, modifiers) {
        return factory.createObjectLiteralExpression([
            createDescriptorMethod(node, node.name, modifiers, node.asteriskToken, "value", (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter), (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock)),
        ]);
    }
    /**
     * Creates a pseudo-{@link PropertyDescriptor} object used when decorating a private {@link GetAccessorDeclaration}.
     */
    function createGetAccessorDescriptorObject(node, modifiers) {
        return factory.createObjectLiteralExpression([
            createDescriptorMethod(node, node.name, modifiers, 
            /*asteriskToken*/ undefined, "get", [], (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock)),
        ]);
    }
    /**
     * Creates a pseudo-{@link PropertyDescriptor} object used when decorating a private {@link SetAccessorDeclaration}.
     */
    function createSetAccessorDescriptorObject(node, modifiers) {
        return factory.createObjectLiteralExpression([
            createDescriptorMethod(node, node.name, modifiers, 
            /*asteriskToken*/ undefined, "set", (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter), (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock)),
        ]);
    }
    /**
     * Creates a pseudo-{@link PropertyDescriptor} object used when decorating an `accessor` {@link PropertyDeclaration} with a private name.
     */
    function createAccessorPropertyDescriptorObject(node, modifiers) {
        //  {
        //      get() { return this.${privateName}; },
        //      set(value) { this.${privateName} = value; },
        //  }
        return factory.createObjectLiteralExpression([
            createDescriptorMethod(node, node.name, modifiers, 
            /*asteriskToken*/ undefined, "get", [], factory.createBlock([
                factory.createReturnStatement(factory.createPropertyAccessExpression(factory.createThis(), factory.getGeneratedPrivateNameForNode(node.name))),
            ])),
            createDescriptorMethod(node, node.name, modifiers, 
            /*asteriskToken*/ undefined, "set", [factory.createParameterDeclaration(
                /*modifiers*/ undefined, 
                /*dotDotDotToken*/ undefined, "value")], factory.createBlock([
                factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(factory.createThis(), factory.getGeneratedPrivateNameForNode(node.name)), factory.createIdentifier("value"))),
            ])),
        ]);
    }
    /**
     * Creates a {@link MethodDeclaration} that forwards its invocation to a {@link PropertyDescriptor} object.
     * @param modifiers The modifiers for the resulting declaration.
     * @param name The name for the resulting declaration.
     * @param descriptorName The name of the descriptor variable.
     */
    function createMethodDescriptorForwarder(modifiers, name, descriptorName) {
        // strip off all but the `static` modifier
        modifiers = (0, ts_js_1.visitNodes)(modifiers, node => (0, ts_js_1.isStaticModifier)(node) ? node : undefined, ts_js_1.isModifier);
        return factory.createGetAccessorDeclaration(modifiers, name, [], 
        /*type*/ undefined, factory.createBlock([
            factory.createReturnStatement(factory.createPropertyAccessExpression(descriptorName, factory.createIdentifier("value"))),
        ]));
    }
    /**
     * Creates a {@link GetAccessorDeclaration} that forwards its invocation to a {@link PropertyDescriptor} object.
     * @param modifiers The modifiers for the resulting declaration.
     * @param name The name for the resulting declaration.
     * @param descriptorName The name of the descriptor variable.
     */
    function createGetAccessorDescriptorForwarder(modifiers, name, descriptorName) {
        // strip off all but the `static` modifier
        modifiers = (0, ts_js_1.visitNodes)(modifiers, node => (0, ts_js_1.isStaticModifier)(node) ? node : undefined, ts_js_1.isModifier);
        return factory.createGetAccessorDeclaration(modifiers, name, [], 
        /*type*/ undefined, factory.createBlock([
            factory.createReturnStatement(factory.createFunctionCallCall(factory.createPropertyAccessExpression(descriptorName, factory.createIdentifier("get")), factory.createThis(), [])),
        ]));
    }
    /**
     * Creates a {@link SetAccessorDeclaration} that forwards its invocation to a {@link PropertyDescriptor} object.
     * @param modifiers The modifiers for the resulting declaration.
     * @param name The name for the resulting declaration.
     * @param descriptorName The name of the descriptor variable.
     */
    function createSetAccessorDescriptorForwarder(modifiers, name, descriptorName) {
        // strip off all but the `static` modifier
        modifiers = (0, ts_js_1.visitNodes)(modifiers, node => (0, ts_js_1.isStaticModifier)(node) ? node : undefined, ts_js_1.isModifier);
        return factory.createSetAccessorDeclaration(modifiers, name, [factory.createParameterDeclaration(
            /*modifiers*/ undefined, 
            /*dotDotDotToken*/ undefined, "value")], factory.createBlock([
            factory.createReturnStatement(factory.createFunctionCallCall(factory.createPropertyAccessExpression(descriptorName, factory.createIdentifier("set")), factory.createThis(), [factory.createIdentifier("value")])),
        ]));
    }
    function createMetadata(name, classSuper) {
        const varDecl = factory.createVariableDeclaration(name, 
        /*exclamationToken*/ undefined, 
        /*type*/ undefined, factory.createConditionalExpression(factory.createLogicalAnd(factory.createTypeCheck(factory.createIdentifier("Symbol"), "function"), factory.createPropertyAccessExpression(factory.createIdentifier("Symbol"), "metadata")), factory.createToken(58 /* SyntaxKind.QuestionToken */), factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("Object"), "create"), 
        /*typeArguments*/ undefined, [classSuper ? createSymbolMetadataReference(classSuper) : factory.createNull()]), factory.createToken(59 /* SyntaxKind.ColonToken */), factory.createVoidZero()));
        return factory.createVariableStatement(/*modifiers*/ undefined, factory.createVariableDeclarationList([varDecl], 2 /* NodeFlags.Const */));
    }
    function createSymbolMetadata(target, value) {
        const defineProperty = factory.createObjectDefinePropertyCall(target, factory.createPropertyAccessExpression(factory.createIdentifier("Symbol"), "metadata"), factory.createPropertyDescriptor({ configurable: true, writable: true, enumerable: true, value }, /*singleLine*/ true));
        return (0, ts_js_1.setEmitFlags)(factory.createIfStatement(value, factory.createExpressionStatement(defineProperty)), 1 /* EmitFlags.SingleLine */);
    }
    function createSymbolMetadataReference(classSuper) {
        return factory.createBinaryExpression(factory.createElementAccessExpression(classSuper, factory.createPropertyAccessExpression(factory.createIdentifier("Symbol"), "metadata")), 61 /* SyntaxKind.QuestionQuestionToken */, factory.createNull());
    }
}
