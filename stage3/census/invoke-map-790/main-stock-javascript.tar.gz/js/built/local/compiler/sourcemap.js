"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.identitySourceMapConsumer = exports.whitespaceOrMapCommentRegExp = exports.sourceMapCommentRegExp = exports.sourceMapCommentRegExpDontCareLineStart = void 0;
exports.createSourceMapGenerator = createSourceMapGenerator;
exports.getLineInfo = getLineInfo;
exports.tryGetSourceMappingURL = tryGetSourceMappingURL;
exports.tryParseRawSourceMap = tryParseRawSourceMap;
exports.decodeMappings = decodeMappings;
exports.sameMapping = sameMapping;
exports.isSourceMapping = isSourceMapping;
exports.createDocumentPositionMapper = createDocumentPositionMapper;
const ts_js_1 = require("./_namespaces/ts.js");
const performance = __importStar(require("./_namespaces/ts.performance.js"));
/** @internal */
function createSourceMapGenerator(host, file, sourceRoot, sourcesDirectoryPath, generatorOptions) {
    // Why var? It avoids TDZ checks in the runtime which can be costly.
    // See: https://github.com/microsoft/TypeScript/issues/52924
    /* eslint-disable no-var */
    var { enter, exit } = generatorOptions.extendedDiagnostics
        ? performance.createTimer("Source Map", "beforeSourcemap", "afterSourcemap")
        : performance.nullTimer;
    // Current source map file and its index in the sources list
    var rawSources = [];
    var sources = [];
    var sourceToSourceIndexMap = new Map();
    var sourcesContent; // eslint-disable-line no-restricted-syntax
    var names = [];
    var nameToNameIndexMap;
    var mappingCharCodes = [];
    var mappings = "";
    // Last recorded and encoded mappings
    var lastGeneratedLine = 0;
    var lastGeneratedCharacter = 0;
    var lastSourceIndex = 0;
    var lastSourceLine = 0;
    var lastSourceCharacter = 0;
    var lastNameIndex = 0;
    var hasLast = false;
    var pendingGeneratedLine = 0;
    var pendingGeneratedCharacter = 0;
    var pendingSourceIndex = 0;
    var pendingSourceLine = 0;
    var pendingSourceCharacter = 0;
    var pendingNameIndex = 0;
    var hasPending = false;
    var hasPendingSource = false;
    var hasPendingName = false;
    /* eslint-enable no-var */
    return {
        getSources: () => rawSources,
        addSource,
        setSourceContent,
        addName,
        addMapping,
        appendSourceMap,
        toJSON,
        toString: () => JSON.stringify(toJSON()),
    };
    function addSource(fileName) {
        enter();
        const source = (0, ts_js_1.getRelativePathToDirectoryOrUrl)(sourcesDirectoryPath, fileName, host.getCurrentDirectory(), host.getCanonicalFileName, /*isAbsolutePathAnUrl*/ true);
        let sourceIndex = sourceToSourceIndexMap.get(source);
        if (sourceIndex === undefined) {
            sourceIndex = sources.length;
            sources.push(source);
            rawSources.push(fileName);
            sourceToSourceIndexMap.set(source, sourceIndex);
        }
        exit();
        return sourceIndex;
    }
    /* eslint-disable no-restricted-syntax */
    function setSourceContent(sourceIndex, content) {
        enter();
        if (content !== null) {
            if (!sourcesContent)
                sourcesContent = [];
            while (sourcesContent.length < sourceIndex) {
                sourcesContent.push(null);
            }
            sourcesContent[sourceIndex] = content;
        }
        exit();
    }
    /* eslint-enable no-restricted-syntax */
    function addName(name) {
        enter();
        if (!nameToNameIndexMap)
            nameToNameIndexMap = new Map();
        let nameIndex = nameToNameIndexMap.get(name);
        if (nameIndex === undefined) {
            nameIndex = names.length;
            names.push(name);
            nameToNameIndexMap.set(name, nameIndex);
        }
        exit();
        return nameIndex;
    }
    function isNewGeneratedPosition(generatedLine, generatedCharacter) {
        return !hasPending
            || pendingGeneratedLine !== generatedLine
            || pendingGeneratedCharacter !== generatedCharacter;
    }
    function isBacktrackingSourcePosition(sourceIndex, sourceLine, sourceCharacter) {
        return sourceIndex !== undefined
            && sourceLine !== undefined
            && sourceCharacter !== undefined
            && pendingSourceIndex === sourceIndex
            && (pendingSourceLine > sourceLine
                || pendingSourceLine === sourceLine && pendingSourceCharacter > sourceCharacter);
    }
    function addMapping(generatedLine, generatedCharacter, sourceIndex, sourceLine, sourceCharacter, nameIndex) {
        ts_js_1.Debug.assert(generatedLine >= pendingGeneratedLine, "generatedLine cannot backtrack");
        ts_js_1.Debug.assert(generatedCharacter >= 0, "generatedCharacter cannot be negative");
        ts_js_1.Debug.assert(sourceIndex === undefined || sourceIndex >= 0, "sourceIndex cannot be negative");
        ts_js_1.Debug.assert(sourceLine === undefined || sourceLine >= 0, "sourceLine cannot be negative");
        ts_js_1.Debug.assert(sourceCharacter === undefined || sourceCharacter >= 0, "sourceCharacter cannot be negative");
        enter();
        // If this location wasn't recorded or the location in source is going backwards, record the mapping
        if (isNewGeneratedPosition(generatedLine, generatedCharacter) ||
            isBacktrackingSourcePosition(sourceIndex, sourceLine, sourceCharacter)) {
            commitPendingMapping();
            pendingGeneratedLine = generatedLine;
            pendingGeneratedCharacter = generatedCharacter;
            hasPendingSource = false;
            hasPendingName = false;
            hasPending = true;
        }
        if (sourceIndex !== undefined && sourceLine !== undefined && sourceCharacter !== undefined) {
            pendingSourceIndex = sourceIndex;
            pendingSourceLine = sourceLine;
            pendingSourceCharacter = sourceCharacter;
            hasPendingSource = true;
            if (nameIndex !== undefined) {
                pendingNameIndex = nameIndex;
                hasPendingName = true;
            }
        }
        exit();
    }
    function appendSourceMap(generatedLine, generatedCharacter, map, sourceMapPath, start, end) {
        ts_js_1.Debug.assert(generatedLine >= pendingGeneratedLine, "generatedLine cannot backtrack");
        ts_js_1.Debug.assert(generatedCharacter >= 0, "generatedCharacter cannot be negative");
        enter();
        // First, decode the old component sourcemap
        const sourceIndexToNewSourceIndexMap = [];
        let nameIndexToNewNameIndexMap;
        const mappingIterator = decodeMappings(map.mappings);
        for (const raw of mappingIterator) {
            if (end && (raw.generatedLine > end.line ||
                (raw.generatedLine === end.line && raw.generatedCharacter > end.character))) {
                break;
            }
            if (start && (raw.generatedLine < start.line ||
                (start.line === raw.generatedLine && raw.generatedCharacter < start.character))) {
                continue;
            }
            // Then reencode all the updated mappings into the overall map
            let newSourceIndex;
            let newSourceLine;
            let newSourceCharacter;
            let newNameIndex;
            if (raw.sourceIndex !== undefined) {
                newSourceIndex = sourceIndexToNewSourceIndexMap[raw.sourceIndex];
                if (newSourceIndex === undefined) {
                    // Apply offsets to each position and fixup source entries
                    const rawPath = map.sources[raw.sourceIndex];
                    const relativePath = map.sourceRoot ? (0, ts_js_1.combinePaths)(map.sourceRoot, rawPath) : rawPath;
                    const combinedPath = (0, ts_js_1.combinePaths)((0, ts_js_1.getDirectoryPath)(sourceMapPath), relativePath);
                    sourceIndexToNewSourceIndexMap[raw.sourceIndex] = newSourceIndex = addSource(combinedPath);
                    if (map.sourcesContent) {
                        const content = map.sourcesContent[raw.sourceIndex];
                        if (typeof content === "string") {
                            setSourceContent(newSourceIndex, content);
                        }
                    }
                }
                newSourceLine = raw.sourceLine;
                newSourceCharacter = raw.sourceCharacter;
                if (map.names && raw.nameIndex !== undefined) {
                    if (!nameIndexToNewNameIndexMap)
                        nameIndexToNewNameIndexMap = [];
                    newNameIndex = nameIndexToNewNameIndexMap[raw.nameIndex];
                    if (newNameIndex === undefined) {
                        nameIndexToNewNameIndexMap[raw.nameIndex] = newNameIndex = addName(map.names[raw.nameIndex]);
                    }
                }
            }
            const rawGeneratedLine = raw.generatedLine - (start ? start.line : 0);
            const newGeneratedLine = rawGeneratedLine + generatedLine;
            const rawGeneratedCharacter = start && start.line === raw.generatedLine ? raw.generatedCharacter - start.character : raw.generatedCharacter;
            const newGeneratedCharacter = rawGeneratedLine === 0 ? rawGeneratedCharacter + generatedCharacter : rawGeneratedCharacter;
            addMapping(newGeneratedLine, newGeneratedCharacter, newSourceIndex, newSourceLine, newSourceCharacter, newNameIndex);
        }
        exit();
    }
    function shouldCommitMapping() {
        return !hasLast
            || lastGeneratedLine !== pendingGeneratedLine
            || lastGeneratedCharacter !== pendingGeneratedCharacter
            || lastSourceIndex !== pendingSourceIndex
            || lastSourceLine !== pendingSourceLine
            || lastSourceCharacter !== pendingSourceCharacter
            || lastNameIndex !== pendingNameIndex;
    }
    function appendMappingCharCode(charCode) {
        mappingCharCodes.push(charCode);
        // String.fromCharCode accepts its arguments on the stack, so we have to chunk the input,
        // otherwise we can get stack overflows for large source maps
        if (mappingCharCodes.length >= 1024) {
            flushMappingBuffer();
        }
    }
    function commitPendingMapping() {
        if (!hasPending || !shouldCommitMapping()) {
            return;
        }
        enter();
        // Line/Comma delimiters
        if (lastGeneratedLine < pendingGeneratedLine) {
            // Emit line delimiters
            do {
                appendMappingCharCode(59 /* CharacterCodes.semicolon */);
                lastGeneratedLine++;
            } while (lastGeneratedLine < pendingGeneratedLine);
            // Only need to set this once
            lastGeneratedCharacter = 0;
        }
        else {
            ts_js_1.Debug.assertEqual(lastGeneratedLine, pendingGeneratedLine, "generatedLine cannot backtrack");
            // Emit comma to separate the entry
            if (hasLast) {
                appendMappingCharCode(44 /* CharacterCodes.comma */);
            }
        }
        // 1. Relative generated character
        appendBase64VLQ(pendingGeneratedCharacter - lastGeneratedCharacter);
        lastGeneratedCharacter = pendingGeneratedCharacter;
        if (hasPendingSource) {
            // 2. Relative sourceIndex
            appendBase64VLQ(pendingSourceIndex - lastSourceIndex);
            lastSourceIndex = pendingSourceIndex;
            // 3. Relative source line
            appendBase64VLQ(pendingSourceLine - lastSourceLine);
            lastSourceLine = pendingSourceLine;
            // 4. Relative source character
            appendBase64VLQ(pendingSourceCharacter - lastSourceCharacter);
            lastSourceCharacter = pendingSourceCharacter;
            if (hasPendingName) {
                // 5. Relative nameIndex
                appendBase64VLQ(pendingNameIndex - lastNameIndex);
                lastNameIndex = pendingNameIndex;
            }
        }
        hasLast = true;
        exit();
    }
    function flushMappingBuffer() {
        if (mappingCharCodes.length > 0) {
            mappings += String.fromCharCode.apply(undefined, mappingCharCodes);
            mappingCharCodes.splice(0);
        }
    }
    function toJSON() {
        commitPendingMapping();
        flushMappingBuffer();
        return {
            version: 3,
            file,
            sourceRoot,
            sources,
            names,
            mappings,
            sourcesContent,
        };
    }
    function appendBase64VLQ(inValue) {
        // Add a new least significant bit that has the sign of the value.
        // if negative number the least significant bit that gets added to the number has value 1
        // else least significant bit value that gets added is 0
        // eg. -1 changes to binary : 01 [1] => 3
        //     +1 changes to binary : 01 [0] => 2
        if (inValue < 0) {
            inValue = ((-inValue) << 1) + 1;
        }
        else {
            inValue = inValue << 1;
        }
        // Encode 5 bits at a time starting from least significant bits
        do {
            let currentDigit = inValue & 31; // 11111
            inValue = inValue >> 5;
            if (inValue > 0) {
                // There are still more digits to decode, set the msb (6th bit)
                currentDigit = currentDigit | 32;
            }
            appendMappingCharCode(base64FormatEncode(currentDigit));
        } while (inValue > 0);
    }
}
// Sometimes tools can see the following line as a source mapping url comment, so we mangle it a bit (the [M])
/** @internal */
exports.sourceMapCommentRegExpDontCareLineStart = /\/\/[@#] source[M]appingURL=(.+)\r?\n?$/; // eslint-disable-line regexp/no-useless-character-class
/** @internal */
exports.sourceMapCommentRegExp = /^\/\/[@#] source[M]appingURL=(.+)\r?\n?$/; // eslint-disable-line regexp/no-useless-character-class
/** @internal */
exports.whitespaceOrMapCommentRegExp = /^\s*(\/\/[@#] .*)?$/;
/** @internal */
function getLineInfo(text, lineStarts) {
    return {
        getLineCount: () => lineStarts.length,
        getLineText: line => text.substring(lineStarts[line], lineStarts[line + 1]),
    };
}
/**
 * Tries to find the sourceMappingURL comment at the end of a file.
 *
 * @internal
 */
function tryGetSourceMappingURL(lineInfo) {
    for (let index = lineInfo.getLineCount() - 1; index >= 0; index--) {
        const line = lineInfo.getLineText(index);
        const comment = exports.sourceMapCommentRegExp.exec(line);
        if (comment) {
            return comment[1].trimEnd();
        }
        // If we see a non-whitespace/map comment-like line, break, to avoid scanning up the entire file
        else if (!line.match(exports.whitespaceOrMapCommentRegExp)) {
            break;
        }
    }
}
/* eslint-disable no-restricted-syntax */
function isStringOrNull(x) {
    return typeof x === "string" || x === null;
}
function isRawSourceMap(x) {
    return x !== null
        && typeof x === "object"
        && x.version === 3
        && typeof x.file === "string"
        && typeof x.mappings === "string"
        && (0, ts_js_1.isArray)(x.sources) && (0, ts_js_1.every)(x.sources, ts_js_1.isString)
        && (x.sourceRoot === undefined || x.sourceRoot === null || typeof x.sourceRoot === "string")
        && (x.sourcesContent === undefined || x.sourcesContent === null || (0, ts_js_1.isArray)(x.sourcesContent) && (0, ts_js_1.every)(x.sourcesContent, isStringOrNull))
        && (x.names === undefined || x.names === null || (0, ts_js_1.isArray)(x.names) && (0, ts_js_1.every)(x.names, ts_js_1.isString));
}
/* eslint-enable no-restricted-syntax */
/** @internal */
function tryParseRawSourceMap(text) {
    try {
        const parsed = JSON.parse(text);
        if (isRawSourceMap(parsed)) {
            return parsed;
        }
    }
    catch {
        // empty
    }
    return undefined;
}
/** @internal */
function decodeMappings(mappings) {
    let done = false;
    let pos = 0;
    let generatedLine = 0;
    let generatedCharacter = 0;
    let sourceIndex = 0;
    let sourceLine = 0;
    let sourceCharacter = 0;
    let nameIndex = 0;
    let error;
    // TODO(jakebailey): can we implement this without writing next ourselves?
    return {
        get pos() {
            return pos;
        },
        get error() {
            return error;
        },
        get state() {
            return captureMapping(/*hasSource*/ true, /*hasName*/ true);
        },
        next() {
            while (!done && pos < mappings.length) {
                const ch = mappings.charCodeAt(pos);
                if (ch === 59 /* CharacterCodes.semicolon */) {
                    // new line
                    generatedLine++;
                    generatedCharacter = 0;
                    pos++;
                    continue;
                }
                if (ch === 44 /* CharacterCodes.comma */) {
                    // Next entry is on same line - no action needed
                    pos++;
                    continue;
                }
                let hasSource = false;
                let hasName = false;
                generatedCharacter += base64VLQFormatDecode();
                if (hasReportedError())
                    return stopIterating();
                if (generatedCharacter < 0)
                    return setErrorAndStopIterating("Invalid generatedCharacter found");
                if (!isSourceMappingSegmentEnd()) {
                    hasSource = true;
                    sourceIndex += base64VLQFormatDecode();
                    if (hasReportedError())
                        return stopIterating();
                    if (sourceIndex < 0)
                        return setErrorAndStopIterating("Invalid sourceIndex found");
                    if (isSourceMappingSegmentEnd())
                        return setErrorAndStopIterating("Unsupported Format: No entries after sourceIndex");
                    sourceLine += base64VLQFormatDecode();
                    if (hasReportedError())
                        return stopIterating();
                    if (sourceLine < 0)
                        return setErrorAndStopIterating("Invalid sourceLine found");
                    if (isSourceMappingSegmentEnd())
                        return setErrorAndStopIterating("Unsupported Format: No entries after sourceLine");
                    sourceCharacter += base64VLQFormatDecode();
                    if (hasReportedError())
                        return stopIterating();
                    if (sourceCharacter < 0)
                        return setErrorAndStopIterating("Invalid sourceCharacter found");
                    if (!isSourceMappingSegmentEnd()) {
                        hasName = true;
                        nameIndex += base64VLQFormatDecode();
                        if (hasReportedError())
                            return stopIterating();
                        if (nameIndex < 0)
                            return setErrorAndStopIterating("Invalid nameIndex found");
                        if (!isSourceMappingSegmentEnd())
                            return setErrorAndStopIterating("Unsupported Error Format: Entries after nameIndex");
                    }
                }
                return { value: captureMapping(hasSource, hasName), done };
            }
            return stopIterating();
        },
        [Symbol.iterator]() {
            return this;
        },
    };
    function captureMapping(hasSource, hasName) {
        return {
            generatedLine,
            generatedCharacter,
            sourceIndex: hasSource ? sourceIndex : undefined,
            sourceLine: hasSource ? sourceLine : undefined,
            sourceCharacter: hasSource ? sourceCharacter : undefined,
            nameIndex: hasName ? nameIndex : undefined,
        };
    }
    function stopIterating() {
        done = true;
        return { value: undefined, done: true };
    }
    function setError(message) {
        if (error === undefined) {
            error = message;
        }
    }
    function setErrorAndStopIterating(message) {
        setError(message);
        return stopIterating();
    }
    function hasReportedError() {
        return error !== undefined;
    }
    function isSourceMappingSegmentEnd() {
        return (pos === mappings.length ||
            mappings.charCodeAt(pos) === 44 /* CharacterCodes.comma */ ||
            mappings.charCodeAt(pos) === 59 /* CharacterCodes.semicolon */);
    }
    function base64VLQFormatDecode() {
        let moreDigits = true;
        let shiftCount = 0;
        let value = 0;
        for (; moreDigits; pos++) {
            if (pos >= mappings.length)
                return setError("Error in decoding base64VLQFormatDecode, past the mapping string"), -1;
            // 6 digit number
            const currentByte = base64FormatDecode(mappings.charCodeAt(pos));
            if (currentByte === -1)
                return setError("Invalid character in VLQ"), -1;
            // If msb is set, we still have more bits to continue
            moreDigits = (currentByte & 32) !== 0;
            // least significant 5 bits are the next msbs in the final value.
            value = value | ((currentByte & 31) << shiftCount);
            shiftCount += 5;
        }
        // Least significant bit if 1 represents negative and rest of the msb is actual absolute value
        if ((value & 1) === 0) {
            // + number
            value = value >> 1;
        }
        else {
            // - number
            value = value >> 1;
            value = -value;
        }
        return value;
    }
}
/** @internal */
function sameMapping(left, right) {
    return left === right
        || left.generatedLine === right.generatedLine
            && left.generatedCharacter === right.generatedCharacter
            && left.sourceIndex === right.sourceIndex
            && left.sourceLine === right.sourceLine
            && left.sourceCharacter === right.sourceCharacter
            && left.nameIndex === right.nameIndex;
}
/** @internal */
function isSourceMapping(mapping) {
    return mapping.sourceIndex !== undefined
        && mapping.sourceLine !== undefined
        && mapping.sourceCharacter !== undefined;
}
function base64FormatEncode(value) {
    return value >= 0 && value < 26 ? 65 /* CharacterCodes.A */ + value :
        value >= 26 && value < 52 ? 97 /* CharacterCodes.a */ + value - 26 :
            value >= 52 && value < 62 ? 48 /* CharacterCodes._0 */ + value - 52 :
                value === 62 ? 43 /* CharacterCodes.plus */ :
                    value === 63 ? 47 /* CharacterCodes.slash */ :
                        ts_js_1.Debug.fail(`${value}: not a base64 value`);
}
function base64FormatDecode(ch) {
    return ch >= 65 /* CharacterCodes.A */ && ch <= 90 /* CharacterCodes.Z */ ? ch - 65 /* CharacterCodes.A */ :
        ch >= 97 /* CharacterCodes.a */ && ch <= 122 /* CharacterCodes.z */ ? ch - 97 /* CharacterCodes.a */ + 26 :
            ch >= 48 /* CharacterCodes._0 */ && ch <= 57 /* CharacterCodes._9 */ ? ch - 48 /* CharacterCodes._0 */ + 52 :
                ch === 43 /* CharacterCodes.plus */ ? 62 :
                    ch === 47 /* CharacterCodes.slash */ ? 63 :
                        -1;
}
function isSourceMappedPosition(value) {
    return value.sourceIndex !== undefined
        && value.sourcePosition !== undefined;
}
function sameMappedPosition(left, right) {
    return left.generatedPosition === right.generatedPosition
        && left.sourceIndex === right.sourceIndex
        && left.sourcePosition === right.sourcePosition;
}
function compareSourcePositions(left, right) {
    // Compares sourcePosition without comparing sourceIndex
    // since the mappings are grouped by sourceIndex
    ts_js_1.Debug.assert(left.sourceIndex === right.sourceIndex);
    return (0, ts_js_1.compareValues)(left.sourcePosition, right.sourcePosition);
}
function compareGeneratedPositions(left, right) {
    return (0, ts_js_1.compareValues)(left.generatedPosition, right.generatedPosition);
}
function getSourcePositionOfMapping(value) {
    return value.sourcePosition;
}
function getGeneratedPositionOfMapping(value) {
    return value.generatedPosition;
}
/** @internal */
function createDocumentPositionMapper(host, map, mapPath) {
    const mapDirectory = (0, ts_js_1.getDirectoryPath)(mapPath);
    const sourceRoot = map.sourceRoot ? (0, ts_js_1.getNormalizedAbsolutePath)(map.sourceRoot, mapDirectory) : mapDirectory;
    const generatedAbsoluteFilePath = (0, ts_js_1.getNormalizedAbsolutePath)(map.file, mapDirectory);
    const generatedFile = host.getSourceFileLike(generatedAbsoluteFilePath);
    const sourceFileAbsolutePaths = map.sources.map(source => (0, ts_js_1.getNormalizedAbsolutePath)(source, sourceRoot));
    const sourceToSourceIndexMap = new Map(sourceFileAbsolutePaths.map((source, i) => [host.getCanonicalFileName(source), i]));
    let decodedMappings;
    let generatedMappings;
    let sourceMappings;
    return {
        getSourcePosition,
        getGeneratedPosition,
    };
    function processMapping(mapping) {
        const generatedPosition = generatedFile !== undefined
            ? (0, ts_js_1.getPositionOfLineAndCharacter)(generatedFile, mapping.generatedLine, mapping.generatedCharacter, /*allowEdits*/ true)
            : -1;
        let source;
        let sourcePosition;
        if (isSourceMapping(mapping)) {
            const sourceFile = host.getSourceFileLike(sourceFileAbsolutePaths[mapping.sourceIndex]);
            source = map.sources[mapping.sourceIndex];
            sourcePosition = sourceFile !== undefined
                ? (0, ts_js_1.getPositionOfLineAndCharacter)(sourceFile, mapping.sourceLine, mapping.sourceCharacter, /*allowEdits*/ true)
                : -1;
        }
        return {
            generatedPosition,
            source,
            sourceIndex: mapping.sourceIndex,
            sourcePosition,
            nameIndex: mapping.nameIndex,
        };
    }
    function getDecodedMappings() {
        if (decodedMappings === undefined) {
            const decoder = decodeMappings(map.mappings);
            const mappings = (0, ts_js_1.arrayFrom)(decoder, processMapping);
            if (decoder.error !== undefined) {
                if (host.log) {
                    host.log(`Encountered error while decoding sourcemap: ${decoder.error}`);
                }
                decodedMappings = ts_js_1.emptyArray;
            }
            else {
                decodedMappings = mappings;
            }
        }
        return decodedMappings;
    }
    function getSourceMappings(sourceIndex) {
        if (sourceMappings === undefined) {
            const lists = [];
            for (const mapping of getDecodedMappings()) {
                if (!isSourceMappedPosition(mapping))
                    continue;
                let list = lists[mapping.sourceIndex];
                if (!list)
                    lists[mapping.sourceIndex] = list = [];
                list.push(mapping);
            }
            sourceMappings = lists.map(list => (0, ts_js_1.sortAndDeduplicate)(list, compareSourcePositions, sameMappedPosition));
        }
        return sourceMappings[sourceIndex];
    }
    function getGeneratedMappings() {
        if (generatedMappings === undefined) {
            const list = [];
            for (const mapping of getDecodedMappings()) {
                list.push(mapping);
            }
            generatedMappings = (0, ts_js_1.sortAndDeduplicate)(list, compareGeneratedPositions, sameMappedPosition);
        }
        return generatedMappings;
    }
    function getGeneratedPosition(loc) {
        const sourceIndex = sourceToSourceIndexMap.get(host.getCanonicalFileName(loc.fileName));
        if (sourceIndex === undefined)
            return loc;
        const sourceMappings = getSourceMappings(sourceIndex);
        if (!(0, ts_js_1.some)(sourceMappings))
            return loc;
        let targetIndex = (0, ts_js_1.binarySearchKey)(sourceMappings, loc.pos, getSourcePositionOfMapping, ts_js_1.compareValues);
        if (targetIndex < 0) {
            // if no exact match, closest is 2's complement of result
            targetIndex = ~targetIndex;
        }
        const mapping = sourceMappings[targetIndex];
        if (mapping === undefined || mapping.sourceIndex !== sourceIndex) {
            return loc;
        }
        return { fileName: generatedAbsoluteFilePath, pos: mapping.generatedPosition }; // Closest pos
    }
    function getSourcePosition(loc) {
        const generatedMappings = getGeneratedMappings();
        if (!(0, ts_js_1.some)(generatedMappings))
            return loc;
        let targetIndex = (0, ts_js_1.binarySearchKey)(generatedMappings, loc.pos, getGeneratedPositionOfMapping, ts_js_1.compareValues);
        if (targetIndex < 0) {
            // if no exact match, closest is 2's complement of result
            targetIndex = ~targetIndex;
        }
        const mapping = generatedMappings[targetIndex];
        if (mapping === undefined || !isSourceMappedPosition(mapping)) {
            return loc;
        }
        return { fileName: sourceFileAbsolutePaths[mapping.sourceIndex], pos: mapping.sourcePosition }; // Closest pos
    }
}
/** @internal */
exports.identitySourceMapConsumer = {
    getSourcePosition: ts_js_1.identity,
    getGeneratedPosition: ts_js_1.identity,
};
