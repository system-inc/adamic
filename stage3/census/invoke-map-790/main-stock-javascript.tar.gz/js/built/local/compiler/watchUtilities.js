"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WatchLogLevel = exports.ProgramUpdateLevel = void 0;
exports.createCachedDirectoryStructureHost = createCachedDirectoryStructureHost;
exports.updateSharedExtendedConfigFileWatcher = updateSharedExtendedConfigFileWatcher;
exports.clearSharedExtendedConfigFileWatcher = clearSharedExtendedConfigFileWatcher;
exports.cleanExtendedConfigCache = cleanExtendedConfigCache;
exports.updateMissingFilePathsWatch = updateMissingFilePathsWatch;
exports.updateWatchingWildcardDirectories = updateWatchingWildcardDirectories;
exports.isIgnoredFileFromWildCardWatching = isIgnoredFileFromWildCardWatching;
exports.isEmittedFileOfProgram = isEmittedFileOfProgram;
exports.getWatchFactory = getWatchFactory;
exports.getFallbackOptions = getFallbackOptions;
exports.closeFileWatcherOf = closeFileWatcherOf;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
function createCachedDirectoryStructureHost(host, currentDirectory, useCaseSensitiveFileNames) {
    if (!host.getDirectories || !host.readDirectory) {
        return undefined;
    }
    const cachedReadDirectoryResult = new Map();
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    return {
        useCaseSensitiveFileNames,
        fileExists,
        readFile: (path, encoding) => host.readFile(path, encoding),
        directoryExists: host.directoryExists && directoryExists,
        getDirectories,
        readDirectory,
        createDirectory: host.createDirectory && createDirectory,
        writeFile: host.writeFile && writeFile,
        addOrDeleteFileOrDirectory,
        addOrDeleteFile,
        clearCache,
        realpath: host.realpath && realpath,
    };
    function toPath(fileName) {
        return (0, ts_js_1.toPath)(fileName, currentDirectory, getCanonicalFileName);
    }
    function getCachedFileSystemEntries(rootDirPath) {
        return cachedReadDirectoryResult.get((0, ts_js_1.ensureTrailingDirectorySeparator)(rootDirPath));
    }
    function getCachedFileSystemEntriesForBaseDir(path) {
        const entries = getCachedFileSystemEntries((0, ts_js_1.getDirectoryPath)(path));
        if (!entries) {
            return entries;
        }
        // If we're looking for the base directory, we're definitely going to search the entries
        if (!entries.sortedAndCanonicalizedFiles) {
            entries.sortedAndCanonicalizedFiles = entries.files.map(getCanonicalFileName).sort();
            entries.sortedAndCanonicalizedDirectories = entries.directories.map(getCanonicalFileName).sort();
        }
        return entries;
    }
    function getBaseNameOfFileName(fileName) {
        return (0, ts_js_1.getBaseFileName)((0, ts_js_1.normalizePath)(fileName));
    }
    function createCachedFileSystemEntries(rootDir, rootDirPath) {
        if (!host.realpath || (0, ts_js_1.ensureTrailingDirectorySeparator)(toPath(host.realpath(rootDir))) === rootDirPath) {
            const resultFromHost = {
                files: (0, ts_js_1.map)(host.readDirectory(rootDir, /*extensions*/ undefined, /*exclude*/ undefined, /*include*/ ["*.*"]), getBaseNameOfFileName) || [],
                directories: host.getDirectories(rootDir) || [],
            };
            cachedReadDirectoryResult.set((0, ts_js_1.ensureTrailingDirectorySeparator)(rootDirPath), resultFromHost);
            return resultFromHost;
        }
        // If the directory is symlink do not cache the result
        if (host.directoryExists?.(rootDir)) {
            cachedReadDirectoryResult.set(rootDirPath, false);
            return false;
        }
        // Non existing directory
        return undefined;
    }
    /**
     * If the readDirectory result was already cached, it returns that
     * Otherwise gets result from host and caches it.
     * The host request is done under try catch block to avoid caching incorrect result
     */
    function tryReadDirectory(rootDir, rootDirPath) {
        rootDirPath = (0, ts_js_1.ensureTrailingDirectorySeparator)(rootDirPath);
        const cachedResult = getCachedFileSystemEntries(rootDirPath);
        if (cachedResult) {
            return cachedResult;
        }
        try {
            return createCachedFileSystemEntries(rootDir, rootDirPath);
        }
        catch {
            // If there is exception to read directories, dont cache the result and direct the calls to host
            ts_js_1.Debug.assert(!cachedReadDirectoryResult.has((0, ts_js_1.ensureTrailingDirectorySeparator)(rootDirPath)));
            return undefined;
        }
    }
    function hasEntry(entries, name) {
        // Case-sensitive comparison since already canonicalized
        const index = (0, ts_js_1.binarySearch)(entries, name, ts_js_1.identity, ts_js_1.compareStringsCaseSensitive);
        return index >= 0;
    }
    function writeFile(fileName, data, writeByteOrderMark) {
        const path = toPath(fileName);
        const result = getCachedFileSystemEntriesForBaseDir(path);
        if (result) {
            updateFilesOfFileSystemEntry(result, getBaseNameOfFileName(fileName), /*fileExists*/ true);
        }
        return host.writeFile(fileName, data, writeByteOrderMark);
    }
    function fileExists(fileName) {
        const path = toPath(fileName);
        const result = getCachedFileSystemEntriesForBaseDir(path);
        return result && hasEntry(result.sortedAndCanonicalizedFiles, getCanonicalFileName(getBaseNameOfFileName(fileName))) ||
            host.fileExists(fileName);
    }
    function directoryExists(dirPath) {
        const path = toPath(dirPath);
        return cachedReadDirectoryResult.has((0, ts_js_1.ensureTrailingDirectorySeparator)(path)) || host.directoryExists(dirPath);
    }
    function createDirectory(dirPath) {
        const path = toPath(dirPath);
        const result = getCachedFileSystemEntriesForBaseDir(path);
        if (result) {
            const baseName = getBaseNameOfFileName(dirPath);
            const canonicalizedBaseName = getCanonicalFileName(baseName);
            const canonicalizedDirectories = result.sortedAndCanonicalizedDirectories;
            // Case-sensitive comparison since already canonicalized
            if ((0, ts_js_1.insertSorted)(canonicalizedDirectories, canonicalizedBaseName, ts_js_1.compareStringsCaseSensitive)) {
                result.directories.push(baseName);
            }
        }
        host.createDirectory(dirPath);
    }
    function getDirectories(rootDir) {
        const rootDirPath = toPath(rootDir);
        const result = tryReadDirectory(rootDir, rootDirPath);
        if (result) {
            return result.directories.slice();
        }
        return host.getDirectories(rootDir);
    }
    function readDirectory(rootDir, extensions, excludes, includes, depth) {
        const rootDirPath = toPath(rootDir);
        const rootResult = tryReadDirectory(rootDir, rootDirPath);
        let rootSymLinkResult;
        if (rootResult !== undefined) {
            return (0, ts_js_1.matchFiles)(rootDir, extensions, excludes, includes, useCaseSensitiveFileNames, currentDirectory, depth, getFileSystemEntries, realpath);
        }
        return host.readDirectory(rootDir, extensions, excludes, includes, depth);
        function getFileSystemEntries(dir) {
            const path = toPath(dir);
            if (path === rootDirPath) {
                return rootResult || getFileSystemEntriesFromHost(dir, path);
            }
            const result = tryReadDirectory(dir, path);
            return result !== undefined ?
                result || getFileSystemEntriesFromHost(dir, path) :
                ts_js_1.emptyFileSystemEntries;
        }
        function getFileSystemEntriesFromHost(dir, path) {
            if (rootSymLinkResult && path === rootDirPath)
                return rootSymLinkResult;
            const result = {
                files: (0, ts_js_1.map)(host.readDirectory(dir, /*extensions*/ undefined, /*exclude*/ undefined, /*include*/ ["*.*"]), getBaseNameOfFileName) || ts_js_1.emptyArray,
                directories: host.getDirectories(dir) || ts_js_1.emptyArray,
            };
            if (path === rootDirPath)
                rootSymLinkResult = result;
            return result;
        }
    }
    function realpath(s) {
        return host.realpath ? host.realpath(s) : s;
    }
    function clearFirstAncestorEntry(fileOrDirectoryPath) {
        (0, ts_js_1.forEachAncestorDirectory)((0, ts_js_1.getDirectoryPath)(fileOrDirectoryPath), ancestor => cachedReadDirectoryResult.delete((0, ts_js_1.ensureTrailingDirectorySeparator)(ancestor)) ? true : undefined);
    }
    function addOrDeleteFileOrDirectory(fileOrDirectory, fileOrDirectoryPath) {
        const existingResult = getCachedFileSystemEntries(fileOrDirectoryPath);
        if (existingResult !== undefined) {
            // Just clear the cache for now
            // For now just clear the cache, since this could mean that multiple level entries might need to be re-evaluated
            clearCache();
            return undefined;
        }
        const parentResult = getCachedFileSystemEntriesForBaseDir(fileOrDirectoryPath);
        if (!parentResult) {
            clearFirstAncestorEntry(fileOrDirectoryPath);
            return undefined;
        }
        // This was earlier a file (hence not in cached directory contents)
        // or we never cached the directory containing it
        if (!host.directoryExists) {
            // Since host doesnt support directory exists, clear the cache as otherwise it might not be same
            clearCache();
            return undefined;
        }
        const baseName = getBaseNameOfFileName(fileOrDirectory);
        const fsQueryResult = {
            fileExists: host.fileExists(fileOrDirectory),
            directoryExists: host.directoryExists(fileOrDirectory),
        };
        if (fsQueryResult.directoryExists || hasEntry(parentResult.sortedAndCanonicalizedDirectories, getCanonicalFileName(baseName))) {
            // Folder added or removed, clear the cache instead of updating the folder and its structure
            clearCache();
        }
        else {
            // No need to update the directory structure, just files
            updateFilesOfFileSystemEntry(parentResult, baseName, fsQueryResult.fileExists);
        }
        return fsQueryResult;
    }
    function addOrDeleteFile(fileName, filePath, eventKind) {
        if (eventKind === ts_js_1.FileWatcherEventKind.Changed) {
            return;
        }
        const parentResult = getCachedFileSystemEntriesForBaseDir(filePath);
        if (parentResult) {
            updateFilesOfFileSystemEntry(parentResult, getBaseNameOfFileName(fileName), eventKind === ts_js_1.FileWatcherEventKind.Created);
        }
        else {
            clearFirstAncestorEntry(filePath);
        }
    }
    function updateFilesOfFileSystemEntry(parentResult, baseName, fileExists) {
        const canonicalizedFiles = parentResult.sortedAndCanonicalizedFiles;
        const canonicalizedBaseName = getCanonicalFileName(baseName);
        if (fileExists) {
            // Case-sensitive comparison since already canonicalized
            if ((0, ts_js_1.insertSorted)(canonicalizedFiles, canonicalizedBaseName, ts_js_1.compareStringsCaseSensitive)) {
                parentResult.files.push(baseName);
            }
        }
        else {
            // Case-sensitive comparison since already canonicalized
            const sortedIndex = (0, ts_js_1.binarySearch)(canonicalizedFiles, canonicalizedBaseName, ts_js_1.identity, ts_js_1.compareStringsCaseSensitive);
            if (sortedIndex >= 0) {
                canonicalizedFiles.splice(sortedIndex, 1);
                const unsortedIndex = parentResult.files.findIndex(entry => getCanonicalFileName(entry) === canonicalizedBaseName);
                parentResult.files.splice(unsortedIndex, 1);
            }
        }
    }
    function clearCache() {
        cachedReadDirectoryResult.clear();
    }
}
var ProgramUpdateLevel;
(function (ProgramUpdateLevel) {
    /** Program is updated with same root file names and options */
    ProgramUpdateLevel[ProgramUpdateLevel["Update"] = 0] = "Update";
    /** Loads program after updating root file names from the disk */
    ProgramUpdateLevel[ProgramUpdateLevel["RootNamesAndUpdate"] = 1] = "RootNamesAndUpdate";
    /**
     * Loads program completely, including:
     *  - re-reading contents of config file from disk
     *  - calculating root file names for the program
     *  - Updating the program
     */
    ProgramUpdateLevel[ProgramUpdateLevel["Full"] = 2] = "Full";
})(ProgramUpdateLevel || (exports.ProgramUpdateLevel = ProgramUpdateLevel = {}));
/**
 * Updates the map of shared extended config file watches with a new set of extended config files from a base config file of the project
 *
 * @internal
 */
function updateSharedExtendedConfigFileWatcher(projectPath, options, extendedConfigFilesMap, createExtendedConfigFileWatch, toPath) {
    const extendedConfigs = (0, ts_js_1.arrayToMap)(options?.configFile?.extendedSourceFiles || ts_js_1.emptyArray, toPath);
    // remove project from all unrelated watchers
    extendedConfigFilesMap.forEach((watcher, extendedConfigFilePath) => {
        if (!extendedConfigs.has(extendedConfigFilePath)) {
            watcher.projects.delete(projectPath);
            watcher.close();
        }
    });
    // Update the extended config files watcher
    extendedConfigs.forEach((extendedConfigFileName, extendedConfigFilePath) => {
        const existing = extendedConfigFilesMap.get(extendedConfigFilePath);
        if (existing) {
            existing.projects.add(projectPath);
        }
        else {
            // start watching previously unseen extended config
            extendedConfigFilesMap.set(extendedConfigFilePath, {
                projects: new Set([projectPath]),
                watcher: createExtendedConfigFileWatch(extendedConfigFileName, extendedConfigFilePath),
                close: () => {
                    const existing = extendedConfigFilesMap.get(extendedConfigFilePath);
                    if (!existing || existing.projects.size !== 0)
                        return;
                    existing.watcher.close();
                    extendedConfigFilesMap.delete(extendedConfigFilePath);
                },
            });
        }
    });
}
/**
 * Remove the project from the extended config file watchers and close not needed watches
 *
 * @internal
 */
function clearSharedExtendedConfigFileWatcher(projectPath, extendedConfigFilesMap) {
    extendedConfigFilesMap.forEach(watcher => {
        if (watcher.projects.delete(projectPath))
            watcher.close();
    });
}
/**
 * Clean the extendsConfigCache when extended config file has changed
 *
 * @internal
 */
function cleanExtendedConfigCache(extendedConfigCache, extendedConfigFilePath, toPath) {
    if (!extendedConfigCache.delete(extendedConfigFilePath))
        return;
    extendedConfigCache.forEach(({ extendedResult }, key) => {
        if (extendedResult.extendedSourceFiles?.some(extendedFile => toPath(extendedFile) === extendedConfigFilePath)) {
            cleanExtendedConfigCache(extendedConfigCache, key, toPath);
        }
    });
}
/**
 * Updates the existing missing file watches with the new set of missing files after new program is created
 *
 * @internal
 */
function updateMissingFilePathsWatch(program, missingFileWatches, createMissingFileWatch) {
    // Update the missing file paths watcher
    (0, ts_js_1.mutateMap)(missingFileWatches, program.getMissingFilePaths(), {
        // Watch the missing files
        createNewValue: createMissingFileWatch,
        // Files that are no longer missing (e.g. because they are no longer required)
        // should no longer be watched.
        onDeleteValue: ts_js_1.closeFileWatcher,
    });
}
/**
 * Updates the existing wild card directory watches with the new set of wild card directories from the config file
 * after new program is created because the config file was reloaded or program was created first time from the config file
 * Note that there is no need to call this function when the program is updated with additional files without reloading config files,
 * as wildcard directories wont change unless reloading config file
 *
 * @internal
 */
function updateWatchingWildcardDirectories(existingWatchedForWildcards, wildcardDirectories, watchDirectory) {
    if (wildcardDirectories) {
        (0, ts_js_1.mutateMap)(existingWatchedForWildcards, new Map(Object.entries(wildcardDirectories)), {
            // Create new watch and recursive info
            createNewValue: createWildcardDirectoryWatcher,
            // Close existing watch thats not needed any more
            onDeleteValue: closeFileWatcherOf,
            // Close existing watch that doesnt match in the flags
            onExistingValue: updateWildcardDirectoryWatcher,
        });
    }
    else {
        (0, ts_js_1.clearMap)(existingWatchedForWildcards, closeFileWatcherOf);
    }
    function createWildcardDirectoryWatcher(directory, flags) {
        // Create new watch and recursive info
        return {
            watcher: watchDirectory(directory, flags),
            flags,
        };
    }
    function updateWildcardDirectoryWatcher(existingWatcher, flags, directory) {
        // Watcher needs to be updated if the recursive flags dont match
        if (existingWatcher.flags === flags) {
            return;
        }
        existingWatcher.watcher.close();
        existingWatchedForWildcards.set(directory, createWildcardDirectoryWatcher(directory, flags));
    }
}
/** @internal */
function isIgnoredFileFromWildCardWatching({ watchedDirPath, fileOrDirectory, fileOrDirectoryPath, configFileName, options, program, extraFileExtensions, currentDirectory, useCaseSensitiveFileNames, writeLog, toPath, getScriptKind, }) {
    const newPath = (0, ts_js_1.removeIgnoredPath)(fileOrDirectoryPath);
    if (!newPath) {
        writeLog(`Project: ${configFileName} Detected ignored path: ${fileOrDirectory}`);
        return true;
    }
    fileOrDirectoryPath = newPath;
    if (fileOrDirectoryPath === watchedDirPath)
        return false;
    // If the the added or created file or directory is not supported file name, ignore the file
    if ((0, ts_js_1.hasExtension)(fileOrDirectoryPath) && !((0, ts_js_1.isSupportedSourceFileName)(fileOrDirectory, options, extraFileExtensions) ||
        isSupportedScriptKind())) {
        writeLog(`Project: ${configFileName} Detected file add/remove of non supported extension: ${fileOrDirectory}`);
        return true;
    }
    if ((0, ts_js_1.isExcludedFile)(fileOrDirectory, options.configFile.configFileSpecs, (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getDirectoryPath)(configFileName), currentDirectory), useCaseSensitiveFileNames, currentDirectory)) {
        writeLog(`Project: ${configFileName} Detected excluded file: ${fileOrDirectory}`);
        return true;
    }
    if (!program)
        return false;
    // We want to ignore emit file check if file is not going to be emitted next to source file
    // In that case we follow config file inclusion rules
    if (options.outFile || options.outDir)
        return false;
    // File if emitted next to input needs to be ignored
    if ((0, ts_js_1.isDeclarationFileName)(fileOrDirectoryPath)) {
        // If its declaration directory: its not ignored if not excluded by config
        if (options.declarationDir)
            return false;
    }
    else if (!(0, ts_js_1.fileExtensionIsOneOf)(fileOrDirectoryPath, ts_js_1.supportedJSExtensionsFlat)) {
        return false;
    }
    // just check if sourceFile with the name exists
    const filePathWithoutExtension = (0, ts_js_1.removeFileExtension)(fileOrDirectoryPath);
    const realProgram = (0, ts_js_1.isArray)(program) ? undefined : (0, ts_js_1.isBuilderProgram)(program) ? program.getProgramOrUndefined() : program;
    const builderProgram = !realProgram && !(0, ts_js_1.isArray)(program) ? program : undefined;
    if (hasSourceFile((filePathWithoutExtension + ".ts" /* Extension.Ts */)) ||
        hasSourceFile((filePathWithoutExtension + ".tsx" /* Extension.Tsx */))) {
        writeLog(`Project: ${configFileName} Detected output file: ${fileOrDirectory}`);
        return true;
    }
    return false;
    function hasSourceFile(file) {
        return realProgram ?
            !!realProgram.getSourceFileByPath(file) :
            builderProgram ?
                builderProgram.state.fileInfos.has(file) :
                !!(0, ts_js_1.find)(program, rootFile => toPath(rootFile) === file);
    }
    function isSupportedScriptKind() {
        if (!getScriptKind)
            return false;
        const scriptKind = getScriptKind(fileOrDirectory);
        switch (scriptKind) {
            case 3 /* ScriptKind.TS */:
            case 4 /* ScriptKind.TSX */:
            case 7 /* ScriptKind.Deferred */:
            case 5 /* ScriptKind.External */:
                return true;
            case 1 /* ScriptKind.JS */:
            case 2 /* ScriptKind.JSX */:
                return (0, ts_js_1.getAllowJSCompilerOption)(options);
            case 6 /* ScriptKind.JSON */:
                return (0, ts_js_1.getResolveJsonModule)(options);
            case 0 /* ScriptKind.Unknown */:
                return false;
        }
    }
}
/** @internal */
function isEmittedFileOfProgram(program, file) {
    if (!program) {
        return false;
    }
    return program.isEmittedFile(file);
}
/** @internal */
var WatchLogLevel;
(function (WatchLogLevel) {
    WatchLogLevel[WatchLogLevel["None"] = 0] = "None";
    WatchLogLevel[WatchLogLevel["TriggerOnly"] = 1] = "TriggerOnly";
    WatchLogLevel[WatchLogLevel["Verbose"] = 2] = "Verbose";
})(WatchLogLevel || (exports.WatchLogLevel = WatchLogLevel = {}));
/** @internal */
function getWatchFactory(host, watchLogLevel, log, getDetailWatchInfo) {
    (0, ts_js_1.setSysLog)(watchLogLevel === WatchLogLevel.Verbose ? log : ts_js_1.noop);
    const plainInvokeFactory = {
        watchFile: (file, callback, pollingInterval, options) => host.watchFile(file, callback, pollingInterval, options),
        watchDirectory: (directory, callback, flags, options) => host.watchDirectory(directory, callback, (flags & 1 /* WatchDirectoryFlags.Recursive */) !== 0, options),
    };
    const triggerInvokingFactory = watchLogLevel !== WatchLogLevel.None ?
        {
            watchFile: createTriggerLoggingAddWatch("watchFile"),
            watchDirectory: createTriggerLoggingAddWatch("watchDirectory"),
        } :
        undefined;
    const factory = watchLogLevel === WatchLogLevel.Verbose ?
        {
            watchFile: createFileWatcherWithLogging,
            watchDirectory: createDirectoryWatcherWithLogging,
        } :
        triggerInvokingFactory || plainInvokeFactory;
    const excludeWatcherFactory = watchLogLevel === WatchLogLevel.Verbose ?
        createExcludeWatcherWithLogging :
        ts_js_1.returnNoopFileWatcher;
    return {
        watchFile: createExcludeHandlingAddWatch("watchFile"),
        watchDirectory: createExcludeHandlingAddWatch("watchDirectory"),
    };
    function createExcludeHandlingAddWatch(key) {
        return (file, cb, flags, options, detailInfo1, detailInfo2) => !(0, ts_js_1.matchesExclude)(file, key === "watchFile" ? options?.excludeFiles : options?.excludeDirectories, useCaseSensitiveFileNames(), host.getCurrentDirectory?.() || "") ?
            factory[key].call(/*thisArgs*/ undefined, file, cb, flags, options, detailInfo1, detailInfo2) :
            excludeWatcherFactory(file, flags, options, detailInfo1, detailInfo2);
    }
    function useCaseSensitiveFileNames() {
        return typeof host.useCaseSensitiveFileNames === "boolean" ?
            host.useCaseSensitiveFileNames :
            host.useCaseSensitiveFileNames();
    }
    function createExcludeWatcherWithLogging(file, flags, options, detailInfo1, detailInfo2) {
        log(`ExcludeWatcher:: Added:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`);
        return {
            close: () => log(`ExcludeWatcher:: Close:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`),
        };
    }
    function createFileWatcherWithLogging(file, cb, flags, options, detailInfo1, detailInfo2) {
        log(`FileWatcher:: Added:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`);
        const watcher = triggerInvokingFactory.watchFile(file, cb, flags, options, detailInfo1, detailInfo2);
        return {
            close: () => {
                log(`FileWatcher:: Close:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`);
                watcher.close();
            },
        };
    }
    function createDirectoryWatcherWithLogging(file, cb, flags, options, detailInfo1, detailInfo2) {
        const watchInfo = `DirectoryWatcher:: Added:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`;
        log(watchInfo);
        const start = (0, ts_js_1.timestamp)();
        const watcher = triggerInvokingFactory.watchDirectory(file, cb, flags, options, detailInfo1, detailInfo2);
        const elapsed = (0, ts_js_1.timestamp)() - start;
        log(`Elapsed:: ${elapsed}ms ${watchInfo}`);
        return {
            close: () => {
                const watchInfo = `DirectoryWatcher:: Close:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`;
                log(watchInfo);
                const start = (0, ts_js_1.timestamp)();
                watcher.close();
                const elapsed = (0, ts_js_1.timestamp)() - start;
                log(`Elapsed:: ${elapsed}ms ${watchInfo}`);
            },
        };
    }
    function createTriggerLoggingAddWatch(key) {
        return (file, cb, flags, options, detailInfo1, detailInfo2) => plainInvokeFactory[key].call(
        /*thisArgs*/ undefined, file, (...args) => {
            const triggerredInfo = `${key === "watchFile" ? "FileWatcher" : "DirectoryWatcher"}:: Triggered with ${args[0]} ${args[1] !== undefined ? args[1] : ""}:: ${getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo)}`;
            log(triggerredInfo);
            const start = (0, ts_js_1.timestamp)();
            cb.call(/*thisArg*/ undefined, ...args);
            const elapsed = (0, ts_js_1.timestamp)() - start;
            log(`Elapsed:: ${elapsed}ms ${triggerredInfo}`);
        }, flags, options, detailInfo1, detailInfo2);
    }
    function getWatchInfo(file, flags, options, detailInfo1, detailInfo2, getDetailWatchInfo) {
        return `WatchInfo: ${file} ${flags} ${JSON.stringify(options)} ${getDetailWatchInfo ? getDetailWatchInfo(detailInfo1, detailInfo2) : detailInfo2 === undefined ? detailInfo1 : `${detailInfo1} ${detailInfo2}`}`;
    }
}
/** @internal */
function getFallbackOptions(options) {
    const fallbackPolling = options?.fallbackPolling;
    return {
        watchFile: fallbackPolling !== undefined ?
            fallbackPolling :
            ts_js_1.WatchFileKind.PriorityPollingInterval,
    };
}
/** @internal */
function closeFileWatcherOf(objWithWatcher) {
    objWithWatcher.watcher.close();
}
