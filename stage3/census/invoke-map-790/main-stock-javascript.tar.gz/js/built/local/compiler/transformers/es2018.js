"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformES2018 = transformES2018;
const ts_js_1 = require("../_namespaces/ts.js");
var ESNextSubstitutionFlags;
(function (ESNextSubstitutionFlags) {
    ESNextSubstitutionFlags[ESNextSubstitutionFlags["None"] = 0] = "None";
    /** Enables substitutions for async methods with `super` calls. */
    ESNextSubstitutionFlags[ESNextSubstitutionFlags["AsyncMethodsWithSuper"] = 1] = "AsyncMethodsWithSuper";
})(ESNextSubstitutionFlags || (ESNextSubstitutionFlags = {}));
// Facts we track as we traverse the tree
var HierarchyFacts;
(function (HierarchyFacts) {
    HierarchyFacts[HierarchyFacts["None"] = 0] = "None";
    //
    // Ancestor facts
    //
    HierarchyFacts[HierarchyFacts["HasLexicalThis"] = 1] = "HasLexicalThis";
    HierarchyFacts[HierarchyFacts["IterationContainer"] = 2] = "IterationContainer";
    // NOTE: do not add more ancestor flags without also updating AncestorFactsMask below.
    //
    // Ancestor masks
    //
    HierarchyFacts[HierarchyFacts["AncestorFactsMask"] = 3] = "AncestorFactsMask";
    HierarchyFacts[HierarchyFacts["SourceFileIncludes"] = 1] = "SourceFileIncludes";
    HierarchyFacts[HierarchyFacts["SourceFileExcludes"] = 2] = "SourceFileExcludes";
    HierarchyFacts[HierarchyFacts["StrictModeSourceFileIncludes"] = 0] = "StrictModeSourceFileIncludes";
    HierarchyFacts[HierarchyFacts["ClassOrFunctionIncludes"] = 1] = "ClassOrFunctionIncludes";
    HierarchyFacts[HierarchyFacts["ClassOrFunctionExcludes"] = 2] = "ClassOrFunctionExcludes";
    HierarchyFacts[HierarchyFacts["ArrowFunctionIncludes"] = 0] = "ArrowFunctionIncludes";
    HierarchyFacts[HierarchyFacts["ArrowFunctionExcludes"] = 2] = "ArrowFunctionExcludes";
    HierarchyFacts[HierarchyFacts["IterationStatementIncludes"] = 2] = "IterationStatementIncludes";
    HierarchyFacts[HierarchyFacts["IterationStatementExcludes"] = 0] = "IterationStatementExcludes";
})(HierarchyFacts || (HierarchyFacts = {}));
/** @internal */
function transformES2018(context) {
    const { factory, getEmitHelperFactory: emitHelpers, resumeLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const previousOnEmitNode = context.onEmitNode;
    context.onEmitNode = onEmitNode;
    const previousOnSubstituteNode = context.onSubstituteNode;
    context.onSubstituteNode = onSubstituteNode;
    let exportedVariableStatement = false;
    let enabledSubstitutions = 0 /* ESNextSubstitutionFlags.None */;
    let enclosingFunctionFlags;
    let parametersWithPrecedingObjectRestOrSpread;
    let enclosingSuperContainerFlags = 0;
    let hierarchyFacts = 0;
    let currentSourceFile;
    let taggedTemplateStringDeclarations;
    /** Keeps track of property names accessed on super (`super.x`) within async functions. */
    let capturedSuperProperties;
    /** Whether the async function contains an element access on super (`super[x]`). */
    let hasSuperElementAccess;
    /** A set of node IDs for generated super accessors. */
    const substitutedSuperAccessors = [];
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function affectsSubtree(excludeFacts, includeFacts) {
        return hierarchyFacts !== (hierarchyFacts & ~excludeFacts | includeFacts);
    }
    /**
     * Sets the `HierarchyFacts` for this node prior to visiting this node's subtree, returning the facts set prior to modification.
     * @param excludeFacts The existing `HierarchyFacts` to reset before visiting the subtree.
     * @param includeFacts The new `HierarchyFacts` to set before visiting the subtree.
     */
    function enterSubtree(excludeFacts, includeFacts) {
        const ancestorFacts = hierarchyFacts;
        hierarchyFacts = (hierarchyFacts & ~excludeFacts | includeFacts) & 3 /* HierarchyFacts.AncestorFactsMask */;
        return ancestorFacts;
    }
    /**
     * Restores the `HierarchyFacts` for this node's ancestor after visiting this node's
     * subtree.
     * @param ancestorFacts The `HierarchyFacts` of the ancestor to restore after visiting the subtree.
     */
    function exitSubtree(ancestorFacts) {
        hierarchyFacts = ancestorFacts;
    }
    function recordTaggedTemplateString(temp) {
        taggedTemplateStringDeclarations = (0, ts_js_1.append)(taggedTemplateStringDeclarations, factory.createVariableDeclaration(temp));
    }
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        currentSourceFile = node;
        const visited = visitSourceFile(node);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        currentSourceFile = undefined;
        taggedTemplateStringDeclarations = undefined;
        return visited;
    }
    function visitor(node) {
        return visitorWorker(node, /*expressionResultIsUnused*/ false);
    }
    function visitorWithUnusedExpressionResult(node) {
        return visitorWorker(node, /*expressionResultIsUnused*/ true);
    }
    function visitorNoAsyncModifier(node) {
        if (node.kind === 134 /* SyntaxKind.AsyncKeyword */) {
            return undefined;
        }
        return node;
    }
    function doWithHierarchyFacts(cb, value, excludeFacts, includeFacts) {
        if (affectsSubtree(excludeFacts, includeFacts)) {
            const ancestorFacts = enterSubtree(excludeFacts, includeFacts);
            const result = cb(value);
            exitSubtree(ancestorFacts);
            return result;
        }
        return cb(value);
    }
    function visitDefault(node) {
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * @param expressionResultIsUnused Indicates the result of an expression is unused by the parent node (i.e., the left side of a comma or the
     * expression of an `ExpressionStatement`).
     */
    function visitorWorker(node, expressionResultIsUnused) {
        if ((node.transformFlags & 128 /* TransformFlags.ContainsES2018 */) === 0) {
            return node;
        }
        switch (node.kind) {
            case 224 /* SyntaxKind.AwaitExpression */:
                return visitAwaitExpression(node);
            case 230 /* SyntaxKind.YieldExpression */:
                return visitYieldExpression(node);
            case 254 /* SyntaxKind.ReturnStatement */:
                return visitReturnStatement(node);
            case 257 /* SyntaxKind.LabeledStatement */:
                return visitLabeledStatement(node);
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                return visitObjectLiteralExpression(node);
            case 227 /* SyntaxKind.BinaryExpression */:
                return visitBinaryExpression(node, expressionResultIsUnused);
            case 357 /* SyntaxKind.CommaListExpression */:
                return visitCommaListExpression(node, expressionResultIsUnused);
            case 300 /* SyntaxKind.CatchClause */:
                return visitCatchClause(node);
            case 244 /* SyntaxKind.VariableStatement */:
                return visitVariableStatement(node);
            case 261 /* SyntaxKind.VariableDeclaration */:
                return visitVariableDeclaration(node);
            case 247 /* SyntaxKind.DoStatement */:
            case 248 /* SyntaxKind.WhileStatement */:
            case 250 /* SyntaxKind.ForInStatement */:
                return doWithHierarchyFacts(visitDefault, node, 0 /* HierarchyFacts.IterationStatementExcludes */, 2 /* HierarchyFacts.IterationStatementIncludes */);
            case 251 /* SyntaxKind.ForOfStatement */:
                return visitForOfStatement(node, /*outermostLabeledStatement*/ undefined);
            case 249 /* SyntaxKind.ForStatement */:
                return doWithHierarchyFacts(visitForStatement, node, 0 /* HierarchyFacts.IterationStatementExcludes */, 2 /* HierarchyFacts.IterationStatementIncludes */);
            case 223 /* SyntaxKind.VoidExpression */:
                return visitVoidExpression(node);
            case 177 /* SyntaxKind.Constructor */:
                return doWithHierarchyFacts(visitConstructorDeclaration, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 175 /* SyntaxKind.MethodDeclaration */:
                return doWithHierarchyFacts(visitMethodDeclaration, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 178 /* SyntaxKind.GetAccessor */:
                return doWithHierarchyFacts(visitGetAccessorDeclaration, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 179 /* SyntaxKind.SetAccessor */:
                return doWithHierarchyFacts(visitSetAccessorDeclaration, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return doWithHierarchyFacts(visitFunctionDeclaration, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 219 /* SyntaxKind.FunctionExpression */:
                return doWithHierarchyFacts(visitFunctionExpression, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            case 220 /* SyntaxKind.ArrowFunction */:
                return doWithHierarchyFacts(visitArrowFunction, node, 2 /* HierarchyFacts.ArrowFunctionExcludes */, 0 /* HierarchyFacts.ArrowFunctionIncludes */);
            case 170 /* SyntaxKind.Parameter */:
                return visitParameter(node);
            case 245 /* SyntaxKind.ExpressionStatement */:
                return visitExpressionStatement(node);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                return visitParenthesizedExpression(node, expressionResultIsUnused);
            case 216 /* SyntaxKind.TaggedTemplateExpression */:
                return visitTaggedTemplateExpression(node);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                if (capturedSuperProperties && (0, ts_js_1.isPropertyAccessExpression)(node) && node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
                    capturedSuperProperties.add(node.name.escapedText);
                }
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                if (capturedSuperProperties && node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
                    hasSuperElementAccess = true;
                }
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 232 /* SyntaxKind.ClassExpression */:
                return doWithHierarchyFacts(visitDefault, node, 2 /* HierarchyFacts.ClassOrFunctionExcludes */, 1 /* HierarchyFacts.ClassOrFunctionIncludes */);
            default:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function visitAwaitExpression(node) {
        if (enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */) {
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createYieldExpression(/*asteriskToken*/ undefined, emitHelpers().createAwaitHelper((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression))), 
            /*location*/ node), node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitYieldExpression(node) {
        if (enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */) {
            if (node.asteriskToken) {
                const expression = (0, ts_js_1.visitNode)(ts_js_1.Debug.checkDefined(node.expression), visitor, ts_js_1.isExpression);
                return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createYieldExpression(
                /*asteriskToken*/ undefined, emitHelpers().createAwaitHelper(factory.updateYieldExpression(node, node.asteriskToken, (0, ts_js_1.setTextRange)(emitHelpers().createAsyncDelegatorHelper((0, ts_js_1.setTextRange)(emitHelpers().createAsyncValuesHelper(expression), expression)), expression)))), node), node);
            }
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createYieldExpression(
            /*asteriskToken*/ undefined, createDownlevelAwait(node.expression
                ? (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)
                : factory.createVoidZero())), node), node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitReturnStatement(node) {
        if (enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */) {
            return factory.updateReturnStatement(node, createDownlevelAwait(node.expression ? (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression) : factory.createVoidZero()));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitLabeledStatement(node) {
        if (enclosingFunctionFlags & 2 /* FunctionFlags.Async */) {
            const statement = (0, ts_js_1.unwrapInnermostStatementOfLabel)(node);
            if (statement.kind === 251 /* SyntaxKind.ForOfStatement */ && statement.awaitModifier) {
                return visitForOfStatement(statement, node);
            }
            return factory.restoreEnclosingLabel((0, ts_js_1.visitNode)(statement, visitor, ts_js_1.isStatement, factory.liftToBlock), node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function chunkObjectLiteralElements(elements) {
        let chunkObject;
        const objects = [];
        for (const e of elements) {
            if (e.kind === 306 /* SyntaxKind.SpreadAssignment */) {
                if (chunkObject) {
                    objects.push(factory.createObjectLiteralExpression(chunkObject));
                    chunkObject = undefined;
                }
                const target = e.expression;
                objects.push((0, ts_js_1.visitNode)(target, visitor, ts_js_1.isExpression));
            }
            else {
                chunkObject = (0, ts_js_1.append)(chunkObject, e.kind === 304 /* SyntaxKind.PropertyAssignment */
                    ? factory.createPropertyAssignment(e.name, (0, ts_js_1.visitNode)(e.initializer, visitor, ts_js_1.isExpression))
                    : (0, ts_js_1.visitNode)(e, visitor, ts_js_1.isObjectLiteralElementLike));
            }
        }
        if (chunkObject) {
            objects.push(factory.createObjectLiteralExpression(chunkObject));
        }
        return objects;
    }
    function visitObjectLiteralExpression(node) {
        if (node.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
            // spread elements emit like so:
            // non-spread elements are chunked together into object literals, and then all are passed to __assign:
            //     { a, ...o, b } => __assign(__assign({a}, o), {b});
            // If the first element is a spread element, then the first argument to __assign is {}:
            //     { ...o, a, b, ...o2 } => __assign(__assign(__assign({}, o), {a, b}), o2)
            //
            // We cannot call __assign with more than two elements, since any element could cause side effects. For
            // example:
            //      var k = { a: 1, b: 2 };
            //      var o = { a: 3, ...k, b: k.a++ };
            //      // expected: { a: 1, b: 1 }
            // If we translate the above to `__assign({ a: 3 }, k, { b: k.a++ })`, the `k.a++` will evaluate before
            // `k` is spread and we end up with `{ a: 2, b: 1 }`.
            //
            // This also occurs for spread elements, not just property assignments:
            //      var k = { a: 1, get b() { l = { z: 9 }; return 2; } };
            //      var l = { c: 3 };
            //      var o = { ...k, ...l };
            //      // expected: { a: 1, b: 2, z: 9 }
            // If we translate the above to `__assign({}, k, l)`, the `l` will evaluate before `k` is spread and we
            // end up with `{ a: 1, b: 2, c: 3 }`
            const objects = chunkObjectLiteralElements(node.properties);
            if (objects.length && objects[0].kind !== 211 /* SyntaxKind.ObjectLiteralExpression */) {
                objects.unshift(factory.createObjectLiteralExpression());
            }
            let expression = objects[0];
            if (objects.length > 1) {
                for (let i = 1; i < objects.length; i++) {
                    expression = emitHelpers().createAssignHelper([expression, objects[i]]);
                }
                return expression;
            }
            else {
                return emitHelpers().createAssignHelper(objects);
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitExpressionStatement(node) {
        return (0, ts_js_1.visitEachChild)(node, visitorWithUnusedExpressionResult, context);
    }
    /**
     * @param expressionResultIsUnused Indicates the result of an expression is unused by the parent node (i.e., the left side of a comma or the
     * expression of an `ExpressionStatement`).
     */
    function visitParenthesizedExpression(node, expressionResultIsUnused) {
        return (0, ts_js_1.visitEachChild)(node, expressionResultIsUnused ? visitorWithUnusedExpressionResult : visitor, context);
    }
    function visitSourceFile(node) {
        const ancestorFacts = enterSubtree(2 /* HierarchyFacts.SourceFileExcludes */, (0, ts_js_1.isEffectiveStrictModeSourceFile)(node, compilerOptions) ?
            0 /* HierarchyFacts.StrictModeSourceFileIncludes */ :
            1 /* HierarchyFacts.SourceFileIncludes */);
        exportedVariableStatement = false;
        const visited = (0, ts_js_1.visitEachChild)(node, visitor, context);
        const statement = (0, ts_js_1.concatenate)(visited.statements, taggedTemplateStringDeclarations && [
            factory.createVariableStatement(/*modifiers*/ undefined, factory.createVariableDeclarationList(taggedTemplateStringDeclarations)),
        ]);
        const result = factory.updateSourceFile(visited, (0, ts_js_1.setTextRange)(factory.createNodeArray(statement), node.statements));
        exitSubtree(ancestorFacts);
        return result;
    }
    function visitTaggedTemplateExpression(node) {
        return (0, ts_js_1.processTaggedTemplateExpression)(context, node, visitor, currentSourceFile, recordTaggedTemplateString, ts_js_1.ProcessLevel.LiftRestriction);
    }
    /**
     * Visits a BinaryExpression that contains a destructuring assignment.
     *
     * @param node A BinaryExpression node.
     * @param expressionResultIsUnused Indicates the result of an expression is unused by the parent node (i.e., the left side of a comma or the
     * expression of an `ExpressionStatement`).
     */
    function visitBinaryExpression(node, expressionResultIsUnused) {
        if ((0, ts_js_1.isDestructuringAssignment)(node) && (0, ts_js_1.containsObjectRestOrSpread)(node.left)) {
            return (0, ts_js_1.flattenDestructuringAssignment)(node, visitor, context, 1 /* FlattenLevel.ObjectRest */, !expressionResultIsUnused);
        }
        if (node.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
            return factory.updateBinaryExpression(node, (0, ts_js_1.visitNode)(node.left, visitorWithUnusedExpressionResult, ts_js_1.isExpression), node.operatorToken, (0, ts_js_1.visitNode)(node.right, expressionResultIsUnused ? visitorWithUnusedExpressionResult : visitor, ts_js_1.isExpression));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * @param expressionResultIsUnused Indicates the result of an expression is unused by the parent node (i.e., the left side of a comma or the
     * expression of an `ExpressionStatement`).
     */
    function visitCommaListExpression(node, expressionResultIsUnused) {
        if (expressionResultIsUnused) {
            return (0, ts_js_1.visitEachChild)(node, visitorWithUnusedExpressionResult, context);
        }
        let result;
        for (let i = 0; i < node.elements.length; i++) {
            const element = node.elements[i];
            const visited = (0, ts_js_1.visitNode)(element, i < node.elements.length - 1 ? visitorWithUnusedExpressionResult : visitor, ts_js_1.isExpression);
            if (result || visited !== element) {
                result || (result = node.elements.slice(0, i));
                result.push(visited);
            }
        }
        const elements = result ? (0, ts_js_1.setTextRange)(factory.createNodeArray(result), node.elements) : node.elements;
        return factory.updateCommaListExpression(node, elements);
    }
    function visitCatchClause(node) {
        if (node.variableDeclaration &&
            (0, ts_js_1.isBindingPattern)(node.variableDeclaration.name) &&
            node.variableDeclaration.name.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
            const name = factory.getGeneratedNameForNode(node.variableDeclaration.name);
            const updatedDecl = factory.updateVariableDeclaration(node.variableDeclaration, node.variableDeclaration.name, /*exclamationToken*/ undefined, /*type*/ undefined, name);
            const visitedBindings = (0, ts_js_1.flattenDestructuringBinding)(updatedDecl, visitor, context, 1 /* FlattenLevel.ObjectRest */);
            let block = (0, ts_js_1.visitNode)(node.block, visitor, ts_js_1.isBlock);
            if ((0, ts_js_1.some)(visitedBindings)) {
                block = factory.updateBlock(block, [
                    factory.createVariableStatement(/*modifiers*/ undefined, visitedBindings),
                    ...block.statements,
                ]);
            }
            return factory.updateCatchClause(node, factory.updateVariableDeclaration(node.variableDeclaration, name, /*exclamationToken*/ undefined, /*type*/ undefined, /*initializer*/ undefined), block);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitVariableStatement(node) {
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            const savedExportedVariableStatement = exportedVariableStatement;
            exportedVariableStatement = true;
            const visited = (0, ts_js_1.visitEachChild)(node, visitor, context);
            exportedVariableStatement = savedExportedVariableStatement;
            return visited;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Visits a VariableDeclaration node with a binding pattern.
     *
     * @param node A VariableDeclaration node.
     */
    function visitVariableDeclaration(node) {
        if (exportedVariableStatement) {
            const savedExportedVariableStatement = exportedVariableStatement;
            exportedVariableStatement = false;
            const visited = visitVariableDeclarationWorker(node, /*exportedVariableStatement*/ true);
            exportedVariableStatement = savedExportedVariableStatement;
            return visited;
        }
        return visitVariableDeclarationWorker(node, /*exportedVariableStatement*/ false);
    }
    function visitVariableDeclarationWorker(node, exportedVariableStatement) {
        // If we are here it is because the name contains a binding pattern with a rest somewhere in it.
        if ((0, ts_js_1.isBindingPattern)(node.name) && node.name.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
            return (0, ts_js_1.flattenDestructuringBinding)(node, visitor, context, 1 /* FlattenLevel.ObjectRest */, 
            /*rval*/ undefined, exportedVariableStatement);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitForStatement(node) {
        return factory.updateForStatement(node, (0, ts_js_1.visitNode)(node.initializer, visitorWithUnusedExpressionResult, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, visitorWithUnusedExpressionResult, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, visitor, context));
    }
    function visitVoidExpression(node) {
        return (0, ts_js_1.visitEachChild)(node, visitorWithUnusedExpressionResult, context);
    }
    /**
     * Visits a ForOfStatement and converts it into a ES2015-compatible ForOfStatement.
     *
     * @param node A ForOfStatement.
     */
    function visitForOfStatement(node, outermostLabeledStatement) {
        const ancestorFacts = enterSubtree(0 /* HierarchyFacts.IterationStatementExcludes */, 2 /* HierarchyFacts.IterationStatementIncludes */);
        if (node.initializer.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */ ||
            (0, ts_js_1.isAssignmentPattern)(node.initializer) && (0, ts_js_1.containsObjectRestOrSpread)(node.initializer)) {
            node = transformForOfStatementWithObjectRest(node);
        }
        const result = node.awaitModifier ?
            transformForAwaitOfStatement(node, outermostLabeledStatement, ancestorFacts) :
            factory.restoreEnclosingLabel((0, ts_js_1.visitEachChild)(node, visitor, context), outermostLabeledStatement);
        exitSubtree(ancestorFacts);
        return result;
    }
    function transformForOfStatementWithObjectRest(node) {
        const initializerWithoutParens = (0, ts_js_1.skipParentheses)(node.initializer);
        if ((0, ts_js_1.isVariableDeclarationList)(initializerWithoutParens) || (0, ts_js_1.isAssignmentPattern)(initializerWithoutParens)) {
            let bodyLocation;
            let statementsLocation;
            const temp = factory.createTempVariable(/*recordTempVariable*/ undefined);
            const statements = [(0, ts_js_1.createForOfBindingStatement)(factory, initializerWithoutParens, temp)];
            if ((0, ts_js_1.isBlock)(node.statement)) {
                (0, ts_js_1.addRange)(statements, node.statement.statements);
                bodyLocation = node.statement;
                statementsLocation = node.statement.statements;
            }
            else if (node.statement) {
                (0, ts_js_1.append)(statements, node.statement);
                bodyLocation = node.statement;
                statementsLocation = node.statement;
            }
            return factory.updateForOfStatement(node, node.awaitModifier, (0, ts_js_1.setTextRange)(factory.createVariableDeclarationList([
                (0, ts_js_1.setTextRange)(factory.createVariableDeclaration(temp), node.initializer),
            ], 1 /* NodeFlags.Let */), node.initializer), node.expression, (0, ts_js_1.setTextRange)(factory.createBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(statements), statementsLocation), 
            /*multiLine*/ true), bodyLocation));
        }
        return node;
    }
    function convertForOfStatementHead(node, boundValue, nonUserCode) {
        const value = factory.createTempVariable(hoistVariableDeclaration);
        const iteratorValueExpression = factory.createAssignment(value, boundValue);
        const iteratorValueStatement = factory.createExpressionStatement(iteratorValueExpression);
        (0, ts_js_1.setSourceMapRange)(iteratorValueStatement, node.expression);
        const exitNonUserCodeExpression = factory.createAssignment(nonUserCode, factory.createFalse());
        const exitNonUserCodeStatement = factory.createExpressionStatement(exitNonUserCodeExpression);
        (0, ts_js_1.setSourceMapRange)(exitNonUserCodeStatement, node.expression);
        const statements = [iteratorValueStatement, exitNonUserCodeStatement];
        const binding = (0, ts_js_1.createForOfBindingStatement)(factory, node.initializer, value);
        statements.push((0, ts_js_1.visitNode)(binding, visitor, ts_js_1.isStatement));
        let bodyLocation;
        let statementsLocation;
        const statement = (0, ts_js_1.visitIterationBody)(node.statement, visitor, context);
        if ((0, ts_js_1.isBlock)(statement)) {
            (0, ts_js_1.addRange)(statements, statement.statements);
            bodyLocation = statement;
            statementsLocation = statement.statements;
        }
        else {
            statements.push(statement);
        }
        return (0, ts_js_1.setTextRange)(factory.createBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(statements), statementsLocation), 
        /*multiLine*/ true), bodyLocation);
    }
    function createDownlevelAwait(expression) {
        return enclosingFunctionFlags & 1 /* FunctionFlags.Generator */
            ? factory.createYieldExpression(/*asteriskToken*/ undefined, emitHelpers().createAwaitHelper(expression))
            : factory.createAwaitExpression(expression);
    }
    function transformForAwaitOfStatement(node, outermostLabeledStatement, ancestorFacts) {
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        const iterator = (0, ts_js_1.isIdentifier)(expression) ? factory.getGeneratedNameForNode(expression) : factory.createTempVariable(/*recordTempVariable*/ undefined);
        const result = (0, ts_js_1.isIdentifier)(expression) ? factory.getGeneratedNameForNode(iterator) : factory.createTempVariable(/*recordTempVariable*/ undefined);
        const nonUserCode = factory.createTempVariable(/*recordTempVariable*/ undefined);
        const done = factory.createTempVariable(hoistVariableDeclaration);
        const errorRecord = factory.createUniqueName("e");
        const catchVariable = factory.getGeneratedNameForNode(errorRecord);
        const returnMethod = factory.createTempVariable(/*recordTempVariable*/ undefined);
        const callValues = (0, ts_js_1.setTextRange)(emitHelpers().createAsyncValuesHelper(expression), node.expression);
        const callNext = factory.createCallExpression(factory.createPropertyAccessExpression(iterator, "next"), /*typeArguments*/ undefined, []);
        const getDone = factory.createPropertyAccessExpression(result, "done");
        const getValue = factory.createPropertyAccessExpression(result, "value");
        const callReturn = factory.createFunctionCallCall(returnMethod, iterator, []);
        hoistVariableDeclaration(errorRecord);
        hoistVariableDeclaration(returnMethod);
        // if we are enclosed in an outer loop ensure we reset 'errorRecord' per each iteration
        const initializer = ancestorFacts & 2 /* HierarchyFacts.IterationContainer */ ?
            factory.inlineExpressions([factory.createAssignment(errorRecord, factory.createVoidZero()), callValues]) :
            callValues;
        const forStatement = (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createForStatement(
        /*initializer*/ (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createVariableDeclarationList([
            factory.createVariableDeclaration(nonUserCode, /*exclamationToken*/ undefined, /*type*/ undefined, factory.createTrue()),
            (0, ts_js_1.setTextRange)(factory.createVariableDeclaration(iterator, /*exclamationToken*/ undefined, /*type*/ undefined, initializer), node.expression),
            factory.createVariableDeclaration(result),
        ]), node.expression), 4194304 /* EmitFlags.NoHoisting */), 
        /*condition*/ factory.inlineExpressions([
            factory.createAssignment(result, createDownlevelAwait(callNext)),
            factory.createAssignment(done, getDone),
            factory.createLogicalNot(done),
        ]), 
        /*incrementor*/ factory.createAssignment(nonUserCode, factory.createTrue()), 
        /*statement*/ convertForOfStatementHead(node, getValue, nonUserCode)), 
        /*location*/ node), 512 /* EmitFlags.NoTokenTrailingSourceMaps */);
        (0, ts_js_1.setOriginalNode)(forStatement, node);
        return factory.createTryStatement(factory.createBlock([
            factory.restoreEnclosingLabel(forStatement, outermostLabeledStatement),
        ]), factory.createCatchClause(factory.createVariableDeclaration(catchVariable), (0, ts_js_1.setEmitFlags)(factory.createBlock([
            factory.createExpressionStatement(factory.createAssignment(errorRecord, factory.createObjectLiteralExpression([
                factory.createPropertyAssignment("error", catchVariable),
            ]))),
        ]), 1 /* EmitFlags.SingleLine */)), factory.createBlock([
            factory.createTryStatement(
            /*tryBlock*/ factory.createBlock([
                (0, ts_js_1.setEmitFlags)(factory.createIfStatement(factory.createLogicalAnd(factory.createLogicalAnd(factory.createLogicalNot(nonUserCode), factory.createLogicalNot(done)), factory.createAssignment(returnMethod, factory.createPropertyAccessExpression(iterator, "return"))), factory.createExpressionStatement(createDownlevelAwait(callReturn))), 1 /* EmitFlags.SingleLine */),
            ]), 
            /*catchClause*/ undefined, 
            /*finallyBlock*/ (0, ts_js_1.setEmitFlags)(factory.createBlock([
                (0, ts_js_1.setEmitFlags)(factory.createIfStatement(errorRecord, factory.createThrowStatement(factory.createPropertyAccessExpression(errorRecord, "error"))), 1 /* EmitFlags.SingleLine */),
            ]), 1 /* EmitFlags.SingleLine */)),
        ]));
    }
    function parameterVisitor(node) {
        ts_js_1.Debug.assertNode(node, ts_js_1.isParameter);
        return visitParameter(node);
    }
    function visitParameter(node) {
        if (parametersWithPrecedingObjectRestOrSpread?.has(node)) {
            return factory.updateParameterDeclaration(node, 
            /*modifiers*/ undefined, node.dotDotDotToken, (0, ts_js_1.isBindingPattern)(node.name) ? factory.getGeneratedNameForNode(node) : node.name, 
            /*questionToken*/ undefined, 
            /*type*/ undefined, 
            /*initializer*/ undefined);
        }
        if (node.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
            // Binding patterns are converted into a generated name and are
            // evaluated inside the function body.
            return factory.updateParameterDeclaration(node, 
            /*modifiers*/ undefined, node.dotDotDotToken, factory.getGeneratedNameForNode(node), 
            /*questionToken*/ undefined, 
            /*type*/ undefined, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function collectParametersWithPrecedingObjectRestOrSpread(node) {
        let parameters;
        for (const parameter of node.parameters) {
            if (parameters) {
                parameters.add(parameter);
            }
            else if (parameter.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
                parameters = new Set();
            }
        }
        return parameters;
    }
    function visitConstructorDeclaration(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateConstructorDeclaration(node, node.modifiers, (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitGetAccessorDeclaration(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateGetAccessorDeclaration(node, node.modifiers, (0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isPropertyName), (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), 
        /*type*/ undefined, transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitSetAccessorDeclaration(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateSetAccessorDeclaration(node, node.modifiers, (0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isPropertyName), (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitMethodDeclaration(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateMethodDeclaration(node, enclosingFunctionFlags & 1 /* FunctionFlags.Generator */
            ? (0, ts_js_1.visitNodes)(node.modifiers, visitorNoAsyncModifier, ts_js_1.isModifierLike)
            : node.modifiers, enclosingFunctionFlags & 2 /* FunctionFlags.Async */
            ? undefined
            : node.asteriskToken, (0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isPropertyName), (0, ts_js_1.visitNode)(/*node*/ undefined, visitor, ts_js_1.isQuestionToken), 
        /*typeParameters*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), 
        /*type*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionBody(node) :
            transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitFunctionDeclaration(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateFunctionDeclaration(node, enclosingFunctionFlags & 1 /* FunctionFlags.Generator */
            ? (0, ts_js_1.visitNodes)(node.modifiers, visitorNoAsyncModifier, ts_js_1.isModifier)
            : node.modifiers, enclosingFunctionFlags & 2 /* FunctionFlags.Async */
            ? undefined
            : node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), 
        /*type*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionBody(node) :
            transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitArrowFunction(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateArrowFunction(node, node.modifiers, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), 
        /*type*/ undefined, node.equalsGreaterThanToken, transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function visitFunctionExpression(node) {
        const savedEnclosingFunctionFlags = enclosingFunctionFlags;
        const savedParametersWithPrecedingObjectRestOrSpread = parametersWithPrecedingObjectRestOrSpread;
        enclosingFunctionFlags = (0, ts_js_1.getFunctionFlags)(node);
        parametersWithPrecedingObjectRestOrSpread = collectParametersWithPrecedingObjectRestOrSpread(node);
        const updated = factory.updateFunctionExpression(node, enclosingFunctionFlags & 1 /* FunctionFlags.Generator */
            ? (0, ts_js_1.visitNodes)(node.modifiers, visitorNoAsyncModifier, ts_js_1.isModifier)
            : node.modifiers, enclosingFunctionFlags & 2 /* FunctionFlags.Async */
            ? undefined
            : node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, parameterVisitor, context), 
        /*type*/ undefined, enclosingFunctionFlags & 2 /* FunctionFlags.Async */ && enclosingFunctionFlags & 1 /* FunctionFlags.Generator */ ?
            transformAsyncGeneratorFunctionBody(node) :
            transformFunctionBody(node));
        enclosingFunctionFlags = savedEnclosingFunctionFlags;
        parametersWithPrecedingObjectRestOrSpread = savedParametersWithPrecedingObjectRestOrSpread;
        return updated;
    }
    function transformAsyncGeneratorFunctionParameterList(node) {
        if ((0, ts_js_1.isSimpleParameterList)(node.parameters)) {
            return (0, ts_js_1.visitParameterList)(node.parameters, visitor, context);
        }
        // Add fixed parameters to preserve the function's `length` property.
        const newParameters = [];
        for (const parameter of node.parameters) {
            if (parameter.initializer || parameter.dotDotDotToken) {
                break;
            }
            const newParameter = factory.createParameterDeclaration(
            /*modifiers*/ undefined, 
            /*dotDotDotToken*/ undefined, factory.getGeneratedNameForNode(parameter.name, 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */));
            newParameters.push(newParameter);
        }
        const newParametersArray = factory.createNodeArray(newParameters);
        (0, ts_js_1.setTextRange)(newParametersArray, node.parameters);
        return newParametersArray;
    }
    function transformAsyncGeneratorFunctionBody(node) {
        const innerParameters = !(0, ts_js_1.isSimpleParameterList)(node.parameters) ? (0, ts_js_1.visitParameterList)(node.parameters, visitor, context) : undefined;
        resumeLexicalEnvironment();
        const savedCapturedSuperProperties = capturedSuperProperties;
        const savedHasSuperElementAccess = hasSuperElementAccess;
        capturedSuperProperties = new Set();
        hasSuperElementAccess = false;
        const outerStatements = [];
        let asyncBody = factory.updateBlock(node.body, (0, ts_js_1.visitNodes)(node.body.statements, visitor, ts_js_1.isStatement));
        asyncBody = factory.updateBlock(asyncBody, factory.mergeLexicalEnvironment(asyncBody.statements, appendObjectRestAssignmentsIfNeeded(endLexicalEnvironment(), node)));
        const returnStatement = factory.createReturnStatement(emitHelpers().createAsyncGeneratorHelper(factory.createFunctionExpression(
        /*modifiers*/ undefined, factory.createToken(42 /* SyntaxKind.AsteriskToken */), node.name && factory.getGeneratedNameForNode(node.name), 
        /*typeParameters*/ undefined, innerParameters ?? [], 
        /*type*/ undefined, asyncBody), !!(hierarchyFacts & 1 /* HierarchyFacts.HasLexicalThis */)));
        // Minor optimization, emit `_super` helper to capture `super` access in an arrow.
        // This step isn't needed if we eventually transform this to ES5.
        const emitSuperHelpers = languageVersion >= 2 /* ScriptTarget.ES2015 */ && (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) || resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */));
        if (emitSuperHelpers) {
            enableSubstitutionForAsyncMethodsWithSuper();
            const variableStatement = (0, ts_js_1.createSuperAccessVariableStatement)(factory, resolver, node, capturedSuperProperties);
            substitutedSuperAccessors[(0, ts_js_1.getNodeId)(variableStatement)] = true;
            (0, ts_js_1.insertStatementsAfterStandardPrologue)(outerStatements, [variableStatement]);
        }
        outerStatements.push(returnStatement);
        const block = factory.updateBlock(node.body, outerStatements);
        if (emitSuperHelpers && hasSuperElementAccess) {
            if (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */)) {
                (0, ts_js_1.addEmitHelper)(block, ts_js_1.advancedAsyncSuperHelper);
            }
            else if (resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */)) {
                (0, ts_js_1.addEmitHelper)(block, ts_js_1.asyncSuperHelper);
            }
        }
        capturedSuperProperties = savedCapturedSuperProperties;
        hasSuperElementAccess = savedHasSuperElementAccess;
        return block;
    }
    function transformFunctionBody(node) {
        resumeLexicalEnvironment();
        let statementOffset = 0;
        const statements = [];
        const body = (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isConciseBody) ?? factory.createBlock([]);
        if ((0, ts_js_1.isBlock)(body)) {
            statementOffset = factory.copyPrologue(body.statements, statements, /*ensureUseStrict*/ false, visitor);
        }
        (0, ts_js_1.addRange)(statements, appendObjectRestAssignmentsIfNeeded(/*statements*/ undefined, node));
        const leadingStatements = endLexicalEnvironment();
        if (statementOffset > 0 || (0, ts_js_1.some)(statements) || (0, ts_js_1.some)(leadingStatements)) {
            const block = factory.converters.convertToFunctionBlock(body, /*multiLine*/ true);
            (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, leadingStatements);
            (0, ts_js_1.addRange)(statements, block.statements.slice(statementOffset));
            return factory.updateBlock(block, (0, ts_js_1.setTextRange)(factory.createNodeArray(statements), block.statements));
        }
        return body;
    }
    function appendObjectRestAssignmentsIfNeeded(statements, node) {
        let containsPrecedingObjectRestOrSpread = false;
        for (const parameter of node.parameters) {
            if (containsPrecedingObjectRestOrSpread) {
                if ((0, ts_js_1.isBindingPattern)(parameter.name)) {
                    // In cases where a binding pattern is simply '[]' or '{}',
                    // we usually don't want to emit a var declaration; however, in the presence
                    // of an initializer, we must emit that expression to preserve side effects.
                    //
                    // NOTE: see `insertDefaultValueAssignmentForBindingPattern` in es2015.ts
                    if (parameter.name.elements.length > 0) {
                        const declarations = (0, ts_js_1.flattenDestructuringBinding)(parameter, visitor, context, 0 /* FlattenLevel.All */, factory.getGeneratedNameForNode(parameter));
                        if ((0, ts_js_1.some)(declarations)) {
                            const declarationList = factory.createVariableDeclarationList(declarations);
                            const statement = factory.createVariableStatement(/*modifiers*/ undefined, declarationList);
                            (0, ts_js_1.setEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
                            statements = (0, ts_js_1.append)(statements, statement);
                        }
                    }
                    else if (parameter.initializer) {
                        const name = factory.getGeneratedNameForNode(parameter);
                        const initializer = (0, ts_js_1.visitNode)(parameter.initializer, visitor, ts_js_1.isExpression);
                        const assignment = factory.createAssignment(name, initializer);
                        const statement = factory.createExpressionStatement(assignment);
                        (0, ts_js_1.setEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
                        statements = (0, ts_js_1.append)(statements, statement);
                    }
                }
                else if (parameter.initializer) {
                    // Converts a parameter initializer into a function body statement, i.e.:
                    //
                    //  function f(x = 1) { }
                    //
                    // becomes
                    //
                    //  function f(x) {
                    //    if (typeof x === "undefined") { x = 1; }
                    //  }
                    const name = factory.cloneNode(parameter.name);
                    (0, ts_js_1.setTextRange)(name, parameter.name);
                    (0, ts_js_1.setEmitFlags)(name, 96 /* EmitFlags.NoSourceMap */);
                    const initializer = (0, ts_js_1.visitNode)(parameter.initializer, visitor, ts_js_1.isExpression);
                    (0, ts_js_1.addEmitFlags)(initializer, 96 /* EmitFlags.NoSourceMap */ | 3072 /* EmitFlags.NoComments */);
                    const assignment = factory.createAssignment(name, initializer);
                    (0, ts_js_1.setTextRange)(assignment, parameter);
                    (0, ts_js_1.setEmitFlags)(assignment, 3072 /* EmitFlags.NoComments */);
                    const block = factory.createBlock([factory.createExpressionStatement(assignment)]);
                    (0, ts_js_1.setTextRange)(block, parameter);
                    (0, ts_js_1.setEmitFlags)(block, 1 /* EmitFlags.SingleLine */ | 64 /* EmitFlags.NoTrailingSourceMap */ | 768 /* EmitFlags.NoTokenSourceMaps */ | 3072 /* EmitFlags.NoComments */);
                    const typeCheck = factory.createTypeCheck(factory.cloneNode(parameter.name), "undefined");
                    const statement = factory.createIfStatement(typeCheck, block);
                    (0, ts_js_1.startOnNewLine)(statement);
                    (0, ts_js_1.setTextRange)(statement, parameter);
                    (0, ts_js_1.setEmitFlags)(statement, 768 /* EmitFlags.NoTokenSourceMaps */ | 64 /* EmitFlags.NoTrailingSourceMap */ | 2097152 /* EmitFlags.CustomPrologue */ | 3072 /* EmitFlags.NoComments */);
                    statements = (0, ts_js_1.append)(statements, statement);
                }
            }
            else if (parameter.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
                containsPrecedingObjectRestOrSpread = true;
                const declarations = (0, ts_js_1.flattenDestructuringBinding)(parameter, visitor, context, 1 /* FlattenLevel.ObjectRest */, factory.getGeneratedNameForNode(parameter), 
                /*hoistTempVariables*/ false, 
                /*skipInitializer*/ true);
                if ((0, ts_js_1.some)(declarations)) {
                    const declarationList = factory.createVariableDeclarationList(declarations);
                    const statement = factory.createVariableStatement(/*modifiers*/ undefined, declarationList);
                    (0, ts_js_1.setEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
                    statements = (0, ts_js_1.append)(statements, statement);
                }
            }
        }
        return statements;
    }
    function enableSubstitutionForAsyncMethodsWithSuper() {
        if ((enabledSubstitutions & 1 /* ESNextSubstitutionFlags.AsyncMethodsWithSuper */) === 0) {
            enabledSubstitutions |= 1 /* ESNextSubstitutionFlags.AsyncMethodsWithSuper */;
            // We need to enable substitutions for call, property access, and element access
            // if we need to rewrite super calls.
            context.enableSubstitution(214 /* SyntaxKind.CallExpression */);
            context.enableSubstitution(212 /* SyntaxKind.PropertyAccessExpression */);
            context.enableSubstitution(213 /* SyntaxKind.ElementAccessExpression */);
            // We need to be notified when entering and exiting declarations that bind super.
            context.enableEmitNotification(264 /* SyntaxKind.ClassDeclaration */);
            context.enableEmitNotification(175 /* SyntaxKind.MethodDeclaration */);
            context.enableEmitNotification(178 /* SyntaxKind.GetAccessor */);
            context.enableEmitNotification(179 /* SyntaxKind.SetAccessor */);
            context.enableEmitNotification(177 /* SyntaxKind.Constructor */);
            // We need to be notified when entering the generated accessor arrow functions.
            context.enableEmitNotification(244 /* SyntaxKind.VariableStatement */);
        }
    }
    /**
     * Called by the printer just before a node is printed.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to be printed.
     * @param emitCallback The callback used to emit the node.
     */
    function onEmitNode(hint, node, emitCallback) {
        // If we need to support substitutions for `super` in an async method,
        // we should track it here.
        if (enabledSubstitutions & 1 /* ESNextSubstitutionFlags.AsyncMethodsWithSuper */ && isSuperContainer(node)) {
            const superContainerFlags = (resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */) ? 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */ : 0) | (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) ? 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */ : 0);
            if (superContainerFlags !== enclosingSuperContainerFlags) {
                const savedEnclosingSuperContainerFlags = enclosingSuperContainerFlags;
                enclosingSuperContainerFlags = superContainerFlags;
                previousOnEmitNode(hint, node, emitCallback);
                enclosingSuperContainerFlags = savedEnclosingSuperContainerFlags;
                return;
            }
        }
        // Disable substitution in the generated super accessor itself.
        else if (enabledSubstitutions && substitutedSuperAccessors[(0, ts_js_1.getNodeId)(node)]) {
            const savedEnclosingSuperContainerFlags = enclosingSuperContainerFlags;
            enclosingSuperContainerFlags = 0;
            previousOnEmitNode(hint, node, emitCallback);
            enclosingSuperContainerFlags = savedEnclosingSuperContainerFlags;
            return;
        }
        previousOnEmitNode(hint, node, emitCallback);
    }
    /**
     * Hooks node substitutions.
     *
     * @param hint The context for the emitter.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (hint === 1 /* EmitHint.Expression */ && enclosingSuperContainerFlags) {
            return substituteExpression(node);
        }
        return node;
    }
    function substituteExpression(node) {
        switch (node.kind) {
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                return substitutePropertyAccessExpression(node);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return substituteElementAccessExpression(node);
            case 214 /* SyntaxKind.CallExpression */:
                return substituteCallExpression(node);
        }
        return node;
    }
    function substitutePropertyAccessExpression(node) {
        if (node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
            return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createUniqueName("_super", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */), node.name), node);
        }
        return node;
    }
    function substituteElementAccessExpression(node) {
        if (node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
            return createSuperElementAccessInAsyncMethod(node.argumentExpression, node);
        }
        return node;
    }
    function substituteCallExpression(node) {
        const expression = node.expression;
        if ((0, ts_js_1.isSuperProperty)(expression)) {
            const argumentExpression = (0, ts_js_1.isPropertyAccessExpression)(expression)
                ? substitutePropertyAccessExpression(expression)
                : substituteElementAccessExpression(expression);
            return factory.createCallExpression(factory.createPropertyAccessExpression(argumentExpression, "call"), 
            /*typeArguments*/ undefined, [
                factory.createThis(),
                ...node.arguments,
            ]);
        }
        return node;
    }
    function isSuperContainer(node) {
        const kind = node.kind;
        return kind === 264 /* SyntaxKind.ClassDeclaration */
            || kind === 177 /* SyntaxKind.Constructor */
            || kind === 175 /* SyntaxKind.MethodDeclaration */
            || kind === 178 /* SyntaxKind.GetAccessor */
            || kind === 179 /* SyntaxKind.SetAccessor */;
    }
    function createSuperElementAccessInAsyncMethod(argumentExpression, location) {
        if (enclosingSuperContainerFlags & 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) {
            return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createCallExpression(factory.createIdentifier("_superIndex"), 
            /*typeArguments*/ undefined, [argumentExpression]), "value"), location);
        }
        else {
            return (0, ts_js_1.setTextRange)(factory.createCallExpression(factory.createIdentifier("_superIndex"), 
            /*typeArguments*/ undefined, [argumentExpression]), location);
        }
    }
}
