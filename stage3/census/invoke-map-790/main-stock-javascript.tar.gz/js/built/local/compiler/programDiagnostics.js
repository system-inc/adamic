"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createProgramDiagnostics = createProgramDiagnostics;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
function createProgramDiagnostics(getCompilerOptionsObjectLiteralSyntax) {
    // Only valid for a single program. The individual components can be reused under certain
    // circumstances (described below), but during `getCombinedDiagnostics`, position information
    // is applied to the diagnostics, so they cannot be shared between programs.
    let computedDiagnostics;
    // Valid between programs if `StructureIsReused.Completely`.
    let fileReasons = (0, ts_js_1.createMultiMap)();
    let fileProcessingDiagnostics;
    // Valid between programs if `StructureIsReused.Completely` and config file is identical.
    let commonSourceDirectory;
    let configDiagnostics;
    let lazyConfigDiagnostics;
    // Local state, only used during getDiagnostics
    let fileReasonsToChain;
    let reasonToRelatedInfo;
    return {
        addConfigDiagnostic(diag) {
            ts_js_1.Debug.assert(computedDiagnostics === undefined, "Cannot modify program diagnostic state after requesting combined diagnostics");
            (configDiagnostics ?? (configDiagnostics = (0, ts_js_1.createDiagnosticCollection)())).add(diag);
        },
        addLazyConfigDiagnostic(file, message, ...args) {
            ts_js_1.Debug.assert(computedDiagnostics === undefined, "Cannot modify program diagnostic state after requesting combined diagnostics");
            (lazyConfigDiagnostics ?? (lazyConfigDiagnostics = [])).push({ file, diagnostic: message, args });
        },
        addFileProcessingDiagnostic(diag) {
            ts_js_1.Debug.assert(computedDiagnostics === undefined, "Cannot modify program diagnostic state after requesting combined diagnostics");
            (fileProcessingDiagnostics ?? (fileProcessingDiagnostics = [])).push(diag);
        },
        setCommonSourceDirectory(directory) {
            commonSourceDirectory = directory;
        },
        reuseStateFromOldProgram(oldProgramDiagnostics, isConfigIdentical) {
            fileReasons = oldProgramDiagnostics.getFileReasons();
            fileProcessingDiagnostics = oldProgramDiagnostics.getFileProcessingDiagnostics();
            if (isConfigIdentical) {
                commonSourceDirectory = oldProgramDiagnostics.getCommonSourceDirectory();
                configDiagnostics = oldProgramDiagnostics.getConfigDiagnostics();
                lazyConfigDiagnostics = oldProgramDiagnostics.getLazyConfigDiagnostics();
            }
        },
        getFileProcessingDiagnostics() {
            return fileProcessingDiagnostics;
        },
        getFileReasons() {
            return fileReasons;
        },
        getCommonSourceDirectory() {
            return commonSourceDirectory;
        },
        getConfigDiagnostics() {
            return configDiagnostics;
        },
        getLazyConfigDiagnostics() {
            return lazyConfigDiagnostics;
        },
        getCombinedDiagnostics(program) {
            if (computedDiagnostics) {
                return computedDiagnostics;
            }
            computedDiagnostics = (0, ts_js_1.createDiagnosticCollection)();
            configDiagnostics?.getDiagnostics().forEach(d => computedDiagnostics.add(d));
            fileProcessingDiagnostics?.forEach(diagnostic => {
                switch (diagnostic.kind) {
                    case 1 /* FilePreprocessingDiagnosticsKind.FilePreprocessingFileExplainingDiagnostic */:
                        return computedDiagnostics.add(createDiagnosticExplainingFile(program, diagnostic.file && program.getSourceFileByPath(diagnostic.file), diagnostic.fileProcessingReason, diagnostic.diagnostic, diagnostic.args || ts_js_1.emptyArray));
                    case 0 /* FilePreprocessingDiagnosticsKind.FilePreprocessingLibReferenceDiagnostic */:
                        return computedDiagnostics.add(filePreprocessingLibreferenceDiagnostic(program, diagnostic));
                    case 2 /* FilePreprocessingDiagnosticsKind.ResolutionDiagnostics */:
                        return diagnostic.diagnostics.forEach(d => computedDiagnostics.add(d));
                    default:
                        ts_js_1.Debug.assertNever(diagnostic);
                }
            });
            lazyConfigDiagnostics?.forEach(({ file, diagnostic, args }) => computedDiagnostics.add(createDiagnosticExplainingFile(program, file, /*fileProcessingReason*/ undefined, diagnostic, args)));
            fileReasonsToChain = undefined;
            reasonToRelatedInfo = undefined;
            return computedDiagnostics;
        },
    };
    function filePreprocessingLibreferenceDiagnostic(program, { reason }) {
        const { file, pos, end } = (0, ts_js_1.getReferencedFileLocation)(program, reason);
        const libReference = file.libReferenceDirectives[reason.index];
        const libName = (0, ts_js_1.getLibNameFromLibReference)(libReference);
        const unqualifiedLibName = (0, ts_js_1.removeSuffix)((0, ts_js_1.removePrefix)(libName, "lib."), ".d.ts");
        const suggestion = (0, ts_js_1.getSpellingSuggestion)(unqualifiedLibName, ts_js_1.libs, ts_js_1.identity);
        return (0, ts_js_1.createFileDiagnostic)(file, ts_js_1.Debug.checkDefined(pos), ts_js_1.Debug.checkDefined(end) - pos, suggestion ? ts_js_1.Diagnostics.Cannot_find_lib_definition_for_0_Did_you_mean_1 : ts_js_1.Diagnostics.Cannot_find_lib_definition_for_0, libName, suggestion);
    }
    function createDiagnosticExplainingFile(program, file, fileProcessingReason, diagnostic, args) {
        let seenReasons;
        let fileIncludeReasons;
        let relatedInfo;
        let fileIncludeReasonDetails;
        let redirectInfo;
        let chain;
        const reasons = file && fileReasons.get(file.path);
        let locationReason = (0, ts_js_1.isReferencedFile)(fileProcessingReason) ? fileProcessingReason : undefined;
        let cachedChain = file && fileReasonsToChain?.get(file.path);
        if (cachedChain) {
            if (cachedChain.fileIncludeReasonDetails) {
                seenReasons = new Set(reasons);
                reasons?.forEach(populateRelatedInfo);
            }
            else {
                reasons?.forEach(processReason);
            }
            redirectInfo = cachedChain.redirectInfo;
        }
        else {
            reasons?.forEach(processReason);
            redirectInfo = file && (0, ts_js_1.explainIfFileIsRedirectAndImpliedFormat)(file, program.getCompilerOptionsForFile(file));
        }
        if (fileProcessingReason)
            processReason(fileProcessingReason);
        const processedExtraReason = seenReasons?.size !== reasons?.length;
        // If we have location and there is only one reason file is in which is the location, dont add details for file include
        if (locationReason && seenReasons?.size === 1)
            seenReasons = undefined;
        if (seenReasons && cachedChain) {
            if (cachedChain.details && !processedExtraReason) {
                chain = (0, ts_js_1.chainDiagnosticMessages)(cachedChain.details, diagnostic, ...args ?? ts_js_1.emptyArray);
            }
            else if (cachedChain.fileIncludeReasonDetails) {
                if (!processedExtraReason) {
                    if (!cachedFileIncludeDetailsHasProcessedExtraReason()) {
                        fileIncludeReasonDetails = cachedChain.fileIncludeReasonDetails;
                    }
                    else {
                        fileIncludeReasons = cachedChain.fileIncludeReasonDetails.next.slice(0, reasons.length);
                    }
                }
                else {
                    if (!cachedFileIncludeDetailsHasProcessedExtraReason()) {
                        fileIncludeReasons = [...cachedChain.fileIncludeReasonDetails.next, fileIncludeReasons[0]];
                    }
                    else {
                        fileIncludeReasons = (0, ts_js_1.append)(cachedChain.fileIncludeReasonDetails.next.slice(0, reasons.length), fileIncludeReasons[0]);
                    }
                }
            }
        }
        if (!chain) {
            if (!fileIncludeReasonDetails)
                fileIncludeReasonDetails = seenReasons && (0, ts_js_1.chainDiagnosticMessages)(fileIncludeReasons, ts_js_1.Diagnostics.The_file_is_in_the_program_because_Colon);
            chain = (0, ts_js_1.chainDiagnosticMessages)(redirectInfo ?
                fileIncludeReasonDetails ? [fileIncludeReasonDetails, ...redirectInfo] : redirectInfo :
                fileIncludeReasonDetails, diagnostic, ...args || ts_js_1.emptyArray);
        }
        // This is chain's next contains:
        //   - File is in program because:
        //      - Files reasons listed
        //      - extra reason if its not already processed - this happens in case sensitive file system where files differ in casing and we are giving reasons for two files so reason is not in file's reason
        //     fyi above whole secton is ommited if we have single reason and we are reporting at that reason's location
        //   - redirect and additional information about file
        // So cache result if we havent ommited file include reasons
        if (file) {
            if (cachedChain) {
                // Cache new fileIncludeDetails if we have update
                // Or if we had cached with more details than the reasons
                if (!cachedChain.fileIncludeReasonDetails || (!processedExtraReason && fileIncludeReasonDetails)) {
                    cachedChain.fileIncludeReasonDetails = fileIncludeReasonDetails;
                }
            }
            else {
                (fileReasonsToChain ?? (fileReasonsToChain = new Map())).set(file.path, cachedChain = { fileIncludeReasonDetails, redirectInfo });
            }
            // If we didnt compute extra file include reason , cache the details to use directly
            if (!cachedChain.details && !processedExtraReason)
                cachedChain.details = chain.next;
        }
        const location = locationReason && (0, ts_js_1.getReferencedFileLocation)(program, locationReason);
        return location && (0, ts_js_1.isReferenceFileLocation)(location) ?
            (0, ts_js_1.createFileDiagnosticFromMessageChain)(location.file, location.pos, location.end - location.pos, chain, relatedInfo) :
            (0, ts_js_1.createCompilerDiagnosticFromMessageChain)(chain, relatedInfo);
        function processReason(reason) {
            if (seenReasons?.has(reason))
                return;
            (seenReasons ?? (seenReasons = new Set())).add(reason);
            (fileIncludeReasons ?? (fileIncludeReasons = [])).push((0, ts_js_1.fileIncludeReasonToDiagnostics)(program, reason));
            populateRelatedInfo(reason);
        }
        function populateRelatedInfo(reason) {
            if (!locationReason && (0, ts_js_1.isReferencedFile)(reason)) {
                // Report error at first reference file or file currently in processing and dont report in related information
                locationReason = reason;
            }
            else if (locationReason !== reason) {
                relatedInfo = (0, ts_js_1.append)(relatedInfo, getFileIncludeReasonToRelatedInformation(program, reason));
            }
        }
        function cachedFileIncludeDetailsHasProcessedExtraReason() {
            return cachedChain.fileIncludeReasonDetails.next?.length !== reasons?.length;
        }
    }
    function getFileIncludeReasonToRelatedInformation(program, reason) {
        let relatedInfo = reasonToRelatedInfo?.get(reason);
        if (relatedInfo === undefined)
            (reasonToRelatedInfo ?? (reasonToRelatedInfo = new Map())).set(reason, relatedInfo = fileIncludeReasonToRelatedInformation(program, reason) ?? false);
        return relatedInfo || undefined;
    }
    function fileIncludeReasonToRelatedInformation(program, reason) {
        if ((0, ts_js_1.isReferencedFile)(reason)) {
            const referenceLocation = (0, ts_js_1.getReferencedFileLocation)(program, reason);
            let message;
            switch (reason.kind) {
                case ts_js_1.FileIncludeKind.Import:
                    message = ts_js_1.Diagnostics.File_is_included_via_import_here;
                    break;
                case ts_js_1.FileIncludeKind.ReferenceFile:
                    message = ts_js_1.Diagnostics.File_is_included_via_reference_here;
                    break;
                case ts_js_1.FileIncludeKind.TypeReferenceDirective:
                    message = ts_js_1.Diagnostics.File_is_included_via_type_library_reference_here;
                    break;
                case ts_js_1.FileIncludeKind.LibReferenceDirective:
                    message = ts_js_1.Diagnostics.File_is_included_via_library_reference_here;
                    break;
                default:
                    ts_js_1.Debug.assertNever(reason);
            }
            return (0, ts_js_1.isReferenceFileLocation)(referenceLocation) ? (0, ts_js_1.createFileDiagnostic)(referenceLocation.file, referenceLocation.pos, referenceLocation.end - referenceLocation.pos, message) : undefined;
        }
        const currentDirectory = program.getCurrentDirectory();
        const rootNames = program.getRootFileNames();
        const options = program.getCompilerOptions();
        if (!options.configFile)
            return undefined;
        let configFileNode;
        let message;
        switch (reason.kind) {
            case ts_js_1.FileIncludeKind.RootFile:
                if (!options.configFile.configFileSpecs)
                    return undefined;
                const fileName = (0, ts_js_1.getNormalizedAbsolutePath)(rootNames[reason.index], currentDirectory);
                const matchedByFiles = (0, ts_js_1.getMatchedFileSpec)(program, fileName);
                if (matchedByFiles) {
                    configFileNode = (0, ts_js_1.getTsConfigPropArrayElementValue)(options.configFile, "files", matchedByFiles);
                    message = ts_js_1.Diagnostics.File_is_matched_by_files_list_specified_here;
                    break;
                }
                const matchedByInclude = (0, ts_js_1.getMatchedIncludeSpec)(program, fileName);
                // Could be additional files specified as roots
                if (!matchedByInclude || !(0, ts_js_1.isString)(matchedByInclude))
                    return undefined;
                configFileNode = (0, ts_js_1.getTsConfigPropArrayElementValue)(options.configFile, "include", matchedByInclude);
                message = ts_js_1.Diagnostics.File_is_matched_by_include_pattern_specified_here;
                break;
            case ts_js_1.FileIncludeKind.SourceFromProjectReference:
            case ts_js_1.FileIncludeKind.OutputFromProjectReference:
                const resolvedProjectReferences = program.getResolvedProjectReferences();
                const projectReferences = program.getProjectReferences();
                const referencedResolvedRef = ts_js_1.Debug.checkDefined(resolvedProjectReferences?.[reason.index]);
                const referenceInfo = (0, ts_js_1.forEachProjectReference)(projectReferences, resolvedProjectReferences, (resolvedRef, parent, index) => resolvedRef === referencedResolvedRef ?
                    { sourceFile: parent?.sourceFile || options.configFile, index } :
                    undefined);
                if (!referenceInfo)
                    return undefined;
                const { sourceFile, index } = referenceInfo;
                const referencesSyntax = (0, ts_js_1.forEachTsConfigPropArray)(sourceFile, "references", property => (0, ts_js_1.isArrayLiteralExpression)(property.initializer) ? property.initializer : undefined);
                return referencesSyntax && referencesSyntax.elements.length > index ?
                    (0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, referencesSyntax.elements[index], reason.kind === ts_js_1.FileIncludeKind.OutputFromProjectReference ?
                        ts_js_1.Diagnostics.File_is_output_from_referenced_project_specified_here :
                        ts_js_1.Diagnostics.File_is_source_from_referenced_project_specified_here) :
                    undefined;
            case ts_js_1.FileIncludeKind.AutomaticTypeDirectiveFile:
                configFileNode = (0, ts_js_1.getOptionsSyntaxByArrayElementValue)(getCompilerOptionsObjectLiteralSyntax(), "types", (0, ts_js_1.usesWildcardTypes)(options) ? "*" : reason.typeReference);
                message = ts_js_1.Diagnostics.File_is_entry_point_of_type_library_specified_here;
                break;
            case ts_js_1.FileIncludeKind.LibFile:
                if (reason.index !== undefined) {
                    configFileNode = (0, ts_js_1.getOptionsSyntaxByArrayElementValue)(getCompilerOptionsObjectLiteralSyntax(), "lib", options.lib[reason.index]);
                    message = ts_js_1.Diagnostics.File_is_library_specified_here;
                    break;
                }
                const target = (0, ts_js_1.getNameOfScriptTarget)((0, ts_js_1.getEmitScriptTarget)(options));
                configFileNode = target ? (0, ts_js_1.getOptionsSyntaxByValue)(getCompilerOptionsObjectLiteralSyntax(), "target", target) : undefined;
                message = ts_js_1.Diagnostics.File_is_default_library_for_target_specified_here;
                break;
            default:
                ts_js_1.Debug.assertNever(reason);
        }
        return configFileNode && (0, ts_js_1.createDiagnosticForNodeInSourceFile)(options.configFile, configFileNode, message);
    }
}
