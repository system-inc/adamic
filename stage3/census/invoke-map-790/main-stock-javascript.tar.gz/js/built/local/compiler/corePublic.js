"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Comparison = exports.version = exports.versionMajorMinor = void 0;
// WARNING: The script `configurePrerelease.ts` uses a regexp to parse out these values.
// If changing the text in this section, be sure to test `configurePrerelease` too.
exports.versionMajorMinor = "6.0";
// The following is baselined as a literal template type without intervention
/** The version of the TypeScript compiler release */
exports.version = "6.0.3";
/** @internal */
var Comparison;
(function (Comparison) {
    Comparison[Comparison["LessThan"] = -1] = "LessThan";
    Comparison[Comparison["EqualTo"] = 0] = "EqualTo";
    Comparison[Comparison["GreaterThan"] = 1] = "GreaterThan";
})(Comparison || (exports.Comparison = Comparison = {}));
