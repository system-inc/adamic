"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nodeCoreModules = exports.exclusivelyPrefixedNodeCoreModules = exports.unprefixedNodeCoreModules = exports.emptyFileSystemEntries = exports.ModuleSpecifierEnding = exports.extensionsNotSupportingExtensionlessResolution = exports.supportedTSImplementationExtensions = exports.supportedDeclarationExtensions = exports.supportedJSExtensionsFlat = exports.supportedTSExtensionsFlat = exports.getAlwaysStrict = exports.getUseDefineForClassFields = exports.getAllowJSCompilerOption = exports.getAreDeclarationMapsEnabled = exports.isIncrementalCompilation = exports.shouldPreserveConstEnums = exports.getEmitDeclarations = exports.getResolveJsonModule = exports.getResolvePackageJsonImports = exports.getResolvePackageJsonExports = exports.getAllowSyntheticDefaultImports = exports.getESModuleInterop = exports.getIsolatedModules = exports.getEmitModuleDetectionKind = exports.getEmitModuleResolutionKind = exports.getEmitModuleKind = exports.getEmitScriptTarget = exports.getAllowImportingTsExtensions = exports.computedOptions = exports.objectAllocator = exports.OperatorPrecedence = exports.Associativity = exports.FunctionFlags = exports.AssignmentKind = exports.GetLiteralTextFlags = exports.getScriptTargetFeatures = exports.defaultHoverMaximumTruncationLength = exports.noTruncationMaximumTruncationLength = exports.defaultMaximumTruncationLength = exports.externalHelpersModuleNameText = exports.resolvingEmptyArray = void 0;
exports.getDeclarationOfKind = getDeclarationOfKind;
exports.getDeclarationsOfKind = getDeclarationsOfKind;
exports.createSymbolTable = createSymbolTable;
exports.isTransientSymbol = isTransientSymbol;
exports.isExternalModuleSymbol = isExternalModuleSymbol;
exports.changesAffectModuleResolution = changesAffectModuleResolution;
exports.changesAffectingProgramStructure = changesAffectingProgramStructure;
exports.optionsHaveChanges = optionsHaveChanges;
exports.forEachAncestor = forEachAncestor;
exports.forEachEntry = forEachEntry;
exports.forEachKey = forEachKey;
exports.copyEntries = copyEntries;
exports.usingSingleLineStringWriter = usingSingleLineStringWriter;
exports.getFullWidth = getFullWidth;
exports.projectReferenceIsEqualTo = projectReferenceIsEqualTo;
exports.moduleResolutionIsEqualTo = moduleResolutionIsEqualTo;
exports.getResolvedModuleFromResolution = getResolvedModuleFromResolution;
exports.getResolvedTypeReferenceDirectiveFromResolution = getResolvedTypeReferenceDirectiveFromResolution;
exports.createModuleNotFoundChain = createModuleNotFoundChain;
exports.createModeMismatchDetails = createModeMismatchDetails;
exports.packageIdToPackageName = packageIdToPackageName;
exports.packageIdToString = packageIdToString;
exports.typeDirectiveIsEqualTo = typeDirectiveIsEqualTo;
exports.hasChangesInResolutions = hasChangesInResolutions;
exports.containsParseError = containsParseError;
exports.getSourceFileOfNode = getSourceFileOfNode;
exports.getSourceFileOfModule = getSourceFileOfModule;
exports.isPlainJsFile = isPlainJsFile;
exports.isStatementWithLocals = isStatementWithLocals;
exports.getStartPositionOfLine = getStartPositionOfLine;
exports.nodePosToString = nodePosToString;
exports.getEndLinePosition = getEndLinePosition;
exports.isFileLevelUniqueName = isFileLevelUniqueName;
exports.nodeIsMissing = nodeIsMissing;
exports.nodeIsPresent = nodeIsPresent;
exports.isGrammarError = isGrammarError;
exports.insertStatementsAfterStandardPrologue = insertStatementsAfterStandardPrologue;
exports.insertStatementsAfterCustomPrologue = insertStatementsAfterCustomPrologue;
exports.insertStatementAfterStandardPrologue = insertStatementAfterStandardPrologue;
exports.insertStatementAfterCustomPrologue = insertStatementAfterCustomPrologue;
exports.isRecognizedTripleSlashComment = isRecognizedTripleSlashComment;
exports.isPinnedComment = isPinnedComment;
exports.createCommentDirectivesMap = createCommentDirectivesMap;
exports.getTokenPosOfNode = getTokenPosOfNode;
exports.getNonDecoratorTokenPosOfNode = getNonDecoratorTokenPosOfNode;
exports.getSourceTextOfNodeFromSourceFile = getSourceTextOfNodeFromSourceFile;
exports.isExportNamespaceAsDefaultDeclaration = isExportNamespaceAsDefaultDeclaration;
exports.moduleExportNameTextUnescaped = moduleExportNameTextUnescaped;
exports.moduleExportNameTextEscaped = moduleExportNameTextEscaped;
exports.moduleExportNameIsDefault = moduleExportNameIsDefault;
exports.getTextOfNodeFromSourceText = getTextOfNodeFromSourceText;
exports.getTextOfNode = getTextOfNode;
exports.indexOfNode = indexOfNode;
exports.getEmitFlags = getEmitFlags;
exports.getInternalEmitFlags = getInternalEmitFlags;
exports.getLiteralText = getLiteralText;
exports.getTextOfConstantValue = getTextOfConstantValue;
exports.makeIdentifierFromModuleName = makeIdentifierFromModuleName;
exports.isBlockOrCatchScoped = isBlockOrCatchScoped;
exports.isCatchClauseVariableDeclarationOrBindingElement = isCatchClauseVariableDeclarationOrBindingElement;
exports.isAmbientModule = isAmbientModule;
exports.isModuleWithStringLiteralName = isModuleWithStringLiteralName;
exports.isNonGlobalAmbientModule = isNonGlobalAmbientModule;
exports.isShorthandAmbientModuleSymbol = isShorthandAmbientModuleSymbol;
exports.isBlockScopedContainerTopLevel = isBlockScopedContainerTopLevel;
exports.isGlobalScopeAugmentation = isGlobalScopeAugmentation;
exports.isExternalModuleAugmentation = isExternalModuleAugmentation;
exports.isModuleAugmentationExternal = isModuleAugmentationExternal;
exports.getNonAugmentationDeclaration = getNonAugmentationDeclaration;
exports.isEffectiveExternalModule = isEffectiveExternalModule;
exports.isEffectiveStrictModeSourceFile = isEffectiveStrictModeSourceFile;
exports.isAmbientPropertyDeclaration = isAmbientPropertyDeclaration;
exports.isBlockScope = isBlockScope;
exports.isDeclarationWithTypeParameters = isDeclarationWithTypeParameters;
exports.isDeclarationWithTypeParameterChildren = isDeclarationWithTypeParameterChildren;
exports.isAnyImportSyntax = isAnyImportSyntax;
exports.isAnyImportOrBareOrAccessedRequire = isAnyImportOrBareOrAccessedRequire;
exports.isAnyImportOrRequireStatement = isAnyImportOrRequireStatement;
exports.isLateVisibilityPaintedStatement = isLateVisibilityPaintedStatement;
exports.hasPossibleExternalModuleReference = hasPossibleExternalModuleReference;
exports.isAnyImportOrReExport = isAnyImportOrReExport;
exports.getEnclosingContainer = getEnclosingContainer;
exports.getEnclosingBlockScopeContainer = getEnclosingBlockScopeContainer;
exports.forEachEnclosingBlockScopeContainer = forEachEnclosingBlockScopeContainer;
exports.declarationNameToString = declarationNameToString;
exports.getNameFromIndexInfo = getNameFromIndexInfo;
exports.isComputedNonLiteralName = isComputedNonLiteralName;
exports.tryGetTextOfPropertyName = tryGetTextOfPropertyName;
exports.getTextOfPropertyName = getTextOfPropertyName;
exports.entityNameToString = entityNameToString;
exports.createDiagnosticForNode = createDiagnosticForNode;
exports.createDiagnosticForNodeArray = createDiagnosticForNodeArray;
exports.createDiagnosticForNodeInSourceFile = createDiagnosticForNodeInSourceFile;
exports.createDiagnosticForNodeFromMessageChain = createDiagnosticForNodeFromMessageChain;
exports.createDiagnosticForNodeArrayFromMessageChain = createDiagnosticForNodeArrayFromMessageChain;
exports.createFileDiagnosticFromMessageChain = createFileDiagnosticFromMessageChain;
exports.createDiagnosticForFileFromMessageChain = createDiagnosticForFileFromMessageChain;
exports.createDiagnosticMessageChainFromDiagnostic = createDiagnosticMessageChainFromDiagnostic;
exports.createDiagnosticForRange = createDiagnosticForRange;
exports.getCanonicalDiagnostic = getCanonicalDiagnostic;
exports.getSpanOfTokenAtPosition = getSpanOfTokenAtPosition;
exports.scanTokenAtPosition = scanTokenAtPosition;
exports.getErrorSpanForNode = getErrorSpanForNode;
exports.isGlobalSourceFile = isGlobalSourceFile;
exports.isExternalOrCommonJsModule = isExternalOrCommonJsModule;
exports.isJsonSourceFile = isJsonSourceFile;
exports.isEnumConst = isEnumConst;
exports.isDeclarationReadonly = isDeclarationReadonly;
exports.isVarAwaitUsing = isVarAwaitUsing;
exports.isVarUsing = isVarUsing;
exports.isVarConst = isVarConst;
exports.isVarConstLike = isVarConstLike;
exports.isLet = isLet;
exports.isSuperCall = isSuperCall;
exports.isImportCall = isImportCall;
exports.isImportMeta = isImportMeta;
exports.isLiteralImportTypeNode = isLiteralImportTypeNode;
exports.isPrologueDirective = isPrologueDirective;
exports.isCustomPrologue = isCustomPrologue;
exports.isHoistedFunction = isHoistedFunction;
exports.isHoistedVariableStatement = isHoistedVariableStatement;
exports.getLeadingCommentRangesOfNode = getLeadingCommentRangesOfNode;
exports.getJSDocCommentRanges = getJSDocCommentRanges;
exports.isPartOfTypeNode = isPartOfTypeNode;
exports.forEachReturnStatement = forEachReturnStatement;
exports.forEachYieldExpression = forEachYieldExpression;
exports.getRestParameterElementType = getRestParameterElementType;
exports.getMembersOfDeclaration = getMembersOfDeclaration;
exports.isVariableLike = isVariableLike;
exports.isVariableDeclarationInVariableStatement = isVariableDeclarationInVariableStatement;
exports.isCommonJsExportedExpression = isCommonJsExportedExpression;
exports.isCommonJsExportPropertyAssignment = isCommonJsExportPropertyAssignment;
exports.isValidESSymbolDeclaration = isValidESSymbolDeclaration;
exports.introducesArgumentsExoticObject = introducesArgumentsExoticObject;
exports.unwrapInnermostStatementOfLabel = unwrapInnermostStatementOfLabel;
exports.isFunctionBlock = isFunctionBlock;
exports.isObjectLiteralMethod = isObjectLiteralMethod;
exports.isObjectLiteralOrClassExpressionMethodOrAccessor = isObjectLiteralOrClassExpressionMethodOrAccessor;
exports.isIdentifierTypePredicate = isIdentifierTypePredicate;
exports.isThisTypePredicate = isThisTypePredicate;
exports.forEachPropertyAssignment = forEachPropertyAssignment;
exports.getTsConfigObjectLiteralExpression = getTsConfigObjectLiteralExpression;
exports.getTsConfigPropArrayElementValue = getTsConfigPropArrayElementValue;
exports.forEachTsConfigPropArray = forEachTsConfigPropArray;
exports.getContainingFunction = getContainingFunction;
exports.getContainingFunctionDeclaration = getContainingFunctionDeclaration;
exports.getContainingClass = getContainingClass;
exports.getContainingClassStaticBlock = getContainingClassStaticBlock;
exports.getContainingFunctionOrClassStaticBlock = getContainingFunctionOrClassStaticBlock;
exports.getContainingClassExcludingClassDecorators = getContainingClassExcludingClassDecorators;
exports.getThisContainer = getThisContainer;
exports.isThisContainerOrFunctionBlock = isThisContainerOrFunctionBlock;
exports.isInTopLevelContext = isInTopLevelContext;
exports.getNewTargetContainer = getNewTargetContainer;
exports.getSuperContainer = getSuperContainer;
exports.getImmediatelyInvokedFunctionExpression = getImmediatelyInvokedFunctionExpression;
exports.isSuperProperty = isSuperProperty;
exports.isThisProperty = isThisProperty;
exports.isThisInitializedDeclaration = isThisInitializedDeclaration;
exports.isThisInitializedObjectBindingExpression = isThisInitializedObjectBindingExpression;
exports.getEntityNameFromTypeNode = getEntityNameFromTypeNode;
exports.getInvokedExpression = getInvokedExpression;
exports.nodeCanBeDecorated = nodeCanBeDecorated;
exports.nodeIsDecorated = nodeIsDecorated;
exports.nodeOrChildIsDecorated = nodeOrChildIsDecorated;
exports.childIsDecorated = childIsDecorated;
exports.classOrConstructorParameterIsDecorated = classOrConstructorParameterIsDecorated;
exports.classElementOrClassElementParameterIsDecorated = classElementOrClassElementParameterIsDecorated;
exports.isEmptyStringLiteral = isEmptyStringLiteral;
exports.isJSXTagName = isJSXTagName;
exports.isExpressionNode = isExpressionNode;
exports.isInExpressionContext = isInExpressionContext;
exports.isPartOfTypeQuery = isPartOfTypeQuery;
exports.isNamespaceReexportDeclaration = isNamespaceReexportDeclaration;
exports.isExternalModuleImportEqualsDeclaration = isExternalModuleImportEqualsDeclaration;
exports.getExternalModuleImportEqualsDeclarationExpression = getExternalModuleImportEqualsDeclarationExpression;
exports.getExternalModuleRequireArgument = getExternalModuleRequireArgument;
exports.isInternalModuleImportEqualsDeclaration = isInternalModuleImportEqualsDeclaration;
exports.isFullSourceFile = isFullSourceFile;
exports.isSourceFileJS = isSourceFileJS;
exports.isInJSFile = isInJSFile;
exports.isInJsonFile = isInJsonFile;
exports.isSourceFileNotJson = isSourceFileNotJson;
exports.isInJSDoc = isInJSDoc;
exports.isJSDocIndexSignature = isJSDocIndexSignature;
exports.isRequireCall = isRequireCall;
exports.isVariableDeclarationInitializedToRequire = isVariableDeclarationInitializedToRequire;
exports.isVariableDeclarationInitializedToBareOrAccessedRequire = isVariableDeclarationInitializedToBareOrAccessedRequire;
exports.isBindingElementOfBareOrAccessedRequire = isBindingElementOfBareOrAccessedRequire;
exports.getModuleSpecifierOfBareOrAccessedRequire = getModuleSpecifierOfBareOrAccessedRequire;
exports.isRequireVariableStatement = isRequireVariableStatement;
exports.isSingleOrDoubleQuote = isSingleOrDoubleQuote;
exports.isStringDoubleQuoted = isStringDoubleQuoted;
exports.isAssignmentDeclaration = isAssignmentDeclaration;
exports.getEffectiveInitializer = getEffectiveInitializer;
exports.getDeclaredExpandoInitializer = getDeclaredExpandoInitializer;
exports.getAssignedExpandoInitializer = getAssignedExpandoInitializer;
exports.getExpandoInitializer = getExpandoInitializer;
exports.isDefaultedExpandoInitializer = isDefaultedExpandoInitializer;
exports.getNameOfExpando = getNameOfExpando;
exports.isSameEntityName = isSameEntityName;
exports.getRightMostAssignedExpression = getRightMostAssignedExpression;
exports.isExportsIdentifier = isExportsIdentifier;
exports.isModuleIdentifier = isModuleIdentifier;
exports.isModuleExportsAccessExpression = isModuleExportsAccessExpression;
exports.getAssignmentDeclarationKind = getAssignmentDeclarationKind;
exports.isBindableObjectDefinePropertyCall = isBindableObjectDefinePropertyCall;
exports.isBindableStaticAccessExpression = isBindableStaticAccessExpression;
exports.isBindableStaticElementAccessExpression = isBindableStaticElementAccessExpression;
exports.isBindableStaticNameExpression = isBindableStaticNameExpression;
exports.getNameOrArgument = getNameOrArgument;
exports.getElementOrPropertyAccessArgumentExpressionOrName = getElementOrPropertyAccessArgumentExpressionOrName;
exports.getElementOrPropertyAccessName = getElementOrPropertyAccessName;
exports.getAssignmentDeclarationPropertyAccessKind = getAssignmentDeclarationPropertyAccessKind;
exports.getInitializerOfBinaryExpression = getInitializerOfBinaryExpression;
exports.isPrototypePropertyAssignment = isPrototypePropertyAssignment;
exports.isSpecialPropertyDeclaration = isSpecialPropertyDeclaration;
exports.setValueDeclaration = setValueDeclaration;
exports.isFunctionSymbol = isFunctionSymbol;
exports.canHaveModuleSpecifier = canHaveModuleSpecifier;
exports.tryGetModuleSpecifierFromDeclaration = tryGetModuleSpecifierFromDeclaration;
exports.importFromModuleSpecifier = importFromModuleSpecifier;
exports.tryGetImportFromModuleSpecifier = tryGetImportFromModuleSpecifier;
exports.shouldRewriteModuleSpecifier = shouldRewriteModuleSpecifier;
exports.getExternalModuleName = getExternalModuleName;
exports.getNamespaceDeclarationNode = getNamespaceDeclarationNode;
exports.isDefaultImport = isDefaultImport;
exports.forEachImportClauseDeclaration = forEachImportClauseDeclaration;
exports.hasQuestionToken = hasQuestionToken;
exports.isJSDocConstructSignature = isJSDocConstructSignature;
exports.isJSDocTypeAlias = isJSDocTypeAlias;
exports.isTypeAlias = isTypeAlias;
exports.getSingleVariableOfVariableStatement = getSingleVariableOfVariableStatement;
exports.canHaveFlowNode = canHaveFlowNode;
exports.canHaveJSDoc = canHaveJSDoc;
exports.getJSDocCommentsAndTags = getJSDocCommentsAndTags;
exports.getNextJSDocCommentLocation = getNextJSDocCommentLocation;
exports.getParameterSymbolFromJSDoc = getParameterSymbolFromJSDoc;
exports.getEffectiveContainerForJSDocTemplateTag = getEffectiveContainerForJSDocTemplateTag;
exports.getJSDocOverloadTags = getJSDocOverloadTags;
exports.getHostSignatureFromJSDoc = getHostSignatureFromJSDoc;
exports.getEffectiveJSDocHost = getEffectiveJSDocHost;
exports.getJSDocHost = getJSDocHost;
exports.getJSDocRoot = getJSDocRoot;
exports.getTypeParameterFromJsDoc = getTypeParameterFromJsDoc;
exports.hasTypeArguments = hasTypeArguments;
exports.getAssignmentTargetKind = getAssignmentTargetKind;
exports.isAssignmentTarget = isAssignmentTarget;
exports.isInCompoundLikeAssignment = isInCompoundLikeAssignment;
exports.isNodeWithPossibleHoistedDeclaration = isNodeWithPossibleHoistedDeclaration;
exports.isValueSignatureDeclaration = isValueSignatureDeclaration;
exports.walkUpParenthesizedTypes = walkUpParenthesizedTypes;
exports.walkUpParenthesizedExpressions = walkUpParenthesizedExpressions;
exports.walkUpParenthesizedTypesAndGetParentAndChild = walkUpParenthesizedTypesAndGetParentAndChild;
exports.skipTypeParentheses = skipTypeParentheses;
exports.skipParentheses = skipParentheses;
exports.isDeleteTarget = isDeleteTarget;
exports.isNodeDescendantOf = isNodeDescendantOf;
exports.isDeclarationName = isDeclarationName;
exports.getDeclarationFromName = getDeclarationFromName;
exports.isLiteralComputedPropertyDeclarationName = isLiteralComputedPropertyDeclarationName;
exports.isIdentifierName = isIdentifierName;
exports.getAliasDeclarationFromName = getAliasDeclarationFromName;
exports.isAliasableExpression = isAliasableExpression;
exports.exportAssignmentIsAlias = exportAssignmentIsAlias;
exports.getExportAssignmentExpression = getExportAssignmentExpression;
exports.getPropertyAssignmentAliasLikeExpression = getPropertyAssignmentAliasLikeExpression;
exports.getEffectiveBaseTypeNode = getEffectiveBaseTypeNode;
exports.getClassExtendsHeritageElement = getClassExtendsHeritageElement;
exports.getEffectiveImplementsTypeNodes = getEffectiveImplementsTypeNodes;
exports.getAllSuperTypeNodes = getAllSuperTypeNodes;
exports.getInterfaceBaseTypeNodes = getInterfaceBaseTypeNodes;
exports.getHeritageClause = getHeritageClause;
exports.getAncestor = getAncestor;
exports.isKeyword = isKeyword;
exports.isPunctuation = isPunctuation;
exports.isKeywordOrPunctuation = isKeywordOrPunctuation;
exports.isContextualKeyword = isContextualKeyword;
exports.isNonContextualKeyword = isNonContextualKeyword;
exports.isStringANonContextualKeyword = isStringANonContextualKeyword;
exports.isIdentifierANonContextualKeyword = isIdentifierANonContextualKeyword;
exports.isTrivia = isTrivia;
exports.getFunctionFlags = getFunctionFlags;
exports.isAsyncFunction = isAsyncFunction;
exports.isStringOrNumericLiteralLike = isStringOrNumericLiteralLike;
exports.isSignedNumericLiteral = isSignedNumericLiteral;
exports.hasDynamicName = hasDynamicName;
exports.isDynamicName = isDynamicName;
exports.getPropertyNameForPropertyNameNode = getPropertyNameForPropertyNameNode;
exports.isPropertyNameLiteral = isPropertyNameLiteral;
exports.getTextOfIdentifierOrLiteral = getTextOfIdentifierOrLiteral;
exports.getEscapedTextOfIdentifierOrLiteral = getEscapedTextOfIdentifierOrLiteral;
exports.getSymbolNameForPrivateIdentifier = getSymbolNameForPrivateIdentifier;
exports.isKnownSymbol = isKnownSymbol;
exports.isPrivateIdentifierSymbol = isPrivateIdentifierSymbol;
exports.isNamedEvaluationSource = isNamedEvaluationSource;
exports.isNamedEvaluation = isNamedEvaluation;
exports.isPushOrUnshiftIdentifier = isPushOrUnshiftIdentifier;
exports.isPartOfParameterDeclaration = isPartOfParameterDeclaration;
exports.getRootDeclaration = getRootDeclaration;
exports.nodeStartsNewLexicalEnvironment = nodeStartsNewLexicalEnvironment;
exports.nodeIsSynthesized = nodeIsSynthesized;
exports.getExpressionAssociativity = getExpressionAssociativity;
exports.getOperatorAssociativity = getOperatorAssociativity;
exports.getExpressionPrecedence = getExpressionPrecedence;
exports.getOperatorPrecedence = getOperatorPrecedence;
exports.getBinaryOperatorPrecedence = getBinaryOperatorPrecedence;
exports.getSemanticJsxChildren = getSemanticJsxChildren;
exports.createDiagnosticCollection = createDiagnosticCollection;
exports.escapeTemplateSubstitution = escapeTemplateSubstitution;
exports.hasInvalidEscape = hasInvalidEscape;
exports.escapeString = escapeString;
exports.escapeNonAsciiString = escapeNonAsciiString;
exports.escapeJsxAttributeString = escapeJsxAttributeString;
exports.stripQuotes = stripQuotes;
exports.isIntrinsicJsxName = isIntrinsicJsxName;
exports.getIndentString = getIndentString;
exports.createTextWriter = createTextWriter;
exports.getTrailingSemicolonDeferringWriter = getTrailingSemicolonDeferringWriter;
exports.hostUsesCaseSensitiveFileNames = hostUsesCaseSensitiveFileNames;
exports.hostGetCanonicalFileName = hostGetCanonicalFileName;
exports.getResolvedExternalModuleName = getResolvedExternalModuleName;
exports.getExternalModuleNameFromDeclaration = getExternalModuleNameFromDeclaration;
exports.getExternalModuleNameFromPath = getExternalModuleNameFromPath;
exports.getOwnEmitOutputFilePath = getOwnEmitOutputFilePath;
exports.getDeclarationEmitOutputFilePath = getDeclarationEmitOutputFilePath;
exports.getDeclarationEmitOutputFilePathWorker = getDeclarationEmitOutputFilePathWorker;
exports.getDeclarationEmitExtensionForPath = getDeclarationEmitExtensionForPath;
exports.getPossibleOriginalInputExtensionForExtension = getPossibleOriginalInputExtensionForExtension;
exports.getPossibleOriginalInputPathWithoutChangingExt = getPossibleOriginalInputPathWithoutChangingExt;
exports.getPathsBasePath = getPathsBasePath;
exports.getSourceFilesToEmit = getSourceFilesToEmit;
exports.sourceFileMayBeEmitted = sourceFileMayBeEmitted;
exports.getSourceFilePathInNewDir = getSourceFilePathInNewDir;
exports.writeFile = writeFile;
exports.writeFileEnsuringDirectories = writeFileEnsuringDirectories;
exports.getLineOfLocalPosition = getLineOfLocalPosition;
exports.getFirstConstructorWithBody = getFirstConstructorWithBody;
exports.getSetAccessorValueParameter = getSetAccessorValueParameter;
exports.getSetAccessorTypeAnnotationNode = getSetAccessorTypeAnnotationNode;
exports.getThisParameter = getThisParameter;
exports.parameterIsThisKeyword = parameterIsThisKeyword;
exports.isThisIdentifier = isThisIdentifier;
exports.isInTypeQuery = isInTypeQuery;
exports.isThisInTypeQuery = isThisInTypeQuery;
exports.identifierIsThisKeyword = identifierIsThisKeyword;
exports.getAllAccessorDeclarations = getAllAccessorDeclarations;
exports.getEffectiveTypeAnnotationNode = getEffectiveTypeAnnotationNode;
exports.getTypeAnnotationNode = getTypeAnnotationNode;
exports.getEffectiveReturnTypeNode = getEffectiveReturnTypeNode;
exports.getJSDocTypeParameterDeclarations = getJSDocTypeParameterDeclarations;
exports.getEffectiveSetAccessorTypeAnnotationNode = getEffectiveSetAccessorTypeAnnotationNode;
exports.emitNewLineBeforeLeadingCommentOfPosition = emitNewLineBeforeLeadingCommentOfPosition;
exports.emitDetachedComments = emitDetachedComments;
exports.writeCommentRange = writeCommentRange;
exports.hasEffectiveModifiers = hasEffectiveModifiers;
exports.hasSyntacticModifiers = hasSyntacticModifiers;
exports.hasEffectiveModifier = hasEffectiveModifier;
exports.hasSyntacticModifier = hasSyntacticModifier;
exports.isStatic = isStatic;
exports.hasStaticModifier = hasStaticModifier;
exports.hasOverrideModifier = hasOverrideModifier;
exports.hasAbstractModifier = hasAbstractModifier;
exports.hasAmbientModifier = hasAmbientModifier;
exports.hasAccessorModifier = hasAccessorModifier;
exports.hasEffectiveReadonlyModifier = hasEffectiveReadonlyModifier;
exports.hasDecorators = hasDecorators;
exports.getSelectedEffectiveModifierFlags = getSelectedEffectiveModifierFlags;
exports.getSelectedSyntacticModifierFlags = getSelectedSyntacticModifierFlags;
exports.getEffectiveModifierFlags = getEffectiveModifierFlags;
exports.getEffectiveModifierFlagsAlwaysIncludeJSDoc = getEffectiveModifierFlagsAlwaysIncludeJSDoc;
exports.getSyntacticModifierFlags = getSyntacticModifierFlags;
exports.getEffectiveModifierFlagsNoCache = getEffectiveModifierFlagsNoCache;
exports.getSyntacticModifierFlagsNoCache = getSyntacticModifierFlagsNoCache;
exports.modifiersToFlags = modifiersToFlags;
exports.modifierToFlag = modifierToFlag;
exports.isBinaryLogicalOperator = isBinaryLogicalOperator;
exports.isLogicalOperator = isLogicalOperator;
exports.isLogicalOrCoalescingAssignmentOperator = isLogicalOrCoalescingAssignmentOperator;
exports.isLogicalOrCoalescingAssignmentExpression = isLogicalOrCoalescingAssignmentExpression;
exports.isLogicalOrCoalescingBinaryOperator = isLogicalOrCoalescingBinaryOperator;
exports.isLogicalOrCoalescingBinaryExpression = isLogicalOrCoalescingBinaryExpression;
exports.isAssignmentOperator = isAssignmentOperator;
exports.tryGetClassExtendingExpressionWithTypeArguments = tryGetClassExtendingExpressionWithTypeArguments;
exports.tryGetClassImplementingOrExtendingExpressionWithTypeArguments = tryGetClassImplementingOrExtendingExpressionWithTypeArguments;
exports.isAssignmentExpression = isAssignmentExpression;
exports.isDestructuringAssignment = isDestructuringAssignment;
exports.isExpressionWithTypeArgumentsInClassExtendsClause = isExpressionWithTypeArgumentsInClassExtendsClause;
exports.isEntityNameExpression = isEntityNameExpression;
exports.getFirstIdentifier = getFirstIdentifier;
exports.isDottedName = isDottedName;
exports.isPropertyAccessEntityNameExpression = isPropertyAccessEntityNameExpression;
exports.tryGetPropertyAccessOrIdentifierToString = tryGetPropertyAccessOrIdentifierToString;
exports.isPrototypeAccess = isPrototypeAccess;
exports.isRightSideOfQualifiedNameOrPropertyAccess = isRightSideOfQualifiedNameOrPropertyAccess;
exports.isRightSideOfAccessExpression = isRightSideOfAccessExpression;
exports.isRightSideOfQualifiedNameOrPropertyAccessOrJSDocMemberName = isRightSideOfQualifiedNameOrPropertyAccessOrJSDocMemberName;
exports.isInstanceOfExpression = isInstanceOfExpression;
exports.isRightSideOfInstanceofExpression = isRightSideOfInstanceofExpression;
exports.isEmptyObjectLiteral = isEmptyObjectLiteral;
exports.isEmptyArrayLiteral = isEmptyArrayLiteral;
exports.getLocalSymbolForExportDefault = getLocalSymbolForExportDefault;
exports.tryExtractTSExtension = tryExtractTSExtension;
exports.convertToBase64 = convertToBase64;
exports.base64encode = base64encode;
exports.base64decode = base64decode;
exports.readJsonOrUndefined = readJsonOrUndefined;
exports.readJson = readJson;
exports.tryParseJson = tryParseJson;
exports.directoryProbablyExists = directoryProbablyExists;
exports.getNewLineCharacter = getNewLineCharacter;
exports.createRange = createRange;
exports.moveRangeEnd = moveRangeEnd;
exports.moveRangePos = moveRangePos;
exports.moveRangePastDecorators = moveRangePastDecorators;
exports.moveRangePastModifiers = moveRangePastModifiers;
exports.createTokenRange = createTokenRange;
exports.rangeIsOnSingleLine = rangeIsOnSingleLine;
exports.rangeStartPositionsAreOnSameLine = rangeStartPositionsAreOnSameLine;
exports.rangeEndPositionsAreOnSameLine = rangeEndPositionsAreOnSameLine;
exports.rangeStartIsOnSameLineAsRangeEnd = rangeStartIsOnSameLineAsRangeEnd;
exports.rangeEndIsOnSameLineAsRangeStart = rangeEndIsOnSameLineAsRangeStart;
exports.getLinesBetweenRangeEndAndRangeStart = getLinesBetweenRangeEndAndRangeStart;
exports.getLinesBetweenRangeEndPositions = getLinesBetweenRangeEndPositions;
exports.isNodeArrayMultiLine = isNodeArrayMultiLine;
exports.positionsAreOnSameLine = positionsAreOnSameLine;
exports.getStartPositionOfRange = getStartPositionOfRange;
exports.getLinesBetweenPositionAndPrecedingNonWhitespaceCharacter = getLinesBetweenPositionAndPrecedingNonWhitespaceCharacter;
exports.getLinesBetweenPositionAndNextNonWhitespaceCharacter = getLinesBetweenPositionAndNextNonWhitespaceCharacter;
exports.rangeContainsRange = rangeContainsRange;
exports.startEndContainsRange = startEndContainsRange;
exports.isDeclarationNameOfEnumOrNamespace = isDeclarationNameOfEnumOrNamespace;
exports.getInitializedVariables = getInitializedVariables;
exports.isInitializedVariable = isInitializedVariable;
exports.isWatchSet = isWatchSet;
exports.closeFileWatcher = closeFileWatcher;
exports.getCheckFlags = getCheckFlags;
exports.getDeclarationModifierFlagsFromSymbol = getDeclarationModifierFlagsFromSymbol;
exports.skipAlias = skipAlias;
exports.getCombinedLocalAndExportSymbolFlags = getCombinedLocalAndExportSymbolFlags;
exports.isWriteOnlyAccess = isWriteOnlyAccess;
exports.isWriteAccess = isWriteAccess;
exports.compareDataObjects = compareDataObjects;
exports.clearMap = clearMap;
exports.mutateMapSkippingNewValues = mutateMapSkippingNewValues;
exports.mutateMap = mutateMap;
exports.isAbstractConstructorSymbol = isAbstractConstructorSymbol;
exports.getClassLikeDeclarationOfSymbol = getClassLikeDeclarationOfSymbol;
exports.getObjectFlags = getObjectFlags;
exports.isUMDExportSymbol = isUMDExportSymbol;
exports.showModuleSpecifier = showModuleSpecifier;
exports.getLastChild = getLastChild;
exports.addToSeen = addToSeen;
exports.isObjectTypeDeclaration = isObjectTypeDeclaration;
exports.isTypeNodeKind = isTypeNodeKind;
exports.isAccessExpression = isAccessExpression;
exports.getNameOfAccessExpression = getNameOfAccessExpression;
exports.isNamedImportsOrExports = isNamedImportsOrExports;
exports.getLeftmostAccessExpression = getLeftmostAccessExpression;
exports.forEachNameInAccessChainWalkingLeft = forEachNameInAccessChainWalkingLeft;
exports.getLeftmostExpression = getLeftmostExpression;
exports.addObjectAllocatorPatcher = addObjectAllocatorPatcher;
exports.setObjectAllocator = setObjectAllocator;
exports.formatStringFromArgs = formatStringFromArgs;
exports.setLocalizedDiagnosticMessages = setLocalizedDiagnosticMessages;
exports.maybeSetLocalizedDiagnosticMessages = maybeSetLocalizedDiagnosticMessages;
exports.getLocaleSpecificMessage = getLocaleSpecificMessage;
exports.createDetachedDiagnostic = createDetachedDiagnostic;
exports.attachFileToDiagnostics = attachFileToDiagnostics;
exports.createFileDiagnostic = createFileDiagnostic;
exports.formatMessage = formatMessage;
exports.createCompilerDiagnostic = createCompilerDiagnostic;
exports.createCompilerDiagnosticFromMessageChain = createCompilerDiagnosticFromMessageChain;
exports.chainDiagnosticMessages = chainDiagnosticMessages;
exports.concatenateDiagnosticMessageChains = concatenateDiagnosticMessageChains;
exports.compareDiagnostics = compareDiagnostics;
exports.diagnosticsEqualityComparer = diagnosticsEqualityComparer;
exports.getLanguageVariant = getLanguageVariant;
exports.getSetExternalModuleIndicator = getSetExternalModuleIndicator;
exports.importSyntaxAffectsModuleResolution = importSyntaxAffectsModuleResolution;
exports.usesWildcardTypes = usesWildcardTypes;
exports.emitModuleKindIsNonNodeESM = emitModuleKindIsNonNodeESM;
exports.hasJsonModuleEmitEnabled = hasJsonModuleEmitEnabled;
exports.moduleResolutionSupportsPackageJsonExportsAndImports = moduleResolutionSupportsPackageJsonExportsAndImports;
exports.moduleSupportsImportAttributes = moduleSupportsImportAttributes;
exports.getStrictOptionValue = getStrictOptionValue;
exports.getNameOfScriptTarget = getNameOfScriptTarget;
exports.getEmitStandardClassFields = getEmitStandardClassFields;
exports.compilerOptionsAffectSemanticDiagnostics = compilerOptionsAffectSemanticDiagnostics;
exports.compilerOptionsAffectEmit = compilerOptionsAffectEmit;
exports.compilerOptionsAffectDeclarationPath = compilerOptionsAffectDeclarationPath;
exports.getCompilerOptionValue = getCompilerOptionValue;
exports.getJSXTransformEnabled = getJSXTransformEnabled;
exports.getJSXImplicitImportBase = getJSXImplicitImportBase;
exports.getJSXRuntimeImport = getJSXRuntimeImport;
exports.hasZeroOrOneAsteriskCharacter = hasZeroOrOneAsteriskCharacter;
exports.createSymlinkCache = createSymlinkCache;
exports.tryRemoveDirectoryPrefix = tryRemoveDirectoryPrefix;
exports.regExpEscape = regExpEscape;
exports.getRegularExpressionForWildcard = getRegularExpressionForWildcard;
exports.getRegularExpressionsForWildcards = getRegularExpressionsForWildcards;
exports.isImplicitGlob = isImplicitGlob;
exports.getPatternFromSpec = getPatternFromSpec;
exports.getSubPatternFromSpec = getSubPatternFromSpec;
exports.getFileMatcherPatterns = getFileMatcherPatterns;
exports.getRegexFromPattern = getRegexFromPattern;
exports.matchFiles = matchFiles;
exports.ensureScriptKind = ensureScriptKind;
exports.getScriptKindFromFileName = getScriptKindFromFileName;
exports.getSupportedExtensions = getSupportedExtensions;
exports.getSupportedExtensionsWithJsonIfResolveJsonModule = getSupportedExtensionsWithJsonIfResolveJsonModule;
exports.hasJSFileExtension = hasJSFileExtension;
exports.hasTSFileExtension = hasTSFileExtension;
exports.hasImplementationTSFileExtension = hasImplementationTSFileExtension;
exports.getModuleSpecifierEndingPreference = getModuleSpecifierEndingPreference;
exports.isSupportedSourceFileName = isSupportedSourceFileName;
exports.compareNumberOfDirectorySeparators = compareNumberOfDirectorySeparators;
exports.removeFileExtension = removeFileExtension;
exports.tryRemoveExtension = tryRemoveExtension;
exports.removeExtension = removeExtension;
exports.changeExtension = changeExtension;
exports.tryParsePattern = tryParsePattern;
exports.tryParsePatterns = tryParsePatterns;
exports.positionIsSynthesized = positionIsSynthesized;
exports.extensionIsTS = extensionIsTS;
exports.resolutionExtensionIsTSOrJson = resolutionExtensionIsTSOrJson;
exports.extensionFromPath = extensionFromPath;
exports.isAnySupportedFileExtension = isAnySupportedFileExtension;
exports.tryGetExtensionFromPath = tryGetExtensionFromPath;
exports.isCheckJsEnabledForFile = isCheckJsEnabledForFile;
exports.matchPatternOrExact = matchPatternOrExact;
exports.sliceAfter = sliceAfter;
exports.addRelatedInfo = addRelatedInfo;
exports.minAndMax = minAndMax;
exports.rangeOfNode = rangeOfNode;
exports.rangeOfTypeParameters = rangeOfTypeParameters;
exports.skipTypeChecking = skipTypeChecking;
exports.skipTypeCheckingIgnoringNoCheck = skipTypeCheckingIgnoringNoCheck;
exports.canIncludeBindAndCheckDiagnostics = canIncludeBindAndCheckDiagnostics;
exports.isJsonEqual = isJsonEqual;
exports.parsePseudoBigInt = parsePseudoBigInt;
exports.pseudoBigIntToString = pseudoBigIntToString;
exports.parseBigInt = parseBigInt;
exports.parseValidBigInt = parseValidBigInt;
exports.isValidBigIntString = isValidBigIntString;
exports.isValidTypeOnlyAliasUseSite = isValidTypeOnlyAliasUseSite;
exports.isIdentifierTypeReference = isIdentifierTypeReference;
exports.arrayIsHomogeneous = arrayIsHomogeneous;
exports.setTextRangePos = setTextRangePos;
exports.setTextRangeEnd = setTextRangeEnd;
exports.setTextRangePosEnd = setTextRangePosEnd;
exports.setTextRangePosWidth = setTextRangePosWidth;
exports.setNodeFlags = setNodeFlags;
exports.setParent = setParent;
exports.setParentRecursive = setParentRecursive;
exports.isPackedArrayLiteral = isPackedArrayLiteral;
exports.expressionResultIsUnused = expressionResultIsUnused;
exports.containsIgnoredPath = containsIgnoredPath;
exports.getContainingNodeArray = getContainingNodeArray;
exports.hasContextSensitiveParameters = hasContextSensitiveParameters;
exports.isInfinityOrNaNString = isInfinityOrNaNString;
exports.isCatchClauseVariableDeclaration = isCatchClauseVariableDeclaration;
exports.isFunctionExpressionOrArrowFunction = isFunctionExpressionOrArrowFunction;
exports.escapeSnippetText = escapeSnippetText;
exports.isNumericLiteralName = isNumericLiteralName;
exports.createPropertyNameNodeForIdentifierOrLiteral = createPropertyNameNodeForIdentifierOrLiteral;
exports.isThisTypeParameter = isThisTypeParameter;
exports.getNodeModulePathParts = getNodeModulePathParts;
exports.isTypeDeclaration = isTypeDeclaration;
exports.canHaveExportModifier = canHaveExportModifier;
exports.isOptionalJSDocPropertyLikeTag = isOptionalJSDocPropertyLikeTag;
exports.canUsePropertyAccess = canUsePropertyAccess;
exports.hasTabstop = hasTabstop;
exports.isJSDocOptionalParameter = isJSDocOptionalParameter;
exports.isOptionalDeclaration = isOptionalDeclaration;
exports.isNonNullAccess = isNonNullAccess;
exports.isJSDocSatisfiesExpression = isJSDocSatisfiesExpression;
exports.getJSDocSatisfiesExpressionType = getJSDocSatisfiesExpressionType;
exports.tryGetJSDocSatisfiesTypeNode = tryGetJSDocSatisfiesTypeNode;
exports.getEscapedTextOfJsxAttributeName = getEscapedTextOfJsxAttributeName;
exports.getTextOfJsxAttributeName = getTextOfJsxAttributeName;
exports.isJsxAttributeName = isJsxAttributeName;
exports.getEscapedTextOfJsxNamespacedName = getEscapedTextOfJsxNamespacedName;
exports.getTextOfJsxNamespacedName = getTextOfJsxNamespacedName;
exports.intrinsicTagNameToString = intrinsicTagNameToString;
exports.isTypeUsableAsPropertyName = isTypeUsableAsPropertyName;
exports.getPropertyNameFromType = getPropertyNameFromType;
exports.isExpandoPropertyDeclaration = isExpandoPropertyDeclaration;
exports.hasResolutionModeOverride = hasResolutionModeOverride;
exports.replaceFirstStar = replaceFirstStar;
exports.getNameFromImportAttribute = getNameFromImportAttribute;
exports.isSourceElement = isSourceElement;
exports.evaluatorResult = evaluatorResult;
exports.createEvaluator = createEvaluator;
exports.isConstAssertion = isConstAssertion;
exports.findConstructorDeclaration = findConstructorDeclaration;
exports.createNameResolver = createNameResolver;
exports.isPrimitiveLiteralValue = isPrimitiveLiteralValue;
exports.unwrapParenthesizedExpression = unwrapParenthesizedExpression;
exports.hasInferredType = hasInferredType;
exports.isSideEffectImport = isSideEffectImport;
exports.forEachDynamicImportOrRequireCall = forEachDynamicImportOrRequireCall;
exports.isNewScopeNode = isNewScopeNode;
exports.getLibNameFromLibReference = getLibNameFromLibReference;
exports.getLibFileNameFromLibReference = getLibFileNameFromLibReference;
exports.forEachResolvedProjectReference = forEachResolvedProjectReference;
exports.forEachProjectReference = forEachProjectReference;
exports.getOptionsSyntaxByArrayElementValue = getOptionsSyntaxByArrayElementValue;
exports.getOptionsSyntaxByValue = getOptionsSyntaxByValue;
exports.forEachOptionsSyntaxByName = forEachOptionsSyntaxByName;
exports.getSynthesizedDeepClone = getSynthesizedDeepClone;
exports.getSynthesizedDeepCloneWithReplacements = getSynthesizedDeepCloneWithReplacements;
exports.getSynthesizedDeepClones = getSynthesizedDeepClones;
exports.getSynthesizedDeepClonesWithReplacements = getSynthesizedDeepClonesWithReplacements;
exports.suppressLeadingAndTrailingTrivia = suppressLeadingAndTrailingTrivia;
exports.suppressLeadingTrivia = suppressLeadingTrivia;
exports.suppressTrailingTrivia = suppressTrailingTrivia;
exports.canHaveStatements = canHaveStatements;
exports.isPotentiallyExecutableNode = isPotentiallyExecutableNode;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
exports.resolvingEmptyArray = [];
/** @internal */
exports.externalHelpersModuleNameText = "tslib";
/** @internal */
exports.defaultMaximumTruncationLength = 160;
/** @internal */
exports.noTruncationMaximumTruncationLength = 1000000;
/** @internal */
exports.defaultHoverMaximumTruncationLength = 500;
/** @internal */
function getDeclarationOfKind(symbol, kind) {
    const declarations = symbol.declarations;
    if (declarations) {
        for (const declaration of declarations) {
            if (declaration.kind === kind) {
                return declaration;
            }
        }
    }
    return undefined;
}
/** @internal */
function getDeclarationsOfKind(symbol, kind) {
    return (0, ts_js_1.filter)(symbol.declarations || ts_js_1.emptyArray, d => d.kind === kind);
}
/** @internal */
function createSymbolTable(symbols) {
    const result = new Map();
    if (symbols) {
        for (const symbol of symbols) {
            result.set(symbol.escapedName, symbol);
        }
    }
    return result;
}
/** @internal */
function isTransientSymbol(symbol) {
    return (symbol.flags & 33554432 /* SymbolFlags.Transient */) !== 0;
}
/**
 * True if the symbol is for an external module, as opposed to a namespace.
 *
 * @internal
 */
function isExternalModuleSymbol(moduleSymbol) {
    return !!(moduleSymbol.flags & 1536 /* SymbolFlags.Module */) && moduleSymbol.escapedName.charCodeAt(0) === 34 /* CharacterCodes.doubleQuote */;
}
const stringWriter = createSingleLineStringWriter();
function createSingleLineStringWriter() {
    // Why var? It avoids TDZ checks in the runtime which can be costly.
    // See: https://github.com/microsoft/TypeScript/issues/52924
    /* eslint-disable no-var */
    var str = "";
    /* eslint-enable no-var */
    const writeText = text => str += text;
    return {
        getText: () => str,
        write: writeText,
        rawWrite: writeText,
        writeKeyword: writeText,
        writeOperator: writeText,
        writePunctuation: writeText,
        writeSpace: writeText,
        writeStringLiteral: writeText,
        writeLiteral: writeText,
        writeParameter: writeText,
        writeProperty: writeText,
        writeSymbol: (s, _) => writeText(s),
        writeTrailingSemicolon: writeText,
        writeComment: writeText,
        getTextPos: () => str.length,
        getLine: () => 0,
        getColumn: () => 0,
        getIndent: () => 0,
        isAtStartOfLine: () => false,
        hasTrailingComment: () => false,
        hasTrailingWhitespace: () => !!str.length && (0, ts_js_1.isWhiteSpaceLike)(str.charCodeAt(str.length - 1)),
        // Completely ignore indentation for string writers.  And map newlines to
        // a single space.
        writeLine: () => str += " ",
        increaseIndent: ts_js_1.noop,
        decreaseIndent: ts_js_1.noop,
        clear: () => str = "",
    };
}
/** @internal */
function changesAffectModuleResolution(oldOptions, newOptions) {
    return oldOptions.configFilePath !== newOptions.configFilePath ||
        optionsHaveModuleResolutionChanges(oldOptions, newOptions);
}
function optionsHaveModuleResolutionChanges(oldOptions, newOptions) {
    return optionsHaveChanges(oldOptions, newOptions, ts_js_1.moduleResolutionOptionDeclarations);
}
/** @internal */
function changesAffectingProgramStructure(oldOptions, newOptions) {
    return optionsHaveChanges(oldOptions, newOptions, ts_js_1.optionsAffectingProgramStructure);
}
/** @internal */
function optionsHaveChanges(oldOptions, newOptions, optionDeclarations) {
    return oldOptions !== newOptions && optionDeclarations.some(o => !isJsonEqual(getCompilerOptionValue(oldOptions, o), getCompilerOptionValue(newOptions, o)));
}
/** @internal */
function forEachAncestor(node, callback) {
    while (true) {
        const res = callback(node);
        if (res === "quit")
            return undefined;
        if (res !== undefined)
            return res;
        if ((0, ts_js_1.isSourceFile)(node))
            return undefined;
        node = node.parent;
    }
}
/**
 * Calls `callback` for each entry in the map, returning the first truthy result.
 * Use `map.forEach` instead for normal iteration.
 *
 * @internal
 */
function forEachEntry(map, callback) {
    const iterator = map.entries();
    for (const [key, value] of iterator) {
        const result = callback(value, key);
        if (result) {
            return result;
        }
    }
    return undefined;
}
/**
 * `forEachEntry` for just keys.
 *
 * @internal
 */
function forEachKey(map, callback) {
    const iterator = map.keys();
    for (const key of iterator) {
        const result = callback(key);
        if (result) {
            return result;
        }
    }
    return undefined;
}
/**
 * Copy entries from `source` to `target`.
 *
 * @internal
 */
function copyEntries(source, target) {
    source.forEach((value, key) => {
        target.set(key, value);
    });
}
/** @internal */
function usingSingleLineStringWriter(action) {
    const oldString = stringWriter.getText();
    try {
        action(stringWriter);
        return stringWriter.getText();
    }
    finally {
        stringWriter.clear();
        stringWriter.writeKeyword(oldString);
    }
}
/** @internal */
function getFullWidth(node) {
    return node.end - node.pos;
}
/** @internal */
function projectReferenceIsEqualTo(oldRef, newRef) {
    return oldRef.path === newRef.path &&
        !oldRef.prepend === !newRef.prepend &&
        !oldRef.circular === !newRef.circular;
}
/** @internal */
function moduleResolutionIsEqualTo(oldResolution, newResolution) {
    return oldResolution === newResolution ||
        oldResolution.resolvedModule === newResolution.resolvedModule ||
        !!oldResolution.resolvedModule &&
            !!newResolution.resolvedModule &&
            oldResolution.resolvedModule.isExternalLibraryImport === newResolution.resolvedModule.isExternalLibraryImport &&
            oldResolution.resolvedModule.extension === newResolution.resolvedModule.extension &&
            oldResolution.resolvedModule.resolvedFileName === newResolution.resolvedModule.resolvedFileName &&
            oldResolution.resolvedModule.originalPath === newResolution.resolvedModule.originalPath &&
            packageIdIsEqual(oldResolution.resolvedModule.packageId, newResolution.resolvedModule.packageId) &&
            oldResolution.alternateResult === newResolution.alternateResult;
}
/** @internal */
function getResolvedModuleFromResolution(resolution) {
    return resolution.resolvedModule;
}
/** @internal */
function getResolvedTypeReferenceDirectiveFromResolution(resolution) {
    return resolution.resolvedTypeReferenceDirective;
}
/** @internal */
function createModuleNotFoundChain(sourceFile, host, moduleReference, mode, packageName) {
    const alternateResult = host.getResolvedModule(sourceFile, moduleReference, mode)?.alternateResult;
    const alternateResultMessage = alternateResult && ((0, exports.getEmitModuleResolutionKind)(host.getCompilerOptions()) === ts_js_1.ModuleResolutionKind.Node10
        ? [ts_js_1.Diagnostics.There_are_types_at_0_but_this_result_could_not_be_resolved_under_your_current_moduleResolution_setting_Consider_updating_to_node16_nodenext_or_bundler, [alternateResult]]
        : [
            ts_js_1.Diagnostics.There_are_types_at_0_but_this_result_could_not_be_resolved_when_respecting_package_json_exports_The_1_library_may_need_to_update_its_package_json_or_typings,
            [alternateResult, alternateResult.includes(ts_js_1.nodeModulesPathPart + "@types/") ? `@types/${(0, ts_js_1.mangleScopedPackageName)(packageName)}` : packageName],
        ]);
    const result = alternateResultMessage
        ? chainDiagnosticMessages(
        /*details*/ undefined, alternateResultMessage[0], ...alternateResultMessage[1])
        : host.typesPackageExists(packageName)
            ? chainDiagnosticMessages(
            /*details*/ undefined, ts_js_1.Diagnostics.If_the_0_package_actually_exposes_this_module_consider_sending_a_pull_request_to_amend_https_Colon_Slash_Slashgithub_com_SlashDefinitelyTyped_SlashDefinitelyTyped_Slashtree_Slashmaster_Slashtypes_Slash_1, packageName, (0, ts_js_1.mangleScopedPackageName)(packageName))
            : host.packageBundlesTypes(packageName)
                ? chainDiagnosticMessages(
                /*details*/ undefined, ts_js_1.Diagnostics.If_the_0_package_actually_exposes_this_module_try_adding_a_new_declaration_d_ts_file_containing_declare_module_1, packageName, moduleReference)
                : chainDiagnosticMessages(
                /*details*/ undefined, ts_js_1.Diagnostics.Try_npm_i_save_dev_types_Slash_1_if_it_exists_or_add_a_new_declaration_d_ts_file_containing_declare_module_0, moduleReference, (0, ts_js_1.mangleScopedPackageName)(packageName));
    if (result)
        result.repopulateInfo = () => ({ moduleReference, mode, packageName: packageName === moduleReference ? undefined : packageName });
    return result;
}
/** @internal */
function createModeMismatchDetails(currentSourceFile) {
    const ext = tryGetExtensionFromPath(currentSourceFile.fileName);
    const scope = currentSourceFile.packageJsonScope;
    const targetExt = ext === ".ts" /* Extension.Ts */ ? ".mts" /* Extension.Mts */ : ext === ".js" /* Extension.Js */ ? ".mjs" /* Extension.Mjs */ : undefined;
    const result = scope && !scope.contents.packageJsonContent.type ?
        targetExt ?
            chainDiagnosticMessages(
            /*details*/ undefined, ts_js_1.Diagnostics.To_convert_this_file_to_an_ECMAScript_module_change_its_file_extension_to_0_or_add_the_field_type_Colon_module_to_1, targetExt, (0, ts_js_1.combinePaths)(scope.packageDirectory, "package.json")) :
            chainDiagnosticMessages(
            /*details*/ undefined, ts_js_1.Diagnostics.To_convert_this_file_to_an_ECMAScript_module_add_the_field_type_Colon_module_to_0, (0, ts_js_1.combinePaths)(scope.packageDirectory, "package.json")) :
        targetExt ?
            chainDiagnosticMessages(
            /*details*/ undefined, ts_js_1.Diagnostics.To_convert_this_file_to_an_ECMAScript_module_change_its_file_extension_to_0_or_create_a_local_package_json_file_with_type_Colon_module, targetExt) :
            chainDiagnosticMessages(
            /*details*/ undefined, ts_js_1.Diagnostics.To_convert_this_file_to_an_ECMAScript_module_create_a_local_package_json_file_with_type_Colon_module);
    result.repopulateInfo = () => true;
    return result;
}
function packageIdIsEqual(a, b) {
    return a === b || !!a && !!b && a.name === b.name && a.subModuleName === b.subModuleName && a.version === b.version && a.peerDependencies === b.peerDependencies;
}
/** @internal */
function packageIdToPackageName({ name, subModuleName }) {
    return subModuleName ? `${name}/${subModuleName}` : name;
}
/** @internal */
function packageIdToString(packageId) {
    return `${packageIdToPackageName(packageId)}@${packageId.version}${packageId.peerDependencies ?? ""}`;
}
/** @internal */
function typeDirectiveIsEqualTo(oldResolution, newResolution) {
    return oldResolution === newResolution ||
        oldResolution.resolvedTypeReferenceDirective === newResolution.resolvedTypeReferenceDirective ||
        !!oldResolution.resolvedTypeReferenceDirective &&
            !!newResolution.resolvedTypeReferenceDirective &&
            oldResolution.resolvedTypeReferenceDirective.resolvedFileName === newResolution.resolvedTypeReferenceDirective.resolvedFileName &&
            !!oldResolution.resolvedTypeReferenceDirective.primary === !!newResolution.resolvedTypeReferenceDirective.primary &&
            oldResolution.resolvedTypeReferenceDirective.originalPath === newResolution.resolvedTypeReferenceDirective.originalPath;
}
/** @internal */
function hasChangesInResolutions(names, newResolutions, getOldResolution, comparer) {
    ts_js_1.Debug.assert(names.length === newResolutions.length);
    for (let i = 0; i < names.length; i++) {
        const newResolution = newResolutions[i];
        const entry = names[i];
        const oldResolution = getOldResolution(entry);
        const changed = oldResolution
            ? !newResolution || !comparer(oldResolution, newResolution)
            : newResolution;
        if (changed) {
            return true;
        }
    }
    return false;
}
// Returns true if this node contains a parse error anywhere underneath it.
/** @internal */
function containsParseError(node) {
    aggregateChildData(node);
    return (node.flags & 1048576 /* NodeFlags.ThisNodeOrAnySubNodesHasError */) !== 0;
}
function aggregateChildData(node) {
    if (!(node.flags & 2097152 /* NodeFlags.HasAggregatedChildData */)) {
        // A node is considered to contain a parse error if:
        //  a) the parser explicitly marked that it had an error
        //  b) any of it's children reported that it had an error.
        const thisNodeOrAnySubNodesHasError = ((node.flags & 262144 /* NodeFlags.ThisNodeHasError */) !== 0) ||
            (0, ts_js_1.forEachChild)(node, containsParseError);
        // If so, mark ourselves accordingly.
        if (thisNodeOrAnySubNodesHasError) {
            node.flags |= 1048576 /* NodeFlags.ThisNodeOrAnySubNodesHasError */;
        }
        // Also mark that we've propagated the child information to this node.  This way we can
        // always consult the bit directly on this node without needing to check its children
        // again.
        node.flags |= 2097152 /* NodeFlags.HasAggregatedChildData */;
    }
}
/** @internal */
function getSourceFileOfNode(node) {
    while (node && node.kind !== 308 /* SyntaxKind.SourceFile */) {
        node = node.parent;
    }
    return node;
}
/** @internal */
function getSourceFileOfModule(module) {
    return getSourceFileOfNode(module.valueDeclaration || getNonAugmentationDeclaration(module));
}
/** @internal */
function isPlainJsFile(file, checkJs) {
    return !!file && (file.scriptKind === 1 /* ScriptKind.JS */ || file.scriptKind === 2 /* ScriptKind.JSX */) && !file.checkJsDirective && checkJs === undefined;
}
/** @internal */
function isStatementWithLocals(node) {
    switch (node.kind) {
        case 242 /* SyntaxKind.Block */:
        case 270 /* SyntaxKind.CaseBlock */:
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
            return true;
    }
    return false;
}
/** @internal */
function getStartPositionOfLine(line, sourceFile) {
    ts_js_1.Debug.assert(line >= 0);
    return (0, ts_js_1.getLineStarts)(sourceFile)[line];
}
// This is a useful function for debugging purposes.
/** @internal @knipignore */
function nodePosToString(node) {
    const file = getSourceFileOfNode(node);
    const loc = (0, ts_js_1.getLineAndCharacterOfPosition)(file, node.pos);
    return `${file.fileName}(${loc.line + 1},${loc.character + 1})`;
}
/** @internal */
function getEndLinePosition(line, sourceFile) {
    ts_js_1.Debug.assert(line >= 0);
    const lineStarts = (0, ts_js_1.getLineStarts)(sourceFile);
    const lineIndex = line;
    const sourceText = sourceFile.text;
    if (lineIndex + 1 === lineStarts.length) {
        // last line - return EOF
        return sourceText.length - 1;
    }
    else {
        // current line start
        const start = lineStarts[lineIndex];
        // take the start position of the next line - 1 = it should be some line break
        let pos = lineStarts[lineIndex + 1] - 1;
        ts_js_1.Debug.assert((0, ts_js_1.isLineBreak)(sourceText.charCodeAt(pos)));
        // walk backwards skipping line breaks, stop the the beginning of current line.
        // i.e:
        // <some text>
        // $ <- end of line for this position should match the start position
        while (start <= pos && (0, ts_js_1.isLineBreak)(sourceText.charCodeAt(pos))) {
            pos--;
        }
        return pos;
    }
}
/**
 * Returns a value indicating whether a name is unique globally or within the current file.
 * Note: This does not consider whether a name appears as a free identifier or not, so at the expression `x.y` this includes both `x` and `y`.
 *
 * @internal
 */
function isFileLevelUniqueName(sourceFile, name, hasGlobalName) {
    return !(hasGlobalName && hasGlobalName(name)) && !sourceFile.identifiers.has(name);
}
// Returns true if this node is missing from the actual source code. A 'missing' node is different
// from 'undefined/defined'. When a node is undefined (which can happen for optional nodes
// in the tree), it is definitely missing. However, a node may be defined, but still be
// missing.  This happens whenever the parser knows it needs to parse something, but can't
// get anything in the source code that it expects at that location. For example:
//
//          let a: ;
//
// Here, the Type in the Type-Annotation is not-optional (as there is a colon in the source
// code). So the parser will attempt to parse out a type, and will create an actual node.
// However, this node will be 'missing' in the sense that no actual source-code/tokens are
// contained within it.
/** @internal */
function nodeIsMissing(node) {
    if (node === undefined) {
        return true;
    }
    return node.pos === node.end && node.pos >= 0 && node.kind !== 1 /* SyntaxKind.EndOfFileToken */;
}
/** @internal */
function nodeIsPresent(node) {
    return !nodeIsMissing(node);
}
/**
 * Tests whether `child` is a grammar error on `parent`.
 * @internal
 */
function isGrammarError(parent, child) {
    if ((0, ts_js_1.isTypeParameterDeclaration)(parent))
        return child === parent.expression;
    if ((0, ts_js_1.isClassStaticBlockDeclaration)(parent))
        return child === parent.modifiers;
    if ((0, ts_js_1.isPropertySignature)(parent))
        return child === parent.initializer;
    if ((0, ts_js_1.isPropertyDeclaration)(parent))
        return child === parent.questionToken && (0, ts_js_1.isAutoAccessorPropertyDeclaration)(parent);
    if ((0, ts_js_1.isPropertyAssignment)(parent))
        return child === parent.modifiers || child === parent.questionToken || child === parent.exclamationToken || isGrammarErrorElement(parent.modifiers, child, ts_js_1.isModifierLike);
    if ((0, ts_js_1.isShorthandPropertyAssignment)(parent))
        return child === parent.equalsToken || child === parent.modifiers || child === parent.questionToken || child === parent.exclamationToken || isGrammarErrorElement(parent.modifiers, child, ts_js_1.isModifierLike);
    if ((0, ts_js_1.isMethodDeclaration)(parent))
        return child === parent.exclamationToken;
    if ((0, ts_js_1.isConstructorDeclaration)(parent))
        return child === parent.typeParameters || child === parent.type || isGrammarErrorElement(parent.typeParameters, child, ts_js_1.isTypeParameterDeclaration);
    if ((0, ts_js_1.isGetAccessorDeclaration)(parent))
        return child === parent.typeParameters || isGrammarErrorElement(parent.typeParameters, child, ts_js_1.isTypeParameterDeclaration);
    if ((0, ts_js_1.isSetAccessorDeclaration)(parent))
        return child === parent.typeParameters || child === parent.type || isGrammarErrorElement(parent.typeParameters, child, ts_js_1.isTypeParameterDeclaration);
    if ((0, ts_js_1.isNamespaceExportDeclaration)(parent))
        return child === parent.modifiers || isGrammarErrorElement(parent.modifiers, child, ts_js_1.isModifierLike);
    return false;
}
function isGrammarErrorElement(nodeArray, child, isElement) {
    if (!nodeArray || (0, ts_js_1.isArray)(child) || !isElement(child))
        return false;
    return (0, ts_js_1.contains)(nodeArray, child);
}
function insertStatementsAfterPrologue(to, from, isPrologueDirective) {
    if (from === undefined || from.length === 0)
        return to;
    let statementIndex = 0;
    // skip all prologue directives to insert at the correct position
    for (; statementIndex < to.length; ++statementIndex) {
        if (!isPrologueDirective(to[statementIndex])) {
            break;
        }
    }
    to.splice(statementIndex, 0, ...from);
    return to;
}
function insertStatementAfterPrologue(to, statement, isPrologueDirective) {
    if (statement === undefined)
        return to;
    let statementIndex = 0;
    // skip all prologue directives to insert at the correct position
    for (; statementIndex < to.length; ++statementIndex) {
        if (!isPrologueDirective(to[statementIndex])) {
            break;
        }
    }
    to.splice(statementIndex, 0, statement);
    return to;
}
function isAnyPrologueDirective(node) {
    return isPrologueDirective(node) || !!(getEmitFlags(node) & 2097152 /* EmitFlags.CustomPrologue */);
}
/**
 * Prepends statements to an array while taking care of prologue directives.
 *
 * @internal
 */
function insertStatementsAfterStandardPrologue(to, from) {
    return insertStatementsAfterPrologue(to, from, isPrologueDirective);
}
/** @internal */
function insertStatementsAfterCustomPrologue(to, from) {
    return insertStatementsAfterPrologue(to, from, isAnyPrologueDirective);
}
/**
 * Prepends statements to an array while taking care of prologue directives.
 *
 * @internal
 * @knipignore
 */
function insertStatementAfterStandardPrologue(to, statement) {
    return insertStatementAfterPrologue(to, statement, isPrologueDirective);
}
/** @internal */
function insertStatementAfterCustomPrologue(to, statement) {
    return insertStatementAfterPrologue(to, statement, isAnyPrologueDirective);
}
/**
 * Determine if the given comment is a triple-slash
 *
 * @return true if the comment is a triple-slash comment else false
 *
 * @internal
 */
function isRecognizedTripleSlashComment(text, commentPos, commentEnd) {
    // Verify this is /// comment, but do the regexp match only when we first can find /// in the comment text
    // so that we don't end up computing comment string and doing match for all // comments
    if (text.charCodeAt(commentPos + 1) === 47 /* CharacterCodes.slash */ &&
        commentPos + 2 < commentEnd &&
        text.charCodeAt(commentPos + 2) === 47 /* CharacterCodes.slash */) {
        const textSubStr = text.substring(commentPos, commentEnd);
        return fullTripleSlashReferencePathRegEx.test(textSubStr) ||
            fullTripleSlashAMDReferencePathRegEx.test(textSubStr) ||
            fullTripleSlashAMDModuleRegEx.test(textSubStr) ||
            fullTripleSlashReferenceTypeReferenceDirectiveRegEx.test(textSubStr) ||
            fullTripleSlashLibReferenceRegEx.test(textSubStr) ||
            defaultLibReferenceRegEx.test(textSubStr) ?
            true : false;
    }
    return false;
}
/** @internal */
function isPinnedComment(text, start) {
    return text.charCodeAt(start + 1) === 42 /* CharacterCodes.asterisk */ &&
        text.charCodeAt(start + 2) === 33 /* CharacterCodes.exclamation */;
}
/** @internal */
function createCommentDirectivesMap(sourceFile, commentDirectives) {
    const directivesByLine = new Map(commentDirectives.map(commentDirective => [
        `${(0, ts_js_1.getLineAndCharacterOfPosition)(sourceFile, commentDirective.range.end).line}`,
        commentDirective,
    ]));
    const usedLines = new Map();
    return { getUnusedExpectations, markUsed };
    function getUnusedExpectations() {
        return (0, ts_js_1.arrayFrom)(directivesByLine.entries())
            .filter(([line, directive]) => directive.type === 0 /* CommentDirectiveType.ExpectError */ && !usedLines.get(line))
            .map(([_, directive]) => directive);
    }
    function markUsed(line) {
        if (!directivesByLine.has(`${line}`)) {
            return false;
        }
        usedLines.set(`${line}`, true);
        return true;
    }
}
/** @internal */
function getTokenPosOfNode(node, sourceFile, includeJsDoc) {
    // With nodes that have no width (i.e. 'Missing' nodes), we actually *don't*
    // want to skip trivia because this will launch us forward to the next token.
    if (nodeIsMissing(node)) {
        return node.pos;
    }
    if ((0, ts_js_1.isJSDocNode)(node) || node.kind === 12 /* SyntaxKind.JsxText */) {
        // JsxText cannot actually contain comments, even though the scanner will think it sees comments
        return (0, ts_js_1.skipTrivia)((sourceFile ?? getSourceFileOfNode(node)).text, node.pos, /*stopAfterLineBreak*/ false, /*stopAtComments*/ true);
    }
    if (includeJsDoc && (0, ts_js_1.hasJSDocNodes)(node)) {
        return getTokenPosOfNode(node.jsDoc[0], sourceFile);
    }
    // For a syntax list, it is possible that one of its children has JSDocComment nodes, while
    // the syntax list itself considers them as normal trivia. Therefore if we simply skip
    // trivia for the list, we may have skipped the JSDocComment as well. So we should process its
    // first child to determine the actual position of its first token.
    if (node.kind === 353 /* SyntaxKind.SyntaxList */) {
        sourceFile ?? (sourceFile = getSourceFileOfNode(node));
        const first = (0, ts_js_1.firstOrUndefined)((0, ts_js_1.getNodeChildren)(node, sourceFile));
        if (first) {
            return getTokenPosOfNode(first, sourceFile, includeJsDoc);
        }
    }
    return (0, ts_js_1.skipTrivia)((sourceFile ?? getSourceFileOfNode(node)).text, node.pos, 
    /*stopAfterLineBreak*/ false, 
    /*stopAtComments*/ false, isInJSDoc(node));
}
/** @internal */
function getNonDecoratorTokenPosOfNode(node, sourceFile) {
    const lastDecorator = !nodeIsMissing(node) && (0, ts_js_1.canHaveModifiers)(node) ? (0, ts_js_1.findLast)(node.modifiers, ts_js_1.isDecorator) : undefined;
    if (!lastDecorator) {
        return getTokenPosOfNode(node, sourceFile);
    }
    return (0, ts_js_1.skipTrivia)((sourceFile || getSourceFileOfNode(node)).text, lastDecorator.end);
}
/** @internal */
function getSourceTextOfNodeFromSourceFile(sourceFile, node, includeTrivia = false) {
    return getTextOfNodeFromSourceText(sourceFile.text, node, includeTrivia);
}
function isJSDocTypeExpressionOrChild(node) {
    return !!(0, ts_js_1.findAncestor)(node, ts_js_1.isJSDocTypeExpression);
}
/** @internal */
function isExportNamespaceAsDefaultDeclaration(node) {
    return !!((0, ts_js_1.isExportDeclaration)(node) && node.exportClause && (0, ts_js_1.isNamespaceExport)(node.exportClause) && moduleExportNameIsDefault(node.exportClause.name));
}
/** @internal */
function moduleExportNameTextUnescaped(node) {
    return node.kind === 11 /* SyntaxKind.StringLiteral */ ? node.text : (0, ts_js_1.unescapeLeadingUnderscores)(node.escapedText);
}
/** @internal */
function moduleExportNameTextEscaped(node) {
    return node.kind === 11 /* SyntaxKind.StringLiteral */ ? (0, ts_js_1.escapeLeadingUnderscores)(node.text) : node.escapedText;
}
/**
 * Equality checks against a keyword without underscores don't need to bother
 * to turn "__" into "___" or vice versa, since they will never be equal in
 * either case. So we can ignore those cases to improve performance.
 *
 * @internal
 */
function moduleExportNameIsDefault(node) {
    return (node.kind === 11 /* SyntaxKind.StringLiteral */ ? node.text : node.escapedText) === "default" /* InternalSymbolName.Default */;
}
/** @internal */
function getTextOfNodeFromSourceText(sourceText, node, includeTrivia = false) {
    if (nodeIsMissing(node)) {
        return "";
    }
    let text = sourceText.substring(includeTrivia ? node.pos : (0, ts_js_1.skipTrivia)(sourceText, node.pos), node.end);
    if (isJSDocTypeExpressionOrChild(node)) {
        // strip space + asterisk at line start
        text = text.split(/\r\n|\n|\r/).map(line => line.replace(/^\s*\*/, "").trimStart()).join("\n");
    }
    return text;
}
/** @internal */
function getTextOfNode(node, includeTrivia = false) {
    return getSourceTextOfNodeFromSourceFile(getSourceFileOfNode(node), node, includeTrivia);
}
function getPos(range) {
    return range.pos;
}
/**
 * Note: it is expected that the `nodeArray` and the `node` are within the same file.
 * For example, searching for a `SourceFile` in a `SourceFile[]` wouldn't work.
 *
 * @internal
 */
function indexOfNode(nodeArray, node) {
    return (0, ts_js_1.binarySearch)(nodeArray, node, getPos, ts_js_1.compareValues);
}
/**
 * Gets flags that control emit behavior of a node.
 *
 * @internal
 */
function getEmitFlags(node) {
    const emitNode = node.emitNode;
    return emitNode && emitNode.flags || 0;
}
/**
 * Gets flags that control emit behavior of a node.
 *
 * @internal
 */
function getInternalEmitFlags(node) {
    const emitNode = node.emitNode;
    return emitNode && emitNode.internalFlags || 0;
}
// NOTE: We must reevaluate the target for upcoming features when each successive TC39 edition is ratified in
//       June of each year. This includes changes to `LanguageFeatureMinimumTarget`, `ScriptTarget`,
//       `ScriptTargetFeatures`, `CommandLineOptionOfCustomType`, transformers/esnext.ts, compiler/commandLineParser.ts,
//       compiler/utilitiesPublic.ts, and the contents of each lib/esnext.*.d.ts file.
/** @internal */
exports.getScriptTargetFeatures = (0, ts_js_1.memoize)(() => new Map(Object.entries({
    Array: new Map(Object.entries({
        es2015: [
            "find",
            "findIndex",
            "fill",
            "copyWithin",
            "entries",
            "keys",
            "values",
        ],
        es2016: [
            "includes",
        ],
        es2019: [
            "flat",
            "flatMap",
        ],
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Iterator: new Map(Object.entries({
        es2015: ts_js_1.emptyArray,
    })),
    AsyncIterator: new Map(Object.entries({
        es2015: ts_js_1.emptyArray,
    })),
    ArrayBuffer: new Map(Object.entries({
        es2024: [
            "maxByteLength",
            "resizable",
            "resize",
            "detached",
            "transfer",
            "transferToFixedLength",
        ],
    })),
    Atomics: new Map(Object.entries({
        es2017: [
            "add",
            "and",
            "compareExchange",
            "exchange",
            "isLockFree",
            "load",
            "or",
            "store",
            "sub",
            "wait",
            "notify",
            "xor",
        ],
        es2024: [
            "waitAsync",
        ],
        esnext: [
            "pause",
        ],
    })),
    SharedArrayBuffer: new Map(Object.entries({
        es2017: [
            "byteLength",
            "slice",
        ],
        es2024: [
            "growable",
            "maxByteLength",
            "grow",
        ],
    })),
    AsyncIterable: new Map(Object.entries({
        es2018: ts_js_1.emptyArray,
    })),
    AsyncIterableIterator: new Map(Object.entries({
        es2018: ts_js_1.emptyArray,
    })),
    AsyncGenerator: new Map(Object.entries({
        es2018: ts_js_1.emptyArray,
    })),
    AsyncGeneratorFunction: new Map(Object.entries({
        es2018: ts_js_1.emptyArray,
    })),
    RegExp: new Map(Object.entries({
        es2015: [
            "flags",
            "sticky",
            "unicode",
        ],
        es2018: [
            "dotAll",
        ],
        es2024: [
            "unicodeSets",
        ],
    })),
    RegExpConstructor: new Map(Object.entries({
        es2025: [
            "escape",
        ],
    })),
    Reflect: new Map(Object.entries({
        es2015: [
            "apply",
            "construct",
            "defineProperty",
            "deleteProperty",
            "get",
            "getOwnPropertyDescriptor",
            "getPrototypeOf",
            "has",
            "isExtensible",
            "ownKeys",
            "preventExtensions",
            "set",
            "setPrototypeOf",
        ],
    })),
    ArrayConstructor: new Map(Object.entries({
        es2015: [
            "from",
            "of",
        ],
        esnext: [
            "fromAsync",
        ],
    })),
    ObjectConstructor: new Map(Object.entries({
        es2015: [
            "assign",
            "getOwnPropertySymbols",
            "keys",
            "is",
            "setPrototypeOf",
        ],
        es2017: [
            "values",
            "entries",
            "getOwnPropertyDescriptors",
        ],
        es2019: [
            "fromEntries",
        ],
        es2022: [
            "hasOwn",
        ],
        es2024: [
            "groupBy",
        ],
    })),
    NumberConstructor: new Map(Object.entries({
        es2015: [
            "isFinite",
            "isInteger",
            "isNaN",
            "isSafeInteger",
            "parseFloat",
            "parseInt",
        ],
    })),
    Math: new Map(Object.entries({
        es2015: [
            "clz32",
            "imul",
            "sign",
            "log10",
            "log2",
            "log1p",
            "expm1",
            "cosh",
            "sinh",
            "tanh",
            "acosh",
            "asinh",
            "atanh",
            "hypot",
            "trunc",
            "fround",
            "cbrt",
        ],
        es2025: [
            "f16round",
        ],
    })),
    Map: new Map(Object.entries({
        es2015: [
            "entries",
            "keys",
            "values",
        ],
        esnext: [
            "getOrInsert",
            "getOrInsertComputed",
        ],
    })),
    MapConstructor: new Map(Object.entries({
        es2024: [
            "groupBy",
        ],
    })),
    Set: new Map(Object.entries({
        es2015: [
            "entries",
            "keys",
            "values",
        ],
        es2025: [
            "union",
            "intersection",
            "difference",
            "symmetricDifference",
            "isSubsetOf",
            "isSupersetOf",
            "isDisjointFrom",
        ],
    })),
    PromiseConstructor: new Map(Object.entries({
        es2015: [
            "all",
            "race",
            "reject",
            "resolve",
        ],
        es2020: [
            "allSettled",
        ],
        es2021: [
            "any",
        ],
        es2024: [
            "withResolvers",
        ],
        es2025: [
            "try",
        ],
    })),
    Symbol: new Map(Object.entries({
        es2015: [
            "for",
            "keyFor",
        ],
        es2019: [
            "description",
        ],
    })),
    WeakMap: new Map(Object.entries({
        es2015: [
            "entries",
            "keys",
            "values",
        ],
        esnext: [
            "getOrInsert",
            "getOrInsertComputed",
        ],
    })),
    WeakSet: new Map(Object.entries({
        es2015: [
            "entries",
            "keys",
            "values",
        ],
    })),
    String: new Map(Object.entries({
        es2015: [
            "codePointAt",
            "includes",
            "endsWith",
            "normalize",
            "repeat",
            "startsWith",
            "anchor",
            "big",
            "blink",
            "bold",
            "fixed",
            "fontcolor",
            "fontsize",
            "italics",
            "link",
            "small",
            "strike",
            "sub",
            "sup",
        ],
        es2017: [
            "padStart",
            "padEnd",
        ],
        es2019: [
            "trimStart",
            "trimEnd",
            "trimLeft",
            "trimRight",
        ],
        es2020: [
            "matchAll",
        ],
        es2021: [
            "replaceAll",
        ],
        es2022: [
            "at",
        ],
        es2024: [
            "isWellFormed",
            "toWellFormed",
        ],
    })),
    StringConstructor: new Map(Object.entries({
        es2015: [
            "fromCodePoint",
            "raw",
        ],
    })),
    DateTimeFormat: new Map(Object.entries({
        es2017: [
            "formatToParts",
        ],
    })),
    Promise: new Map(Object.entries({
        es2015: ts_js_1.emptyArray,
        es2018: [
            "finally",
        ],
    })),
    RegExpMatchArray: new Map(Object.entries({
        es2018: [
            "groups",
        ],
    })),
    RegExpExecArray: new Map(Object.entries({
        es2018: [
            "groups",
        ],
    })),
    Intl: new Map(Object.entries({
        es2018: [
            "PluralRules",
        ],
        es2020: [
            "RelativeTimeFormat",
            "Locale",
            "DisplayNames",
        ],
        es2021: [
            "ListFormat",
            "DateTimeFormat",
        ],
        es2022: [
            "Segmenter",
        ],
        es2025: [
            "DurationFormat",
        ],
    })),
    NumberFormat: new Map(Object.entries({
        es2018: [
            "formatToParts",
        ],
    })),
    SymbolConstructor: new Map(Object.entries({
        es2020: [
            "matchAll",
        ],
        esnext: [
            "metadata",
            "dispose",
            "asyncDispose",
        ],
    })),
    DataView: new Map(Object.entries({
        es2020: [
            "setBigInt64",
            "setBigUint64",
            "getBigInt64",
            "getBigUint64",
        ],
        es2025: [
            "setFloat16",
            "getFloat16",
        ],
    })),
    BigInt: new Map(Object.entries({
        es2020: ts_js_1.emptyArray,
    })),
    RelativeTimeFormat: new Map(Object.entries({
        es2020: [
            "format",
            "formatToParts",
            "resolvedOptions",
        ],
    })),
    Int8Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Uint8Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
        esnext: [
            "toBase64",
            "setFromBase64",
            "toHex",
            "setFromHex",
        ],
    })),
    Uint8ClampedArray: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Int16Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Uint16Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Int32Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Uint32Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Float16Array: new Map(Object.entries({
        es2025: ts_js_1.emptyArray,
    })),
    Float32Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Float64Array: new Map(Object.entries({
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    BigInt64Array: new Map(Object.entries({
        es2020: ts_js_1.emptyArray,
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    BigUint64Array: new Map(Object.entries({
        es2020: ts_js_1.emptyArray,
        es2022: [
            "at",
        ],
        es2023: [
            "findLastIndex",
            "findLast",
            "toReversed",
            "toSorted",
            "toSpliced",
            "with",
        ],
    })),
    Error: new Map(Object.entries({
        es2022: [
            "cause",
        ],
    })),
    ErrorConstructor: new Map(Object.entries({
        esnext: [
            "isError",
        ],
    })),
    Uint8ArrayConstructor: new Map(Object.entries({
        esnext: [
            "fromBase64",
            "fromHex",
        ],
    })),
    Date: new Map(Object.entries({
        esnext: [
            "toTemporalInstant",
        ],
    })),
    DisposableStack: new Map(Object.entries({
        esnext: ts_js_1.emptyArray,
    })),
    AsyncDisposableStack: new Map(Object.entries({
        esnext: ts_js_1.emptyArray,
    })),
})));
/** @internal */
var GetLiteralTextFlags;
(function (GetLiteralTextFlags) {
    GetLiteralTextFlags[GetLiteralTextFlags["None"] = 0] = "None";
    GetLiteralTextFlags[GetLiteralTextFlags["NeverAsciiEscape"] = 1] = "NeverAsciiEscape";
    GetLiteralTextFlags[GetLiteralTextFlags["JsxAttributeEscape"] = 2] = "JsxAttributeEscape";
    GetLiteralTextFlags[GetLiteralTextFlags["TerminateUnterminatedLiterals"] = 4] = "TerminateUnterminatedLiterals";
    GetLiteralTextFlags[GetLiteralTextFlags["AllowNumericSeparator"] = 8] = "AllowNumericSeparator";
})(GetLiteralTextFlags || (exports.GetLiteralTextFlags = GetLiteralTextFlags = {}));
/** @internal */
function getLiteralText(node, sourceFile, flags) {
    // If we don't need to downlevel and we can reach the original source text using
    // the node's parent reference, then simply get the text as it was originally written.
    if (sourceFile && canUseOriginalText(node, flags)) {
        return getSourceTextOfNodeFromSourceFile(sourceFile, node);
    }
    // If we can't reach the original source text, use the canonical form if it's a number,
    // or a (possibly escaped) quoted form of the original text if it's string-like.
    switch (node.kind) {
        case 11 /* SyntaxKind.StringLiteral */: {
            const escapeText = flags & 2 /* GetLiteralTextFlags.JsxAttributeEscape */ ? escapeJsxAttributeString :
                flags & 1 /* GetLiteralTextFlags.NeverAsciiEscape */ || (getEmitFlags(node) & 16777216 /* EmitFlags.NoAsciiEscaping */) ? escapeString :
                    escapeNonAsciiString;
            if (node.singleQuote) {
                return "'" + escapeText(node.text, 39 /* CharacterCodes.singleQuote */) + "'";
            }
            else {
                return '"' + escapeText(node.text, 34 /* CharacterCodes.doubleQuote */) + '"';
            }
        }
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 16 /* SyntaxKind.TemplateHead */:
        case 17 /* SyntaxKind.TemplateMiddle */:
        case 18 /* SyntaxKind.TemplateTail */: {
            // If a NoSubstitutionTemplateLiteral appears to have a substitution in it, the original text
            // had to include a backslash: `not \${a} substitution`.
            const escapeText = flags & 1 /* GetLiteralTextFlags.NeverAsciiEscape */ || (getEmitFlags(node) & 16777216 /* EmitFlags.NoAsciiEscaping */) ? escapeString :
                escapeNonAsciiString;
            const rawText = node.rawText ?? escapeTemplateSubstitution(escapeText(node.text, 96 /* CharacterCodes.backtick */));
            switch (node.kind) {
                case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
                    return "`" + rawText + "`";
                case 16 /* SyntaxKind.TemplateHead */:
                    return "`" + rawText + "${";
                case 17 /* SyntaxKind.TemplateMiddle */:
                    return "}" + rawText + "${";
                case 18 /* SyntaxKind.TemplateTail */:
                    return "}" + rawText + "`";
            }
            break;
        }
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
            return node.text;
        case 14 /* SyntaxKind.RegularExpressionLiteral */:
            if (flags & 4 /* GetLiteralTextFlags.TerminateUnterminatedLiterals */ && node.isUnterminated) {
                return node.text + (node.text.charCodeAt(node.text.length - 1) === 92 /* CharacterCodes.backslash */ ? " /" : "/");
            }
            return node.text;
    }
    return ts_js_1.Debug.fail(`Literal kind '${node.kind}' not accounted for.`);
}
function canUseOriginalText(node, flags) {
    if (nodeIsSynthesized(node) || !node.parent || (flags & 4 /* GetLiteralTextFlags.TerminateUnterminatedLiterals */ && node.isUnterminated)) {
        return false;
    }
    if ((0, ts_js_1.isNumericLiteral)(node)) {
        if (node.numericLiteralFlags & 26656 /* TokenFlags.IsInvalid */) {
            return false;
        }
        if (node.numericLiteralFlags & 512 /* TokenFlags.ContainsSeparator */) {
            return !!(flags & 8 /* GetLiteralTextFlags.AllowNumericSeparator */);
        }
    }
    return !(0, ts_js_1.isBigIntLiteral)(node);
}
/** @internal */
function getTextOfConstantValue(value) {
    return (0, ts_js_1.isString)(value) ? `"${escapeString(value)}"` : "" + value;
}
// Make an identifier from an external module name by extracting the string after the last "/" and replacing
// all non-alphanumeric characters with underscores
/** @internal */
function makeIdentifierFromModuleName(moduleName) {
    return (0, ts_js_1.getBaseFileName)(moduleName).replace(/^(\d)/, "_$1").replace(/\W/g, "_");
}
/** @internal */
function isBlockOrCatchScoped(declaration) {
    return ((0, ts_js_1.getCombinedNodeFlags)(declaration) & 7 /* NodeFlags.BlockScoped */) !== 0 ||
        isCatchClauseVariableDeclarationOrBindingElement(declaration);
}
/** @internal */
function isCatchClauseVariableDeclarationOrBindingElement(declaration) {
    const node = getRootDeclaration(declaration);
    return node.kind === 261 /* SyntaxKind.VariableDeclaration */ && node.parent.kind === 300 /* SyntaxKind.CatchClause */;
}
/** @internal */
function isAmbientModule(node) {
    return (0, ts_js_1.isModuleDeclaration)(node) && (node.name.kind === 11 /* SyntaxKind.StringLiteral */ || isGlobalScopeAugmentation(node));
}
/** @internal */
function isModuleWithStringLiteralName(node) {
    return (0, ts_js_1.isModuleDeclaration)(node) && node.name.kind === 11 /* SyntaxKind.StringLiteral */;
}
/** @internal */
function isNonGlobalAmbientModule(node) {
    return (0, ts_js_1.isModuleDeclaration)(node) && (0, ts_js_1.isStringLiteral)(node.name);
}
/**
 * An effective module (namespace) declaration is either
 * 1. An actual declaration: namespace X { ... }
 * 2. A Javascript declaration, which is:
 *    An identifier in a nested property access expression: Y in `X.Y.Z = { ... }`
 */
function isEffectiveModuleDeclaration(node) {
    return (0, ts_js_1.isModuleDeclaration)(node) || (0, ts_js_1.isIdentifier)(node);
}
/**
 * Given a symbol for a module, checks that it is a shorthand ambient module.
 *
 * @internal
 */
function isShorthandAmbientModuleSymbol(moduleSymbol) {
    return isShorthandAmbientModule(moduleSymbol.valueDeclaration);
}
function isShorthandAmbientModule(node) {
    // The only kind of module that can be missing a body is a shorthand ambient module.
    return !!node && node.kind === 268 /* SyntaxKind.ModuleDeclaration */ && (!node.body);
}
/** @internal */
function isBlockScopedContainerTopLevel(node) {
    return node.kind === 308 /* SyntaxKind.SourceFile */ ||
        node.kind === 268 /* SyntaxKind.ModuleDeclaration */ ||
        (0, ts_js_1.isFunctionLikeOrClassStaticBlockDeclaration)(node);
}
/** @internal */
function isGlobalScopeAugmentation(module) {
    return !!(module.flags & 2048 /* NodeFlags.GlobalAugmentation */);
}
/** @internal */
function isExternalModuleAugmentation(node) {
    return isAmbientModule(node) && isModuleAugmentationExternal(node);
}
/** @internal */
function isModuleAugmentationExternal(node) {
    // external module augmentation is a ambient module declaration that is either:
    // - defined in the top level scope and source file is an external module
    // - defined inside ambient module declaration located in the top level scope and source file not an external module
    switch (node.parent.kind) {
        case 308 /* SyntaxKind.SourceFile */:
            return (0, ts_js_1.isExternalModule)(node.parent);
        case 269 /* SyntaxKind.ModuleBlock */:
            return isAmbientModule(node.parent.parent) && (0, ts_js_1.isSourceFile)(node.parent.parent.parent) && !(0, ts_js_1.isExternalModule)(node.parent.parent.parent);
    }
    return false;
}
/** @internal */
function getNonAugmentationDeclaration(symbol) {
    return symbol.declarations?.find(d => !isExternalModuleAugmentation(d) && !((0, ts_js_1.isModuleDeclaration)(d) && isGlobalScopeAugmentation(d)));
}
function isCommonJSContainingModuleKind(kind) {
    return kind === ts_js_1.ModuleKind.CommonJS || ts_js_1.ModuleKind.Node16 <= kind && kind <= ts_js_1.ModuleKind.NodeNext;
}
/** @internal */
function isEffectiveExternalModule(node, compilerOptions) {
    return (0, ts_js_1.isExternalModule)(node) || (isCommonJSContainingModuleKind((0, exports.getEmitModuleKind)(compilerOptions)) && !!node.commonJsModuleIndicator);
}
/**
 * Returns whether the source file will be treated as if it were in strict mode at runtime.
 *
 * @internal
 */
function isEffectiveStrictModeSourceFile(node, compilerOptions) {
    // We can only verify strict mode for JS/TS files
    switch (node.scriptKind) {
        case 1 /* ScriptKind.JS */:
        case 3 /* ScriptKind.TS */:
        case 2 /* ScriptKind.JSX */:
        case 4 /* ScriptKind.TSX */:
            break;
        default:
            return false;
    }
    // Strict mode does not matter for declaration files.
    if (node.isDeclarationFile) {
        return false;
    }
    // If `alwaysStrict` is set, then treat the file as strict.
    if ((0, exports.getAlwaysStrict)(compilerOptions)) {
        return true;
    }
    // Starting with a "use strict" directive indicates the file is strict.
    if ((0, ts_js_1.startsWithUseStrict)(node.statements)) {
        return true;
    }
    if ((0, ts_js_1.isExternalModule)(node) || (0, exports.getIsolatedModules)(compilerOptions)) {
        // Modules are always strict.
        return true;
    }
    return false;
}
/** @internal */
function isAmbientPropertyDeclaration(node) {
    return !!(node.flags & 33554432 /* NodeFlags.Ambient */) || hasSyntacticModifier(node, 128 /* ModifierFlags.Ambient */);
}
/** @internal */
function isBlockScope(node, parentNode) {
    switch (node.kind) {
        case 308 /* SyntaxKind.SourceFile */:
        case 270 /* SyntaxKind.CaseBlock */:
        case 300 /* SyntaxKind.CatchClause */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 177 /* SyntaxKind.Constructor */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
            return true;
        case 242 /* SyntaxKind.Block */:
            // function block is not considered block-scope container
            // see comment in binder.ts: bind(...), case for SyntaxKind.Block
            return !(0, ts_js_1.isFunctionLikeOrClassStaticBlockDeclaration)(parentNode);
    }
    return false;
}
/** @internal */
function isDeclarationWithTypeParameters(node) {
    switch (node.kind) {
        case 339 /* SyntaxKind.JSDocCallbackTag */:
        case 347 /* SyntaxKind.JSDocTypedefTag */:
        case 324 /* SyntaxKind.JSDocSignature */:
            return true;
        default:
            return isDeclarationWithTypeParameterChildren(node);
    }
}
/** @internal */
function isDeclarationWithTypeParameterChildren(node) {
    switch (node.kind) {
        case 180 /* SyntaxKind.CallSignature */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 185 /* SyntaxKind.FunctionType */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 346 /* SyntaxKind.JSDocTemplateTag */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 177 /* SyntaxKind.Constructor */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
            return true;
        default:
            (0, ts_js_1.assertType)(node.kind);
            return false;
    }
}
/** @internal */
function isAnyImportSyntax(node) {
    switch (node.kind) {
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function isAnyImportOrBareOrAccessedRequire(node) {
    return isAnyImportSyntax(node) || isVariableDeclarationInitializedToBareOrAccessedRequire(node);
}
/** @internal */
function isAnyImportOrRequireStatement(node) {
    return isAnyImportSyntax(node) || isRequireVariableStatement(node);
}
/** @internal */
function isLateVisibilityPaintedStatement(node) {
    switch (node.kind) {
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 244 /* SyntaxKind.VariableStatement */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 267 /* SyntaxKind.EnumDeclaration */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function hasPossibleExternalModuleReference(node) {
    return isAnyImportOrReExport(node) || (0, ts_js_1.isModuleDeclaration)(node) || (0, ts_js_1.isImportTypeNode)(node) || isImportCall(node);
}
/** @internal */
function isAnyImportOrReExport(node) {
    return isAnyImportSyntax(node) || (0, ts_js_1.isExportDeclaration)(node);
}
/** @internal */
function getEnclosingContainer(node) {
    return (0, ts_js_1.findAncestor)(node.parent, n => !!((0, ts_js_1.getContainerFlags)(n) & 1 /* ContainerFlags.IsContainer */));
}
// Gets the nearest enclosing block scope container that has the provided node
// as a descendant, that is not the provided node.
/** @internal */
function getEnclosingBlockScopeContainer(node) {
    return (0, ts_js_1.findAncestor)(node.parent, current => isBlockScope(current, current.parent));
}
/** @internal */
function forEachEnclosingBlockScopeContainer(node, cb) {
    let container = getEnclosingBlockScopeContainer(node);
    while (container) {
        cb(container);
        container = getEnclosingBlockScopeContainer(container);
    }
}
// Return display name of an identifier
// Computed property names will just be emitted as "[<expr>]", where <expr> is the source
// text of the expression in the computed property.
/** @internal */
function declarationNameToString(name) {
    return !name || getFullWidth(name) === 0 ? "(Missing)" : getTextOfNode(name);
}
/** @internal */
function getNameFromIndexInfo(info) {
    return info.declaration ? declarationNameToString(info.declaration.parameters[0].name) : undefined;
}
/** @internal */
function isComputedNonLiteralName(name) {
    return name.kind === 168 /* SyntaxKind.ComputedPropertyName */ && !isStringOrNumericLiteralLike(name.expression);
}
/** @internal */
function tryGetTextOfPropertyName(name) {
    switch (name.kind) {
        case 80 /* SyntaxKind.Identifier */:
        case 81 /* SyntaxKind.PrivateIdentifier */:
            return name.emitNode?.autoGenerate ? undefined : name.escapedText;
        case 11 /* SyntaxKind.StringLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
            return (0, ts_js_1.escapeLeadingUnderscores)(name.text);
        case 168 /* SyntaxKind.ComputedPropertyName */:
            if (isStringOrNumericLiteralLike(name.expression))
                return (0, ts_js_1.escapeLeadingUnderscores)(name.expression.text);
            return undefined;
        case 296 /* SyntaxKind.JsxNamespacedName */:
            return getEscapedTextOfJsxNamespacedName(name);
        default:
            return ts_js_1.Debug.assertNever(name);
    }
}
/** @internal */
function getTextOfPropertyName(name) {
    return ts_js_1.Debug.checkDefined(tryGetTextOfPropertyName(name));
}
/** @internal */
function entityNameToString(name) {
    switch (name.kind) {
        case 110 /* SyntaxKind.ThisKeyword */:
            return "this";
        case 81 /* SyntaxKind.PrivateIdentifier */:
        case 80 /* SyntaxKind.Identifier */:
            return getFullWidth(name) === 0 ? (0, ts_js_1.idText)(name) : getTextOfNode(name);
        case 167 /* SyntaxKind.QualifiedName */:
            return entityNameToString(name.left) + "." + entityNameToString(name.right);
        case 212 /* SyntaxKind.PropertyAccessExpression */:
            if ((0, ts_js_1.isIdentifier)(name.name) || (0, ts_js_1.isPrivateIdentifier)(name.name)) {
                return entityNameToString(name.expression) + "." + entityNameToString(name.name);
            }
            else {
                return ts_js_1.Debug.assertNever(name.name);
            }
        case 312 /* SyntaxKind.JSDocMemberName */:
            return entityNameToString(name.left) + "#" + entityNameToString(name.right);
        case 296 /* SyntaxKind.JsxNamespacedName */:
            return entityNameToString(name.namespace) + ":" + entityNameToString(name.name);
        default:
            return ts_js_1.Debug.assertNever(name);
    }
}
/** @internal */
function createDiagnosticForNode(node, message, ...args) {
    const sourceFile = getSourceFileOfNode(node);
    return createDiagnosticForNodeInSourceFile(sourceFile, node, message, ...args);
}
/** @internal */
function createDiagnosticForNodeArray(sourceFile, nodes, message, ...args) {
    const start = (0, ts_js_1.skipTrivia)(sourceFile.text, nodes.pos);
    return createFileDiagnostic(sourceFile, start, nodes.end - start, message, ...args);
}
/** @internal */
function createDiagnosticForNodeInSourceFile(sourceFile, node, message, ...args) {
    const span = getErrorSpanForNode(sourceFile, node);
    return createFileDiagnostic(sourceFile, span.start, span.length, message, ...args);
}
/** @internal */
function createDiagnosticForNodeFromMessageChain(sourceFile, node, messageChain, relatedInformation) {
    const span = getErrorSpanForNode(sourceFile, node);
    return createFileDiagnosticFromMessageChain(sourceFile, span.start, span.length, messageChain, relatedInformation);
}
/** @internal */
function createDiagnosticForNodeArrayFromMessageChain(sourceFile, nodes, messageChain, relatedInformation) {
    const start = (0, ts_js_1.skipTrivia)(sourceFile.text, nodes.pos);
    return createFileDiagnosticFromMessageChain(sourceFile, start, nodes.end - start, messageChain, relatedInformation);
}
function assertDiagnosticLocation(sourceText, start, length) {
    ts_js_1.Debug.assertGreaterThanOrEqual(start, 0);
    ts_js_1.Debug.assertGreaterThanOrEqual(length, 0);
    ts_js_1.Debug.assertLessThanOrEqual(start, sourceText.length);
    ts_js_1.Debug.assertLessThanOrEqual(start + length, sourceText.length);
}
/** @internal */
function createFileDiagnosticFromMessageChain(file, start, length, messageChain, relatedInformation) {
    assertDiagnosticLocation(file.text, start, length);
    return {
        file,
        start,
        length,
        code: messageChain.code,
        category: messageChain.category,
        messageText: messageChain.next ? messageChain : messageChain.messageText,
        relatedInformation,
        canonicalHead: messageChain.canonicalHead,
    };
}
/** @internal */
function createDiagnosticForFileFromMessageChain(sourceFile, messageChain, relatedInformation) {
    return {
        file: sourceFile,
        start: 0,
        length: 0,
        code: messageChain.code,
        category: messageChain.category,
        messageText: messageChain.next ? messageChain : messageChain.messageText,
        relatedInformation,
    };
}
/** @internal */
function createDiagnosticMessageChainFromDiagnostic(diagnostic) {
    return typeof diagnostic.messageText === "string" ? {
        code: diagnostic.code,
        category: diagnostic.category,
        messageText: diagnostic.messageText,
        next: diagnostic.next,
    } : diagnostic.messageText;
}
/** @internal */
function createDiagnosticForRange(sourceFile, range, message) {
    return {
        file: sourceFile,
        start: range.pos,
        length: range.end - range.pos,
        code: message.code,
        category: message.category,
        messageText: message.message,
    };
}
/** @internal */
function getCanonicalDiagnostic(message, ...args) {
    return {
        code: message.code,
        messageText: formatMessage(message, ...args),
    };
}
/** @internal */
function getSpanOfTokenAtPosition(sourceFile, pos) {
    const scanner = (0, ts_js_1.createScanner)(sourceFile.languageVersion, /*skipTrivia*/ true, sourceFile.languageVariant, sourceFile.text, /*onError*/ undefined, pos);
    scanner.scan();
    const start = scanner.getTokenStart();
    return (0, ts_js_1.createTextSpanFromBounds)(start, scanner.getTokenEnd());
}
/** @internal */
function scanTokenAtPosition(sourceFile, pos) {
    const scanner = (0, ts_js_1.createScanner)(sourceFile.languageVersion, /*skipTrivia*/ true, sourceFile.languageVariant, sourceFile.text, /*onError*/ undefined, pos);
    scanner.scan();
    return scanner.getToken();
}
function getErrorSpanForArrowFunction(sourceFile, node) {
    const pos = (0, ts_js_1.skipTrivia)(sourceFile.text, node.pos);
    if (node.body && node.body.kind === 242 /* SyntaxKind.Block */) {
        const { line: startLine } = (0, ts_js_1.getLineAndCharacterOfPosition)(sourceFile, node.body.pos);
        const { line: endLine } = (0, ts_js_1.getLineAndCharacterOfPosition)(sourceFile, node.body.end);
        if (startLine < endLine) {
            // The arrow function spans multiple lines,
            // make the error span be the first line, inclusive.
            return (0, ts_js_1.createTextSpan)(pos, getEndLinePosition(startLine, sourceFile) - pos + 1);
        }
    }
    return (0, ts_js_1.createTextSpanFromBounds)(pos, node.end);
}
/** @internal */
function getErrorSpanForNode(sourceFile, node) {
    let errorNode = node;
    switch (node.kind) {
        case 308 /* SyntaxKind.SourceFile */: {
            const pos = (0, ts_js_1.skipTrivia)(sourceFile.text, 0, /*stopAfterLineBreak*/ false);
            if (pos === sourceFile.text.length) {
                // file is empty - return span for the beginning of the file
                return (0, ts_js_1.createTextSpan)(0, 0);
            }
            return getSpanOfTokenAtPosition(sourceFile, pos);
        }
        // This list is a work in progress. Add missing node kinds to improve their error
        // spans.
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 209 /* SyntaxKind.BindingElement */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 307 /* SyntaxKind.EnumMember */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 275 /* SyntaxKind.NamespaceImport */:
            errorNode = node.name;
            break;
        case 220 /* SyntaxKind.ArrowFunction */:
            return getErrorSpanForArrowFunction(sourceFile, node);
        case 297 /* SyntaxKind.CaseClause */:
        case 298 /* SyntaxKind.DefaultClause */: {
            const start = (0, ts_js_1.skipTrivia)(sourceFile.text, node.pos);
            const end = node.statements.length > 0 ? node.statements[0].pos : node.end;
            return (0, ts_js_1.createTextSpanFromBounds)(start, end);
        }
        case 254 /* SyntaxKind.ReturnStatement */:
        case 230 /* SyntaxKind.YieldExpression */: {
            const pos = (0, ts_js_1.skipTrivia)(sourceFile.text, node.pos);
            return getSpanOfTokenAtPosition(sourceFile, pos);
        }
        case 239 /* SyntaxKind.SatisfiesExpression */: {
            const pos = (0, ts_js_1.skipTrivia)(sourceFile.text, node.expression.end);
            return getSpanOfTokenAtPosition(sourceFile, pos);
        }
        case 351 /* SyntaxKind.JSDocSatisfiesTag */: {
            const pos = (0, ts_js_1.skipTrivia)(sourceFile.text, node.tagName.pos);
            return getSpanOfTokenAtPosition(sourceFile, pos);
        }
        case 177 /* SyntaxKind.Constructor */: {
            const constructorDeclaration = node;
            const start = (0, ts_js_1.skipTrivia)(sourceFile.text, constructorDeclaration.pos);
            const scanner = (0, ts_js_1.createScanner)(sourceFile.languageVersion, /*skipTrivia*/ true, sourceFile.languageVariant, sourceFile.text, /*onError*/ undefined, start);
            let token = scanner.scan();
            while (token !== 137 /* SyntaxKind.ConstructorKeyword */ && token !== 1 /* SyntaxKind.EndOfFileToken */) {
                token = scanner.scan();
            }
            const end = scanner.getTokenEnd();
            return (0, ts_js_1.createTextSpanFromBounds)(start, end);
        }
    }
    if (errorNode === undefined) {
        // If we don't have a better node, then just set the error on the first token of
        // construct.
        return getSpanOfTokenAtPosition(sourceFile, node.pos);
    }
    ts_js_1.Debug.assert(!(0, ts_js_1.isJSDoc)(errorNode));
    const isMissing = nodeIsMissing(errorNode);
    const pos = isMissing || (0, ts_js_1.isJsxText)(node)
        ? errorNode.pos
        : (0, ts_js_1.skipTrivia)(sourceFile.text, errorNode.pos);
    // These asserts should all be satisfied for a properly constructed `errorNode`.
    if (isMissing) {
        ts_js_1.Debug.assert(pos === errorNode.pos, "This failure could trigger https://github.com/Microsoft/TypeScript/issues/20809");
        ts_js_1.Debug.assert(pos === errorNode.end, "This failure could trigger https://github.com/Microsoft/TypeScript/issues/20809");
    }
    else {
        ts_js_1.Debug.assert(pos >= errorNode.pos, "This failure could trigger https://github.com/Microsoft/TypeScript/issues/20809");
        ts_js_1.Debug.assert(pos <= errorNode.end, "This failure could trigger https://github.com/Microsoft/TypeScript/issues/20809");
    }
    return (0, ts_js_1.createTextSpanFromBounds)(pos, errorNode.end);
}
/** @internal */
function isGlobalSourceFile(node) {
    return node.kind === 308 /* SyntaxKind.SourceFile */ && !isExternalOrCommonJsModule(node);
}
/** @internal */
function isExternalOrCommonJsModule(file) {
    return (file.externalModuleIndicator || file.commonJsModuleIndicator) !== undefined;
}
/** @internal */
function isJsonSourceFile(file) {
    return file.scriptKind === 6 /* ScriptKind.JSON */;
}
/** @internal */
function isEnumConst(node) {
    return !!((0, ts_js_1.getCombinedModifierFlags)(node) & 4096 /* ModifierFlags.Const */);
}
/** @internal */
function isDeclarationReadonly(declaration) {
    return !!((0, ts_js_1.getCombinedModifierFlags)(declaration) & 8 /* ModifierFlags.Readonly */ && !(0, ts_js_1.isParameterPropertyDeclaration)(declaration, declaration.parent));
}
/**
 * Gets whether a bound `VariableDeclaration` or `VariableDeclarationList` is part of an `await using` declaration.
 * @internal
 */
function isVarAwaitUsing(node) {
    return ((0, ts_js_1.getCombinedNodeFlags)(node) & 7 /* NodeFlags.BlockScoped */) === 6 /* NodeFlags.AwaitUsing */;
}
/**
 * Gets whether a bound `VariableDeclaration` or `VariableDeclarationList` is part of a `using` declaration.
 * @internal
 */
function isVarUsing(node) {
    return ((0, ts_js_1.getCombinedNodeFlags)(node) & 7 /* NodeFlags.BlockScoped */) === 4 /* NodeFlags.Using */;
}
/**
 * Gets whether a bound `VariableDeclaration` or `VariableDeclarationList` is part of a `const` declaration.
 * @internal
 */
function isVarConst(node) {
    return ((0, ts_js_1.getCombinedNodeFlags)(node) & 7 /* NodeFlags.BlockScoped */) === 2 /* NodeFlags.Const */;
}
/**
 * Gets whether a bound `VariableDeclaration` or `VariableDeclarationList` is part of a `const`, `using` or `await using` declaration.
 * @internal
 */
function isVarConstLike(node) {
    const blockScopeKind = (0, ts_js_1.getCombinedNodeFlags)(node) & 7 /* NodeFlags.BlockScoped */;
    return blockScopeKind === 2 /* NodeFlags.Const */ ||
        blockScopeKind === 4 /* NodeFlags.Using */ ||
        blockScopeKind === 6 /* NodeFlags.AwaitUsing */;
}
/**
 * Gets whether a bound `VariableDeclaration` or `VariableDeclarationList` is part of a `let` declaration.
 * @internal
 */
function isLet(node) {
    return ((0, ts_js_1.getCombinedNodeFlags)(node) & 7 /* NodeFlags.BlockScoped */) === 1 /* NodeFlags.Let */;
}
/** @internal */
function isSuperCall(n) {
    return n.kind === 214 /* SyntaxKind.CallExpression */ && n.expression.kind === 108 /* SyntaxKind.SuperKeyword */;
}
/** @internal */
function isImportCall(n) {
    if (n.kind !== 214 /* SyntaxKind.CallExpression */)
        return false;
    const e = n.expression;
    return e.kind === 102 /* SyntaxKind.ImportKeyword */ || ((0, ts_js_1.isMetaProperty)(e)
        && e.keywordToken === 102 /* SyntaxKind.ImportKeyword */
        && e.name.escapedText === "defer");
}
/** @internal */
function isImportMeta(n) {
    return (0, ts_js_1.isMetaProperty)(n)
        && n.keywordToken === 102 /* SyntaxKind.ImportKeyword */
        && n.name.escapedText === "meta";
}
/** @internal */
function isLiteralImportTypeNode(n) {
    return (0, ts_js_1.isImportTypeNode)(n) && (0, ts_js_1.isLiteralTypeNode)(n.argument) && (0, ts_js_1.isStringLiteral)(n.argument.literal);
}
/** @internal */
function isPrologueDirective(node) {
    return node.kind === 245 /* SyntaxKind.ExpressionStatement */
        && node.expression.kind === 11 /* SyntaxKind.StringLiteral */;
}
/** @internal */
function isCustomPrologue(node) {
    return !!(getEmitFlags(node) & 2097152 /* EmitFlags.CustomPrologue */);
}
/** @internal */
function isHoistedFunction(node) {
    return isCustomPrologue(node)
        && (0, ts_js_1.isFunctionDeclaration)(node);
}
function isHoistedVariable(node) {
    return (0, ts_js_1.isIdentifier)(node.name)
        && !node.initializer;
}
/** @internal */
function isHoistedVariableStatement(node) {
    return isCustomPrologue(node)
        && (0, ts_js_1.isVariableStatement)(node)
        && (0, ts_js_1.every)(node.declarationList.declarations, isHoistedVariable);
}
/** @internal */
function getLeadingCommentRangesOfNode(node, sourceFileOfNode) {
    return node.kind !== 12 /* SyntaxKind.JsxText */ ? (0, ts_js_1.getLeadingCommentRanges)(sourceFileOfNode.text, node.pos) : undefined;
}
/** @internal */
function getJSDocCommentRanges(node, text) {
    const commentRanges = (node.kind === 170 /* SyntaxKind.Parameter */ ||
        node.kind === 169 /* SyntaxKind.TypeParameter */ ||
        node.kind === 219 /* SyntaxKind.FunctionExpression */ ||
        node.kind === 220 /* SyntaxKind.ArrowFunction */ ||
        node.kind === 218 /* SyntaxKind.ParenthesizedExpression */ ||
        node.kind === 261 /* SyntaxKind.VariableDeclaration */ ||
        node.kind === 282 /* SyntaxKind.ExportSpecifier */) ?
        (0, ts_js_1.concatenate)((0, ts_js_1.getTrailingCommentRanges)(text, node.pos), (0, ts_js_1.getLeadingCommentRanges)(text, node.pos)) :
        (0, ts_js_1.getLeadingCommentRanges)(text, node.pos);
    // True if the comment starts with '/**' but not if it is '/**/'
    return (0, ts_js_1.filter)(commentRanges, comment => comment.end <= node.end && // Due to parse errors sometime empty parameter may get comments assigned to it that end up not in parameter range
        text.charCodeAt(comment.pos + 1) === 42 /* CharacterCodes.asterisk */ &&
        text.charCodeAt(comment.pos + 2) === 42 /* CharacterCodes.asterisk */ &&
        text.charCodeAt(comment.pos + 3) !== 47 /* CharacterCodes.slash */);
}
const fullTripleSlashReferencePathRegEx = /^\/\/\/\s*<reference\s+path\s*=\s*(?:'[^']*'|"[^"]*").*?\/>/;
const fullTripleSlashReferenceTypeReferenceDirectiveRegEx = /^\/\/\/\s*<reference\s+types\s*=\s*(?:'[^']*'|"[^"]*").*?\/>/;
const fullTripleSlashLibReferenceRegEx = /^\/\/\/\s*<reference\s+lib\s*=\s*(?:'[^']*'|"[^"]*").*?\/>/;
const fullTripleSlashAMDReferencePathRegEx = /^\/\/\/\s*<amd-dependency\s+path\s*=\s*(?:'[^']*'|"[^"]*").*?\/>/;
const fullTripleSlashAMDModuleRegEx = /^\/\/\/\s*<amd-module\s+(?:\S.*?)??\/>/;
const defaultLibReferenceRegEx = /^\/\/\/\s*<reference\s+no-default-lib\s*=\s*(?:'[^']*'|"[^"]*")\s*\/>/;
function isPartOfTypeNode(node) {
    if (183 /* SyntaxKind.FirstTypeNode */ <= node.kind && node.kind <= 206 /* SyntaxKind.LastTypeNode */) {
        return true;
    }
    switch (node.kind) {
        case 133 /* SyntaxKind.AnyKeyword */:
        case 159 /* SyntaxKind.UnknownKeyword */:
        case 150 /* SyntaxKind.NumberKeyword */:
        case 163 /* SyntaxKind.BigIntKeyword */:
        case 154 /* SyntaxKind.StringKeyword */:
        case 136 /* SyntaxKind.BooleanKeyword */:
        case 155 /* SyntaxKind.SymbolKeyword */:
        case 151 /* SyntaxKind.ObjectKeyword */:
        case 157 /* SyntaxKind.UndefinedKeyword */:
        case 106 /* SyntaxKind.NullKeyword */:
        case 146 /* SyntaxKind.NeverKeyword */:
            return true;
        case 116 /* SyntaxKind.VoidKeyword */:
            return node.parent.kind !== 223 /* SyntaxKind.VoidExpression */;
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
            return isPartOfTypeExpressionWithTypeArguments(node);
        case 169 /* SyntaxKind.TypeParameter */:
            return node.parent.kind === 201 /* SyntaxKind.MappedType */ || node.parent.kind === 196 /* SyntaxKind.InferType */;
        // Identifiers and qualified names may be type nodes, depending on their context. Climb
        // above them to find the lowest container
        case 80 /* SyntaxKind.Identifier */:
            // If the identifier is the RHS of a qualified name, then it's a type iff its parent is.
            if (node.parent.kind === 167 /* SyntaxKind.QualifiedName */ && node.parent.right === node) {
                node = node.parent;
            }
            else if (node.parent.kind === 212 /* SyntaxKind.PropertyAccessExpression */ && node.parent.name === node) {
                node = node.parent;
            }
            // At this point, node is either a qualified name or an identifier
            ts_js_1.Debug.assert(node.kind === 80 /* SyntaxKind.Identifier */ || node.kind === 167 /* SyntaxKind.QualifiedName */ || node.kind === 212 /* SyntaxKind.PropertyAccessExpression */, "'node' was expected to be a qualified name, identifier or property access in 'isPartOfTypeNode'.");
        // falls through
        case 167 /* SyntaxKind.QualifiedName */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 110 /* SyntaxKind.ThisKeyword */: {
            const { parent } = node;
            if (parent.kind === 187 /* SyntaxKind.TypeQuery */) {
                return false;
            }
            if (parent.kind === 206 /* SyntaxKind.ImportType */) {
                return !parent.isTypeOf;
            }
            // Do not recursively call isPartOfTypeNode on the parent. In the example:
            //
            //     let a: A.B.C;
            //
            // Calling isPartOfTypeNode would consider the qualified name A.B a type node.
            // Only C and A.B.C are type nodes.
            if (183 /* SyntaxKind.FirstTypeNode */ <= parent.kind && parent.kind <= 206 /* SyntaxKind.LastTypeNode */) {
                return true;
            }
            switch (parent.kind) {
                case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
                    return isPartOfTypeExpressionWithTypeArguments(parent);
                case 169 /* SyntaxKind.TypeParameter */:
                    return node === parent.constraint;
                case 346 /* SyntaxKind.JSDocTemplateTag */:
                    return node === parent.constraint;
                case 173 /* SyntaxKind.PropertyDeclaration */:
                case 172 /* SyntaxKind.PropertySignature */:
                case 170 /* SyntaxKind.Parameter */:
                case 261 /* SyntaxKind.VariableDeclaration */:
                    return node === parent.type;
                case 263 /* SyntaxKind.FunctionDeclaration */:
                case 219 /* SyntaxKind.FunctionExpression */:
                case 220 /* SyntaxKind.ArrowFunction */:
                case 177 /* SyntaxKind.Constructor */:
                case 175 /* SyntaxKind.MethodDeclaration */:
                case 174 /* SyntaxKind.MethodSignature */:
                case 178 /* SyntaxKind.GetAccessor */:
                case 179 /* SyntaxKind.SetAccessor */:
                    return node === parent.type;
                case 180 /* SyntaxKind.CallSignature */:
                case 181 /* SyntaxKind.ConstructSignature */:
                case 182 /* SyntaxKind.IndexSignature */:
                    return node === parent.type;
                case 217 /* SyntaxKind.TypeAssertionExpression */:
                    return node === parent.type;
                case 214 /* SyntaxKind.CallExpression */:
                case 215 /* SyntaxKind.NewExpression */:
                case 216 /* SyntaxKind.TaggedTemplateExpression */:
                    return (0, ts_js_1.contains)(parent.typeArguments, node);
            }
        }
    }
    return false;
}
function isPartOfTypeExpressionWithTypeArguments(node) {
    return (0, ts_js_1.isJSDocImplementsTag)(node.parent)
        || (0, ts_js_1.isJSDocAugmentsTag)(node.parent)
        || (0, ts_js_1.isHeritageClause)(node.parent) && !isExpressionWithTypeArgumentsInClassExtendsClause(node);
}
// Warning: This has the same semantics as the forEach family of functions,
//          in that traversal terminates in the event that 'visitor' supplies a truthy value.
/** @internal */
function forEachReturnStatement(body, visitor) {
    return traverse(body);
    function traverse(node) {
        switch (node.kind) {
            case 254 /* SyntaxKind.ReturnStatement */:
                return visitor(node);
            case 270 /* SyntaxKind.CaseBlock */:
            case 242 /* SyntaxKind.Block */:
            case 246 /* SyntaxKind.IfStatement */:
            case 247 /* SyntaxKind.DoStatement */:
            case 248 /* SyntaxKind.WhileStatement */:
            case 249 /* SyntaxKind.ForStatement */:
            case 250 /* SyntaxKind.ForInStatement */:
            case 251 /* SyntaxKind.ForOfStatement */:
            case 255 /* SyntaxKind.WithStatement */:
            case 256 /* SyntaxKind.SwitchStatement */:
            case 297 /* SyntaxKind.CaseClause */:
            case 298 /* SyntaxKind.DefaultClause */:
            case 257 /* SyntaxKind.LabeledStatement */:
            case 259 /* SyntaxKind.TryStatement */:
            case 300 /* SyntaxKind.CatchClause */:
                return (0, ts_js_1.forEachChild)(node, traverse);
        }
    }
}
// Warning: This has the same semantics as the forEach family of functions,
//          in that traversal terminates in the event that 'visitor' supplies a truthy value.
/** @internal */
function forEachYieldExpression(body, visitor) {
    return traverse(body);
    function traverse(node) {
        switch (node.kind) {
            case 230 /* SyntaxKind.YieldExpression */:
                const value = visitor(node);
                if (value) {
                    return value;
                }
                const operand = node.expression;
                if (!operand) {
                    return;
                }
                return traverse(operand);
            case 267 /* SyntaxKind.EnumDeclaration */:
            case 265 /* SyntaxKind.InterfaceDeclaration */:
            case 268 /* SyntaxKind.ModuleDeclaration */:
            case 266 /* SyntaxKind.TypeAliasDeclaration */:
                // These are not allowed inside a generator now, but eventually they may be allowed
                // as local types. Regardless, skip them to avoid the work.
                return;
            default:
                if ((0, ts_js_1.isFunctionLike)(node)) {
                    if (node.name && node.name.kind === 168 /* SyntaxKind.ComputedPropertyName */) {
                        // Note that we will not include methods/accessors of a class because they would require
                        // first descending into the class. This is by design.
                        return traverse(node.name.expression);
                    }
                }
                else if (!isPartOfTypeNode(node)) {
                    // This is the general case, which should include mostly expressions and statements.
                    // Also includes NodeArrays.
                    return (0, ts_js_1.forEachChild)(node, traverse);
                }
        }
    }
}
/**
 * Gets the most likely element type for a TypeNode. This is not an exhaustive test
 * as it assumes a rest argument can only be an array type (either T[], or Array<T>).
 *
 * @param node The type node.
 *
 * @internal
 */
function getRestParameterElementType(node) {
    if (node && node.kind === 189 /* SyntaxKind.ArrayType */) {
        return node.elementType;
    }
    else if (node && node.kind === 184 /* SyntaxKind.TypeReference */) {
        return (0, ts_js_1.singleOrUndefined)(node.typeArguments);
    }
    else {
        return undefined;
    }
}
/** @internal */
function getMembersOfDeclaration(node) {
    switch (node.kind) {
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 188 /* SyntaxKind.TypeLiteral */:
            return node.members;
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
            return node.properties;
    }
}
/** @internal */
function isVariableLike(node) {
    if (node) {
        switch (node.kind) {
            case 209 /* SyntaxKind.BindingElement */:
            case 307 /* SyntaxKind.EnumMember */:
            case 170 /* SyntaxKind.Parameter */:
            case 304 /* SyntaxKind.PropertyAssignment */:
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 172 /* SyntaxKind.PropertySignature */:
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            case 261 /* SyntaxKind.VariableDeclaration */:
                return true;
        }
    }
    return false;
}
/** @internal */
function isVariableDeclarationInVariableStatement(node) {
    return node.parent.kind === 262 /* SyntaxKind.VariableDeclarationList */
        && node.parent.parent.kind === 244 /* SyntaxKind.VariableStatement */;
}
/** @internal */
function isCommonJsExportedExpression(node) {
    if (!isInJSFile(node))
        return false;
    return ((0, ts_js_1.isObjectLiteralExpression)(node.parent) && (0, ts_js_1.isBinaryExpression)(node.parent.parent) && getAssignmentDeclarationKind(node.parent.parent) === 2 /* AssignmentDeclarationKind.ModuleExports */) ||
        isCommonJsExportPropertyAssignment(node.parent);
}
/** @internal */
function isCommonJsExportPropertyAssignment(node) {
    if (!isInJSFile(node))
        return false;
    return ((0, ts_js_1.isBinaryExpression)(node) && getAssignmentDeclarationKind(node) === 1 /* AssignmentDeclarationKind.ExportsProperty */);
}
/** @internal */
function isValidESSymbolDeclaration(node) {
    return ((0, ts_js_1.isVariableDeclaration)(node) ? isVarConst(node) && (0, ts_js_1.isIdentifier)(node.name) && isVariableDeclarationInVariableStatement(node) :
        (0, ts_js_1.isPropertyDeclaration)(node) ? hasEffectiveReadonlyModifier(node) && hasStaticModifier(node) :
            (0, ts_js_1.isPropertySignature)(node) && hasEffectiveReadonlyModifier(node)) || isCommonJsExportPropertyAssignment(node);
}
/** @internal */
function introducesArgumentsExoticObject(node) {
    switch (node.kind) {
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 177 /* SyntaxKind.Constructor */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
            return true;
    }
    return false;
}
/** @internal */
function unwrapInnermostStatementOfLabel(node, beforeUnwrapLabelCallback) {
    while (true) {
        if (beforeUnwrapLabelCallback) {
            beforeUnwrapLabelCallback(node);
        }
        if (node.statement.kind !== 257 /* SyntaxKind.LabeledStatement */) {
            return node.statement;
        }
        node = node.statement;
    }
}
/** @internal */
function isFunctionBlock(node) {
    return node && node.kind === 242 /* SyntaxKind.Block */ && (0, ts_js_1.isFunctionLike)(node.parent);
}
/** @internal */
function isObjectLiteralMethod(node) {
    return node && node.kind === 175 /* SyntaxKind.MethodDeclaration */ && node.parent.kind === 211 /* SyntaxKind.ObjectLiteralExpression */;
}
/** @internal */
function isObjectLiteralOrClassExpressionMethodOrAccessor(node) {
    return (node.kind === 175 /* SyntaxKind.MethodDeclaration */ || node.kind === 178 /* SyntaxKind.GetAccessor */ || node.kind === 179 /* SyntaxKind.SetAccessor */) &&
        (node.parent.kind === 211 /* SyntaxKind.ObjectLiteralExpression */ ||
            node.parent.kind === 232 /* SyntaxKind.ClassExpression */);
}
/** @internal */
function isIdentifierTypePredicate(predicate) {
    return predicate && predicate.kind === 1 /* TypePredicateKind.Identifier */;
}
/** @internal */
function isThisTypePredicate(predicate) {
    return predicate && predicate.kind === 0 /* TypePredicateKind.This */;
}
/** @internal */
function forEachPropertyAssignment(objectLiteral, key, callback, key2) {
    return (0, ts_js_1.forEach)(objectLiteral?.properties, property => {
        if (!(0, ts_js_1.isPropertyAssignment)(property))
            return undefined;
        const propName = tryGetTextOfPropertyName(property.name);
        return key === propName || (key2 && key2 === propName) ?
            callback(property) :
            undefined;
    });
}
/** @internal */
function getTsConfigObjectLiteralExpression(tsConfigSourceFile) {
    if (tsConfigSourceFile && tsConfigSourceFile.statements.length) {
        const expression = tsConfigSourceFile.statements[0].expression;
        return (0, ts_js_1.tryCast)(expression, ts_js_1.isObjectLiteralExpression);
    }
}
/** @internal */
function getTsConfigPropArrayElementValue(tsConfigSourceFile, propKey, elementValue) {
    return forEachTsConfigPropArray(tsConfigSourceFile, propKey, property => (0, ts_js_1.isArrayLiteralExpression)(property.initializer) ?
        (0, ts_js_1.find)(property.initializer.elements, (element) => (0, ts_js_1.isStringLiteral)(element) && element.text === elementValue) :
        undefined);
}
/** @internal */
function forEachTsConfigPropArray(tsConfigSourceFile, propKey, callback) {
    return forEachPropertyAssignment(getTsConfigObjectLiteralExpression(tsConfigSourceFile), propKey, callback);
}
/** @internal */
function getContainingFunction(node) {
    return (0, ts_js_1.findAncestor)(node.parent, ts_js_1.isFunctionLike);
}
/** @internal */
function getContainingFunctionDeclaration(node) {
    return (0, ts_js_1.findAncestor)(node.parent, ts_js_1.isFunctionLikeDeclaration);
}
/** @internal */
function getContainingClass(node) {
    return (0, ts_js_1.findAncestor)(node.parent, ts_js_1.isClassLike);
}
/** @internal */
function getContainingClassStaticBlock(node) {
    return (0, ts_js_1.findAncestor)(node.parent, n => {
        if ((0, ts_js_1.isClassLike)(n) || (0, ts_js_1.isFunctionLike)(n)) {
            return "quit";
        }
        return (0, ts_js_1.isClassStaticBlockDeclaration)(n);
    });
}
/** @internal */
function getContainingFunctionOrClassStaticBlock(node) {
    return (0, ts_js_1.findAncestor)(node.parent, ts_js_1.isFunctionLikeOrClassStaticBlockDeclaration);
}
/** @internal */
function getContainingClassExcludingClassDecorators(node) {
    const decorator = (0, ts_js_1.findAncestor)(node.parent, n => (0, ts_js_1.isClassLike)(n) ? "quit" : (0, ts_js_1.isDecorator)(n));
    return decorator && (0, ts_js_1.isClassLike)(decorator.parent) ? getContainingClass(decorator.parent) : getContainingClass(decorator ?? node);
}
function getThisContainer(node, includeArrowFunctions, includeClassComputedPropertyName) {
    ts_js_1.Debug.assert(node.kind !== 308 /* SyntaxKind.SourceFile */);
    while (true) {
        node = node.parent;
        if (!node) {
            return ts_js_1.Debug.fail(); // If we never pass in a SourceFile, this should be unreachable, since we'll stop when we reach that.
        }
        switch (node.kind) {
            case 168 /* SyntaxKind.ComputedPropertyName */:
                // If the grandparent node is an object literal (as opposed to a class),
                // then the computed property is not a 'this' container.
                // A computed property name in a class needs to be a this container
                // so that we can error on it.
                if (includeClassComputedPropertyName && (0, ts_js_1.isClassLike)(node.parent.parent)) {
                    return node;
                }
                // If this is a computed property, then the parent should not
                // make it a this container. The parent might be a property
                // in an object literal, like a method or accessor. But in order for
                // such a parent to be a this container, the reference must be in
                // the *body* of the container.
                node = node.parent.parent;
                break;
            case 171 /* SyntaxKind.Decorator */:
                // Decorators are always applied outside of the body of a class or method.
                if (node.parent.kind === 170 /* SyntaxKind.Parameter */ && (0, ts_js_1.isClassElement)(node.parent.parent)) {
                    // If the decorator's parent is a Parameter, we resolve the this container from
                    // the grandparent class declaration.
                    node = node.parent.parent;
                }
                else if ((0, ts_js_1.isClassElement)(node.parent)) {
                    // If the decorator's parent is a class element, we resolve the 'this' container
                    // from the parent class declaration.
                    node = node.parent;
                }
                break;
            case 220 /* SyntaxKind.ArrowFunction */:
                if (!includeArrowFunctions) {
                    continue;
                }
            // falls through
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 219 /* SyntaxKind.FunctionExpression */:
            case 268 /* SyntaxKind.ModuleDeclaration */:
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 172 /* SyntaxKind.PropertySignature */:
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 174 /* SyntaxKind.MethodSignature */:
            case 177 /* SyntaxKind.Constructor */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
            case 180 /* SyntaxKind.CallSignature */:
            case 181 /* SyntaxKind.ConstructSignature */:
            case 182 /* SyntaxKind.IndexSignature */:
            case 267 /* SyntaxKind.EnumDeclaration */:
            case 308 /* SyntaxKind.SourceFile */:
                return node;
        }
    }
}
/**
 * @returns Whether the node creates a new 'this' scope for its children.
 *
 * @internal
 */
function isThisContainerOrFunctionBlock(node) {
    switch (node.kind) {
        // Arrow functions use the same scope, but may do so in a "delayed" manner
        // For example, `const getThis = () => this` may be before a super() call in a derived constructor
        case 220 /* SyntaxKind.ArrowFunction */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
            return true;
        case 242 /* SyntaxKind.Block */:
            switch (node.parent.kind) {
                case 177 /* SyntaxKind.Constructor */:
                case 175 /* SyntaxKind.MethodDeclaration */:
                case 178 /* SyntaxKind.GetAccessor */:
                case 179 /* SyntaxKind.SetAccessor */:
                    // Object properties can have computed names; only method-like bodies start a new scope
                    return true;
                default:
                    return false;
            }
        default:
            return false;
    }
}
/** @internal */
function isInTopLevelContext(node) {
    // The name of a class or function declaration is a BindingIdentifier in its surrounding scope.
    if ((0, ts_js_1.isIdentifier)(node) && ((0, ts_js_1.isClassDeclaration)(node.parent) || (0, ts_js_1.isFunctionDeclaration)(node.parent)) && node.parent.name === node) {
        node = node.parent;
    }
    const container = getThisContainer(node, /*includeArrowFunctions*/ true, /*includeClassComputedPropertyName*/ false);
    return (0, ts_js_1.isSourceFile)(container);
}
/** @internal */
function getNewTargetContainer(node) {
    const container = getThisContainer(node, /*includeArrowFunctions*/ false, /*includeClassComputedPropertyName*/ false);
    if (container) {
        switch (container.kind) {
            case 177 /* SyntaxKind.Constructor */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 219 /* SyntaxKind.FunctionExpression */:
                return container;
        }
    }
    return undefined;
}
function getSuperContainer(node, stopOnFunctions) {
    while (true) {
        node = node.parent;
        if (!node) {
            return undefined;
        }
        switch (node.kind) {
            case 168 /* SyntaxKind.ComputedPropertyName */:
                node = node.parent;
                break;
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 219 /* SyntaxKind.FunctionExpression */:
            case 220 /* SyntaxKind.ArrowFunction */:
                if (!stopOnFunctions) {
                    continue;
                }
            // falls through
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 172 /* SyntaxKind.PropertySignature */:
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 174 /* SyntaxKind.MethodSignature */:
            case 177 /* SyntaxKind.Constructor */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return node;
            case 171 /* SyntaxKind.Decorator */:
                // Decorators are always applied outside of the body of a class or method.
                if (node.parent.kind === 170 /* SyntaxKind.Parameter */ && (0, ts_js_1.isClassElement)(node.parent.parent)) {
                    // If the decorator's parent is a Parameter, we resolve the this container from
                    // the grandparent class declaration.
                    node = node.parent.parent;
                }
                else if ((0, ts_js_1.isClassElement)(node.parent)) {
                    // If the decorator's parent is a class element, we resolve the 'this' container
                    // from the parent class declaration.
                    node = node.parent;
                }
                break;
        }
    }
}
/** @internal */
function getImmediatelyInvokedFunctionExpression(func) {
    if (func.kind === 219 /* SyntaxKind.FunctionExpression */ || func.kind === 220 /* SyntaxKind.ArrowFunction */) {
        let prev = func;
        let parent = func.parent;
        while (parent.kind === 218 /* SyntaxKind.ParenthesizedExpression */) {
            prev = parent;
            parent = parent.parent;
        }
        if (parent.kind === 214 /* SyntaxKind.CallExpression */ && parent.expression === prev) {
            return parent;
        }
    }
}
/**
 * Determines whether a node is a property or element access expression for `super`.
 *
 * @internal
 */
function isSuperProperty(node) {
    const kind = node.kind;
    return (kind === 212 /* SyntaxKind.PropertyAccessExpression */ || kind === 213 /* SyntaxKind.ElementAccessExpression */)
        && node.expression.kind === 108 /* SyntaxKind.SuperKeyword */;
}
/**
 * Determines whether a node is a property or element access expression for `this`.
 *
 * @internal
 */
function isThisProperty(node) {
    const kind = node.kind;
    return (kind === 212 /* SyntaxKind.PropertyAccessExpression */ || kind === 213 /* SyntaxKind.ElementAccessExpression */)
        && node.expression.kind === 110 /* SyntaxKind.ThisKeyword */;
}
/** @internal */
function isThisInitializedDeclaration(node) {
    return !!node && (0, ts_js_1.isVariableDeclaration)(node) && node.initializer?.kind === 110 /* SyntaxKind.ThisKeyword */;
}
/** @internal */
function isThisInitializedObjectBindingExpression(node) {
    return !!node
        && ((0, ts_js_1.isShorthandPropertyAssignment)(node) || (0, ts_js_1.isPropertyAssignment)(node))
        && (0, ts_js_1.isBinaryExpression)(node.parent.parent)
        && node.parent.parent.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */
        && node.parent.parent.right.kind === 110 /* SyntaxKind.ThisKeyword */;
}
/** @internal */
function getEntityNameFromTypeNode(node) {
    switch (node.kind) {
        case 184 /* SyntaxKind.TypeReference */:
            return node.typeName;
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
            return isEntityNameExpression(node.expression)
                ? node.expression
                : undefined;
        // TODO(rbuckton): These aren't valid TypeNodes, but we treat them as such because of `isPartOfTypeNode`, which returns `true` for things that aren't `TypeNode`s.
        case 80 /* SyntaxKind.Identifier */:
        case 167 /* SyntaxKind.QualifiedName */:
            return node;
    }
    return undefined;
}
/** @internal */
function getInvokedExpression(node) {
    switch (node.kind) {
        case 216 /* SyntaxKind.TaggedTemplateExpression */:
            return node.tag;
        case 287 /* SyntaxKind.JsxOpeningElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
            return node.tagName;
        case 227 /* SyntaxKind.BinaryExpression */:
            return node.right;
        case 290 /* SyntaxKind.JsxOpeningFragment */:
            return node;
        default:
            return node.expression;
    }
}
/** @internal */
function nodeCanBeDecorated(useLegacyDecorators, node, parent, grandparent) {
    // private names cannot be used with decorators yet
    if (useLegacyDecorators && (0, ts_js_1.isNamedDeclaration)(node) && (0, ts_js_1.isPrivateIdentifier)(node.name)) {
        return false;
    }
    switch (node.kind) {
        case 264 /* SyntaxKind.ClassDeclaration */:
            // class declarations are valid targets
            return true;
        case 232 /* SyntaxKind.ClassExpression */:
            // class expressions are valid targets for native decorators
            return !useLegacyDecorators;
        case 173 /* SyntaxKind.PropertyDeclaration */:
            // property declarations are valid if their parent is a class declaration.
            return parent !== undefined
                && (useLegacyDecorators ? (0, ts_js_1.isClassDeclaration)(parent) : (0, ts_js_1.isClassLike)(parent) && !hasAbstractModifier(node) && !hasAmbientModifier(node));
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 175 /* SyntaxKind.MethodDeclaration */:
            // if this method has a body and its parent is a class declaration, this is a valid target.
            return node.body !== undefined
                && parent !== undefined
                && (useLegacyDecorators ? (0, ts_js_1.isClassDeclaration)(parent) : (0, ts_js_1.isClassLike)(parent));
        case 170 /* SyntaxKind.Parameter */:
            // TODO(rbuckton): Parameter decorator support for ES decorators must wait until it is standardized
            if (!useLegacyDecorators)
                return false;
            // if the parameter's parent has a body and its grandparent is a class declaration, this is a valid target.
            return parent !== undefined
                && parent.body !== undefined
                && (parent.kind === 177 /* SyntaxKind.Constructor */
                    || parent.kind === 175 /* SyntaxKind.MethodDeclaration */
                    || parent.kind === 179 /* SyntaxKind.SetAccessor */)
                && getThisParameter(parent) !== node
                && grandparent !== undefined
                && grandparent.kind === 264 /* SyntaxKind.ClassDeclaration */;
    }
    return false;
}
/** @internal */
function nodeIsDecorated(useLegacyDecorators, node, parent, grandparent) {
    return hasDecorators(node)
        && nodeCanBeDecorated(useLegacyDecorators, node, parent, grandparent);
}
/** @internal */
function nodeOrChildIsDecorated(useLegacyDecorators, node, parent, grandparent) {
    return nodeIsDecorated(useLegacyDecorators, node, parent, grandparent)
        || childIsDecorated(useLegacyDecorators, node, parent);
}
/** @internal */
function childIsDecorated(useLegacyDecorators, node, parent) {
    switch (node.kind) {
        case 264 /* SyntaxKind.ClassDeclaration */:
            return (0, ts_js_1.some)(node.members, m => nodeOrChildIsDecorated(useLegacyDecorators, m, node, parent));
        case 232 /* SyntaxKind.ClassExpression */:
            return !useLegacyDecorators && (0, ts_js_1.some)(node.members, m => nodeOrChildIsDecorated(useLegacyDecorators, m, node, parent));
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 177 /* SyntaxKind.Constructor */:
            return (0, ts_js_1.some)(node.parameters, p => nodeIsDecorated(useLegacyDecorators, p, node, parent));
        default:
            return false;
    }
}
/** @internal */
function classOrConstructorParameterIsDecorated(useLegacyDecorators, node) {
    if (nodeIsDecorated(useLegacyDecorators, node))
        return true;
    const constructor = getFirstConstructorWithBody(node);
    return !!constructor && childIsDecorated(useLegacyDecorators, constructor, node);
}
/** @internal */
function classElementOrClassElementParameterIsDecorated(useLegacyDecorators, node, parent) {
    let parameters;
    if ((0, ts_js_1.isAccessor)(node)) {
        const { firstAccessor, secondAccessor, setAccessor } = getAllAccessorDeclarations(parent.members, node);
        const firstAccessorWithDecorators = hasDecorators(firstAccessor) ? firstAccessor :
            secondAccessor && hasDecorators(secondAccessor) ? secondAccessor :
                undefined;
        if (!firstAccessorWithDecorators || node !== firstAccessorWithDecorators) {
            return false;
        }
        parameters = setAccessor?.parameters;
    }
    else if ((0, ts_js_1.isMethodDeclaration)(node)) {
        parameters = node.parameters;
    }
    if (nodeIsDecorated(useLegacyDecorators, node, parent)) {
        return true;
    }
    if (parameters) {
        for (const parameter of parameters) {
            if (parameterIsThisKeyword(parameter))
                continue;
            if (nodeIsDecorated(useLegacyDecorators, parameter, node, parent))
                return true;
        }
    }
    return false;
}
/** @internal */
function isEmptyStringLiteral(node) {
    if (node.textSourceNode) {
        switch (node.textSourceNode.kind) {
            case 11 /* SyntaxKind.StringLiteral */:
                return isEmptyStringLiteral(node.textSourceNode);
            case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
                return node.text === "";
        }
        return false;
    }
    return node.text === "";
}
/** @internal */
function isJSXTagName(node) {
    const { parent } = node;
    if (parent.kind === 287 /* SyntaxKind.JsxOpeningElement */ ||
        parent.kind === 286 /* SyntaxKind.JsxSelfClosingElement */ ||
        parent.kind === 288 /* SyntaxKind.JsxClosingElement */) {
        return parent.tagName === node;
    }
    return false;
}
/** @internal */
function isExpressionNode(node) {
    switch (node.kind) {
        case 108 /* SyntaxKind.SuperKeyword */:
        case 106 /* SyntaxKind.NullKeyword */:
        case 112 /* SyntaxKind.TrueKeyword */:
        case 97 /* SyntaxKind.FalseKeyword */:
        case 14 /* SyntaxKind.RegularExpressionLiteral */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 214 /* SyntaxKind.CallExpression */:
        case 215 /* SyntaxKind.NewExpression */:
        case 216 /* SyntaxKind.TaggedTemplateExpression */:
        case 235 /* SyntaxKind.AsExpression */:
        case 217 /* SyntaxKind.TypeAssertionExpression */:
        case 239 /* SyntaxKind.SatisfiesExpression */:
        case 236 /* SyntaxKind.NonNullExpression */:
        case 218 /* SyntaxKind.ParenthesizedExpression */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 223 /* SyntaxKind.VoidExpression */:
        case 221 /* SyntaxKind.DeleteExpression */:
        case 222 /* SyntaxKind.TypeOfExpression */:
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
        case 227 /* SyntaxKind.BinaryExpression */:
        case 228 /* SyntaxKind.ConditionalExpression */:
        case 231 /* SyntaxKind.SpreadElement */:
        case 229 /* SyntaxKind.TemplateExpression */:
        case 233 /* SyntaxKind.OmittedExpression */:
        case 285 /* SyntaxKind.JsxElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
        case 289 /* SyntaxKind.JsxFragment */:
        case 230 /* SyntaxKind.YieldExpression */:
        case 224 /* SyntaxKind.AwaitExpression */:
            return true;
        case 237 /* SyntaxKind.MetaProperty */:
            // `import.defer` in `import.defer(...)` is not an expression
            return !isImportCall(node.parent) || node.parent.expression !== node;
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
            return !(0, ts_js_1.isHeritageClause)(node.parent) && !(0, ts_js_1.isJSDocAugmentsTag)(node.parent);
        case 167 /* SyntaxKind.QualifiedName */:
            while (node.parent.kind === 167 /* SyntaxKind.QualifiedName */) {
                node = node.parent;
            }
            return node.parent.kind === 187 /* SyntaxKind.TypeQuery */ || (0, ts_js_1.isJSDocLinkLike)(node.parent) || (0, ts_js_1.isJSDocNameReference)(node.parent) || (0, ts_js_1.isJSDocMemberName)(node.parent) || isJSXTagName(node);
        case 312 /* SyntaxKind.JSDocMemberName */:
            while ((0, ts_js_1.isJSDocMemberName)(node.parent)) {
                node = node.parent;
            }
            return node.parent.kind === 187 /* SyntaxKind.TypeQuery */ || (0, ts_js_1.isJSDocLinkLike)(node.parent) || (0, ts_js_1.isJSDocNameReference)(node.parent) || (0, ts_js_1.isJSDocMemberName)(node.parent) || isJSXTagName(node);
        case 81 /* SyntaxKind.PrivateIdentifier */:
            return (0, ts_js_1.isBinaryExpression)(node.parent) && node.parent.left === node && node.parent.operatorToken.kind === 103 /* SyntaxKind.InKeyword */;
        case 80 /* SyntaxKind.Identifier */:
            if (node.parent.kind === 187 /* SyntaxKind.TypeQuery */ || (0, ts_js_1.isJSDocLinkLike)(node.parent) || (0, ts_js_1.isJSDocNameReference)(node.parent) || (0, ts_js_1.isJSDocMemberName)(node.parent) || isJSXTagName(node)) {
                return true;
            }
        // falls through
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 110 /* SyntaxKind.ThisKeyword */:
            return isInExpressionContext(node);
        default:
            return false;
    }
}
/** @internal */
function isInExpressionContext(node) {
    const { parent } = node;
    switch (parent.kind) {
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 170 /* SyntaxKind.Parameter */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 307 /* SyntaxKind.EnumMember */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 209 /* SyntaxKind.BindingElement */:
            return parent.initializer === node;
        case 245 /* SyntaxKind.ExpressionStatement */:
        case 246 /* SyntaxKind.IfStatement */:
        case 247 /* SyntaxKind.DoStatement */:
        case 248 /* SyntaxKind.WhileStatement */:
        case 254 /* SyntaxKind.ReturnStatement */:
        case 255 /* SyntaxKind.WithStatement */:
        case 256 /* SyntaxKind.SwitchStatement */:
        case 297 /* SyntaxKind.CaseClause */:
        case 258 /* SyntaxKind.ThrowStatement */:
            return parent.expression === node;
        case 249 /* SyntaxKind.ForStatement */:
            const forStatement = parent;
            return (forStatement.initializer === node && forStatement.initializer.kind !== 262 /* SyntaxKind.VariableDeclarationList */) ||
                forStatement.condition === node ||
                forStatement.incrementor === node;
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
            const forInOrOfStatement = parent;
            return (forInOrOfStatement.initializer === node && forInOrOfStatement.initializer.kind !== 262 /* SyntaxKind.VariableDeclarationList */) ||
                forInOrOfStatement.expression === node;
        case 217 /* SyntaxKind.TypeAssertionExpression */:
        case 235 /* SyntaxKind.AsExpression */:
            return node === parent.expression;
        case 240 /* SyntaxKind.TemplateSpan */:
            return node === parent.expression;
        case 168 /* SyntaxKind.ComputedPropertyName */:
            return node === parent.expression;
        case 171 /* SyntaxKind.Decorator */:
        case 295 /* SyntaxKind.JsxExpression */:
        case 294 /* SyntaxKind.JsxSpreadAttribute */:
        case 306 /* SyntaxKind.SpreadAssignment */:
            return true;
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
            return parent.expression === node && !isPartOfTypeNode(parent);
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            // TODO(jakebailey): it's possible that node could be the name, too
            return parent.objectAssignmentInitializer === node;
        case 239 /* SyntaxKind.SatisfiesExpression */:
            return node === parent.expression;
        default:
            return isExpressionNode(parent);
    }
}
/** @internal */
function isPartOfTypeQuery(node) {
    while (node.kind === 167 /* SyntaxKind.QualifiedName */ || node.kind === 80 /* SyntaxKind.Identifier */) {
        node = node.parent;
    }
    return node.kind === 187 /* SyntaxKind.TypeQuery */;
}
/** @internal */
function isNamespaceReexportDeclaration(node) {
    return (0, ts_js_1.isNamespaceExport)(node) && !!node.parent.moduleSpecifier;
}
/** @internal */
function isExternalModuleImportEqualsDeclaration(node) {
    return node.kind === 272 /* SyntaxKind.ImportEqualsDeclaration */ && node.moduleReference.kind === 284 /* SyntaxKind.ExternalModuleReference */;
}
/** @internal */
function getExternalModuleImportEqualsDeclarationExpression(node) {
    ts_js_1.Debug.assert(isExternalModuleImportEqualsDeclaration(node));
    return node.moduleReference.expression;
}
/** @internal */
function getExternalModuleRequireArgument(node) {
    return isVariableDeclarationInitializedToBareOrAccessedRequire(node) && getLeftmostAccessExpression(node.initializer).arguments[0];
}
/** @internal */
function isInternalModuleImportEqualsDeclaration(node) {
    return node.kind === 272 /* SyntaxKind.ImportEqualsDeclaration */ && node.moduleReference.kind !== 284 /* SyntaxKind.ExternalModuleReference */;
}
/** @internal */
function isFullSourceFile(sourceFile) {
    return sourceFile?.kind === 308 /* SyntaxKind.SourceFile */;
}
/** @internal */
function isSourceFileJS(file) {
    return isInJSFile(file);
}
/** @internal */
function isInJSFile(node) {
    return !!node && !!(node.flags & 524288 /* NodeFlags.JavaScriptFile */);
}
/** @internal */
function isInJsonFile(node) {
    return !!node && !!(node.flags & 134217728 /* NodeFlags.JsonFile */);
}
/** @internal */
function isSourceFileNotJson(file) {
    return !isJsonSourceFile(file);
}
/** @internal */
function isInJSDoc(node) {
    return !!node && !!(node.flags & 16777216 /* NodeFlags.JSDoc */);
}
/** @internal */
function isJSDocIndexSignature(node) {
    return (0, ts_js_1.isTypeReferenceNode)(node) &&
        (0, ts_js_1.isIdentifier)(node.typeName) &&
        node.typeName.escapedText === "Object" &&
        node.typeArguments && node.typeArguments.length === 2 &&
        (node.typeArguments[0].kind === 154 /* SyntaxKind.StringKeyword */ || node.typeArguments[0].kind === 150 /* SyntaxKind.NumberKeyword */);
}
/** @internal */
function isRequireCall(callExpression, requireStringLiteralLikeArgument) {
    if (callExpression.kind !== 214 /* SyntaxKind.CallExpression */) {
        return false;
    }
    const { expression, arguments: args } = callExpression;
    if (expression.kind !== 80 /* SyntaxKind.Identifier */ || expression.escapedText !== "require") {
        return false;
    }
    if (args.length !== 1) {
        return false;
    }
    const arg = args[0];
    return !requireStringLiteralLikeArgument || (0, ts_js_1.isStringLiteralLike)(arg);
}
/**
 * Returns true if the node is a VariableDeclaration initialized to a require call (see `isRequireCall`).
 * This function does not test if the node is in a JavaScript file or not.
 *
 * @internal
 */
function isVariableDeclarationInitializedToRequire(node) {
    return isVariableDeclarationInitializedWithRequireHelper(node, /*allowAccessedRequire*/ false);
}
/**
 * Like {@link isVariableDeclarationInitializedToRequire} but allows things like `require("...").foo.bar` or `require("...")["baz"]`.
 *
 * @internal
 */
function isVariableDeclarationInitializedToBareOrAccessedRequire(node) {
    return isVariableDeclarationInitializedWithRequireHelper(node, /*allowAccessedRequire*/ true);
}
/** @internal */
function isBindingElementOfBareOrAccessedRequire(node) {
    return (0, ts_js_1.isBindingElement)(node) && isVariableDeclarationInitializedToBareOrAccessedRequire(node.parent.parent);
}
/** @internal */
function getModuleSpecifierOfBareOrAccessedRequire(node) {
    if (isVariableDeclarationInitializedToRequire(node)) {
        return node.initializer.arguments[0];
    }
    if (isVariableDeclarationInitializedToBareOrAccessedRequire(node)) {
        const leftmost = getLeftmostAccessExpression(node.initializer);
        if (isRequireCall(leftmost, /*requireStringLiteralLikeArgument*/ true)) {
            return leftmost.arguments[0];
        }
    }
    return undefined;
}
function isVariableDeclarationInitializedWithRequireHelper(node, allowAccessedRequire) {
    return (0, ts_js_1.isVariableDeclaration)(node) &&
        !!node.initializer &&
        isRequireCall(allowAccessedRequire ? getLeftmostAccessExpression(node.initializer) : node.initializer, /*requireStringLiteralLikeArgument*/ true);
}
/** @internal */
function isRequireVariableStatement(node) {
    return (0, ts_js_1.isVariableStatement)(node)
        && node.declarationList.declarations.length > 0
        && (0, ts_js_1.every)(node.declarationList.declarations, decl => isVariableDeclarationInitializedToRequire(decl));
}
/** @internal */
function isSingleOrDoubleQuote(charCode) {
    return charCode === 39 /* CharacterCodes.singleQuote */ || charCode === 34 /* CharacterCodes.doubleQuote */;
}
/** @internal */
function isStringDoubleQuoted(str, sourceFile) {
    return getSourceTextOfNodeFromSourceFile(sourceFile, str).charCodeAt(0) === 34 /* CharacterCodes.doubleQuote */;
}
/** @internal */
function isAssignmentDeclaration(decl) {
    return (0, ts_js_1.isBinaryExpression)(decl) || isAccessExpression(decl) || (0, ts_js_1.isIdentifier)(decl) || (0, ts_js_1.isCallExpression)(decl);
}
/**
 * Get the initializer, taking into account defaulted Javascript initializers
 *
 * @internal
 */
function getEffectiveInitializer(node) {
    if (isInJSFile(node) && node.initializer &&
        (0, ts_js_1.isBinaryExpression)(node.initializer) &&
        (node.initializer.operatorToken.kind === 57 /* SyntaxKind.BarBarToken */ || node.initializer.operatorToken.kind === 61 /* SyntaxKind.QuestionQuestionToken */) &&
        node.name && isEntityNameExpression(node.name) && isSameEntityName(node.name, node.initializer.left)) {
        return node.initializer.right;
    }
    return node.initializer;
}
/**
 * Get the declaration initializer when it is container-like (See getExpandoInitializer).
 *
 * @internal
 */
function getDeclaredExpandoInitializer(node) {
    const init = getEffectiveInitializer(node);
    return init && getExpandoInitializer(init, isPrototypeAccess(node.name));
}
function hasExpandoValueProperty(node, isPrototypeAssignment) {
    return (0, ts_js_1.forEach)(node.properties, p => (0, ts_js_1.isPropertyAssignment)(p) &&
        (0, ts_js_1.isIdentifier)(p.name) &&
        p.name.escapedText === "value" &&
        p.initializer &&
        getExpandoInitializer(p.initializer, isPrototypeAssignment));
}
/**
 * Get the assignment 'initializer' -- the righthand side-- when the initializer is container-like (See getExpandoInitializer).
 * We treat the right hand side of assignments with container-like initializers as declarations.
 *
 * @internal
 */
function getAssignedExpandoInitializer(node) {
    if (node && node.parent && (0, ts_js_1.isBinaryExpression)(node.parent) && node.parent.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */) {
        const isPrototypeAssignment = isPrototypeAccess(node.parent.left);
        return getExpandoInitializer(node.parent.right, isPrototypeAssignment) ||
            getDefaultedExpandoInitializer(node.parent.left, node.parent.right, isPrototypeAssignment);
    }
    if (node && (0, ts_js_1.isCallExpression)(node) && isBindableObjectDefinePropertyCall(node)) {
        const result = hasExpandoValueProperty(node.arguments[2], node.arguments[1].text === "prototype");
        if (result) {
            return result;
        }
    }
}
/**
 * Recognized expando initializers are:
 * 1. (function() {})() -- IIFEs
 * 2. function() { } -- Function expressions
 * 3. class { } -- Class expressions
 * 4. {} -- Empty object literals
 * 5. { ... } -- Non-empty object literals, when used to initialize a prototype, like `C.prototype = { m() { } }`
 *
 * This function returns the provided initializer, or undefined if it is not valid.
 *
 * @internal
 */
function getExpandoInitializer(initializer, isPrototypeAssignment) {
    if ((0, ts_js_1.isCallExpression)(initializer)) {
        const e = skipParentheses(initializer.expression);
        return e.kind === 219 /* SyntaxKind.FunctionExpression */ || e.kind === 220 /* SyntaxKind.ArrowFunction */ ? initializer : undefined;
    }
    if (initializer.kind === 219 /* SyntaxKind.FunctionExpression */ ||
        initializer.kind === 232 /* SyntaxKind.ClassExpression */ ||
        initializer.kind === 220 /* SyntaxKind.ArrowFunction */) {
        return initializer;
    }
    if ((0, ts_js_1.isObjectLiteralExpression)(initializer) && (initializer.properties.length === 0 || isPrototypeAssignment)) {
        return initializer;
    }
}
/**
 * A defaulted expando initializer matches the pattern
 * `Lhs = Lhs || ExpandoInitializer`
 * or `var Lhs = Lhs || ExpandoInitializer`
 *
 * The second Lhs is required to be the same as the first except that it may be prefixed with
 * 'window.', 'global.' or 'self.' The second Lhs is otherwise ignored by the binder and checker.
 */
function getDefaultedExpandoInitializer(name, initializer, isPrototypeAssignment) {
    const e = (0, ts_js_1.isBinaryExpression)(initializer)
        && (initializer.operatorToken.kind === 57 /* SyntaxKind.BarBarToken */ || initializer.operatorToken.kind === 61 /* SyntaxKind.QuestionQuestionToken */)
        && getExpandoInitializer(initializer.right, isPrototypeAssignment);
    if (e && isSameEntityName(name, initializer.left)) {
        return e;
    }
}
/** @internal */
function isDefaultedExpandoInitializer(node) {
    const name = (0, ts_js_1.isVariableDeclaration)(node.parent) ? node.parent.name :
        (0, ts_js_1.isBinaryExpression)(node.parent) && node.parent.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */ ? node.parent.left :
            undefined;
    return name && getExpandoInitializer(node.right, isPrototypeAccess(name)) && isEntityNameExpression(name) && isSameEntityName(name, node.left);
}
/**
 * Given an expando initializer, return its declaration name, or the left-hand side of the assignment if it's part of an assignment declaration.
 *
 * @internal
 */
function getNameOfExpando(node) {
    if ((0, ts_js_1.isBinaryExpression)(node.parent)) {
        const parent = ((node.parent.operatorToken.kind === 57 /* SyntaxKind.BarBarToken */ || node.parent.operatorToken.kind === 61 /* SyntaxKind.QuestionQuestionToken */) && (0, ts_js_1.isBinaryExpression)(node.parent.parent)) ? node.parent.parent : node.parent;
        if (parent.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */ && (0, ts_js_1.isIdentifier)(parent.left)) {
            return parent.left;
        }
    }
    else if ((0, ts_js_1.isVariableDeclaration)(node.parent)) {
        return node.parent.name;
    }
}
/**
 * Is the 'declared' name the same as the one in the initializer?
 * @return true for identical entity names, as well as ones where the initializer is prefixed with
 * 'window', 'self' or 'global'. For example:
 *
 * var my = my || {}
 * var min = window.min || {}
 * my.app = self.my.app || class { }
 *
 * @internal
 */
function isSameEntityName(name, initializer) {
    if (isPropertyNameLiteral(name) && isPropertyNameLiteral(initializer)) {
        return getTextOfIdentifierOrLiteral(name) === getTextOfIdentifierOrLiteral(initializer);
    }
    if ((0, ts_js_1.isMemberName)(name) && isLiteralLikeAccess(initializer) &&
        (initializer.expression.kind === 110 /* SyntaxKind.ThisKeyword */ ||
            (0, ts_js_1.isIdentifier)(initializer.expression) &&
                (initializer.expression.escapedText === "window" ||
                    initializer.expression.escapedText === "self" ||
                    initializer.expression.escapedText === "global"))) {
        return isSameEntityName(name, getNameOrArgument(initializer));
    }
    if (isLiteralLikeAccess(name) && isLiteralLikeAccess(initializer)) {
        return getElementOrPropertyAccessName(name) === getElementOrPropertyAccessName(initializer)
            && isSameEntityName(name.expression, initializer.expression);
    }
    return false;
}
/** @internal */
function getRightMostAssignedExpression(node) {
    while (isAssignmentExpression(node, /*excludeCompoundAssignment*/ true)) {
        node = node.right;
    }
    return node;
}
/** @internal */
function isExportsIdentifier(node) {
    return (0, ts_js_1.isIdentifier)(node) && node.escapedText === "exports";
}
/** @internal */
function isModuleIdentifier(node) {
    return (0, ts_js_1.isIdentifier)(node) && node.escapedText === "module";
}
/** @internal */
function isModuleExportsAccessExpression(node) {
    return ((0, ts_js_1.isPropertyAccessExpression)(node) || isLiteralLikeElementAccess(node))
        && isModuleIdentifier(node.expression)
        && getElementOrPropertyAccessName(node) === "exports";
}
/// Given a BinaryExpression, returns SpecialPropertyAssignmentKind for the various kinds of property
/// assignments we treat as special in the binder
/** @internal */
function getAssignmentDeclarationKind(expr) {
    const special = getAssignmentDeclarationKindWorker(expr);
    return special === 5 /* AssignmentDeclarationKind.Property */ || isInJSFile(expr) ? special : 0 /* AssignmentDeclarationKind.None */;
}
/** @internal */
function isBindableObjectDefinePropertyCall(expr) {
    return (0, ts_js_1.length)(expr.arguments) === 3 &&
        (0, ts_js_1.isPropertyAccessExpression)(expr.expression) &&
        (0, ts_js_1.isIdentifier)(expr.expression.expression) &&
        (0, ts_js_1.idText)(expr.expression.expression) === "Object" &&
        (0, ts_js_1.idText)(expr.expression.name) === "defineProperty" &&
        isStringOrNumericLiteralLike(expr.arguments[1]) &&
        isBindableStaticNameExpression(expr.arguments[0], /*excludeThisKeyword*/ true);
}
/**
 * x.y OR x[0]
 */
function isLiteralLikeAccess(node) {
    return (0, ts_js_1.isPropertyAccessExpression)(node) || isLiteralLikeElementAccess(node);
}
/**
 * x[0] OR x['a'] OR x[Symbol.y]
 */
function isLiteralLikeElementAccess(node) {
    return (0, ts_js_1.isElementAccessExpression)(node) && isStringOrNumericLiteralLike(node.argumentExpression);
}
/**
 * Any series of property and element accesses.
 *
 * @internal
 */
function isBindableStaticAccessExpression(node, excludeThisKeyword) {
    return (0, ts_js_1.isPropertyAccessExpression)(node) && (!excludeThisKeyword && node.expression.kind === 110 /* SyntaxKind.ThisKeyword */ || (0, ts_js_1.isIdentifier)(node.name) && isBindableStaticNameExpression(node.expression, /*excludeThisKeyword*/ true))
        || isBindableStaticElementAccessExpression(node, excludeThisKeyword);
}
/**
 * Any series of property and element accesses, ending in a literal element access
 *
 * @internal
 */
function isBindableStaticElementAccessExpression(node, excludeThisKeyword) {
    return isLiteralLikeElementAccess(node)
        && ((!excludeThisKeyword && node.expression.kind === 110 /* SyntaxKind.ThisKeyword */) ||
            isEntityNameExpression(node.expression) ||
            isBindableStaticAccessExpression(node.expression, /*excludeThisKeyword*/ true));
}
/** @internal */
function isBindableStaticNameExpression(node, excludeThisKeyword) {
    return isEntityNameExpression(node) || isBindableStaticAccessExpression(node, excludeThisKeyword);
}
/** @internal */
function getNameOrArgument(expr) {
    if ((0, ts_js_1.isPropertyAccessExpression)(expr)) {
        return expr.name;
    }
    return expr.argumentExpression;
}
function getAssignmentDeclarationKindWorker(expr) {
    if ((0, ts_js_1.isCallExpression)(expr)) {
        if (!isBindableObjectDefinePropertyCall(expr)) {
            return 0 /* AssignmentDeclarationKind.None */;
        }
        const entityName = expr.arguments[0];
        if (isExportsIdentifier(entityName) || isModuleExportsAccessExpression(entityName)) {
            return 8 /* AssignmentDeclarationKind.ObjectDefinePropertyExports */;
        }
        if (isBindableStaticAccessExpression(entityName) && getElementOrPropertyAccessName(entityName) === "prototype") {
            return 9 /* AssignmentDeclarationKind.ObjectDefinePrototypeProperty */;
        }
        return 7 /* AssignmentDeclarationKind.ObjectDefinePropertyValue */;
    }
    if (expr.operatorToken.kind !== 64 /* SyntaxKind.EqualsToken */ || !isAccessExpression(expr.left) || isVoidZero(getRightMostAssignedExpression(expr))) {
        return 0 /* AssignmentDeclarationKind.None */;
    }
    if (isBindableStaticNameExpression(expr.left.expression, /*excludeThisKeyword*/ true) && getElementOrPropertyAccessName(expr.left) === "prototype" && (0, ts_js_1.isObjectLiteralExpression)(getInitializerOfBinaryExpression(expr))) {
        // F.prototype = { ... }
        return 6 /* AssignmentDeclarationKind.Prototype */;
    }
    return getAssignmentDeclarationPropertyAccessKind(expr.left);
}
function isVoidZero(node) {
    return (0, ts_js_1.isVoidExpression)(node) && (0, ts_js_1.isNumericLiteral)(node.expression) && node.expression.text === "0";
}
/**
 * Does not handle signed numeric names like `a[+0]` - handling those would require handling prefix unary expressions
 * throughout late binding handling as well, which is awkward (but ultimately probably doable if there is demand)
 *
 * @internal
 */
function getElementOrPropertyAccessArgumentExpressionOrName(node) {
    if ((0, ts_js_1.isPropertyAccessExpression)(node)) {
        return node.name;
    }
    const arg = skipParentheses(node.argumentExpression);
    if ((0, ts_js_1.isNumericLiteral)(arg) || (0, ts_js_1.isStringLiteralLike)(arg)) {
        return arg;
    }
    return node;
}
/** @internal */
function getElementOrPropertyAccessName(node) {
    const name = getElementOrPropertyAccessArgumentExpressionOrName(node);
    if (name) {
        if ((0, ts_js_1.isIdentifier)(name)) {
            return name.escapedText;
        }
        if ((0, ts_js_1.isStringLiteralLike)(name) || (0, ts_js_1.isNumericLiteral)(name)) {
            return (0, ts_js_1.escapeLeadingUnderscores)(name.text);
        }
    }
    return undefined;
}
/** @internal */
function getAssignmentDeclarationPropertyAccessKind(lhs) {
    if (lhs.expression.kind === 110 /* SyntaxKind.ThisKeyword */) {
        return 4 /* AssignmentDeclarationKind.ThisProperty */;
    }
    else if (isModuleExportsAccessExpression(lhs)) {
        // module.exports = expr
        return 2 /* AssignmentDeclarationKind.ModuleExports */;
    }
    else if (isBindableStaticNameExpression(lhs.expression, /*excludeThisKeyword*/ true)) {
        if (isPrototypeAccess(lhs.expression)) {
            // F.G....prototype.x = expr
            return 3 /* AssignmentDeclarationKind.PrototypeProperty */;
        }
        let nextToLast = lhs;
        while (!(0, ts_js_1.isIdentifier)(nextToLast.expression)) {
            nextToLast = nextToLast.expression;
        }
        const id = nextToLast.expression;
        if ((id.escapedText === "exports" ||
            id.escapedText === "module" && getElementOrPropertyAccessName(nextToLast) === "exports") &&
            // ExportsProperty does not support binding with computed names
            isBindableStaticAccessExpression(lhs)) {
            // exports.name = expr OR module.exports.name = expr OR exports["name"] = expr ...
            return 1 /* AssignmentDeclarationKind.ExportsProperty */;
        }
        if (isBindableStaticNameExpression(lhs, /*excludeThisKeyword*/ true) || ((0, ts_js_1.isElementAccessExpression)(lhs) && isDynamicName(lhs))) {
            // F.G...x = expr
            return 5 /* AssignmentDeclarationKind.Property */;
        }
    }
    return 0 /* AssignmentDeclarationKind.None */;
}
/** @internal */
function getInitializerOfBinaryExpression(expr) {
    while ((0, ts_js_1.isBinaryExpression)(expr.right)) {
        expr = expr.right;
    }
    return expr.right;
}
/** @internal */
function isPrototypePropertyAssignment(node) {
    return (0, ts_js_1.isBinaryExpression)(node) && getAssignmentDeclarationKind(node) === 3 /* AssignmentDeclarationKind.PrototypeProperty */;
}
/** @internal */
function isSpecialPropertyDeclaration(expr) {
    return isInJSFile(expr) &&
        expr.parent && expr.parent.kind === 245 /* SyntaxKind.ExpressionStatement */ &&
        (!(0, ts_js_1.isElementAccessExpression)(expr) || isLiteralLikeElementAccess(expr)) &&
        !!(0, ts_js_1.getJSDocTypeTag)(expr.parent);
}
/** @internal */
function setValueDeclaration(symbol, node) {
    const { valueDeclaration } = symbol;
    if (!valueDeclaration ||
        !(node.flags & 33554432 /* NodeFlags.Ambient */ && !isInJSFile(node) && !(valueDeclaration.flags & 33554432 /* NodeFlags.Ambient */)) &&
            (isAssignmentDeclaration(valueDeclaration) && !isAssignmentDeclaration(node)) ||
        (valueDeclaration.kind !== node.kind && isEffectiveModuleDeclaration(valueDeclaration))) {
        // other kinds of value declarations take precedence over modules and assignment declarations
        symbol.valueDeclaration = node;
    }
}
/** @internal */
function isFunctionSymbol(symbol) {
    if (!symbol || !symbol.valueDeclaration) {
        return false;
    }
    const decl = symbol.valueDeclaration;
    return decl.kind === 263 /* SyntaxKind.FunctionDeclaration */ || (0, ts_js_1.isVariableDeclaration)(decl) && decl.initializer && (0, ts_js_1.isFunctionLike)(decl.initializer);
}
/** @internal */
function canHaveModuleSpecifier(node) {
    switch (node?.kind) {
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 209 /* SyntaxKind.BindingElement */:
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 274 /* SyntaxKind.ImportClause */:
        case 281 /* SyntaxKind.NamespaceExport */:
        case 275 /* SyntaxKind.NamespaceImport */:
        case 282 /* SyntaxKind.ExportSpecifier */:
        case 277 /* SyntaxKind.ImportSpecifier */:
        case 206 /* SyntaxKind.ImportType */:
            return true;
    }
    return false;
}
/** @internal */
function tryGetModuleSpecifierFromDeclaration(node) {
    switch (node.kind) {
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 209 /* SyntaxKind.BindingElement */:
            return (0, ts_js_1.findAncestor)(node.initializer, (node) => isRequireCall(node, /*requireStringLiteralLikeArgument*/ true))?.arguments[0];
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 352 /* SyntaxKind.JSDocImportTag */:
            return (0, ts_js_1.tryCast)(node.moduleSpecifier, ts_js_1.isStringLiteralLike);
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            return (0, ts_js_1.tryCast)((0, ts_js_1.tryCast)(node.moduleReference, ts_js_1.isExternalModuleReference)?.expression, ts_js_1.isStringLiteralLike);
        case 274 /* SyntaxKind.ImportClause */:
        case 281 /* SyntaxKind.NamespaceExport */:
            return (0, ts_js_1.tryCast)(node.parent.moduleSpecifier, ts_js_1.isStringLiteralLike);
        case 275 /* SyntaxKind.NamespaceImport */:
        case 282 /* SyntaxKind.ExportSpecifier */:
            return (0, ts_js_1.tryCast)(node.parent.parent.moduleSpecifier, ts_js_1.isStringLiteralLike);
        case 277 /* SyntaxKind.ImportSpecifier */:
            return (0, ts_js_1.tryCast)(node.parent.parent.parent.moduleSpecifier, ts_js_1.isStringLiteralLike);
        case 206 /* SyntaxKind.ImportType */:
            return isLiteralImportTypeNode(node) ? node.argument.literal : undefined;
        default:
            ts_js_1.Debug.assertNever(node);
    }
}
/** @internal */
function importFromModuleSpecifier(node) {
    return tryGetImportFromModuleSpecifier(node) || ts_js_1.Debug.failBadSyntaxKind(node.parent);
}
/** @internal */
function tryGetImportFromModuleSpecifier(node) {
    switch (node.parent.kind) {
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 352 /* SyntaxKind.JSDocImportTag */:
            return node.parent;
        case 284 /* SyntaxKind.ExternalModuleReference */:
            return node.parent.parent;
        case 214 /* SyntaxKind.CallExpression */:
            return isImportCall(node.parent) || isRequireCall(node.parent, /*requireStringLiteralLikeArgument*/ false) ? node.parent : undefined;
        case 202 /* SyntaxKind.LiteralType */:
            if (!(0, ts_js_1.isStringLiteral)(node)) {
                break;
            }
            return (0, ts_js_1.tryCast)(node.parent.parent, ts_js_1.isImportTypeNode);
        default:
            return undefined;
    }
}
/** @internal */
function shouldRewriteModuleSpecifier(specifier, compilerOptions) {
    return !!compilerOptions.rewriteRelativeImportExtensions && (0, ts_js_1.pathIsRelative)(specifier) && !(0, ts_js_1.isDeclarationFileName)(specifier) && hasTSFileExtension(specifier);
}
/** @internal */
function getExternalModuleName(node) {
    switch (node.kind) {
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 352 /* SyntaxKind.JSDocImportTag */:
            return node.moduleSpecifier;
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            return node.moduleReference.kind === 284 /* SyntaxKind.ExternalModuleReference */ ? node.moduleReference.expression : undefined;
        case 206 /* SyntaxKind.ImportType */:
            return isLiteralImportTypeNode(node) ? node.argument.literal : undefined;
        case 214 /* SyntaxKind.CallExpression */:
            return node.arguments[0];
        case 268 /* SyntaxKind.ModuleDeclaration */:
            return node.name.kind === 11 /* SyntaxKind.StringLiteral */ ? node.name : undefined;
        default:
            return ts_js_1.Debug.assertNever(node);
    }
}
/** @internal */
function getNamespaceDeclarationNode(node) {
    switch (node.kind) {
        case 273 /* SyntaxKind.ImportDeclaration */:
            return node.importClause && (0, ts_js_1.tryCast)(node.importClause.namedBindings, ts_js_1.isNamespaceImport);
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            return node;
        case 279 /* SyntaxKind.ExportDeclaration */:
            return node.exportClause && (0, ts_js_1.tryCast)(node.exportClause, ts_js_1.isNamespaceExport);
        default:
            return ts_js_1.Debug.assertNever(node);
    }
}
/** @internal */
function isDefaultImport(node) {
    return (node.kind === 273 /* SyntaxKind.ImportDeclaration */ || node.kind === 352 /* SyntaxKind.JSDocImportTag */) && !!node.importClause && !!node.importClause.name;
}
/** @internal */
function forEachImportClauseDeclaration(node, action) {
    if (node.name) {
        const result = action(node);
        if (result)
            return result;
    }
    if (node.namedBindings) {
        const result = (0, ts_js_1.isNamespaceImport)(node.namedBindings)
            ? action(node.namedBindings)
            : (0, ts_js_1.forEach)(node.namedBindings.elements, action);
        if (result)
            return result;
    }
}
/** @internal */
function hasQuestionToken(node) {
    switch (node.kind) {
        case 170 /* SyntaxKind.Parameter */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
            return node.questionToken !== undefined;
    }
    return false;
}
/** @internal */
function isJSDocConstructSignature(node) {
    const param = (0, ts_js_1.isJSDocFunctionType)(node) ? (0, ts_js_1.firstOrUndefined)(node.parameters) : undefined;
    const name = (0, ts_js_1.tryCast)(param && param.name, ts_js_1.isIdentifier);
    return !!name && name.escapedText === "new";
}
/** @internal */
function isJSDocTypeAlias(node) {
    return node.kind === 347 /* SyntaxKind.JSDocTypedefTag */ || node.kind === 339 /* SyntaxKind.JSDocCallbackTag */ || node.kind === 341 /* SyntaxKind.JSDocEnumTag */;
}
/** @internal */
function isTypeAlias(node) {
    return isJSDocTypeAlias(node) || (0, ts_js_1.isTypeAliasDeclaration)(node);
}
function getSourceOfAssignment(node) {
    return (0, ts_js_1.isExpressionStatement)(node) &&
        (0, ts_js_1.isBinaryExpression)(node.expression) &&
        node.expression.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */
        ? getRightMostAssignedExpression(node.expression)
        : undefined;
}
function getSourceOfDefaultedAssignment(node) {
    return (0, ts_js_1.isExpressionStatement)(node) &&
        (0, ts_js_1.isBinaryExpression)(node.expression) &&
        getAssignmentDeclarationKind(node.expression) !== 0 /* AssignmentDeclarationKind.None */ &&
        (0, ts_js_1.isBinaryExpression)(node.expression.right) &&
        (node.expression.right.operatorToken.kind === 57 /* SyntaxKind.BarBarToken */ || node.expression.right.operatorToken.kind === 61 /* SyntaxKind.QuestionQuestionToken */)
        ? node.expression.right.right
        : undefined;
}
function getSingleInitializerOfVariableStatementOrPropertyDeclaration(node) {
    switch (node.kind) {
        case 244 /* SyntaxKind.VariableStatement */:
            const v = getSingleVariableOfVariableStatement(node);
            return v && v.initializer;
        case 173 /* SyntaxKind.PropertyDeclaration */:
            return node.initializer;
        case 304 /* SyntaxKind.PropertyAssignment */:
            return node.initializer;
    }
}
/** @internal */
function getSingleVariableOfVariableStatement(node) {
    return (0, ts_js_1.isVariableStatement)(node) ? (0, ts_js_1.firstOrUndefined)(node.declarationList.declarations) : undefined;
}
function getNestedModuleDeclaration(node) {
    return (0, ts_js_1.isModuleDeclaration)(node) &&
        node.body &&
        node.body.kind === 268 /* SyntaxKind.ModuleDeclaration */
        ? node.body
        : undefined;
}
/** @internal */
function canHaveFlowNode(node) {
    if (node.kind >= 244 /* SyntaxKind.FirstStatement */ && node.kind <= 260 /* SyntaxKind.LastStatement */) {
        return true;
    }
    switch (node.kind) {
        case 80 /* SyntaxKind.Identifier */:
        case 110 /* SyntaxKind.ThisKeyword */:
        case 108 /* SyntaxKind.SuperKeyword */:
        case 167 /* SyntaxKind.QualifiedName */:
        case 237 /* SyntaxKind.MetaProperty */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 209 /* SyntaxKind.BindingElement */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function canHaveJSDoc(node) {
    switch (node.kind) {
        case 220 /* SyntaxKind.ArrowFunction */:
        case 227 /* SyntaxKind.BinaryExpression */:
        case 242 /* SyntaxKind.Block */:
        case 253 /* SyntaxKind.BreakStatement */:
        case 180 /* SyntaxKind.CallSignature */:
        case 297 /* SyntaxKind.CaseClause */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
        case 177 /* SyntaxKind.Constructor */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 252 /* SyntaxKind.ContinueStatement */:
        case 260 /* SyntaxKind.DebuggerStatement */:
        case 247 /* SyntaxKind.DoStatement */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 243 /* SyntaxKind.EmptyStatement */:
        case 1 /* SyntaxKind.EndOfFileToken */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 307 /* SyntaxKind.EnumMember */:
        case 278 /* SyntaxKind.ExportAssignment */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 282 /* SyntaxKind.ExportSpecifier */:
        case 245 /* SyntaxKind.ExpressionStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 249 /* SyntaxKind.ForStatement */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 185 /* SyntaxKind.FunctionType */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 80 /* SyntaxKind.Identifier */:
        case 246 /* SyntaxKind.IfStatement */:
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 324 /* SyntaxKind.JSDocSignature */:
        case 257 /* SyntaxKind.LabeledStatement */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 203 /* SyntaxKind.NamedTupleMember */:
        case 271 /* SyntaxKind.NamespaceExportDeclaration */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 170 /* SyntaxKind.Parameter */:
        case 218 /* SyntaxKind.ParenthesizedExpression */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 254 /* SyntaxKind.ReturnStatement */:
        case 241 /* SyntaxKind.SemicolonClassElement */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
        case 306 /* SyntaxKind.SpreadAssignment */:
        case 256 /* SyntaxKind.SwitchStatement */:
        case 258 /* SyntaxKind.ThrowStatement */:
        case 259 /* SyntaxKind.TryStatement */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 169 /* SyntaxKind.TypeParameter */:
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 244 /* SyntaxKind.VariableStatement */:
        case 248 /* SyntaxKind.WhileStatement */:
        case 255 /* SyntaxKind.WithStatement */:
            return true;
        default:
            return false;
    }
}
function getJSDocCommentsAndTags(hostNode, noCache) {
    let result;
    // Pull parameter comments from declaring function as well
    if (isVariableLike(hostNode) && (0, ts_js_1.hasInitializer)(hostNode) && (0, ts_js_1.hasJSDocNodes)(hostNode.initializer)) {
        result = (0, ts_js_1.addRange)(result, filterOwnedJSDocTags(hostNode, hostNode.initializer.jsDoc));
    }
    let node = hostNode;
    while (node && node.parent) {
        if ((0, ts_js_1.hasJSDocNodes)(node)) {
            result = (0, ts_js_1.addRange)(result, filterOwnedJSDocTags(hostNode, node.jsDoc));
        }
        if (node.kind === 170 /* SyntaxKind.Parameter */) {
            result = (0, ts_js_1.addRange)(result, (noCache ? ts_js_1.getJSDocParameterTagsNoCache : ts_js_1.getJSDocParameterTags)(node));
            break;
        }
        if (node.kind === 169 /* SyntaxKind.TypeParameter */) {
            result = (0, ts_js_1.addRange)(result, (noCache ? ts_js_1.getJSDocTypeParameterTagsNoCache : ts_js_1.getJSDocTypeParameterTags)(node));
            break;
        }
        node = getNextJSDocCommentLocation(node);
    }
    return result || ts_js_1.emptyArray;
}
function filterOwnedJSDocTags(hostNode, comments) {
    const lastJsDoc = (0, ts_js_1.last)(comments);
    return (0, ts_js_1.flatMap)(comments, jsDoc => {
        if (jsDoc === lastJsDoc) {
            const ownedTags = (0, ts_js_1.filter)(jsDoc.tags, tag => ownsJSDocTag(hostNode, tag));
            return jsDoc.tags === ownedTags ? [jsDoc] : ownedTags;
        }
        else {
            return (0, ts_js_1.filter)(jsDoc.tags, ts_js_1.isJSDocOverloadTag);
        }
    });
}
/**
 * Determines whether a host node owns a jsDoc tag. A `@type`/`@satisfies` tag attached to a
 * a ParenthesizedExpression belongs only to the ParenthesizedExpression.
 */
function ownsJSDocTag(hostNode, tag) {
    return !((0, ts_js_1.isJSDocTypeTag)(tag) || (0, ts_js_1.isJSDocSatisfiesTag)(tag))
        || !tag.parent
        || !(0, ts_js_1.isJSDoc)(tag.parent)
        || !(0, ts_js_1.isParenthesizedExpression)(tag.parent.parent)
        || tag.parent.parent === hostNode;
}
/** @internal */
function getNextJSDocCommentLocation(node) {
    const parent = node.parent;
    if (parent.kind === 304 /* SyntaxKind.PropertyAssignment */ ||
        parent.kind === 278 /* SyntaxKind.ExportAssignment */ ||
        parent.kind === 173 /* SyntaxKind.PropertyDeclaration */ ||
        parent.kind === 245 /* SyntaxKind.ExpressionStatement */ && node.kind === 212 /* SyntaxKind.PropertyAccessExpression */ ||
        parent.kind === 254 /* SyntaxKind.ReturnStatement */ ||
        getNestedModuleDeclaration(parent) ||
        isAssignmentExpression(node)) {
        return parent;
    }
    // Try to recognize this pattern when node is initializer of variable declaration and JSDoc comments are on containing variable statement.
    // /**
    //   * @param {number} name
    //   * @returns {number}
    //   */
    // var x = function(name) { return name.length; }
    else if (parent.parent &&
        (getSingleVariableOfVariableStatement(parent.parent) === node || isAssignmentExpression(parent))) {
        return parent.parent;
    }
    else if (parent.parent && parent.parent.parent &&
        (getSingleVariableOfVariableStatement(parent.parent.parent) ||
            getSingleInitializerOfVariableStatementOrPropertyDeclaration(parent.parent.parent) === node ||
            getSourceOfDefaultedAssignment(parent.parent.parent))) {
        return parent.parent.parent;
    }
}
/**
 * Does the opposite of `getJSDocParameterTags`: given a JSDoc parameter, finds the parameter corresponding to it.
 *
 * @internal
 */
function getParameterSymbolFromJSDoc(node) {
    if (node.symbol) {
        return node.symbol;
    }
    if (!(0, ts_js_1.isIdentifier)(node.name)) {
        return undefined;
    }
    const name = node.name.escapedText;
    const decl = getHostSignatureFromJSDoc(node);
    if (!decl) {
        return undefined;
    }
    const parameter = (0, ts_js_1.find)(decl.parameters, p => p.name.kind === 80 /* SyntaxKind.Identifier */ && p.name.escapedText === name);
    return parameter && parameter.symbol;
}
/** @internal */
function getEffectiveContainerForJSDocTemplateTag(node) {
    if ((0, ts_js_1.isJSDoc)(node.parent) && node.parent.tags) {
        // A @template tag belongs to any @typedef, @callback, or @enum tags in the same comment block, if they exist.
        const typeAlias = (0, ts_js_1.find)(node.parent.tags, isJSDocTypeAlias);
        if (typeAlias) {
            return typeAlias;
        }
    }
    // otherwise it belongs to the host it annotates
    return getHostSignatureFromJSDoc(node);
}
/** @internal */
function getJSDocOverloadTags(node) {
    return (0, ts_js_1.getAllJSDocTags)(node, ts_js_1.isJSDocOverloadTag);
}
/** @internal */
function getHostSignatureFromJSDoc(node) {
    const host = getEffectiveJSDocHost(node);
    if (host) {
        return (0, ts_js_1.isPropertySignature)(host) && host.type && (0, ts_js_1.isFunctionLike)(host.type) ? host.type :
            (0, ts_js_1.isFunctionLike)(host) ? host : undefined;
    }
    return undefined;
}
/** @internal */
function getEffectiveJSDocHost(node) {
    const host = getJSDocHost(node);
    if (host) {
        return getSourceOfDefaultedAssignment(host)
            || getSourceOfAssignment(host)
            || getSingleInitializerOfVariableStatementOrPropertyDeclaration(host)
            || getSingleVariableOfVariableStatement(host)
            || getNestedModuleDeclaration(host)
            || host;
    }
}
/**
 * Use getEffectiveJSDocHost if you additionally need to look for jsdoc on parent nodes, like assignments.
 *
 * @internal
 */
function getJSDocHost(node) {
    const jsDoc = getJSDocRoot(node);
    if (!jsDoc) {
        return undefined;
    }
    const host = jsDoc.parent;
    if (host && host.jsDoc && jsDoc === (0, ts_js_1.lastOrUndefined)(host.jsDoc)) {
        return host;
    }
}
/** @internal */
function getJSDocRoot(node) {
    return (0, ts_js_1.findAncestor)(node.parent, ts_js_1.isJSDoc);
}
/** @internal */
function getTypeParameterFromJsDoc(node) {
    const name = node.name.escapedText;
    const { typeParameters } = node.parent.parent.parent;
    return typeParameters && (0, ts_js_1.find)(typeParameters, p => p.name.escapedText === name);
}
/** @internal */
function hasTypeArguments(node) {
    return !!node.typeArguments;
}
/** @internal */
var AssignmentKind;
(function (AssignmentKind) {
    AssignmentKind[AssignmentKind["None"] = 0] = "None";
    AssignmentKind[AssignmentKind["Definite"] = 1] = "Definite";
    AssignmentKind[AssignmentKind["Compound"] = 2] = "Compound";
})(AssignmentKind || (exports.AssignmentKind = AssignmentKind = {}));
function getAssignmentTarget(node) {
    let parent = node.parent;
    while (true) {
        switch (parent.kind) {
            case 227 /* SyntaxKind.BinaryExpression */:
                const binaryExpression = parent;
                const binaryOperator = binaryExpression.operatorToken.kind;
                return isAssignmentOperator(binaryOperator) && binaryExpression.left === node ? binaryExpression : undefined;
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                const unaryExpression = parent;
                const unaryOperator = unaryExpression.operator;
                return unaryOperator === 46 /* SyntaxKind.PlusPlusToken */ || unaryOperator === 47 /* SyntaxKind.MinusMinusToken */ ? unaryExpression : undefined;
            case 250 /* SyntaxKind.ForInStatement */:
            case 251 /* SyntaxKind.ForOfStatement */:
                const forInOrOfStatement = parent;
                return forInOrOfStatement.initializer === node ? forInOrOfStatement : undefined;
            case 218 /* SyntaxKind.ParenthesizedExpression */:
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
            case 231 /* SyntaxKind.SpreadElement */:
            case 236 /* SyntaxKind.NonNullExpression */:
                node = parent;
                break;
            case 306 /* SyntaxKind.SpreadAssignment */:
                node = parent.parent;
                break;
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
                if (parent.name !== node) {
                    return undefined;
                }
                node = parent.parent;
                break;
            case 304 /* SyntaxKind.PropertyAssignment */:
                if (parent.name === node) {
                    return undefined;
                }
                node = parent.parent;
                break;
            default:
                return undefined;
        }
        parent = node.parent;
    }
}
/** @internal */
function getAssignmentTargetKind(node) {
    const target = getAssignmentTarget(node);
    if (!target) {
        return 0 /* AssignmentKind.None */;
    }
    switch (target.kind) {
        case 227 /* SyntaxKind.BinaryExpression */:
            const binaryOperator = target.operatorToken.kind;
            return binaryOperator === 64 /* SyntaxKind.EqualsToken */ || isLogicalOrCoalescingAssignmentOperator(binaryOperator) ?
                1 /* AssignmentKind.Definite */ :
                2 /* AssignmentKind.Compound */;
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
            return 2 /* AssignmentKind.Compound */;
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
            return 1 /* AssignmentKind.Definite */;
    }
}
// A node is an assignment target if it is on the left hand side of an '=' token, if it is parented by a property
// assignment in an object literal that is an assignment target, or if it is parented by an array literal that is
// an assignment target. Examples include 'a = xxx', '{ p: a } = xxx', '[{ a }] = xxx'.
// (Note that `p` is not a target in the above examples, only `a`.)
/** @internal */
function isAssignmentTarget(node) {
    return !!getAssignmentTarget(node);
}
function isCompoundLikeAssignment(assignment) {
    const right = skipParentheses(assignment.right);
    return right.kind === 227 /* SyntaxKind.BinaryExpression */ && (0, ts_js_1.isShiftOperatorOrHigher)(right.operatorToken.kind);
}
/** @internal */
function isInCompoundLikeAssignment(node) {
    const target = getAssignmentTarget(node);
    return !!target && isAssignmentExpression(target, /*excludeCompoundAssignment*/ true) && isCompoundLikeAssignment(target);
}
/**
 * Indicates whether a node could contain a `var` VariableDeclarationList that contributes to
 * the same `var` declaration scope as the node's parent.
 *
 * @internal
 */
function isNodeWithPossibleHoistedDeclaration(node) {
    switch (node.kind) {
        case 242 /* SyntaxKind.Block */:
        case 244 /* SyntaxKind.VariableStatement */:
        case 255 /* SyntaxKind.WithStatement */:
        case 246 /* SyntaxKind.IfStatement */:
        case 256 /* SyntaxKind.SwitchStatement */:
        case 270 /* SyntaxKind.CaseBlock */:
        case 297 /* SyntaxKind.CaseClause */:
        case 298 /* SyntaxKind.DefaultClause */:
        case 257 /* SyntaxKind.LabeledStatement */:
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 247 /* SyntaxKind.DoStatement */:
        case 248 /* SyntaxKind.WhileStatement */:
        case 259 /* SyntaxKind.TryStatement */:
        case 300 /* SyntaxKind.CatchClause */:
            return true;
    }
    return false;
}
/** @internal */
function isValueSignatureDeclaration(node) {
    return (0, ts_js_1.isFunctionExpression)(node) || (0, ts_js_1.isArrowFunction)(node) || (0, ts_js_1.isMethodOrAccessor)(node) || (0, ts_js_1.isFunctionDeclaration)(node) || (0, ts_js_1.isConstructorDeclaration)(node);
}
function walkUp(node, kind) {
    while (node && node.kind === kind) {
        node = node.parent;
    }
    return node;
}
/** @internal */
function walkUpParenthesizedTypes(node) {
    return walkUp(node, 197 /* SyntaxKind.ParenthesizedType */);
}
/** @internal */
function walkUpParenthesizedExpressions(node) {
    return walkUp(node, 218 /* SyntaxKind.ParenthesizedExpression */);
}
/**
 * Walks up parenthesized types.
 * It returns both the outermost parenthesized type and its parent.
 * If given node is not a parenthesiezd type, undefined is return as the former.
 *
 * @internal
 */
function walkUpParenthesizedTypesAndGetParentAndChild(node) {
    let child;
    while (node && node.kind === 197 /* SyntaxKind.ParenthesizedType */) {
        child = node;
        node = node.parent;
    }
    return [child, node];
}
/** @internal */
function skipTypeParentheses(node) {
    while ((0, ts_js_1.isParenthesizedTypeNode)(node))
        node = node.type;
    return node;
}
/** @internal */
function skipParentheses(node, excludeJSDocTypeAssertions) {
    const flags = excludeJSDocTypeAssertions ?
        1 /* OuterExpressionKinds.Parentheses */ | -2147483648 /* OuterExpressionKinds.ExcludeJSDocTypeAssertion */ :
        1 /* OuterExpressionKinds.Parentheses */;
    return (0, ts_js_1.skipOuterExpressions)(node, flags);
}
// a node is delete target iff. it is PropertyAccessExpression/ElementAccessExpression with parentheses skipped
/** @internal */
function isDeleteTarget(node) {
    if (node.kind !== 212 /* SyntaxKind.PropertyAccessExpression */ && node.kind !== 213 /* SyntaxKind.ElementAccessExpression */) {
        return false;
    }
    node = walkUpParenthesizedExpressions(node.parent);
    return node && node.kind === 221 /* SyntaxKind.DeleteExpression */;
}
/** @internal */
function isNodeDescendantOf(node, ancestor) {
    while (node) {
        if (node === ancestor)
            return true;
        node = node.parent;
    }
    return false;
}
// True if `name` is the name of a declaration node
/** @internal */
function isDeclarationName(name) {
    return !(0, ts_js_1.isSourceFile)(name) && !(0, ts_js_1.isBindingPattern)(name) && (0, ts_js_1.isDeclaration)(name.parent) && name.parent.name === name;
}
// See GH#16030
/** @internal */
function getDeclarationFromName(name) {
    const parent = name.parent;
    switch (name.kind) {
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
            if ((0, ts_js_1.isComputedPropertyName)(parent))
                return parent.parent;
        // falls through
        case 80 /* SyntaxKind.Identifier */:
            if ((0, ts_js_1.isDeclaration)(parent)) {
                return parent.name === name ? parent : undefined;
            }
            else if ((0, ts_js_1.isQualifiedName)(parent)) {
                const tag = parent.parent;
                return (0, ts_js_1.isJSDocParameterTag)(tag) && tag.name === parent ? tag : undefined;
            }
            else {
                const binExp = parent.parent;
                return (0, ts_js_1.isBinaryExpression)(binExp) &&
                    getAssignmentDeclarationKind(binExp) !== 0 /* AssignmentDeclarationKind.None */ &&
                    (binExp.left.symbol || binExp.symbol) &&
                    (0, ts_js_1.getNameOfDeclaration)(binExp) === name
                    ? binExp
                    : undefined;
            }
        case 81 /* SyntaxKind.PrivateIdentifier */:
            return (0, ts_js_1.isDeclaration)(parent) && parent.name === name ? parent : undefined;
        default:
            return undefined;
    }
}
/** @internal */
function isLiteralComputedPropertyDeclarationName(node) {
    return isStringOrNumericLiteralLike(node) &&
        node.parent.kind === 168 /* SyntaxKind.ComputedPropertyName */ &&
        (0, ts_js_1.isDeclaration)(node.parent.parent);
}
// Return true if the given identifier is classified as an IdentifierName
/** @internal */
function isIdentifierName(node) {
    const parent = node.parent;
    switch (parent.kind) {
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 307 /* SyntaxKind.EnumMember */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
            // Name in member declaration or property name in property access
            return parent.name === node;
        case 167 /* SyntaxKind.QualifiedName */:
            // Name on right hand side of dot in a type query or type reference
            return parent.right === node;
        case 209 /* SyntaxKind.BindingElement */:
        case 277 /* SyntaxKind.ImportSpecifier */:
            // Property name in binding element or import specifier
            return parent.propertyName === node;
        case 282 /* SyntaxKind.ExportSpecifier */:
        case 292 /* SyntaxKind.JsxAttribute */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
        case 287 /* SyntaxKind.JsxOpeningElement */:
        case 288 /* SyntaxKind.JsxClosingElement */:
            // Any name in an export specifier or JSX Attribute or Jsx Element
            return true;
    }
    return false;
}
/** @internal */
function getAliasDeclarationFromName(node) {
    switch (node.parent.kind) {
        case 274 /* SyntaxKind.ImportClause */:
        case 277 /* SyntaxKind.ImportSpecifier */:
        case 275 /* SyntaxKind.NamespaceImport */:
        case 282 /* SyntaxKind.ExportSpecifier */:
        case 278 /* SyntaxKind.ExportAssignment */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 281 /* SyntaxKind.NamespaceExport */:
            return node.parent;
        case 167 /* SyntaxKind.QualifiedName */:
            do {
                node = node.parent;
            } while (node.parent.kind === 167 /* SyntaxKind.QualifiedName */);
            return getAliasDeclarationFromName(node);
    }
}
/** @internal */
function isAliasableExpression(e) {
    return isEntityNameExpression(e) || (0, ts_js_1.isClassExpression)(e);
}
/** @internal */
function exportAssignmentIsAlias(node) {
    const e = getExportAssignmentExpression(node);
    return isAliasableExpression(e);
}
/** @internal */
function getExportAssignmentExpression(node) {
    return (0, ts_js_1.isExportAssignment)(node) ? node.expression : node.right;
}
/** @internal */
function getPropertyAssignmentAliasLikeExpression(node) {
    return node.kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */ ? node.name : node.kind === 304 /* SyntaxKind.PropertyAssignment */ ? node.initializer :
        node.parent.right;
}
/** @internal */
function getEffectiveBaseTypeNode(node) {
    const baseType = getClassExtendsHeritageElement(node);
    if (baseType && isInJSFile(node)) {
        // Prefer an @augments tag because it may have type parameters.
        const tag = (0, ts_js_1.getJSDocAugmentsTag)(node);
        if (tag) {
            return tag.class;
        }
    }
    return baseType;
}
/** @internal */
function getClassExtendsHeritageElement(node) {
    const heritageClause = getHeritageClause(node.heritageClauses, 96 /* SyntaxKind.ExtendsKeyword */);
    return heritageClause && heritageClause.types.length > 0 ? heritageClause.types[0] : undefined;
}
/** @internal */
function getEffectiveImplementsTypeNodes(node) {
    if (isInJSFile(node)) {
        return (0, ts_js_1.getJSDocImplementsTags)(node).map(n => n.class);
    }
    else {
        const heritageClause = getHeritageClause(node.heritageClauses, 119 /* SyntaxKind.ImplementsKeyword */);
        return heritageClause?.types;
    }
}
/**
 * Returns the node in an `extends` or `implements` clause of a class or interface.
 *
 * @internal
 */
function getAllSuperTypeNodes(node) {
    return (0, ts_js_1.isInterfaceDeclaration)(node) ? getInterfaceBaseTypeNodes(node) || ts_js_1.emptyArray :
        (0, ts_js_1.isClassLike)(node) ? (0, ts_js_1.concatenate)((0, ts_js_1.singleElementArray)(getEffectiveBaseTypeNode(node)), getEffectiveImplementsTypeNodes(node)) || ts_js_1.emptyArray :
            ts_js_1.emptyArray;
}
/** @internal */
function getInterfaceBaseTypeNodes(node) {
    const heritageClause = getHeritageClause(node.heritageClauses, 96 /* SyntaxKind.ExtendsKeyword */);
    return heritageClause ? heritageClause.types : undefined;
}
/** @internal */
function getHeritageClause(clauses, kind) {
    if (clauses) {
        for (const clause of clauses) {
            if (clause.token === kind) {
                return clause;
            }
        }
    }
    return undefined;
}
/** @internal */
function getAncestor(node, kind) {
    while (node) {
        if (node.kind === kind) {
            return node;
        }
        node = node.parent;
    }
    return undefined;
}
/** @internal */
function isKeyword(token) {
    return 83 /* SyntaxKind.FirstKeyword */ <= token && token <= 166 /* SyntaxKind.LastKeyword */;
}
/** @internal */
function isPunctuation(token) {
    return 19 /* SyntaxKind.FirstPunctuation */ <= token && token <= 79 /* SyntaxKind.LastPunctuation */;
}
/** @internal */
function isKeywordOrPunctuation(token) {
    return isKeyword(token) || isPunctuation(token);
}
/** @internal */
function isContextualKeyword(token) {
    return 128 /* SyntaxKind.FirstContextualKeyword */ <= token && token <= 166 /* SyntaxKind.LastContextualKeyword */;
}
/** @internal */
function isNonContextualKeyword(token) {
    return isKeyword(token) && !isContextualKeyword(token);
}
/** @internal */
function isStringANonContextualKeyword(name) {
    const token = (0, ts_js_1.stringToToken)(name);
    return token !== undefined && isNonContextualKeyword(token);
}
/** @internal */
function isIdentifierANonContextualKeyword(node) {
    const originalKeywordKind = (0, ts_js_1.identifierToKeywordKind)(node);
    return !!originalKeywordKind && !isContextualKeyword(originalKeywordKind);
}
/** @internal */
function isTrivia(token) {
    return 2 /* SyntaxKind.FirstTriviaToken */ <= token && token <= 7 /* SyntaxKind.LastTriviaToken */;
}
// dprint-ignore
/** @internal */
var FunctionFlags;
(function (FunctionFlags) {
    FunctionFlags[FunctionFlags["Normal"] = 0] = "Normal";
    FunctionFlags[FunctionFlags["Generator"] = 1] = "Generator";
    FunctionFlags[FunctionFlags["Async"] = 2] = "Async";
    FunctionFlags[FunctionFlags["Invalid"] = 4] = "Invalid";
    FunctionFlags[FunctionFlags["AsyncGenerator"] = 3] = "AsyncGenerator";
})(FunctionFlags || (exports.FunctionFlags = FunctionFlags = {}));
/** @internal */
function getFunctionFlags(node) {
    if (!node) {
        return 4 /* FunctionFlags.Invalid */;
    }
    let flags = 0 /* FunctionFlags.Normal */;
    switch (node.kind) {
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 175 /* SyntaxKind.MethodDeclaration */:
            if (node.asteriskToken) {
                flags |= 1 /* FunctionFlags.Generator */;
            }
        // falls through
        case 220 /* SyntaxKind.ArrowFunction */:
            if (hasSyntacticModifier(node, 1024 /* ModifierFlags.Async */)) {
                flags |= 2 /* FunctionFlags.Async */;
            }
            break;
    }
    if (!node.body) {
        flags |= 4 /* FunctionFlags.Invalid */;
    }
    return flags;
}
/** @internal */
function isAsyncFunction(node) {
    switch (node.kind) {
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 175 /* SyntaxKind.MethodDeclaration */:
            return node.body !== undefined
                && node.asteriskToken === undefined
                && hasSyntacticModifier(node, 1024 /* ModifierFlags.Async */);
    }
    return false;
}
/** @internal */
function isStringOrNumericLiteralLike(node) {
    return (0, ts_js_1.isStringLiteralLike)(node) || (0, ts_js_1.isNumericLiteral)(node);
}
/** @internal */
function isSignedNumericLiteral(node) {
    return (0, ts_js_1.isPrefixUnaryExpression)(node) && (node.operator === 40 /* SyntaxKind.PlusToken */ || node.operator === 41 /* SyntaxKind.MinusToken */) && (0, ts_js_1.isNumericLiteral)(node.operand);
}
/**
 * A declaration has a dynamic name if all of the following are true:
 *   1. The declaration has a computed property name.
 *   2. The computed name is *not* expressed as a StringLiteral.
 *   3. The computed name is *not* expressed as a NumericLiteral.
 *   4. The computed name is *not* expressed as a PlusToken or MinusToken
 *      immediately followed by a NumericLiteral.
 *
 * @internal
 */
function hasDynamicName(declaration) {
    const name = (0, ts_js_1.getNameOfDeclaration)(declaration);
    return !!name && isDynamicName(name);
}
/** @internal */
function isDynamicName(name) {
    if (!(name.kind === 168 /* SyntaxKind.ComputedPropertyName */ || name.kind === 213 /* SyntaxKind.ElementAccessExpression */)) {
        return false;
    }
    const expr = (0, ts_js_1.isElementAccessExpression)(name) ? skipParentheses(name.argumentExpression) : name.expression;
    return !isStringOrNumericLiteralLike(expr) &&
        !isSignedNumericLiteral(expr);
}
/** @internal */
function getPropertyNameForPropertyNameNode(name) {
    switch (name.kind) {
        case 80 /* SyntaxKind.Identifier */:
        case 81 /* SyntaxKind.PrivateIdentifier */:
            return name.escapedText;
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
            return (0, ts_js_1.escapeLeadingUnderscores)(name.text);
        case 168 /* SyntaxKind.ComputedPropertyName */:
            const nameExpression = name.expression;
            if (isStringOrNumericLiteralLike(nameExpression)) {
                return (0, ts_js_1.escapeLeadingUnderscores)(nameExpression.text);
            }
            else if (isSignedNumericLiteral(nameExpression)) {
                if (nameExpression.operator === 41 /* SyntaxKind.MinusToken */) {
                    return (0, ts_js_1.tokenToString)(nameExpression.operator) + nameExpression.operand.text;
                }
                return nameExpression.operand.text;
            }
            return undefined;
        case 296 /* SyntaxKind.JsxNamespacedName */:
            return getEscapedTextOfJsxNamespacedName(name);
        default:
            return ts_js_1.Debug.assertNever(name);
    }
}
/** @internal */
function isPropertyNameLiteral(node) {
    switch (node.kind) {
        case 80 /* SyntaxKind.Identifier */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 9 /* SyntaxKind.NumericLiteral */:
            return true;
        default:
            return false;
    }
}
/** @internal */
function getTextOfIdentifierOrLiteral(node) {
    return (0, ts_js_1.isMemberName)(node) ? (0, ts_js_1.idText)(node) : (0, ts_js_1.isJsxNamespacedName)(node) ? getTextOfJsxNamespacedName(node) : node.text;
}
/** @internal */
function getEscapedTextOfIdentifierOrLiteral(node) {
    return (0, ts_js_1.isMemberName)(node) ? node.escapedText : (0, ts_js_1.isJsxNamespacedName)(node) ? getEscapedTextOfJsxNamespacedName(node) : (0, ts_js_1.escapeLeadingUnderscores)(node.text);
}
/** @internal */
function getSymbolNameForPrivateIdentifier(containingClassSymbol, description) {
    return `__#${(0, ts_js_1.getSymbolId)(containingClassSymbol)}@${description}`;
}
/** @internal */
function isKnownSymbol(symbol) {
    return (0, ts_js_1.startsWith)(symbol.escapedName, "__@");
}
/** @internal */
function isPrivateIdentifierSymbol(symbol) {
    return (0, ts_js_1.startsWith)(symbol.escapedName, "__#");
}
/**
 * Indicates whether a property name is the special `__proto__` property.
 * Per the ECMA-262 spec, this only matters for property assignments whose name is
 * the Identifier `__proto__`, or the string literal `"__proto__"`, but not for
 * computed property names.
 */
function isProtoSetter(node) {
    return (0, ts_js_1.isIdentifier)(node) ? (0, ts_js_1.idText)(node) === "__proto__" :
        (0, ts_js_1.isStringLiteral)(node) && node.text === "__proto__";
}
/**
 * Indicates whether an expression is an anonymous function definition.
 *
 * @see https://tc39.es/ecma262/#sec-isanonymousfunctiondefinition
 */
function isAnonymousFunctionDefinition(node, cb) {
    node = (0, ts_js_1.skipOuterExpressions)(node);
    switch (node.kind) {
        case 232 /* SyntaxKind.ClassExpression */:
            if ((0, ts_js_1.classHasDeclaredOrExplicitlyAssignedName)(node)) {
                return false;
            }
            break;
        case 219 /* SyntaxKind.FunctionExpression */:
            if (node.name) {
                return false;
            }
            break;
        case 220 /* SyntaxKind.ArrowFunction */:
            break;
        default:
            return false;
    }
    return typeof cb === "function" ? cb(node) : true;
}
/**
 * Indicates whether a node is a potential source of an assigned name for a class, function, or arrow function.
 *
 * @internal
 */
function isNamedEvaluationSource(node) {
    switch (node.kind) {
        case 304 /* SyntaxKind.PropertyAssignment */:
            return !isProtoSetter(node.name);
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            return !!node.objectAssignmentInitializer;
        case 261 /* SyntaxKind.VariableDeclaration */:
            return (0, ts_js_1.isIdentifier)(node.name) && !!node.initializer;
        case 170 /* SyntaxKind.Parameter */:
            return (0, ts_js_1.isIdentifier)(node.name) && !!node.initializer && !node.dotDotDotToken;
        case 209 /* SyntaxKind.BindingElement */:
            return (0, ts_js_1.isIdentifier)(node.name) && !!node.initializer && !node.dotDotDotToken;
        case 173 /* SyntaxKind.PropertyDeclaration */:
            return !!node.initializer;
        case 227 /* SyntaxKind.BinaryExpression */:
            switch (node.operatorToken.kind) {
                case 64 /* SyntaxKind.EqualsToken */:
                case 77 /* SyntaxKind.AmpersandAmpersandEqualsToken */:
                case 76 /* SyntaxKind.BarBarEqualsToken */:
                case 78 /* SyntaxKind.QuestionQuestionEqualsToken */:
                    return (0, ts_js_1.isIdentifier)(node.left);
            }
            break;
        case 278 /* SyntaxKind.ExportAssignment */:
            return true;
    }
    return false;
}
/** @internal */
function isNamedEvaluation(node, cb) {
    if (!isNamedEvaluationSource(node))
        return false;
    switch (node.kind) {
        case 304 /* SyntaxKind.PropertyAssignment */:
            return isAnonymousFunctionDefinition(node.initializer, cb);
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            return isAnonymousFunctionDefinition(node.objectAssignmentInitializer, cb);
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 170 /* SyntaxKind.Parameter */:
        case 209 /* SyntaxKind.BindingElement */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
            return isAnonymousFunctionDefinition(node.initializer, cb);
        case 227 /* SyntaxKind.BinaryExpression */:
            return isAnonymousFunctionDefinition(node.right, cb);
        case 278 /* SyntaxKind.ExportAssignment */:
            return isAnonymousFunctionDefinition(node.expression, cb);
    }
}
/** @internal */
function isPushOrUnshiftIdentifier(node) {
    return node.escapedText === "push" || node.escapedText === "unshift";
}
/**
 * This function returns true if the this node's root declaration is a parameter.
 * For example, passing a `ParameterDeclaration` will return true, as will passing a
 * binding element that is a child of a `ParameterDeclaration`.
 *
 * If you are looking to test that a `Node` is a `ParameterDeclaration`, use `isParameter`.
 *
 * @internal
 */
function isPartOfParameterDeclaration(node) {
    const root = getRootDeclaration(node);
    return root.kind === 170 /* SyntaxKind.Parameter */;
}
/** @internal */
function getRootDeclaration(node) {
    while (node.kind === 209 /* SyntaxKind.BindingElement */) {
        node = node.parent.parent;
    }
    return node;
}
/** @internal */
function nodeStartsNewLexicalEnvironment(node) {
    const kind = node.kind;
    return kind === 177 /* SyntaxKind.Constructor */
        || kind === 219 /* SyntaxKind.FunctionExpression */
        || kind === 263 /* SyntaxKind.FunctionDeclaration */
        || kind === 220 /* SyntaxKind.ArrowFunction */
        || kind === 175 /* SyntaxKind.MethodDeclaration */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 308 /* SyntaxKind.SourceFile */;
}
/** @internal */
function nodeIsSynthesized(range) {
    return positionIsSynthesized(range.pos)
        || positionIsSynthesized(range.end);
}
/** @internal */
var Associativity;
(function (Associativity) {
    Associativity[Associativity["Left"] = 0] = "Left";
    Associativity[Associativity["Right"] = 1] = "Right";
})(Associativity || (exports.Associativity = Associativity = {}));
/** @internal */
function getExpressionAssociativity(expression) {
    const operator = getOperator(expression);
    const hasArguments = expression.kind === 215 /* SyntaxKind.NewExpression */ && expression.arguments !== undefined;
    return getOperatorAssociativity(expression.kind, operator, hasArguments);
}
/** @internal */
function getOperatorAssociativity(kind, operator, hasArguments) {
    switch (kind) {
        case 215 /* SyntaxKind.NewExpression */:
            return hasArguments ? 0 /* Associativity.Left */ : 1 /* Associativity.Right */;
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
        case 222 /* SyntaxKind.TypeOfExpression */:
        case 223 /* SyntaxKind.VoidExpression */:
        case 221 /* SyntaxKind.DeleteExpression */:
        case 224 /* SyntaxKind.AwaitExpression */:
        case 228 /* SyntaxKind.ConditionalExpression */:
        case 230 /* SyntaxKind.YieldExpression */:
            return 1 /* Associativity.Right */;
        case 227 /* SyntaxKind.BinaryExpression */:
            switch (operator) {
                case 43 /* SyntaxKind.AsteriskAsteriskToken */:
                case 64 /* SyntaxKind.EqualsToken */:
                case 65 /* SyntaxKind.PlusEqualsToken */:
                case 66 /* SyntaxKind.MinusEqualsToken */:
                case 68 /* SyntaxKind.AsteriskAsteriskEqualsToken */:
                case 67 /* SyntaxKind.AsteriskEqualsToken */:
                case 69 /* SyntaxKind.SlashEqualsToken */:
                case 70 /* SyntaxKind.PercentEqualsToken */:
                case 71 /* SyntaxKind.LessThanLessThanEqualsToken */:
                case 72 /* SyntaxKind.GreaterThanGreaterThanEqualsToken */:
                case 73 /* SyntaxKind.GreaterThanGreaterThanGreaterThanEqualsToken */:
                case 74 /* SyntaxKind.AmpersandEqualsToken */:
                case 79 /* SyntaxKind.CaretEqualsToken */:
                case 75 /* SyntaxKind.BarEqualsToken */:
                case 76 /* SyntaxKind.BarBarEqualsToken */:
                case 77 /* SyntaxKind.AmpersandAmpersandEqualsToken */:
                case 78 /* SyntaxKind.QuestionQuestionEqualsToken */:
                    return 1 /* Associativity.Right */;
            }
    }
    return 0 /* Associativity.Left */;
}
/** @internal */
function getExpressionPrecedence(expression) {
    const operator = getOperator(expression);
    const hasArguments = expression.kind === 215 /* SyntaxKind.NewExpression */ && expression.arguments !== undefined;
    return getOperatorPrecedence(expression.kind, operator, hasArguments);
}
function getOperator(expression) {
    if (expression.kind === 227 /* SyntaxKind.BinaryExpression */) {
        return expression.operatorToken.kind;
    }
    else if (expression.kind === 225 /* SyntaxKind.PrefixUnaryExpression */ || expression.kind === 226 /* SyntaxKind.PostfixUnaryExpression */) {
        return expression.operator;
    }
    else {
        return expression.kind;
    }
}
/** @internal */
var OperatorPrecedence;
(function (OperatorPrecedence) {
    // Expression:
    //     AssignmentExpression
    //     Expression `,` AssignmentExpression
    OperatorPrecedence[OperatorPrecedence["Comma"] = 0] = "Comma";
    // NOTE: `Spread` is higher than `Comma` due to how it is parsed in |ElementList|
    // SpreadElement:
    //     `...` AssignmentExpression
    OperatorPrecedence[OperatorPrecedence["Spread"] = 1] = "Spread";
    // AssignmentExpression:
    //     ConditionalExpression
    //     YieldExpression
    //     ArrowFunction
    //     AsyncArrowFunction
    //     LeftHandSideExpression `=` AssignmentExpression
    //     LeftHandSideExpression AssignmentOperator AssignmentExpression
    //
    // NOTE: AssignmentExpression is broken down into several precedences due to the requirements
    //       of the parenthesizer rules.
    // AssignmentExpression: YieldExpression
    // YieldExpression:
    //     `yield`
    //     `yield` AssignmentExpression
    //     `yield` `*` AssignmentExpression
    OperatorPrecedence[OperatorPrecedence["Yield"] = 2] = "Yield";
    // AssignmentExpression: LeftHandSideExpression `=` AssignmentExpression
    // AssignmentExpression: LeftHandSideExpression AssignmentOperator AssignmentExpression
    // AssignmentOperator: one of
    //     `*=` `/=` `%=` `+=` `-=` `<<=` `>>=` `>>>=` `&=` `^=` `|=` `**=`
    OperatorPrecedence[OperatorPrecedence["Assignment"] = 3] = "Assignment";
    // NOTE: `Conditional` is considered higher than `Assignment` here, but in reality they have
    //       the same precedence.
    // AssignmentExpression: ConditionalExpression
    // ConditionalExpression:
    //     ShortCircuitExpression
    //     ShortCircuitExpression `?` AssignmentExpression `:` AssignmentExpression
    // ShortCircuitExpression:
    //     LogicalORExpression
    //     CoalesceExpression
    OperatorPrecedence[OperatorPrecedence["Conditional"] = 4] = "Conditional";
    // LogicalORExpression:
    //     LogicalANDExpression
    //     LogicalORExpression `||` LogicalANDExpression
    OperatorPrecedence[OperatorPrecedence["LogicalOR"] = 5] = "LogicalOR";
    // CoalesceExpression:
    //     CoalesceExpressionHead `??` BitwiseORExpression
    // CoalesceExpressionHead:
    //     CoalesceExpression
    //     BitwiseORExpression
    OperatorPrecedence[OperatorPrecedence["Coalesce"] = 5] = "Coalesce";
    // LogicalANDExpression:
    //     BitwiseORExpression
    //     LogicalANDExprerssion `&&` BitwiseORExpression
    OperatorPrecedence[OperatorPrecedence["LogicalAND"] = 6] = "LogicalAND";
    // BitwiseORExpression:
    //     BitwiseXORExpression
    //     BitwiseORExpression `^` BitwiseXORExpression
    OperatorPrecedence[OperatorPrecedence["BitwiseOR"] = 7] = "BitwiseOR";
    // BitwiseXORExpression:
    //     BitwiseANDExpression
    //     BitwiseXORExpression `^` BitwiseANDExpression
    OperatorPrecedence[OperatorPrecedence["BitwiseXOR"] = 8] = "BitwiseXOR";
    // BitwiseANDExpression:
    //     EqualityExpression
    //     BitwiseANDExpression `^` EqualityExpression
    OperatorPrecedence[OperatorPrecedence["BitwiseAND"] = 9] = "BitwiseAND";
    // EqualityExpression:
    //     RelationalExpression
    //     EqualityExpression `==` RelationalExpression
    //     EqualityExpression `!=` RelationalExpression
    //     EqualityExpression `===` RelationalExpression
    //     EqualityExpression `!==` RelationalExpression
    OperatorPrecedence[OperatorPrecedence["Equality"] = 10] = "Equality";
    // RelationalExpression:
    //     ShiftExpression
    //     RelationalExpression `<` ShiftExpression
    //     RelationalExpression `>` ShiftExpression
    //     RelationalExpression `<=` ShiftExpression
    //     RelationalExpression `>=` ShiftExpression
    //     RelationalExpression `instanceof` ShiftExpression
    //     RelationalExpression `in` ShiftExpression
    //     [+TypeScript] RelationalExpression `as` Type
    OperatorPrecedence[OperatorPrecedence["Relational"] = 11] = "Relational";
    // ShiftExpression:
    //     AdditiveExpression
    //     ShiftExpression `<<` AdditiveExpression
    //     ShiftExpression `>>` AdditiveExpression
    //     ShiftExpression `>>>` AdditiveExpression
    OperatorPrecedence[OperatorPrecedence["Shift"] = 12] = "Shift";
    // AdditiveExpression:
    //     MultiplicativeExpression
    //     AdditiveExpression `+` MultiplicativeExpression
    //     AdditiveExpression `-` MultiplicativeExpression
    OperatorPrecedence[OperatorPrecedence["Additive"] = 13] = "Additive";
    // MultiplicativeExpression:
    //     ExponentiationExpression
    //     MultiplicativeExpression MultiplicativeOperator ExponentiationExpression
    // MultiplicativeOperator: one of `*`, `/`, `%`
    OperatorPrecedence[OperatorPrecedence["Multiplicative"] = 14] = "Multiplicative";
    // ExponentiationExpression:
    //     UnaryExpression
    //     UpdateExpression `**` ExponentiationExpression
    OperatorPrecedence[OperatorPrecedence["Exponentiation"] = 15] = "Exponentiation";
    // UnaryExpression:
    //     UpdateExpression
    //     `delete` UnaryExpression
    //     `void` UnaryExpression
    //     `typeof` UnaryExpression
    //     `+` UnaryExpression
    //     `-` UnaryExpression
    //     `~` UnaryExpression
    //     `!` UnaryExpression
    //     AwaitExpression
    // UpdateExpression:            // TODO: Do we need to investigate the precedence here?
    //     `++` UnaryExpression
    //     `--` UnaryExpression
    OperatorPrecedence[OperatorPrecedence["Unary"] = 16] = "Unary";
    // UpdateExpression:
    //     LeftHandSideExpression
    //     LeftHandSideExpression `++`
    //     LeftHandSideExpression `--`
    OperatorPrecedence[OperatorPrecedence["Update"] = 17] = "Update";
    // LeftHandSideExpression:
    //     NewExpression
    //     CallExpression
    // NewExpression:
    //     MemberExpression
    //     `new` NewExpression
    OperatorPrecedence[OperatorPrecedence["LeftHandSide"] = 18] = "LeftHandSide";
    // CallExpression:
    //     CoverCallExpressionAndAsyncArrowHead
    //     SuperCall
    //     ImportCall
    //     CallExpression Arguments
    //     CallExpression `[` Expression `]`
    //     CallExpression `.` IdentifierName
    //     CallExpression TemplateLiteral
    // MemberExpression:
    //     PrimaryExpression
    //     MemberExpression `[` Expression `]`
    //     MemberExpression `.` IdentifierName
    //     MemberExpression TemplateLiteral
    //     SuperProperty
    //     MetaProperty
    //     `new` MemberExpression Arguments
    OperatorPrecedence[OperatorPrecedence["Member"] = 19] = "Member";
    // TODO: JSXElement?
    // PrimaryExpression:
    //     `this`
    //     IdentifierReference
    //     Literal
    //     ArrayLiteral
    //     ObjectLiteral
    //     FunctionExpression
    //     ClassExpression
    //     GeneratorExpression
    //     AsyncFunctionExpression
    //     AsyncGeneratorExpression
    //     RegularExpressionLiteral
    //     TemplateLiteral
    //     CoverParenthesizedExpressionAndArrowParameterList
    OperatorPrecedence[OperatorPrecedence["Primary"] = 20] = "Primary";
    OperatorPrecedence[OperatorPrecedence["Highest"] = 20] = "Highest";
    OperatorPrecedence[OperatorPrecedence["Lowest"] = 0] = "Lowest";
    // -1 is lower than all other precedences. Returning it will cause binary expression
    // parsing to stop.
    OperatorPrecedence[OperatorPrecedence["Invalid"] = -1] = "Invalid";
})(OperatorPrecedence || (exports.OperatorPrecedence = OperatorPrecedence = {}));
/** @internal */
function getOperatorPrecedence(nodeKind, operatorKind, hasArguments) {
    switch (nodeKind) {
        case 357 /* SyntaxKind.CommaListExpression */:
            return 0 /* OperatorPrecedence.Comma */;
        case 231 /* SyntaxKind.SpreadElement */:
            return 1 /* OperatorPrecedence.Spread */;
        case 230 /* SyntaxKind.YieldExpression */:
            return 2 /* OperatorPrecedence.Yield */;
        case 228 /* SyntaxKind.ConditionalExpression */:
            return 4 /* OperatorPrecedence.Conditional */;
        case 227 /* SyntaxKind.BinaryExpression */:
            switch (operatorKind) {
                case 28 /* SyntaxKind.CommaToken */:
                    return 0 /* OperatorPrecedence.Comma */;
                case 64 /* SyntaxKind.EqualsToken */:
                case 65 /* SyntaxKind.PlusEqualsToken */:
                case 66 /* SyntaxKind.MinusEqualsToken */:
                case 68 /* SyntaxKind.AsteriskAsteriskEqualsToken */:
                case 67 /* SyntaxKind.AsteriskEqualsToken */:
                case 69 /* SyntaxKind.SlashEqualsToken */:
                case 70 /* SyntaxKind.PercentEqualsToken */:
                case 71 /* SyntaxKind.LessThanLessThanEqualsToken */:
                case 72 /* SyntaxKind.GreaterThanGreaterThanEqualsToken */:
                case 73 /* SyntaxKind.GreaterThanGreaterThanGreaterThanEqualsToken */:
                case 74 /* SyntaxKind.AmpersandEqualsToken */:
                case 79 /* SyntaxKind.CaretEqualsToken */:
                case 75 /* SyntaxKind.BarEqualsToken */:
                case 76 /* SyntaxKind.BarBarEqualsToken */:
                case 77 /* SyntaxKind.AmpersandAmpersandEqualsToken */:
                case 78 /* SyntaxKind.QuestionQuestionEqualsToken */:
                    return 3 /* OperatorPrecedence.Assignment */;
                default:
                    return getBinaryOperatorPrecedence(operatorKind);
            }
        // TODO: Should prefix `++` and `--` be moved to the `Update` precedence?
        case 217 /* SyntaxKind.TypeAssertionExpression */:
        case 236 /* SyntaxKind.NonNullExpression */:
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
        case 222 /* SyntaxKind.TypeOfExpression */:
        case 223 /* SyntaxKind.VoidExpression */:
        case 221 /* SyntaxKind.DeleteExpression */:
        case 224 /* SyntaxKind.AwaitExpression */:
            return 16 /* OperatorPrecedence.Unary */;
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
            return 17 /* OperatorPrecedence.Update */;
        case 214 /* SyntaxKind.CallExpression */:
            return 18 /* OperatorPrecedence.LeftHandSide */;
        case 215 /* SyntaxKind.NewExpression */:
            return hasArguments ? 19 /* OperatorPrecedence.Member */ : 18 /* OperatorPrecedence.LeftHandSide */;
        case 216 /* SyntaxKind.TaggedTemplateExpression */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 237 /* SyntaxKind.MetaProperty */:
            return 19 /* OperatorPrecedence.Member */;
        case 235 /* SyntaxKind.AsExpression */:
        case 239 /* SyntaxKind.SatisfiesExpression */:
            return 11 /* OperatorPrecedence.Relational */;
        case 110 /* SyntaxKind.ThisKeyword */:
        case 108 /* SyntaxKind.SuperKeyword */:
        case 80 /* SyntaxKind.Identifier */:
        case 81 /* SyntaxKind.PrivateIdentifier */:
        case 106 /* SyntaxKind.NullKeyword */:
        case 112 /* SyntaxKind.TrueKeyword */:
        case 97 /* SyntaxKind.FalseKeyword */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 10 /* SyntaxKind.BigIntLiteral */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 219 /* SyntaxKind.FunctionExpression */:
        case 220 /* SyntaxKind.ArrowFunction */:
        case 232 /* SyntaxKind.ClassExpression */:
        case 14 /* SyntaxKind.RegularExpressionLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
        case 229 /* SyntaxKind.TemplateExpression */:
        case 218 /* SyntaxKind.ParenthesizedExpression */:
        case 233 /* SyntaxKind.OmittedExpression */:
        case 285 /* SyntaxKind.JsxElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
        case 289 /* SyntaxKind.JsxFragment */:
            return 20 /* OperatorPrecedence.Primary */;
        default:
            return -1 /* OperatorPrecedence.Invalid */;
    }
}
/** @internal */
function getBinaryOperatorPrecedence(kind) {
    switch (kind) {
        case 61 /* SyntaxKind.QuestionQuestionToken */:
            return 5 /* OperatorPrecedence.Coalesce */;
        case 57 /* SyntaxKind.BarBarToken */:
            return 5 /* OperatorPrecedence.LogicalOR */;
        case 56 /* SyntaxKind.AmpersandAmpersandToken */:
            return 6 /* OperatorPrecedence.LogicalAND */;
        case 52 /* SyntaxKind.BarToken */:
            return 7 /* OperatorPrecedence.BitwiseOR */;
        case 53 /* SyntaxKind.CaretToken */:
            return 8 /* OperatorPrecedence.BitwiseXOR */;
        case 51 /* SyntaxKind.AmpersandToken */:
            return 9 /* OperatorPrecedence.BitwiseAND */;
        case 35 /* SyntaxKind.EqualsEqualsToken */:
        case 36 /* SyntaxKind.ExclamationEqualsToken */:
        case 37 /* SyntaxKind.EqualsEqualsEqualsToken */:
        case 38 /* SyntaxKind.ExclamationEqualsEqualsToken */:
            return 10 /* OperatorPrecedence.Equality */;
        case 30 /* SyntaxKind.LessThanToken */:
        case 32 /* SyntaxKind.GreaterThanToken */:
        case 33 /* SyntaxKind.LessThanEqualsToken */:
        case 34 /* SyntaxKind.GreaterThanEqualsToken */:
        case 104 /* SyntaxKind.InstanceOfKeyword */:
        case 103 /* SyntaxKind.InKeyword */:
        case 130 /* SyntaxKind.AsKeyword */:
        case 152 /* SyntaxKind.SatisfiesKeyword */:
            return 11 /* OperatorPrecedence.Relational */;
        case 48 /* SyntaxKind.LessThanLessThanToken */:
        case 49 /* SyntaxKind.GreaterThanGreaterThanToken */:
        case 50 /* SyntaxKind.GreaterThanGreaterThanGreaterThanToken */:
            return 12 /* OperatorPrecedence.Shift */;
        case 40 /* SyntaxKind.PlusToken */:
        case 41 /* SyntaxKind.MinusToken */:
            return 13 /* OperatorPrecedence.Additive */;
        case 42 /* SyntaxKind.AsteriskToken */:
        case 44 /* SyntaxKind.SlashToken */:
        case 45 /* SyntaxKind.PercentToken */:
            return 14 /* OperatorPrecedence.Multiplicative */;
        case 43 /* SyntaxKind.AsteriskAsteriskToken */:
            return 15 /* OperatorPrecedence.Exponentiation */;
    }
    // -1 is lower than all other precedences.  Returning it will cause binary expression
    // parsing to stop.
    return -1;
}
/** @internal */
function getSemanticJsxChildren(children) {
    return (0, ts_js_1.filter)(children, i => {
        switch (i.kind) {
            case 295 /* SyntaxKind.JsxExpression */:
                return !!i.expression;
            case 12 /* SyntaxKind.JsxText */:
                return !i.containsOnlyTriviaWhiteSpaces;
            default:
                return true;
        }
    });
}
/** @internal */
function createDiagnosticCollection() {
    let nonFileDiagnostics = []; // See GH#19873
    const filesWithDiagnostics = [];
    const fileDiagnostics = new Map();
    let hasReadNonFileDiagnostics = false;
    return {
        add,
        lookup,
        getGlobalDiagnostics,
        getDiagnostics,
    };
    function lookup(diagnostic) {
        let diagnostics;
        if (diagnostic.file) {
            diagnostics = fileDiagnostics.get(diagnostic.file.fileName);
        }
        else {
            diagnostics = nonFileDiagnostics;
        }
        if (!diagnostics) {
            return undefined;
        }
        const result = (0, ts_js_1.binarySearch)(diagnostics, diagnostic, ts_js_1.identity, compareDiagnosticsSkipRelatedInformation);
        if (result >= 0) {
            return diagnostics[result];
        }
        if (~result > 0 && diagnosticsEqualityComparer(diagnostic, diagnostics[~result - 1])) {
            return diagnostics[~result - 1];
        }
        return undefined;
    }
    function add(diagnostic) {
        let diagnostics;
        if (diagnostic.file) {
            diagnostics = fileDiagnostics.get(diagnostic.file.fileName);
            if (!diagnostics) {
                diagnostics = []; // See GH#19873
                fileDiagnostics.set(diagnostic.file.fileName, diagnostics);
                (0, ts_js_1.insertSorted)(filesWithDiagnostics, diagnostic.file.fileName, ts_js_1.compareStringsCaseSensitive);
            }
        }
        else {
            // If we've already read the non-file diagnostics, do not modify the existing array.
            if (hasReadNonFileDiagnostics) {
                hasReadNonFileDiagnostics = false;
                nonFileDiagnostics = nonFileDiagnostics.slice();
            }
            diagnostics = nonFileDiagnostics;
        }
        (0, ts_js_1.insertSorted)(diagnostics, diagnostic, compareDiagnosticsSkipRelatedInformation, diagnosticsEqualityComparer);
    }
    function getGlobalDiagnostics() {
        hasReadNonFileDiagnostics = true;
        return nonFileDiagnostics;
    }
    function getDiagnostics(fileName) {
        if (fileName) {
            return fileDiagnostics.get(fileName) || [];
        }
        const fileDiags = (0, ts_js_1.flatMapToMutable)(filesWithDiagnostics, f => fileDiagnostics.get(f));
        if (!nonFileDiagnostics.length) {
            return fileDiags;
        }
        fileDiags.unshift(...nonFileDiagnostics);
        return fileDiags;
    }
}
const templateSubstitutionRegExp = /\$\{/g;
/** @internal */
function escapeTemplateSubstitution(str) {
    return str.replace(templateSubstitutionRegExp, "\\${");
}
function containsInvalidEscapeFlag(node) {
    return !!((node.templateFlags || 0) & 2048 /* TokenFlags.ContainsInvalidEscape */);
}
/** @internal */
function hasInvalidEscape(template) {
    return template && !!((0, ts_js_1.isNoSubstitutionTemplateLiteral)(template)
        ? containsInvalidEscapeFlag(template)
        : (containsInvalidEscapeFlag(template.head) || (0, ts_js_1.some)(template.templateSpans, span => containsInvalidEscapeFlag(span.literal))));
}
// This consists of the first 19 unprintable ASCII characters, canonical escapes, lineSeparator,
// paragraphSeparator, and nextLine. The latter three are just desirable to suppress new lines in
// the language service. These characters should be escaped when printing, and if any characters are added,
// the map below must be updated. Note that this regexp *does not* include the 'delete' character.
// There is no reason for this other than that JSON.stringify does not handle it either.
const doubleQuoteEscapedCharsRegExp = /[\\"\u0000-\u001f\u2028\u2029\u0085]/g;
const singleQuoteEscapedCharsRegExp = /[\\'\u0000-\u001f\u2028\u2029\u0085]/g;
// Template strings preserve simple LF newlines, still encode CRLF (or CR)
const backtickQuoteEscapedCharsRegExp = /\r\n|[\\`\u0000-\u0009\u000b-\u001f\u2028\u2029\u0085]/g;
const escapedCharsMap = new Map(Object.entries({
    "\t": "\\t",
    "\v": "\\v",
    "\f": "\\f",
    "\b": "\\b",
    "\r": "\\r",
    "\n": "\\n",
    "\\": "\\\\",
    '"': '\\"',
    "'": "\\'",
    "`": "\\`",
    "\u2028": "\\u2028", // lineSeparator
    "\u2029": "\\u2029", // paragraphSeparator
    "\u0085": "\\u0085", // nextLine
    "\r\n": "\\r\\n", // special case for CRLFs in backticks
}));
function encodeUtf16EscapeSequence(charCode) {
    const hexCharCode = charCode.toString(16).toUpperCase();
    const paddedHexCode = ("0000" + hexCharCode).slice(-4);
    return "\\u" + paddedHexCode;
}
function getReplacement(c, offset, input) {
    if (c.charCodeAt(0) === 0 /* CharacterCodes.nullCharacter */) {
        const lookAhead = input.charCodeAt(offset + c.length);
        if (lookAhead >= 48 /* CharacterCodes._0 */ && lookAhead <= 57 /* CharacterCodes._9 */) {
            // If the null character is followed by digits, print as a hex escape to prevent the result from parsing as an octal (which is forbidden in strict mode)
            return "\\x00";
        }
        // Otherwise, keep printing a literal \0 for the null character
        return "\\0";
    }
    return escapedCharsMap.get(c) || encodeUtf16EscapeSequence(c.charCodeAt(0));
}
/**
 * Based heavily on the abstract 'Quote'/'QuoteJSONString' operation from ECMA-262 (24.3.2.2),
 * but augmented for a few select characters (e.g. lineSeparator, paragraphSeparator, nextLine)
 * Note that this doesn't actually wrap the input in double quotes.
 *
 * @internal
 */
function escapeString(s, quoteChar) {
    const escapedCharsRegExp = quoteChar === 96 /* CharacterCodes.backtick */ ? backtickQuoteEscapedCharsRegExp :
        quoteChar === 39 /* CharacterCodes.singleQuote */ ? singleQuoteEscapedCharsRegExp :
            doubleQuoteEscapedCharsRegExp;
    return s.replace(escapedCharsRegExp, getReplacement);
}
const nonAsciiCharacters = /[^\u0000-\u007F]/g;
/** @internal */
function escapeNonAsciiString(s, quoteChar) {
    s = escapeString(s, quoteChar);
    // Replace non-ASCII characters with '\uNNNN' escapes if any exist.
    // Otherwise just return the original string.
    return nonAsciiCharacters.test(s) ?
        s.replace(nonAsciiCharacters, c => encodeUtf16EscapeSequence(c.charCodeAt(0))) :
        s;
}
// This consists of the first 19 unprintable ASCII characters, JSX canonical escapes, lineSeparator,
// paragraphSeparator, and nextLine. The latter three are just desirable to suppress new lines in
// the language service. These characters should be escaped when printing, and if any characters are added,
// the map below must be updated.
const jsxDoubleQuoteEscapedCharsRegExp = /["\u0000-\u001f\u2028\u2029\u0085]/g;
const jsxSingleQuoteEscapedCharsRegExp = /['\u0000-\u001f\u2028\u2029\u0085]/g;
const jsxEscapedCharsMap = new Map(Object.entries({
    '"': "&quot;",
    "'": "&apos;",
}));
function encodeJsxCharacterEntity(charCode) {
    const hexCharCode = charCode.toString(16).toUpperCase();
    return "&#x" + hexCharCode + ";";
}
function getJsxAttributeStringReplacement(c) {
    if (c.charCodeAt(0) === 0 /* CharacterCodes.nullCharacter */) {
        return "&#0;";
    }
    return jsxEscapedCharsMap.get(c) || encodeJsxCharacterEntity(c.charCodeAt(0));
}
/** @internal */
function escapeJsxAttributeString(s, quoteChar) {
    const escapedCharsRegExp = quoteChar === 39 /* CharacterCodes.singleQuote */ ? jsxSingleQuoteEscapedCharsRegExp :
        jsxDoubleQuoteEscapedCharsRegExp;
    return s.replace(escapedCharsRegExp, getJsxAttributeStringReplacement);
}
/**
 * Strip off existed surrounding single quotes, double quotes, or backticks from a given string
 *
 * @return non-quoted string
 *
 * @internal
 */
function stripQuotes(name) {
    const length = name.length;
    if (length >= 2 && name.charCodeAt(0) === name.charCodeAt(length - 1) && isQuoteOrBacktick(name.charCodeAt(0))) {
        return name.substring(1, length - 1);
    }
    return name;
}
function isQuoteOrBacktick(charCode) {
    return charCode === 39 /* CharacterCodes.singleQuote */ ||
        charCode === 34 /* CharacterCodes.doubleQuote */ ||
        charCode === 96 /* CharacterCodes.backtick */;
}
/** @internal */
function isIntrinsicJsxName(name) {
    const ch = name.charCodeAt(0);
    return (ch >= 97 /* CharacterCodes.a */ && ch <= 122 /* CharacterCodes.z */) || name.includes("-");
}
const indentStrings = ["", "    "];
/** @internal */
function getIndentString(level) {
    // prepopulate cache
    const singleLevel = indentStrings[1];
    for (let current = indentStrings.length; current <= level; current++) {
        indentStrings.push(indentStrings[current - 1] + singleLevel);
    }
    return indentStrings[level];
}
function getIndentSize() {
    return indentStrings[1].length;
}
/** @internal */
function createTextWriter(newLine) {
    // Why var? It avoids TDZ checks in the runtime which can be costly.
    // See: https://github.com/microsoft/TypeScript/issues/52924
    /* eslint-disable no-var */
    var output;
    var indent;
    var lineStart;
    var lineCount;
    var linePos;
    var hasTrailingComment = false;
    /* eslint-enable no-var */
    function updateLineCountAndPosFor(s) {
        const lineStartsOfS = (0, ts_js_1.computeLineStarts)(s);
        if (lineStartsOfS.length > 1) {
            lineCount = lineCount + lineStartsOfS.length - 1;
            linePos = output.length - s.length + (0, ts_js_1.last)(lineStartsOfS);
            lineStart = (linePos - output.length) === 0;
        }
        else {
            lineStart = false;
        }
    }
    function writeText(s) {
        if (s && s.length) {
            if (lineStart) {
                s = getIndentString(indent) + s;
                lineStart = false;
            }
            output += s;
            updateLineCountAndPosFor(s);
        }
    }
    function write(s) {
        if (s)
            hasTrailingComment = false;
        writeText(s);
    }
    function writeComment(s) {
        if (s)
            hasTrailingComment = true;
        writeText(s);
    }
    function reset() {
        output = "";
        indent = 0;
        lineStart = true;
        lineCount = 0;
        linePos = 0;
        hasTrailingComment = false;
    }
    function rawWrite(s) {
        if (s !== undefined) {
            output += s;
            updateLineCountAndPosFor(s);
            hasTrailingComment = false;
        }
    }
    function writeLiteral(s) {
        if (s && s.length) {
            write(s);
        }
    }
    function writeLine(force) {
        if (!lineStart || force) {
            output += newLine;
            lineCount++;
            linePos = output.length;
            lineStart = true;
            hasTrailingComment = false;
        }
    }
    reset();
    return {
        write,
        rawWrite,
        writeLiteral,
        writeLine,
        increaseIndent: () => {
            indent++;
        },
        decreaseIndent: () => {
            indent--;
        },
        getIndent: () => indent,
        getTextPos: () => output.length,
        getLine: () => lineCount,
        getColumn: () => lineStart ? indent * getIndentSize() : output.length - linePos,
        getText: () => output,
        isAtStartOfLine: () => lineStart,
        hasTrailingComment: () => hasTrailingComment,
        hasTrailingWhitespace: () => !!output.length && (0, ts_js_1.isWhiteSpaceLike)(output.charCodeAt(output.length - 1)),
        clear: reset,
        writeKeyword: write,
        writeOperator: write,
        writeParameter: write,
        writeProperty: write,
        writePunctuation: write,
        writeSpace: write,
        writeStringLiteral: write,
        writeSymbol: (s, _) => write(s),
        writeTrailingSemicolon: write,
        writeComment,
    };
}
/** @internal */
function getTrailingSemicolonDeferringWriter(writer) {
    let pendingTrailingSemicolon = false;
    function commitPendingTrailingSemicolon() {
        if (pendingTrailingSemicolon) {
            writer.writeTrailingSemicolon(";");
            pendingTrailingSemicolon = false;
        }
    }
    return {
        ...writer,
        writeTrailingSemicolon() {
            pendingTrailingSemicolon = true;
        },
        writeLiteral(s) {
            commitPendingTrailingSemicolon();
            writer.writeLiteral(s);
        },
        writeStringLiteral(s) {
            commitPendingTrailingSemicolon();
            writer.writeStringLiteral(s);
        },
        writeSymbol(s, sym) {
            commitPendingTrailingSemicolon();
            writer.writeSymbol(s, sym);
        },
        writePunctuation(s) {
            commitPendingTrailingSemicolon();
            writer.writePunctuation(s);
        },
        writeKeyword(s) {
            commitPendingTrailingSemicolon();
            writer.writeKeyword(s);
        },
        writeOperator(s) {
            commitPendingTrailingSemicolon();
            writer.writeOperator(s);
        },
        writeParameter(s) {
            commitPendingTrailingSemicolon();
            writer.writeParameter(s);
        },
        writeSpace(s) {
            commitPendingTrailingSemicolon();
            writer.writeSpace(s);
        },
        writeProperty(s) {
            commitPendingTrailingSemicolon();
            writer.writeProperty(s);
        },
        writeComment(s) {
            commitPendingTrailingSemicolon();
            writer.writeComment(s);
        },
        writeLine() {
            commitPendingTrailingSemicolon();
            writer.writeLine();
        },
        increaseIndent() {
            commitPendingTrailingSemicolon();
            writer.increaseIndent();
        },
        decreaseIndent() {
            commitPendingTrailingSemicolon();
            writer.decreaseIndent();
        },
    };
}
/** @internal */
function hostUsesCaseSensitiveFileNames(host) {
    return host.useCaseSensitiveFileNames ? host.useCaseSensitiveFileNames() : false;
}
/** @internal */
function hostGetCanonicalFileName(host) {
    return (0, ts_js_1.createGetCanonicalFileName)(hostUsesCaseSensitiveFileNames(host));
}
/** @internal */
function getResolvedExternalModuleName(host, file, referenceFile) {
    return file.moduleName || getExternalModuleNameFromPath(host, file.fileName, referenceFile && referenceFile.fileName);
}
function getCanonicalAbsolutePath(host, path) {
    return host.getCanonicalFileName((0, ts_js_1.getNormalizedAbsolutePath)(path, host.getCurrentDirectory()));
}
/** @internal */
function getExternalModuleNameFromDeclaration(host, resolver, declaration) {
    const file = resolver.getExternalModuleFileFromDeclaration(declaration);
    if (!file || file.isDeclarationFile) {
        return undefined;
    }
    // If the declaration already uses a non-relative name, and is outside the common source directory, continue to use it
    const specifier = getExternalModuleName(declaration);
    if (specifier && (0, ts_js_1.isStringLiteralLike)(specifier) && !(0, ts_js_1.pathIsRelative)(specifier.text) &&
        !getCanonicalAbsolutePath(host, file.path).includes(getCanonicalAbsolutePath(host, (0, ts_js_1.ensureTrailingDirectorySeparator)(host.getCommonSourceDirectory())))) {
        return undefined;
    }
    return getResolvedExternalModuleName(host, file);
}
/**
 * Resolves a local path to a path which is absolute to the base of the emit
 *
 * @internal
 */
function getExternalModuleNameFromPath(host, fileName, referencePath) {
    const getCanonicalFileName = (f) => host.getCanonicalFileName(f);
    const dir = (0, ts_js_1.toPath)(referencePath ? (0, ts_js_1.getDirectoryPath)(referencePath) : host.getCommonSourceDirectory(), host.getCurrentDirectory(), getCanonicalFileName);
    const filePath = (0, ts_js_1.getNormalizedAbsolutePath)(fileName, host.getCurrentDirectory());
    const relativePath = (0, ts_js_1.getRelativePathToDirectoryOrUrl)(dir, filePath, dir, getCanonicalFileName, /*isAbsolutePathAnUrl*/ false);
    const extensionless = removeFileExtension(relativePath);
    return referencePath ? (0, ts_js_1.ensurePathIsNonModuleName)(extensionless) : extensionless;
}
/** @internal */
function getOwnEmitOutputFilePath(fileName, host, extension) {
    const compilerOptions = host.getCompilerOptions();
    let emitOutputFilePathWithoutExtension;
    if (compilerOptions.outDir) {
        emitOutputFilePathWithoutExtension = removeFileExtension(getSourceFilePathInNewDir(fileName, host, compilerOptions.outDir));
    }
    else {
        emitOutputFilePathWithoutExtension = removeFileExtension(fileName);
    }
    return emitOutputFilePathWithoutExtension + extension;
}
/** @internal */
function getDeclarationEmitOutputFilePath(fileName, host) {
    return getDeclarationEmitOutputFilePathWorker(fileName, host.getCompilerOptions(), host);
}
/** @internal */
function getDeclarationEmitOutputFilePathWorker(fileName, options, host) {
    const outputDir = options.declarationDir || options.outDir; // Prefer declaration folder if specified
    const path = outputDir
        ? getSourceFilePathInNewDirWorker(fileName, outputDir, host.getCurrentDirectory(), host.getCommonSourceDirectory(), f => host.getCanonicalFileName(f))
        : fileName;
    const declarationExtension = getDeclarationEmitExtensionForPath(path);
    return removeFileExtension(path) + declarationExtension;
}
/** @internal */
function getDeclarationEmitExtensionForPath(path) {
    return (0, ts_js_1.fileExtensionIsOneOf)(path, [".mjs" /* Extension.Mjs */, ".mts" /* Extension.Mts */]) ? ".d.mts" /* Extension.Dmts */ :
        (0, ts_js_1.fileExtensionIsOneOf)(path, [".cjs" /* Extension.Cjs */, ".cts" /* Extension.Cts */]) ? ".d.cts" /* Extension.Dcts */ :
            (0, ts_js_1.fileExtensionIsOneOf)(path, [".json" /* Extension.Json */]) ? `.d.json.ts` : // Drive-by redefinition of json declaration file output name so if it's ever enabled, it behaves well
                ".d.ts" /* Extension.Dts */;
}
/**
 * This function is an inverse of `getDeclarationEmitExtensionForPath`.
 *
 * @internal
 */
function getPossibleOriginalInputExtensionForExtension(path) {
    return (0, ts_js_1.fileExtensionIsOneOf)(path, [".d.mts" /* Extension.Dmts */, ".mjs" /* Extension.Mjs */, ".mts" /* Extension.Mts */]) ? [".mts" /* Extension.Mts */, ".mjs" /* Extension.Mjs */] :
        (0, ts_js_1.fileExtensionIsOneOf)(path, [".d.cts" /* Extension.Dcts */, ".cjs" /* Extension.Cjs */, ".cts" /* Extension.Cts */]) ? [".cts" /* Extension.Cts */, ".cjs" /* Extension.Cjs */] :
            (0, ts_js_1.fileExtensionIsOneOf)(path, [`.d.json.ts`]) ? [".json" /* Extension.Json */] :
                [".tsx" /* Extension.Tsx */, ".ts" /* Extension.Ts */, ".jsx" /* Extension.Jsx */, ".js" /* Extension.Js */];
}
/** @internal */
function getPossibleOriginalInputPathWithoutChangingExt(filePath, ignoreCase, outputDir, getCommonSourceDirectory) {
    return outputDir ?
        (0, ts_js_1.resolvePath)(getCommonSourceDirectory(), (0, ts_js_1.getRelativePathFromDirectory)(outputDir, filePath, ignoreCase)) :
        filePath;
}
/**
 * Returns 'undefined' if and only if 'options.paths' is undefined.
 *
 * @internal
 */
function getPathsBasePath(options, host) {
    if (!options.paths)
        return undefined;
    return options.baseUrl ?? ts_js_1.Debug.checkDefined(options.pathsBasePath || host.getCurrentDirectory?.(), "Encountered 'paths' without a 'baseUrl', config file, or host 'getCurrentDirectory'.");
}
/**
 * Gets the source files that are expected to have an emit output.
 *
 * Originally part of `forEachExpectedEmitFile`, this functionality was extracted to support
 * transformations.
 *
 * @param host An EmitHost.
 * @param targetSourceFile An optional target source file to emit.
 *
 * @internal
 */
function getSourceFilesToEmit(host, targetSourceFile, forceDtsEmit) {
    const options = host.getCompilerOptions();
    if (options.outFile) {
        const moduleKind = (0, exports.getEmitModuleKind)(options);
        const moduleEmitEnabled = options.emitDeclarationOnly || moduleKind === ts_js_1.ModuleKind.AMD || moduleKind === ts_js_1.ModuleKind.System;
        // Can emit only sources that are not declaration file and are either non module code or module with --module or --target es6 specified
        return (0, ts_js_1.filter)(host.getSourceFiles(), sourceFile => (moduleEmitEnabled || !(0, ts_js_1.isExternalModule)(sourceFile)) &&
            sourceFileMayBeEmitted(sourceFile, host, forceDtsEmit));
    }
    else {
        const sourceFiles = targetSourceFile === undefined ? host.getSourceFiles() : [targetSourceFile];
        return (0, ts_js_1.filter)(sourceFiles, sourceFile => sourceFileMayBeEmitted(sourceFile, host, forceDtsEmit));
    }
}
/**
 * Don't call this for `--outFile`, just for `--outDir` or plain emit. `--outFile` needs additional checks.
 *
 * @internal
 */
function sourceFileMayBeEmitted(sourceFile, host, forceDtsEmit) {
    const options = host.getCompilerOptions();
    // Js files are emitted only if option is enabled
    if (options.noEmitForJsFiles && isSourceFileJS(sourceFile))
        return false;
    // Declaration files are not emitted
    if (sourceFile.isDeclarationFile)
        return false;
    // Source file from node_modules are not emitted
    if (host.isSourceFileFromExternalLibrary(sourceFile))
        return false;
    // forcing dts emit => file needs to be emitted
    if (forceDtsEmit)
        return true;
    // Check other conditions for file emit
    // Source files from referenced projects are not emitted
    if (host.isSourceOfProjectReferenceRedirect(sourceFile.fileName))
        return false;
    // Any non json file should be emitted
    if (!isJsonSourceFile(sourceFile))
        return true;
    if (host.getRedirectFromSourceFile(sourceFile.fileName))
        return false;
    // Emit json file if outFile is specified
    if (options.outFile)
        return true;
    // Json file is not emitted if outDir is not specified
    if (!options.outDir)
        return false;
    // Otherwise if rootDir or composite config file, we know common sourceDir and can check if file would be emitted in same location
    if (options.rootDir || options.configFilePath) {
        const commonDir = (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getCommonSourceDirectory)(options, () => [], host.getCurrentDirectory(), host.getCanonicalFileName), host.getCurrentDirectory());
        const outputPath = getSourceFilePathInNewDirWorker(sourceFile.fileName, options.outDir, host.getCurrentDirectory(), commonDir, host.getCanonicalFileName);
        if ((0, ts_js_1.comparePaths)(sourceFile.fileName, outputPath, host.getCurrentDirectory(), !host.useCaseSensitiveFileNames()) === 0 /* Comparison.EqualTo */)
            return false;
    }
    return true;
}
/** @internal */
function getSourceFilePathInNewDir(fileName, host, newDirPath) {
    return getSourceFilePathInNewDirWorker(fileName, newDirPath, host.getCurrentDirectory(), host.getCommonSourceDirectory(), f => host.getCanonicalFileName(f));
}
function getSourceFilePathInNewDirWorker(fileName, newDirPath, currentDirectory, commonSourceDirectory, getCanonicalFileName) {
    let sourceFilePath = (0, ts_js_1.getNormalizedAbsolutePath)(fileName, currentDirectory);
    const isSourceFileInCommonSourceDirectory = getCanonicalFileName(sourceFilePath).indexOf(getCanonicalFileName(commonSourceDirectory)) === 0;
    sourceFilePath = isSourceFileInCommonSourceDirectory ? sourceFilePath.substring(commonSourceDirectory.length) : sourceFilePath;
    return (0, ts_js_1.combinePaths)(newDirPath, sourceFilePath);
}
/** @internal */
function writeFile(host, diagnostics, fileName, text, writeByteOrderMark, sourceFiles, data) {
    host.writeFile(fileName, text, writeByteOrderMark, hostErrorMessage => {
        diagnostics.add(createCompilerDiagnostic(ts_js_1.Diagnostics.Could_not_write_file_0_Colon_1, fileName, hostErrorMessage));
    }, sourceFiles, data);
}
function ensureDirectoriesExist(directoryPath, createDirectory, directoryExists) {
    if (directoryPath.length > (0, ts_js_1.getRootLength)(directoryPath) && !directoryExists(directoryPath)) {
        const parentDirectory = (0, ts_js_1.getDirectoryPath)(directoryPath);
        ensureDirectoriesExist(parentDirectory, createDirectory, directoryExists);
        createDirectory(directoryPath);
    }
}
/** @internal */
function writeFileEnsuringDirectories(path, data, writeByteOrderMark, writeFile, createDirectory, directoryExists) {
    // PERF: Checking for directory existence is expensive.  Instead, assume the directory exists
    // and fall back to creating it if the file write fails.
    try {
        writeFile(path, data, writeByteOrderMark);
    }
    catch {
        ensureDirectoriesExist((0, ts_js_1.getDirectoryPath)((0, ts_js_1.normalizePath)(path)), createDirectory, directoryExists);
        writeFile(path, data, writeByteOrderMark);
    }
}
/** @internal */
function getLineOfLocalPosition(sourceFile, pos) {
    const lineStarts = (0, ts_js_1.getLineStarts)(sourceFile);
    return (0, ts_js_1.computeLineOfPosition)(lineStarts, pos);
}
function getLineOfLocalPositionFromLineMap(lineMap, pos) {
    return (0, ts_js_1.computeLineOfPosition)(lineMap, pos);
}
/** @internal */
function getFirstConstructorWithBody(node) {
    return (0, ts_js_1.find)(node.members, (member) => (0, ts_js_1.isConstructorDeclaration)(member) && nodeIsPresent(member.body));
}
/** @internal */
function getSetAccessorValueParameter(accessor) {
    if (accessor && accessor.parameters.length > 0) {
        const hasThis = accessor.parameters.length === 2 && parameterIsThisKeyword(accessor.parameters[0]);
        return accessor.parameters[hasThis ? 1 : 0];
    }
}
/**
 * Get the type annotation for the value parameter.
 *
 * @internal
 */
function getSetAccessorTypeAnnotationNode(accessor) {
    const parameter = getSetAccessorValueParameter(accessor);
    return parameter && parameter.type;
}
/** @internal */
function getThisParameter(signature) {
    // callback tags do not currently support this parameters
    if (signature.parameters.length && !(0, ts_js_1.isJSDocSignature)(signature)) {
        const thisParameter = signature.parameters[0];
        if (parameterIsThisKeyword(thisParameter)) {
            return thisParameter;
        }
    }
}
/** @internal */
function parameterIsThisKeyword(parameter) {
    return isThisIdentifier(parameter.name);
}
/** @internal */
function isThisIdentifier(node) {
    return !!node && node.kind === 80 /* SyntaxKind.Identifier */ && identifierIsThisKeyword(node);
}
/** @internal */
function isInTypeQuery(node) {
    // TypeScript 1.0 spec (April 2014): 3.6.3
    // A type query consists of the keyword typeof followed by an expression.
    // The expression is restricted to a single identifier or a sequence of identifiers separated by periods
    return !!(0, ts_js_1.findAncestor)(node, n => n.kind === 187 /* SyntaxKind.TypeQuery */ ? true : n.kind === 80 /* SyntaxKind.Identifier */ || n.kind === 167 /* SyntaxKind.QualifiedName */ ? false : "quit");
}
/** @internal */
function isThisInTypeQuery(node) {
    if (!isThisIdentifier(node)) {
        return false;
    }
    while ((0, ts_js_1.isQualifiedName)(node.parent) && node.parent.left === node) {
        node = node.parent;
    }
    return node.parent.kind === 187 /* SyntaxKind.TypeQuery */;
}
/** @internal */
function identifierIsThisKeyword(id) {
    return id.escapedText === "this";
}
/** @internal */
function getAllAccessorDeclarations(declarations, accessor) {
    // TODO: GH#18217
    let firstAccessor;
    let secondAccessor;
    let getAccessor;
    let setAccessor;
    if (hasDynamicName(accessor)) {
        firstAccessor = accessor;
        if (accessor.kind === 178 /* SyntaxKind.GetAccessor */) {
            getAccessor = accessor;
        }
        else if (accessor.kind === 179 /* SyntaxKind.SetAccessor */) {
            setAccessor = accessor;
        }
        else {
            ts_js_1.Debug.fail("Accessor has wrong kind");
        }
    }
    else {
        (0, ts_js_1.forEach)(declarations, member => {
            if ((0, ts_js_1.isAccessor)(member)
                && isStatic(member) === isStatic(accessor)) {
                const memberName = getPropertyNameForPropertyNameNode(member.name);
                const accessorName = getPropertyNameForPropertyNameNode(accessor.name);
                if (memberName === accessorName) {
                    if (!firstAccessor) {
                        firstAccessor = member;
                    }
                    else if (!secondAccessor) {
                        secondAccessor = member;
                    }
                    if (member.kind === 178 /* SyntaxKind.GetAccessor */ && !getAccessor) {
                        getAccessor = member;
                    }
                    if (member.kind === 179 /* SyntaxKind.SetAccessor */ && !setAccessor) {
                        setAccessor = member;
                    }
                }
            }
        });
    }
    return {
        firstAccessor,
        secondAccessor,
        getAccessor,
        setAccessor,
    };
}
/**
 * Gets the effective type annotation of a variable, parameter, or property. If the node was
 * parsed in a JavaScript file, gets the type annotation from JSDoc.  Also gets the type of
 * functions only the JSDoc case.
 *
 * @internal
 */
function getEffectiveTypeAnnotationNode(node) {
    if (!isInJSFile(node) && (0, ts_js_1.isFunctionDeclaration)(node))
        return undefined;
    if ((0, ts_js_1.isTypeAliasDeclaration)(node))
        return undefined; // has a .type, is not a type annotation
    const type = node.type;
    if (type || !isInJSFile(node))
        return type;
    return (0, ts_js_1.isJSDocPropertyLikeTag)(node) ? node.typeExpression && node.typeExpression.type : (0, ts_js_1.getJSDocType)(node);
}
/** @internal */
function getTypeAnnotationNode(node) {
    return node.type;
}
/**
 * Gets the effective return type annotation of a signature. If the node was parsed in a
 * JavaScript file, gets the return type annotation from JSDoc.
 *
 * @internal
 */
function getEffectiveReturnTypeNode(node) {
    return (0, ts_js_1.isJSDocSignature)(node) ?
        node.type && node.type.typeExpression && node.type.typeExpression.type :
        node.type || (isInJSFile(node) ? (0, ts_js_1.getJSDocReturnType)(node) : undefined);
}
/** @internal */
function getJSDocTypeParameterDeclarations(node) {
    return (0, ts_js_1.flatMap)((0, ts_js_1.getJSDocTags)(node), tag => isNonTypeAliasTemplate(tag) ? tag.typeParameters : undefined);
}
/** template tags are only available when a typedef isn't already using them */
function isNonTypeAliasTemplate(tag) {
    return (0, ts_js_1.isJSDocTemplateTag)(tag) && !(tag.parent.kind === 321 /* SyntaxKind.JSDoc */ && (tag.parent.tags.some(isJSDocTypeAlias) || tag.parent.tags.some(ts_js_1.isJSDocOverloadTag)));
}
/**
 * Gets the effective type annotation of the value parameter of a set accessor. If the node
 * was parsed in a JavaScript file, gets the type annotation from JSDoc.
 *
 * @internal
 */
function getEffectiveSetAccessorTypeAnnotationNode(node) {
    const parameter = getSetAccessorValueParameter(node);
    return parameter && getEffectiveTypeAnnotationNode(parameter);
}
function emitNewLineBeforeLeadingComments(lineMap, writer, node, leadingComments) {
    emitNewLineBeforeLeadingCommentsOfPosition(lineMap, writer, node.pos, leadingComments);
}
function emitNewLineBeforeLeadingCommentsOfPosition(lineMap, writer, pos, leadingComments) {
    // If the leading comments start on different line than the start of node, write new line
    if (leadingComments && leadingComments.length && pos !== leadingComments[0].pos &&
        getLineOfLocalPositionFromLineMap(lineMap, pos) !== getLineOfLocalPositionFromLineMap(lineMap, leadingComments[0].pos)) {
        writer.writeLine();
    }
}
/** @internal */
function emitNewLineBeforeLeadingCommentOfPosition(lineMap, writer, pos, commentPos) {
    // If the leading comments start on different line than the start of node, write new line
    if (pos !== commentPos &&
        getLineOfLocalPositionFromLineMap(lineMap, pos) !== getLineOfLocalPositionFromLineMap(lineMap, commentPos)) {
        writer.writeLine();
    }
}
function emitComments(text, lineMap, writer, comments, leadingSeparator, trailingSeparator, newLine, writeComment) {
    if (comments && comments.length > 0) {
        if (leadingSeparator) {
            writer.writeSpace(" ");
        }
        let emitInterveningSeparator = false;
        for (const comment of comments) {
            if (emitInterveningSeparator) {
                writer.writeSpace(" ");
                emitInterveningSeparator = false;
            }
            writeComment(text, lineMap, writer, comment.pos, comment.end, newLine);
            if (comment.hasTrailingNewLine) {
                writer.writeLine();
            }
            else {
                emitInterveningSeparator = true;
            }
        }
        if (emitInterveningSeparator && trailingSeparator) {
            writer.writeSpace(" ");
        }
    }
}
/**
 * Detached comment is a comment at the top of file or function body that is separated from
 * the next statement by space.
 *
 * @internal
 */
function emitDetachedComments(text, lineMap, writer, writeComment, node, newLine, removeComments) {
    let leadingComments;
    let currentDetachedCommentInfo;
    if (removeComments) {
        // removeComments is true, only reserve pinned comment at the top of file
        // For example:
        //      /*! Pinned Comment */
        //
        //      var x = 10;
        if (node.pos === 0) {
            leadingComments = (0, ts_js_1.filter)((0, ts_js_1.getLeadingCommentRanges)(text, node.pos), isPinnedCommentLocal);
        }
    }
    else {
        // removeComments is false, just get detached as normal and bypass the process to filter comment
        leadingComments = (0, ts_js_1.getLeadingCommentRanges)(text, node.pos);
    }
    if (leadingComments) {
        const detachedComments = [];
        let lastComment;
        for (const comment of leadingComments) {
            if (lastComment) {
                const lastCommentLine = getLineOfLocalPositionFromLineMap(lineMap, lastComment.end);
                const commentLine = getLineOfLocalPositionFromLineMap(lineMap, comment.pos);
                if (commentLine >= lastCommentLine + 2) {
                    // There was a blank line between the last comment and this comment.  This
                    // comment is not part of the copyright comments.  Return what we have so
                    // far.
                    break;
                }
            }
            detachedComments.push(comment);
            lastComment = comment;
        }
        if (detachedComments.length) {
            // All comments look like they could have been part of the copyright header.  Make
            // sure there is at least one blank line between it and the node.  If not, it's not
            // a copyright header.
            const lastCommentLine = getLineOfLocalPositionFromLineMap(lineMap, (0, ts_js_1.last)(detachedComments).end);
            const nodeLine = getLineOfLocalPositionFromLineMap(lineMap, (0, ts_js_1.skipTrivia)(text, node.pos));
            if (nodeLine >= lastCommentLine + 2) {
                // Valid detachedComments
                emitNewLineBeforeLeadingComments(lineMap, writer, node, leadingComments);
                emitComments(text, lineMap, writer, detachedComments, /*leadingSeparator*/ false, /*trailingSeparator*/ true, newLine, writeComment);
                currentDetachedCommentInfo = { nodePos: node.pos, detachedCommentEndPos: (0, ts_js_1.last)(detachedComments).end };
            }
        }
    }
    return currentDetachedCommentInfo;
    function isPinnedCommentLocal(comment) {
        return isPinnedComment(text, comment.pos);
    }
}
/** @internal */
function writeCommentRange(text, lineMap, writer, commentPos, commentEnd, newLine) {
    if (text.charCodeAt(commentPos + 1) === 42 /* CharacterCodes.asterisk */) {
        const firstCommentLineAndCharacter = (0, ts_js_1.computeLineAndCharacterOfPosition)(lineMap, commentPos);
        const lineCount = lineMap.length;
        let firstCommentLineIndent;
        for (let pos = commentPos, currentLine = firstCommentLineAndCharacter.line; pos < commentEnd; currentLine++) {
            const nextLineStart = (currentLine + 1) === lineCount
                ? text.length + 1
                : lineMap[currentLine + 1];
            if (pos !== commentPos) {
                // If we are not emitting first line, we need to write the spaces to adjust the alignment
                if (firstCommentLineIndent === undefined) {
                    firstCommentLineIndent = calculateIndent(text, lineMap[firstCommentLineAndCharacter.line], commentPos);
                }
                // These are number of spaces writer is going to write at current indent
                const currentWriterIndentSpacing = writer.getIndent() * getIndentSize();
                // Number of spaces we want to be writing
                // eg: Assume writer indent
                // module m {
                //         /* starts at character 9 this is line 1
                //    * starts at character pos 4 line                        --1  = 8 - 8 + 3
                //   More left indented comment */                            --2  = 8 - 8 + 2
                //     class c { }
                // }
                // module m {
                //     /* this is line 1 -- Assume current writer indent 8
                //      * line                                                --3 = 8 - 4 + 5
                //            More right indented comment */                  --4 = 8 - 4 + 11
                //     class c { }
                // }
                const spacesToEmit = currentWriterIndentSpacing - firstCommentLineIndent + calculateIndent(text, pos, nextLineStart);
                if (spacesToEmit > 0) {
                    let numberOfSingleSpacesToEmit = spacesToEmit % getIndentSize();
                    const indentSizeSpaceString = getIndentString((spacesToEmit - numberOfSingleSpacesToEmit) / getIndentSize());
                    // Write indent size string ( in eg 1: = "", 2: "" , 3: string with 8 spaces 4: string with 12 spaces
                    writer.rawWrite(indentSizeSpaceString);
                    // Emit the single spaces (in eg: 1: 3 spaces, 2: 2 spaces, 3: 1 space, 4: 3 spaces)
                    while (numberOfSingleSpacesToEmit) {
                        writer.rawWrite(" ");
                        numberOfSingleSpacesToEmit--;
                    }
                }
                else {
                    // No spaces to emit write empty string
                    writer.rawWrite("");
                }
            }
            // Write the comment line text
            writeTrimmedCurrentLine(text, commentEnd, writer, newLine, pos, nextLineStart);
            pos = nextLineStart;
        }
    }
    else {
        // Single line comment of style //....
        writer.writeComment(text.substring(commentPos, commentEnd));
    }
}
function writeTrimmedCurrentLine(text, commentEnd, writer, newLine, pos, nextLineStart) {
    const end = Math.min(commentEnd, nextLineStart - 1);
    const currentLineText = text.substring(pos, end).trim();
    if (currentLineText) {
        // trimmed forward and ending spaces text
        writer.writeComment(currentLineText);
        if (end !== commentEnd) {
            writer.writeLine();
        }
    }
    else {
        // Empty string - make sure we write empty line
        writer.rawWrite(newLine);
    }
}
function calculateIndent(text, pos, end) {
    let currentLineIndent = 0;
    for (; pos < end && (0, ts_js_1.isWhiteSpaceSingleLine)(text.charCodeAt(pos)); pos++) {
        if (text.charCodeAt(pos) === 9 /* CharacterCodes.tab */) {
            // Tabs = TabSize = indent size and go to next tabStop
            currentLineIndent += getIndentSize() - (currentLineIndent % getIndentSize());
        }
        else {
            // Single space
            currentLineIndent++;
        }
    }
    return currentLineIndent;
}
/** @internal */
function hasEffectiveModifiers(node) {
    return getEffectiveModifierFlags(node) !== 0 /* ModifierFlags.None */;
}
/** @internal */
function hasSyntacticModifiers(node) {
    return getSyntacticModifierFlags(node) !== 0 /* ModifierFlags.None */;
}
/** @internal */
function hasEffectiveModifier(node, flags) {
    return !!getSelectedEffectiveModifierFlags(node, flags);
}
/** @internal */
function hasSyntacticModifier(node, flags) {
    return !!getSelectedSyntacticModifierFlags(node, flags);
}
/** @internal */
function isStatic(node) {
    // https://tc39.es/ecma262/#sec-static-semantics-isstatic
    return (0, ts_js_1.isClassElement)(node) && hasStaticModifier(node) || (0, ts_js_1.isClassStaticBlockDeclaration)(node);
}
/** @internal */
function hasStaticModifier(node) {
    return hasSyntacticModifier(node, 256 /* ModifierFlags.Static */);
}
/** @internal */
function hasOverrideModifier(node) {
    return hasEffectiveModifier(node, 16 /* ModifierFlags.Override */);
}
/** @internal */
function hasAbstractModifier(node) {
    return hasSyntacticModifier(node, 64 /* ModifierFlags.Abstract */);
}
/** @internal */
function hasAmbientModifier(node) {
    return hasSyntacticModifier(node, 128 /* ModifierFlags.Ambient */);
}
/** @internal */
function hasAccessorModifier(node) {
    return hasSyntacticModifier(node, 512 /* ModifierFlags.Accessor */);
}
/** @internal */
function hasEffectiveReadonlyModifier(node) {
    return hasEffectiveModifier(node, 8 /* ModifierFlags.Readonly */);
}
/** @internal */
function hasDecorators(node) {
    return hasSyntacticModifier(node, 32768 /* ModifierFlags.Decorator */);
}
/** @internal */
function getSelectedEffectiveModifierFlags(node, flags) {
    return getEffectiveModifierFlags(node) & flags;
}
/** @internal @knipignore */
function getSelectedSyntacticModifierFlags(node, flags) {
    return getSyntacticModifierFlags(node) & flags;
}
function getModifierFlagsWorker(node, includeJSDoc, alwaysIncludeJSDoc) {
    if (node.kind >= 0 /* SyntaxKind.FirstToken */ && node.kind <= 166 /* SyntaxKind.LastToken */) {
        return 0 /* ModifierFlags.None */;
    }
    if (!(node.modifierFlagsCache & 536870912 /* ModifierFlags.HasComputedFlags */)) {
        node.modifierFlagsCache = getSyntacticModifierFlagsNoCache(node) | 536870912 /* ModifierFlags.HasComputedFlags */;
    }
    if (alwaysIncludeJSDoc || includeJSDoc && isInJSFile(node)) {
        if (!(node.modifierFlagsCache & 268435456 /* ModifierFlags.HasComputedJSDocModifiers */) && node.parent) {
            node.modifierFlagsCache |= getRawJSDocModifierFlagsNoCache(node) | 268435456 /* ModifierFlags.HasComputedJSDocModifiers */;
        }
        return selectEffectiveModifierFlags(node.modifierFlagsCache);
    }
    return selectSyntacticModifierFlags(node.modifierFlagsCache);
}
/**
 * Gets the effective ModifierFlags for the provided node, including JSDoc modifiers. The modifiers will be cached on the node to improve performance.
 *
 * NOTE: This function may use `parent` pointers.
 *
 * @internal
 */
function getEffectiveModifierFlags(node) {
    return getModifierFlagsWorker(node, /*includeJSDoc*/ true);
}
/** @internal */
function getEffectiveModifierFlagsAlwaysIncludeJSDoc(node) {
    return getModifierFlagsWorker(node, /*includeJSDoc*/ true, /*alwaysIncludeJSDoc*/ true);
}
/**
 * Gets the ModifierFlags for syntactic modifiers on the provided node. The modifiers will be cached on the node to improve performance.
 *
 * NOTE: This function does not use `parent` pointers and will not include modifiers from JSDoc.
 *
 * @internal
 */
function getSyntacticModifierFlags(node) {
    return getModifierFlagsWorker(node, /*includeJSDoc*/ false);
}
function getRawJSDocModifierFlagsNoCache(node) {
    let flags = 0 /* ModifierFlags.None */;
    if (!!node.parent && !(0, ts_js_1.isParameter)(node)) {
        if (isInJSFile(node)) {
            if ((0, ts_js_1.getJSDocPublicTagNoCache)(node))
                flags |= 8388608 /* ModifierFlags.JSDocPublic */;
            if ((0, ts_js_1.getJSDocPrivateTagNoCache)(node))
                flags |= 16777216 /* ModifierFlags.JSDocPrivate */;
            if ((0, ts_js_1.getJSDocProtectedTagNoCache)(node))
                flags |= 33554432 /* ModifierFlags.JSDocProtected */;
            if ((0, ts_js_1.getJSDocReadonlyTagNoCache)(node))
                flags |= 67108864 /* ModifierFlags.JSDocReadonly */;
            if ((0, ts_js_1.getJSDocOverrideTagNoCache)(node))
                flags |= 134217728 /* ModifierFlags.JSDocOverride */;
        }
        if ((0, ts_js_1.getJSDocDeprecatedTagNoCache)(node))
            flags |= 65536 /* ModifierFlags.Deprecated */;
    }
    return flags;
}
function selectSyntacticModifierFlags(flags) {
    return flags & 65535 /* ModifierFlags.SyntacticModifiers */;
}
function selectEffectiveModifierFlags(flags) {
    return (flags & 131071 /* ModifierFlags.NonCacheOnlyModifiers */) |
        ((flags & 260046848 /* ModifierFlags.JSDocCacheOnlyModifiers */) >>> 23); // shift ModifierFlags.JSDoc* to match ModifierFlags.*
}
function getJSDocModifierFlagsNoCache(node) {
    return selectEffectiveModifierFlags(getRawJSDocModifierFlagsNoCache(node));
}
/**
 * Gets the effective ModifierFlags for the provided node, including JSDoc modifiers. The modifier flags cache on the node is ignored.
 *
 * NOTE: This function may use `parent` pointers.
 *
 * @internal
 */
function getEffectiveModifierFlagsNoCache(node) {
    return getSyntacticModifierFlagsNoCache(node) | getJSDocModifierFlagsNoCache(node);
}
/**
 * Gets the ModifierFlags for syntactic modifiers on the provided node. The modifier flags cache on the node is ignored.
 *
 * NOTE: This function does not use `parent` pointers and will not include modifiers from JSDoc.
 *
 * @internal
 * @knipignore
 */
function getSyntacticModifierFlagsNoCache(node) {
    let flags = (0, ts_js_1.canHaveModifiers)(node) ? modifiersToFlags(node.modifiers) : 0 /* ModifierFlags.None */;
    if (node.flags & 8 /* NodeFlags.NestedNamespace */ || node.kind === 80 /* SyntaxKind.Identifier */ && node.flags & 4096 /* NodeFlags.IdentifierIsInJSDocNamespace */) {
        flags |= 32 /* ModifierFlags.Export */;
    }
    return flags;
}
/** @internal */
function modifiersToFlags(modifiers) {
    let flags = 0 /* ModifierFlags.None */;
    if (modifiers) {
        for (const modifier of modifiers) {
            flags |= modifierToFlag(modifier.kind);
        }
    }
    return flags;
}
/** @internal */
function modifierToFlag(token) {
    switch (token) {
        case 126 /* SyntaxKind.StaticKeyword */:
            return 256 /* ModifierFlags.Static */;
        case 125 /* SyntaxKind.PublicKeyword */:
            return 1 /* ModifierFlags.Public */;
        case 124 /* SyntaxKind.ProtectedKeyword */:
            return 4 /* ModifierFlags.Protected */;
        case 123 /* SyntaxKind.PrivateKeyword */:
            return 2 /* ModifierFlags.Private */;
        case 128 /* SyntaxKind.AbstractKeyword */:
            return 64 /* ModifierFlags.Abstract */;
        case 129 /* SyntaxKind.AccessorKeyword */:
            return 512 /* ModifierFlags.Accessor */;
        case 95 /* SyntaxKind.ExportKeyword */:
            return 32 /* ModifierFlags.Export */;
        case 138 /* SyntaxKind.DeclareKeyword */:
            return 128 /* ModifierFlags.Ambient */;
        case 87 /* SyntaxKind.ConstKeyword */:
            return 4096 /* ModifierFlags.Const */;
        case 90 /* SyntaxKind.DefaultKeyword */:
            return 2048 /* ModifierFlags.Default */;
        case 134 /* SyntaxKind.AsyncKeyword */:
            return 1024 /* ModifierFlags.Async */;
        case 148 /* SyntaxKind.ReadonlyKeyword */:
            return 8 /* ModifierFlags.Readonly */;
        case 164 /* SyntaxKind.OverrideKeyword */:
            return 16 /* ModifierFlags.Override */;
        case 103 /* SyntaxKind.InKeyword */:
            return 8192 /* ModifierFlags.In */;
        case 147 /* SyntaxKind.OutKeyword */:
            return 16384 /* ModifierFlags.Out */;
        case 171 /* SyntaxKind.Decorator */:
            return 32768 /* ModifierFlags.Decorator */;
    }
    return 0 /* ModifierFlags.None */;
}
/** @internal */
function isBinaryLogicalOperator(token) {
    return token === 57 /* SyntaxKind.BarBarToken */ || token === 56 /* SyntaxKind.AmpersandAmpersandToken */;
}
/** @internal */
function isLogicalOperator(token) {
    return isBinaryLogicalOperator(token) || token === 54 /* SyntaxKind.ExclamationToken */;
}
/** @internal */
function isLogicalOrCoalescingAssignmentOperator(token) {
    return token === 76 /* SyntaxKind.BarBarEqualsToken */
        || token === 77 /* SyntaxKind.AmpersandAmpersandEqualsToken */
        || token === 78 /* SyntaxKind.QuestionQuestionEqualsToken */;
}
/** @internal */
function isLogicalOrCoalescingAssignmentExpression(expr) {
    return (0, ts_js_1.isBinaryExpression)(expr) && isLogicalOrCoalescingAssignmentOperator(expr.operatorToken.kind);
}
/** @internal */
function isLogicalOrCoalescingBinaryOperator(token) {
    return isBinaryLogicalOperator(token) || token === 61 /* SyntaxKind.QuestionQuestionToken */;
}
/** @internal */
function isLogicalOrCoalescingBinaryExpression(expr) {
    return (0, ts_js_1.isBinaryExpression)(expr) && isLogicalOrCoalescingBinaryOperator(expr.operatorToken.kind);
}
/** @internal */
function isAssignmentOperator(token) {
    return token >= 64 /* SyntaxKind.FirstAssignment */ && token <= 79 /* SyntaxKind.LastAssignment */;
}
/**
 * Get `C` given `N` if `N` is in the position `class C extends N` where `N` is an ExpressionWithTypeArguments.
 *
 * @internal
 */
function tryGetClassExtendingExpressionWithTypeArguments(node) {
    const cls = tryGetClassImplementingOrExtendingExpressionWithTypeArguments(node);
    return cls && !cls.isImplements ? cls.class : undefined;
}
/** @internal */
function tryGetClassImplementingOrExtendingExpressionWithTypeArguments(node) {
    if ((0, ts_js_1.isExpressionWithTypeArguments)(node)) {
        if ((0, ts_js_1.isHeritageClause)(node.parent) && (0, ts_js_1.isClassLike)(node.parent.parent)) {
            return { class: node.parent.parent, isImplements: node.parent.token === 119 /* SyntaxKind.ImplementsKeyword */ };
        }
        if ((0, ts_js_1.isJSDocAugmentsTag)(node.parent)) {
            const host = getEffectiveJSDocHost(node.parent);
            if (host && (0, ts_js_1.isClassLike)(host)) {
                return { class: host, isImplements: false };
            }
        }
    }
    return undefined;
}
/** @internal */
function isAssignmentExpression(node, excludeCompoundAssignment) {
    return (0, ts_js_1.isBinaryExpression)(node)
        && (excludeCompoundAssignment
            ? node.operatorToken.kind === 64 /* SyntaxKind.EqualsToken */
            : isAssignmentOperator(node.operatorToken.kind))
        && (0, ts_js_1.isLeftHandSideExpression)(node.left);
}
/** @internal */
function isDestructuringAssignment(node) {
    if (isAssignmentExpression(node, /*excludeCompoundAssignment*/ true)) {
        const kind = node.left.kind;
        return kind === 211 /* SyntaxKind.ObjectLiteralExpression */
            || kind === 210 /* SyntaxKind.ArrayLiteralExpression */;
    }
    return false;
}
/** @internal */
function isExpressionWithTypeArgumentsInClassExtendsClause(node) {
    return tryGetClassExtendingExpressionWithTypeArguments(node) !== undefined;
}
/** @internal */
function isEntityNameExpression(node) {
    return node.kind === 80 /* SyntaxKind.Identifier */ || isPropertyAccessEntityNameExpression(node);
}
/** @internal */
function getFirstIdentifier(node) {
    switch (node.kind) {
        case 80 /* SyntaxKind.Identifier */:
            return node;
        case 167 /* SyntaxKind.QualifiedName */:
            do {
                node = node.left;
            } while (node.kind !== 80 /* SyntaxKind.Identifier */);
            return node;
        case 212 /* SyntaxKind.PropertyAccessExpression */:
            do {
                node = node.expression;
            } while (node.kind !== 80 /* SyntaxKind.Identifier */);
            return node;
    }
}
/** @internal */
function isDottedName(node) {
    return node.kind === 80 /* SyntaxKind.Identifier */
        || node.kind === 110 /* SyntaxKind.ThisKeyword */
        || node.kind === 108 /* SyntaxKind.SuperKeyword */
        || node.kind === 237 /* SyntaxKind.MetaProperty */
        || node.kind === 212 /* SyntaxKind.PropertyAccessExpression */ && isDottedName(node.expression)
        || node.kind === 218 /* SyntaxKind.ParenthesizedExpression */ && isDottedName(node.expression);
}
/** @internal */
function isPropertyAccessEntityNameExpression(node) {
    return (0, ts_js_1.isPropertyAccessExpression)(node) && (0, ts_js_1.isIdentifier)(node.name) && isEntityNameExpression(node.expression);
}
/** @internal */
function tryGetPropertyAccessOrIdentifierToString(expr) {
    if ((0, ts_js_1.isPropertyAccessExpression)(expr)) {
        const baseStr = tryGetPropertyAccessOrIdentifierToString(expr.expression);
        if (baseStr !== undefined) {
            return baseStr + "." + entityNameToString(expr.name);
        }
    }
    else if ((0, ts_js_1.isElementAccessExpression)(expr)) {
        const baseStr = tryGetPropertyAccessOrIdentifierToString(expr.expression);
        if (baseStr !== undefined && (0, ts_js_1.isPropertyName)(expr.argumentExpression)) {
            return baseStr + "." + getPropertyNameForPropertyNameNode(expr.argumentExpression);
        }
    }
    else if ((0, ts_js_1.isIdentifier)(expr)) {
        return (0, ts_js_1.unescapeLeadingUnderscores)(expr.escapedText);
    }
    else if ((0, ts_js_1.isJsxNamespacedName)(expr)) {
        return getTextOfJsxNamespacedName(expr);
    }
    return undefined;
}
/** @internal */
function isPrototypeAccess(node) {
    return isBindableStaticAccessExpression(node) && getElementOrPropertyAccessName(node) === "prototype";
}
/** @internal */
function isRightSideOfQualifiedNameOrPropertyAccess(node) {
    return (node.parent.kind === 167 /* SyntaxKind.QualifiedName */ && node.parent.right === node) ||
        (node.parent.kind === 212 /* SyntaxKind.PropertyAccessExpression */ && node.parent.name === node) ||
        (node.parent.kind === 237 /* SyntaxKind.MetaProperty */ && node.parent.name === node);
}
/** @internal */
function isRightSideOfAccessExpression(node) {
    return !!node.parent && ((0, ts_js_1.isPropertyAccessExpression)(node.parent) && node.parent.name === node
        || (0, ts_js_1.isElementAccessExpression)(node.parent) && node.parent.argumentExpression === node);
}
/** @internal */
function isRightSideOfQualifiedNameOrPropertyAccessOrJSDocMemberName(node) {
    return (0, ts_js_1.isQualifiedName)(node.parent) && node.parent.right === node
        || (0, ts_js_1.isPropertyAccessExpression)(node.parent) && node.parent.name === node
        || (0, ts_js_1.isJSDocMemberName)(node.parent) && node.parent.right === node;
}
/** @internal */
function isInstanceOfExpression(node) {
    return (0, ts_js_1.isBinaryExpression)(node) && node.operatorToken.kind === 104 /* SyntaxKind.InstanceOfKeyword */;
}
/** @internal */
function isRightSideOfInstanceofExpression(node) {
    return isInstanceOfExpression(node.parent) && node === node.parent.right;
}
/** @internal */
function isEmptyObjectLiteral(expression) {
    return expression.kind === 211 /* SyntaxKind.ObjectLiteralExpression */ &&
        expression.properties.length === 0;
}
/** @internal */
function isEmptyArrayLiteral(expression) {
    return expression.kind === 210 /* SyntaxKind.ArrayLiteralExpression */ &&
        expression.elements.length === 0;
}
/** @internal */
function getLocalSymbolForExportDefault(symbol) {
    if (!isExportDefaultSymbol(symbol) || !symbol.declarations)
        return undefined;
    for (const decl of symbol.declarations) {
        if (decl.localSymbol)
            return decl.localSymbol;
    }
    return undefined;
}
function isExportDefaultSymbol(symbol) {
    return symbol && (0, ts_js_1.length)(symbol.declarations) > 0 && hasSyntacticModifier(symbol.declarations[0], 2048 /* ModifierFlags.Default */);
}
/**
 * Return ".ts", ".d.ts", or ".tsx", if that is the extension.
 *
 * @internal
 */
function tryExtractTSExtension(fileName) {
    return (0, ts_js_1.find)(supportedTSExtensionsForExtractExtension, extension => (0, ts_js_1.fileExtensionIs)(fileName, extension));
}
/**
 * Replace each instance of non-ascii characters by one, two, three, or four escape sequences
 * representing the UTF-8 encoding of the character, and return the expanded char code list.
 */
function getExpandedCharCodes(input) {
    const output = [];
    const length = input.length;
    for (let i = 0; i < length; i++) {
        const charCode = input.charCodeAt(i);
        // handle utf8
        if (charCode < 0x80) {
            output.push(charCode);
        }
        else if (charCode < 0x800) {
            output.push((charCode >> 6) | 0B11000000);
            output.push((charCode & 0B00111111) | 0B10000000);
        }
        else if (charCode < 0x10000) {
            output.push((charCode >> 12) | 0B11100000);
            output.push(((charCode >> 6) & 0B00111111) | 0B10000000);
            output.push((charCode & 0B00111111) | 0B10000000);
        }
        else if (charCode < 0x20000) {
            output.push((charCode >> 18) | 0B11110000);
            output.push(((charCode >> 12) & 0B00111111) | 0B10000000);
            output.push(((charCode >> 6) & 0B00111111) | 0B10000000);
            output.push((charCode & 0B00111111) | 0B10000000);
        }
        else {
            ts_js_1.Debug.assert(false, "Unexpected code point");
        }
    }
    return output;
}
const base64Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
/**
 * Converts a string to a base-64 encoded ASCII string.
 *
 * @internal
 */
function convertToBase64(input) {
    let result = "";
    const charCodes = getExpandedCharCodes(input);
    let i = 0;
    const length = charCodes.length;
    let byte1, byte2, byte3, byte4;
    while (i < length) {
        // Convert every 6-bits in the input 3 character points
        // into a base64 digit
        byte1 = charCodes[i] >> 2;
        byte2 = (charCodes[i] & 0B00000011) << 4 | (charCodes[i + 1] ?? 0) >> 4;
        byte3 = ((charCodes[i + 1] ?? 0) & 0B00001111) << 2 | (charCodes[i + 2] ?? 0) >> 6;
        byte4 = (charCodes[i + 2] ?? 0) & 0B00111111;
        // We are out of characters in the input, set the extra
        // digits to 64 (padding character).
        if (i + 1 >= length) {
            byte3 = byte4 = 64;
        }
        else if (i + 2 >= length) {
            byte4 = 64;
        }
        // Write to the output
        result += base64Digits.charAt(byte1) + base64Digits.charAt(byte2) + base64Digits.charAt(byte3) + base64Digits.charAt(byte4);
        i += 3;
    }
    return result;
}
function getStringFromExpandedCharCodes(codes) {
    let output = "";
    let i = 0;
    const length = codes.length;
    while (i < length) {
        const charCode = codes[i];
        if (charCode < 0x80) {
            output += String.fromCharCode(charCode);
            i++;
        }
        else if ((charCode & 0B11000000) === 0B11000000) {
            let value = charCode & 0B00111111;
            i++;
            let nextCode = codes[i];
            while (nextCode !== undefined && (nextCode & 0B11000000) === 0B10000000) {
                value = (value << 6) | (nextCode & 0B00111111);
                i++;
                nextCode = codes[i];
            }
            // `value` may be greater than 10FFFF (the maximum unicode codepoint) - JS will just make this into an invalid character for us
            output += String.fromCharCode(value);
        }
        else {
            // We don't want to kill the process when decoding fails (due to a following char byte not
            // following a leading char), so we just print the (bad) value
            output += String.fromCharCode(charCode);
            i++;
        }
    }
    return output;
}
/** @internal */
function base64encode(host, input) {
    if (host && host.base64encode) {
        return host.base64encode(input);
    }
    return convertToBase64(input);
}
/** @internal */
function base64decode(host, input) {
    if (host && host.base64decode) {
        return host.base64decode(input);
    }
    const length = input.length;
    const expandedCharCodes = [];
    let i = 0;
    while (i < length) {
        // Stop decoding once padding characters are present
        if (input.charCodeAt(i) === base64Digits.charCodeAt(64)) {
            break;
        }
        // convert 4 input digits into three characters, ignoring padding characters at the end
        const ch1 = base64Digits.indexOf(input[i]);
        const ch2 = base64Digits.indexOf(input[i + 1]);
        const ch3 = base64Digits.indexOf(input[i + 2]);
        const ch4 = base64Digits.indexOf(input[i + 3]);
        const code1 = ((ch1 & 0B00111111) << 2) | ((ch2 >> 4) & 0B00000011);
        const code2 = ((ch2 & 0B00001111) << 4) | ((ch3 >> 2) & 0B00001111);
        const code3 = ((ch3 & 0B00000011) << 6) | (ch4 & 0B00111111);
        if (code2 === 0 && ch3 !== 0) { // code2 decoded to zero, but ch3 was padding - elide code2 and code3
            expandedCharCodes.push(code1);
        }
        else if (code3 === 0 && ch4 !== 0) { // code3 decoded to zero, but ch4 was padding, elide code3
            expandedCharCodes.push(code1, code2);
        }
        else {
            expandedCharCodes.push(code1, code2, code3);
        }
        i += 4;
    }
    return getStringFromExpandedCharCodes(expandedCharCodes);
}
/** @internal */
function readJsonOrUndefined(path, hostOrText) {
    const jsonText = (0, ts_js_1.isString)(hostOrText) ? hostOrText : hostOrText.readFile(path);
    if (!jsonText)
        return undefined;
    // Try strictly parsing first, then fall back to our (slower)
    // parser that is resilient to comments/trailing commas.
    // package.json files should never have these, but we
    // have no way to communicate these issues in the first place.
    let result = tryParseJson(jsonText);
    if (result === undefined) {
        const looseResult = (0, ts_js_1.parseConfigFileTextToJson)(path, jsonText);
        if (!looseResult.error) {
            result = looseResult.config;
        }
    }
    return result;
}
/** @internal */
function readJson(path, host) {
    return readJsonOrUndefined(path, host) || {};
}
/** @internal */
function tryParseJson(text) {
    try {
        return JSON.parse(text);
    }
    catch {
        return undefined;
    }
}
/** @internal */
function directoryProbablyExists(directoryName, host) {
    // if host does not support 'directoryExists' assume that directory will exist
    return !host.directoryExists || host.directoryExists(directoryName);
}
const carriageReturnLineFeed = "\r\n";
const lineFeed = "\n";
/** @internal */
function getNewLineCharacter(options) {
    switch (options.newLine) {
        case 0 /* NewLineKind.CarriageReturnLineFeed */:
            return carriageReturnLineFeed;
        case 1 /* NewLineKind.LineFeed */:
        case undefined:
            return lineFeed;
    }
}
/**
 * Creates a new TextRange from the provided pos and end.
 *
 * @param pos The start position.
 * @param end The end position.
 *
 * @internal
 */
function createRange(pos, end = pos) {
    ts_js_1.Debug.assert(end >= pos || end === -1);
    return { pos, end };
}
/**
 * Creates a new TextRange from a provided range with a new end position.
 *
 * @param range A TextRange.
 * @param end The new end position.
 *
 * @internal
 */
function moveRangeEnd(range, end) {
    return createRange(range.pos, end);
}
/**
 * Creates a new TextRange from a provided range with a new start position.
 *
 * @param range A TextRange.
 * @param pos The new Start position.
 *
 * @internal
 */
function moveRangePos(range, pos) {
    return createRange(pos, range.end);
}
/**
 * Moves the start position of a range past any decorators.
 *
 * @internal
 */
function moveRangePastDecorators(node) {
    const lastDecorator = (0, ts_js_1.canHaveModifiers)(node) ? (0, ts_js_1.findLast)(node.modifiers, ts_js_1.isDecorator) : undefined;
    return lastDecorator && !positionIsSynthesized(lastDecorator.end)
        ? moveRangePos(node, lastDecorator.end)
        : node;
}
/**
 * Moves the start position of a range past any decorators or modifiers.
 *
 * @internal
 */
function moveRangePastModifiers(node) {
    if ((0, ts_js_1.isPropertyDeclaration)(node) || (0, ts_js_1.isMethodDeclaration)(node)) {
        return moveRangePos(node, node.name.pos);
    }
    const lastModifier = (0, ts_js_1.canHaveModifiers)(node) ? (0, ts_js_1.lastOrUndefined)(node.modifiers) : undefined;
    return lastModifier && !positionIsSynthesized(lastModifier.end)
        ? moveRangePos(node, lastModifier.end)
        : moveRangePastDecorators(node);
}
/**
 * Creates a new TextRange for a token at the provides start position.
 *
 * @param pos The start position.
 * @param token The token.
 *
 * @internal
 */
function createTokenRange(pos, token) {
    return createRange(pos, pos + (0, ts_js_1.tokenToString)(token).length);
}
/** @internal */
function rangeIsOnSingleLine(range, sourceFile) {
    return rangeStartIsOnSameLineAsRangeEnd(range, range, sourceFile);
}
/** @internal */
function rangeStartPositionsAreOnSameLine(range1, range2, sourceFile) {
    return positionsAreOnSameLine(getStartPositionOfRange(range1, sourceFile, /*includeComments*/ false), getStartPositionOfRange(range2, sourceFile, /*includeComments*/ false), sourceFile);
}
/** @internal */
function rangeEndPositionsAreOnSameLine(range1, range2, sourceFile) {
    return positionsAreOnSameLine(range1.end, range2.end, sourceFile);
}
/** @internal @knipignore */
function rangeStartIsOnSameLineAsRangeEnd(range1, range2, sourceFile) {
    return positionsAreOnSameLine(getStartPositionOfRange(range1, sourceFile, /*includeComments*/ false), range2.end, sourceFile);
}
/** @internal */
function rangeEndIsOnSameLineAsRangeStart(range1, range2, sourceFile) {
    return positionsAreOnSameLine(range1.end, getStartPositionOfRange(range2, sourceFile, /*includeComments*/ false), sourceFile);
}
/** @internal */
function getLinesBetweenRangeEndAndRangeStart(range1, range2, sourceFile, includeSecondRangeComments) {
    const range2Start = getStartPositionOfRange(range2, sourceFile, includeSecondRangeComments);
    return (0, ts_js_1.getLinesBetweenPositions)(sourceFile, range1.end, range2Start);
}
/** @internal @knipignore */
function getLinesBetweenRangeEndPositions(range1, range2, sourceFile) {
    return (0, ts_js_1.getLinesBetweenPositions)(sourceFile, range1.end, range2.end);
}
/** @internal */
function isNodeArrayMultiLine(list, sourceFile) {
    return !positionsAreOnSameLine(list.pos, list.end, sourceFile);
}
/** @internal */
function positionsAreOnSameLine(pos1, pos2, sourceFile) {
    return (0, ts_js_1.getLinesBetweenPositions)(sourceFile, pos1, pos2) === 0;
}
/** @internal @knipignore */
function getStartPositionOfRange(range, sourceFile, includeComments) {
    return positionIsSynthesized(range.pos) ? -1 : (0, ts_js_1.skipTrivia)(sourceFile.text, range.pos, /*stopAfterLineBreak*/ false, includeComments);
}
/** @internal */
function getLinesBetweenPositionAndPrecedingNonWhitespaceCharacter(pos, stopPos, sourceFile, includeComments) {
    const startPos = (0, ts_js_1.skipTrivia)(sourceFile.text, pos, /*stopAfterLineBreak*/ false, includeComments);
    const prevPos = getPreviousNonWhitespacePosition(startPos, stopPos, sourceFile);
    return (0, ts_js_1.getLinesBetweenPositions)(sourceFile, prevPos ?? stopPos, startPos);
}
/** @internal */
function getLinesBetweenPositionAndNextNonWhitespaceCharacter(pos, stopPos, sourceFile, includeComments) {
    const nextPos = (0, ts_js_1.skipTrivia)(sourceFile.text, pos, /*stopAfterLineBreak*/ false, includeComments);
    return (0, ts_js_1.getLinesBetweenPositions)(sourceFile, pos, Math.min(stopPos, nextPos));
}
/** @internal */
function rangeContainsRange(r1, r2) {
    return startEndContainsRange(r1.pos, r1.end, r2);
}
/** @internal */
function startEndContainsRange(start, end, range) {
    return start <= range.pos && end >= range.end;
}
function getPreviousNonWhitespacePosition(pos, stopPos = 0, sourceFile) {
    while (pos-- > stopPos) {
        if (!(0, ts_js_1.isWhiteSpaceLike)(sourceFile.text.charCodeAt(pos))) {
            return pos;
        }
    }
}
/**
 * Determines whether a name was originally the declaration name of an enum or namespace
 * declaration.
 *
 * @internal
 */
function isDeclarationNameOfEnumOrNamespace(node) {
    const parseNode = (0, ts_js_1.getParseTreeNode)(node);
    if (parseNode) {
        switch (parseNode.parent.kind) {
            case 267 /* SyntaxKind.EnumDeclaration */:
            case 268 /* SyntaxKind.ModuleDeclaration */:
                return parseNode === parseNode.parent.name;
        }
    }
    return false;
}
/** @internal */
function getInitializedVariables(node) {
    return (0, ts_js_1.filter)(node.declarations, isInitializedVariable);
}
/** @internal */
function isInitializedVariable(node) {
    return (0, ts_js_1.isVariableDeclaration)(node) && node.initializer !== undefined;
}
/** @internal */
function isWatchSet(options) {
    // Firefox has Object.prototype.watch
    return options.watch && (0, ts_js_1.hasProperty)(options, "watch");
}
/** @internal */
function closeFileWatcher(watcher) {
    watcher.close();
}
/** @internal */
function getCheckFlags(symbol) {
    return symbol.flags & 33554432 /* SymbolFlags.Transient */ ? symbol.links.checkFlags : 0;
}
/** @internal */
function getDeclarationModifierFlagsFromSymbol(s, isWrite = false) {
    if (s.valueDeclaration) {
        const declaration = (isWrite && s.declarations && (0, ts_js_1.find)(s.declarations, ts_js_1.isSetAccessorDeclaration))
            || (s.flags & 32768 /* SymbolFlags.GetAccessor */ && (0, ts_js_1.find)(s.declarations, ts_js_1.isGetAccessorDeclaration)) || s.valueDeclaration;
        const flags = (0, ts_js_1.getCombinedModifierFlags)(declaration);
        return s.parent && s.parent.flags & 32 /* SymbolFlags.Class */ ? flags : flags & ~7 /* ModifierFlags.AccessibilityModifier */;
    }
    if (getCheckFlags(s) & 6 /* CheckFlags.Synthetic */) {
        // NOTE: potentially unchecked cast to TransientSymbol
        const checkFlags = s.links.checkFlags;
        const accessModifier = checkFlags & 1024 /* CheckFlags.ContainsPrivate */ ? 2 /* ModifierFlags.Private */ :
            checkFlags & 256 /* CheckFlags.ContainsPublic */ ? 1 /* ModifierFlags.Public */ :
                4 /* ModifierFlags.Protected */;
        const staticModifier = checkFlags & 2048 /* CheckFlags.ContainsStatic */ ? 256 /* ModifierFlags.Static */ : 0;
        return accessModifier | staticModifier;
    }
    if (s.flags & 4194304 /* SymbolFlags.Prototype */) {
        return 1 /* ModifierFlags.Public */ | 256 /* ModifierFlags.Static */;
    }
    return 0;
}
/** @internal */
function skipAlias(symbol, checker) {
    return symbol.flags & 2097152 /* SymbolFlags.Alias */ ? checker.getAliasedSymbol(symbol) : symbol;
}
/**
 * See comment on `declareModuleMember` in `binder.ts`.
 *
 * @internal
 */
function getCombinedLocalAndExportSymbolFlags(symbol) {
    return symbol.exportSymbol ? symbol.exportSymbol.flags | symbol.flags : symbol.flags;
}
/** @internal */
function isWriteOnlyAccess(node) {
    return accessKind(node) === 1 /* AccessKind.Write */;
}
/** @internal */
function isWriteAccess(node) {
    return accessKind(node) !== 0 /* AccessKind.Read */;
}
var AccessKind;
(function (AccessKind) {
    /** Only reads from a variable. */
    AccessKind[AccessKind["Read"] = 0] = "Read";
    /** Only writes to a variable without ever reading it. E.g.: `x=1;`. */
    AccessKind[AccessKind["Write"] = 1] = "Write";
    /** Reads from and writes to a variable. E.g.: `f(x++);`, `x/=1`. */
    AccessKind[AccessKind["ReadWrite"] = 2] = "ReadWrite";
})(AccessKind || (AccessKind = {}));
function accessKind(node) {
    const { parent } = node;
    switch (parent?.kind) {
        case 218 /* SyntaxKind.ParenthesizedExpression */:
            return accessKind(parent);
        case 226 /* SyntaxKind.PostfixUnaryExpression */:
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
            const { operator } = parent;
            return operator === 46 /* SyntaxKind.PlusPlusToken */ || operator === 47 /* SyntaxKind.MinusMinusToken */ ? 2 /* AccessKind.ReadWrite */ : 0 /* AccessKind.Read */;
        case 227 /* SyntaxKind.BinaryExpression */:
            const { left, operatorToken } = parent;
            return left === node && isAssignmentOperator(operatorToken.kind) ?
                operatorToken.kind === 64 /* SyntaxKind.EqualsToken */ ? 1 /* AccessKind.Write */ : 2 /* AccessKind.ReadWrite */
                : 0 /* AccessKind.Read */;
        case 212 /* SyntaxKind.PropertyAccessExpression */:
            return parent.name !== node ? 0 /* AccessKind.Read */ : accessKind(parent);
        case 304 /* SyntaxKind.PropertyAssignment */: {
            const parentAccess = accessKind(parent.parent);
            // In `({ x: varname }) = { x: 1 }`, the left `x` is a read, the right `x` is a write.
            return node === parent.name ? reverseAccessKind(parentAccess) : parentAccess;
        }
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            // Assume it's the local variable being accessed, since we don't check public properties for --noUnusedLocals.
            return node === parent.objectAssignmentInitializer ? 0 /* AccessKind.Read */ : accessKind(parent.parent);
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
            return accessKind(parent);
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
            return node === parent.initializer ? 1 /* AccessKind.Write */ : 0 /* AccessKind.Read */;
        default:
            return 0 /* AccessKind.Read */;
    }
}
function reverseAccessKind(a) {
    switch (a) {
        case 0 /* AccessKind.Read */:
            return 1 /* AccessKind.Write */;
        case 1 /* AccessKind.Write */:
            return 0 /* AccessKind.Read */;
        case 2 /* AccessKind.ReadWrite */:
            return 2 /* AccessKind.ReadWrite */;
        default:
            return ts_js_1.Debug.assertNever(a);
    }
}
/** @internal */
function compareDataObjects(dst, src) {
    if (!dst || !src || Object.keys(dst).length !== Object.keys(src).length) {
        return false;
    }
    for (const e in dst) {
        if (typeof dst[e] === "object") {
            if (!compareDataObjects(dst[e], src[e])) {
                return false;
            }
        }
        else if (typeof dst[e] !== "function") {
            if (dst[e] !== src[e]) {
                return false;
            }
        }
    }
    return true;
}
/**
 * clears already present map by calling onDeleteExistingValue callback before deleting that key/value
 *
 * @internal
 */
function clearMap(map, onDeleteValue) {
    // Remove all
    map.forEach(onDeleteValue);
    map.clear();
}
function mutateMapSkippingNewValues(map, newMap, options) {
    const { onDeleteValue, onExistingValue } = options;
    // Needs update
    map.forEach((existingValue, key) => {
        // Not present any more in new map, remove it
        if (!newMap?.has(key)) {
            map.delete(key);
            onDeleteValue(existingValue, key);
        }
        // If present notify about existing values
        else if (onExistingValue) {
            onExistingValue(existingValue, newMap.get?.(key), key);
        }
    });
}
function mutateMap(map, newMap, options) {
    // Needs update
    mutateMapSkippingNewValues(map, newMap, options);
    const { createNewValue } = options;
    // Add new values that are not already present
    newMap?.forEach((valueInNewMap, key) => {
        if (!map.has(key)) {
            // New values
            map.set(key, createNewValue(key, valueInNewMap));
        }
    });
}
/** @internal */
function isAbstractConstructorSymbol(symbol) {
    if (symbol.flags & 32 /* SymbolFlags.Class */) {
        const declaration = getClassLikeDeclarationOfSymbol(symbol);
        return !!declaration && hasSyntacticModifier(declaration, 64 /* ModifierFlags.Abstract */);
    }
    return false;
}
/** @internal */
function getClassLikeDeclarationOfSymbol(symbol) {
    return symbol.declarations?.find(ts_js_1.isClassLike);
}
/** @internal */
function getObjectFlags(type) {
    return type.flags & 403963917 /* TypeFlags.ObjectFlagsType */ ? type.objectFlags : 0;
}
/** @internal */
function isUMDExportSymbol(symbol) {
    return !!symbol && !!symbol.declarations && !!symbol.declarations[0] && (0, ts_js_1.isNamespaceExportDeclaration)(symbol.declarations[0]);
}
/** @internal */
function showModuleSpecifier({ moduleSpecifier }) {
    return (0, ts_js_1.isStringLiteral)(moduleSpecifier) ? moduleSpecifier.text : getTextOfNode(moduleSpecifier);
}
/** @internal */
function getLastChild(node) {
    let lastChild;
    (0, ts_js_1.forEachChild)(node, child => {
        if (nodeIsPresent(child))
            lastChild = child;
    }, children => {
        // As an optimization, jump straight to the end of the list.
        for (let i = children.length - 1; i >= 0; i--) {
            if (nodeIsPresent(children[i])) {
                lastChild = children[i];
                break;
            }
        }
    });
    return lastChild;
}
/**
 * Add a value to a set, and return true if it wasn't already present.
 *
 * @internal
 */
function addToSeen(seen, key) {
    if (seen.has(key)) {
        return false;
    }
    seen.add(key);
    return true;
}
/** @internal */
function isObjectTypeDeclaration(node) {
    return (0, ts_js_1.isClassLike)(node) || (0, ts_js_1.isInterfaceDeclaration)(node) || (0, ts_js_1.isTypeLiteralNode)(node);
}
/** @internal */
function isTypeNodeKind(kind) {
    return (kind >= 183 /* SyntaxKind.FirstTypeNode */ && kind <= 206 /* SyntaxKind.LastTypeNode */)
        || kind === 133 /* SyntaxKind.AnyKeyword */
        || kind === 159 /* SyntaxKind.UnknownKeyword */
        || kind === 150 /* SyntaxKind.NumberKeyword */
        || kind === 163 /* SyntaxKind.BigIntKeyword */
        || kind === 151 /* SyntaxKind.ObjectKeyword */
        || kind === 136 /* SyntaxKind.BooleanKeyword */
        || kind === 154 /* SyntaxKind.StringKeyword */
        || kind === 155 /* SyntaxKind.SymbolKeyword */
        || kind === 116 /* SyntaxKind.VoidKeyword */
        || kind === 157 /* SyntaxKind.UndefinedKeyword */
        || kind === 146 /* SyntaxKind.NeverKeyword */
        || kind === 141 /* SyntaxKind.IntrinsicKeyword */
        || kind === 234 /* SyntaxKind.ExpressionWithTypeArguments */
        || kind === 313 /* SyntaxKind.JSDocAllType */
        || kind === 314 /* SyntaxKind.JSDocUnknownType */
        || kind === 315 /* SyntaxKind.JSDocNullableType */
        || kind === 316 /* SyntaxKind.JSDocNonNullableType */
        || kind === 317 /* SyntaxKind.JSDocOptionalType */
        || kind === 318 /* SyntaxKind.JSDocFunctionType */
        || kind === 319 /* SyntaxKind.JSDocVariadicType */;
}
/** @internal */
function isAccessExpression(node) {
    return node.kind === 212 /* SyntaxKind.PropertyAccessExpression */ || node.kind === 213 /* SyntaxKind.ElementAccessExpression */;
}
/** @internal */
function getNameOfAccessExpression(node) {
    if (node.kind === 212 /* SyntaxKind.PropertyAccessExpression */) {
        return node.name;
    }
    ts_js_1.Debug.assert(node.kind === 213 /* SyntaxKind.ElementAccessExpression */);
    return node.argumentExpression;
}
/** @internal */
function isNamedImportsOrExports(node) {
    return node.kind === 276 /* SyntaxKind.NamedImports */ || node.kind === 280 /* SyntaxKind.NamedExports */;
}
/** @internal */
function getLeftmostAccessExpression(expr) {
    while (isAccessExpression(expr)) {
        expr = expr.expression;
    }
    return expr;
}
/** @internal */
function forEachNameInAccessChainWalkingLeft(name, action) {
    if (isAccessExpression(name.parent) && isRightSideOfAccessExpression(name)) {
        return walkAccessExpression(name.parent);
    }
    function walkAccessExpression(access) {
        if (access.kind === 212 /* SyntaxKind.PropertyAccessExpression */) {
            const res = action(access.name);
            if (res !== undefined) {
                return res;
            }
        }
        else if (access.kind === 213 /* SyntaxKind.ElementAccessExpression */) {
            if ((0, ts_js_1.isIdentifier)(access.argumentExpression) || (0, ts_js_1.isStringLiteralLike)(access.argumentExpression)) {
                const res = action(access.argumentExpression);
                if (res !== undefined) {
                    return res;
                }
            }
            else {
                // Chain interrupted by non-static-name access 'x[expr()].y.z'
                return undefined;
            }
        }
        if (isAccessExpression(access.expression)) {
            return walkAccessExpression(access.expression);
        }
        if ((0, ts_js_1.isIdentifier)(access.expression)) {
            // End of chain at Identifier 'x.y.z'
            return action(access.expression);
        }
        // End of chain at non-Identifier 'x().y.z'
        return undefined;
    }
}
/** @internal */
function getLeftmostExpression(node, stopAtCallExpressions) {
    while (true) {
        switch (node.kind) {
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                node = node.operand;
                continue;
            case 227 /* SyntaxKind.BinaryExpression */:
                node = node.left;
                continue;
            case 228 /* SyntaxKind.ConditionalExpression */:
                node = node.condition;
                continue;
            case 216 /* SyntaxKind.TaggedTemplateExpression */:
                node = node.tag;
                continue;
            case 214 /* SyntaxKind.CallExpression */:
                if (stopAtCallExpressions) {
                    return node;
                }
            // falls through
            case 235 /* SyntaxKind.AsExpression */:
            case 213 /* SyntaxKind.ElementAccessExpression */:
            case 212 /* SyntaxKind.PropertyAccessExpression */:
            case 236 /* SyntaxKind.NonNullExpression */:
            case 356 /* SyntaxKind.PartiallyEmittedExpression */:
            case 239 /* SyntaxKind.SatisfiesExpression */:
                node = node.expression;
                continue;
        }
        return node;
    }
}
function Symbol(flags, name) {
    // Note: if modifying this, be sure to update SymbolObject in src/services/services.ts
    this.flags = flags;
    this.escapedName = name;
    this.declarations = undefined;
    this.valueDeclaration = undefined;
    this.id = 0;
    this.mergeId = 0;
    this.parent = undefined;
    this.members = undefined;
    this.exports = undefined;
    this.exportSymbol = undefined;
    this.constEnumOnlyModule = undefined;
    this.isReferenced = undefined;
    this.lastAssignmentPos = undefined;
    this.links = undefined; // used by TransientSymbol
}
function Type(checker, flags) {
    // Note: if modifying this, be sure to update TypeObject in src/services/services.ts
    this.flags = flags;
    if (ts_js_1.Debug.isDebugging || ts_js_1.tracing) {
        this.checker = checker;
    }
}
function Signature(checker, flags) {
    // Note: if modifying this, be sure to update SignatureObject in src/services/services.ts
    this.flags = flags;
    if (ts_js_1.Debug.isDebugging) {
        this.checker = checker;
    }
}
function Node(kind, pos, end) {
    // Note: if modifying this, be sure to update NodeObject in src/services/services.ts
    this.pos = pos;
    this.end = end;
    this.kind = kind;
    this.id = 0;
    this.flags = 0 /* NodeFlags.None */;
    this.modifierFlagsCache = 0 /* ModifierFlags.None */;
    this.transformFlags = 0 /* TransformFlags.None */;
    this.parent = undefined;
    this.original = undefined;
    this.emitNode = undefined;
}
function Token(kind, pos, end) {
    // Note: if modifying this, be sure to update TokenOrIdentifierObject in src/services/services.ts
    this.pos = pos;
    this.end = end;
    this.kind = kind;
    this.id = 0;
    this.flags = 0 /* NodeFlags.None */;
    this.transformFlags = 0 /* TransformFlags.None */;
    this.parent = undefined;
    this.emitNode = undefined;
}
function Identifier(kind, pos, end) {
    // Note: if modifying this, be sure to update TokenOrIdentifierObject in src/services/services.ts
    this.pos = pos;
    this.end = end;
    this.kind = kind;
    this.id = 0;
    this.flags = 0 /* NodeFlags.None */;
    this.transformFlags = 0 /* TransformFlags.None */;
    this.parent = undefined;
    this.original = undefined;
    this.emitNode = undefined;
}
function SourceMapSource(fileName, text, skipTrivia) {
    // Note: if modifying this, be sure to update SourceMapSourceObject in src/services/services.ts
    this.fileName = fileName;
    this.text = text;
    this.skipTrivia = skipTrivia || (pos => pos);
}
/** @internal */
exports.objectAllocator = {
    getNodeConstructor: () => Node,
    getTokenConstructor: () => Token,
    getIdentifierConstructor: () => Identifier,
    getPrivateIdentifierConstructor: () => Node,
    getSourceFileConstructor: () => Node,
    getSymbolConstructor: () => Symbol,
    getTypeConstructor: () => Type,
    getSignatureConstructor: () => Signature,
    getSourceMapSourceConstructor: () => SourceMapSource,
};
const objectAllocatorPatchers = [];
/**
 * Used by `deprecatedCompat` to patch the object allocator to apply deprecations.
 * @internal
 * @knipignore
 */
function addObjectAllocatorPatcher(fn) {
    objectAllocatorPatchers.push(fn);
    fn(exports.objectAllocator);
}
/** @internal */
function setObjectAllocator(alloc) {
    Object.assign(exports.objectAllocator, alloc);
    (0, ts_js_1.forEach)(objectAllocatorPatchers, fn => { fn(exports.objectAllocator); });
}
/** @internal */
function formatStringFromArgs(text, args) {
    return text.replace(/\{(\d+)\}/g, (_match, index) => "" + ts_js_1.Debug.checkDefined(args[+index]));
}
let localizedDiagnosticMessages;
/** @internal */
function setLocalizedDiagnosticMessages(messages) {
    localizedDiagnosticMessages = messages;
}
/** @internal */
// If the localized messages json is unset, and if given function use it to set the json
function maybeSetLocalizedDiagnosticMessages(getMessages) {
    if (!localizedDiagnosticMessages && getMessages) {
        localizedDiagnosticMessages = getMessages();
    }
}
/** @internal */
function getLocaleSpecificMessage(message) {
    return localizedDiagnosticMessages && localizedDiagnosticMessages[message.key] || message.message;
}
/** @internal */
function createDetachedDiagnostic(fileName, sourceText, start, length, message, ...args) {
    if ((start + length) > sourceText.length) {
        length = sourceText.length - start;
    }
    assertDiagnosticLocation(sourceText, start, length);
    let text = getLocaleSpecificMessage(message);
    if ((0, ts_js_1.some)(args)) {
        text = formatStringFromArgs(text, args);
    }
    return {
        file: undefined,
        start,
        length,
        messageText: text,
        category: message.category,
        code: message.code,
        reportsUnnecessary: message.reportsUnnecessary,
        fileName,
    };
}
function isDiagnosticWithDetachedLocation(diagnostic) {
    return diagnostic.file === undefined
        && diagnostic.start !== undefined
        && diagnostic.length !== undefined
        && typeof diagnostic.fileName === "string";
}
function attachFileToDiagnostic(diagnostic, file) {
    const fileName = file.fileName || "";
    const length = file.text.length;
    ts_js_1.Debug.assertEqual(diagnostic.fileName, fileName);
    ts_js_1.Debug.assertLessThanOrEqual(diagnostic.start, length);
    ts_js_1.Debug.assertLessThanOrEqual(diagnostic.start + diagnostic.length, length);
    const diagnosticWithLocation = {
        file,
        start: diagnostic.start,
        length: diagnostic.length,
        messageText: diagnostic.messageText,
        category: diagnostic.category,
        code: diagnostic.code,
        reportsUnnecessary: diagnostic.reportsUnnecessary,
    };
    if (diagnostic.relatedInformation) {
        diagnosticWithLocation.relatedInformation = [];
        for (const related of diagnostic.relatedInformation) {
            if (isDiagnosticWithDetachedLocation(related) && related.fileName === fileName) {
                ts_js_1.Debug.assertLessThanOrEqual(related.start, length);
                ts_js_1.Debug.assertLessThanOrEqual(related.start + related.length, length);
                diagnosticWithLocation.relatedInformation.push(attachFileToDiagnostic(related, file));
            }
            else {
                diagnosticWithLocation.relatedInformation.push(related);
            }
        }
    }
    return diagnosticWithLocation;
}
/** @internal */
function attachFileToDiagnostics(diagnostics, file) {
    const diagnosticsWithLocation = [];
    for (const diagnostic of diagnostics) {
        diagnosticsWithLocation.push(attachFileToDiagnostic(diagnostic, file));
    }
    return diagnosticsWithLocation;
}
/** @internal */
function createFileDiagnostic(file, start, length, message, ...args) {
    assertDiagnosticLocation(file.text, start, length);
    let text = getLocaleSpecificMessage(message);
    if ((0, ts_js_1.some)(args)) {
        text = formatStringFromArgs(text, args);
    }
    return {
        file,
        start,
        length,
        messageText: text,
        category: message.category,
        code: message.code,
        reportsUnnecessary: message.reportsUnnecessary,
        reportsDeprecated: message.reportsDeprecated,
    };
}
/** @internal */
function formatMessage(message, ...args) {
    let text = getLocaleSpecificMessage(message);
    if ((0, ts_js_1.some)(args)) {
        text = formatStringFromArgs(text, args);
    }
    return text;
}
/** @internal */
function createCompilerDiagnostic(message, ...args) {
    let text = getLocaleSpecificMessage(message);
    if ((0, ts_js_1.some)(args)) {
        text = formatStringFromArgs(text, args);
    }
    return {
        file: undefined,
        start: undefined,
        length: undefined,
        messageText: text,
        category: message.category,
        code: message.code,
        reportsUnnecessary: message.reportsUnnecessary,
        reportsDeprecated: message.reportsDeprecated,
    };
}
/** @internal */
function createCompilerDiagnosticFromMessageChain(chain, relatedInformation) {
    return {
        file: undefined,
        start: undefined,
        length: undefined,
        code: chain.code,
        category: chain.category,
        messageText: chain.next ? chain : chain.messageText,
        relatedInformation,
    };
}
/** @internal */
function chainDiagnosticMessages(details, message, ...args) {
    let text = getLocaleSpecificMessage(message);
    if ((0, ts_js_1.some)(args)) {
        text = formatStringFromArgs(text, args);
    }
    return {
        messageText: text,
        category: message.category,
        code: message.code,
        next: details === undefined || Array.isArray(details) ? details : [details],
    };
}
/** @internal */
function concatenateDiagnosticMessageChains(headChain, tailChain) {
    let lastChain = headChain;
    while (lastChain.next) {
        lastChain = lastChain.next[0];
    }
    lastChain.next = [tailChain];
}
function getDiagnosticFilePath(diagnostic) {
    return diagnostic.file ? diagnostic.file.path : undefined;
}
/** @internal */
function compareDiagnostics(d1, d2) {
    return compareDiagnosticsSkipRelatedInformation(d1, d2) ||
        compareRelatedInformation(d1, d2) ||
        0 /* Comparison.EqualTo */;
}
function compareDiagnosticsSkipRelatedInformation(d1, d2) {
    const code1 = getDiagnosticCode(d1);
    const code2 = getDiagnosticCode(d2);
    return (0, ts_js_1.compareStringsCaseSensitive)(getDiagnosticFilePath(d1), getDiagnosticFilePath(d2)) ||
        (0, ts_js_1.compareValues)(d1.start, d2.start) ||
        (0, ts_js_1.compareValues)(d1.length, d2.length) ||
        (0, ts_js_1.compareValues)(code1, code2) ||
        compareMessageText(d1, d2) ||
        0 /* Comparison.EqualTo */;
}
// A diagnostic with more elaboration should be considered *less than* a diagnostic
// with less elaboration that is otherwise similar.
function compareRelatedInformation(d1, d2) {
    if (!d1.relatedInformation && !d2.relatedInformation) {
        return 0 /* Comparison.EqualTo */;
    }
    if (d1.relatedInformation && d2.relatedInformation) {
        return (0, ts_js_1.compareValues)(d2.relatedInformation.length, d1.relatedInformation.length) || (0, ts_js_1.forEach)(d1.relatedInformation, (d1i, index) => {
            const d2i = d2.relatedInformation[index];
            return compareDiagnostics(d1i, d2i); // EqualTo is 0, so falsy, and will cause the next item to be compared
        }) || 0 /* Comparison.EqualTo */;
    }
    return d1.relatedInformation ? -1 /* Comparison.LessThan */ : 1 /* Comparison.GreaterThan */;
}
// An diagnostic message with more elaboration should be considered *less than* a diagnostic message
// with less elaboration that is otherwise similar.
function compareMessageText(d1, d2) {
    let headMsg1 = getDiagnosticMessage(d1);
    let headMsg2 = getDiagnosticMessage(d2);
    if (typeof headMsg1 !== "string") {
        headMsg1 = headMsg1.messageText;
    }
    if (typeof headMsg2 !== "string") {
        headMsg2 = headMsg2.messageText;
    }
    const chain1 = typeof d1.messageText !== "string" ? d1.messageText.next : undefined;
    const chain2 = typeof d2.messageText !== "string" ? d2.messageText.next : undefined;
    let res = (0, ts_js_1.compareStringsCaseSensitive)(headMsg1, headMsg2);
    if (res) {
        return res;
    }
    res = compareMessageChain(chain1, chain2);
    if (res) {
        return res;
    }
    if (d1.canonicalHead && !d2.canonicalHead) {
        return -1 /* Comparison.LessThan */;
    }
    if (d2.canonicalHead && !d1.canonicalHead) {
        return 1 /* Comparison.GreaterThan */;
    }
    return 0 /* Comparison.EqualTo */;
}
// First compare by size of the message chain,
// then compare by content of the message chain.
function compareMessageChain(c1, c2) {
    if (c1 === undefined && c2 === undefined) {
        return 0 /* Comparison.EqualTo */;
    }
    if (c1 === undefined) {
        return 1 /* Comparison.GreaterThan */;
    }
    if (c2 === undefined) {
        return -1 /* Comparison.LessThan */;
    }
    return compareMessageChainSize(c1, c2) || compareMessageChainContent(c1, c2);
}
function compareMessageChainSize(c1, c2) {
    if (c1 === undefined && c2 === undefined) {
        return 0 /* Comparison.EqualTo */;
    }
    if (c1 === undefined) {
        return 1 /* Comparison.GreaterThan */;
    }
    if (c2 === undefined) {
        return -1 /* Comparison.LessThan */;
    }
    let res = (0, ts_js_1.compareValues)(c2.length, c1.length);
    if (res) {
        return res;
    }
    for (let i = 0; i < c2.length; i++) {
        res = compareMessageChainSize(c1[i].next, c2[i].next);
        if (res) {
            return res;
        }
    }
    return 0 /* Comparison.EqualTo */;
}
// Assumes the two chains have the same shape.
function compareMessageChainContent(c1, c2) {
    let res;
    for (let i = 0; i < c2.length; i++) {
        res = (0, ts_js_1.compareStringsCaseSensitive)(c1[i].messageText, c2[i].messageText);
        if (res) {
            return res;
        }
        if (c1[i].next === undefined) {
            continue;
        }
        res = compareMessageChainContent(c1[i].next, c2[i].next);
        if (res) {
            return res;
        }
    }
    return 0 /* Comparison.EqualTo */;
}
/** @internal */
function diagnosticsEqualityComparer(d1, d2) {
    const code1 = getDiagnosticCode(d1);
    const code2 = getDiagnosticCode(d2);
    const msg1 = getDiagnosticMessage(d1);
    const msg2 = getDiagnosticMessage(d2);
    return (0, ts_js_1.compareStringsCaseSensitive)(getDiagnosticFilePath(d1), getDiagnosticFilePath(d2)) === 0 /* Comparison.EqualTo */ &&
        (0, ts_js_1.compareValues)(d1.start, d2.start) === 0 /* Comparison.EqualTo */ &&
        (0, ts_js_1.compareValues)(d1.length, d2.length) === 0 /* Comparison.EqualTo */ &&
        (0, ts_js_1.compareValues)(code1, code2) === 0 /* Comparison.EqualTo */ &&
        messageTextEqualityComparer(msg1, msg2);
}
function getDiagnosticCode(d) {
    return d.canonicalHead?.code || d.code;
}
function getDiagnosticMessage(d) {
    return d.canonicalHead?.messageText || d.messageText;
}
function messageTextEqualityComparer(m1, m2) {
    const t1 = typeof m1 === "string" ? m1 : m1.messageText;
    const t2 = typeof m2 === "string" ? m2 : m2.messageText;
    return (0, ts_js_1.compareStringsCaseSensitive)(t1, t2) === 0 /* Comparison.EqualTo */;
}
/** @internal */
function getLanguageVariant(scriptKind) {
    // .tsx and .jsx files are treated as jsx language variant.
    return scriptKind === 4 /* ScriptKind.TSX */ || scriptKind === 2 /* ScriptKind.JSX */ || scriptKind === 1 /* ScriptKind.JS */ || scriptKind === 6 /* ScriptKind.JSON */ ? 1 /* LanguageVariant.JSX */ : 0 /* LanguageVariant.Standard */;
}
/**
 * This is a somewhat unavoidable full tree walk to locate a JSX tag - `import.meta` requires the same,
 * but we avoid that walk (or parts of it) if at all possible using the `PossiblyContainsImportMeta` node flag.
 * Unfortunately, there's no `NodeFlag` space to do the same for JSX.
 */
function walkTreeForJSXTags(node) {
    if (!(node.transformFlags & 2 /* TransformFlags.ContainsJsx */))
        return undefined;
    return (0, ts_js_1.isJsxOpeningLikeElement)(node) || (0, ts_js_1.isJsxFragment)(node) ? node : (0, ts_js_1.forEachChild)(node, walkTreeForJSXTags);
}
function isFileModuleFromUsingJSXTag(file) {
    // Excludes declaration files - they still require an explicit `export {}` or the like
    // for back compat purposes. (not that declaration files should contain JSX tags!)
    return !file.isDeclarationFile ? walkTreeForJSXTags(file) : undefined;
}
/**
 * Note that this requires file.impliedNodeFormat be set already; meaning it must be set very early on
 * in SourceFile construction.
 */
function isFileForcedToBeModuleByFormat(file, options) {
    // Excludes declaration files - they still require an explicit `export {}` or the like
    // for back compat purposes. The only non-declaration files _not_ forced to be a module are `.js` files
    // that aren't esm-mode (meaning not in a `type: module` scope).
    return ((0, ts_js_1.getImpliedNodeFormatForEmitWorker)(file, options) === ts_js_1.ModuleKind.ESNext || ((0, ts_js_1.fileExtensionIsOneOf)(file.fileName, [".cjs" /* Extension.Cjs */, ".cts" /* Extension.Cts */, ".mjs" /* Extension.Mjs */, ".mts" /* Extension.Mts */]))) && !file.isDeclarationFile ? true : undefined;
}
/** @internal */
function getSetExternalModuleIndicator(options) {
    // TODO: Should this callback be cached?
    switch ((0, exports.getEmitModuleDetectionKind)(options)) {
        case ts_js_1.ModuleDetectionKind.Force:
            // All non-declaration files are modules, declaration files still do the usual isFileProbablyExternalModule
            return (file) => {
                file.externalModuleIndicator = (0, ts_js_1.isFileProbablyExternalModule)(file) || !file.isDeclarationFile || undefined;
            };
        case ts_js_1.ModuleDetectionKind.Legacy:
            // Files are modules if they have imports, exports, or import.meta
            return (file) => {
                file.externalModuleIndicator = (0, ts_js_1.isFileProbablyExternalModule)(file);
            };
        case ts_js_1.ModuleDetectionKind.Auto:
            // If module is nodenext or node16, all esm format files are modules
            // If jsx is react-jsx or react-jsxdev then jsx tags force module-ness
            // otherwise, the presence of import or export statments (or import.meta) implies module-ness
            const checks = [ts_js_1.isFileProbablyExternalModule];
            if (options.jsx === 4 /* JsxEmit.ReactJSX */ || options.jsx === 5 /* JsxEmit.ReactJSXDev */) {
                checks.push(isFileModuleFromUsingJSXTag);
            }
            checks.push(isFileForcedToBeModuleByFormat);
            const combined = (0, ts_js_1.or)(...checks);
            const callback = (file) => void (file.externalModuleIndicator = combined(file, options));
            return callback;
    }
}
/**
 * @internal
 * Returns true if an `import` and a `require` of the same module specifier
 * can resolve to a different file.
 */
function importSyntaxAffectsModuleResolution(options) {
    const moduleResolution = (0, exports.getEmitModuleResolutionKind)(options);
    return ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext
        || (0, exports.getResolvePackageJsonExports)(options)
        || (0, exports.getResolvePackageJsonImports)(options);
}
/**
 * @internal
 * Returns true if this option's types array includes "*"
 */
function usesWildcardTypes(options) {
    return (0, ts_js_1.some)(options.types, t => t === "*");
}
function createComputedCompilerOptions(options) {
    return options;
}
const _computedOptions = createComputedCompilerOptions({
    allowImportingTsExtensions: {
        dependencies: ["rewriteRelativeImportExtensions"],
        computeValue: compilerOptions => {
            return !!(compilerOptions.allowImportingTsExtensions || compilerOptions.rewriteRelativeImportExtensions);
        },
    },
    target: {
        dependencies: [],
        computeValue: compilerOptions => {
            const target = compilerOptions.target === 0 /* ScriptTarget.ES3 */ ? undefined : compilerOptions.target;
            return target ?? 12 /* ScriptTarget.LatestStandard */;
        },
    },
    module: {
        dependencies: ["target"],
        computeValue: (compilerOptions) => {
            if (typeof compilerOptions.module === "number") {
                return compilerOptions.module;
            }
            const target = _computedOptions.target.computeValue(compilerOptions);
            if (target === 99 /* ScriptTarget.ESNext */) {
                return ts_js_1.ModuleKind.ESNext;
            }
            if (target >= 9 /* ScriptTarget.ES2022 */) {
                return ts_js_1.ModuleKind.ES2022;
            }
            if (target >= 7 /* ScriptTarget.ES2020 */) {
                return ts_js_1.ModuleKind.ES2020;
            }
            if (target >= 2 /* ScriptTarget.ES2015 */) {
                return ts_js_1.ModuleKind.ES2015;
            }
            return ts_js_1.ModuleKind.CommonJS;
        },
    },
    moduleResolution: {
        dependencies: ["module", "target"],
        computeValue: (compilerOptions) => {
            if (compilerOptions.moduleResolution !== undefined) {
                return compilerOptions.moduleResolution;
            }
            const moduleKind = _computedOptions.module.computeValue(compilerOptions);
            switch (moduleKind) {
                case ts_js_1.ModuleKind.None:
                case ts_js_1.ModuleKind.AMD:
                case ts_js_1.ModuleKind.UMD:
                case ts_js_1.ModuleKind.System:
                    return ts_js_1.ModuleResolutionKind.Classic;
                case ts_js_1.ModuleKind.NodeNext:
                    return ts_js_1.ModuleResolutionKind.NodeNext;
            }
            if (ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind < ts_js_1.ModuleKind.NodeNext) {
                return ts_js_1.ModuleResolutionKind.Node16;
            }
            return ts_js_1.ModuleResolutionKind.Bundler;
        },
    },
    moduleDetection: {
        dependencies: ["module", "target"],
        computeValue: (compilerOptions) => {
            if (compilerOptions.moduleDetection !== undefined) {
                return compilerOptions.moduleDetection;
            }
            const moduleKind = _computedOptions.module.computeValue(compilerOptions);
            return ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext
                ? ts_js_1.ModuleDetectionKind.Force
                : ts_js_1.ModuleDetectionKind.Auto;
        },
    },
    isolatedModules: {
        dependencies: ["verbatimModuleSyntax"],
        computeValue: compilerOptions => {
            return !!(compilerOptions.isolatedModules || compilerOptions.verbatimModuleSyntax);
        },
    },
    esModuleInterop: {
        dependencies: [],
        computeValue: (compilerOptions) => {
            if (compilerOptions.esModuleInterop !== undefined) {
                return compilerOptions.esModuleInterop;
            }
            return true;
        },
    },
    allowSyntheticDefaultImports: {
        dependencies: [],
        computeValue: (compilerOptions) => {
            if (compilerOptions.allowSyntheticDefaultImports !== undefined) {
                return compilerOptions.allowSyntheticDefaultImports;
            }
            return true;
        },
    },
    resolvePackageJsonExports: {
        dependencies: ["moduleResolution", "module", "target"],
        computeValue: (compilerOptions) => {
            const moduleResolution = _computedOptions.moduleResolution.computeValue(compilerOptions);
            if (!moduleResolutionSupportsPackageJsonExportsAndImports(moduleResolution)) {
                return false;
            }
            if (compilerOptions.resolvePackageJsonExports !== undefined) {
                return compilerOptions.resolvePackageJsonExports;
            }
            switch (moduleResolution) {
                case ts_js_1.ModuleResolutionKind.Node16:
                case ts_js_1.ModuleResolutionKind.NodeNext:
                case ts_js_1.ModuleResolutionKind.Bundler:
                    return true;
            }
            return false;
        },
    },
    resolvePackageJsonImports: {
        dependencies: ["moduleResolution", "resolvePackageJsonExports", "module", "target"],
        computeValue: (compilerOptions) => {
            const moduleResolution = _computedOptions.moduleResolution.computeValue(compilerOptions);
            if (!moduleResolutionSupportsPackageJsonExportsAndImports(moduleResolution)) {
                return false;
            }
            if (compilerOptions.resolvePackageJsonImports !== undefined) {
                return compilerOptions.resolvePackageJsonImports;
            }
            switch (moduleResolution) {
                case ts_js_1.ModuleResolutionKind.Node16:
                case ts_js_1.ModuleResolutionKind.NodeNext:
                case ts_js_1.ModuleResolutionKind.Bundler:
                    return true;
            }
            return false;
        },
    },
    resolveJsonModule: {
        dependencies: ["moduleResolution", "module", "target"],
        computeValue: (compilerOptions) => {
            if (compilerOptions.resolveJsonModule !== undefined) {
                return compilerOptions.resolveJsonModule;
            }
            switch (_computedOptions.module.computeValue(compilerOptions)) {
                // TODO in 6.0: uncomment
                // case ModuleKind.Node16:
                // case ModuleKind.Node18:
                case ts_js_1.ModuleKind.Node20:
                case ts_js_1.ModuleKind.NodeNext:
                    return true;
            }
            return _computedOptions.moduleResolution.computeValue(compilerOptions) === ts_js_1.ModuleResolutionKind.Bundler;
        },
    },
    declaration: {
        dependencies: ["composite"],
        computeValue: compilerOptions => {
            return !!(compilerOptions.declaration || compilerOptions.composite);
        },
    },
    preserveConstEnums: {
        dependencies: ["isolatedModules", "verbatimModuleSyntax"],
        computeValue: (compilerOptions) => {
            return !!(compilerOptions.preserveConstEnums || _computedOptions.isolatedModules.computeValue(compilerOptions));
        },
    },
    incremental: {
        dependencies: ["composite"],
        computeValue: compilerOptions => {
            return !!(compilerOptions.incremental || compilerOptions.composite);
        },
    },
    declarationMap: {
        dependencies: ["declaration", "composite"],
        computeValue: (compilerOptions) => {
            return !!(compilerOptions.declarationMap && _computedOptions.declaration.computeValue(compilerOptions));
        },
    },
    allowJs: {
        dependencies: ["checkJs"],
        computeValue: compilerOptions => {
            return compilerOptions.allowJs === undefined ? !!compilerOptions.checkJs : compilerOptions.allowJs;
        },
    },
    useDefineForClassFields: {
        dependencies: ["target", "module"],
        computeValue: (compilerOptions) => {
            return compilerOptions.useDefineForClassFields === undefined
                ? _computedOptions.target.computeValue(compilerOptions) >= 9 /* ScriptTarget.ES2022 */
                : compilerOptions.useDefineForClassFields;
        },
    },
    noImplicitAny: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "noImplicitAny");
        },
    },
    noImplicitThis: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "noImplicitThis");
        },
    },
    strictNullChecks: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "strictNullChecks");
        },
    },
    strictFunctionTypes: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "strictFunctionTypes");
        },
    },
    strictBindCallApply: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "strictBindCallApply");
        },
    },
    strictPropertyInitialization: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "strictPropertyInitialization");
        },
    },
    strictBuiltinIteratorReturn: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "strictBuiltinIteratorReturn");
        },
    },
    // Previously a strict-mode flag, but no longer.
    alwaysStrict: {
        dependencies: [],
        computeValue: compilerOptions => {
            return compilerOptions.alwaysStrict !== false;
        },
    },
    useUnknownInCatchVariables: {
        dependencies: ["strict"],
        computeValue: compilerOptions => {
            return getStrictOptionValue(compilerOptions, "useUnknownInCatchVariables");
        },
    },
});
/** @internal */
exports.computedOptions = _computedOptions;
/** @internal */
exports.getAllowImportingTsExtensions = _computedOptions.allowImportingTsExtensions.computeValue;
/** @internal */
exports.getEmitScriptTarget = _computedOptions.target.computeValue;
/** @internal */
exports.getEmitModuleKind = _computedOptions.module.computeValue;
/** @internal */
exports.getEmitModuleResolutionKind = _computedOptions.moduleResolution.computeValue;
/** @internal @knipignore */
exports.getEmitModuleDetectionKind = _computedOptions.moduleDetection.computeValue;
/** @internal */
exports.getIsolatedModules = _computedOptions.isolatedModules.computeValue;
/** @internal */
exports.getESModuleInterop = _computedOptions.esModuleInterop.computeValue;
/** @internal */
exports.getAllowSyntheticDefaultImports = _computedOptions.allowSyntheticDefaultImports.computeValue;
/** @internal */
exports.getResolvePackageJsonExports = _computedOptions.resolvePackageJsonExports.computeValue;
/** @internal */
exports.getResolvePackageJsonImports = _computedOptions.resolvePackageJsonImports.computeValue;
/** @internal */
exports.getResolveJsonModule = _computedOptions.resolveJsonModule.computeValue;
/** @internal */
exports.getEmitDeclarations = _computedOptions.declaration.computeValue;
/** @internal */
exports.shouldPreserveConstEnums = _computedOptions.preserveConstEnums.computeValue;
/** @internal */
exports.isIncrementalCompilation = _computedOptions.incremental.computeValue;
/** @internal */
exports.getAreDeclarationMapsEnabled = _computedOptions.declarationMap.computeValue;
/** @internal */
exports.getAllowJSCompilerOption = _computedOptions.allowJs.computeValue;
/** @internal */
exports.getUseDefineForClassFields = _computedOptions.useDefineForClassFields.computeValue;
/** @internal */
exports.getAlwaysStrict = _computedOptions.alwaysStrict.computeValue;
/** @internal */
function emitModuleKindIsNonNodeESM(moduleKind) {
    return moduleKind >= ts_js_1.ModuleKind.ES2015 && moduleKind <= ts_js_1.ModuleKind.ESNext;
}
/** @internal */
function hasJsonModuleEmitEnabled(options) {
    switch ((0, exports.getEmitModuleKind)(options)) {
        case ts_js_1.ModuleKind.None:
        case ts_js_1.ModuleKind.System:
        case ts_js_1.ModuleKind.UMD:
            return false;
    }
    return true;
}
/** @internal */
function moduleResolutionSupportsPackageJsonExportsAndImports(moduleResolution) {
    return moduleResolution >= ts_js_1.ModuleResolutionKind.Node16 && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext
        || moduleResolution === ts_js_1.ModuleResolutionKind.Bundler;
}
/**
 * @internal
 * The same set of options also support import assertions.
 */
function moduleSupportsImportAttributes(moduleKind) {
    return ts_js_1.ModuleKind.Node18 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext
        || moduleKind === ts_js_1.ModuleKind.Preserve
        || moduleKind === ts_js_1.ModuleKind.ESNext;
}
/** @internal */
function getStrictOptionValue(compilerOptions, flag) {
    return compilerOptions[flag] === undefined ? (compilerOptions.strict !== false) : !!compilerOptions[flag];
}
/** @internal */
function getNameOfScriptTarget(scriptTarget) {
    return forEachEntry(ts_js_1.targetOptionDeclaration.type, (value, key) => value === scriptTarget ? key : undefined);
}
/** @internal */
function getEmitStandardClassFields(compilerOptions) {
    return compilerOptions.useDefineForClassFields !== false && (0, exports.getEmitScriptTarget)(compilerOptions) >= 9 /* ScriptTarget.ES2022 */;
}
/** @internal */
function compilerOptionsAffectSemanticDiagnostics(newOptions, oldOptions) {
    return optionsHaveChanges(oldOptions, newOptions, ts_js_1.semanticDiagnosticsOptionDeclarations);
}
/** @internal */
function compilerOptionsAffectEmit(newOptions, oldOptions) {
    return optionsHaveChanges(oldOptions, newOptions, ts_js_1.affectsEmitOptionDeclarations);
}
/** @internal */
function compilerOptionsAffectDeclarationPath(newOptions, oldOptions) {
    return optionsHaveChanges(oldOptions, newOptions, ts_js_1.affectsDeclarationPathOptionDeclarations);
}
/** @internal */
function getCompilerOptionValue(options, option) {
    return option.strictFlag ? getStrictOptionValue(options, option.name) :
        option.allowJsFlag ? (0, exports.getAllowJSCompilerOption)(options) :
            options[option.name];
}
/** @internal */
function getJSXTransformEnabled(options) {
    const jsx = options.jsx;
    return jsx === 2 /* JsxEmit.React */ || jsx === 4 /* JsxEmit.ReactJSX */ || jsx === 5 /* JsxEmit.ReactJSXDev */;
}
/** @internal */
function getJSXImplicitImportBase(compilerOptions, file) {
    const jsxImportSourcePragmas = file?.pragmas.get("jsximportsource");
    const jsxImportSourcePragma = (0, ts_js_1.isArray)(jsxImportSourcePragmas) ? jsxImportSourcePragmas[jsxImportSourcePragmas.length - 1] : jsxImportSourcePragmas;
    const jsxRuntimePragmas = file?.pragmas.get("jsxruntime");
    const jsxRuntimePragma = (0, ts_js_1.isArray)(jsxRuntimePragmas) ? jsxRuntimePragmas[jsxRuntimePragmas.length - 1] : jsxRuntimePragmas;
    if (jsxRuntimePragma?.arguments.factory === "classic") {
        return undefined;
    }
    return compilerOptions.jsx === 4 /* JsxEmit.ReactJSX */ ||
        compilerOptions.jsx === 5 /* JsxEmit.ReactJSXDev */ ||
        compilerOptions.jsxImportSource ||
        jsxImportSourcePragma ||
        jsxRuntimePragma?.arguments.factory === "automatic" ?
        jsxImportSourcePragma?.arguments.factory || compilerOptions.jsxImportSource || "react" :
        undefined;
}
/** @internal */
function getJSXRuntimeImport(base, options) {
    return base ? `${base}/${options.jsx === 5 /* JsxEmit.ReactJSXDev */ ? "jsx-dev-runtime" : "jsx-runtime"}` : undefined;
}
/** @internal */
function hasZeroOrOneAsteriskCharacter(str) {
    let seenAsterisk = false;
    for (let i = 0; i < str.length; i++) {
        if (str.charCodeAt(i) === 42 /* CharacterCodes.asterisk */) {
            if (!seenAsterisk) {
                seenAsterisk = true;
            }
            else {
                // have already seen asterisk
                return false;
            }
        }
    }
    return true;
}
/** @internal */
function createSymlinkCache(cwd, getCanonicalFileName) {
    let symlinkedDirectories;
    let symlinkedDirectoriesByRealpath;
    let symlinkedFiles;
    let hasProcessedResolutions = false;
    return {
        getSymlinkedFiles: () => symlinkedFiles,
        getSymlinkedDirectories: () => symlinkedDirectories,
        getSymlinkedDirectoriesByRealpath: () => symlinkedDirectoriesByRealpath,
        setSymlinkedFile: (path, real) => (symlinkedFiles || (symlinkedFiles = new Map())).set(path, real),
        setSymlinkedDirectory: (symlink, real) => {
            // Large, interconnected dependency graphs in pnpm will have a huge number of symlinks
            // where both the realpath and the symlink path are inside node_modules/.pnpm. Since
            // this path is never a candidate for a module specifier, we can ignore it entirely.
            let symlinkPath = (0, ts_js_1.toPath)(symlink, cwd, getCanonicalFileName);
            if (!containsIgnoredPath(symlinkPath)) {
                symlinkPath = (0, ts_js_1.ensureTrailingDirectorySeparator)(symlinkPath);
                if (real !== false && !symlinkedDirectories?.has(symlinkPath)) {
                    (0, ts_js_1.multiMapAddValue)((symlinkedDirectoriesByRealpath || (symlinkedDirectoriesByRealpath = (0, ts_js_1.createMultiMap)())), real.realPath, symlink);
                }
                (symlinkedDirectories || (symlinkedDirectories = new Map())).set(symlinkPath, real);
            }
        },
        setSymlinksFromResolutions(forEachResolvedModule, forEachResolvedTypeReferenceDirective, typeReferenceDirectives) {
            ts_js_1.Debug.assert(!hasProcessedResolutions);
            hasProcessedResolutions = true;
            forEachResolvedModule(resolution => processResolution(this, resolution.resolvedModule));
            forEachResolvedTypeReferenceDirective(resolution => processResolution(this, resolution.resolvedTypeReferenceDirective));
            typeReferenceDirectives.forEach(resolution => processResolution(this, resolution.resolvedTypeReferenceDirective));
        },
        hasProcessedResolutions: () => hasProcessedResolutions,
        setSymlinksFromResolution(resolution) {
            processResolution(this, resolution);
        },
        hasAnySymlinks,
    };
    function hasAnySymlinks() {
        return !!symlinkedFiles?.size || (!!symlinkedDirectories && !!forEachEntry(symlinkedDirectories, value => !!value));
    }
    function processResolution(cache, resolution) {
        if (!resolution || !resolution.originalPath || !resolution.resolvedFileName)
            return;
        const { resolvedFileName, originalPath } = resolution;
        cache.setSymlinkedFile((0, ts_js_1.toPath)(originalPath, cwd, getCanonicalFileName), resolvedFileName);
        const [commonResolved, commonOriginal] = guessDirectorySymlink(resolvedFileName, originalPath, cwd, getCanonicalFileName) || ts_js_1.emptyArray;
        if (commonResolved && commonOriginal) {
            cache.setSymlinkedDirectory(commonOriginal, {
                real: (0, ts_js_1.ensureTrailingDirectorySeparator)(commonResolved),
                realPath: (0, ts_js_1.ensureTrailingDirectorySeparator)((0, ts_js_1.toPath)(commonResolved, cwd, getCanonicalFileName)),
            });
        }
    }
}
function guessDirectorySymlink(a, b, cwd, getCanonicalFileName) {
    const aParts = (0, ts_js_1.getPathComponents)((0, ts_js_1.getNormalizedAbsolutePath)(a, cwd));
    const bParts = (0, ts_js_1.getPathComponents)((0, ts_js_1.getNormalizedAbsolutePath)(b, cwd));
    let isDirectory = false;
    while (aParts.length >= 2 && bParts.length >= 2 &&
        !isNodeModulesOrScopedPackageDirectory(aParts[aParts.length - 2], getCanonicalFileName) &&
        !isNodeModulesOrScopedPackageDirectory(bParts[bParts.length - 2], getCanonicalFileName) &&
        getCanonicalFileName(aParts[aParts.length - 1]) === getCanonicalFileName(bParts[bParts.length - 1])) {
        aParts.pop();
        bParts.pop();
        isDirectory = true;
    }
    return isDirectory ? [(0, ts_js_1.getPathFromPathComponents)(aParts), (0, ts_js_1.getPathFromPathComponents)(bParts)] : undefined;
}
// KLUDGE: Don't assume one 'node_modules' links to another. More likely a single directory inside the node_modules is the symlink.
// ALso, don't assume that an `@foo` directory is linked. More likely the contents of that are linked.
function isNodeModulesOrScopedPackageDirectory(s, getCanonicalFileName) {
    return s !== undefined && (getCanonicalFileName(s) === "node_modules" || (0, ts_js_1.startsWith)(s, "@"));
}
function stripLeadingDirectorySeparator(s) {
    return (0, ts_js_1.isAnyDirectorySeparator)(s.charCodeAt(0)) ? s.slice(1) : undefined;
}
/** @internal */
function tryRemoveDirectoryPrefix(path, dirPath, getCanonicalFileName) {
    const withoutPrefix = (0, ts_js_1.tryRemovePrefix)(path, dirPath, getCanonicalFileName);
    return withoutPrefix === undefined ? undefined : stripLeadingDirectorySeparator(withoutPrefix);
}
// Reserved characters, forces escaping of any non-word (or digit), non-whitespace character.
// It may be inefficient (we could just match (/[-[\]{}()*+?.,\\^$|#\s]/g), but this is future
// proof.
const reservedCharacterPattern = /[^\w\s/]/g;
/** @internal */
function regExpEscape(text) {
    return text.replace(reservedCharacterPattern, escapeRegExpCharacter);
}
function escapeRegExpCharacter(match) {
    return "\\" + match;
}
const wildcardCharCodes = [42 /* CharacterCodes.asterisk */, 63 /* CharacterCodes.question */];
const commonPackageFolders = ["node_modules", "bower_components", "jspm_packages"];
const implicitExcludePathRegexPattern = `(?!(?:${commonPackageFolders.join("|")})(?:/|$))`;
const filesMatcher = {
    /**
     * Matches any single directory segment unless it is the last segment and a .min.js file
     * Breakdown:
     *  [^./]                   # matches everything up to the first . character (excluding directory separators)
     *  (\\.(?!min\\.js$))?     # matches . characters but not if they are part of the .min.js file extension
     */
    singleAsteriskRegexFragment: "(?:[^./]|(?:\\.(?!min\\.js$))?)*",
    /**
     * Regex for the ** wildcard. Matches any number of subdirectories. When used for including
     * files or directories, does not match subdirectories that start with a . character
     */
    doubleAsteriskRegexFragment: `(?:/${implicitExcludePathRegexPattern}[^/.][^/]*)*?`,
    replaceWildcardCharacter: match => replaceWildcardCharacter(match, filesMatcher.singleAsteriskRegexFragment),
};
const directoriesMatcher = {
    singleAsteriskRegexFragment: "[^/]*",
    /**
     * Regex for the ** wildcard. Matches any number of subdirectories. When used for including
     * files or directories, does not match subdirectories that start with a . character
     */
    doubleAsteriskRegexFragment: `(?:/${implicitExcludePathRegexPattern}[^/.][^/]*)*?`,
    replaceWildcardCharacter: match => replaceWildcardCharacter(match, directoriesMatcher.singleAsteriskRegexFragment),
};
const excludeMatcher = {
    singleAsteriskRegexFragment: "[^/]*",
    doubleAsteriskRegexFragment: "(?:/.+?)?",
    replaceWildcardCharacter: match => replaceWildcardCharacter(match, excludeMatcher.singleAsteriskRegexFragment),
};
const wildcardMatchers = {
    files: filesMatcher,
    directories: directoriesMatcher,
    exclude: excludeMatcher,
};
/** @internal */
function getRegularExpressionForWildcard(specs, basePath, usage) {
    const patterns = getRegularExpressionsForWildcards(specs, basePath, usage);
    if (!patterns || !patterns.length) {
        return undefined;
    }
    const pattern = patterns.map(pattern => `(?:${pattern})`).join("|");
    // If excluding, match "foo/bar/baz...", but if including, only allow "foo".
    const terminator = usage === "exclude" ? "(?:$|/)" : "$";
    return `^(?:${pattern})${terminator}`;
}
/** @internal */
function getRegularExpressionsForWildcards(specs, basePath, usage) {
    if (specs === undefined || specs.length === 0) {
        return undefined;
    }
    return (0, ts_js_1.flatMap)(specs, spec => spec && getSubPatternFromSpec(spec, basePath, usage, wildcardMatchers[usage]));
}
/**
 * An "includes" path "foo" is implicitly a glob "foo/** /*" (without the space) if its last component has no extension,
 * and does not contain any glob characters itself.
 *
 * @internal
 */
function isImplicitGlob(lastPathComponent) {
    return !/[.*?]/.test(lastPathComponent);
}
/** @internal */
function getPatternFromSpec(spec, basePath, usage) {
    const pattern = spec && getSubPatternFromSpec(spec, basePath, usage, wildcardMatchers[usage]);
    return pattern && `^(?:${pattern})${usage === "exclude" ? "(?:$|/)" : "$"}`;
}
/** @internal */
function getSubPatternFromSpec(spec, basePath, usage, { singleAsteriskRegexFragment, doubleAsteriskRegexFragment, replaceWildcardCharacter } = wildcardMatchers[usage]) {
    let subpattern = "";
    let hasWrittenComponent = false;
    const components = (0, ts_js_1.getNormalizedPathComponents)(spec, basePath);
    const lastComponent = (0, ts_js_1.last)(components);
    if (usage !== "exclude" && lastComponent === "**") {
        return undefined;
    }
    // getNormalizedPathComponents includes the separator for the root component.
    // We need to remove to create our regex correctly.
    components[0] = (0, ts_js_1.removeTrailingDirectorySeparator)(components[0]);
    if (isImplicitGlob(lastComponent)) {
        components.push("**", "*");
    }
    let optionalCount = 0;
    for (let component of components) {
        if (component === "**") {
            subpattern += doubleAsteriskRegexFragment;
        }
        else {
            if (usage === "directories") {
                subpattern += "(?:";
                optionalCount++;
            }
            if (hasWrittenComponent) {
                subpattern += ts_js_1.directorySeparator;
            }
            if (usage !== "exclude") {
                let componentPattern = "";
                // The * and ? wildcards should not match directories or files that start with . if they
                // appear first in a component. Dotted directories and files can be included explicitly
                // like so: **/.*/.*
                if (component.charCodeAt(0) === 42 /* CharacterCodes.asterisk */) {
                    componentPattern += "(?:[^./]" + singleAsteriskRegexFragment + ")?";
                    component = component.substr(1);
                }
                else if (component.charCodeAt(0) === 63 /* CharacterCodes.question */) {
                    componentPattern += "[^./]";
                    component = component.substr(1);
                }
                componentPattern += component.replace(reservedCharacterPattern, replaceWildcardCharacter);
                // Patterns should not include subfolders like node_modules unless they are
                // explicitly included as part of the path.
                //
                // As an optimization, if the component pattern is the same as the component,
                // then there definitely were no wildcard characters and we do not need to
                // add the exclusion pattern.
                if (componentPattern !== component) {
                    subpattern += implicitExcludePathRegexPattern;
                }
                subpattern += componentPattern;
            }
            else {
                subpattern += component.replace(reservedCharacterPattern, replaceWildcardCharacter);
            }
        }
        hasWrittenComponent = true;
    }
    while (optionalCount > 0) {
        subpattern += ")?";
        optionalCount--;
    }
    return subpattern;
}
function replaceWildcardCharacter(match, singleAsteriskRegexFragment) {
    return match === "*" ? singleAsteriskRegexFragment : match === "?" ? "[^/]" : "\\" + match;
}
/**
 * @param path directory of the tsconfig.json
 *
 * @internal
 */
function getFileMatcherPatterns(path, excludes, includes, useCaseSensitiveFileNames, currentDirectory) {
    path = (0, ts_js_1.normalizePath)(path);
    currentDirectory = (0, ts_js_1.normalizePath)(currentDirectory);
    const absolutePath = (0, ts_js_1.combinePaths)(currentDirectory, path);
    return {
        includeFilePatterns: (0, ts_js_1.map)(getRegularExpressionsForWildcards(includes, absolutePath, "files"), pattern => `^${pattern}$`),
        includeFilePattern: getRegularExpressionForWildcard(includes, absolutePath, "files"),
        includeDirectoryPattern: getRegularExpressionForWildcard(includes, absolutePath, "directories"),
        excludePattern: getRegularExpressionForWildcard(excludes, absolutePath, "exclude"),
        basePaths: getBasePaths(path, includes, useCaseSensitiveFileNames),
    };
}
/** @internal */
function getRegexFromPattern(pattern, useCaseSensitiveFileNames) {
    return new RegExp(pattern, useCaseSensitiveFileNames ? "" : "i");
}
/**
 * @param path directory of the tsconfig.json
 *
 * @internal
 */
function matchFiles(path, extensions, excludes, includes, useCaseSensitiveFileNames, currentDirectory, depth, getFileSystemEntries, realpath) {
    path = (0, ts_js_1.normalizePath)(path);
    currentDirectory = (0, ts_js_1.normalizePath)(currentDirectory);
    const patterns = getFileMatcherPatterns(path, excludes, includes, useCaseSensitiveFileNames, currentDirectory);
    const includeFileRegexes = patterns.includeFilePatterns && patterns.includeFilePatterns.map(pattern => getRegexFromPattern(pattern, useCaseSensitiveFileNames));
    const includeDirectoryRegex = patterns.includeDirectoryPattern && getRegexFromPattern(patterns.includeDirectoryPattern, useCaseSensitiveFileNames);
    const excludeRegex = patterns.excludePattern && getRegexFromPattern(patterns.excludePattern, useCaseSensitiveFileNames);
    // Associate an array of results with each include regex. This keeps results in order of the "include" order.
    // If there are no "includes", then just put everything in results[0].
    const results = includeFileRegexes ? includeFileRegexes.map(() => []) : [[]];
    const visited = new Map();
    const toCanonical = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    for (const basePath of patterns.basePaths) {
        visitDirectory(basePath, (0, ts_js_1.combinePaths)(currentDirectory, basePath), depth);
    }
    return (0, ts_js_1.flatten)(results);
    function visitDirectory(path, absolutePath, depth) {
        const canonicalPath = toCanonical(realpath(absolutePath));
        if (visited.has(canonicalPath))
            return;
        visited.set(canonicalPath, true);
        const { files, directories } = getFileSystemEntries(path);
        for (const current of (0, ts_js_1.toSorted)(files, ts_js_1.compareStringsCaseSensitive)) {
            const name = (0, ts_js_1.combinePaths)(path, current);
            const absoluteName = (0, ts_js_1.combinePaths)(absolutePath, current);
            if (extensions && !(0, ts_js_1.fileExtensionIsOneOf)(name, extensions))
                continue;
            if (excludeRegex && excludeRegex.test(absoluteName))
                continue;
            if (!includeFileRegexes) {
                results[0].push(name);
            }
            else {
                const includeIndex = (0, ts_js_1.findIndex)(includeFileRegexes, re => re.test(absoluteName));
                if (includeIndex !== -1) {
                    results[includeIndex].push(name);
                }
            }
        }
        if (depth !== undefined) {
            depth--;
            if (depth === 0) {
                return;
            }
        }
        for (const current of (0, ts_js_1.toSorted)(directories, ts_js_1.compareStringsCaseSensitive)) {
            const name = (0, ts_js_1.combinePaths)(path, current);
            const absoluteName = (0, ts_js_1.combinePaths)(absolutePath, current);
            if ((!includeDirectoryRegex || includeDirectoryRegex.test(absoluteName)) &&
                (!excludeRegex || !excludeRegex.test(absoluteName))) {
                visitDirectory(name, absoluteName, depth);
            }
        }
    }
}
/**
 * Computes the unique non-wildcard base paths amongst the provided include patterns.
 */
function getBasePaths(path, includes, useCaseSensitiveFileNames) {
    // Storage for our results in the form of literal paths (e.g. the paths as written by the user).
    const basePaths = [path];
    if (includes) {
        // Storage for literal base paths amongst the include patterns.
        const includeBasePaths = [];
        for (const include of includes) {
            // We also need to check the relative paths by converting them to absolute and normalizing
            // in case they escape the base path (e.g "..\somedirectory")
            const absolute = (0, ts_js_1.isRootedDiskPath)(include) ? include : (0, ts_js_1.normalizePath)((0, ts_js_1.combinePaths)(path, include));
            // Append the literal and canonical candidate base paths.
            includeBasePaths.push(getIncludeBasePath(absolute));
        }
        // Sort the offsets array using either the literal or canonical path representations.
        includeBasePaths.sort((0, ts_js_1.getStringComparer)(!useCaseSensitiveFileNames));
        // Iterate over each include base path and include unique base paths that are not a
        // subpath of an existing base path
        for (const includeBasePath of includeBasePaths) {
            if ((0, ts_js_1.every)(basePaths, basePath => !(0, ts_js_1.containsPath)(basePath, includeBasePath, path, !useCaseSensitiveFileNames))) {
                basePaths.push(includeBasePath);
            }
        }
    }
    return basePaths;
}
function getIncludeBasePath(absolute) {
    const wildcardOffset = (0, ts_js_1.indexOfAnyCharCode)(absolute, wildcardCharCodes);
    if (wildcardOffset < 0) {
        // No "*" or "?" in the path
        return !(0, ts_js_1.hasExtension)(absolute)
            ? absolute
            : (0, ts_js_1.removeTrailingDirectorySeparator)((0, ts_js_1.getDirectoryPath)(absolute));
    }
    return absolute.substring(0, absolute.lastIndexOf(ts_js_1.directorySeparator, wildcardOffset));
}
/** @internal */
function ensureScriptKind(fileName, scriptKind) {
    // Using scriptKind as a condition handles both:
    // - 'scriptKind' is unspecified and thus it is `undefined`
    // - 'scriptKind' is set and it is `Unknown` (0)
    // If the 'scriptKind' is 'undefined' or 'Unknown' then we attempt
    // to get the ScriptKind from the file name. If it cannot be resolved
    // from the file name then the default 'TS' script kind is returned.
    return scriptKind || getScriptKindFromFileName(fileName) || 3 /* ScriptKind.TS */;
}
/** @internal */
function getScriptKindFromFileName(fileName) {
    const ext = fileName.substr(fileName.lastIndexOf("."));
    switch (ext.toLowerCase()) {
        case ".js" /* Extension.Js */:
        case ".cjs" /* Extension.Cjs */:
        case ".mjs" /* Extension.Mjs */:
            return 1 /* ScriptKind.JS */;
        case ".jsx" /* Extension.Jsx */:
            return 2 /* ScriptKind.JSX */;
        case ".ts" /* Extension.Ts */:
        case ".cts" /* Extension.Cts */:
        case ".mts" /* Extension.Mts */:
            return 3 /* ScriptKind.TS */;
        case ".tsx" /* Extension.Tsx */:
            return 4 /* ScriptKind.TSX */;
        case ".json" /* Extension.Json */:
            return 6 /* ScriptKind.JSON */;
        default:
            return 0 /* ScriptKind.Unknown */;
    }
}
/**
 *  Groups of supported extensions in order of file resolution precedence. (eg, TS > TSX > DTS and seperately, CTS > DCTS)
 */
const supportedTSExtensions = [[".ts" /* Extension.Ts */, ".tsx" /* Extension.Tsx */, ".d.ts" /* Extension.Dts */], [".cts" /* Extension.Cts */, ".d.cts" /* Extension.Dcts */], [".mts" /* Extension.Mts */, ".d.mts" /* Extension.Dmts */]];
/** @internal */
exports.supportedTSExtensionsFlat = (0, ts_js_1.flatten)(supportedTSExtensions);
const supportedTSExtensionsWithJson = [...supportedTSExtensions, [".json" /* Extension.Json */]];
/** Must have ".d.ts" first because if ".ts" goes first, that will be detected as the extension instead of ".d.ts". */
const supportedTSExtensionsForExtractExtension = [".d.ts" /* Extension.Dts */, ".d.cts" /* Extension.Dcts */, ".d.mts" /* Extension.Dmts */, ".cts" /* Extension.Cts */, ".mts" /* Extension.Mts */, ".ts" /* Extension.Ts */, ".tsx" /* Extension.Tsx */];
const supportedJSExtensions = [[".js" /* Extension.Js */, ".jsx" /* Extension.Jsx */], [".mjs" /* Extension.Mjs */], [".cjs" /* Extension.Cjs */]];
/** @internal */
exports.supportedJSExtensionsFlat = (0, ts_js_1.flatten)(supportedJSExtensions);
const allSupportedExtensions = [[".ts" /* Extension.Ts */, ".tsx" /* Extension.Tsx */, ".d.ts" /* Extension.Dts */, ".js" /* Extension.Js */, ".jsx" /* Extension.Jsx */], [".cts" /* Extension.Cts */, ".d.cts" /* Extension.Dcts */, ".cjs" /* Extension.Cjs */], [".mts" /* Extension.Mts */, ".d.mts" /* Extension.Dmts */, ".mjs" /* Extension.Mjs */]];
const allSupportedExtensionsWithJson = [...allSupportedExtensions, [".json" /* Extension.Json */]];
/** @internal */
exports.supportedDeclarationExtensions = [".d.ts" /* Extension.Dts */, ".d.cts" /* Extension.Dcts */, ".d.mts" /* Extension.Dmts */];
/** @internal */
exports.supportedTSImplementationExtensions = [".ts" /* Extension.Ts */, ".cts" /* Extension.Cts */, ".mts" /* Extension.Mts */, ".tsx" /* Extension.Tsx */];
/** @internal */
exports.extensionsNotSupportingExtensionlessResolution = [".mts" /* Extension.Mts */, ".d.mts" /* Extension.Dmts */, ".mjs" /* Extension.Mjs */, ".cts" /* Extension.Cts */, ".d.cts" /* Extension.Dcts */, ".cjs" /* Extension.Cjs */];
/** @internal */
function getSupportedExtensions(options, extraFileExtensions) {
    const needJsExtensions = options && (0, exports.getAllowJSCompilerOption)(options);
    if (!extraFileExtensions || extraFileExtensions.length === 0) {
        return needJsExtensions ? allSupportedExtensions : supportedTSExtensions;
    }
    const builtins = needJsExtensions ? allSupportedExtensions : supportedTSExtensions;
    const flatBuiltins = (0, ts_js_1.flatten)(builtins);
    const extensions = [
        ...builtins,
        ...(0, ts_js_1.mapDefined)(extraFileExtensions, x => x.scriptKind === 7 /* ScriptKind.Deferred */ || needJsExtensions && isJSLike(x.scriptKind) && !flatBuiltins.includes(x.extension) ? [x.extension] : undefined),
    ];
    return extensions;
}
/** @internal */
function getSupportedExtensionsWithJsonIfResolveJsonModule(options, supportedExtensions) {
    if (!options || !(0, exports.getResolveJsonModule)(options))
        return supportedExtensions;
    if (supportedExtensions === allSupportedExtensions)
        return allSupportedExtensionsWithJson;
    if (supportedExtensions === supportedTSExtensions)
        return supportedTSExtensionsWithJson;
    return [...supportedExtensions, [".json" /* Extension.Json */]];
}
function isJSLike(scriptKind) {
    return scriptKind === 1 /* ScriptKind.JS */ || scriptKind === 2 /* ScriptKind.JSX */;
}
/** @internal */
function hasJSFileExtension(fileName) {
    return (0, ts_js_1.some)(exports.supportedJSExtensionsFlat, extension => (0, ts_js_1.fileExtensionIs)(fileName, extension));
}
/** @internal */
function hasTSFileExtension(fileName) {
    return (0, ts_js_1.some)(exports.supportedTSExtensionsFlat, extension => (0, ts_js_1.fileExtensionIs)(fileName, extension));
}
/** @internal */
function hasImplementationTSFileExtension(fileName) {
    return (0, ts_js_1.some)(exports.supportedTSImplementationExtensions, extension => (0, ts_js_1.fileExtensionIs)(fileName, extension))
        && !(0, ts_js_1.isDeclarationFileName)(fileName);
}
/**
 * @internal
 * Corresponds to UserPreferences#importPathEnding
 */
var ModuleSpecifierEnding;
(function (ModuleSpecifierEnding) {
    ModuleSpecifierEnding[ModuleSpecifierEnding["Minimal"] = 0] = "Minimal";
    ModuleSpecifierEnding[ModuleSpecifierEnding["Index"] = 1] = "Index";
    ModuleSpecifierEnding[ModuleSpecifierEnding["JsExtension"] = 2] = "JsExtension";
    ModuleSpecifierEnding[ModuleSpecifierEnding["TsExtension"] = 3] = "TsExtension";
})(ModuleSpecifierEnding || (exports.ModuleSpecifierEnding = ModuleSpecifierEnding = {}));
function usesExtensionsOnImports({ imports }, hasExtension = (0, ts_js_1.or)(hasJSFileExtension, hasTSFileExtension)) {
    return (0, ts_js_1.firstDefined)(imports, ({ text }) => (0, ts_js_1.pathIsRelative)(text) && !(0, ts_js_1.fileExtensionIsOneOf)(text, exports.extensionsNotSupportingExtensionlessResolution)
        ? hasExtension(text)
        : undefined) || false;
}
/** @internal */
function getModuleSpecifierEndingPreference(preference, resolutionMode, compilerOptions, sourceFile) {
    const moduleResolution = (0, exports.getEmitModuleResolutionKind)(compilerOptions);
    const moduleResolutionIsNodeNext = ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext;
    if (preference === "js" || resolutionMode === ts_js_1.ModuleKind.ESNext && moduleResolutionIsNodeNext) {
        // Extensions are explicitly requested or required. Now choose between .js and .ts.
        if (!(0, ts_js_1.shouldAllowImportingTsExtension)(compilerOptions)) {
            return 2 /* ModuleSpecifierEnding.JsExtension */;
        }
        // `allowImportingTsExtensions` is a strong signal, so use .ts unless the file
        // already uses .js extensions and no .ts extensions.
        return inferPreference() !== 2 /* ModuleSpecifierEnding.JsExtension */
            ? 3 /* ModuleSpecifierEnding.TsExtension */
            : 2 /* ModuleSpecifierEnding.JsExtension */;
    }
    if (preference === "minimal") {
        return 0 /* ModuleSpecifierEnding.Minimal */;
    }
    if (preference === "index") {
        return 1 /* ModuleSpecifierEnding.Index */;
    }
    // No preference was specified.
    // Look at imports and/or requires to guess whether .js, .ts, or extensionless imports are preferred.
    // N.B. that `Index` detection is not supported since it would require file system probing to do
    // accurately, and more importantly, literally nobody wants `Index` and its existence is a mystery.
    if (!(0, ts_js_1.shouldAllowImportingTsExtension)(compilerOptions)) {
        // If .ts imports are not valid, we only need to see one .js import to go with that.
        return sourceFile && usesExtensionsOnImports(sourceFile) ? 2 /* ModuleSpecifierEnding.JsExtension */ : 0 /* ModuleSpecifierEnding.Minimal */;
    }
    return inferPreference();
    function inferPreference() {
        let usesJsExtensions = false;
        const specifiers = sourceFile?.imports.length ? sourceFile.imports :
            sourceFile && isSourceFileJS(sourceFile) ? getRequiresAtTopOfFile(sourceFile).map(r => r.arguments[0]) :
                ts_js_1.emptyArray;
        for (const specifier of specifiers) {
            if ((0, ts_js_1.pathIsRelative)(specifier.text)) {
                if (moduleResolutionIsNodeNext &&
                    resolutionMode === ts_js_1.ModuleKind.CommonJS &&
                    (0, ts_js_1.getModeForUsageLocation)(sourceFile, specifier, compilerOptions) === ts_js_1.ModuleKind.ESNext) {
                    // We're trying to decide a preference for a CommonJS module specifier, but looking at an ESM import.
                    continue;
                }
                if ((0, ts_js_1.fileExtensionIsOneOf)(specifier.text, exports.extensionsNotSupportingExtensionlessResolution)) {
                    // These extensions are not optional, so do not indicate a preference.
                    continue;
                }
                if (hasTSFileExtension(specifier.text)) {
                    return 3 /* ModuleSpecifierEnding.TsExtension */;
                }
                if (hasJSFileExtension(specifier.text)) {
                    usesJsExtensions = true;
                }
            }
        }
        return usesJsExtensions ? 2 /* ModuleSpecifierEnding.JsExtension */ : 0 /* ModuleSpecifierEnding.Minimal */;
    }
}
function getRequiresAtTopOfFile(sourceFile) {
    let nonRequireStatementCount = 0;
    let requires;
    for (const statement of sourceFile.statements) {
        if (nonRequireStatementCount > 3) {
            break;
        }
        if (isRequireVariableStatement(statement)) {
            requires = (0, ts_js_1.concatenate)(requires, statement.declarationList.declarations.map(d => d.initializer));
        }
        else if ((0, ts_js_1.isExpressionStatement)(statement) && isRequireCall(statement.expression, /*requireStringLiteralLikeArgument*/ true)) {
            requires = (0, ts_js_1.append)(requires, statement.expression);
        }
        else {
            nonRequireStatementCount++;
        }
    }
    return requires || ts_js_1.emptyArray;
}
/** @internal */
function isSupportedSourceFileName(fileName, compilerOptions, extraFileExtensions) {
    if (!fileName)
        return false;
    const supportedExtensions = getSupportedExtensions(compilerOptions, extraFileExtensions);
    for (const extension of (0, ts_js_1.flatten)(getSupportedExtensionsWithJsonIfResolveJsonModule(compilerOptions, supportedExtensions))) {
        if ((0, ts_js_1.fileExtensionIs)(fileName, extension)) {
            return true;
        }
    }
    return false;
}
function numberOfDirectorySeparators(str) {
    const match = str.match(/\//g);
    return match ? match.length : 0;
}
/** @internal */
function compareNumberOfDirectorySeparators(path1, path2) {
    return (0, ts_js_1.compareValues)(numberOfDirectorySeparators(path1), numberOfDirectorySeparators(path2));
}
const extensionsToRemove = [".d.ts" /* Extension.Dts */, ".d.mts" /* Extension.Dmts */, ".d.cts" /* Extension.Dcts */, ".mjs" /* Extension.Mjs */, ".mts" /* Extension.Mts */, ".cjs" /* Extension.Cjs */, ".cts" /* Extension.Cts */, ".ts" /* Extension.Ts */, ".js" /* Extension.Js */, ".tsx" /* Extension.Tsx */, ".jsx" /* Extension.Jsx */, ".json" /* Extension.Json */];
/** @internal */
function removeFileExtension(path) {
    for (const ext of extensionsToRemove) {
        const extensionless = tryRemoveExtension(path, ext);
        if (extensionless !== undefined) {
            return extensionless;
        }
    }
    return path;
}
/** @internal @knipignore */
function tryRemoveExtension(path, extension) {
    return (0, ts_js_1.fileExtensionIs)(path, extension) ? removeExtension(path, extension) : undefined;
}
/** @internal */
function removeExtension(path, extension) {
    return path.substring(0, path.length - extension.length);
}
/** @internal */
function changeExtension(path, newExtension) {
    return (0, ts_js_1.changeAnyExtension)(path, newExtension, extensionsToRemove, /*ignoreCase*/ false);
}
/**
 * Returns the input if there are no stars, a pattern if there is exactly one,
 * and undefined if there are more.
 *
 * @internal
 */
function tryParsePattern(pattern) {
    const indexOfStar = pattern.indexOf("*");
    if (indexOfStar === -1) {
        return pattern;
    }
    return pattern.indexOf("*", indexOfStar + 1) !== -1
        ? undefined
        : {
            prefix: pattern.substr(0, indexOfStar),
            suffix: pattern.substr(indexOfStar + 1),
        };
}
const parsedPatternsCache = new WeakMap();
/**
 * Divides patterns into a set of exact specifiers and patterns.
 * NOTE that this function caches the result based on object identity.
 *
 * @internal
 */
function tryParsePatterns(paths) {
    let result = parsedPatternsCache.get(paths);
    if (result !== undefined) {
        return result;
    }
    let matchableStringSet;
    let patterns;
    const pathList = (0, ts_js_1.getOwnKeys)(paths);
    for (const path of pathList) {
        const patternOrStr = tryParsePattern(path);
        if (patternOrStr === undefined) {
            continue;
        }
        else if (typeof patternOrStr === "string") {
            (matchableStringSet ?? (matchableStringSet = new Set())).add(patternOrStr);
        }
        else {
            (patterns ?? (patterns = [])).push(patternOrStr);
        }
    }
    parsedPatternsCache.set(paths, result = {
        matchableStringSet,
        patterns,
    });
    return result;
}
/** @internal */
function positionIsSynthesized(pos) {
    // This is a fast way of testing the following conditions:
    //  pos === undefined || pos === null || isNaN(pos) || pos < 0;
    return !(pos >= 0);
}
/**
 * True if an extension is one of the supported TypeScript extensions.
 *
 * @internal
 */
function extensionIsTS(ext) {
    return ext === ".ts" /* Extension.Ts */ || ext === ".tsx" /* Extension.Tsx */ || ext === ".d.ts" /* Extension.Dts */ || ext === ".cts" /* Extension.Cts */ || ext === ".mts" /* Extension.Mts */ || ext === ".d.mts" /* Extension.Dmts */ || ext === ".d.cts" /* Extension.Dcts */ || ((0, ts_js_1.startsWith)(ext, ".d.") && (0, ts_js_1.endsWith)(ext, ".ts"));
}
/** @internal */
function resolutionExtensionIsTSOrJson(ext) {
    return extensionIsTS(ext) || ext === ".json" /* Extension.Json */;
}
/**
 * Gets the extension from a path.
 * Path must have a valid extension.
 *
 * @internal
 */
function extensionFromPath(path) {
    const ext = tryGetExtensionFromPath(path);
    return ext !== undefined ? ext : ts_js_1.Debug.fail(`File ${path} has unknown extension.`);
}
/** @internal */
function isAnySupportedFileExtension(path) {
    return tryGetExtensionFromPath(path) !== undefined;
}
/** @internal */
function tryGetExtensionFromPath(path) {
    return (0, ts_js_1.find)(extensionsToRemove, e => (0, ts_js_1.fileExtensionIs)(path, e));
}
/** @internal */
function isCheckJsEnabledForFile(sourceFile, compilerOptions) {
    return sourceFile.checkJsDirective ? sourceFile.checkJsDirective.enabled : compilerOptions.checkJs;
}
/** @internal */
exports.emptyFileSystemEntries = {
    files: ts_js_1.emptyArray,
    directories: ts_js_1.emptyArray,
};
/**
 * `parsedPatterns` contains both patterns (containing "*") and regular strings.
 * Return an exact match if possible, or a pattern match, or undefined.
 * (These are verified by verifyCompilerOptions to have 0 or 1 "*" characters.)
 *
 * @internal
 */
function matchPatternOrExact(parsedPatterns, candidate) {
    const { matchableStringSet, patterns } = parsedPatterns;
    if (matchableStringSet?.has(candidate)) {
        return candidate;
    }
    if (patterns === undefined || patterns.length === 0) {
        return undefined;
    }
    return (0, ts_js_1.findBestPatternMatch)(patterns, _ => _, candidate);
}
/** @internal */
function sliceAfter(arr, value) {
    const index = arr.indexOf(value);
    ts_js_1.Debug.assert(index !== -1);
    return arr.slice(index);
}
/** @internal */
function addRelatedInfo(diagnostic, ...relatedInformation) {
    if (!relatedInformation.length) {
        return diagnostic;
    }
    if (!diagnostic.relatedInformation) {
        diagnostic.relatedInformation = [];
    }
    ts_js_1.Debug.assert(diagnostic.relatedInformation !== ts_js_1.emptyArray, "Diagnostic had empty array singleton for related info, but is still being constructed!");
    diagnostic.relatedInformation.push(...relatedInformation);
    return diagnostic;
}
/** @internal */
function minAndMax(arr, getValue) {
    ts_js_1.Debug.assert(arr.length !== 0);
    let min = getValue(arr[0]);
    let max = min;
    for (let i = 1; i < arr.length; i++) {
        const value = getValue(arr[i]);
        if (value < min) {
            min = value;
        }
        else if (value > max) {
            max = value;
        }
    }
    return { min, max };
}
/** @internal */
function rangeOfNode(node) {
    return { pos: getTokenPosOfNode(node), end: node.end };
}
/** @internal */
function rangeOfTypeParameters(sourceFile, typeParameters) {
    // Include the `<>`
    const pos = typeParameters.pos - 1;
    const end = Math.min(sourceFile.text.length, (0, ts_js_1.skipTrivia)(sourceFile.text, typeParameters.end) + 1);
    return { pos, end };
}
/** @internal */
function skipTypeChecking(sourceFile, options, host) {
    return skipTypeCheckingWorker(sourceFile, options, host, /*ignoreNoCheck*/ false);
}
/** @internal */
function skipTypeCheckingIgnoringNoCheck(sourceFile, options, host) {
    return skipTypeCheckingWorker(sourceFile, options, host, /*ignoreNoCheck*/ true);
}
function skipTypeCheckingWorker(sourceFile, options, host, ignoreNoCheck) {
    // If skipLibCheck is enabled, skip reporting errors if file is a declaration file.
    // If skipDefaultLibCheck is enabled, skip reporting errors if file is a lib.
    return (options.skipLibCheck && sourceFile.isDeclarationFile ||
        options.skipDefaultLibCheck && host.isSourceFileDefaultLibrary(sourceFile)) ||
        (!ignoreNoCheck && options.noCheck) ||
        host.isSourceOfProjectReferenceRedirect(sourceFile.fileName) ||
        !canIncludeBindAndCheckDiagnostics(sourceFile, options);
}
/** @internal */
function canIncludeBindAndCheckDiagnostics(sourceFile, options) {
    if (!!sourceFile.checkJsDirective && sourceFile.checkJsDirective.enabled === false)
        return false;
    if (sourceFile.scriptKind === 3 /* ScriptKind.TS */ ||
        sourceFile.scriptKind === 4 /* ScriptKind.TSX */ ||
        sourceFile.scriptKind === 5 /* ScriptKind.External */)
        return true;
    const isJs = sourceFile.scriptKind === 1 /* ScriptKind.JS */ || sourceFile.scriptKind === 2 /* ScriptKind.JSX */;
    const isCheckJs = isJs && isCheckJsEnabledForFile(sourceFile, options);
    const isPlainJs = isPlainJsFile(sourceFile, options.checkJs);
    // By default, only type-check .ts, .tsx, Deferred, plain JS, checked JS and External
    // - plain JS: .js files with no // ts-check and checkJs: undefined
    // - check JS: .js files with either // ts-check or checkJs: true
    // - external: files that are added by plugins
    return isPlainJs || isCheckJs || sourceFile.scriptKind === 7 /* ScriptKind.Deferred */;
}
/** @internal */
function isJsonEqual(a, b) {
    // eslint-disable-next-line no-restricted-syntax
    return a === b || typeof a === "object" && a !== null && typeof b === "object" && b !== null && (0, ts_js_1.equalOwnProperties)(a, b, isJsonEqual);
}
/**
 * Converts a bigint literal string, e.g. `0x1234n`,
 * to its decimal string representation, e.g. `4660`.
 *
 * @internal
 */
function parsePseudoBigInt(stringValue) {
    let log2Base;
    switch (stringValue.charCodeAt(1)) { // "x" in "0x123"
        case 98 /* CharacterCodes.b */:
        case 66 /* CharacterCodes.B */: // 0b or 0B
            log2Base = 1;
            break;
        case 111 /* CharacterCodes.o */:
        case 79 /* CharacterCodes.O */: // 0o or 0O
            log2Base = 3;
            break;
        case 120 /* CharacterCodes.x */:
        case 88 /* CharacterCodes.X */: // 0x or 0X
            log2Base = 4;
            break;
        default: // already in decimal; omit trailing "n"
            const nIndex = stringValue.length - 1;
            // Skip leading 0s
            let nonZeroStart = 0;
            while (stringValue.charCodeAt(nonZeroStart) === 48 /* CharacterCodes._0 */) {
                nonZeroStart++;
            }
            return stringValue.slice(nonZeroStart, nIndex) || "0";
    }
    // Omit leading "0b", "0o", or "0x", and trailing "n"
    const startIndex = 2, endIndex = stringValue.length - 1;
    const bitsNeeded = (endIndex - startIndex) * log2Base;
    // Stores the value specified by the string as a LE array of 16-bit integers
    // using Uint16 instead of Uint32 so combining steps can use bitwise operators
    const segments = new Uint16Array((bitsNeeded >>> 4) + (bitsNeeded & 15 ? 1 : 0));
    // Add the digits, one at a time
    for (let i = endIndex - 1, bitOffset = 0; i >= startIndex; i--, bitOffset += log2Base) {
        const segment = bitOffset >>> 4;
        const digitChar = stringValue.charCodeAt(i);
        // Find character range: 0-9 < A-F < a-f
        const digit = digitChar <= 57 /* CharacterCodes._9 */
            ? digitChar - 48 /* CharacterCodes._0 */
            : 10 + digitChar -
                (digitChar <= 70 /* CharacterCodes.F */ ? 65 /* CharacterCodes.A */ : 97 /* CharacterCodes.a */);
        const shiftedDigit = digit << (bitOffset & 15);
        segments[segment] |= shiftedDigit;
        const residual = shiftedDigit >>> 16;
        if (residual)
            segments[segment + 1] |= residual; // overflows segment
    }
    // Repeatedly divide segments by 10 and add remainder to base10Value
    let base10Value = "";
    let firstNonzeroSegment = segments.length - 1;
    let segmentsRemaining = true;
    while (segmentsRemaining) {
        let mod10 = 0;
        segmentsRemaining = false;
        for (let segment = firstNonzeroSegment; segment >= 0; segment--) {
            const newSegment = mod10 << 16 | segments[segment];
            const segmentValue = (newSegment / 10) | 0;
            segments[segment] = segmentValue;
            mod10 = newSegment - segmentValue * 10;
            if (segmentValue && !segmentsRemaining) {
                firstNonzeroSegment = segment;
                segmentsRemaining = true;
            }
        }
        base10Value = mod10 + base10Value;
    }
    return base10Value;
}
/** @internal */
function pseudoBigIntToString({ negative, base10Value }) {
    return (negative && base10Value !== "0" ? "-" : "") + base10Value;
}
/** @internal */
function parseBigInt(text) {
    if (!isValidBigIntString(text, /*roundTripOnly*/ false)) {
        return undefined;
    }
    return parseValidBigInt(text);
}
/**
 * @internal
 * @param text a valid bigint string excluding a trailing `n`, but including a possible prefix `-`. Use `isValidBigIntString(text, roundTripOnly)` before calling this function.
 */
function parseValidBigInt(text) {
    const negative = text.startsWith("-");
    const base10Value = parsePseudoBigInt(`${negative ? text.slice(1) : text}n`);
    return { negative, base10Value };
}
/**
 * @internal
 * Tests whether the provided string can be parsed as a bigint.
 * @param s The string to test.
 * @param roundTripOnly Indicates the resulting bigint matches the input when converted back to a string.
 */
function isValidBigIntString(s, roundTripOnly) {
    if (s === "")
        return false;
    const scanner = (0, ts_js_1.createScanner)(99 /* ScriptTarget.ESNext */, /*skipTrivia*/ false);
    let success = true;
    scanner.setOnError(() => success = false);
    scanner.setText(s + "n");
    let result = scanner.scan();
    const negative = result === 41 /* SyntaxKind.MinusToken */;
    if (negative) {
        result = scanner.scan();
    }
    const flags = scanner.getTokenFlags();
    // validate that
    // * scanning proceeded without error
    // * a bigint can be scanned, and that when it is scanned, it is
    // * the full length of the input string (so the scanner is one character beyond the augmented input length)
    // * it does not contain a numeric seperator (the `BigInt` constructor does not accept a numeric seperator in its input)
    return success && result === 10 /* SyntaxKind.BigIntLiteral */ && scanner.getTokenEnd() === (s.length + 1) && !(flags & 512 /* TokenFlags.ContainsSeparator */)
        && (!roundTripOnly || s === pseudoBigIntToString({ negative, base10Value: parsePseudoBigInt(scanner.getTokenValue()) }));
}
/** @internal */
function isValidTypeOnlyAliasUseSite(useSite) {
    return !!(useSite.flags & 33554432 /* NodeFlags.Ambient */)
        || isInJSDoc(useSite)
        || isPartOfTypeQuery(useSite)
        || isIdentifierInNonEmittingHeritageClause(useSite)
        || isPartOfPossiblyValidTypeOrAbstractComputedPropertyName(useSite)
        || !(isExpressionNode(useSite) || isShorthandPropertyNameUseSite(useSite));
}
function isShorthandPropertyNameUseSite(useSite) {
    return (0, ts_js_1.isIdentifier)(useSite) && (0, ts_js_1.isShorthandPropertyAssignment)(useSite.parent) && useSite.parent.name === useSite;
}
function isPartOfPossiblyValidTypeOrAbstractComputedPropertyName(node) {
    while (node.kind === 80 /* SyntaxKind.Identifier */ || node.kind === 212 /* SyntaxKind.PropertyAccessExpression */) {
        node = node.parent;
    }
    if (node.kind !== 168 /* SyntaxKind.ComputedPropertyName */) {
        return false;
    }
    if (hasSyntacticModifier(node.parent, 64 /* ModifierFlags.Abstract */)) {
        return true;
    }
    const containerKind = node.parent.parent.kind;
    return containerKind === 265 /* SyntaxKind.InterfaceDeclaration */ || containerKind === 188 /* SyntaxKind.TypeLiteral */;
}
/** Returns true for an identifier in 1) an `implements` clause, and 2) an `extends` clause of an interface. */
function isIdentifierInNonEmittingHeritageClause(node) {
    if (node.kind !== 80 /* SyntaxKind.Identifier */)
        return false;
    const heritageClause = (0, ts_js_1.findAncestor)(node.parent, parent => {
        switch (parent.kind) {
            case 299 /* SyntaxKind.HeritageClause */:
                return true;
            case 212 /* SyntaxKind.PropertyAccessExpression */:
            case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
                return false;
            default:
                return "quit";
        }
    });
    return heritageClause?.token === 119 /* SyntaxKind.ImplementsKeyword */ || heritageClause?.parent.kind === 265 /* SyntaxKind.InterfaceDeclaration */;
}
/** @internal */
function isIdentifierTypeReference(node) {
    return (0, ts_js_1.isTypeReferenceNode)(node) && (0, ts_js_1.isIdentifier)(node.typeName);
}
/** @internal */
function arrayIsHomogeneous(array, comparer = ts_js_1.equateValues) {
    if (array.length < 2)
        return true;
    const first = array[0];
    for (let i = 1, length = array.length; i < length; i++) {
        const target = array[i];
        if (!comparer(first, target))
            return false;
    }
    return true;
}
/**
 * Bypasses immutability and directly sets the `pos` property of a `TextRange` or `Node`.
 *
 * @internal
 */
function setTextRangePos(range, pos) {
    range.pos = pos;
    return range;
}
/**
 * Bypasses immutability and directly sets the `end` property of a `TextRange` or `Node`.
 *
 * @internal
 */
function setTextRangeEnd(range, end) {
    range.end = end;
    return range;
}
/**
 * Bypasses immutability and directly sets the `pos` and `end` properties of a `TextRange` or `Node`.
 *
 * @internal
 */
function setTextRangePosEnd(range, pos, end) {
    return setTextRangeEnd(setTextRangePos(range, pos), end);
}
/**
 * Bypasses immutability and directly sets the `pos` and `end` properties of a `TextRange` or `Node` from the
 * provided position and width.
 *
 * @internal
 */
function setTextRangePosWidth(range, pos, width) {
    return setTextRangePosEnd(range, pos, pos + width);
}
/** @internal */
function setNodeFlags(node, newFlags) {
    if (node) {
        node.flags = newFlags;
    }
    return node;
}
/** @internal */
function setParent(child, parent) {
    if (child && parent) {
        child.parent = parent;
    }
    return child;
}
/** @internal */
function setParentRecursive(rootNode, incremental) {
    if (!rootNode)
        return rootNode;
    (0, ts_js_1.forEachChildRecursively)(rootNode, (0, ts_js_1.isJSDocNode)(rootNode) ? bindParentToChildIgnoringJSDoc : bindParentToChild);
    return rootNode;
    function bindParentToChildIgnoringJSDoc(child, parent) {
        if (incremental && child.parent === parent) {
            return "skip";
        }
        setParent(child, parent);
    }
    function bindJSDoc(child) {
        if ((0, ts_js_1.hasJSDocNodes)(child)) {
            for (const doc of child.jsDoc) {
                bindParentToChildIgnoringJSDoc(doc, child);
                (0, ts_js_1.forEachChildRecursively)(doc, bindParentToChildIgnoringJSDoc);
            }
        }
    }
    function bindParentToChild(child, parent) {
        return bindParentToChildIgnoringJSDoc(child, parent) || bindJSDoc(child);
    }
}
function isPackedElement(node) {
    return !(0, ts_js_1.isOmittedExpression)(node);
}
/**
 * Determines whether the provided node is an ArrayLiteralExpression that contains no missing elements.
 *
 * @internal
 */
function isPackedArrayLiteral(node) {
    return (0, ts_js_1.isArrayLiteralExpression)(node) && (0, ts_js_1.every)(node.elements, isPackedElement);
}
/**
 * Indicates whether the result of an `Expression` will be unused.
 *
 * NOTE: This requires a node with a valid `parent` pointer.
 *
 * @internal
 */
function expressionResultIsUnused(node) {
    ts_js_1.Debug.assertIsDefined(node.parent);
    while (true) {
        const parent = node.parent;
        // walk up parenthesized expressions, but keep a pointer to the top-most parenthesized expression
        if ((0, ts_js_1.isParenthesizedExpression)(parent)) {
            node = parent;
            continue;
        }
        // result is unused in an expression statement, `void` expression, or the initializer or incrementer of a `for` loop
        if ((0, ts_js_1.isExpressionStatement)(parent) ||
            (0, ts_js_1.isVoidExpression)(parent) ||
            (0, ts_js_1.isForStatement)(parent) && (parent.initializer === node || parent.incrementor === node)) {
            return true;
        }
        if ((0, ts_js_1.isCommaListExpression)(parent)) {
            // left side of comma is always unused
            if (node !== (0, ts_js_1.last)(parent.elements))
                return true;
            // right side of comma is unused if parent is unused
            node = parent;
            continue;
        }
        if ((0, ts_js_1.isBinaryExpression)(parent) && parent.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
            // left side of comma is always unused
            if (node === parent.left)
                return true;
            // right side of comma is unused if parent is unused
            node = parent;
            continue;
        }
        return false;
    }
}
/** @internal */
function containsIgnoredPath(path) {
    return (0, ts_js_1.some)(ts_js_1.ignoredPaths, p => path.includes(p));
}
/** @internal */
function getContainingNodeArray(node) {
    if (!node.parent)
        return undefined;
    switch (node.kind) {
        case 169 /* SyntaxKind.TypeParameter */:
            const { parent } = node;
            return parent.kind === 196 /* SyntaxKind.InferType */ ? undefined : parent.typeParameters;
        case 170 /* SyntaxKind.Parameter */:
            return node.parent.parameters;
        case 205 /* SyntaxKind.TemplateLiteralTypeSpan */:
            return node.parent.templateSpans;
        case 240 /* SyntaxKind.TemplateSpan */:
            return node.parent.templateSpans;
        case 171 /* SyntaxKind.Decorator */: {
            const { parent } = node;
            return (0, ts_js_1.canHaveDecorators)(parent) ? parent.modifiers :
                undefined;
        }
        case 299 /* SyntaxKind.HeritageClause */:
            return node.parent.heritageClauses;
    }
    const { parent } = node;
    if ((0, ts_js_1.isJSDocTag)(node)) {
        return (0, ts_js_1.isJSDocTypeLiteral)(node.parent) ? undefined : node.parent.tags;
    }
    switch (parent.kind) {
        case 188 /* SyntaxKind.TypeLiteral */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
            return (0, ts_js_1.isTypeElement)(node) ? parent.members : undefined;
        case 193 /* SyntaxKind.UnionType */:
        case 194 /* SyntaxKind.IntersectionType */:
            return parent.types;
        case 190 /* SyntaxKind.TupleType */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
        case 357 /* SyntaxKind.CommaListExpression */:
        case 276 /* SyntaxKind.NamedImports */:
        case 280 /* SyntaxKind.NamedExports */:
            return parent.elements;
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
        case 293 /* SyntaxKind.JsxAttributes */:
            return parent.properties;
        case 214 /* SyntaxKind.CallExpression */:
        case 215 /* SyntaxKind.NewExpression */:
            return (0, ts_js_1.isTypeNode)(node) ? parent.typeArguments :
                parent.expression === node ? undefined :
                    parent.arguments;
        case 285 /* SyntaxKind.JsxElement */:
        case 289 /* SyntaxKind.JsxFragment */:
            return (0, ts_js_1.isJsxChild)(node) ? parent.children : undefined;
        case 287 /* SyntaxKind.JsxOpeningElement */:
        case 286 /* SyntaxKind.JsxSelfClosingElement */:
            return (0, ts_js_1.isTypeNode)(node) ? parent.typeArguments : undefined;
        case 242 /* SyntaxKind.Block */:
        case 297 /* SyntaxKind.CaseClause */:
        case 298 /* SyntaxKind.DefaultClause */:
        case 269 /* SyntaxKind.ModuleBlock */:
            return parent.statements;
        case 270 /* SyntaxKind.CaseBlock */:
            return parent.clauses;
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 232 /* SyntaxKind.ClassExpression */:
            return (0, ts_js_1.isClassElement)(node) ? parent.members : undefined;
        case 267 /* SyntaxKind.EnumDeclaration */:
            return (0, ts_js_1.isEnumMember)(node) ? parent.members : undefined;
        case 308 /* SyntaxKind.SourceFile */:
            return parent.statements;
    }
}
/** @internal */
function hasContextSensitiveParameters(node) {
    // Functions with type parameters are not context sensitive.
    if (!node.typeParameters) {
        // Functions with any parameters that lack type annotations are context sensitive.
        if ((0, ts_js_1.some)(node.parameters, p => !getEffectiveTypeAnnotationNode(p))) {
            return true;
        }
        if (node.kind !== 220 /* SyntaxKind.ArrowFunction */) {
            // If the first parameter is not an explicit 'this' parameter, then the function has
            // an implicit 'this' parameter which is subject to contextual typing.
            const parameter = (0, ts_js_1.firstOrUndefined)(node.parameters);
            if (!(parameter && parameterIsThisKeyword(parameter))) {
                return !!(node.flags & 256 /* NodeFlags.ContainsThis */);
            }
        }
    }
    return false;
}
/** @internal */
function isInfinityOrNaNString(name) {
    return name === "Infinity" || name === "-Infinity" || name === "NaN";
}
/** @internal */
function isCatchClauseVariableDeclaration(node) {
    return node.kind === 261 /* SyntaxKind.VariableDeclaration */ && node.parent.kind === 300 /* SyntaxKind.CatchClause */;
}
/** @internal */
function isFunctionExpressionOrArrowFunction(node) {
    return node.kind === 219 /* SyntaxKind.FunctionExpression */ || node.kind === 220 /* SyntaxKind.ArrowFunction */;
}
/** @internal */
function escapeSnippetText(text) {
    return text.replace(/\$/g, () => "\\$");
}
/** @internal */
function isNumericLiteralName(name) {
    // The intent of numeric names is that
    //     - they are names with text in a numeric form, and that
    //     - setting properties/indexing with them is always equivalent to doing so with the numeric literal 'numLit',
    //         acquired by applying the abstract 'ToNumber' operation on the name's text.
    //
    // The subtlety is in the latter portion, as we cannot reliably say that anything that looks like a numeric literal is a numeric name.
    // In fact, it is the case that the text of the name must be equal to 'ToString(numLit)' for this to hold.
    //
    // Consider the property name '"0xF00D"'. When one indexes with '0xF00D', they are actually indexing with the value of 'ToString(0xF00D)'
    // according to the ECMAScript specification, so it is actually as if the user indexed with the string '"61453"'.
    // Thus, the text of all numeric literals equivalent to '61543' such as '0xF00D', '0xf00D', '0170015', etc. are not valid numeric names
    // because their 'ToString' representation is not equal to their original text.
    // This is motivated by ECMA-262 sections 9.3.1, 9.8.1, 11.1.5, and 11.2.1.
    //
    // Here, we test whether 'ToString(ToNumber(name))' is exactly equal to 'name'.
    // The '+' prefix operator is equivalent here to applying the abstract ToNumber operation.
    // Applying the 'toString()' method on a number gives us the abstract ToString operation on a number.
    //
    // Note that this accepts the values 'Infinity', '-Infinity', and 'NaN', and that this is intentional.
    // This is desired behavior, because when indexing with them as numeric entities, you are indexing
    // with the strings '"Infinity"', '"-Infinity"', and '"NaN"' respectively.
    return (+name).toString() === name;
}
/** @internal */
function createPropertyNameNodeForIdentifierOrLiteral(name, target, singleQuote, stringNamed, isMethod) {
    const isMethodNamedNew = isMethod && name === "new";
    return !isMethodNamedNew && (0, ts_js_1.isIdentifierText)(name, target) ? ts_js_1.factory.createIdentifier(name) :
        !stringNamed && !isMethodNamedNew && isNumericLiteralName(name) && +name >= 0 ? ts_js_1.factory.createNumericLiteral(+name) :
            ts_js_1.factory.createStringLiteral(name, !!singleQuote);
}
/** @internal */
function isThisTypeParameter(type) {
    return !!(type.flags & 524288 /* TypeFlags.TypeParameter */ && type.isThisType);
}
/** @internal */
function getNodeModulePathParts(fullPath) {
    // If fullPath can't be valid module file within node_modules, returns undefined.
    // Example of expected pattern: /base/path/node_modules/[@scope/otherpackage/@otherscope/node_modules/]package/[subdirectory/]file.js
    // Returns indices:                       ^            ^                                                      ^             ^
    let topLevelNodeModulesIndex = 0;
    let topLevelPackageNameIndex = 0;
    let packageRootIndex = 0;
    let fileNameIndex = 0;
    let States;
    (function (States) {
        States[States["BeforeNodeModules"] = 0] = "BeforeNodeModules";
        States[States["NodeModules"] = 1] = "NodeModules";
        States[States["Scope"] = 2] = "Scope";
        States[States["PackageContent"] = 3] = "PackageContent";
    })(States || (States = {}));
    let partStart = 0;
    let partEnd = 0;
    let state = 0 /* States.BeforeNodeModules */;
    while (partEnd >= 0) {
        partStart = partEnd;
        partEnd = fullPath.indexOf("/", partStart + 1);
        switch (state) {
            case 0 /* States.BeforeNodeModules */:
                if (fullPath.indexOf(ts_js_1.nodeModulesPathPart, partStart) === partStart) {
                    topLevelNodeModulesIndex = partStart;
                    topLevelPackageNameIndex = partEnd;
                    state = 1 /* States.NodeModules */;
                }
                break;
            case 1 /* States.NodeModules */:
            case 2 /* States.Scope */:
                if (state === 1 /* States.NodeModules */ && fullPath.charAt(partStart + 1) === "@") {
                    state = 2 /* States.Scope */;
                }
                else {
                    packageRootIndex = partEnd;
                    state = 3 /* States.PackageContent */;
                }
                break;
            case 3 /* States.PackageContent */:
                if (fullPath.indexOf(ts_js_1.nodeModulesPathPart, partStart) === partStart) {
                    state = 1 /* States.NodeModules */;
                }
                else {
                    state = 3 /* States.PackageContent */;
                }
                break;
        }
    }
    fileNameIndex = partStart;
    return state > 1 /* States.NodeModules */ ? { topLevelNodeModulesIndex, topLevelPackageNameIndex, packageRootIndex, fileNameIndex } : undefined;
}
/** @internal */
function isTypeDeclaration(node) {
    switch (node.kind) {
        case 169 /* SyntaxKind.TypeParameter */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 347 /* SyntaxKind.JSDocTypedefTag */:
        case 339 /* SyntaxKind.JSDocCallbackTag */:
        case 341 /* SyntaxKind.JSDocEnumTag */:
            return true;
        case 274 /* SyntaxKind.ImportClause */:
            return node.phaseModifier === 156 /* SyntaxKind.TypeKeyword */;
        case 277 /* SyntaxKind.ImportSpecifier */:
            return node.parent.parent.phaseModifier === 156 /* SyntaxKind.TypeKeyword */;
        case 282 /* SyntaxKind.ExportSpecifier */:
            return node.parent.parent.isTypeOnly;
        default:
            return false;
    }
}
/** @internal */
function canHaveExportModifier(node) {
    return (0, ts_js_1.isEnumDeclaration)(node) || (0, ts_js_1.isVariableStatement)(node) || (0, ts_js_1.isFunctionDeclaration)(node) || (0, ts_js_1.isClassDeclaration)(node)
        || (0, ts_js_1.isInterfaceDeclaration)(node) || isTypeDeclaration(node) || ((0, ts_js_1.isModuleDeclaration)(node) && !isExternalModuleAugmentation(node) && !isGlobalScopeAugmentation(node));
}
/** @internal */
function isOptionalJSDocPropertyLikeTag(node) {
    if (!(0, ts_js_1.isJSDocPropertyLikeTag)(node)) {
        return false;
    }
    const { isBracketed, typeExpression } = node;
    return isBracketed || !!typeExpression && typeExpression.type.kind === 317 /* SyntaxKind.JSDocOptionalType */;
}
/** @internal */
function canUsePropertyAccess(name, languageVersion) {
    if (name.length === 0) {
        return false;
    }
    const firstChar = name.charCodeAt(0);
    return firstChar === 35 /* CharacterCodes.hash */ ?
        name.length > 1 && (0, ts_js_1.isIdentifierStart)(name.charCodeAt(1), languageVersion) :
        (0, ts_js_1.isIdentifierStart)(firstChar, languageVersion);
}
/** @internal */
function hasTabstop(node) {
    return (0, ts_js_1.getSnippetElement)(node)?.kind === 0 /* SnippetKind.TabStop */;
}
/** @internal */
function isJSDocOptionalParameter(node) {
    return isInJSFile(node) && (
    // node.type should only be a JSDocOptionalType when node is a parameter of a JSDocFunctionType
    node.type && node.type.kind === 317 /* SyntaxKind.JSDocOptionalType */
        || (0, ts_js_1.getJSDocParameterTags)(node).some(isOptionalJSDocPropertyLikeTag));
}
/** @internal */
function isOptionalDeclaration(declaration) {
    switch (declaration.kind) {
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
            return !!declaration.questionToken;
        case 170 /* SyntaxKind.Parameter */:
            return !!declaration.questionToken || isJSDocOptionalParameter(declaration);
        case 349 /* SyntaxKind.JSDocPropertyTag */:
        case 342 /* SyntaxKind.JSDocParameterTag */:
            return isOptionalJSDocPropertyLikeTag(declaration);
        default:
            return false;
    }
}
/** @internal */
function isNonNullAccess(node) {
    const kind = node.kind;
    return (kind === 212 /* SyntaxKind.PropertyAccessExpression */
        || kind === 213 /* SyntaxKind.ElementAccessExpression */) && (0, ts_js_1.isNonNullExpression)(node.expression);
}
/** @internal */
function isJSDocSatisfiesExpression(node) {
    return isInJSFile(node) && (0, ts_js_1.isParenthesizedExpression)(node) && (0, ts_js_1.hasJSDocNodes)(node) && !!(0, ts_js_1.getJSDocSatisfiesTag)(node);
}
/** @internal */
function getJSDocSatisfiesExpressionType(node) {
    return ts_js_1.Debug.checkDefined(tryGetJSDocSatisfiesTypeNode(node));
}
/** @internal */
function tryGetJSDocSatisfiesTypeNode(node) {
    const tag = (0, ts_js_1.getJSDocSatisfiesTag)(node);
    return tag && tag.typeExpression && tag.typeExpression.type;
}
/** @internal */
function getEscapedTextOfJsxAttributeName(node) {
    return (0, ts_js_1.isIdentifier)(node) ? node.escapedText : getEscapedTextOfJsxNamespacedName(node);
}
/** @internal */
function getTextOfJsxAttributeName(node) {
    return (0, ts_js_1.isIdentifier)(node) ? (0, ts_js_1.idText)(node) : getTextOfJsxNamespacedName(node);
}
/** @internal */
function isJsxAttributeName(node) {
    const kind = node.kind;
    return kind === 80 /* SyntaxKind.Identifier */
        || kind === 296 /* SyntaxKind.JsxNamespacedName */;
}
/** @internal */
function getEscapedTextOfJsxNamespacedName(node) {
    return `${node.namespace.escapedText}:${(0, ts_js_1.idText)(node.name)}`;
}
/** @internal */
function getTextOfJsxNamespacedName(node) {
    return `${(0, ts_js_1.idText)(node.namespace)}:${(0, ts_js_1.idText)(node.name)}`;
}
/** @internal */
function intrinsicTagNameToString(node) {
    return (0, ts_js_1.isIdentifier)(node) ? (0, ts_js_1.idText)(node) : getTextOfJsxNamespacedName(node);
}
/**
 * Indicates whether a type can be used as a property name.
 * @internal
 */
function isTypeUsableAsPropertyName(type) {
    return !!(type.flags & 19456 /* TypeFlags.StringOrNumberLiteralOrUnique */);
}
/**
 * Gets the symbolic name for a member from its type.
 * @internal
 */
function getPropertyNameFromType(type) {
    if (type.flags & 16384 /* TypeFlags.UniqueESSymbol */) {
        return type.escapedName;
    }
    if (type.flags & (1024 /* TypeFlags.StringLiteral */ | 2048 /* TypeFlags.NumberLiteral */)) {
        return (0, ts_js_1.escapeLeadingUnderscores)("" + type.value);
    }
    return ts_js_1.Debug.fail();
}
/** @internal */
function isExpandoPropertyDeclaration(declaration) {
    return !!declaration && ((0, ts_js_1.isPropertyAccessExpression)(declaration) || (0, ts_js_1.isElementAccessExpression)(declaration) || (0, ts_js_1.isBinaryExpression)(declaration));
}
/** @internal */
function hasResolutionModeOverride(node) {
    if (node === undefined) {
        return false;
    }
    return !!(0, ts_js_1.getResolutionModeOverride)(node.attributes);
}
const stringReplace = String.prototype.replace;
/** @internal */
function replaceFirstStar(s, replacement) {
    // `s.replace("*", replacement)` triggers CodeQL as they think it's a potentially incorrect string escaping.
    // See: https://codeql.github.com/codeql-query-help/javascript/js-incomplete-sanitization/
    // But, we really do want to replace only the first star.
    // Attempt to defeat this analysis by indirectly calling the method.
    return stringReplace.call(s, "*", replacement);
}
/** @internal */
function getNameFromImportAttribute(node) {
    return (0, ts_js_1.isIdentifier)(node.name) ? node.name.escapedText : (0, ts_js_1.escapeLeadingUnderscores)(node.name.text);
}
/** @internal */
function isSourceElement(node) {
    switch (node.kind) {
        case 169 /* SyntaxKind.TypeParameter */:
        case 170 /* SyntaxKind.Parameter */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 185 /* SyntaxKind.FunctionType */:
        case 180 /* SyntaxKind.CallSignature */:
        case 181 /* SyntaxKind.ConstructSignature */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
        case 177 /* SyntaxKind.Constructor */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 184 /* SyntaxKind.TypeReference */:
        case 183 /* SyntaxKind.TypePredicate */:
        case 187 /* SyntaxKind.TypeQuery */:
        case 188 /* SyntaxKind.TypeLiteral */:
        case 189 /* SyntaxKind.ArrayType */:
        case 190 /* SyntaxKind.TupleType */:
        case 193 /* SyntaxKind.UnionType */:
        case 194 /* SyntaxKind.IntersectionType */:
        case 197 /* SyntaxKind.ParenthesizedType */:
        case 191 /* SyntaxKind.OptionalType */:
        case 192 /* SyntaxKind.RestType */:
        case 198 /* SyntaxKind.ThisType */:
        case 199 /* SyntaxKind.TypeOperator */:
        case 195 /* SyntaxKind.ConditionalType */:
        case 196 /* SyntaxKind.InferType */:
        case 204 /* SyntaxKind.TemplateLiteralType */:
        case 206 /* SyntaxKind.ImportType */:
        case 203 /* SyntaxKind.NamedTupleMember */:
        case 329 /* SyntaxKind.JSDocAugmentsTag */:
        case 330 /* SyntaxKind.JSDocImplementsTag */:
        case 347 /* SyntaxKind.JSDocTypedefTag */:
        case 339 /* SyntaxKind.JSDocCallbackTag */:
        case 341 /* SyntaxKind.JSDocEnumTag */:
        case 346 /* SyntaxKind.JSDocTemplateTag */:
        case 345 /* SyntaxKind.JSDocTypeTag */:
        case 325 /* SyntaxKind.JSDocLink */:
        case 326 /* SyntaxKind.JSDocLinkCode */:
        case 327 /* SyntaxKind.JSDocLinkPlain */:
        case 342 /* SyntaxKind.JSDocParameterTag */:
        case 349 /* SyntaxKind.JSDocPropertyTag */:
        case 318 /* SyntaxKind.JSDocFunctionType */:
        case 316 /* SyntaxKind.JSDocNonNullableType */:
        case 315 /* SyntaxKind.JSDocNullableType */:
        case 313 /* SyntaxKind.JSDocAllType */:
        case 314 /* SyntaxKind.JSDocUnknownType */:
        case 323 /* SyntaxKind.JSDocTypeLiteral */:
        case 319 /* SyntaxKind.JSDocVariadicType */:
        case 310 /* SyntaxKind.JSDocTypeExpression */:
        case 334 /* SyntaxKind.JSDocPublicTag */:
        case 336 /* SyntaxKind.JSDocProtectedTag */:
        case 335 /* SyntaxKind.JSDocPrivateTag */:
        case 351 /* SyntaxKind.JSDocSatisfiesTag */:
        case 344 /* SyntaxKind.JSDocThisTag */:
        case 200 /* SyntaxKind.IndexedAccessType */:
        case 201 /* SyntaxKind.MappedType */:
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 242 /* SyntaxKind.Block */:
        case 269 /* SyntaxKind.ModuleBlock */:
        case 244 /* SyntaxKind.VariableStatement */:
        case 245 /* SyntaxKind.ExpressionStatement */:
        case 246 /* SyntaxKind.IfStatement */:
        case 247 /* SyntaxKind.DoStatement */:
        case 248 /* SyntaxKind.WhileStatement */:
        case 249 /* SyntaxKind.ForStatement */:
        case 250 /* SyntaxKind.ForInStatement */:
        case 251 /* SyntaxKind.ForOfStatement */:
        case 252 /* SyntaxKind.ContinueStatement */:
        case 253 /* SyntaxKind.BreakStatement */:
        case 254 /* SyntaxKind.ReturnStatement */:
        case 255 /* SyntaxKind.WithStatement */:
        case 256 /* SyntaxKind.SwitchStatement */:
        case 257 /* SyntaxKind.LabeledStatement */:
        case 258 /* SyntaxKind.ThrowStatement */:
        case 259 /* SyntaxKind.TryStatement */:
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 209 /* SyntaxKind.BindingElement */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 278 /* SyntaxKind.ExportAssignment */:
        case 243 /* SyntaxKind.EmptyStatement */:
        case 260 /* SyntaxKind.DebuggerStatement */:
        case 283 /* SyntaxKind.MissingDeclaration */:
            return true;
    }
    return false;
}
/** @internal */
function evaluatorResult(value, isSyntacticallyString = false, resolvedOtherFiles = false, hasExternalReferences = false) {
    return { value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences };
}
/** @internal */
function createEvaluator({ evaluateElementAccessExpression, evaluateEntityNameExpression }) {
    function evaluate(expr, location) {
        let isSyntacticallyString = false;
        let resolvedOtherFiles = false;
        let hasExternalReferences = false;
        // It's unclear when/whether we should consider skipping other kinds of outer expressions.
        // Type assertions intentionally break evaluation when evaluating literal types, such as:
        //     type T = `one ${"two" as any} three`; // string
        // But it's less clear whether such an assertion should break enum member evaluation:
        //     enum E {
        //       A = "one" as any
        //     }
        // SatisfiesExpressions and non-null assertions seem to have even less reason to break
        // emitting enum members as literals. However, these expressions also break Babel's
        // evaluation (but not esbuild's), and the isolatedModules errors we give depend on
        // our evaluation results, so we're currently being conservative so as to issue errors
        // on code that might break Babel.
        expr = skipParentheses(expr);
        switch (expr.kind) {
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
                const result = evaluate(expr.operand, location);
                resolvedOtherFiles = result.resolvedOtherFiles;
                hasExternalReferences = result.hasExternalReferences;
                if (typeof result.value === "number") {
                    switch (expr.operator) {
                        case 40 /* SyntaxKind.PlusToken */:
                            return evaluatorResult(result.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 41 /* SyntaxKind.MinusToken */:
                            return evaluatorResult(-result.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 55 /* SyntaxKind.TildeToken */:
                            return evaluatorResult(~result.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                    }
                }
                break;
            case 227 /* SyntaxKind.BinaryExpression */: {
                const left = evaluate(expr.left, location);
                const right = evaluate(expr.right, location);
                isSyntacticallyString = (left.isSyntacticallyString || right.isSyntacticallyString) && expr.operatorToken.kind === 40 /* SyntaxKind.PlusToken */;
                resolvedOtherFiles = left.resolvedOtherFiles || right.resolvedOtherFiles;
                hasExternalReferences = left.hasExternalReferences || right.hasExternalReferences;
                if (typeof left.value === "number" && typeof right.value === "number") {
                    switch (expr.operatorToken.kind) {
                        case 52 /* SyntaxKind.BarToken */:
                            return evaluatorResult(left.value | right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 51 /* SyntaxKind.AmpersandToken */:
                            return evaluatorResult(left.value & right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 49 /* SyntaxKind.GreaterThanGreaterThanToken */:
                            return evaluatorResult(left.value >> right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 50 /* SyntaxKind.GreaterThanGreaterThanGreaterThanToken */:
                            return evaluatorResult(left.value >>> right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 48 /* SyntaxKind.LessThanLessThanToken */:
                            return evaluatorResult(left.value << right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 53 /* SyntaxKind.CaretToken */:
                            return evaluatorResult(left.value ^ right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 42 /* SyntaxKind.AsteriskToken */:
                            return evaluatorResult(left.value * right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 44 /* SyntaxKind.SlashToken */:
                            return evaluatorResult(left.value / right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 40 /* SyntaxKind.PlusToken */:
                            return evaluatorResult(left.value + right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 41 /* SyntaxKind.MinusToken */:
                            return evaluatorResult(left.value - right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 45 /* SyntaxKind.PercentToken */:
                            return evaluatorResult(left.value % right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                        case 43 /* SyntaxKind.AsteriskAsteriskToken */:
                            return evaluatorResult(left.value ** right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                    }
                }
                else if ((typeof left.value === "string" || typeof left.value === "number") &&
                    (typeof right.value === "string" || typeof right.value === "number") &&
                    expr.operatorToken.kind === 40 /* SyntaxKind.PlusToken */) {
                    return evaluatorResult("" + left.value + right.value, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
                }
                break;
            }
            case 11 /* SyntaxKind.StringLiteral */:
            case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
                return evaluatorResult(expr.text, /*isSyntacticallyString*/ true);
            case 229 /* SyntaxKind.TemplateExpression */:
                return evaluateTemplateExpression(expr, location);
            case 9 /* SyntaxKind.NumericLiteral */:
                return evaluatorResult(+expr.text);
            case 80 /* SyntaxKind.Identifier */:
                return evaluateEntityNameExpression(expr, location);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                if (isEntityNameExpression(expr)) {
                    return evaluateEntityNameExpression(expr, location);
                }
                break;
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return evaluateElementAccessExpression(expr, location);
        }
        return evaluatorResult(/*value*/ undefined, isSyntacticallyString, resolvedOtherFiles, hasExternalReferences);
    }
    function evaluateTemplateExpression(expr, location) {
        let result = expr.head.text;
        let resolvedOtherFiles = false;
        let hasExternalReferences = false;
        for (const span of expr.templateSpans) {
            const spanResult = evaluate(span.expression, location);
            if (spanResult.value === undefined) {
                return evaluatorResult(/*value*/ undefined, /*isSyntacticallyString*/ true);
            }
            result += spanResult.value;
            result += span.literal.text;
            resolvedOtherFiles || (resolvedOtherFiles = spanResult.resolvedOtherFiles);
            hasExternalReferences || (hasExternalReferences = spanResult.hasExternalReferences);
        }
        return evaluatorResult(result, 
        /*isSyntacticallyString*/ true, resolvedOtherFiles, hasExternalReferences);
    }
    return evaluate;
}
/** @internal */
function isConstAssertion(location) {
    return ((0, ts_js_1.isAssertionExpression)(location) && (0, ts_js_1.isConstTypeReference)(location.type))
        || ((0, ts_js_1.isJSDocTypeTag)(location) && (0, ts_js_1.isConstTypeReference)(location.typeExpression));
}
/** @internal */
function findConstructorDeclaration(node) {
    const members = node.members;
    for (const member of members) {
        if (member.kind === 177 /* SyntaxKind.Constructor */ && nodeIsPresent(member.body)) {
            return member;
        }
    }
}
/** @internal */
function createNameResolver({ compilerOptions, requireSymbol, argumentsSymbol, error, getSymbolOfDeclaration, globals, lookup, setRequiresScopeChangeCache = ts_js_1.returnUndefined, getRequiresScopeChangeCache = ts_js_1.returnUndefined, onPropertyWithInvalidInitializer = ts_js_1.returnFalse, onFailedToResolveSymbol = ts_js_1.returnUndefined, onSuccessfullyResolvedSymbol = ts_js_1.returnUndefined, }) {
    /* eslint-disable no-var */
    var isolatedModulesLikeFlagName = compilerOptions.verbatimModuleSyntax ? "verbatimModuleSyntax" : "isolatedModules";
    /* eslint-disable no-var */
    var emitStandardClassFields = getEmitStandardClassFields(compilerOptions);
    var emptySymbols = createSymbolTable();
    return resolveNameHelper;
    function resolveNameHelper(location, nameArg, meaning, nameNotFoundMessage, isUse, excludeGlobals) {
        const originalLocation = location; // needed for did-you-mean error reporting, which gathers candidates starting from the original location
        let result;
        let lastLocation;
        let lastSelfReferenceLocation;
        let propertyWithInvalidInitializer;
        let associatedDeclarationForContainingInitializerOrBindingName;
        let withinDeferredContext = false;
        let grandparent;
        const name = (0, ts_js_1.isString)(nameArg) ? nameArg : nameArg.escapedText;
        loop: while (location) {
            if (name === "const" && isConstAssertion(location)) {
                // `const` in an `as const` has no symbol, but issues no error because there is no *actual* lookup of the type
                // (it refers to the constant type of the expression instead)
                return undefined;
            }
            if ((0, ts_js_1.isModuleOrEnumDeclaration)(location) && lastLocation && location.name === lastLocation) {
                // If lastLocation is the name of a namespace or enum, skip the parent since it will have is own locals that could
                // conflict.
                lastLocation = location;
                location = location.parent;
            }
            // Locals of a source file are not in scope (because they get merged into the global symbol table)
            if ((0, ts_js_1.canHaveLocals)(location) && location.locals && !isGlobalSourceFile(location)) {
                if (result = lookup(location.locals, name, meaning)) {
                    let useResult = true;
                    if ((0, ts_js_1.isFunctionLike)(location) && lastLocation && lastLocation !== location.body) {
                        // symbol lookup restrictions for function-like declarations
                        // - Type parameters of a function are in scope in the entire function declaration, including the parameter
                        //   list and return type. However, local types are only in scope in the function body.
                        // - parameters are only in the scope of function body
                        // This restriction does not apply to JSDoc comment types because they are parented
                        // at a higher level than type parameters would normally be
                        if (meaning & result.flags & 788968 /* SymbolFlags.Type */ && lastLocation.kind !== 321 /* SyntaxKind.JSDoc */) {
                            useResult = result.flags & 262144 /* SymbolFlags.TypeParameter */
                                // type parameters are visible in parameter list, return type and type parameter list
                                ? !!(lastLocation.flags & 16 /* NodeFlags.Synthesized */) || // Synthetic fake scopes are added for signatures so type parameters are accessible from them
                                    lastLocation === location.type ||
                                    lastLocation.kind === 170 /* SyntaxKind.Parameter */ ||
                                    lastLocation.kind === 342 /* SyntaxKind.JSDocParameterTag */ ||
                                    lastLocation.kind === 343 /* SyntaxKind.JSDocReturnTag */ ||
                                    lastLocation.kind === 169 /* SyntaxKind.TypeParameter */
                                // local types not visible outside the function body
                                : false;
                        }
                        if (meaning & result.flags & 3 /* SymbolFlags.Variable */) {
                            // expression inside parameter will lookup as normal variable scope when targeting es2015+
                            if (useOuterVariableScopeInParameter(result, location, lastLocation)) {
                                useResult = false;
                            }
                            else if (result.flags & 1 /* SymbolFlags.FunctionScopedVariable */) {
                                // parameters are visible only inside function body, parameter list and return type
                                // technically for parameter list case here we might mix parameters and variables declared in function,
                                // however it is detected separately when checking initializers of parameters
                                // to make sure that they reference no variables declared after them.
                                useResult = lastLocation.kind === 170 /* SyntaxKind.Parameter */ ||
                                    !!(lastLocation.flags & 16 /* NodeFlags.Synthesized */) || // Synthetic fake scopes are added for signatures so parameters are accessible from them
                                    (lastLocation === location.type &&
                                        !!(0, ts_js_1.findAncestor)(result.valueDeclaration, ts_js_1.isParameter));
                            }
                        }
                    }
                    else if (location.kind === 195 /* SyntaxKind.ConditionalType */) {
                        // A type parameter declared using 'infer T' in a conditional type is visible only in
                        // the true branch of the conditional type.
                        useResult = lastLocation === location.trueType;
                    }
                    if (useResult) {
                        break loop;
                    }
                    else {
                        result = undefined;
                    }
                }
            }
            withinDeferredContext = withinDeferredContext || getIsDeferredContext(location, lastLocation);
            switch (location.kind) {
                case 308 /* SyntaxKind.SourceFile */:
                    if (!isExternalOrCommonJsModule(location))
                        break;
                // falls through
                case 268 /* SyntaxKind.ModuleDeclaration */:
                    const moduleExports = getSymbolOfDeclaration(location)?.exports || emptySymbols;
                    if (location.kind === 308 /* SyntaxKind.SourceFile */ || ((0, ts_js_1.isModuleDeclaration)(location) && location.flags & 33554432 /* NodeFlags.Ambient */ && !isGlobalScopeAugmentation(location))) {
                        // It's an external module. First see if the module has an export default and if the local
                        // name of that export default matches.
                        if (result = moduleExports.get("default" /* InternalSymbolName.Default */)) {
                            const localSymbol = getLocalSymbolForExportDefault(result);
                            if (localSymbol && (result.flags & meaning) && localSymbol.escapedName === name) {
                                break loop;
                            }
                            result = undefined;
                        }
                        // Because of module/namespace merging, a module's exports are in scope,
                        // yet we never want to treat an export specifier as putting a member in scope.
                        // Therefore, if the name we find is purely an export specifier, it is not actually considered in scope.
                        // Two things to note about this:
                        //     1. We have to check this without calling getSymbol. The problem with calling getSymbol
                        //        on an export specifier is that it might find the export specifier itself, and try to
                        //        resolve it as an alias. This will cause the checker to consider the export specifier
                        //        a circular alias reference when it might not be.
                        //     2. We check === SymbolFlags.Alias in order to check that the symbol is *purely*
                        //        an alias. If we used &, we'd be throwing out symbols that have non alias aspects,
                        //        which is not the desired behavior.
                        const moduleExport = moduleExports.get(name);
                        if (moduleExport &&
                            moduleExport.flags === 2097152 /* SymbolFlags.Alias */ &&
                            (getDeclarationOfKind(moduleExport, 282 /* SyntaxKind.ExportSpecifier */) || getDeclarationOfKind(moduleExport, 281 /* SyntaxKind.NamespaceExport */))) {
                            break;
                        }
                    }
                    // ES6 exports are also visible locally (except for 'default'), but commonjs exports are not (except typedefs)
                    if (name !== "default" /* InternalSymbolName.Default */ && (result = lookup(moduleExports, name, meaning & 2623475 /* SymbolFlags.ModuleMember */))) {
                        if ((0, ts_js_1.isSourceFile)(location) && location.commonJsModuleIndicator && !result.declarations?.some(isJSDocTypeAlias)) {
                            result = undefined;
                        }
                        else {
                            break loop;
                        }
                    }
                    break;
                case 267 /* SyntaxKind.EnumDeclaration */:
                    if (result = lookup(getSymbolOfDeclaration(location)?.exports || emptySymbols, name, meaning & 8 /* SymbolFlags.EnumMember */)) {
                        if (nameNotFoundMessage && (0, exports.getIsolatedModules)(compilerOptions) && !(location.flags & 33554432 /* NodeFlags.Ambient */) && getSourceFileOfNode(location) !== getSourceFileOfNode(result.valueDeclaration)) {
                            error(originalLocation, ts_js_1.Diagnostics.Cannot_access_0_from_another_file_without_qualification_when_1_is_enabled_Use_2_instead, (0, ts_js_1.unescapeLeadingUnderscores)(name), isolatedModulesLikeFlagName, `${(0, ts_js_1.unescapeLeadingUnderscores)(getSymbolOfDeclaration(location).escapedName)}.${(0, ts_js_1.unescapeLeadingUnderscores)(name)}`);
                        }
                        break loop;
                    }
                    break;
                case 173 /* SyntaxKind.PropertyDeclaration */:
                    // TypeScript 1.0 spec (April 2014): 8.4.1
                    // Initializer expressions for instance member variables are evaluated in the scope
                    // of the class constructor body but are not permitted to reference parameters or
                    // local variables of the constructor. This effectively means that entities from outer scopes
                    // by the same name as a constructor parameter or local variable are inaccessible
                    // in initializer expressions for instance member variables.
                    if (!isStatic(location)) {
                        const ctor = findConstructorDeclaration(location.parent);
                        if (ctor && ctor.locals) {
                            if (lookup(ctor.locals, name, meaning & 111551 /* SymbolFlags.Value */)) {
                                // Remember the property node, it will be used later to report appropriate error
                                ts_js_1.Debug.assertNode(location, ts_js_1.isPropertyDeclaration);
                                propertyWithInvalidInitializer = location;
                            }
                        }
                    }
                    break;
                case 264 /* SyntaxKind.ClassDeclaration */:
                case 232 /* SyntaxKind.ClassExpression */:
                case 265 /* SyntaxKind.InterfaceDeclaration */:
                    // The below is used to lookup type parameters within a class or interface, as they are added to the class/interface locals
                    // These can never be latebound, so the symbol's raw members are sufficient. `getMembersOfNode` cannot be used, as it would
                    // trigger resolving late-bound names, which we may already be in the process of doing while we're here!
                    if (result = lookup(getSymbolOfDeclaration(location).members || emptySymbols, name, meaning & 788968 /* SymbolFlags.Type */)) {
                        if (!isTypeParameterSymbolDeclaredInContainer(result, location)) {
                            // ignore type parameters not declared in this container
                            result = undefined;
                            break;
                        }
                        if (lastLocation && isStatic(lastLocation)) {
                            // TypeScript 1.0 spec (April 2014): 3.4.1
                            // The scope of a type parameter extends over the entire declaration with which the type
                            // parameter list is associated, with the exception of static member declarations in classes.
                            if (nameNotFoundMessage) {
                                error(originalLocation, ts_js_1.Diagnostics.Static_members_cannot_reference_class_type_parameters);
                            }
                            return undefined;
                        }
                        break loop;
                    }
                    if ((0, ts_js_1.isClassExpression)(location) && meaning & 32 /* SymbolFlags.Class */) {
                        const className = location.name;
                        if (className && name === className.escapedText) {
                            result = location.symbol;
                            break loop;
                        }
                    }
                    break;
                case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
                    // The type parameters of a class are not in scope in the base class expression.
                    if (lastLocation === location.expression && location.parent.token === 96 /* SyntaxKind.ExtendsKeyword */) {
                        const container = location.parent.parent;
                        if ((0, ts_js_1.isClassLike)(container) && (result = lookup(getSymbolOfDeclaration(container).members, name, meaning & 788968 /* SymbolFlags.Type */))) {
                            if (nameNotFoundMessage) {
                                error(originalLocation, ts_js_1.Diagnostics.Base_class_expressions_cannot_reference_class_type_parameters);
                            }
                            return undefined;
                        }
                    }
                    break;
                // It is not legal to reference a class's own type parameters from a computed property name that
                // belongs to the class. For example:
                //
                //   function foo<T>() { return '' }
                //   class C<T> { // <-- Class's own type parameter T
                //       [foo<T>()]() { } // <-- Reference to T from class's own computed property
                //   }
                //
                case 168 /* SyntaxKind.ComputedPropertyName */:
                    grandparent = location.parent.parent;
                    if ((0, ts_js_1.isClassLike)(grandparent) || grandparent.kind === 265 /* SyntaxKind.InterfaceDeclaration */) {
                        // A reference to this grandparent's type parameters would be an error
                        if (result = lookup(getSymbolOfDeclaration(grandparent).members, name, meaning & 788968 /* SymbolFlags.Type */)) {
                            if (nameNotFoundMessage) {
                                error(originalLocation, ts_js_1.Diagnostics.A_computed_property_name_cannot_reference_a_type_parameter_from_its_containing_type);
                            }
                            return undefined;
                        }
                    }
                    break;
                case 220 /* SyntaxKind.ArrowFunction */:
                    // when targeting ES6 or higher there is no 'arguments' in an arrow function
                    // for lower compile targets the resolved symbol is used to emit an error
                    if ((0, exports.getEmitScriptTarget)(compilerOptions) >= 2 /* ScriptTarget.ES2015 */) {
                        break;
                    }
                // falls through
                case 175 /* SyntaxKind.MethodDeclaration */:
                case 177 /* SyntaxKind.Constructor */:
                case 178 /* SyntaxKind.GetAccessor */:
                case 179 /* SyntaxKind.SetAccessor */:
                case 263 /* SyntaxKind.FunctionDeclaration */:
                    if (meaning & 3 /* SymbolFlags.Variable */ && name === "arguments") {
                        result = argumentsSymbol;
                        break loop;
                    }
                    break;
                case 219 /* SyntaxKind.FunctionExpression */:
                    if (meaning & 3 /* SymbolFlags.Variable */ && name === "arguments") {
                        result = argumentsSymbol;
                        break loop;
                    }
                    if (meaning & 16 /* SymbolFlags.Function */) {
                        const functionName = location.name;
                        if (functionName && name === functionName.escapedText) {
                            result = location.symbol;
                            break loop;
                        }
                    }
                    break;
                case 171 /* SyntaxKind.Decorator */:
                    // Decorators are resolved at the class declaration. Resolving at the parameter
                    // or member would result in looking up locals in the method.
                    //
                    //   function y() {}
                    //   class C {
                    //       method(@y x, y) {} // <-- decorator y should be resolved at the class declaration, not the parameter.
                    //   }
                    //
                    if (location.parent && location.parent.kind === 170 /* SyntaxKind.Parameter */) {
                        location = location.parent;
                    }
                    //
                    //   function y() {}
                    //   class C {
                    //       @y method(x, y) {} // <-- decorator y should be resolved at the class declaration, not the method.
                    //   }
                    //
                    // class Decorators are resolved outside of the class to avoid referencing type parameters of that class.
                    //
                    //   type T = number;
                    //   declare function y(x: T): any;
                    //   @param(1 as T) // <-- T should resolve to the type alias outside of class C
                    //   class C<T> {}
                    if (location.parent && ((0, ts_js_1.isClassElement)(location.parent) || location.parent.kind === 264 /* SyntaxKind.ClassDeclaration */)) {
                        location = location.parent;
                    }
                    break;
                case 347 /* SyntaxKind.JSDocTypedefTag */:
                case 339 /* SyntaxKind.JSDocCallbackTag */:
                case 341 /* SyntaxKind.JSDocEnumTag */:
                case 352 /* SyntaxKind.JSDocImportTag */:
                    // js type aliases do not resolve names from their host, so skip past it
                    const root = getJSDocRoot(location);
                    if (root) {
                        location = root.parent;
                    }
                    break;
                case 170 /* SyntaxKind.Parameter */:
                    if (lastLocation && (lastLocation === location.initializer ||
                        lastLocation === location.name && (0, ts_js_1.isBindingPattern)(lastLocation))) {
                        if (!associatedDeclarationForContainingInitializerOrBindingName) {
                            associatedDeclarationForContainingInitializerOrBindingName = location;
                        }
                    }
                    break;
                case 209 /* SyntaxKind.BindingElement */:
                    if (lastLocation && (lastLocation === location.initializer ||
                        lastLocation === location.name && (0, ts_js_1.isBindingPattern)(lastLocation))) {
                        if (isPartOfParameterDeclaration(location) && !associatedDeclarationForContainingInitializerOrBindingName) {
                            associatedDeclarationForContainingInitializerOrBindingName = location;
                        }
                    }
                    break;
                case 196 /* SyntaxKind.InferType */:
                    if (meaning & 262144 /* SymbolFlags.TypeParameter */) {
                        const parameterName = location.typeParameter.name;
                        if (parameterName && name === parameterName.escapedText) {
                            result = location.typeParameter.symbol;
                            break loop;
                        }
                    }
                    break;
                case 282 /* SyntaxKind.ExportSpecifier */:
                    // External module export bindings shouldn't be resolved to local symbols.
                    if (lastLocation &&
                        lastLocation === location.propertyName &&
                        location.parent.parent.moduleSpecifier) {
                        location = location.parent.parent.parent;
                    }
                    break;
            }
            if (isSelfReferenceLocation(location, lastLocation)) {
                lastSelfReferenceLocation = location;
            }
            lastLocation = location;
            location = (0, ts_js_1.isJSDocTemplateTag)(location) ? getEffectiveContainerForJSDocTemplateTag(location) || location.parent :
                (0, ts_js_1.isJSDocParameterTag)(location) || (0, ts_js_1.isJSDocReturnTag)(location) ? getHostSignatureFromJSDoc(location) || location.parent :
                    location.parent;
        }
        // We just climbed up parents looking for the name, meaning that we started in a descendant node of `lastLocation`.
        // If `result === lastSelfReferenceLocation.symbol`, that means that we are somewhere inside `lastSelfReferenceLocation` looking up a name, and resolving to `lastLocation` itself.
        // That means that this is a self-reference of `lastLocation`, and shouldn't count this when considering whether `lastLocation` is used.
        if (isUse && result && (!lastSelfReferenceLocation || result !== lastSelfReferenceLocation.symbol)) {
            result.isReferenced |= meaning;
        }
        if (!result) {
            if (lastLocation) {
                ts_js_1.Debug.assertNode(lastLocation, ts_js_1.isSourceFile);
                if (lastLocation.commonJsModuleIndicator && name === "exports" && meaning & lastLocation.symbol.flags) {
                    return lastLocation.symbol;
                }
            }
            if (!excludeGlobals) {
                result = lookup(globals, name, meaning);
            }
        }
        if (!result) {
            if (originalLocation && isInJSFile(originalLocation) && originalLocation.parent) {
                if (isRequireCall(originalLocation.parent, /*requireStringLiteralLikeArgument*/ false)) {
                    return requireSymbol;
                }
            }
        }
        if (nameNotFoundMessage) {
            if (propertyWithInvalidInitializer && onPropertyWithInvalidInitializer(originalLocation, name, propertyWithInvalidInitializer, result)) {
                return undefined;
            }
            if (!result) {
                onFailedToResolveSymbol(originalLocation, nameArg, meaning, nameNotFoundMessage);
            }
            else {
                onSuccessfullyResolvedSymbol(originalLocation, result, meaning, lastLocation, associatedDeclarationForContainingInitializerOrBindingName, withinDeferredContext);
            }
        }
        return result;
    }
    function useOuterVariableScopeInParameter(result, location, lastLocation) {
        const target = (0, exports.getEmitScriptTarget)(compilerOptions);
        const functionLocation = location;
        if ((0, ts_js_1.isParameter)(lastLocation)
            && functionLocation.body
            && result.valueDeclaration
            && result.valueDeclaration.pos >= functionLocation.body.pos
            && result.valueDeclaration.end <= functionLocation.body.end) {
            // check for several cases where we introduce temporaries that require moving the name/initializer of the parameter to the body
            // - static field in a class expression
            // - optional chaining pre-es2020
            // - nullish coalesce pre-es2020
            // - spread assignment in binding pattern pre-es2017
            if (target >= 2 /* ScriptTarget.ES2015 */) {
                let declarationRequiresScopeChange = getRequiresScopeChangeCache(functionLocation);
                if (declarationRequiresScopeChange === undefined) {
                    declarationRequiresScopeChange = (0, ts_js_1.forEach)(functionLocation.parameters, requiresScopeChange) || false;
                    setRequiresScopeChangeCache(functionLocation, declarationRequiresScopeChange);
                }
                return !declarationRequiresScopeChange;
            }
        }
        return false;
        function requiresScopeChange(node) {
            return requiresScopeChangeWorker(node.name)
                || !!node.initializer && requiresScopeChangeWorker(node.initializer);
        }
        function requiresScopeChangeWorker(node) {
            switch (node.kind) {
                case 220 /* SyntaxKind.ArrowFunction */:
                case 219 /* SyntaxKind.FunctionExpression */:
                case 263 /* SyntaxKind.FunctionDeclaration */:
                case 177 /* SyntaxKind.Constructor */:
                    // do not descend into these
                    return false;
                case 175 /* SyntaxKind.MethodDeclaration */:
                case 178 /* SyntaxKind.GetAccessor */:
                case 179 /* SyntaxKind.SetAccessor */:
                case 304 /* SyntaxKind.PropertyAssignment */:
                    return requiresScopeChangeWorker(node.name);
                case 173 /* SyntaxKind.PropertyDeclaration */:
                    // static properties in classes introduce temporary variables
                    if (hasStaticModifier(node)) {
                        return !emitStandardClassFields;
                    }
                    return requiresScopeChangeWorker(node.name);
                default:
                    // null coalesce and optional chain pre-es2020 produce temporary variables
                    if ((0, ts_js_1.isNullishCoalesce)(node) || (0, ts_js_1.isOptionalChain)(node)) {
                        return target < 7 /* ScriptTarget.ES2020 */;
                    }
                    if ((0, ts_js_1.isBindingElement)(node) && node.dotDotDotToken && (0, ts_js_1.isObjectBindingPattern)(node.parent)) {
                        return target < 4 /* ScriptTarget.ES2017 */;
                    }
                    if ((0, ts_js_1.isTypeNode)(node))
                        return false;
                    return (0, ts_js_1.forEachChild)(node, requiresScopeChangeWorker) || false;
            }
        }
    }
    function getIsDeferredContext(location, lastLocation) {
        if (location.kind !== 220 /* SyntaxKind.ArrowFunction */ && location.kind !== 219 /* SyntaxKind.FunctionExpression */) {
            // initializers in instance property declaration of class like entities are executed in constructor and thus deferred
            return (0, ts_js_1.isTypeQueryNode)(location) || (((0, ts_js_1.isFunctionLikeDeclaration)(location) ||
                (location.kind === 173 /* SyntaxKind.PropertyDeclaration */ && !isStatic(location))) && (!lastLocation || lastLocation !== location.name)); // A name is evaluated within the enclosing scope - so it shouldn't count as deferred
        }
        if (lastLocation && lastLocation === location.name) {
            return false;
        }
        // generator functions and async functions are not inlined in control flow when immediately invoked
        if (location.asteriskToken || hasSyntacticModifier(location, 1024 /* ModifierFlags.Async */)) {
            return true;
        }
        return !getImmediatelyInvokedFunctionExpression(location);
    }
    function isSelfReferenceLocation(node, lastLocation) {
        switch (node.kind) {
            case 170 /* SyntaxKind.Parameter */:
                return !!lastLocation && lastLocation === node.name;
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 265 /* SyntaxKind.InterfaceDeclaration */:
            case 267 /* SyntaxKind.EnumDeclaration */:
            case 266 /* SyntaxKind.TypeAliasDeclaration */:
            case 268 /* SyntaxKind.ModuleDeclaration */: // For `namespace N { N; }`
                return true;
            default:
                return false;
        }
    }
    function isTypeParameterSymbolDeclaredInContainer(symbol, container) {
        if (symbol.declarations) {
            for (const decl of symbol.declarations) {
                if (decl.kind === 169 /* SyntaxKind.TypeParameter */) {
                    const parent = (0, ts_js_1.isJSDocTemplateTag)(decl.parent) ? getJSDocHost(decl.parent) : decl.parent;
                    if (parent === container) {
                        return !((0, ts_js_1.isJSDocTemplateTag)(decl.parent) && (0, ts_js_1.find)(decl.parent.parent.tags, isJSDocTypeAlias));
                    }
                }
            }
        }
        return false;
    }
}
/** @internal */
function isPrimitiveLiteralValue(node, includeBigInt = true) {
    switch (node.kind) {
        case 112 /* SyntaxKind.TrueKeyword */:
        case 97 /* SyntaxKind.FalseKeyword */:
        case 9 /* SyntaxKind.NumericLiteral */:
        case 11 /* SyntaxKind.StringLiteral */:
        case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
            return true;
        case 10 /* SyntaxKind.BigIntLiteral */:
            return includeBigInt;
        case 225 /* SyntaxKind.PrefixUnaryExpression */:
            ts_js_1.Debug.assert((0, ts_js_1.isPrefixUnaryExpression)(node));
            if (node.operator === 41 /* SyntaxKind.MinusToken */) {
                return (0, ts_js_1.isNumericLiteral)(node.operand) || (includeBigInt && (0, ts_js_1.isBigIntLiteral)(node.operand));
            }
            if (node.operator === 40 /* SyntaxKind.PlusToken */) {
                return (0, ts_js_1.isNumericLiteral)(node.operand);
            }
            return false;
        default:
            (0, ts_js_1.assertType)(node.kind);
            return false;
    }
}
/** @internal */
function unwrapParenthesizedExpression(o) {
    while (o.kind === 218 /* SyntaxKind.ParenthesizedExpression */) {
        o = o.expression;
    }
    return o;
}
/** @internal */
function hasInferredType(node) {
    switch (node.kind) {
        case 170 /* SyntaxKind.Parameter */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 209 /* SyntaxKind.BindingElement */:
        case 212 /* SyntaxKind.PropertyAccessExpression */:
        case 213 /* SyntaxKind.ElementAccessExpression */:
        case 227 /* SyntaxKind.BinaryExpression */:
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 278 /* SyntaxKind.ExportAssignment */:
        case 304 /* SyntaxKind.PropertyAssignment */:
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
        case 342 /* SyntaxKind.JSDocParameterTag */:
        case 349 /* SyntaxKind.JSDocPropertyTag */:
            return true;
        default:
            (0, ts_js_1.assertType)(node.kind);
            return false;
    }
}
/** @internal */
function isSideEffectImport(node) {
    const ancestor = (0, ts_js_1.findAncestor)(node, ts_js_1.isImportDeclaration);
    return !!ancestor && !ancestor.importClause;
}
// require('module').builtinModules.filter(x => !x.match(/^(?:_|node:)/))
const unprefixedNodeCoreModulesList = [
    "assert",
    "assert/strict",
    "async_hooks",
    "buffer",
    "child_process",
    "cluster",
    "console",
    "constants",
    "crypto",
    "dgram",
    "diagnostics_channel",
    "dns",
    "dns/promises",
    "domain",
    "events",
    "fs",
    "fs/promises",
    "http",
    "http2",
    "https",
    "inspector",
    "inspector/promises",
    "module",
    "net",
    "os",
    "path",
    "path/posix",
    "path/win32",
    "perf_hooks",
    "process",
    "punycode",
    "querystring",
    "readline",
    "readline/promises",
    "repl",
    "stream",
    "stream/consumers",
    "stream/promises",
    "stream/web",
    "string_decoder",
    "sys",
    "timers",
    "timers/promises",
    "tls",
    "trace_events",
    "tty",
    "url",
    "util",
    "util/types",
    "v8",
    "vm",
    "wasi",
    "worker_threads",
    "zlib",
];
/** @internal */
exports.unprefixedNodeCoreModules = new Set(unprefixedNodeCoreModulesList);
// require('module').builtinModules.filter(x => x.startsWith('node:'))
/** @internal */
exports.exclusivelyPrefixedNodeCoreModules = new Set([
    "node:quic",
    "node:sea",
    "node:sqlite",
    "node:test",
    "node:test/reporters",
]);
/** @internal */
exports.nodeCoreModules = new Set([
    ...unprefixedNodeCoreModulesList,
    ...unprefixedNodeCoreModulesList.map(name => `node:${name}`),
    ...exports.exclusivelyPrefixedNodeCoreModules,
]);
/** @internal */
function forEachDynamicImportOrRequireCall(file, includeTypeSpaceImports, requireStringLiteralLikeArgument, cb) {
    const isJavaScriptFile = isInJSFile(file);
    const r = /import|require/g;
    while (r.exec(file.text) !== null) { // eslint-disable-line no-restricted-syntax
        const node = getNodeAtPosition(file, r.lastIndex, /*includeJSDoc*/ includeTypeSpaceImports);
        if (isJavaScriptFile && isRequireCall(node, requireStringLiteralLikeArgument)) {
            cb(node, node.arguments[0]);
        }
        else if (isImportCall(node) && node.arguments.length >= 1 && (!requireStringLiteralLikeArgument || (0, ts_js_1.isStringLiteralLike)(node.arguments[0]))) {
            cb(node, node.arguments[0]);
        }
        else if (includeTypeSpaceImports && isLiteralImportTypeNode(node)) {
            cb(node, node.argument.literal);
        }
        else if (includeTypeSpaceImports && (0, ts_js_1.isJSDocImportTag)(node)) {
            const moduleNameExpr = getExternalModuleName(node);
            if (moduleNameExpr && (0, ts_js_1.isStringLiteral)(moduleNameExpr) && moduleNameExpr.text) {
                cb(node, moduleNameExpr);
            }
        }
    }
}
/** Returns a token if position is in [start-of-leading-trivia, end), includes JSDoc only in JS files */
function getNodeAtPosition(sourceFile, position, includeJSDoc) {
    const isJavaScriptFile = isInJSFile(sourceFile);
    let current = sourceFile;
    const getContainingChild = (child) => {
        if (child.pos <= position && (position < child.end || (position === child.end && (child.kind === 1 /* SyntaxKind.EndOfFileToken */)))) {
            return child;
        }
    };
    while (true) {
        const child = isJavaScriptFile && includeJSDoc && (0, ts_js_1.hasJSDocNodes)(current) && (0, ts_js_1.forEach)(current.jsDoc, getContainingChild) || (0, ts_js_1.forEachChild)(current, getContainingChild);
        if (!child || (0, ts_js_1.isMetaProperty)(child)) {
            return current;
        }
        current = child;
    }
}
/** @internal */
function isNewScopeNode(node) {
    return (0, ts_js_1.isFunctionLike)(node)
        || (0, ts_js_1.isJSDocSignature)(node)
        || (0, ts_js_1.isMappedTypeNode)(node);
}
/** @internal */
function getLibNameFromLibReference(libReference) {
    return (0, ts_js_1.toFileNameLowerCase)(libReference.fileName);
}
/** @internal */
function getLibFileNameFromLibReference(libReference) {
    const libName = getLibNameFromLibReference(libReference);
    return ts_js_1.libMap.get(libName);
}
/** @internal */
function forEachResolvedProjectReference(resolvedProjectReferences, cb) {
    return forEachProjectReference(
    /*projectReferences*/ undefined, resolvedProjectReferences, resolvedRef => resolvedRef && cb(resolvedRef));
}
/** @internal */
function forEachProjectReference(projectReferences, resolvedProjectReferences, cbResolvedRef, cbRef) {
    let seenResolvedRefs;
    return worker(projectReferences, resolvedProjectReferences, /*parent*/ undefined);
    function worker(projectReferences, resolvedProjectReferences, parent) {
        // Visit project references first
        if (cbRef) {
            const result = cbRef(projectReferences, parent);
            if (result)
                return result;
        }
        let skipChildren;
        return (0, ts_js_1.forEach)(resolvedProjectReferences, (resolvedRef, index) => {
            if (resolvedRef && seenResolvedRefs?.has(resolvedRef.sourceFile.path)) {
                (skipChildren ?? (skipChildren = new Set())).add(resolvedRef);
                // ignore recursives
                return undefined;
            }
            const result = cbResolvedRef(resolvedRef, parent, index);
            if (result || !resolvedRef)
                return result;
            (seenResolvedRefs || (seenResolvedRefs = new Set())).add(resolvedRef.sourceFile.path);
        }) || (0, ts_js_1.forEach)(resolvedProjectReferences, resolvedRef => resolvedRef && !skipChildren?.has(resolvedRef) ?
            worker(resolvedRef.commandLine.projectReferences, resolvedRef.references, resolvedRef) :
            undefined);
    }
}
/** @internal */
function getOptionsSyntaxByArrayElementValue(optionsObject, name, value) {
    return optionsObject && getPropertyArrayElementValue(optionsObject, name, value);
}
function getPropertyArrayElementValue(objectLiteral, propKey, elementValue) {
    return forEachPropertyAssignment(objectLiteral, propKey, property => (0, ts_js_1.isArrayLiteralExpression)(property.initializer) ?
        (0, ts_js_1.find)(property.initializer.elements, (element) => (0, ts_js_1.isStringLiteral)(element) && element.text === elementValue) :
        undefined);
}
/** @internal */
function getOptionsSyntaxByValue(optionsObject, name, value) {
    return forEachOptionsSyntaxByName(optionsObject, name, property => (0, ts_js_1.isStringLiteral)(property.initializer) && property.initializer.text === value ? property.initializer : undefined);
}
/** @internal */
function forEachOptionsSyntaxByName(optionsObject, name, callback) {
    return forEachPropertyAssignment(optionsObject, name, callback);
}
/**
 * Creates a deep, memberwise clone of a node with no source map location.
 *
 * WARNING: This is an expensive operation and is only intended to be used in refactorings
 * and code fixes (because those are triggered by explicit user actions).
 *
 * @internal
 */
// Moved here to compiler utilities for usage in node builder for quickinfo.
function getSynthesizedDeepClone(node, includeTrivia = true) {
    const clone = node && getSynthesizedDeepCloneWorker(node);
    if (clone && !includeTrivia)
        suppressLeadingAndTrailingTrivia(clone);
    return setParentRecursive(clone, /*incremental*/ false);
}
/** @internal */
function getSynthesizedDeepCloneWithReplacements(node, includeTrivia, replaceNode) {
    let clone = replaceNode(node);
    if (clone) {
        (0, ts_js_1.setOriginalNode)(clone, node);
    }
    else {
        clone = getSynthesizedDeepCloneWorker(node, replaceNode);
    }
    if (clone && !includeTrivia)
        suppressLeadingAndTrailingTrivia(clone);
    return clone;
}
function getSynthesizedDeepCloneWorker(node, replaceNode) {
    const nodeClone = replaceNode
        ? n => getSynthesizedDeepCloneWithReplacements(n, /*includeTrivia*/ true, replaceNode)
        : getSynthesizedDeepClone;
    const nodesClone = replaceNode
        ? ns => ns && getSynthesizedDeepClonesWithReplacements(ns, /*includeTrivia*/ true, replaceNode)
        : ns => ns && getSynthesizedDeepClones(ns);
    const visited = (0, ts_js_1.visitEachChild)(node, nodeClone, /*context*/ undefined, nodesClone, nodeClone);
    if (visited === node) {
        // This only happens for leaf nodes - internal nodes always see their children change.
        const clone = (0, ts_js_1.isStringLiteral)(node) ? (0, ts_js_1.setOriginalNode)(ts_js_1.factory.createStringLiteralFromNode(node), node) :
            (0, ts_js_1.isNumericLiteral)(node) ? (0, ts_js_1.setOriginalNode)(ts_js_1.factory.createNumericLiteral(node.text, node.numericLiteralFlags), node) :
                ts_js_1.factory.cloneNode(node);
        return (0, ts_js_1.setTextRange)(clone, node);
    }
    // PERF: As an optimization, rather than calling factory.cloneNode, we'll update
    // the new node created by visitEachChild with the extra changes factory.cloneNode
    // would have made.
    visited.parent = undefined;
    return visited;
}
/** @internal */
function getSynthesizedDeepClones(nodes, includeTrivia = true) {
    if (nodes) {
        const cloned = ts_js_1.factory.createNodeArray(nodes.map(n => getSynthesizedDeepClone(n, includeTrivia)), nodes.hasTrailingComma);
        (0, ts_js_1.setTextRange)(cloned, nodes);
        return cloned;
    }
    return nodes;
}
/** @internal */
function getSynthesizedDeepClonesWithReplacements(nodes, includeTrivia, replaceNode) {
    return ts_js_1.factory.createNodeArray(nodes.map(n => getSynthesizedDeepCloneWithReplacements(n, includeTrivia, replaceNode)), nodes.hasTrailingComma);
}
/**
 * Sets EmitFlags to suppress leading and trailing trivia on the node.
 *
 * @internal
 */
function suppressLeadingAndTrailingTrivia(node) {
    suppressLeadingTrivia(node);
    suppressTrailingTrivia(node);
}
/**
 * Sets EmitFlags to suppress leading trivia on the node.
 *
 * @internal
 */
function suppressLeadingTrivia(node) {
    addEmitFlagsRecursively(node, 1024 /* EmitFlags.NoLeadingComments */, getFirstChild);
}
/**
 * Sets EmitFlags to suppress trailing trivia on the node.
 *
 * @internal @knipignore
 */
function suppressTrailingTrivia(node) {
    addEmitFlagsRecursively(node, 2048 /* EmitFlags.NoTrailingComments */, getLastChild);
}
function addEmitFlagsRecursively(node, flag, getChild) {
    (0, ts_js_1.addEmitFlags)(node, flag);
    const child = getChild(node);
    if (child)
        addEmitFlagsRecursively(child, flag, getChild);
}
function getFirstChild(node) {
    return (0, ts_js_1.forEachChild)(node, child => child);
}
/** @internal */
function canHaveStatements(node) {
    return (0, ts_js_1.isBlock)(node) || (0, ts_js_1.isModuleBlock)(node) || (0, ts_js_1.isSourceFile)(node) || (0, ts_js_1.isCaseClause)(node) || (0, ts_js_1.isDefaultClause)(node);
}
/** @internal */
function isPotentiallyExecutableNode(node) {
    if (244 /* SyntaxKind.FirstStatement */ <= node.kind && node.kind <= 260 /* SyntaxKind.LastStatement */) {
        if ((0, ts_js_1.isVariableStatement)(node)) {
            if ((0, ts_js_1.getCombinedNodeFlags)(node.declarationList) & 7 /* NodeFlags.BlockScoped */) {
                return true;
            }
            return (0, ts_js_1.some)(node.declarationList.declarations, d => d.initializer !== undefined);
        }
        return true;
    }
    return (0, ts_js_1.isClassDeclaration)(node) || (0, ts_js_1.isEnumDeclaration)(node) || (0, ts_js_1.isModuleDeclaration)(node);
}
