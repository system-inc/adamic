"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGetSymbolWalker = createGetSymbolWalker;
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
function createGetSymbolWalker(getRestTypeOfSignature, getTypePredicateOfSignature, getReturnTypeOfSignature, getBaseTypes, resolveStructuredTypeMembers, getTypeOfSymbol, getResolvedSymbol, getConstraintOfTypeParameter, getFirstIdentifier, getTypeArguments) {
    return getSymbolWalker;
    function getSymbolWalker(accept = () => true) {
        const visitedTypes = {}; // Record from id to type
        const visitedSymbols = {}; // Record from id to symbol
        return {
            walkType: type => {
                try {
                    visitType(type);
                    return { visitedTypes: (0, ts_js_1.getOwnValues)(visitedTypes), visitedSymbols: (0, ts_js_1.getOwnValues)(visitedSymbols) };
                }
                finally {
                    for (const key in visitedTypes)
                        delete visitedTypes[key];
                    for (const key in visitedSymbols)
                        delete visitedSymbols[key];
                }
            },
            walkSymbol: symbol => {
                try {
                    visitSymbol(symbol);
                    return { visitedTypes: (0, ts_js_1.getOwnValues)(visitedTypes), visitedSymbols: (0, ts_js_1.getOwnValues)(visitedSymbols) };
                }
                finally {
                    for (const key in visitedTypes)
                        delete visitedTypes[key];
                    for (const key in visitedSymbols)
                        delete visitedSymbols[key];
                }
            },
        };
        function visitType(type) {
            if (!type) {
                return;
            }
            if (visitedTypes[type.id]) {
                return;
            }
            visitedTypes[type.id] = type;
            // Reuse visitSymbol to visit the type's symbol,
            //  but be sure to bail on recuring into the type if accept declines the symbol.
            const shouldBail = visitSymbol(type.symbol);
            if (shouldBail)
                return;
            // Visit the type's related types, if any
            if (type.flags & 1048576 /* TypeFlags.Object */) {
                const objectType = type;
                const objectFlags = objectType.objectFlags;
                if (objectFlags & 4 /* ObjectFlags.Reference */) {
                    visitTypeReference(type);
                }
                if (objectFlags & 32 /* ObjectFlags.Mapped */) {
                    visitMappedType(type);
                }
                if (objectFlags & (1 /* ObjectFlags.Class */ | 2 /* ObjectFlags.Interface */)) {
                    visitInterfaceType(type);
                }
                if (objectFlags & (8 /* ObjectFlags.Tuple */ | 16 /* ObjectFlags.Anonymous */)) {
                    visitObjectType(objectType);
                }
            }
            if (type.flags & 524288 /* TypeFlags.TypeParameter */) {
                visitTypeParameter(type);
            }
            if (type.flags & 402653184 /* TypeFlags.UnionOrIntersection */) {
                visitUnionOrIntersectionType(type);
            }
            if (type.flags & 2097152 /* TypeFlags.Index */) {
                visitIndexType(type);
            }
            if (type.flags & 33554432 /* TypeFlags.IndexedAccess */) {
                visitIndexedAccessType(type);
            }
        }
        function visitTypeReference(type) {
            visitType(type.target);
            (0, ts_js_1.forEach)(getTypeArguments(type), visitType);
        }
        function visitTypeParameter(type) {
            visitType(getConstraintOfTypeParameter(type));
        }
        function visitUnionOrIntersectionType(type) {
            (0, ts_js_1.forEach)(type.types, visitType);
        }
        function visitIndexType(type) {
            visitType(type.type);
        }
        function visitIndexedAccessType(type) {
            visitType(type.objectType);
            visitType(type.indexType);
            visitType(type.constraint);
        }
        function visitMappedType(type) {
            visitType(type.typeParameter);
            visitType(type.constraintType);
            visitType(type.templateType);
            visitType(type.modifiersType);
        }
        function visitSignature(signature) {
            const typePredicate = getTypePredicateOfSignature(signature);
            if (typePredicate) {
                visitType(typePredicate.type);
            }
            (0, ts_js_1.forEach)(signature.typeParameters, visitType);
            for (const parameter of signature.parameters) {
                visitSymbol(parameter);
            }
            visitType(getRestTypeOfSignature(signature));
            visitType(getReturnTypeOfSignature(signature));
        }
        function visitInterfaceType(interfaceT) {
            visitObjectType(interfaceT);
            (0, ts_js_1.forEach)(interfaceT.typeParameters, visitType);
            (0, ts_js_1.forEach)(getBaseTypes(interfaceT), visitType);
            visitType(interfaceT.thisType);
        }
        function visitObjectType(type) {
            const resolved = resolveStructuredTypeMembers(type);
            for (const info of resolved.indexInfos) {
                visitType(info.keyType);
                visitType(info.type);
            }
            for (const signature of resolved.callSignatures) {
                visitSignature(signature);
            }
            for (const signature of resolved.constructSignatures) {
                visitSignature(signature);
            }
            for (const p of resolved.properties) {
                visitSymbol(p);
            }
        }
        function visitSymbol(symbol) {
            if (!symbol) {
                return false;
            }
            const symbolId = (0, ts_js_1.getSymbolId)(symbol);
            if (visitedSymbols[symbolId]) {
                return false;
            }
            visitedSymbols[symbolId] = symbol;
            if (!accept(symbol)) {
                return true;
            }
            const t = getTypeOfSymbol(symbol);
            visitType(t); // Should handle members on classes and such
            if (symbol.exports) {
                symbol.exports.forEach(visitSymbol);
            }
            (0, ts_js_1.forEach)(symbol.declarations, d => {
                // Type queries are too far resolved when we just visit the symbol's type
                //  (their type resolved directly to the member deeply referenced)
                // So to get the intervening symbols, we need to check if there's a type
                // query node on any of the symbol's declarations and get symbols there
                if (d.type && d.type.kind === 187 /* SyntaxKind.TypeQuery */) {
                    const query = d.type;
                    const entity = getResolvedSymbol(getFirstIdentifier(query.exprName));
                    visitSymbol(entity);
                }
            });
            return false;
        }
    }
}
