"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdentifierNameMap = void 0;
exports.getOriginalNodeId = getOriginalNodeId;
exports.chainBundle = chainBundle;
exports.getExportNeedsImportStarHelper = getExportNeedsImportStarHelper;
exports.getImportNeedsImportStarHelper = getImportNeedsImportStarHelper;
exports.getImportNeedsImportDefaultHelper = getImportNeedsImportDefaultHelper;
exports.collectExternalModuleInfo = collectExternalModuleInfo;
exports.isSimpleCopiableExpression = isSimpleCopiableExpression;
exports.isSimpleInlineableExpression = isSimpleInlineableExpression;
exports.isCompoundAssignment = isCompoundAssignment;
exports.getNonAssignmentOperatorForCompoundAssignment = getNonAssignmentOperatorForCompoundAssignment;
exports.getSuperCallFromStatement = getSuperCallFromStatement;
exports.findSuperStatementIndexPath = findSuperStatementIndexPath;
exports.getProperties = getProperties;
exports.getStaticPropertiesAndClassStaticBlock = getStaticPropertiesAndClassStaticBlock;
exports.isInitializedProperty = isInitializedProperty;
exports.isNonStaticMethodOrAccessorWithPrivateName = isNonStaticMethodOrAccessorWithPrivateName;
exports.getAllDecoratorsOfClass = getAllDecoratorsOfClass;
exports.getAllDecoratorsOfClassElement = getAllDecoratorsOfClassElement;
exports.newPrivateEnvironment = newPrivateEnvironment;
exports.getPrivateIdentifier = getPrivateIdentifier;
exports.setPrivateIdentifier = setPrivateIdentifier;
exports.accessPrivateIdentifier = accessPrivateIdentifier;
exports.isSimpleParameterList = isSimpleParameterList;
exports.rewriteModuleSpecifier = rewriteModuleSpecifier;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function getOriginalNodeId(node) {
    node = (0, ts_js_1.getOriginalNode)(node);
    return node ? (0, ts_js_1.getNodeId)(node) : 0;
}
function containsDefaultReference(node) {
    if (!node)
        return false;
    if (!(0, ts_js_1.isNamedImports)(node) && !(0, ts_js_1.isNamedExports)(node))
        return false;
    return (0, ts_js_1.some)(node.elements, isNamedDefaultReference);
}
function isNamedDefaultReference(e) {
    return (0, ts_js_1.moduleExportNameIsDefault)(e.propertyName || e.name);
}
/** @internal */
function chainBundle(context, transformSourceFile) {
    return transformSourceFileOrBundle;
    function transformSourceFileOrBundle(node) {
        return node.kind === 308 /* SyntaxKind.SourceFile */ ? transformSourceFile(node) : transformBundle(node);
    }
    function transformBundle(node) {
        return context.factory.createBundle((0, ts_js_1.map)(node.sourceFiles, transformSourceFile));
    }
}
/** @internal */
function getExportNeedsImportStarHelper(node) {
    return !!(0, ts_js_1.getNamespaceDeclarationNode)(node);
}
/** @internal */
function getImportNeedsImportStarHelper(node) {
    if (!!(0, ts_js_1.getNamespaceDeclarationNode)(node)) {
        return true;
    }
    const bindings = node.importClause && node.importClause.namedBindings;
    if (!bindings) {
        return false;
    }
    if (!(0, ts_js_1.isNamedImports)(bindings))
        return false;
    let defaultRefCount = 0;
    for (const binding of bindings.elements) {
        if (isNamedDefaultReference(binding)) {
            defaultRefCount++;
        }
    }
    // Import star is required if there's default named refs mixed with non-default refs, or if theres non-default refs and it has a default import
    return (defaultRefCount > 0 && defaultRefCount !== bindings.elements.length) || (!!(bindings.elements.length - defaultRefCount) && (0, ts_js_1.isDefaultImport)(node));
}
/** @internal */
function getImportNeedsImportDefaultHelper(node) {
    // Import default is needed if there's a default import or a default ref and no other refs (meaning an import star helper wasn't requested)
    return !getImportNeedsImportStarHelper(node) && ((0, ts_js_1.isDefaultImport)(node) || (!!node.importClause && (0, ts_js_1.isNamedImports)(node.importClause.namedBindings) && containsDefaultReference(node.importClause.namedBindings))); // TODO: GH#18217
}
/** @internal */
function collectExternalModuleInfo(context, sourceFile) {
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const externalImports = [];
    const exportSpecifiers = new IdentifierNameMultiMap();
    const exportedBindings = [];
    const uniqueExports = new Map();
    const exportedFunctions = new Set();
    let exportedNames;
    let hasExportDefault = false;
    let exportEquals;
    let hasExportStarsToExportValues = false;
    let hasImportStar = false;
    let hasImportDefault = false;
    for (const node of sourceFile.statements) {
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
                // import "mod"
                // import x from "mod"
                // import * as x from "mod"
                // import { x, y } from "mod"
                externalImports.push(node);
                if (!hasImportStar && getImportNeedsImportStarHelper(node)) {
                    hasImportStar = true;
                }
                if (!hasImportDefault && getImportNeedsImportDefaultHelper(node)) {
                    hasImportDefault = true;
                }
                break;
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                if (node.moduleReference.kind === 284 /* SyntaxKind.ExternalModuleReference */) {
                    // import x = require("mod")
                    externalImports.push(node);
                }
                break;
            case 279 /* SyntaxKind.ExportDeclaration */:
                if (node.moduleSpecifier) {
                    if (!node.exportClause) {
                        // export * from "mod"
                        externalImports.push(node);
                        hasExportStarsToExportValues = true;
                    }
                    else {
                        // export * as ns from "mod"
                        // export { x, y } from "mod"
                        externalImports.push(node);
                        if ((0, ts_js_1.isNamedExports)(node.exportClause)) {
                            addExportedNamesForExportDeclaration(node);
                            hasImportDefault || (hasImportDefault = containsDefaultReference(node.exportClause));
                        }
                        else {
                            const name = node.exportClause.name;
                            const nameText = (0, ts_js_1.moduleExportNameTextUnescaped)(name);
                            if (!uniqueExports.get(nameText)) {
                                multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(node), name);
                                uniqueExports.set(nameText, true);
                                exportedNames = (0, ts_js_1.append)(exportedNames, name);
                            }
                            // we use the same helpers for `export * as ns` as we do for `import * as ns`
                            hasImportStar = true;
                        }
                    }
                }
                else {
                    // export { x, y }
                    addExportedNamesForExportDeclaration(node);
                }
                break;
            case 278 /* SyntaxKind.ExportAssignment */:
                if (node.isExportEquals && !exportEquals) {
                    // export = x
                    exportEquals = node;
                }
                break;
            case 244 /* SyntaxKind.VariableStatement */:
                if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
                    for (const decl of node.declarationList.declarations) {
                        exportedNames = collectExportedVariableInfo(decl, uniqueExports, exportedNames, exportedBindings);
                    }
                }
                break;
            case 263 /* SyntaxKind.FunctionDeclaration */:
                if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
                    addExportedFunctionDeclaration(node, /*name*/ undefined, (0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */));
                }
                break;
            case 264 /* SyntaxKind.ClassDeclaration */:
                if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
                    if ((0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */)) {
                        // export default class { }
                        if (!hasExportDefault) {
                            multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(node), context.factory.getDeclarationName(node));
                            hasExportDefault = true;
                        }
                    }
                    else {
                        // export class x { }
                        const name = node.name;
                        if (name && !uniqueExports.get((0, ts_js_1.idText)(name))) {
                            multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(node), name);
                            uniqueExports.set((0, ts_js_1.idText)(name), true);
                            exportedNames = (0, ts_js_1.append)(exportedNames, name);
                        }
                    }
                }
                break;
        }
    }
    const externalHelpersImportDeclaration = (0, ts_js_1.createExternalHelpersImportDeclarationIfNeeded)(context.factory, context.getEmitHelperFactory(), sourceFile, compilerOptions, hasExportStarsToExportValues, hasImportStar, hasImportDefault);
    if (externalHelpersImportDeclaration) {
        externalImports.unshift(externalHelpersImportDeclaration);
    }
    return { externalImports, exportSpecifiers, exportEquals, hasExportStarsToExportValues, exportedBindings, exportedNames, exportedFunctions, externalHelpersImportDeclaration };
    function addExportedNamesForExportDeclaration(node) {
        for (const specifier of (0, ts_js_1.cast)(node.exportClause, ts_js_1.isNamedExports).elements) {
            const specifierNameText = (0, ts_js_1.moduleExportNameTextUnescaped)(specifier.name);
            if (!uniqueExports.get(specifierNameText)) {
                const name = specifier.propertyName || specifier.name;
                if (name.kind !== 11 /* SyntaxKind.StringLiteral */) {
                    if (!node.moduleSpecifier) {
                        exportSpecifiers.add(name, specifier);
                    }
                    const decl = resolver.getReferencedImportDeclaration(name)
                        || resolver.getReferencedValueDeclaration(name);
                    if (decl) {
                        if (decl.kind === 263 /* SyntaxKind.FunctionDeclaration */) {
                            addExportedFunctionDeclaration(decl, specifier.name, (0, ts_js_1.moduleExportNameIsDefault)(specifier.name));
                            continue;
                        }
                        multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(decl), specifier.name);
                    }
                }
                uniqueExports.set(specifierNameText, true);
                exportedNames = (0, ts_js_1.append)(exportedNames, specifier.name);
            }
        }
    }
    function addExportedFunctionDeclaration(node, name, isDefault) {
        exportedFunctions.add((0, ts_js_1.getOriginalNode)(node, ts_js_1.isFunctionDeclaration));
        if (isDefault) {
            // export default function() { }
            // function x() { } + export { x as default };
            if (!hasExportDefault) {
                multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(node), name ?? context.factory.getDeclarationName(node));
                hasExportDefault = true;
            }
        }
        else {
            // export function x() { }
            // function x() { } + export { x }
            name ?? (name = node.name);
            const nameText = (0, ts_js_1.moduleExportNameTextUnescaped)(name);
            if (!uniqueExports.get(nameText)) {
                multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(node), name);
                uniqueExports.set(nameText, true);
            }
        }
    }
}
function collectExportedVariableInfo(decl, uniqueExports, exportedNames, exportedBindings) {
    if ((0, ts_js_1.isBindingPattern)(decl.name)) {
        for (const element of decl.name.elements) {
            if (!(0, ts_js_1.isOmittedExpression)(element)) {
                exportedNames = collectExportedVariableInfo(element, uniqueExports, exportedNames, exportedBindings);
            }
        }
    }
    else if (!(0, ts_js_1.isGeneratedIdentifier)(decl.name)) {
        const text = (0, ts_js_1.idText)(decl.name);
        if (!uniqueExports.get(text)) {
            uniqueExports.set(text, true);
            exportedNames = (0, ts_js_1.append)(exportedNames, decl.name);
            if ((0, ts_js_1.isLocalName)(decl.name)) {
                multiMapSparseArrayAdd(exportedBindings, getOriginalNodeId(decl), decl.name);
            }
        }
    }
    return exportedNames;
}
/** Use a sparse array as a multi-map. */
function multiMapSparseArrayAdd(map, key, value) {
    let values = map[key];
    if (values) {
        values.push(value);
    }
    else {
        map[key] = values = [value];
    }
    return values;
}
/** @internal */
class IdentifierNameMap {
    constructor() {
        this._map = new Map();
    }
    get size() {
        return this._map.size;
    }
    has(key) {
        return this._map.has(IdentifierNameMap.toKey(key));
    }
    get(key) {
        return this._map.get(IdentifierNameMap.toKey(key));
    }
    set(key, value) {
        this._map.set(IdentifierNameMap.toKey(key), value);
        return this;
    }
    delete(key) {
        return this._map?.delete(IdentifierNameMap.toKey(key)) ?? false;
    }
    clear() {
        this._map.clear();
    }
    values() {
        return this._map.values();
    }
    static toKey(name) {
        if ((0, ts_js_1.isGeneratedPrivateIdentifier)(name) || (0, ts_js_1.isGeneratedIdentifier)(name)) {
            const autoGenerate = name.emitNode.autoGenerate;
            if ((autoGenerate.flags & 7 /* GeneratedIdentifierFlags.KindMask */) === 4 /* GeneratedIdentifierFlags.Node */) {
                const node = (0, ts_js_1.getNodeForGeneratedName)(name);
                const baseName = (0, ts_js_1.isMemberName)(node) && node !== name ? IdentifierNameMap.toKey(node) : `(generated@${(0, ts_js_1.getNodeId)(node)})`;
                return (0, ts_js_1.formatGeneratedName)(/*privateName*/ false, autoGenerate.prefix, baseName, autoGenerate.suffix, IdentifierNameMap.toKey);
            }
            else {
                const baseName = `(auto@${autoGenerate.id})`;
                return (0, ts_js_1.formatGeneratedName)(/*privateName*/ false, autoGenerate.prefix, baseName, autoGenerate.suffix, IdentifierNameMap.toKey);
            }
        }
        if ((0, ts_js_1.isPrivateIdentifier)(name)) {
            return (0, ts_js_1.idText)(name).slice(1);
        }
        return (0, ts_js_1.idText)(name);
    }
}
exports.IdentifierNameMap = IdentifierNameMap;
class IdentifierNameMultiMap extends IdentifierNameMap {
    add(key, value) {
        let values = this.get(key);
        if (values) {
            values.push(value);
        }
        else {
            this.set(key, values = [value]);
        }
        return values;
    }
    remove(key, value) {
        const values = this.get(key);
        if (values) {
            (0, ts_js_1.unorderedRemoveItem)(values, value);
            if (!values.length) {
                this.delete(key);
            }
        }
    }
}
/**
 * Used in the module transformer to check if an expression is reasonably without sideeffect,
 *  and thus better to copy into multiple places rather than to cache in a temporary variable
 *  - this is mostly subjective beyond the requirement that the expression not be sideeffecting
 *
 * @internal
 */
function isSimpleCopiableExpression(expression) {
    return (0, ts_js_1.isStringLiteralLike)(expression) ||
        expression.kind === 9 /* SyntaxKind.NumericLiteral */ ||
        (0, ts_js_1.isKeyword)(expression.kind) ||
        (0, ts_js_1.isIdentifier)(expression);
}
/**
 * A simple inlinable expression is an expression which can be copied into multiple locations
 * without risk of repeating any sideeffects and whose value could not possibly change between
 * any such locations
 *
 * @internal
 */
function isSimpleInlineableExpression(expression) {
    return !(0, ts_js_1.isIdentifier)(expression) && isSimpleCopiableExpression(expression);
}
/** @internal */
function isCompoundAssignment(kind) {
    return kind >= 65 /* SyntaxKind.FirstCompoundAssignment */
        && kind <= 79 /* SyntaxKind.LastCompoundAssignment */;
}
/** @internal */
function getNonAssignmentOperatorForCompoundAssignment(kind) {
    switch (kind) {
        case 65 /* SyntaxKind.PlusEqualsToken */:
            return 40 /* SyntaxKind.PlusToken */;
        case 66 /* SyntaxKind.MinusEqualsToken */:
            return 41 /* SyntaxKind.MinusToken */;
        case 67 /* SyntaxKind.AsteriskEqualsToken */:
            return 42 /* SyntaxKind.AsteriskToken */;
        case 68 /* SyntaxKind.AsteriskAsteriskEqualsToken */:
            return 43 /* SyntaxKind.AsteriskAsteriskToken */;
        case 69 /* SyntaxKind.SlashEqualsToken */:
            return 44 /* SyntaxKind.SlashToken */;
        case 70 /* SyntaxKind.PercentEqualsToken */:
            return 45 /* SyntaxKind.PercentToken */;
        case 71 /* SyntaxKind.LessThanLessThanEqualsToken */:
            return 48 /* SyntaxKind.LessThanLessThanToken */;
        case 72 /* SyntaxKind.GreaterThanGreaterThanEqualsToken */:
            return 49 /* SyntaxKind.GreaterThanGreaterThanToken */;
        case 73 /* SyntaxKind.GreaterThanGreaterThanGreaterThanEqualsToken */:
            return 50 /* SyntaxKind.GreaterThanGreaterThanGreaterThanToken */;
        case 74 /* SyntaxKind.AmpersandEqualsToken */:
            return 51 /* SyntaxKind.AmpersandToken */;
        case 75 /* SyntaxKind.BarEqualsToken */:
            return 52 /* SyntaxKind.BarToken */;
        case 79 /* SyntaxKind.CaretEqualsToken */:
            return 53 /* SyntaxKind.CaretToken */;
        case 76 /* SyntaxKind.BarBarEqualsToken */:
            return 57 /* SyntaxKind.BarBarToken */;
        case 77 /* SyntaxKind.AmpersandAmpersandEqualsToken */:
            return 56 /* SyntaxKind.AmpersandAmpersandToken */;
        case 78 /* SyntaxKind.QuestionQuestionEqualsToken */:
            return 61 /* SyntaxKind.QuestionQuestionToken */;
    }
}
/**
 * @returns Contained super() call from descending into the statement ignoring parentheses, if that call exists.
 *
 * @internal
 */
function getSuperCallFromStatement(statement) {
    if (!(0, ts_js_1.isExpressionStatement)(statement)) {
        return undefined;
    }
    const expression = (0, ts_js_1.skipParentheses)(statement.expression);
    return (0, ts_js_1.isSuperCall)(expression)
        ? expression
        : undefined;
}
function findSuperStatementIndexPathWorker(statements, start, indices) {
    for (let i = start; i < statements.length; i += 1) {
        const statement = statements[i];
        if (getSuperCallFromStatement(statement)) {
            indices.unshift(i);
            return true;
        }
        else if ((0, ts_js_1.isTryStatement)(statement) && findSuperStatementIndexPathWorker(statement.tryBlock.statements, 0, indices)) {
            indices.unshift(i);
            return true;
        }
    }
    return false;
}
/**
 * Finds a path of indices to navigate to a `super()` call, descending only through `try` statements.
 *
 * @returns An array of indicies to walk down through `try` statements, with the last element being the index of
 * the statement containing `super()`. Otherwise, an empty array if `super()` was not found.
 *
 * @internal
 */
function findSuperStatementIndexPath(statements, start) {
    const indices = [];
    findSuperStatementIndexPathWorker(statements, start, indices);
    return indices;
}
/** @internal */
function getProperties(node, requireInitializer, isStatic) {
    return (0, ts_js_1.filter)(node.members, m => isInitializedOrStaticProperty(m, requireInitializer, isStatic));
}
function isStaticPropertyDeclarationOrClassStaticBlockDeclaration(element) {
    return isStaticPropertyDeclaration(element) || (0, ts_js_1.isClassStaticBlockDeclaration)(element);
}
/** @internal */
function getStaticPropertiesAndClassStaticBlock(node) {
    return (0, ts_js_1.filter)(node.members, isStaticPropertyDeclarationOrClassStaticBlockDeclaration);
}
/**
 * Is a class element either a static or an instance property declaration with an initializer?
 *
 * @param member The class element node.
 * @param isStatic A value indicating whether the member should be a static or instance member.
 */
function isInitializedOrStaticProperty(member, requireInitializer, isStatic) {
    return (0, ts_js_1.isPropertyDeclaration)(member)
        && (!!member.initializer || !requireInitializer)
        && (0, ts_js_1.hasStaticModifier)(member) === isStatic;
}
function isStaticPropertyDeclaration(member) {
    return (0, ts_js_1.isPropertyDeclaration)(member) && (0, ts_js_1.hasStaticModifier)(member);
}
/**
 * Gets a value indicating whether a class element is either a static or an instance property declaration with an initializer.
 *
 * @param member The class element node.
 * @param isStatic A value indicating whether the member should be a static or instance member.
 *
 * @internal
 */
function isInitializedProperty(member) {
    return member.kind === 173 /* SyntaxKind.PropertyDeclaration */
        && member.initializer !== undefined;
}
/**
 * Gets a value indicating whether a class element is a private instance method or accessor.
 *
 * @param member The class element node.
 *
 * @internal
 */
function isNonStaticMethodOrAccessorWithPrivateName(member) {
    return !(0, ts_js_1.isStatic)(member) && ((0, ts_js_1.isMethodOrAccessor)(member) || (0, ts_js_1.isAutoAccessorPropertyDeclaration)(member)) && (0, ts_js_1.isPrivateIdentifier)(member.name);
}
/**
 * Gets an array of arrays of decorators for the parameters of a function-like node.
 * The offset into the result array should correspond to the offset of the parameter.
 *
 * @param node The function-like node.
 */
function getDecoratorsOfParameters(node) {
    let decorators;
    if (node) {
        const parameters = node.parameters;
        const firstParameterIsThis = parameters.length > 0 && (0, ts_js_1.parameterIsThisKeyword)(parameters[0]);
        const firstParameterOffset = firstParameterIsThis ? 1 : 0;
        const numParameters = firstParameterIsThis ? parameters.length - 1 : parameters.length;
        for (let i = 0; i < numParameters; i++) {
            const parameter = parameters[i + firstParameterOffset];
            if (decorators || (0, ts_js_1.hasDecorators)(parameter)) {
                if (!decorators) {
                    decorators = new Array(numParameters);
                }
                decorators[i] = (0, ts_js_1.getDecorators)(parameter);
            }
        }
    }
    return decorators;
}
/**
 * Gets an AllDecorators object containing the decorators for the class and the decorators for the
 * parameters of the constructor of the class.
 *
 * @param node The class node.
 *
 * @internal
 */
function getAllDecoratorsOfClass(node, useLegacyDecorators) {
    const decorators = (0, ts_js_1.getDecorators)(node);
    const parameters = useLegacyDecorators ? getDecoratorsOfParameters((0, ts_js_1.getFirstConstructorWithBody)(node)) : undefined;
    if (!(0, ts_js_1.some)(decorators) && !(0, ts_js_1.some)(parameters)) {
        return undefined;
    }
    return {
        decorators,
        parameters,
    };
}
/**
 * Gets an AllDecorators object containing the decorators for the member and its parameters.
 *
 * @param parent The class node that contains the member.
 * @param member The class member.
 *
 * @internal
 */
function getAllDecoratorsOfClassElement(member, parent, useLegacyDecorators) {
    switch (member.kind) {
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
            if (!useLegacyDecorators) {
                return getAllDecoratorsOfMethod(member, /*useLegacyDecorators*/ false);
            }
            return getAllDecoratorsOfAccessors(member, parent, /*useLegacyDecorators*/ true);
        case 175 /* SyntaxKind.MethodDeclaration */:
            return getAllDecoratorsOfMethod(member, useLegacyDecorators);
        case 173 /* SyntaxKind.PropertyDeclaration */:
            return getAllDecoratorsOfProperty(member);
        default:
            return undefined;
    }
}
/**
 * Gets an AllDecorators object containing the decorators for the accessor and its parameters.
 *
 * @param parent The class node that contains the accessor.
 * @param accessor The class accessor member.
 */
function getAllDecoratorsOfAccessors(accessor, parent, useLegacyDecorators) {
    if (!accessor.body) {
        return undefined;
    }
    const { firstAccessor, secondAccessor, getAccessor, setAccessor } = (0, ts_js_1.getAllAccessorDeclarations)(parent.members, accessor);
    const firstAccessorWithDecorators = (0, ts_js_1.hasDecorators)(firstAccessor) ? firstAccessor :
        secondAccessor && (0, ts_js_1.hasDecorators)(secondAccessor) ? secondAccessor :
            undefined;
    if (!firstAccessorWithDecorators || accessor !== firstAccessorWithDecorators) {
        return undefined;
    }
    const decorators = (0, ts_js_1.getDecorators)(firstAccessorWithDecorators);
    const parameters = useLegacyDecorators ? getDecoratorsOfParameters(setAccessor) : undefined;
    if (!(0, ts_js_1.some)(decorators) && !(0, ts_js_1.some)(parameters)) {
        return undefined;
    }
    return {
        decorators,
        parameters,
        getDecorators: getAccessor && (0, ts_js_1.getDecorators)(getAccessor),
        setDecorators: setAccessor && (0, ts_js_1.getDecorators)(setAccessor),
    };
}
/**
 * Gets an AllDecorators object containing the decorators for the method and its parameters.
 *
 * @param method The class method member.
 */
function getAllDecoratorsOfMethod(method, useLegacyDecorators) {
    if (!method.body) {
        return undefined;
    }
    const decorators = (0, ts_js_1.getDecorators)(method);
    const parameters = useLegacyDecorators ? getDecoratorsOfParameters(method) : undefined;
    if (!(0, ts_js_1.some)(decorators) && !(0, ts_js_1.some)(parameters)) {
        return undefined;
    }
    return { decorators, parameters };
}
/**
 * Gets an AllDecorators object containing the decorators for the property.
 *
 * @param property The class property member.
 */
function getAllDecoratorsOfProperty(property) {
    const decorators = (0, ts_js_1.getDecorators)(property);
    if (!(0, ts_js_1.some)(decorators)) {
        return undefined;
    }
    return { decorators };
}
function walkUpLexicalEnvironments(env, cb) {
    while (env) {
        const result = cb(env);
        if (result !== undefined)
            return result;
        env = env.previous;
    }
}
/** @internal */
function newPrivateEnvironment(data) {
    return { data };
}
/** @internal */
function getPrivateIdentifier(privateEnv, name) {
    return (0, ts_js_1.isGeneratedPrivateIdentifier)(name) ?
        privateEnv?.generatedIdentifiers?.get((0, ts_js_1.getNodeForGeneratedName)(name)) :
        privateEnv?.identifiers?.get(name.escapedText);
}
/** @internal */
function setPrivateIdentifier(privateEnv, name, entry) {
    if ((0, ts_js_1.isGeneratedPrivateIdentifier)(name)) {
        privateEnv.generatedIdentifiers ?? (privateEnv.generatedIdentifiers = new Map());
        privateEnv.generatedIdentifiers.set((0, ts_js_1.getNodeForGeneratedName)(name), entry);
    }
    else {
        privateEnv.identifiers ?? (privateEnv.identifiers = new Map());
        privateEnv.identifiers.set(name.escapedText, entry);
    }
}
/** @internal */
function accessPrivateIdentifier(env, name) {
    return walkUpLexicalEnvironments(env, env => getPrivateIdentifier(env.privateEnv, name));
}
function isSimpleParameter(node) {
    return !node.initializer && (0, ts_js_1.isIdentifier)(node.name);
}
/** @internal */
function isSimpleParameterList(nodes) {
    return (0, ts_js_1.every)(nodes, isSimpleParameter);
}
/** @internal */
function rewriteModuleSpecifier(node, compilerOptions) {
    if (!node || !(0, ts_js_1.isStringLiteral)(node) || !(0, ts_js_1.shouldRewriteModuleSpecifier)(node.text, compilerOptions)) {
        return node;
    }
    const updatedText = (0, ts_js_1.changeExtension)(node.text, (0, ts_js_1.getOutputExtension)(node.text, compilerOptions));
    return updatedText !== node.text ? (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(ts_js_1.factory.createStringLiteral(updatedText, node.singleQuote), node), node) : node;
}
