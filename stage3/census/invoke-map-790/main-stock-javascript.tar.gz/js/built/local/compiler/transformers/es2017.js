"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformES2017 = transformES2017;
exports.createSuperAccessVariableStatement = createSuperAccessVariableStatement;
const ts_js_1 = require("../_namespaces/ts.js");
var ES2017SubstitutionFlags;
(function (ES2017SubstitutionFlags) {
    ES2017SubstitutionFlags[ES2017SubstitutionFlags["None"] = 0] = "None";
    /** Enables substitutions for async methods with `super` calls. */
    ES2017SubstitutionFlags[ES2017SubstitutionFlags["AsyncMethodsWithSuper"] = 1] = "AsyncMethodsWithSuper";
})(ES2017SubstitutionFlags || (ES2017SubstitutionFlags = {}));
var ContextFlags;
(function (ContextFlags) {
    ContextFlags[ContextFlags["None"] = 0] = "None";
    ContextFlags[ContextFlags["NonTopLevel"] = 1] = "NonTopLevel";
    ContextFlags[ContextFlags["HasLexicalThis"] = 2] = "HasLexicalThis";
})(ContextFlags || (ContextFlags = {}));
/** @internal */
function transformES2017(context) {
    const { factory, getEmitHelperFactory: emitHelpers, resumeLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    /**
     * Keeps track of whether expression substitution has been enabled for specific edge cases.
     * They are persisted between each SourceFile transformation and should not be reset.
     */
    let enabledSubstitutions = 0 /* ES2017SubstitutionFlags.None */;
    /**
     * This keeps track of containers where `super` is valid, for use with
     * just-in-time substitution for `super` expressions inside of async methods.
     */
    let enclosingSuperContainerFlags = 0;
    let enclosingFunctionParameterNames;
    /**
     * Keeps track of property names accessed on super (`super.x`) within async functions.
     */
    let capturedSuperProperties;
    /** Whether the async function contains an element access on super (`super[x]`). */
    let hasSuperElementAccess;
    let lexicalArgumentsBinding;
    /** A set of node IDs for generated super accessors (variable statements). */
    const substitutedSuperAccessors = [];
    let contextFlags = 0 /* ContextFlags.None */;
    // Save the previous transformation hooks.
    const previousOnEmitNode = context.onEmitNode;
    const previousOnSubstituteNode = context.onSubstituteNode;
    // Set new transformation hooks.
    context.onEmitNode = onEmitNode;
    context.onSubstituteNode = onSubstituteNode;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        setContextFlag(1 /* ContextFlags.NonTopLevel */, false);
        setContextFlag(2 /* ContextFlags.HasLexicalThis */, !(0, ts_js_1.isEffectiveStrictModeSourceFile)(node, compilerOptions));
        const visited = (0, ts_js_1.visitEachChild)(node, visitor, context);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        return visited;
    }
    function setContextFlag(flag, val) {
        contextFlags = val ? contextFlags | flag : contextFlags & ~flag;
    }
    function inContext(flags) {
        return (contextFlags & flags) !== 0;
    }
    function inTopLevelContext() {
        return !inContext(1 /* ContextFlags.NonTopLevel */);
    }
    function inHasLexicalThisContext() {
        return inContext(2 /* ContextFlags.HasLexicalThis */);
    }
    function doWithContext(flags, cb, value) {
        const contextFlagsToSet = flags & ~contextFlags;
        if (contextFlagsToSet) {
            setContextFlag(contextFlagsToSet, /*val*/ true);
            const result = cb(value);
            setContextFlag(contextFlagsToSet, /*val*/ false);
            return result;
        }
        return cb(value);
    }
    function visitDefault(node) {
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function argumentsVisitor(node) {
        switch (node.kind) {
            case 219 /* SyntaxKind.FunctionExpression */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
            case 177 /* SyntaxKind.Constructor */:
                return node;
            case 170 /* SyntaxKind.Parameter */:
            case 209 /* SyntaxKind.BindingElement */:
            case 261 /* SyntaxKind.VariableDeclaration */:
                break;
            case 80 /* SyntaxKind.Identifier */:
                if (lexicalArgumentsBinding && resolver.isArgumentsLocalBinding(node)) {
                    return lexicalArgumentsBinding;
                }
                break;
        }
        return (0, ts_js_1.visitEachChild)(node, argumentsVisitor, context);
    }
    function visitor(node) {
        if ((node.transformFlags & 256 /* TransformFlags.ContainsES2017 */) === 0) {
            return lexicalArgumentsBinding ? argumentsVisitor(node) : node;
        }
        switch (node.kind) {
            case 134 /* SyntaxKind.AsyncKeyword */:
                // ES2017 async modifier should be elided for targets < ES2017
                return undefined;
            case 224 /* SyntaxKind.AwaitExpression */:
                return visitAwaitExpression(node);
            case 175 /* SyntaxKind.MethodDeclaration */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitMethodDeclaration, node);
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitFunctionDeclaration, node);
            case 219 /* SyntaxKind.FunctionExpression */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitFunctionExpression, node);
            case 220 /* SyntaxKind.ArrowFunction */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */, visitArrowFunction, node);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                if (capturedSuperProperties && (0, ts_js_1.isPropertyAccessExpression)(node) && node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
                    capturedSuperProperties.add(node.name.escapedText);
                }
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                if (capturedSuperProperties && node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
                    hasSuperElementAccess = true;
                }
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            case 178 /* SyntaxKind.GetAccessor */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitGetAccessorDeclaration, node);
            case 179 /* SyntaxKind.SetAccessor */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitSetAccessorDeclaration, node);
            case 177 /* SyntaxKind.Constructor */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitConstructorDeclaration, node);
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 232 /* SyntaxKind.ClassExpression */:
                return doWithContext(1 /* ContextFlags.NonTopLevel */ | 2 /* ContextFlags.HasLexicalThis */, visitDefault, node);
            default:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function asyncBodyVisitor(node) {
        if ((0, ts_js_1.isNodeWithPossibleHoistedDeclaration)(node)) {
            switch (node.kind) {
                case 244 /* SyntaxKind.VariableStatement */:
                    return visitVariableStatementInAsyncBody(node);
                case 249 /* SyntaxKind.ForStatement */:
                    return visitForStatementInAsyncBody(node);
                case 250 /* SyntaxKind.ForInStatement */:
                    return visitForInStatementInAsyncBody(node);
                case 251 /* SyntaxKind.ForOfStatement */:
                    return visitForOfStatementInAsyncBody(node);
                case 300 /* SyntaxKind.CatchClause */:
                    return visitCatchClauseInAsyncBody(node);
                case 242 /* SyntaxKind.Block */:
                case 256 /* SyntaxKind.SwitchStatement */:
                case 270 /* SyntaxKind.CaseBlock */:
                case 297 /* SyntaxKind.CaseClause */:
                case 298 /* SyntaxKind.DefaultClause */:
                case 259 /* SyntaxKind.TryStatement */:
                case 247 /* SyntaxKind.DoStatement */:
                case 248 /* SyntaxKind.WhileStatement */:
                case 246 /* SyntaxKind.IfStatement */:
                case 255 /* SyntaxKind.WithStatement */:
                case 257 /* SyntaxKind.LabeledStatement */:
                    return (0, ts_js_1.visitEachChild)(node, asyncBodyVisitor, context);
                default:
                    return ts_js_1.Debug.assertNever(node, "Unhandled node.");
            }
        }
        return visitor(node);
    }
    function visitCatchClauseInAsyncBody(node) {
        const catchClauseNames = new Set();
        recordDeclarationName(node.variableDeclaration, catchClauseNames); // TODO: GH#18217
        // names declared in a catch variable are block scoped
        let catchClauseUnshadowedNames;
        catchClauseNames.forEach((_, escapedName) => {
            if (enclosingFunctionParameterNames.has(escapedName)) {
                if (!catchClauseUnshadowedNames) {
                    catchClauseUnshadowedNames = new Set(enclosingFunctionParameterNames);
                }
                catchClauseUnshadowedNames.delete(escapedName);
            }
        });
        if (catchClauseUnshadowedNames) {
            const savedEnclosingFunctionParameterNames = enclosingFunctionParameterNames;
            enclosingFunctionParameterNames = catchClauseUnshadowedNames;
            const result = (0, ts_js_1.visitEachChild)(node, asyncBodyVisitor, context);
            enclosingFunctionParameterNames = savedEnclosingFunctionParameterNames;
            return result;
        }
        else {
            return (0, ts_js_1.visitEachChild)(node, asyncBodyVisitor, context);
        }
    }
    function visitVariableStatementInAsyncBody(node) {
        if (isVariableDeclarationListWithCollidingName(node.declarationList)) {
            const expression = visitVariableDeclarationListWithCollidingNames(node.declarationList, /*hasReceiver*/ false);
            return expression ? factory.createExpressionStatement(expression) : undefined;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitForInStatementInAsyncBody(node) {
        return factory.updateForInStatement(node, isVariableDeclarationListWithCollidingName(node.initializer)
            ? visitVariableDeclarationListWithCollidingNames(node.initializer, /*hasReceiver*/ true)
            : ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isForInitializer)), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), (0, ts_js_1.visitIterationBody)(node.statement, asyncBodyVisitor, context));
    }
    function visitForOfStatementInAsyncBody(node) {
        return factory.updateForOfStatement(node, (0, ts_js_1.visitNode)(node.awaitModifier, visitor, ts_js_1.isAwaitKeyword), isVariableDeclarationListWithCollidingName(node.initializer)
            ? visitVariableDeclarationListWithCollidingNames(node.initializer, /*hasReceiver*/ true)
            : ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isForInitializer)), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), (0, ts_js_1.visitIterationBody)(node.statement, asyncBodyVisitor, context));
    }
    function visitForStatementInAsyncBody(node) {
        const initializer = node.initializer; // TODO: GH#18217
        return factory.updateForStatement(node, isVariableDeclarationListWithCollidingName(initializer)
            ? visitVariableDeclarationListWithCollidingNames(initializer, /*hasReceiver*/ false)
            : (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, asyncBodyVisitor, context));
    }
    /**
     * Visits an AwaitExpression node.
     *
     * This function will be called any time a ES2017 await expression is encountered.
     *
     * @param node The node to visit.
     */
    function visitAwaitExpression(node) {
        // do not downlevel a top-level await as it is module syntax...
        if (inTopLevelContext()) {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createYieldExpression(
        /*asteriskToken*/ undefined, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), node), node);
    }
    function visitConstructorDeclaration(node) {
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const updated = factory.updateConstructorDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifier), (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), transformMethodBody(node));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    /**
     * Visits a MethodDeclaration node.
     *
     * This function will be called when one of the following conditions are met:
     * - The node is marked as async
     *
     * @param node The node to visit.
     */
    function visitMethodDeclaration(node) {
        let parameters;
        const functionFlags = (0, ts_js_1.getFunctionFlags)(node);
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const updated = factory.updateMethodDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike), node.asteriskToken, node.name, 
        /*questionToken*/ undefined, 
        /*typeParameters*/ undefined, parameters = functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionBody(node, parameters) :
            transformMethodBody(node));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    function visitGetAccessorDeclaration(node) {
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const updated = factory.updateGetAccessorDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike), node.name, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, transformMethodBody(node));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    function visitSetAccessorDeclaration(node) {
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const updated = factory.updateSetAccessorDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike), node.name, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), transformMethodBody(node));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    /**
     * Visits a FunctionDeclaration node.
     *
     * This function will be called when one of the following conditions are met:
     * - The node is marked async
     *
     * @param node The node to visit.
     */
    function visitFunctionDeclaration(node) {
        let parameters;
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const functionFlags = (0, ts_js_1.getFunctionFlags)(node);
        const updated = factory.updateFunctionDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike), node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, parameters = functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionBody(node, parameters) :
            (0, ts_js_1.visitFunctionBody)(node.body, visitor, context));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    /**
     * Visits a FunctionExpression node.
     *
     * This function will be called when one of the following conditions are met:
     * - The node is marked async
     *
     * @param node The node to visit.
     */
    function visitFunctionExpression(node) {
        let parameters;
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        lexicalArgumentsBinding = undefined;
        const functionFlags = (0, ts_js_1.getFunctionFlags)(node);
        const updated = factory.updateFunctionExpression(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifier), node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, parameters = functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionBody(node, parameters) :
            (0, ts_js_1.visitFunctionBody)(node.body, visitor, context));
        lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        return updated;
    }
    /**
     * Visits an ArrowFunction.
     *
     * This function will be called when one of the following conditions are met:
     * - The node is marked async
     *
     * @param node The node to visit.
     */
    function visitArrowFunction(node) {
        let parameters;
        const functionFlags = (0, ts_js_1.getFunctionFlags)(node);
        return factory.updateArrowFunction(node, (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifier), 
        /*typeParameters*/ undefined, parameters = functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionParameterList(node) :
            (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, node.equalsGreaterThanToken, functionFlags & 2 /* FunctionFlags.Async */ ?
            transformAsyncFunctionBody(node, parameters) :
            (0, ts_js_1.visitFunctionBody)(node.body, visitor, context));
    }
    function recordDeclarationName({ name }, names) {
        if ((0, ts_js_1.isIdentifier)(name)) {
            names.add(name.escapedText);
        }
        else {
            for (const element of name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    recordDeclarationName(element, names);
                }
            }
        }
    }
    function isVariableDeclarationListWithCollidingName(node) {
        return !!node
            && (0, ts_js_1.isVariableDeclarationList)(node)
            && !(node.flags & 7 /* NodeFlags.BlockScoped */)
            && node.declarations.some(collidesWithParameterName);
    }
    function visitVariableDeclarationListWithCollidingNames(node, hasReceiver) {
        hoistVariableDeclarationList(node);
        const variables = (0, ts_js_1.getInitializedVariables)(node);
        if (variables.length === 0) {
            if (hasReceiver) {
                return (0, ts_js_1.visitNode)(factory.converters.convertToAssignmentElementTarget(node.declarations[0].name), visitor, ts_js_1.isExpression);
            }
            return undefined;
        }
        return factory.inlineExpressions((0, ts_js_1.map)(variables, transformInitializedVariable));
    }
    function hoistVariableDeclarationList(node) {
        (0, ts_js_1.forEach)(node.declarations, hoistVariable);
    }
    function hoistVariable({ name }) {
        if ((0, ts_js_1.isIdentifier)(name)) {
            hoistVariableDeclaration(name);
        }
        else {
            for (const element of name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    hoistVariable(element);
                }
            }
        }
    }
    function transformInitializedVariable(node) {
        const converted = (0, ts_js_1.setSourceMapRange)(factory.createAssignment(factory.converters.convertToAssignmentElementTarget(node.name), node.initializer), node);
        return ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(converted, visitor, ts_js_1.isExpression));
    }
    function collidesWithParameterName({ name }) {
        if ((0, ts_js_1.isIdentifier)(name)) {
            return enclosingFunctionParameterNames.has(name.escapedText);
        }
        else {
            for (const element of name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element) && collidesWithParameterName(element)) {
                    return true;
                }
            }
        }
        return false;
    }
    function transformMethodBody(node) {
        ts_js_1.Debug.assertIsDefined(node.body);
        const savedCapturedSuperProperties = capturedSuperProperties;
        const savedHasSuperElementAccess = hasSuperElementAccess;
        capturedSuperProperties = new Set();
        hasSuperElementAccess = false;
        let updated = (0, ts_js_1.visitFunctionBody)(node.body, visitor, context);
        // Minor optimization, emit `_super` helper to capture `super` access in an arrow.
        // This step isn't needed if we eventually transform this to ES5.
        const originalMethod = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isFunctionLikeDeclaration);
        const emitSuperHelpers = languageVersion >= 2 /* ScriptTarget.ES2015 */ &&
            (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) || resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */)) &&
            ((0, ts_js_1.getFunctionFlags)(originalMethod) & 3 /* FunctionFlags.AsyncGenerator */) !== 3 /* FunctionFlags.AsyncGenerator */;
        if (emitSuperHelpers) {
            enableSubstitutionForAsyncMethodsWithSuper();
            if (capturedSuperProperties.size) {
                const variableStatement = createSuperAccessVariableStatement(factory, resolver, node, capturedSuperProperties);
                substitutedSuperAccessors[(0, ts_js_1.getNodeId)(variableStatement)] = true;
                const statements = updated.statements.slice();
                (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, [variableStatement]);
                updated = factory.updateBlock(updated, statements);
            }
            if (hasSuperElementAccess) {
                // Emit helpers for super element access expressions (`super[x]`).
                if (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */)) {
                    (0, ts_js_1.addEmitHelper)(updated, ts_js_1.advancedAsyncSuperHelper);
                }
                else if (resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */)) {
                    (0, ts_js_1.addEmitHelper)(updated, ts_js_1.asyncSuperHelper);
                }
            }
        }
        capturedSuperProperties = savedCapturedSuperProperties;
        hasSuperElementAccess = savedHasSuperElementAccess;
        return updated;
    }
    function createCaptureArgumentsStatement() {
        ts_js_1.Debug.assert(lexicalArgumentsBinding);
        const variable = factory.createVariableDeclaration(lexicalArgumentsBinding, /*exclamationToken*/ undefined, /*type*/ undefined, factory.createIdentifier("arguments"));
        const statement = factory.createVariableStatement(/*modifiers*/ undefined, [variable]);
        (0, ts_js_1.startOnNewLine)(statement);
        (0, ts_js_1.addEmitFlags)(statement, 2097152 /* EmitFlags.CustomPrologue */);
        return statement;
    }
    function transformAsyncFunctionParameterList(node) {
        if ((0, ts_js_1.isSimpleParameterList)(node.parameters)) {
            return (0, ts_js_1.visitParameterList)(node.parameters, visitor, context);
        }
        const newParameters = [];
        for (const parameter of node.parameters) {
            if (parameter.initializer || parameter.dotDotDotToken) {
                // for an arrow function, capture the remaining arguments in a rest parameter.
                // for any other function/method this isn't necessary as we can just use `arguments`.
                if (node.kind === 220 /* SyntaxKind.ArrowFunction */) {
                    const restParameter = factory.createParameterDeclaration(
                    /*modifiers*/ undefined, factory.createToken(26 /* SyntaxKind.DotDotDotToken */), factory.createUniqueName("args", 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */));
                    newParameters.push(restParameter);
                }
                break;
            }
            // for arrow functions we capture fixed parameters to forward to `__awaiter`. For all other functions
            // we add fixed parameters to preserve the function's `length` property.
            const newParameter = factory.createParameterDeclaration(
            /*modifiers*/ undefined, 
            /*dotDotDotToken*/ undefined, factory.getGeneratedNameForNode(parameter.name, 8 /* GeneratedIdentifierFlags.ReservedInNestedScopes */));
            newParameters.push(newParameter);
        }
        const newParametersArray = factory.createNodeArray(newParameters);
        (0, ts_js_1.setTextRange)(newParametersArray, node.parameters);
        return newParametersArray;
    }
    function transformAsyncFunctionBody(node, outerParameters) {
        const innerParameters = !(0, ts_js_1.isSimpleParameterList)(node.parameters) ? (0, ts_js_1.visitParameterList)(node.parameters, visitor, context) : undefined;
        resumeLexicalEnvironment();
        const original = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isFunctionLike);
        const nodeType = original.type;
        const promiseConstructor = languageVersion < 2 /* ScriptTarget.ES2015 */ ? getPromiseConstructor(nodeType) : undefined;
        const isArrowFunction = node.kind === 220 /* SyntaxKind.ArrowFunction */;
        const savedLexicalArgumentsBinding = lexicalArgumentsBinding;
        const hasLexicalArguments = resolver.hasNodeCheckFlag(node, 512 /* NodeCheckFlags.CaptureArguments */);
        const captureLexicalArguments = hasLexicalArguments && !lexicalArgumentsBinding;
        if (captureLexicalArguments) {
            lexicalArgumentsBinding = factory.createUniqueName("arguments");
        }
        let argumentsExpression;
        if (innerParameters) {
            if (isArrowFunction) {
                // `node` does not have a simple parameter list, so `outerParameters` refers to placeholders that are
                // forwarded to `innerParameters`, matching how they are introduced in `transformAsyncFunctionParameterList`.
                const parameterBindings = [];
                ts_js_1.Debug.assert(outerParameters.length <= node.parameters.length);
                for (let i = 0; i < node.parameters.length; i++) {
                    ts_js_1.Debug.assert(i < outerParameters.length);
                    const originalParameter = node.parameters[i];
                    const outerParameter = outerParameters[i];
                    ts_js_1.Debug.assertNode(outerParameter.name, ts_js_1.isIdentifier);
                    if (originalParameter.initializer || originalParameter.dotDotDotToken) {
                        ts_js_1.Debug.assert(i === outerParameters.length - 1);
                        parameterBindings.push(factory.createSpreadElement(outerParameter.name));
                        break;
                    }
                    parameterBindings.push(outerParameter.name);
                }
                argumentsExpression = factory.createArrayLiteralExpression(parameterBindings);
            }
            else {
                argumentsExpression = factory.createIdentifier("arguments");
            }
        }
        // An async function is emit as an outer function that calls an inner
        // generator function. To preserve lexical bindings, we pass the current
        // `this` and `arguments` objects to `__awaiter`. The generator function
        // passed to `__awaiter` is executed inside of the callback to the
        // promise constructor.
        const savedEnclosingFunctionParameterNames = enclosingFunctionParameterNames;
        enclosingFunctionParameterNames = new Set();
        for (const parameter of node.parameters) {
            recordDeclarationName(parameter, enclosingFunctionParameterNames);
        }
        const savedCapturedSuperProperties = capturedSuperProperties;
        const savedHasSuperElementAccess = hasSuperElementAccess;
        if (!isArrowFunction) {
            capturedSuperProperties = new Set();
            hasSuperElementAccess = false;
        }
        const hasLexicalThis = inHasLexicalThisContext();
        let asyncBody = transformAsyncFunctionBodyWorker(node.body);
        asyncBody = factory.updateBlock(asyncBody, factory.mergeLexicalEnvironment(asyncBody.statements, endLexicalEnvironment()));
        let result;
        if (!isArrowFunction) {
            const statements = [];
            statements.push(factory.createReturnStatement(emitHelpers().createAwaiterHelper(hasLexicalThis, argumentsExpression, promiseConstructor, innerParameters, asyncBody)));
            // Minor optimization, emit `_super` helper to capture `super` access in an arrow.
            // This step isn't needed if we eventually transform this to ES5.
            const emitSuperHelpers = languageVersion >= 2 /* ScriptTarget.ES2015 */ && (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) || resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */));
            if (emitSuperHelpers) {
                enableSubstitutionForAsyncMethodsWithSuper();
                if (capturedSuperProperties.size) {
                    const variableStatement = createSuperAccessVariableStatement(factory, resolver, node, capturedSuperProperties);
                    substitutedSuperAccessors[(0, ts_js_1.getNodeId)(variableStatement)] = true;
                    (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, [variableStatement]);
                }
            }
            if (captureLexicalArguments) {
                (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, [createCaptureArgumentsStatement()]);
            }
            const block = factory.createBlock(statements, /*multiLine*/ true);
            (0, ts_js_1.setTextRange)(block, node.body);
            if (emitSuperHelpers && hasSuperElementAccess) {
                // Emit helpers for super element access expressions (`super[x]`).
                if (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */)) {
                    (0, ts_js_1.addEmitHelper)(block, ts_js_1.advancedAsyncSuperHelper);
                }
                else if (resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */)) {
                    (0, ts_js_1.addEmitHelper)(block, ts_js_1.asyncSuperHelper);
                }
            }
            result = block;
        }
        else {
            result = emitHelpers().createAwaiterHelper(hasLexicalThis, argumentsExpression, promiseConstructor, innerParameters, asyncBody);
            if (captureLexicalArguments) {
                const block = factory.converters.convertToFunctionBlock(result);
                result = factory.updateBlock(block, factory.mergeLexicalEnvironment(block.statements, [createCaptureArgumentsStatement()]));
            }
        }
        enclosingFunctionParameterNames = savedEnclosingFunctionParameterNames;
        if (!isArrowFunction) {
            capturedSuperProperties = savedCapturedSuperProperties;
            hasSuperElementAccess = savedHasSuperElementAccess;
            lexicalArgumentsBinding = savedLexicalArgumentsBinding;
        }
        return result;
    }
    function transformAsyncFunctionBodyWorker(body, start) {
        if ((0, ts_js_1.isBlock)(body)) {
            return factory.updateBlock(body, (0, ts_js_1.visitNodes)(body.statements, asyncBodyVisitor, ts_js_1.isStatement, start));
        }
        else {
            return factory.converters.convertToFunctionBlock(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(body, asyncBodyVisitor, ts_js_1.isConciseBody)));
        }
    }
    function getPromiseConstructor(type) {
        const typeName = type && (0, ts_js_1.getEntityNameFromTypeNode)(type);
        if (typeName && (0, ts_js_1.isEntityName)(typeName)) {
            const serializationKind = resolver.getTypeReferenceSerializationKind(typeName);
            if (serializationKind === ts_js_1.TypeReferenceSerializationKind.TypeWithConstructSignatureAndValue
                || serializationKind === ts_js_1.TypeReferenceSerializationKind.Unknown) {
                return typeName;
            }
        }
        return undefined;
    }
    function enableSubstitutionForAsyncMethodsWithSuper() {
        if ((enabledSubstitutions & 1 /* ES2017SubstitutionFlags.AsyncMethodsWithSuper */) === 0) {
            enabledSubstitutions |= 1 /* ES2017SubstitutionFlags.AsyncMethodsWithSuper */;
            // We need to enable substitutions for call, property access, and element access
            // if we need to rewrite super calls.
            context.enableSubstitution(214 /* SyntaxKind.CallExpression */);
            context.enableSubstitution(212 /* SyntaxKind.PropertyAccessExpression */);
            context.enableSubstitution(213 /* SyntaxKind.ElementAccessExpression */);
            // We need to be notified when entering and exiting declarations that bind super.
            context.enableEmitNotification(264 /* SyntaxKind.ClassDeclaration */);
            context.enableEmitNotification(175 /* SyntaxKind.MethodDeclaration */);
            context.enableEmitNotification(178 /* SyntaxKind.GetAccessor */);
            context.enableEmitNotification(179 /* SyntaxKind.SetAccessor */);
            context.enableEmitNotification(177 /* SyntaxKind.Constructor */);
            // We need to be notified when entering the generated accessor arrow functions.
            context.enableEmitNotification(244 /* SyntaxKind.VariableStatement */);
        }
    }
    /**
     * Hook for node emit.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emit A callback used to emit the node in the printer.
     */
    function onEmitNode(hint, node, emitCallback) {
        // If we need to support substitutions for `super` in an async method,
        // we should track it here.
        if (enabledSubstitutions & 1 /* ES2017SubstitutionFlags.AsyncMethodsWithSuper */ && isSuperContainer(node)) {
            const superContainerFlags = (resolver.hasNodeCheckFlag(node, 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */) ? 128 /* NodeCheckFlags.MethodWithSuperPropertyAccessInAsync */ : 0) | (resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) ? 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */ : 0);
            if (superContainerFlags !== enclosingSuperContainerFlags) {
                const savedEnclosingSuperContainerFlags = enclosingSuperContainerFlags;
                enclosingSuperContainerFlags = superContainerFlags;
                previousOnEmitNode(hint, node, emitCallback);
                enclosingSuperContainerFlags = savedEnclosingSuperContainerFlags;
                return;
            }
        }
        // Disable substitution in the generated super accessor itself.
        else if (enabledSubstitutions && substitutedSuperAccessors[(0, ts_js_1.getNodeId)(node)]) {
            const savedEnclosingSuperContainerFlags = enclosingSuperContainerFlags;
            enclosingSuperContainerFlags = 0;
            previousOnEmitNode(hint, node, emitCallback);
            enclosingSuperContainerFlags = savedEnclosingSuperContainerFlags;
            return;
        }
        previousOnEmitNode(hint, node, emitCallback);
    }
    /**
     * Hooks node substitutions.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (hint === 1 /* EmitHint.Expression */ && enclosingSuperContainerFlags) {
            return substituteExpression(node);
        }
        return node;
    }
    function substituteExpression(node) {
        switch (node.kind) {
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                return substitutePropertyAccessExpression(node);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return substituteElementAccessExpression(node);
            case 214 /* SyntaxKind.CallExpression */:
                return substituteCallExpression(node);
        }
        return node;
    }
    function substitutePropertyAccessExpression(node) {
        if (node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
            return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createUniqueName("_super", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */), node.name), node);
        }
        return node;
    }
    function substituteElementAccessExpression(node) {
        if (node.expression.kind === 108 /* SyntaxKind.SuperKeyword */) {
            return createSuperElementAccessInAsyncMethod(node.argumentExpression, node);
        }
        return node;
    }
    function substituteCallExpression(node) {
        const expression = node.expression;
        if ((0, ts_js_1.isSuperProperty)(expression)) {
            const argumentExpression = (0, ts_js_1.isPropertyAccessExpression)(expression)
                ? substitutePropertyAccessExpression(expression)
                : substituteElementAccessExpression(expression);
            return factory.createCallExpression(factory.createPropertyAccessExpression(argumentExpression, "call"), 
            /*typeArguments*/ undefined, [
                factory.createThis(),
                ...node.arguments,
            ]);
        }
        return node;
    }
    function isSuperContainer(node) {
        const kind = node.kind;
        return kind === 264 /* SyntaxKind.ClassDeclaration */
            || kind === 177 /* SyntaxKind.Constructor */
            || kind === 175 /* SyntaxKind.MethodDeclaration */
            || kind === 178 /* SyntaxKind.GetAccessor */
            || kind === 179 /* SyntaxKind.SetAccessor */;
    }
    function createSuperElementAccessInAsyncMethod(argumentExpression, location) {
        if (enclosingSuperContainerFlags & 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */) {
            return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createCallExpression(factory.createUniqueName("_superIndex", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */), 
            /*typeArguments*/ undefined, [argumentExpression]), "value"), location);
        }
        else {
            return (0, ts_js_1.setTextRange)(factory.createCallExpression(factory.createUniqueName("_superIndex", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */), 
            /*typeArguments*/ undefined, [argumentExpression]), location);
        }
    }
}
/**
 * Creates a variable named `_super` with accessor properties for the given property names.
 *
 * @internal
 */
function createSuperAccessVariableStatement(factory, resolver, node, names) {
    // Create a variable declaration with a getter/setter (if binding) definition for each name:
    //   const _super = Object.create(null, { x: { get: () => super.x, set: (v) => super.x = v }, ... });
    const hasBinding = resolver.hasNodeCheckFlag(node, 256 /* NodeCheckFlags.MethodWithSuperPropertyAssignmentInAsync */);
    const accessors = [];
    names.forEach((_, key) => {
        const name = (0, ts_js_1.unescapeLeadingUnderscores)(key);
        const getterAndSetter = [];
        getterAndSetter.push(factory.createPropertyAssignment("get", factory.createArrowFunction(
        /*modifiers*/ undefined, 
        /*typeParameters*/ undefined, 
        /* parameters */ [], 
        /*type*/ undefined, 
        /*equalsGreaterThanToken*/ undefined, (0, ts_js_1.setEmitFlags)(factory.createPropertyAccessExpression((0, ts_js_1.setEmitFlags)(factory.createSuper(), 8 /* EmitFlags.NoSubstitution */), name), 8 /* EmitFlags.NoSubstitution */))));
        if (hasBinding) {
            getterAndSetter.push(factory.createPropertyAssignment("set", factory.createArrowFunction(
            /*modifiers*/ undefined, 
            /*typeParameters*/ undefined, 
            /* parameters */ [
                factory.createParameterDeclaration(
                /*modifiers*/ undefined, 
                /*dotDotDotToken*/ undefined, "v", 
                /*questionToken*/ undefined, 
                /*type*/ undefined, 
                /*initializer*/ undefined),
            ], 
            /*type*/ undefined, 
            /*equalsGreaterThanToken*/ undefined, factory.createAssignment((0, ts_js_1.setEmitFlags)(factory.createPropertyAccessExpression((0, ts_js_1.setEmitFlags)(factory.createSuper(), 8 /* EmitFlags.NoSubstitution */), name), 8 /* EmitFlags.NoSubstitution */), factory.createIdentifier("v")))));
        }
        accessors.push(factory.createPropertyAssignment(name, factory.createObjectLiteralExpression(getterAndSetter)));
    });
    return factory.createVariableStatement(
    /*modifiers*/ undefined, factory.createVariableDeclarationList([
        factory.createVariableDeclaration(factory.createUniqueName("_super", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */), 
        /*exclamationToken*/ undefined, 
        /*type*/ undefined, factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("Object"), "create"), 
        /*typeArguments*/ undefined, [
            factory.createNull(),
            factory.createObjectLiteralExpression(accessors, /*multiLine*/ true),
        ])),
    ], 2 /* NodeFlags.Const */));
}
