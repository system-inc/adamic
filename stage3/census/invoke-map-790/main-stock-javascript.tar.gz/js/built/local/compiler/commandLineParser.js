"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.compilerOptionsDidYouMeanDiagnostics = exports.defaultInitCompilerOptions = exports.typeAcquisitionDeclarations = exports.buildOpts = exports.optionsForBuild = exports.tscBuildOption = exports.commandLineOptionOfCustomType = exports.transpileOptionValueCompilerOptions = exports.optionsAffectingProgramStructure = exports.sourceFileAffectingCompilerOptions = exports.moduleResolutionOptionDeclarations = exports.affectsDeclarationPathOptionDeclarations = exports.affectsEmitOptionDeclarations = exports.semanticDiagnosticsOptionDeclarations = exports.optionDeclarations = exports.moduleOptionDeclaration = exports.targetOptionDeclaration = exports.commonOptionsWithBuild = exports.optionsForWatch = exports.libMap = exports.libs = exports.inverseJsxOptionMap = void 0;
exports.createOptionNameMap = createOptionNameMap;
exports.getOptionsNameMap = getOptionsNameMap;
exports.createCompilerDiagnosticForInvalidCustomType = createCompilerDiagnosticForInvalidCustomType;
exports.parseCustomTypeOption = parseCustomTypeOption;
exports.parseListTypeOption = parseListTypeOption;
exports.parseCommandLineWorker = parseCommandLineWorker;
exports.parseCommandLine = parseCommandLine;
exports.getOptionFromName = getOptionFromName;
exports.parseBuildCommand = parseBuildCommand;
exports.getDiagnosticText = getDiagnosticText;
exports.getParsedCommandLineOfConfigFile = getParsedCommandLineOfConfigFile;
exports.readConfigFile = readConfigFile;
exports.parseConfigFileTextToJson = parseConfigFileTextToJson;
exports.readJsonConfigFile = readJsonConfigFile;
exports.tryReadFile = tryReadFile;
exports.isAdamicJsonObject = isAdamicJsonObject;
exports.checkedAdamicJsonObject = checkedAdamicJsonObject;
exports.convertToObject = convertToObject;
exports.convertToJson = convertToJson;
exports.convertToTSConfig = convertToTSConfig;
exports.optionMapToObject = optionMapToObject;
exports.getNameOfCompilerOptionValue = getNameOfCompilerOptionValue;
exports.serializeCompilerOptions = serializeCompilerOptions;
exports.generateTSConfig = generateTSConfig;
exports.convertToOptionsWithAbsolutePaths = convertToOptionsWithAbsolutePaths;
exports.parseJsonConfigFileContent = parseJsonConfigFileContent;
exports.parseJsonSourceFileConfigFileContent = parseJsonSourceFileConfigFileContent;
exports.setConfigFileInOptions = setConfigFileInOptions;
exports.handleWatchOptionsConfigDirTemplateSubstitution = handleWatchOptionsConfigDirTemplateSubstitution;
exports.isSolutionConfig = isSolutionConfig;
exports.canJsonReportNoInputFiles = canJsonReportNoInputFiles;
exports.updateErrorForNoInputFiles = updateErrorForNoInputFiles;
exports.convertCompilerOptionsFromJson = convertCompilerOptionsFromJson;
exports.convertTypeAcquisitionFromJson = convertTypeAcquisitionFromJson;
exports.convertJsonOption = convertJsonOption;
exports.getFileNamesFromConfigSpecs = getFileNamesFromConfigSpecs;
exports.isExcludedFile = isExcludedFile;
exports.matchesExclude = matchesExclude;
exports.matchesExcludeWorker = matchesExcludeWorker;
exports.convertCompilerOptionsForTelemetry = convertCompilerOptionsForTelemetry;
const ts_js_1 = require("./_namespaces/ts.js");
const hostErrors_js_1 = require("./hostErrors.js");
const compileOnSaveCommandLineOption = {
    name: "compileOnSave",
    type: "boolean",
    defaultValueDescription: false,
};
const jsxOptionMap = new Map(Object.entries({
    "preserve": 1 /* JsxEmit.Preserve */,
    "react-native": 3 /* JsxEmit.ReactNative */,
    "react-jsx": 4 /* JsxEmit.ReactJSX */,
    "react-jsxdev": 5 /* JsxEmit.ReactJSXDev */,
    "react": 2 /* JsxEmit.React */,
}));
/** @internal */
exports.inverseJsxOptionMap = new Map((0, ts_js_1.mapIterator)(jsxOptionMap.entries(), ([key, value]) => ["" + value, key]));
// NOTE: The order here is important to default lib ordering as entries will have the same
//       order in the generated program (see `getDefaultLibFilePriority` in program.ts). This
//       order also affects overload resolution when a type declared in one lib is
//       augmented in another lib.
// NOTE: We must reevaluate the target for upcoming features when each successive TC39 edition is ratified in
//       June of each year. This includes changes to `LanguageFeatureMinimumTarget`, `ScriptTarget`,
//       `ScriptTargetFeatures`, `CommandLineOptionOfCustomType`, transformers/esnext.ts, compiler/commandLineParser.ts,
//       compiler/utilitiesPublic.ts, and the contents of each lib/esnext.*.d.ts file.
const libEntries = [
    // JavaScript only
    ["es5", "lib.es5.d.ts"],
    ["es6", "lib.es2015.d.ts"],
    ["es2015", "lib.es2015.d.ts"],
    ["es7", "lib.es2016.d.ts"],
    ["es2016", "lib.es2016.d.ts"],
    ["es2017", "lib.es2017.d.ts"],
    ["es2018", "lib.es2018.d.ts"],
    ["es2019", "lib.es2019.d.ts"],
    ["es2020", "lib.es2020.d.ts"],
    ["es2021", "lib.es2021.d.ts"],
    ["es2022", "lib.es2022.d.ts"],
    ["es2023", "lib.es2023.d.ts"],
    ["es2024", "lib.es2024.d.ts"],
    ["es2025", "lib.es2025.d.ts"],
    ["esnext", "lib.esnext.d.ts"],
    // Host only
    ["dom", "lib.dom.d.ts"],
    ["dom.iterable", "lib.dom.iterable.d.ts"],
    ["dom.asynciterable", "lib.dom.asynciterable.d.ts"],
    ["webworker", "lib.webworker.d.ts"],
    ["webworker.importscripts", "lib.webworker.importscripts.d.ts"],
    ["webworker.iterable", "lib.webworker.iterable.d.ts"],
    ["webworker.asynciterable", "lib.webworker.asynciterable.d.ts"],
    ["scripthost", "lib.scripthost.d.ts"],
    // ES2015 and later By-feature options
    ["es2015.core", "lib.es2015.core.d.ts"],
    ["es2015.collection", "lib.es2015.collection.d.ts"],
    ["es2015.generator", "lib.es2015.generator.d.ts"],
    ["es2015.iterable", "lib.es2015.iterable.d.ts"],
    ["es2015.promise", "lib.es2015.promise.d.ts"],
    ["es2015.proxy", "lib.es2015.proxy.d.ts"],
    ["es2015.reflect", "lib.es2015.reflect.d.ts"],
    ["es2015.symbol", "lib.es2015.symbol.d.ts"],
    ["es2015.symbol.wellknown", "lib.es2015.symbol.wellknown.d.ts"],
    ["es2016.array.include", "lib.es2016.array.include.d.ts"],
    ["es2016.intl", "lib.es2016.intl.d.ts"],
    ["es2017.arraybuffer", "lib.es2017.arraybuffer.d.ts"],
    ["es2017.date", "lib.es2017.date.d.ts"],
    ["es2017.object", "lib.es2017.object.d.ts"],
    ["es2017.sharedmemory", "lib.es2017.sharedmemory.d.ts"],
    ["es2017.string", "lib.es2017.string.d.ts"],
    ["es2017.intl", "lib.es2017.intl.d.ts"],
    ["es2017.typedarrays", "lib.es2017.typedarrays.d.ts"],
    ["es2018.asyncgenerator", "lib.es2018.asyncgenerator.d.ts"],
    ["es2018.asynciterable", "lib.es2018.asynciterable.d.ts"],
    ["es2018.intl", "lib.es2018.intl.d.ts"],
    ["es2018.promise", "lib.es2018.promise.d.ts"],
    ["es2018.regexp", "lib.es2018.regexp.d.ts"],
    ["es2019.array", "lib.es2019.array.d.ts"],
    ["es2019.object", "lib.es2019.object.d.ts"],
    ["es2019.string", "lib.es2019.string.d.ts"],
    ["es2019.symbol", "lib.es2019.symbol.d.ts"],
    ["es2019.intl", "lib.es2019.intl.d.ts"],
    ["es2020.bigint", "lib.es2020.bigint.d.ts"],
    ["es2020.date", "lib.es2020.date.d.ts"],
    ["es2020.promise", "lib.es2020.promise.d.ts"],
    ["es2020.sharedmemory", "lib.es2020.sharedmemory.d.ts"],
    ["es2020.string", "lib.es2020.string.d.ts"],
    ["es2020.symbol.wellknown", "lib.es2020.symbol.wellknown.d.ts"],
    ["es2020.intl", "lib.es2020.intl.d.ts"],
    ["es2020.number", "lib.es2020.number.d.ts"],
    ["es2021.promise", "lib.es2021.promise.d.ts"],
    ["es2021.string", "lib.es2021.string.d.ts"],
    ["es2021.weakref", "lib.es2021.weakref.d.ts"],
    ["es2021.intl", "lib.es2021.intl.d.ts"],
    ["es2022.array", "lib.es2022.array.d.ts"],
    ["es2022.error", "lib.es2022.error.d.ts"],
    ["es2022.intl", "lib.es2022.intl.d.ts"],
    ["es2022.object", "lib.es2022.object.d.ts"],
    ["es2022.string", "lib.es2022.string.d.ts"],
    ["es2022.regexp", "lib.es2022.regexp.d.ts"],
    ["es2023.array", "lib.es2023.array.d.ts"],
    ["es2023.collection", "lib.es2023.collection.d.ts"],
    ["es2023.intl", "lib.es2023.intl.d.ts"],
    ["es2024.arraybuffer", "lib.es2024.arraybuffer.d.ts"],
    ["es2024.collection", "lib.es2024.collection.d.ts"],
    ["es2024.object", "lib.es2024.object.d.ts"],
    ["es2024.promise", "lib.es2024.promise.d.ts"],
    ["es2024.regexp", "lib.es2024.regexp.d.ts"],
    ["es2024.sharedmemory", "lib.es2024.sharedmemory.d.ts"],
    ["es2024.string", "lib.es2024.string.d.ts"],
    ["es2025.collection", "lib.es2025.collection.d.ts"],
    ["es2025.float16", "lib.es2025.float16.d.ts"],
    ["es2025.intl", "lib.es2025.intl.d.ts"],
    ["es2025.iterator", "lib.es2025.iterator.d.ts"],
    ["es2025.promise", "lib.es2025.promise.d.ts"],
    ["es2025.regexp", "lib.es2025.regexp.d.ts"],
    // Fallback for backward compatibility
    ["esnext.asynciterable", "lib.es2018.asynciterable.d.ts"],
    ["esnext.symbol", "lib.es2019.symbol.d.ts"],
    ["esnext.bigint", "lib.es2020.bigint.d.ts"],
    ["esnext.weakref", "lib.es2021.weakref.d.ts"],
    ["esnext.object", "lib.es2024.object.d.ts"],
    ["esnext.regexp", "lib.es2024.regexp.d.ts"],
    ["esnext.string", "lib.es2024.string.d.ts"],
    ["esnext.float16", "lib.es2025.float16.d.ts"],
    ["esnext.iterator", "lib.es2025.iterator.d.ts"],
    ["esnext.promise", "lib.es2025.promise.d.ts"],
    // ESNext By-feature options
    ["esnext.array", "lib.esnext.array.d.ts"],
    ["esnext.collection", "lib.esnext.collection.d.ts"],
    ["esnext.date", "lib.esnext.date.d.ts"],
    ["esnext.decorators", "lib.esnext.decorators.d.ts"],
    ["esnext.disposable", "lib.esnext.disposable.d.ts"],
    ["esnext.error", "lib.esnext.error.d.ts"],
    ["esnext.intl", "lib.esnext.intl.d.ts"],
    ["esnext.sharedmemory", "lib.esnext.sharedmemory.d.ts"],
    ["esnext.temporal", "lib.esnext.temporal.d.ts"],
    ["esnext.typedarrays", "lib.esnext.typedarrays.d.ts"],
    // Decorators
    ["decorators", "lib.decorators.d.ts"],
    ["decorators.legacy", "lib.decorators.legacy.d.ts"],
];
/**
 * An array of supported "lib" reference file names used to determine the order for inclusion
 * when referenced, as well as for spelling suggestions. This ensures the correct ordering for
 * overload resolution when a type declared in one lib is extended by another.
 *
 * @internal
 */
exports.libs = libEntries.map(entry => entry[0]);
/**
 * A map of lib names to lib files. This map is used both for parsing the "lib" command line
 * option as well as for resolving lib reference directives.
 *
 * @internal
 */
exports.libMap = new Map(libEntries);
// Watch related options
// Do not delete this without updating the website's tsconfig generation.
/** @internal */
exports.optionsForWatch = [
    {
        name: "watchFile",
        type: new Map(Object.entries({
            fixedpollinginterval: ts_js_1.WatchFileKind.FixedPollingInterval,
            prioritypollinginterval: ts_js_1.WatchFileKind.PriorityPollingInterval,
            dynamicprioritypolling: ts_js_1.WatchFileKind.DynamicPriorityPolling,
            fixedchunksizepolling: ts_js_1.WatchFileKind.FixedChunkSizePolling,
            usefsevents: ts_js_1.WatchFileKind.UseFsEvents,
            usefseventsonparentdirectory: ts_js_1.WatchFileKind.UseFsEventsOnParentDirectory,
        })),
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Specify_how_the_TypeScript_watch_mode_works,
        defaultValueDescription: ts_js_1.WatchFileKind.UseFsEvents,
    },
    {
        name: "watchDirectory",
        type: new Map(Object.entries({
            usefsevents: ts_js_1.WatchDirectoryKind.UseFsEvents,
            fixedpollinginterval: ts_js_1.WatchDirectoryKind.FixedPollingInterval,
            dynamicprioritypolling: ts_js_1.WatchDirectoryKind.DynamicPriorityPolling,
            fixedchunksizepolling: ts_js_1.WatchDirectoryKind.FixedChunkSizePolling,
        })),
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Specify_how_directories_are_watched_on_systems_that_lack_recursive_file_watching_functionality,
        defaultValueDescription: ts_js_1.WatchDirectoryKind.UseFsEvents,
    },
    {
        name: "fallbackPolling",
        type: new Map(Object.entries({
            fixedinterval: ts_js_1.PollingWatchKind.FixedInterval,
            priorityinterval: ts_js_1.PollingWatchKind.PriorityInterval,
            dynamicpriority: ts_js_1.PollingWatchKind.DynamicPriority,
            fixedchunksize: ts_js_1.PollingWatchKind.FixedChunkSize,
        })),
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Specify_what_approach_the_watcher_should_use_if_the_system_runs_out_of_native_file_watchers,
        defaultValueDescription: ts_js_1.PollingWatchKind.PriorityInterval,
    },
    {
        name: "synchronousWatchDirectory",
        type: "boolean",
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Synchronously_call_callbacks_and_update_the_state_of_directory_watchers_on_platforms_that_don_t_support_recursive_watching_natively,
        defaultValueDescription: false,
    },
    {
        name: "excludeDirectories",
        type: "list",
        element: {
            name: "excludeDirectory",
            type: "string",
            isFilePath: true,
            extraValidation: specToDiagnostic,
        },
        allowConfigDirTemplateSubstitution: true,
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Remove_a_list_of_directories_from_the_watch_process,
    },
    {
        name: "excludeFiles",
        type: "list",
        element: {
            name: "excludeFile",
            type: "string",
            isFilePath: true,
            extraValidation: specToDiagnostic,
        },
        allowConfigDirTemplateSubstitution: true,
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Remove_a_list_of_files_from_the_watch_mode_s_processing,
    },
];
/** @internal */
exports.commonOptionsWithBuild = [
    {
        name: "help",
        shortName: "h",
        type: "boolean",
        showInSimplifiedHelpView: true,
        isCommandLineOnly: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Print_this_message,
        defaultValueDescription: false,
    },
    {
        name: "help",
        shortName: "?",
        type: "boolean",
        isCommandLineOnly: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        defaultValueDescription: false,
    },
    {
        name: "watch",
        shortName: "w",
        type: "boolean",
        showInSimplifiedHelpView: true,
        isCommandLineOnly: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Watch_input_files,
        defaultValueDescription: false,
    },
    {
        name: "preserveWatchOutput",
        type: "boolean",
        showInSimplifiedHelpView: false,
        category: ts_js_1.Diagnostics.Output_Formatting,
        description: ts_js_1.Diagnostics.Disable_wiping_the_console_in_watch_mode,
        defaultValueDescription: false,
    },
    {
        name: "listFiles",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Print_all_of_the_files_read_during_the_compilation,
        defaultValueDescription: false,
    },
    {
        name: "explainFiles",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Print_files_read_during_the_compilation_including_why_it_was_included,
        defaultValueDescription: false,
    },
    {
        name: "listEmittedFiles",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Print_the_names_of_emitted_files_after_a_compilation,
        defaultValueDescription: false,
    },
    {
        name: "pretty",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Output_Formatting,
        description: ts_js_1.Diagnostics.Enable_color_and_formatting_in_TypeScript_s_output_to_make_compiler_errors_easier_to_read,
        defaultValueDescription: true,
    },
    {
        name: "traceResolution",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Log_paths_used_during_the_moduleResolution_process,
        defaultValueDescription: false,
    },
    {
        name: "diagnostics",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Output_compiler_performance_information_after_building,
        defaultValueDescription: false,
    },
    {
        name: "extendedDiagnostics",
        type: "boolean",
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Output_more_detailed_compiler_performance_information_after_building,
        defaultValueDescription: false,
    },
    {
        name: "generateCpuProfile",
        type: "string",
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.FILE_OR_DIRECTORY,
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Emit_a_v8_CPU_profile_of_the_compiler_run_for_debugging,
        defaultValueDescription: "profile.cpuprofile",
    },
    {
        name: "generateTrace",
        type: "string",
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.DIRECTORY,
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Generates_an_event_trace_and_a_list_of_types,
    },
    {
        name: "incremental",
        shortName: "i",
        type: "boolean",
        category: ts_js_1.Diagnostics.Projects,
        description: ts_js_1.Diagnostics.Save_tsbuildinfo_files_to_allow_for_incremental_compilation_of_projects,
        transpileOptionValue: undefined,
        defaultValueDescription: ts_js_1.Diagnostics.false_unless_composite_is_set,
    },
    {
        name: "declaration",
        shortName: "d",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        transpileOptionValue: undefined,
        description: ts_js_1.Diagnostics.Generate_d_ts_files_from_TypeScript_and_JavaScript_files_in_your_project,
        defaultValueDescription: ts_js_1.Diagnostics.false_unless_composite_is_set,
    },
    {
        name: "declarationMap",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        defaultValueDescription: false,
        description: ts_js_1.Diagnostics.Create_sourcemaps_for_d_ts_files,
    },
    {
        name: "emitDeclarationOnly",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Only_output_d_ts_files_and_not_JavaScript_files,
        transpileOptionValue: undefined,
        defaultValueDescription: false,
    },
    {
        name: "sourceMap",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        defaultValueDescription: false,
        description: ts_js_1.Diagnostics.Create_source_map_files_for_emitted_JavaScript_files,
    },
    {
        name: "inlineSourceMap",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Include_sourcemap_files_inside_the_emitted_JavaScript,
        defaultValueDescription: false,
    },
    {
        name: "noCheck",
        type: "boolean",
        showInSimplifiedHelpView: false,
        category: ts_js_1.Diagnostics.Compiler_Diagnostics,
        description: ts_js_1.Diagnostics.Disable_full_type_checking_only_critical_parse_and_emit_errors_will_be_reported,
        transpileOptionValue: true,
        defaultValueDescription: false,
        // Not setting affectsSemanticDiagnostics or affectsBuildInfo because we dont want all diagnostics to go away, its handled in builder
    },
    {
        name: "noEmit",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Disable_emitting_files_from_a_compilation,
        transpileOptionValue: undefined,
        defaultValueDescription: false,
    },
    {
        name: "assumeChangesOnlyAffectDirectDependencies",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Watch_and_Build_Modes,
        description: ts_js_1.Diagnostics.Have_recompiles_in_projects_that_use_incremental_and_watch_mode_assume_that_changes_within_a_file_will_only_affect_files_directly_depending_on_it,
        defaultValueDescription: false,
    },
    {
        name: "locale",
        type: "string",
        category: ts_js_1.Diagnostics.Command_line_Options,
        isCommandLineOnly: true,
        description: ts_js_1.Diagnostics.Set_the_language_of_the_messaging_from_TypeScript_This_does_not_affect_emit,
        defaultValueDescription: ts_js_1.Diagnostics.Platform_specific,
    },
];
// NOTE: We must reevaluate the target for upcoming features when each successive TC39 edition is ratified in
//       June of each year. This includes changes to `LanguageFeatureMinimumTarget`, `ScriptTarget`,
//       `ScriptTargetFeatures`, `CommandLineOptionOfCustomType`, transformers/esnext.ts, compiler/commandLineParser.ts,
//       compiler/utilitiesPublic.ts, and the contents of each lib/esnext.*.d.ts file.
/** @internal */
exports.targetOptionDeclaration = {
    name: "target",
    shortName: "t",
    type: new Map(Object.entries({
        es3: 0 /* ScriptTarget.ES3 */,
        es5: 1 /* ScriptTarget.ES5 */,
        es6: 2 /* ScriptTarget.ES2015 */,
        es2015: 2 /* ScriptTarget.ES2015 */,
        es2016: 3 /* ScriptTarget.ES2016 */,
        es2017: 4 /* ScriptTarget.ES2017 */,
        es2018: 5 /* ScriptTarget.ES2018 */,
        es2019: 6 /* ScriptTarget.ES2019 */,
        es2020: 7 /* ScriptTarget.ES2020 */,
        es2021: 8 /* ScriptTarget.ES2021 */,
        es2022: 9 /* ScriptTarget.ES2022 */,
        es2023: 10 /* ScriptTarget.ES2023 */,
        es2024: 11 /* ScriptTarget.ES2024 */,
        es2025: 12 /* ScriptTarget.ES2025 */,
        esnext: 99 /* ScriptTarget.ESNext */,
    })),
    affectsSourceFile: true,
    affectsModuleResolution: true,
    affectsEmit: true,
    affectsBuildInfo: true,
    deprecatedKeys: new Set(["es3", "es5"]),
    paramType: ts_js_1.Diagnostics.VERSION,
    showInSimplifiedHelpView: true,
    category: ts_js_1.Diagnostics.Language_and_Environment,
    description: ts_js_1.Diagnostics.Set_the_JavaScript_language_version_for_emitted_JavaScript_and_include_compatible_library_declarations,
    defaultValueDescription: 12 /* ScriptTarget.LatestStandard */,
};
/** @internal */
exports.moduleOptionDeclaration = {
    name: "module",
    shortName: "m",
    type: new Map(Object.entries({
        none: ts_js_1.ModuleKind.None,
        commonjs: ts_js_1.ModuleKind.CommonJS,
        amd: ts_js_1.ModuleKind.AMD,
        system: ts_js_1.ModuleKind.System,
        umd: ts_js_1.ModuleKind.UMD,
        es6: ts_js_1.ModuleKind.ES2015,
        es2015: ts_js_1.ModuleKind.ES2015,
        es2020: ts_js_1.ModuleKind.ES2020,
        es2022: ts_js_1.ModuleKind.ES2022,
        esnext: ts_js_1.ModuleKind.ESNext,
        node16: ts_js_1.ModuleKind.Node16,
        node18: ts_js_1.ModuleKind.Node18,
        node20: ts_js_1.ModuleKind.Node20,
        nodenext: ts_js_1.ModuleKind.NodeNext,
        preserve: ts_js_1.ModuleKind.Preserve,
    })),
    deprecatedKeys: new Set(["none", "amd", "system", "umd"]),
    affectsSourceFile: true,
    affectsModuleResolution: true,
    affectsEmit: true,
    affectsBuildInfo: true,
    paramType: ts_js_1.Diagnostics.KIND,
    showInSimplifiedHelpView: true,
    category: ts_js_1.Diagnostics.Modules,
    description: ts_js_1.Diagnostics.Specify_what_module_code_is_generated,
    defaultValueDescription: undefined,
};
const commandOptionsWithoutBuild = [
    // CommandLine only options
    {
        name: "all",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Show_all_compiler_options,
        defaultValueDescription: false,
    },
    {
        name: "version",
        shortName: "v",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Print_the_compiler_s_version,
        defaultValueDescription: false,
    },
    {
        name: "init",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Initializes_a_TypeScript_project_and_creates_a_tsconfig_json_file,
        defaultValueDescription: false,
    },
    {
        name: "project",
        shortName: "p",
        type: "string",
        isFilePath: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        paramType: ts_js_1.Diagnostics.FILE_OR_DIRECTORY,
        description: ts_js_1.Diagnostics.Compile_the_project_given_the_path_to_its_configuration_file_or_to_a_folder_with_a_tsconfig_json,
    },
    {
        name: "showConfig",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        isCommandLineOnly: true,
        description: ts_js_1.Diagnostics.Print_the_final_configuration_instead_of_building,
        defaultValueDescription: false,
    },
    {
        name: "listFilesOnly",
        type: "boolean",
        category: ts_js_1.Diagnostics.Command_line_Options,
        isCommandLineOnly: true,
        description: ts_js_1.Diagnostics.Print_names_of_files_that_are_part_of_the_compilation_and_then_stop_processing,
        defaultValueDescription: false,
    },
    {
        name: "ignoreConfig",
        type: "boolean",
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Command_line_Options,
        isCommandLineOnly: true,
        description: ts_js_1.Diagnostics.Ignore_the_tsconfig_found_and_build_with_commandline_options_and_files,
        defaultValueDescription: false,
    },
    // Basic
    exports.targetOptionDeclaration,
    exports.moduleOptionDeclaration,
    {
        name: "lib",
        type: "list",
        element: {
            name: "lib",
            type: exports.libMap,
            defaultValueDescription: undefined,
        },
        affectsProgramStructure: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_a_set_of_bundled_library_declaration_files_that_describe_the_target_runtime_environment,
        transpileOptionValue: undefined,
    },
    {
        name: "allowJs",
        type: "boolean",
        allowJsFlag: true,
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.JavaScript_Support,
        description: ts_js_1.Diagnostics.Allow_JavaScript_files_to_be_a_part_of_your_program_Use_the_checkJs_option_to_get_errors_from_these_files,
        defaultValueDescription: ts_js_1.Diagnostics.false_unless_checkJs_is_set,
    },
    {
        name: "checkJs",
        type: "boolean",
        affectsModuleResolution: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.JavaScript_Support,
        description: ts_js_1.Diagnostics.Enable_error_reporting_in_type_checked_JavaScript_files,
        defaultValueDescription: false,
    },
    {
        name: "jsx",
        type: jsxOptionMap,
        affectsSourceFile: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsModuleResolution: true,
        // The checker emits an error when it sees JSX but this option is not set in compilerOptions.
        // This is effectively a semantic error, so mark this option as affecting semantic diagnostics
        // so we know to refresh errors when this option is changed.
        affectsSemanticDiagnostics: true,
        paramType: ts_js_1.Diagnostics.KIND,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_what_JSX_code_is_generated,
        defaultValueDescription: undefined,
    },
    {
        name: "outFile",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsDeclarationPath: true,
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.FILE,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Specify_a_file_that_bundles_all_outputs_into_one_JavaScript_file_If_declaration_is_true_also_designates_a_file_that_bundles_all_d_ts_output,
        transpileOptionValue: undefined,
    },
    {
        name: "outDir",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsDeclarationPath: true,
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.DIRECTORY,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Specify_an_output_folder_for_all_emitted_files,
    },
    {
        name: "rootDir",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsDeclarationPath: true,
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.LOCATION,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_the_root_folder_within_your_source_files,
        defaultValueDescription: ts_js_1.Diagnostics.Computed_from_the_list_of_input_files,
    },
    {
        name: "composite",
        type: "boolean",
        // Not setting affectsEmit because we calculate this flag might not affect full emit
        affectsBuildInfo: true,
        isTSConfigOnly: true,
        category: ts_js_1.Diagnostics.Projects,
        transpileOptionValue: undefined,
        defaultValueDescription: false,
        description: ts_js_1.Diagnostics.Enable_constraints_that_allow_a_TypeScript_project_to_be_used_with_project_references,
    },
    {
        name: "tsBuildInfoFile",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.FILE,
        category: ts_js_1.Diagnostics.Projects,
        transpileOptionValue: undefined,
        defaultValueDescription: ".tsbuildinfo",
        description: ts_js_1.Diagnostics.Specify_the_path_to_tsbuildinfo_incremental_compilation_file,
    },
    {
        name: "removeComments",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Emit,
        defaultValueDescription: false,
        description: ts_js_1.Diagnostics.Disable_emitting_comments,
    },
    {
        name: "importHelpers",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsSourceFile: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Allow_importing_helper_functions_from_tslib_once_per_project_instead_of_including_them_per_file,
        defaultValueDescription: false,
    },
    {
        name: "importsNotUsedAsValues",
        type: new Map(Object.entries({
            remove: 0 /* ImportsNotUsedAsValues.Remove */,
            preserve: 1 /* ImportsNotUsedAsValues.Preserve */,
            error: 2 /* ImportsNotUsedAsValues.Error */,
        })),
        affectsEmit: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Specify_emit_Slashchecking_behavior_for_imports_that_are_only_used_for_types,
        defaultValueDescription: 0 /* ImportsNotUsedAsValues.Remove */,
    },
    {
        name: "downlevelIteration",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Emit_more_compliant_but_verbose_and_less_performant_JavaScript_for_iteration,
        defaultValueDescription: false,
    },
    {
        name: "isolatedModules",
        type: "boolean",
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Ensure_that_each_file_can_be_safely_transpiled_without_relying_on_other_imports,
        transpileOptionValue: true,
        defaultValueDescription: false,
    },
    {
        name: "verbatimModuleSyntax",
        type: "boolean",
        affectsEmit: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Do_not_transform_or_elide_any_imports_or_exports_not_marked_as_type_only_ensuring_they_are_written_in_the_output_file_s_format_based_on_the_module_setting,
        defaultValueDescription: false,
    },
    {
        name: "isolatedDeclarations",
        type: "boolean",
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Require_sufficient_annotation_on_exports_so_other_tools_can_trivially_generate_declaration_files,
        defaultValueDescription: false,
        affectsBuildInfo: true,
        affectsSemanticDiagnostics: true,
    },
    {
        name: "erasableSyntaxOnly",
        type: "boolean",
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Do_not_allow_runtime_constructs_that_are_not_part_of_ECMAScript,
        defaultValueDescription: false,
        affectsBuildInfo: true,
        affectsSemanticDiagnostics: true,
    },
    {
        name: "libReplacement",
        type: "boolean",
        affectsProgramStructure: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Enable_lib_replacement,
        defaultValueDescription: false,
    },
    // Strict Type Checks
    {
        name: "strict",
        type: "boolean",
        // Though this affects semantic diagnostics, affectsSemanticDiagnostics is not set here
        // The value of each strictFlag depends on own strictFlag value or this and never accessed directly.
        // But we need to store `strict` in builf info, even though it won't be examined directly, so that the
        // flags it controls (e.g. `strictNullChecks`) will be retrieved correctly
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_all_strict_type_checking_options,
        defaultValueDescription: true,
    },
    {
        name: "noImplicitAny",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_error_reporting_for_expressions_and_declarations_with_an_implied_any_type,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "strictNullChecks",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.When_type_checking_take_into_account_null_and_undefined,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "strictFunctionTypes",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.When_assigning_functions_check_to_ensure_parameters_and_the_return_values_are_subtype_compatible,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "strictBindCallApply",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Check_that_the_arguments_for_bind_call_and_apply_methods_match_the_original_function,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "strictPropertyInitialization",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Check_for_class_properties_that_are_declared_but_not_set_in_the_constructor,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "strictBuiltinIteratorReturn",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Built_in_iterators_are_instantiated_with_a_TReturn_type_of_undefined_instead_of_any,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "stableTypeOrdering",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        showInHelp: false,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Ensure_types_are_ordered_stably_and_deterministically_across_compilations,
        defaultValueDescription: false,
    },
    {
        name: "noImplicitThis",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_error_reporting_when_this_is_given_the_type_any,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "useUnknownInCatchVariables",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        strictFlag: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Default_catch_clause_variables_as_unknown_instead_of_any,
        defaultValueDescription: ts_js_1.Diagnostics.true_unless_strict_is_false,
    },
    {
        name: "alwaysStrict",
        type: "boolean",
        affectsSourceFile: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Ensure_use_strict_is_always_emitted,
        defaultValueDescription: true,
    },
    // Additional Checks
    {
        name: "noUnusedLocals",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_error_reporting_when_local_variables_aren_t_read,
        defaultValueDescription: false,
    },
    {
        name: "noUnusedParameters",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Raise_an_error_when_a_function_parameter_isn_t_read,
        defaultValueDescription: false,
    },
    {
        name: "exactOptionalPropertyTypes",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Interpret_optional_property_types_as_written_rather_than_adding_undefined,
        defaultValueDescription: false,
    },
    {
        name: "noImplicitReturns",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_error_reporting_for_codepaths_that_do_not_explicitly_return_in_a_function,
        defaultValueDescription: false,
    },
    {
        name: "noFallthroughCasesInSwitch",
        type: "boolean",
        affectsBindDiagnostics: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enable_error_reporting_for_fallthrough_cases_in_switch_statements,
        defaultValueDescription: false,
    },
    {
        name: "noUncheckedIndexedAccess",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Add_undefined_to_a_type_when_accessed_using_an_index,
        defaultValueDescription: false,
    },
    {
        name: "noImplicitOverride",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Ensure_overriding_members_in_derived_classes_are_marked_with_an_override_modifier,
        defaultValueDescription: false,
    },
    {
        name: "noPropertyAccessFromIndexSignature",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        showInSimplifiedHelpView: false,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Enforces_using_indexed_accessors_for_keys_declared_using_an_indexed_type,
        defaultValueDescription: false,
    },
    // Module Resolution
    {
        name: "moduleResolution",
        type: new Map(Object.entries({
            // N.B. The first entry specifies the value shown in `tsc --init`
            node10: ts_js_1.ModuleResolutionKind.Node10,
            node: ts_js_1.ModuleResolutionKind.Node10,
            classic: ts_js_1.ModuleResolutionKind.Classic,
            node16: ts_js_1.ModuleResolutionKind.Node16,
            nodenext: ts_js_1.ModuleResolutionKind.NodeNext,
            bundler: ts_js_1.ModuleResolutionKind.Bundler,
        })),
        deprecatedKeys: new Set(["node", "node10", "classic"]),
        affectsSourceFile: true,
        affectsModuleResolution: true,
        paramType: ts_js_1.Diagnostics.STRATEGY,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_how_TypeScript_looks_up_a_file_from_a_given_module_specifier,
        defaultValueDescription: ts_js_1.Diagnostics.nodenext_if_module_is_nodenext_node16_if_module_is_node16_or_node18_otherwise_bundler,
    },
    {
        name: "baseUrl",
        type: "string",
        affectsModuleResolution: true,
        isFilePath: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_the_base_directory_to_resolve_non_relative_module_names,
    },
    {
        // this option can only be specified in tsconfig.json
        // use type = object to copy the value as-is
        name: "paths",
        type: "object",
        affectsModuleResolution: true,
        allowConfigDirTemplateSubstitution: true,
        isTSConfigOnly: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_a_set_of_entries_that_re_map_imports_to_additional_lookup_locations,
        transpileOptionValue: undefined,
    },
    {
        // this option can only be specified in tsconfig.json
        // use type = object to copy the value as-is
        name: "rootDirs",
        type: "list",
        isTSConfigOnly: true,
        element: {
            name: "rootDirs",
            type: "string",
            isFilePath: true,
        },
        affectsModuleResolution: true,
        allowConfigDirTemplateSubstitution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Allow_multiple_folders_to_be_treated_as_one_when_resolving_modules,
        transpileOptionValue: undefined,
        defaultValueDescription: ts_js_1.Diagnostics.Computed_from_the_list_of_input_files,
    },
    {
        name: "typeRoots",
        type: "list",
        element: {
            name: "typeRoots",
            type: "string",
            isFilePath: true,
        },
        affectsModuleResolution: true,
        allowConfigDirTemplateSubstitution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_multiple_folders_that_act_like_Slashnode_modules_Slash_types,
    },
    {
        name: "types",
        type: "list",
        element: {
            name: "types",
            type: "string",
        },
        affectsProgramStructure: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Specify_type_package_names_to_be_included_without_being_referenced_in_a_source_file,
        transpileOptionValue: undefined,
    },
    {
        name: "allowSyntheticDefaultImports",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Allow_import_x_from_y_when_a_module_doesn_t_have_a_default_export,
        defaultValueDescription: true,
    },
    {
        name: "esModuleInterop",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        showInSimplifiedHelpView: true,
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Emit_additional_JavaScript_to_ease_support_for_importing_CommonJS_modules_This_enables_allowSyntheticDefaultImports_for_type_compatibility,
        defaultValueDescription: true,
    },
    {
        name: "preserveSymlinks",
        type: "boolean",
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Disable_resolving_symlinks_to_their_realpath_This_correlates_to_the_same_flag_in_node,
        defaultValueDescription: false,
    },
    {
        name: "allowUmdGlobalAccess",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Allow_accessing_UMD_globals_from_modules,
        defaultValueDescription: false,
    },
    {
        name: "moduleSuffixes",
        type: "list",
        element: {
            name: "suffix",
            type: "string",
        },
        listPreserveFalsyValues: true,
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.List_of_file_name_suffixes_to_search_when_resolving_a_module,
    },
    {
        name: "allowImportingTsExtensions",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Allow_imports_to_include_TypeScript_file_extensions_Requires_moduleResolution_bundler_and_either_noEmit_or_emitDeclarationOnly_to_be_set,
        defaultValueDescription: false,
        transpileOptionValue: undefined,
    },
    {
        name: "rewriteRelativeImportExtensions",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Rewrite_ts_tsx_mts_and_cts_file_extensions_in_relative_import_paths_to_their_JavaScript_equivalent_in_output_files,
        defaultValueDescription: false,
    },
    {
        name: "resolvePackageJsonExports",
        type: "boolean",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Use_the_package_json_exports_field_when_resolving_package_imports,
        defaultValueDescription: ts_js_1.Diagnostics.true_when_moduleResolution_is_node16_nodenext_or_bundler_otherwise_false,
    },
    {
        name: "resolvePackageJsonImports",
        type: "boolean",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Use_the_package_json_imports_field_when_resolving_imports,
        defaultValueDescription: ts_js_1.Diagnostics.true_when_moduleResolution_is_node16_nodenext_or_bundler_otherwise_false,
    },
    {
        name: "customConditions",
        type: "list",
        element: {
            name: "condition",
            type: "string",
        },
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Conditions_to_set_in_addition_to_the_resolver_specific_defaults_when_resolving_imports,
    },
    {
        name: "noUncheckedSideEffectImports",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Check_side_effect_imports,
        defaultValueDescription: true,
    },
    // Source Maps
    {
        name: "sourceRoot",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        paramType: ts_js_1.Diagnostics.LOCATION,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Specify_the_root_path_for_debuggers_to_find_the_reference_source_code,
    },
    {
        name: "mapRoot",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        paramType: ts_js_1.Diagnostics.LOCATION,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Specify_the_location_where_debugger_should_locate_map_files_instead_of_generated_locations,
    },
    {
        name: "inlineSources",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Include_source_code_in_the_sourcemaps_inside_the_emitted_JavaScript,
        defaultValueDescription: false,
    },
    // Experimental
    {
        name: "experimentalDecorators",
        type: "boolean",
        affectsEmit: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Enable_experimental_support_for_legacy_experimental_decorators,
        defaultValueDescription: false,
    },
    {
        name: "emitDecoratorMetadata",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Emit_design_type_metadata_for_decorated_declarations_in_source_files,
        defaultValueDescription: false,
    },
    // Advanced
    {
        name: "jsxFactory",
        type: "string",
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_the_JSX_factory_function_used_when_targeting_React_JSX_emit_e_g_React_createElement_or_h,
        defaultValueDescription: "`React.createElement`",
    },
    {
        name: "jsxFragmentFactory",
        type: "string",
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_the_JSX_Fragment_reference_used_for_fragments_when_targeting_React_JSX_emit_e_g_React_Fragment_or_Fragment,
        defaultValueDescription: "React.Fragment",
    },
    {
        name: "jsxImportSource",
        type: "string",
        affectsSemanticDiagnostics: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsModuleResolution: true,
        affectsSourceFile: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_module_specifier_used_to_import_the_JSX_factory_functions_when_using_jsx_Colon_react_jsx_Asterisk,
        defaultValueDescription: "react",
    },
    {
        name: "resolveJsonModule",
        type: "boolean",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Enable_importing_json_files,
        defaultValueDescription: false,
    },
    {
        name: "allowArbitraryExtensions",
        type: "boolean",
        affectsProgramStructure: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Enable_importing_files_with_any_extension_provided_a_declaration_file_is_present,
        defaultValueDescription: false,
    },
    {
        name: "out",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsDeclarationPath: true,
        isFilePath: false, // This is intentionally broken to support compatibility with existing tsconfig files
        // for correct behaviour, please use outFile
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        paramType: ts_js_1.Diagnostics.FILE,
        transpileOptionValue: undefined,
        description: ts_js_1.Diagnostics.Deprecated_setting_Use_outFile_instead,
    },
    {
        name: "reactNamespace",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Specify_the_object_invoked_for_createElement_This_only_applies_when_targeting_react_JSX_emit,
        defaultValueDescription: "`React`",
    },
    {
        name: "skipDefaultLibCheck",
        type: "boolean",
        // We need to store these to determine whether `lib` files need to be rechecked
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Completeness,
        description: ts_js_1.Diagnostics.Skip_type_checking_d_ts_files_that_are_included_with_TypeScript,
        defaultValueDescription: false,
    },
    {
        name: "charset",
        type: "string",
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.No_longer_supported_In_early_versions_manually_set_the_text_encoding_for_reading_files,
        defaultValueDescription: "utf8",
    },
    {
        name: "emitBOM",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Emit_a_UTF_8_Byte_Order_Mark_BOM_in_the_beginning_of_output_files,
        defaultValueDescription: false,
    },
    {
        name: "newLine",
        type: new Map(Object.entries({
            crlf: 0 /* NewLineKind.CarriageReturnLineFeed */,
            lf: 1 /* NewLineKind.LineFeed */,
        })),
        affectsEmit: true,
        affectsBuildInfo: true,
        paramType: ts_js_1.Diagnostics.NEWLINE,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Set_the_newline_character_for_emitting_files,
        defaultValueDescription: "lf",
    },
    {
        name: "noErrorTruncation",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Output_Formatting,
        description: ts_js_1.Diagnostics.Disable_truncating_types_in_error_messages,
        defaultValueDescription: false,
    },
    {
        name: "noLib",
        type: "boolean",
        category: ts_js_1.Diagnostics.Language_and_Environment,
        affectsProgramStructure: true,
        description: ts_js_1.Diagnostics.Disable_including_any_library_files_including_the_default_lib_d_ts,
        // We are not returning a sourceFile for lib file when asked by the program,
        // so pass --noLib to avoid reporting a file not found error.
        transpileOptionValue: true,
        defaultValueDescription: false,
    },
    {
        name: "noResolve",
        type: "boolean",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Modules,
        description: ts_js_1.Diagnostics.Disallow_import_s_require_s_or_reference_s_from_expanding_the_number_of_files_TypeScript_should_add_to_a_project,
        // We are not doing a full typecheck, we are not resolving the whole context,
        // so pass --noResolve to avoid reporting missing file errors.
        transpileOptionValue: true,
        defaultValueDescription: false,
    },
    {
        name: "stripInternal",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Disable_emitting_declarations_that_have_internal_in_their_JSDoc_comments,
        defaultValueDescription: false,
    },
    {
        name: "disableSizeLimit",
        type: "boolean",
        affectsProgramStructure: true,
        category: ts_js_1.Diagnostics.Editor_Support,
        description: ts_js_1.Diagnostics.Remove_the_20mb_cap_on_total_source_code_size_for_JavaScript_files_in_the_TypeScript_language_server,
        defaultValueDescription: false,
    },
    {
        name: "disableSourceOfProjectReferenceRedirect",
        type: "boolean",
        isTSConfigOnly: true,
        category: ts_js_1.Diagnostics.Projects,
        description: ts_js_1.Diagnostics.Disable_preferring_source_files_instead_of_declaration_files_when_referencing_composite_projects,
        defaultValueDescription: false,
    },
    {
        name: "disableSolutionSearching",
        type: "boolean",
        isTSConfigOnly: true,
        category: ts_js_1.Diagnostics.Projects,
        description: ts_js_1.Diagnostics.Opt_a_project_out_of_multi_project_reference_checking_when_editing,
        defaultValueDescription: false,
    },
    {
        name: "disableReferencedProjectLoad",
        type: "boolean",
        isTSConfigOnly: true,
        category: ts_js_1.Diagnostics.Projects,
        description: ts_js_1.Diagnostics.Reduce_the_number_of_projects_loaded_automatically_by_TypeScript,
        defaultValueDescription: false,
    },
    {
        name: "noImplicitUseStrict",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Disable_adding_use_strict_directives_in_emitted_JavaScript_files,
        defaultValueDescription: false,
    },
    {
        name: "noEmitHelpers",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Disable_generating_custom_helper_functions_like_extends_in_compiled_output,
        defaultValueDescription: false,
    },
    {
        name: "noEmitOnError",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        transpileOptionValue: undefined,
        description: ts_js_1.Diagnostics.Disable_emitting_files_if_any_type_checking_errors_are_reported,
        defaultValueDescription: false,
    },
    {
        name: "preserveConstEnums",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Emit,
        description: ts_js_1.Diagnostics.Disable_erasing_const_enum_declarations_in_generated_code,
        defaultValueDescription: false,
    },
    {
        name: "declarationDir",
        type: "string",
        affectsEmit: true,
        affectsBuildInfo: true,
        affectsDeclarationPath: true,
        isFilePath: true,
        paramType: ts_js_1.Diagnostics.DIRECTORY,
        category: ts_js_1.Diagnostics.Emit,
        transpileOptionValue: undefined,
        description: ts_js_1.Diagnostics.Specify_the_output_directory_for_generated_declaration_files,
    },
    {
        name: "skipLibCheck",
        type: "boolean",
        // We need to store these to determine whether `lib` files need to be rechecked
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Completeness,
        description: ts_js_1.Diagnostics.Skip_type_checking_all_d_ts_files,
        defaultValueDescription: false,
    },
    {
        name: "allowUnusedLabels",
        type: "boolean",
        affectsBindDiagnostics: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Disable_error_reporting_for_unused_labels,
        defaultValueDescription: undefined,
    },
    {
        name: "allowUnreachableCode",
        type: "boolean",
        affectsBindDiagnostics: true,
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Type_Checking,
        description: ts_js_1.Diagnostics.Disable_error_reporting_for_unreachable_code,
        defaultValueDescription: undefined,
    },
    {
        name: "suppressExcessPropertyErrors",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Disable_reporting_of_excess_property_errors_during_the_creation_of_object_literals,
        defaultValueDescription: false,
    },
    {
        name: "suppressImplicitAnyIndexErrors",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Suppress_noImplicitAny_errors_when_indexing_objects_that_lack_index_signatures,
        defaultValueDescription: false,
    },
    {
        name: "forceConsistentCasingInFileNames",
        type: "boolean",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.Interop_Constraints,
        description: ts_js_1.Diagnostics.Ensure_that_casing_is_correct_in_imports,
        defaultValueDescription: true,
    },
    {
        name: "maxNodeModuleJsDepth",
        type: "number",
        affectsModuleResolution: true,
        category: ts_js_1.Diagnostics.JavaScript_Support,
        description: ts_js_1.Diagnostics.Specify_the_maximum_folder_depth_used_for_checking_JavaScript_files_from_node_modules_Only_applicable_with_allowJs,
        defaultValueDescription: 0,
    },
    {
        name: "noStrictGenericChecks",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Disable_strict_checking_of_generic_signatures_in_function_types,
        defaultValueDescription: false,
    },
    {
        name: "useDefineForClassFields",
        type: "boolean",
        affectsSemanticDiagnostics: true,
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        description: ts_js_1.Diagnostics.Emit_ECMAScript_standard_compliant_class_fields,
        defaultValueDescription: ts_js_1.Diagnostics.true_for_ES2022_and_above_including_ESNext,
    },
    {
        name: "preserveValueImports",
        type: "boolean",
        affectsEmit: true,
        affectsBuildInfo: true,
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Preserve_unused_imported_values_in_the_JavaScript_output_that_would_otherwise_be_removed,
        defaultValueDescription: false,
    },
    {
        name: "keyofStringsOnly",
        type: "boolean",
        category: ts_js_1.Diagnostics.Backwards_Compatibility,
        description: ts_js_1.Diagnostics.Make_keyof_only_return_strings_instead_of_string_numbers_or_symbols_Legacy_option,
        defaultValueDescription: false,
    },
    {
        // A list of plugins to load in the language service
        name: "plugins",
        type: "list",
        isTSConfigOnly: true,
        element: {
            name: "plugin",
            type: "object",
        },
        description: ts_js_1.Diagnostics.Specify_a_list_of_language_service_plugins_to_include,
        category: ts_js_1.Diagnostics.Editor_Support,
    },
    {
        name: "moduleDetection",
        type: new Map(Object.entries({
            auto: ts_js_1.ModuleDetectionKind.Auto,
            legacy: ts_js_1.ModuleDetectionKind.Legacy,
            force: ts_js_1.ModuleDetectionKind.Force,
        })),
        affectsSourceFile: true,
        affectsModuleResolution: true,
        description: ts_js_1.Diagnostics.Control_what_method_is_used_to_detect_module_format_JS_files,
        category: ts_js_1.Diagnostics.Language_and_Environment,
        defaultValueDescription: ts_js_1.Diagnostics.auto_Colon_Treat_files_with_imports_exports_import_meta_jsx_with_jsx_Colon_react_jsx_or_esm_format_with_module_Colon_node16_as_modules,
    },
    {
        name: "ignoreDeprecations",
        type: "string",
        defaultValueDescription: undefined,
    },
];
// Do not delete this without updating the website's tsconfig generation.
/** @internal */
exports.optionDeclarations = [
    ...exports.commonOptionsWithBuild,
    ...commandOptionsWithoutBuild,
];
/** @internal */
exports.semanticDiagnosticsOptionDeclarations = exports.optionDeclarations.filter(option => !!option.affectsSemanticDiagnostics);
/** @internal */
exports.affectsEmitOptionDeclarations = exports.optionDeclarations.filter(option => !!option.affectsEmit);
/** @internal */
exports.affectsDeclarationPathOptionDeclarations = exports.optionDeclarations.filter(option => !!option.affectsDeclarationPath);
/** @internal */
exports.moduleResolutionOptionDeclarations = exports.optionDeclarations.filter(option => !!option.affectsModuleResolution);
/** @internal */
exports.sourceFileAffectingCompilerOptions = exports.optionDeclarations.filter(option => !!option.affectsSourceFile || !!option.affectsBindDiagnostics);
/** @internal */
exports.optionsAffectingProgramStructure = exports.optionDeclarations.filter(option => !!option.affectsProgramStructure);
/** @internal */
exports.transpileOptionValueCompilerOptions = exports.optionDeclarations.filter(option => (0, ts_js_1.hasProperty)(option, "transpileOptionValue"));
const configDirTemplateSubstitutionOptions = exports.optionDeclarations.filter(option => option.allowConfigDirTemplateSubstitution || (!option.isCommandLineOnly && option.isFilePath));
const configDirTemplateSubstitutionWatchOptions = exports.optionsForWatch.filter(option => option.allowConfigDirTemplateSubstitution || (!option.isCommandLineOnly && option.isFilePath));
/** @internal */
exports.commandLineOptionOfCustomType = exports.optionDeclarations.filter(isCommandLineOptionOfCustomType);
function isCommandLineOptionOfCustomType(option) {
    return !(0, ts_js_1.isString)(option.type);
}
/** @internal */
exports.tscBuildOption = {
    name: "build",
    type: "boolean",
    shortName: "b",
    showInSimplifiedHelpView: true,
    category: ts_js_1.Diagnostics.Command_line_Options,
    description: ts_js_1.Diagnostics.Build_one_or_more_projects_and_their_dependencies_if_out_of_date,
    defaultValueDescription: false,
};
// Build related options
/** @internal */
exports.optionsForBuild = [
    exports.tscBuildOption,
    {
        name: "verbose",
        shortName: "v",
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Enable_verbose_logging,
        type: "boolean",
        defaultValueDescription: false,
    },
    {
        name: "dry",
        shortName: "d",
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Show_what_would_be_built_or_deleted_if_specified_with_clean,
        type: "boolean",
        defaultValueDescription: false,
    },
    {
        name: "force",
        shortName: "f",
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Build_all_projects_including_those_that_appear_to_be_up_to_date,
        type: "boolean",
        defaultValueDescription: false,
    },
    {
        name: "clean",
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Delete_the_outputs_of_all_projects,
        type: "boolean",
        defaultValueDescription: false,
    },
    {
        name: "stopBuildOnErrors",
        category: ts_js_1.Diagnostics.Command_line_Options,
        description: ts_js_1.Diagnostics.Skip_building_downstream_projects_on_error_in_upstream_project,
        type: "boolean",
        defaultValueDescription: false,
    },
];
/** @internal */
exports.buildOpts = [
    ...exports.commonOptionsWithBuild,
    ...exports.optionsForBuild,
];
// Do not delete this without updating the website's tsconfig generation.
/** @internal */
exports.typeAcquisitionDeclarations = [
    {
        name: "enable",
        type: "boolean",
        defaultValueDescription: false,
    },
    {
        name: "include",
        type: "list",
        element: {
            name: "include",
            type: "string",
        },
    },
    {
        name: "exclude",
        type: "list",
        element: {
            name: "exclude",
            type: "string",
        },
    },
    {
        name: "disableFilenameBasedTypeAcquisition",
        type: "boolean",
        defaultValueDescription: false,
    },
];
/** @internal */
function createOptionNameMap(optionDeclarations) {
    const optionsNameMap = new Map();
    const shortOptionNames = new Map();
    (0, ts_js_1.forEach)(optionDeclarations, option => {
        optionsNameMap.set(option.name.toLowerCase(), option);
        if (option.shortName) {
            shortOptionNames.set(option.shortName, option.name);
        }
    });
    return { optionsNameMap, shortOptionNames };
}
let optionsNameMapCache;
/** @internal */
function getOptionsNameMap() {
    return optionsNameMapCache || (optionsNameMapCache = createOptionNameMap(exports.optionDeclarations));
}
const compilerOptionsAlternateMode = {
    diagnostic: ts_js_1.Diagnostics.Compiler_option_0_may_only_be_used_with_build,
    getOptionsNameMap: getBuildOptionsNameMap,
};
// Do not delete this without updating the website's tsconfig generation.
/** @internal @knipignore */
exports.defaultInitCompilerOptions = {
    module: ts_js_1.ModuleKind.CommonJS,
    target: 3 /* ScriptTarget.ES2016 */,
    strict: true,
    esModuleInterop: true,
    forceConsistentCasingInFileNames: true,
    skipLibCheck: true,
};
/** @internal */
function createCompilerDiagnosticForInvalidCustomType(opt) {
    return createDiagnosticForInvalidCustomType(opt, ts_js_1.createCompilerDiagnostic);
}
function createDiagnosticForInvalidCustomType(opt, createDiagnostic) {
    const namesOfType = (0, ts_js_1.arrayFrom)(opt.type.keys());
    const stringNames = (opt.deprecatedKeys ? namesOfType.filter(k => !opt.deprecatedKeys.has(k)) : namesOfType).map(key => `'${key}'`).join(", ");
    return createDiagnostic(ts_js_1.Diagnostics.Argument_for_0_option_must_be_Colon_1, `--${opt.name}`, stringNames);
}
/** @internal */
function parseCustomTypeOption(opt, value, errors) {
    return convertJsonOptionOfCustomType(opt, (value ?? "").trim(), errors);
}
/** @internal */
function parseListTypeOption(opt, value = "", errors) {
    value = value.trim();
    if ((0, ts_js_1.startsWith)(value, "-")) {
        return undefined;
    }
    if (opt.type === "listOrElement" && !value.includes(",")) {
        return validateJsonOptionValue(opt, value, errors);
    }
    if (value === "") {
        return [];
    }
    const values = value.split(",");
    switch (opt.element.type) {
        case "number":
            return (0, ts_js_1.mapDefined)(values, v => validateJsonOptionValue(opt.element, parseInt(v), errors));
        case "string":
            return (0, ts_js_1.mapDefined)(values, v => validateJsonOptionValue(opt.element, v || "", errors));
        case "boolean":
        case "object":
            return ts_js_1.Debug.fail(`List of ${opt.element.type} is not yet supported.`);
        default:
            return (0, ts_js_1.mapDefined)(values, v => parseCustomTypeOption(opt.element, v, errors));
    }
}
function getOptionName(option) {
    return option.name;
}
function createUnknownOptionError(unknownOption, diagnostics, unknownOptionErrorText, node, sourceFile) {
    const otherOption = diagnostics.alternateMode?.getOptionsNameMap().optionsNameMap.get(unknownOption.toLowerCase());
    if (otherOption) {
        return createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, node, otherOption !== exports.tscBuildOption ?
            diagnostics.alternateMode.diagnostic :
            ts_js_1.Diagnostics.Option_build_must_be_the_first_command_line_argument, unknownOption);
    }
    const possibleOption = (0, ts_js_1.getSpellingSuggestion)(unknownOption, diagnostics.optionDeclarations, getOptionName);
    return possibleOption ?
        createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, node, diagnostics.unknownDidYouMeanDiagnostic, unknownOptionErrorText || unknownOption, possibleOption.name) :
        createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, node, diagnostics.unknownOptionDiagnostic, unknownOptionErrorText || unknownOption);
}
/** @internal */
function parseCommandLineWorker(diagnostics, commandLine, readFile) {
    const options = {};
    let watchOptions;
    const fileNames = [];
    const errors = [];
    parseStrings(commandLine);
    return {
        options,
        watchOptions,
        fileNames,
        errors,
    };
    function parseStrings(args) {
        let i = 0;
        while (i < args.length) {
            const s = args[i];
            i++;
            if (s.charCodeAt(0) === 64 /* CharacterCodes.at */) {
                parseResponseFile(s.slice(1));
            }
            else if (s.charCodeAt(0) === 45 /* CharacterCodes.minus */) {
                const inputOptionName = s.slice(s.charCodeAt(1) === 45 /* CharacterCodes.minus */ ? 2 : 1);
                const opt = getOptionDeclarationFromName(diagnostics.getOptionsNameMap, inputOptionName, /*allowShort*/ true);
                if (opt) {
                    i = parseOptionValue(args, i, diagnostics, opt, options, errors);
                }
                else {
                    const watchOpt = getOptionDeclarationFromName(watchOptionsDidYouMeanDiagnostics.getOptionsNameMap, inputOptionName, /*allowShort*/ true);
                    if (watchOpt) {
                        i = parseOptionValue(args, i, watchOptionsDidYouMeanDiagnostics, watchOpt, watchOptions || (watchOptions = {}), errors);
                    }
                    else {
                        errors.push(createUnknownOptionError(inputOptionName, diagnostics, s));
                    }
                }
            }
            else {
                fileNames.push(s);
            }
        }
    }
    function parseResponseFile(fileName) {
        const text = tryReadFile(fileName, readFile || (fileName => ts_js_1.sys.readFile(fileName)));
        if (!(0, ts_js_1.isString)(text)) {
            errors.push(text);
            return;
        }
        const args = [];
        let pos = 0;
        while (true) {
            while (pos < text.length && text.charCodeAt(pos) <= 32 /* CharacterCodes.space */)
                pos++;
            if (pos >= text.length)
                break;
            const start = pos;
            if (text.charCodeAt(start) === 34 /* CharacterCodes.doubleQuote */) {
                pos++;
                while (pos < text.length && text.charCodeAt(pos) !== 34 /* CharacterCodes.doubleQuote */)
                    pos++;
                if (pos < text.length) {
                    args.push(text.substring(start + 1, pos));
                    pos++;
                }
                else {
                    errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Unterminated_quoted_string_in_response_file_0, fileName));
                }
            }
            else {
                while (text.charCodeAt(pos) > 32 /* CharacterCodes.space */)
                    pos++;
                args.push(text.substring(start, pos));
            }
        }
        parseStrings(args);
    }
}
function parseOptionValue(args, i, diagnostics, opt, options, errors) {
    if (opt.isTSConfigOnly) {
        const optValue = args[i];
        if (optValue === "null") {
            options[opt.name] = undefined;
            i++;
        }
        else if (opt.type === "boolean") {
            if (optValue === "false") {
                options[opt.name] = validateJsonOptionValue(opt, /*value*/ false, errors);
                i++;
            }
            else {
                if (optValue === "true")
                    i++;
                errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Option_0_can_only_be_specified_in_tsconfig_json_file_or_set_to_false_or_null_on_command_line, opt.name));
            }
        }
        else {
            errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Option_0_can_only_be_specified_in_tsconfig_json_file_or_set_to_null_on_command_line, opt.name));
            if (optValue && !(0, ts_js_1.startsWith)(optValue, "-"))
                i++;
        }
    }
    else {
        // Check to see if no argument was provided (e.g. "--locale" is the last command-line argument).
        if (!args[i] && opt.type !== "boolean") {
            errors.push((0, ts_js_1.createCompilerDiagnostic)(diagnostics.optionTypeMismatchDiagnostic, opt.name, getCompilerOptionValueTypeString(opt)));
        }
        if (args[i] !== "null") {
            switch (opt.type) {
                case "number":
                    options[opt.name] = validateJsonOptionValue(opt, parseInt(String(args[i])), errors);
                    i++;
                    break;
                case "boolean":
                    // boolean flag has optional value true, false, others
                    const optValue = args[i];
                    options[opt.name] = validateJsonOptionValue(opt, optValue !== "false", errors);
                    // consume next argument as boolean flag value
                    if (optValue === "false" || optValue === "true") {
                        i++;
                    }
                    break;
                case "string":
                    options[opt.name] = validateJsonOptionValue(opt, args[i] || "", errors);
                    i++;
                    break;
                case "list":
                    const result = parseListTypeOption(opt, args[i], errors);
                    options[opt.name] = result || [];
                    if (result) {
                        i++;
                    }
                    break;
                case "listOrElement":
                    ts_js_1.Debug.fail("listOrElement not supported here");
                    break;
                // If not a primitive, the possible types are specified in what is effectively a map of options.
                default:
                    options[opt.name] = parseCustomTypeOption(opt, args[i], errors);
                    i++;
                    break;
            }
        }
        else {
            options[opt.name] = undefined;
            i++;
        }
    }
    return i;
}
/** @internal */
exports.compilerOptionsDidYouMeanDiagnostics = {
    alternateMode: compilerOptionsAlternateMode,
    getOptionsNameMap,
    optionDeclarations: exports.optionDeclarations,
    unknownOptionDiagnostic: ts_js_1.Diagnostics.Unknown_compiler_option_0,
    unknownDidYouMeanDiagnostic: ts_js_1.Diagnostics.Unknown_compiler_option_0_Did_you_mean_1,
    optionTypeMismatchDiagnostic: ts_js_1.Diagnostics.Compiler_option_0_expects_an_argument,
};
function parseCommandLine(commandLine, readFile) {
    return parseCommandLineWorker(exports.compilerOptionsDidYouMeanDiagnostics, commandLine, readFile);
}
/** @internal */
function getOptionFromName(optionName, allowShort) {
    return getOptionDeclarationFromName(getOptionsNameMap, optionName, allowShort);
}
function getOptionDeclarationFromName(getOptionNameMap, optionName, allowShort = false) {
    optionName = optionName.toLowerCase();
    const { optionsNameMap, shortOptionNames } = getOptionNameMap();
    // Try to translate short option names to their full equivalents.
    if (allowShort) {
        const short = shortOptionNames.get(optionName);
        if (short !== undefined) {
            optionName = short;
        }
    }
    return optionsNameMap.get(optionName);
}
let buildOptionsNameMapCache;
function getBuildOptionsNameMap() {
    return buildOptionsNameMapCache || (buildOptionsNameMapCache = createOptionNameMap(exports.buildOpts));
}
const buildOptionsAlternateMode = {
    diagnostic: ts_js_1.Diagnostics.Compiler_option_0_may_not_be_used_with_build,
    getOptionsNameMap,
};
const buildOptionsDidYouMeanDiagnostics = {
    alternateMode: buildOptionsAlternateMode,
    getOptionsNameMap: getBuildOptionsNameMap,
    optionDeclarations: exports.buildOpts,
    unknownOptionDiagnostic: ts_js_1.Diagnostics.Unknown_build_option_0,
    unknownDidYouMeanDiagnostic: ts_js_1.Diagnostics.Unknown_build_option_0_Did_you_mean_1,
    optionTypeMismatchDiagnostic: ts_js_1.Diagnostics.Build_option_0_requires_a_value_of_type_1,
};
function parseBuildCommand(commandLine) {
    const { options, watchOptions, fileNames: projects, errors } = parseCommandLineWorker(buildOptionsDidYouMeanDiagnostics, commandLine);
    const buildOptions = options;
    if (projects.length === 0) {
        // tsc -b invoked with no extra arguments; act as if invoked with "tsc -b ."
        projects.push(".");
    }
    // Nonsensical combinations
    if (buildOptions.clean && buildOptions.force) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Options_0_and_1_cannot_be_combined, "clean", "force"));
    }
    if (buildOptions.clean && buildOptions.verbose) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Options_0_and_1_cannot_be_combined, "clean", "verbose"));
    }
    if (buildOptions.clean && buildOptions.watch) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Options_0_and_1_cannot_be_combined, "clean", "watch"));
    }
    if (buildOptions.watch && buildOptions.dry) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Options_0_and_1_cannot_be_combined, "watch", "dry"));
    }
    return { buildOptions, watchOptions, projects, errors };
}
/** @internal */
function getDiagnosticText(message, ...args) {
    return (0, ts_js_1.cast)((0, ts_js_1.createCompilerDiagnostic)(message, ...args).messageText, ts_js_1.isString);
}
/**
 * Reads the config file, reports errors if any and exits if the config file cannot be found
 */
function getParsedCommandLineOfConfigFile(configFileName, optionsToExtend, host, extendedConfigCache, watchOptionsToExtend, extraFileExtensions) {
    const configFileText = tryReadFile(configFileName, fileName => host.readFile(fileName));
    if (!(0, ts_js_1.isString)(configFileText)) {
        host.onUnRecoverableConfigFileDiagnostic(configFileText);
        return undefined;
    }
    const result = (0, ts_js_1.parseJsonText)(configFileName, configFileText);
    const cwd = host.getCurrentDirectory();
    result.path = (0, ts_js_1.toPath)(configFileName, cwd, (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames));
    result.resolvedPath = result.path;
    result.originalFileName = result.fileName;
    return parseJsonSourceFileConfigFileContent(result, host, (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getDirectoryPath)(configFileName), cwd), optionsToExtend, (0, ts_js_1.getNormalizedAbsolutePath)(configFileName, cwd), 
    /*resolutionStack*/ undefined, extraFileExtensions, extendedConfigCache, watchOptionsToExtend);
}
/**
 * Read tsconfig.json file
 * @param fileName The path to the config file
 */
function readConfigFile(fileName, readFile) {
    const textOrDiagnostic = tryReadFile(fileName, readFile);
    return (0, ts_js_1.isString)(textOrDiagnostic) ? parseConfigFileTextToJson(fileName, textOrDiagnostic) : { config: {}, error: textOrDiagnostic };
}
/**
 * Parse the text of the tsconfig.json file
 * @param fileName The path to the config file
 * @param jsonText The text of the config file
 */
function parseConfigFileTextToJson(fileName, jsonText) {
    const jsonSourceFile = (0, ts_js_1.parseJsonText)(fileName, jsonText);
    return {
        config: convertConfigFileToObject(jsonSourceFile, jsonSourceFile.parseDiagnostics, /*jsonConversionNotifier*/ undefined),
        error: jsonSourceFile.parseDiagnostics.length ? jsonSourceFile.parseDiagnostics[0] : undefined,
    };
}
/**
 * Read tsconfig.json file
 * @param fileName The path to the config file
 */
function readJsonConfigFile(fileName, readFile) {
    const textOrDiagnostic = tryReadFile(fileName, readFile);
    return (0, ts_js_1.isString)(textOrDiagnostic) ? (0, ts_js_1.parseJsonText)(fileName, textOrDiagnostic) : { fileName, parseDiagnostics: [textOrDiagnostic] };
}
/** @internal */
function tryReadFile(fileName, readFile) {
    let text;
    try {
        text = readFile(fileName);
    }
    catch (e) {
        return (0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Cannot_read_file_0_Colon_1, fileName, String((0, hostErrors_js_1.propertyOf)(e, "message")));
    }
    return text === undefined ? (0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Cannot_read_file_0, fileName) : text;
}
function commandLineOptionsToMap(options) {
    return (0, ts_js_1.arrayToMap)(options, getOptionName);
}
const typeAcquisitionDidYouMeanDiagnostics = {
    optionDeclarations: exports.typeAcquisitionDeclarations,
    unknownOptionDiagnostic: ts_js_1.Diagnostics.Unknown_type_acquisition_option_0,
    unknownDidYouMeanDiagnostic: ts_js_1.Diagnostics.Unknown_type_acquisition_option_0_Did_you_mean_1,
};
let watchOptionsNameMapCache;
function getWatchOptionsNameMap() {
    return watchOptionsNameMapCache || (watchOptionsNameMapCache = createOptionNameMap(exports.optionsForWatch));
}
const watchOptionsDidYouMeanDiagnostics = {
    getOptionsNameMap: getWatchOptionsNameMap,
    optionDeclarations: exports.optionsForWatch,
    unknownOptionDiagnostic: ts_js_1.Diagnostics.Unknown_watch_option_0,
    unknownDidYouMeanDiagnostic: ts_js_1.Diagnostics.Unknown_watch_option_0_Did_you_mean_1,
    optionTypeMismatchDiagnostic: ts_js_1.Diagnostics.Watch_option_0_requires_a_value_of_type_1,
};
let commandLineCompilerOptionsMapCache;
function getCommandLineCompilerOptionsMap() {
    return commandLineCompilerOptionsMapCache || (commandLineCompilerOptionsMapCache = commandLineOptionsToMap(exports.optionDeclarations));
}
let commandLineWatchOptionsMapCache;
function getCommandLineWatchOptionsMap() {
    return commandLineWatchOptionsMapCache || (commandLineWatchOptionsMapCache = commandLineOptionsToMap(exports.optionsForWatch));
}
let commandLineTypeAcquisitionMapCache;
function getCommandLineTypeAcquisitionMap() {
    return commandLineTypeAcquisitionMapCache || (commandLineTypeAcquisitionMapCache = commandLineOptionsToMap(exports.typeAcquisitionDeclarations));
}
const extendsOptionDeclaration = {
    name: "extends",
    type: "listOrElement",
    element: {
        name: "extends",
        type: "string",
    },
    category: ts_js_1.Diagnostics.File_Management,
    disallowNullOrUndefined: true,
};
const compilerOptionsDeclaration = {
    name: "compilerOptions",
    type: "object",
    elementOptions: getCommandLineCompilerOptionsMap(),
    extraKeyDiagnostics: exports.compilerOptionsDidYouMeanDiagnostics,
};
const watchOptionsDeclaration = {
    name: "watchOptions",
    type: "object",
    elementOptions: getCommandLineWatchOptionsMap(),
    extraKeyDiagnostics: watchOptionsDidYouMeanDiagnostics,
};
const typeAcquisitionDeclaration = {
    name: "typeAcquisition",
    type: "object",
    elementOptions: getCommandLineTypeAcquisitionMap(),
    extraKeyDiagnostics: typeAcquisitionDidYouMeanDiagnostics,
};
let _tsconfigRootOptions;
function getTsconfigRootOptionsMap() {
    if (_tsconfigRootOptions === undefined) {
        _tsconfigRootOptions = {
            name: undefined, // should never be needed since this is root
            type: "object",
            elementOptions: commandLineOptionsToMap([
                compilerOptionsDeclaration,
                watchOptionsDeclaration,
                typeAcquisitionDeclaration,
                extendsOptionDeclaration,
                {
                    name: "references",
                    type: "list",
                    element: {
                        name: "references",
                        type: "object",
                    },
                    category: ts_js_1.Diagnostics.Projects,
                },
                {
                    name: "files",
                    type: "list",
                    element: {
                        name: "files",
                        type: "string",
                    },
                    category: ts_js_1.Diagnostics.File_Management,
                },
                {
                    name: "include",
                    type: "list",
                    element: {
                        name: "include",
                        type: "string",
                    },
                    category: ts_js_1.Diagnostics.File_Management,
                    defaultValueDescription: ts_js_1.Diagnostics.if_files_is_specified_otherwise_Asterisk_Asterisk_Slash_Asterisk,
                },
                {
                    name: "exclude",
                    type: "list",
                    element: {
                        name: "exclude",
                        type: "string",
                    },
                    category: ts_js_1.Diagnostics.File_Management,
                    defaultValueDescription: ts_js_1.Diagnostics.node_modules_bower_components_jspm_packages_plus_the_value_of_outDir_if_one_is_specified,
                },
                compileOnSaveCommandLineOption,
            ]),
        };
    }
    return _tsconfigRootOptions;
}
/** @internal */
function isAdamicJsonObject(value) {
    return typeof value === "object" && value !== null || typeof value === "function";
}
/** @internal */
function checkedAdamicJsonObject(value) {
    if (!isAdamicJsonObject(value))
        throw new TypeError("Expected a JSON/config object");
    return value;
}
function convertConfigFileToObject(sourceFile, errors, jsonConversionNotifier) {
    const rootExpression = sourceFile.statements[0]?.expression;
    if (rootExpression && rootExpression.kind !== 211 /* SyntaxKind.ObjectLiteralExpression */) {
        errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, rootExpression, ts_js_1.Diagnostics.The_root_value_of_a_0_file_must_be_an_object, (0, ts_js_1.getBaseFileName)(sourceFile.fileName) === "jsconfig.json" ? "jsconfig.json" : "tsconfig.json"));
        // Last-ditch error recovery. Somewhat useful because the JSON parser will recover from some parse errors by
        // synthesizing a top-level array literal expression. There's a reasonable chance the first element of that
        // array is a well-formed configuration object, made into an array element by stray characters.
        if ((0, ts_js_1.isArrayLiteralExpression)(rootExpression)) {
            const firstObject = (0, ts_js_1.find)(rootExpression.elements, ts_js_1.isObjectLiteralExpression);
            if (firstObject) {
                return convertToJson(sourceFile, firstObject, errors, /*returnValue*/ true, jsonConversionNotifier);
            }
        }
        return {};
    }
    return convertToJson(sourceFile, rootExpression, errors, /*returnValue*/ true, jsonConversionNotifier);
}
/**
 * Convert the json syntax tree into the json value
 */
function convertToObject(sourceFile, errors) {
    return convertToJson(sourceFile, sourceFile.statements[0]?.expression, errors, /*returnValue*/ true, /*jsonConversionNotifier*/ undefined);
}
/**
 * Convert the json syntax tree into the json value and report errors
 * This returns the json value (apart from checking errors) only if returnValue provided is true.
 * Otherwise it just checks the errors and returns undefined
 *
 * @internal
 */
function convertToJson(sourceFile, rootExpression, errors, returnValue, jsonConversionNotifier) {
    if (!rootExpression) {
        return returnValue ? {} : undefined;
    }
    return convertPropertyValueToJson(rootExpression, jsonConversionNotifier?.rootOptions);
    function convertObjectLiteralExpressionToJson(node, objectOption) {
        const result = returnValue ? {} : undefined;
        for (const element of node.properties) {
            if (element.kind !== 304 /* SyntaxKind.PropertyAssignment */) {
                errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, element, ts_js_1.Diagnostics.Property_assignment_expected));
                continue;
            }
            if (element.questionToken) {
                errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, element.questionToken, ts_js_1.Diagnostics.The_0_modifier_can_only_be_used_in_TypeScript_files, "?"));
            }
            if (!isDoubleQuotedString(element.name)) {
                errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, element.name, ts_js_1.Diagnostics.String_literal_with_double_quotes_expected));
            }
            const textOfKey = (0, ts_js_1.isComputedNonLiteralName)(element.name) ? undefined : (0, ts_js_1.getTextOfPropertyName)(element.name);
            const keyText = textOfKey && (0, ts_js_1.unescapeLeadingUnderscores)(textOfKey);
            const option = keyText ? objectOption?.elementOptions?.get(keyText) : undefined;
            const value = convertPropertyValueToJson(element.initializer, option);
            if (typeof keyText !== "undefined") {
                if (returnValue) {
                    result[keyText] = value;
                }
                // Notify key value set, if user asked for it
                jsonConversionNotifier?.onPropertySet(keyText, value, element, objectOption, option);
            }
        }
        return result;
    }
    function convertArrayLiteralExpressionToJson(elements, elementOption) {
        if (!returnValue) {
            elements.forEach(element => convertPropertyValueToJson(element, elementOption));
            return undefined;
        }
        // Filter out invalid values
        return (0, ts_js_1.filter)(elements.map(element => convertPropertyValueToJson(element, elementOption)), v => v !== undefined);
    }
    function convertPropertyValueToJson(valueExpression, option) {
        switch (valueExpression.kind) {
            case 112 /* SyntaxKind.TrueKeyword */:
                return true;
            case 97 /* SyntaxKind.FalseKeyword */:
                return false;
            case 106 /* SyntaxKind.NullKeyword */:
                return null; // eslint-disable-line no-restricted-syntax
            case 11 /* SyntaxKind.StringLiteral */:
                if (!isDoubleQuotedString(valueExpression)) {
                    errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, valueExpression, ts_js_1.Diagnostics.String_literal_with_double_quotes_expected));
                }
                return valueExpression.text;
            case 9 /* SyntaxKind.NumericLiteral */:
                return Number(valueExpression.text);
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
                if (valueExpression.operator !== 41 /* SyntaxKind.MinusToken */ || valueExpression.operand.kind !== 9 /* SyntaxKind.NumericLiteral */) {
                    break; // not valid JSON syntax
                }
                return -Number(valueExpression.operand.text);
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                const objectLiteralExpression = valueExpression;
                // Currently having element option declaration in the tsconfig with type "object"
                // determines if it needs onSetValidOptionKeyValueInParent callback or not
                // At moment there are only "compilerOptions", "typeAcquisition" and "typingOptions"
                // that satisfies it and need it to modify options set in them (for normalizing file paths)
                // vs what we set in the json
                // If need arises, we can modify this interface and callbacks as needed
                return convertObjectLiteralExpressionToJson(objectLiteralExpression, option);
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
                return convertArrayLiteralExpressionToJson(valueExpression.elements, option && option.element);
        }
        // Not in expected format
        if (option) {
            errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, valueExpression, ts_js_1.Diagnostics.Compiler_option_0_requires_a_value_of_type_1, option.name, getCompilerOptionValueTypeString(option)));
        }
        else {
            errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, valueExpression, ts_js_1.Diagnostics.Property_value_can_only_be_string_literal_numeric_literal_true_false_null_object_literal_or_array_literal));
        }
        return undefined;
    }
    function isDoubleQuotedString(node) {
        return (0, ts_js_1.isStringLiteral)(node) && (0, ts_js_1.isStringDoubleQuoted)(node, sourceFile);
    }
}
function getCompilerOptionValueTypeString(option) {
    return (option.type === "listOrElement") ?
        `${getCompilerOptionValueTypeString(option.element)} or Array` :
        option.type === "list" ?
            "Array" :
            (0, ts_js_1.isString)(option.type) ? option.type : "string";
}
function isCompilerOptionsValue(option, value) {
    if (option) {
        if (isNullOrUndefined(value))
            return !option.disallowNullOrUndefined; // All options are undefinable/nullable
        if (option.type === "list") {
            return (0, ts_js_1.isArray)(value);
        }
        if (option.type === "listOrElement") {
            return (0, ts_js_1.isArray)(value) || isCompilerOptionsValue(option.element, value);
        }
        const expectedType = (0, ts_js_1.isString)(option.type) ? option.type : "string";
        return typeof value === expectedType;
    }
    return false;
}
/**
 * Generate an uncommented, complete tsconfig for use with "--showConfig"
 * @param configParseResult options to be generated into tsconfig.json
 * @param configFileName name of the parsed config file - output paths will be generated relative to this
 * @param host provides current directory and case sensitivity services
 *
 * @internal
 */
function convertToTSConfig(configParseResult, configFileName, host) {
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames);
    const files = (0, ts_js_1.map)((0, ts_js_1.filter)(configParseResult.fileNames, !configParseResult.options.configFile?.configFileSpecs?.validatedIncludeSpecs ? ts_js_1.returnTrue : matchesSpecs(configFileName, configParseResult.options.configFile.configFileSpecs.validatedIncludeSpecs, configParseResult.options.configFile.configFileSpecs.validatedExcludeSpecs, host)), f => (0, ts_js_1.getRelativePathFromFile)((0, ts_js_1.getNormalizedAbsolutePath)(configFileName, host.getCurrentDirectory()), (0, ts_js_1.getNormalizedAbsolutePath)(f, host.getCurrentDirectory()), getCanonicalFileName));
    const pathOptions = { configFilePath: (0, ts_js_1.getNormalizedAbsolutePath)(configFileName, host.getCurrentDirectory()), useCaseSensitiveFileNames: host.useCaseSensitiveFileNames };
    const optionMap = serializeCompilerOptions(configParseResult.options, pathOptions);
    const watchOptionMap = configParseResult.watchOptions && serializeWatchOptions(configParseResult.watchOptions);
    const config = {
        compilerOptions: {
            ...optionMapToObject(optionMap),
            showConfig: undefined,
            configFile: undefined,
            configFilePath: undefined,
            help: undefined,
            init: undefined,
            listFiles: undefined,
            listEmittedFiles: undefined,
            project: undefined,
            build: undefined,
            version: undefined,
        },
        watchOptions: watchOptionMap && optionMapToObject(watchOptionMap),
        references: (0, ts_js_1.map)(configParseResult.projectReferences, r => ({ ...r, path: r.originalPath ? r.originalPath : "", originalPath: undefined })),
        files: (0, ts_js_1.length)(files) ? files : undefined,
        ...(configParseResult.options.configFile?.configFileSpecs ? {
            include: filterSameAsDefaultInclude(configParseResult.options.configFile.configFileSpecs.validatedIncludeSpecs),
            exclude: configParseResult.options.configFile.configFileSpecs.validatedExcludeSpecs,
        } : {}),
        compileOnSave: !!configParseResult.compileOnSave ? true : undefined,
    };
    const providedKeys = new Set(optionMap.keys());
    const impliedCompilerOptions = {};
    for (const option in ts_js_1.computedOptions) {
        if (!providedKeys.has(option) && optionDependsOn(option, providedKeys)) {
            const implied = ts_js_1.computedOptions[option].computeValue(configParseResult.options);
            const defaultValue = ts_js_1.computedOptions[option].computeValue({});
            if (implied !== defaultValue) {
                impliedCompilerOptions[option] = ts_js_1.computedOptions[option].computeValue(configParseResult.options);
            }
        }
    }
    (0, ts_js_1.assign)(config.compilerOptions, optionMapToObject(serializeCompilerOptions(impliedCompilerOptions, pathOptions)));
    return config;
}
function optionDependsOn(option, dependsOn) {
    const seen = new Set();
    return optionDependsOnRecursive(option);
    function optionDependsOnRecursive(option) {
        if ((0, ts_js_1.addToSeen)(seen, option)) {
            return (0, ts_js_1.some)(ts_js_1.computedOptions[option]?.dependencies, dep => dependsOn.has(dep) || optionDependsOnRecursive(dep));
        }
        return false;
    }
}
/** @internal */
function optionMapToObject(optionMap) {
    return Object.fromEntries(optionMap);
}
function filterSameAsDefaultInclude(specs) {
    if (!(0, ts_js_1.length)(specs))
        return undefined;
    if ((0, ts_js_1.length)(specs) !== 1)
        return specs;
    if (specs[0] === defaultIncludeSpec)
        return undefined;
    return specs;
}
function matchesSpecs(path, includeSpecs, excludeSpecs, host) {
    if (!includeSpecs)
        return ts_js_1.returnTrue;
    const patterns = (0, ts_js_1.getFileMatcherPatterns)(path, excludeSpecs, includeSpecs, host.useCaseSensitiveFileNames, host.getCurrentDirectory());
    const excludeRe = patterns.excludePattern && (0, ts_js_1.getRegexFromPattern)(patterns.excludePattern, host.useCaseSensitiveFileNames);
    const includeRe = patterns.includeFilePattern && (0, ts_js_1.getRegexFromPattern)(patterns.includeFilePattern, host.useCaseSensitiveFileNames);
    if (includeRe) {
        if (excludeRe) {
            return path => !(includeRe.test(path) && !excludeRe.test(path));
        }
        return path => !includeRe.test(path);
    }
    if (excludeRe) {
        return path => excludeRe.test(path);
    }
    return ts_js_1.returnTrue;
}
function getCustomTypeMapOfCommandLineOption(optionDefinition) {
    switch (optionDefinition.type) {
        case "string":
        case "number":
        case "boolean":
        case "object":
            // this is of a type CommandLineOptionOfPrimitiveType
            return undefined;
        case "list":
        case "listOrElement":
            return getCustomTypeMapOfCommandLineOption(optionDefinition.element);
        default:
            return optionDefinition.type;
    }
}
/** @internal */
function getNameOfCompilerOptionValue(value, customTypeMap) {
    // There is a typeMap associated with this command-line option so use it to map value back to its name
    return (0, ts_js_1.forEachEntry)(customTypeMap, (mapValue, key) => {
        if (mapValue === value) {
            return key;
        }
    });
}
/** @internal */
function serializeCompilerOptions(options, pathOptions) {
    return serializeOptionBaseObject(options, getOptionsNameMap(), pathOptions);
}
function serializeWatchOptions(options) {
    return serializeOptionBaseObject(options, getWatchOptionsNameMap());
}
function serializeOptionBaseObject(options, { optionsNameMap }, pathOptions) {
    const result = new Map();
    const getCanonicalFileName = pathOptions && (0, ts_js_1.createGetCanonicalFileName)(pathOptions.useCaseSensitiveFileNames);
    for (const name in options) {
        if ((0, ts_js_1.hasProperty)(options, name)) {
            // tsconfig only options cannot be specified via command line,
            // so we can assume that only types that can appear here string | number | boolean
            if (optionsNameMap.has(name) && (optionsNameMap.get(name).category === ts_js_1.Diagnostics.Command_line_Options || optionsNameMap.get(name).category === ts_js_1.Diagnostics.Output_Formatting)) {
                continue;
            }
            const value = options[name];
            const optionDefinition = optionsNameMap.get(name.toLowerCase());
            if (optionDefinition) {
                ts_js_1.Debug.assert(optionDefinition.type !== "listOrElement");
                const customTypeMap = getCustomTypeMapOfCommandLineOption(optionDefinition);
                if (!customTypeMap) {
                    // There is no map associated with this compiler option then use the value as-is
                    // This is the case if the value is expect to be string, number, boolean or list of string
                    if (pathOptions && optionDefinition.isFilePath) {
                        ts_js_1.Debug.assert(typeof value === "string");
                        result.set(name, (0, ts_js_1.getRelativePathFromFile)(pathOptions.configFilePath, (0, ts_js_1.getNormalizedAbsolutePath)(value, (0, ts_js_1.getDirectoryPath)(pathOptions.configFilePath)), getCanonicalFileName));
                    }
                    else if (pathOptions && optionDefinition.type === "list" && optionDefinition.element.isFilePath) {
                        result.set(name, value.map(v => (0, ts_js_1.getRelativePathFromFile)(pathOptions.configFilePath, (0, ts_js_1.getNormalizedAbsolutePath)(v, (0, ts_js_1.getDirectoryPath)(pathOptions.configFilePath)), getCanonicalFileName)));
                    }
                    else {
                        result.set(name, value);
                    }
                }
                else {
                    if (optionDefinition.type === "list") {
                        result.set(name, value.map(element => getNameOfCompilerOptionValue(element, customTypeMap))); // TODO: GH#18217
                    }
                    else {
                        // There is a typeMap associated with this command-line option so use it to map value back to its name
                        result.set(name, getNameOfCompilerOptionValue(value, customTypeMap));
                    }
                }
            }
        }
    }
    return result;
}
/**
 * Generate tsconfig configuration when running command line "--init"
 * @param options commandlineOptions to be generated into tsconfig.json
 * @internal
 */
function generateTSConfig(options, newLine) {
    const tab = "  ";
    const result = [];
    const allSetOptions = Object.keys(options).filter(k => k !== "init" && k !== "help" && k !== "watch");
    result.push(`{`);
    result.push(`${tab}// ${(0, ts_js_1.getLocaleSpecificMessage)(ts_js_1.Diagnostics.Visit_https_Colon_Slash_Slashaka_ms_Slashtsconfig_to_read_more_about_this_file)}`);
    result.push(`${tab}"compilerOptions": {`);
    emitHeader(ts_js_1.Diagnostics.File_Layout);
    emitOption("rootDir", "./src", "optional");
    emitOption("outDir", "./dist", "optional");
    newline();
    emitHeader(ts_js_1.Diagnostics.Environment_Settings);
    emitHeader(ts_js_1.Diagnostics.See_also_https_Colon_Slash_Slashaka_ms_Slashtsconfig_Slashmodule);
    emitOption("module", ts_js_1.ModuleKind.NodeNext);
    emitOption("target", 99 /* ScriptTarget.ESNext */);
    emitOption("types", []);
    if (options.lib) {
        emitOption("lib", options.lib);
    }
    emitHeader(ts_js_1.Diagnostics.For_nodejs_Colon);
    result.push(`${tab}${tab}// "lib": ["esnext"],`);
    result.push(`${tab}${tab}// "types": ["node"],`);
    emitHeader(ts_js_1.Diagnostics.and_npm_install_D_types_Slashnode);
    newline();
    emitHeader(ts_js_1.Diagnostics.Other_Outputs);
    emitOption("sourceMap", /*defaultValue*/ true);
    emitOption("declaration", /*defaultValue*/ true);
    emitOption("declarationMap", /*defaultValue*/ true);
    newline();
    emitHeader(ts_js_1.Diagnostics.Stricter_Typechecking_Options);
    emitOption("noUncheckedIndexedAccess", /*defaultValue*/ true);
    emitOption("exactOptionalPropertyTypes", /*defaultValue*/ true);
    newline();
    emitHeader(ts_js_1.Diagnostics.Style_Options);
    emitOption("noImplicitReturns", /*defaultValue*/ true, "optional");
    emitOption("noImplicitOverride", /*defaultValue*/ true, "optional");
    emitOption("noUnusedLocals", /*defaultValue*/ true, "optional");
    emitOption("noUnusedParameters", /*defaultValue*/ true, "optional");
    emitOption("noFallthroughCasesInSwitch", /*defaultValue*/ true, "optional");
    emitOption("noPropertyAccessFromIndexSignature", /*defaultValue*/ true, "optional");
    newline();
    emitHeader(ts_js_1.Diagnostics.Recommended_Options);
    emitOption("strict", /*defaultValue*/ true);
    emitOption("jsx", 4 /* JsxEmit.ReactJSX */);
    emitOption("verbatimModuleSyntax", /*defaultValue*/ true);
    emitOption("isolatedModules", /*defaultValue*/ true);
    emitOption("noUncheckedSideEffectImports", /*defaultValue*/ true);
    emitOption("moduleDetection", ts_js_1.ModuleDetectionKind.Force);
    emitOption("skipLibCheck", /*defaultValue*/ true);
    // Write any user-provided options we haven't already
    if (allSetOptions.length > 0) {
        newline();
        while (allSetOptions.length > 0) {
            emitOption(allSetOptions[0], options[allSetOptions[0]]);
        }
    }
    function newline() {
        result.push("");
    }
    function emitHeader(header) {
        result.push(`${tab}${tab}// ${(0, ts_js_1.getLocaleSpecificMessage)(header)}`);
    }
    // commented = 'always': Always comment this out, even if it's on commandline
    // commented = 'optional': Comment out unless it's on commandline
    // commented = 'never': Never comment this out
    function emitOption(setting, defaultValue, commented = "never") {
        const existingOptionIndex = allSetOptions.indexOf(setting);
        if (existingOptionIndex >= 0) {
            allSetOptions.splice(existingOptionIndex, 1);
        }
        let comment;
        if (commented === "always") {
            comment = true;
        }
        else if (commented === "never") {
            comment = false;
        }
        else {
            comment = !(0, ts_js_1.hasProperty)(options, setting);
        }
        const value = options[setting];
        const formattedValue = (0, ts_js_1.hasProperty)(options, setting) && value === undefined ? "null" : formatValueOrArray(setting, (value ?? defaultValue));
        if (comment) {
            result.push(`${tab}${tab}// "${setting}": ${String(formattedValue)},`);
        }
        else {
            result.push(`${tab}${tab}"${setting}": ${String(formattedValue)},`);
        }
    }
    function formatValueOrArray(settingName, value) {
        const option = exports.optionDeclarations.filter(c => c.name === settingName)[0];
        if (!option)
            ts_js_1.Debug.fail(`No option named ${settingName}?`);
        const map = (option.type instanceof Map) ? option.type : undefined;
        if ((0, ts_js_1.isArray)(value)) {
            // eslint-disable-next-line local/no-in-operator
            const map = ("element" in option && (option.element.type instanceof Map)) ? option.element.type : undefined;
            return `[${String(value.map(v => formatSingleValue(v, map)).join(", "))}]`;
        }
        else {
            return formatSingleValue(value, map);
        }
    }
    function formatSingleValue(value, map) {
        if (map) {
            value = getNameOfCompilerOptionValue(value, map) ?? ts_js_1.Debug.fail(`No matching value of ${value}`);
        }
        return JSON.stringify(value);
    }
    result.push(`${tab}}`);
    result.push(`}`);
    result.push(``);
    return result.join(newLine);
}
/** @internal */
function convertToOptionsWithAbsolutePaths(options, toAbsolutePath) {
    const result = {};
    const optionsNameMap = getOptionsNameMap().optionsNameMap;
    for (const name in options) {
        if ((0, ts_js_1.hasProperty)(options, name)) {
            result[name] = convertToOptionValueWithAbsolutePaths(optionsNameMap.get(name.toLowerCase()), options[name], toAbsolutePath);
        }
    }
    if (result.configFilePath) {
        result.configFilePath = toAbsolutePath(result.configFilePath);
    }
    return result;
}
function convertToOptionValueWithAbsolutePaths(option, value, toAbsolutePath) {
    if (option && !isNullOrUndefined(value)) {
        if (option.type === "list") {
            const values = value;
            if (option.element.isFilePath && values.length) {
                return values.map(toAbsolutePath);
            }
        }
        else if (option.isFilePath) {
            ts_js_1.Debug.assert(typeof value === "string");
            return toAbsolutePath(value);
        }
        ts_js_1.Debug.assert(option.type !== "listOrElement");
    }
    return value;
}
/**
 * Parse the contents of a config file (tsconfig.json).
 * @param json The contents of the config file to parse
 * @param host Instance of ParseConfigHost used to enumerate files in folder.
 * @param basePath A root directory to resolve relative path entries in the config
 *    file to. e.g. outDir
 */
function parseJsonConfigFileContent(json, host, basePath, existingOptions, configFileName, resolutionStack, extraFileExtensions, extendedConfigCache, existingWatchOptions) {
    return parseJsonConfigFileContentWorker(json, /*sourceFile*/ undefined, host, basePath, existingOptions, existingWatchOptions, configFileName, resolutionStack, extraFileExtensions, extendedConfigCache);
}
/**
 * Parse the contents of a config file (tsconfig.json).
 * @param jsonNode The contents of the config file to parse
 * @param host Instance of ParseConfigHost used to enumerate files in folder.
 * @param basePath A root directory to resolve relative path entries in the config
 *    file to. e.g. outDir
 */
function parseJsonSourceFileConfigFileContent(sourceFile, host, basePath, existingOptions, configFileName, resolutionStack, extraFileExtensions, extendedConfigCache, existingWatchOptions) {
    ts_js_1.tracing?.push("parse" /* tracing.Phase.Parse */, "parseJsonSourceFileConfigFileContent", { path: sourceFile.fileName });
    const result = parseJsonConfigFileContentWorker(/*json*/ undefined, sourceFile, host, basePath, existingOptions, existingWatchOptions, configFileName, resolutionStack, extraFileExtensions, extendedConfigCache);
    ts_js_1.tracing?.pop();
    return result;
}
/** @internal */
function setConfigFileInOptions(options, configFile) {
    if (configFile) {
        Object.defineProperty(options, "configFile", { enumerable: false, writable: false, value: configFile });
    }
}
function isNullOrUndefined(x) {
    return x === undefined || x === null; // eslint-disable-line no-restricted-syntax
}
function directoryOfCombinedPath(fileName, basePath) {
    // Use the `getNormalizedAbsolutePath` function to avoid canonicalizing the path, as it must remain noncanonical
    // until consistent casing errors are reported
    return (0, ts_js_1.getDirectoryPath)((0, ts_js_1.getNormalizedAbsolutePath)(fileName, basePath));
}
const defaultIncludeSpec = "**/*";
/**
 * Parse the contents of a config file from json or json source file (tsconfig.json).
 * @param json The contents of the config file to parse
 * @param sourceFile sourceFile corresponding to the Json
 * @param host Instance of ParseConfigHost used to enumerate files in folder.
 * @param basePath A root directory to resolve relative path entries in the config
 *    file to. e.g. outDir
 * @param resolutionStack Only present for backwards-compatibility. Should be empty.
 */
function parseJsonConfigFileContentWorker(json, sourceFile, host, basePath, existingOptions = {}, existingWatchOptions, configFileName, resolutionStack = [], extraFileExtensions = [], extendedConfigCache) {
    ts_js_1.Debug.assert((json === undefined && sourceFile !== undefined) || (json !== undefined && sourceFile === undefined));
    const errors = [];
    const parsedConfig = parseConfig(json, sourceFile, host, basePath, configFileName, resolutionStack, errors, extendedConfigCache);
    const raw = checkedAdamicJsonObject(parsedConfig.raw);
    const options = handleOptionConfigDirTemplateSubstitution((0, ts_js_1.extend)(existingOptions, parsedConfig.options || {}), configDirTemplateSubstitutionOptions, basePath);
    const watchOptions = handleWatchOptionsConfigDirTemplateSubstitution(existingWatchOptions && parsedConfig.watchOptions ?
        (0, ts_js_1.extend)(existingWatchOptions, parsedConfig.watchOptions) :
        parsedConfig.watchOptions || existingWatchOptions, basePath);
    options.configFilePath = configFileName && (0, ts_js_1.normalizeSlashes)(configFileName);
    const basePathForFileNames = (0, ts_js_1.normalizePath)(configFileName ? directoryOfCombinedPath(configFileName, basePath) : basePath);
    const configFileSpecs = getConfigFileSpecs();
    if (sourceFile)
        sourceFile.configFileSpecs = configFileSpecs;
    setConfigFileInOptions(options, sourceFile);
    return {
        options,
        watchOptions,
        fileNames: getFileNames(basePathForFileNames),
        projectReferences: getProjectReferences(basePathForFileNames),
        typeAcquisition: parsedConfig.typeAcquisition || getDefaultTypeAcquisition(),
        raw,
        errors,
        // Wildcard directories (provided as part of a wildcard path) are stored in a
        // file map that marks whether it was a regular wildcard match (with a `*` or `?` token),
        // or a recursive directory. This information is used by filesystem watchers to monitor for
        // new entries in these paths.
        wildcardDirectories: getWildcardDirectories(configFileSpecs, basePathForFileNames, host.useCaseSensitiveFileNames),
        compileOnSave: !!raw.compileOnSave,
    };
    function getConfigFileSpecs() {
        const referencesOfRaw = getPropFromRaw("references", element => typeof element === "object", "object");
        const filesSpecs = toPropValue(getSpecsFromRaw("files"));
        if (filesSpecs) {
            const hasZeroOrNoReferences = referencesOfRaw === "no-prop" || (0, ts_js_1.isArray)(referencesOfRaw) && referencesOfRaw.length === 0;
            const hasExtends = (0, ts_js_1.hasProperty)(raw, "extends");
            if (filesSpecs.length === 0 && hasZeroOrNoReferences && !hasExtends) {
                if (sourceFile) {
                    const fileName = configFileName || "tsconfig.json";
                    const diagnosticMessage = ts_js_1.Diagnostics.The_files_list_in_config_file_0_is_empty;
                    const nodeValue = (0, ts_js_1.forEachTsConfigPropArray)(sourceFile, "files", property => property.initializer);
                    const error = createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, nodeValue, diagnosticMessage, fileName);
                    errors.push(error);
                }
                else {
                    createCompilerDiagnosticOnlyIfJson(ts_js_1.Diagnostics.The_files_list_in_config_file_0_is_empty, configFileName || "tsconfig.json");
                }
            }
        }
        let includeSpecs = toPropValue(getSpecsFromRaw("include"));
        const excludeOfRaw = getSpecsFromRaw("exclude");
        let isDefaultIncludeSpec = false;
        let excludeSpecs = toPropValue(excludeOfRaw);
        if (excludeOfRaw === "no-prop") {
            const outDir = options.outDir;
            const declarationDir = options.declarationDir;
            if (outDir || declarationDir) {
                excludeSpecs = (0, ts_js_1.filter)([outDir, declarationDir], (d) => !!d);
            }
        }
        if (filesSpecs === undefined && includeSpecs === undefined) {
            includeSpecs = [defaultIncludeSpec];
            isDefaultIncludeSpec = true;
        }
        let validatedIncludeSpecsBeforeSubstitution, validatedExcludeSpecsBeforeSubstitution;
        let validatedIncludeSpecs, validatedExcludeSpecs;
        // The exclude spec list is converted into a regular expression, which allows us to quickly
        // test whether a file or directory should be excluded before recursively traversing the
        // file system.
        if (includeSpecs) {
            validatedIncludeSpecsBeforeSubstitution = validateSpecs(includeSpecs, errors, /*disallowTrailingRecursion*/ true, sourceFile, "include");
            validatedIncludeSpecs = getSubstitutedStringArrayWithConfigDirTemplate(validatedIncludeSpecsBeforeSubstitution, basePathForFileNames) || validatedIncludeSpecsBeforeSubstitution;
        }
        if (excludeSpecs) {
            validatedExcludeSpecsBeforeSubstitution = validateSpecs(excludeSpecs, errors, /*disallowTrailingRecursion*/ false, sourceFile, "exclude");
            validatedExcludeSpecs = getSubstitutedStringArrayWithConfigDirTemplate(validatedExcludeSpecsBeforeSubstitution, basePathForFileNames) || validatedExcludeSpecsBeforeSubstitution;
        }
        const validatedFilesSpecBeforeSubstitution = (0, ts_js_1.filter)(filesSpecs, ts_js_1.isString);
        const validatedFilesSpec = getSubstitutedStringArrayWithConfigDirTemplate(validatedFilesSpecBeforeSubstitution, basePathForFileNames) || validatedFilesSpecBeforeSubstitution;
        return {
            filesSpecs,
            includeSpecs,
            excludeSpecs,
            validatedFilesSpec,
            validatedIncludeSpecs,
            validatedExcludeSpecs,
            validatedFilesSpecBeforeSubstitution,
            validatedIncludeSpecsBeforeSubstitution,
            validatedExcludeSpecsBeforeSubstitution,
            isDefaultIncludeSpec,
        };
    }
    function getFileNames(basePath) {
        const fileNames = getFileNamesFromConfigSpecs(configFileSpecs, basePath, options, host, extraFileExtensions);
        if (shouldReportNoInputFiles(fileNames, canJsonReportNoInputFiles(raw), resolutionStack)) {
            errors.push(getErrorForNoInputFiles(configFileSpecs, configFileName));
        }
        return fileNames;
    }
    function getProjectReferences(basePath) {
        let projectReferences;
        const referencesOfRaw = getPropFromRaw("references", element => typeof element === "object", "object");
        if ((0, ts_js_1.isArray)(referencesOfRaw)) {
            for (const ref of referencesOfRaw) {
                if (typeof ref.path !== "string") {
                    createCompilerDiagnosticOnlyIfJson(ts_js_1.Diagnostics.Compiler_option_0_requires_a_value_of_type_1, "reference.path", "string");
                }
                else {
                    (projectReferences || (projectReferences = [])).push({
                        path: (0, ts_js_1.getNormalizedAbsolutePath)(ref.path, basePath),
                        originalPath: ref.path,
                        prepend: ref.prepend,
                        circular: ref.circular,
                    });
                }
            }
        }
        return projectReferences;
    }
    function toPropValue(specResult) {
        return (0, ts_js_1.isArray)(specResult) ? specResult : undefined;
    }
    function getSpecsFromRaw(prop) {
        return getPropFromRaw(prop, ts_js_1.isString, "string");
    }
    function getPropFromRaw(prop, validateElement, elementTypeName) {
        if ((0, ts_js_1.hasProperty)(raw, prop) && !isNullOrUndefined(raw[prop])) {
            if ((0, ts_js_1.isArray)(raw[prop])) {
                const result = raw[prop];
                if (!sourceFile && !(0, ts_js_1.every)(result, validateElement)) {
                    errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Compiler_option_0_requires_a_value_of_type_1, prop, elementTypeName));
                }
                return result;
            }
            else {
                createCompilerDiagnosticOnlyIfJson(ts_js_1.Diagnostics.Compiler_option_0_requires_a_value_of_type_1, prop, "Array");
                return "not-array";
            }
        }
        return "no-prop";
    }
    function createCompilerDiagnosticOnlyIfJson(message, ...args) {
        if (!sourceFile) {
            errors.push((0, ts_js_1.createCompilerDiagnostic)(message, ...args));
        }
    }
}
/** @internal */
function handleWatchOptionsConfigDirTemplateSubstitution(watchOptions, basePath) {
    return handleOptionConfigDirTemplateSubstitution(watchOptions, configDirTemplateSubstitutionWatchOptions, basePath);
}
function handleOptionConfigDirTemplateSubstitution(options, optionDeclarations, basePath) {
    if (!options)
        return options;
    let result;
    for (const option of optionDeclarations) {
        if (options[option.name] !== undefined) {
            const value = options[option.name];
            switch (option.type) {
                case "string":
                    ts_js_1.Debug.assert(option.isFilePath);
                    if (startsWithConfigDirTemplate(value)) {
                        setOptionValue(option, getSubstitutedPathWithConfigDirTemplate(value, basePath));
                    }
                    break;
                case "list":
                    ts_js_1.Debug.assert(option.element.isFilePath);
                    const listResult = getSubstitutedStringArrayWithConfigDirTemplate(value, basePath);
                    if (listResult)
                        setOptionValue(option, listResult);
                    break;
                case "object":
                    ts_js_1.Debug.assert(option.name === "paths");
                    const objectResult = getSubstitutedMapLikeOfStringArrayWithConfigDirTemplate(value, basePath);
                    if (objectResult)
                        setOptionValue(option, objectResult);
                    break;
                default:
                    ts_js_1.Debug.fail("option type not supported");
            }
        }
    }
    return result || options;
    function setOptionValue(option, value) {
        (result ?? (result = (0, ts_js_1.assign)({}, options)))[option.name] = value;
    }
}
const configDirTemplate = `\${configDir}`;
function startsWithConfigDirTemplate(value) {
    return (0, ts_js_1.isString)(value) && (0, ts_js_1.startsWith)(value, configDirTemplate, /*ignoreCase*/ true);
}
function getSubstitutedPathWithConfigDirTemplate(value, basePath) {
    return (0, ts_js_1.getNormalizedAbsolutePath)(value.replace(configDirTemplate, "./"), basePath);
}
function getSubstitutedStringArrayWithConfigDirTemplate(list, basePath) {
    if (!list)
        return list;
    let result;
    list.forEach((element, index) => {
        if (!startsWithConfigDirTemplate(element))
            return;
        (result ?? (result = list.slice()))[index] = getSubstitutedPathWithConfigDirTemplate(element, basePath);
    });
    return result;
}
function getSubstitutedMapLikeOfStringArrayWithConfigDirTemplate(mapLike, basePath) {
    let result;
    const ownKeys = (0, ts_js_1.getOwnKeys)(mapLike);
    ownKeys.forEach(key => {
        if (!(0, ts_js_1.isArray)(mapLike[key]))
            return;
        const subStitution = getSubstitutedStringArrayWithConfigDirTemplate(mapLike[key], basePath);
        if (!subStitution)
            return;
        (result ?? (result = (0, ts_js_1.assign)({}, mapLike)))[key] = subStitution;
    });
    return result;
}
function isErrorNoInputFiles(error) {
    return error.code === ts_js_1.Diagnostics.No_inputs_were_found_in_config_file_0_Specified_include_paths_were_1_and_exclude_paths_were_2.code;
}
function getErrorForNoInputFiles({ includeSpecs, excludeSpecs }, configFileName) {
    return (0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.No_inputs_were_found_in_config_file_0_Specified_include_paths_were_1_and_exclude_paths_were_2, configFileName || "tsconfig.json", JSON.stringify(includeSpecs || []), JSON.stringify(excludeSpecs || []));
}
function shouldReportNoInputFiles(fileNames, canJsonReportNoInutFiles, resolutionStack) {
    return fileNames.length === 0 && canJsonReportNoInutFiles && (!resolutionStack || resolutionStack.length === 0);
}
/** @internal */
function isSolutionConfig(config) {
    return !config.fileNames.length &&
        (0, ts_js_1.hasProperty)(checkedAdamicJsonObject(config.raw), "references");
}
/** @internal */
function canJsonReportNoInputFiles(raw) {
    return !(0, ts_js_1.hasProperty)(raw, "files") && !(0, ts_js_1.hasProperty)(raw, "references");
}
/** @internal */
function updateErrorForNoInputFiles(fileNames, configFileName, configFileSpecs, configParseDiagnostics, canJsonReportNoInutFiles) {
    const existingErrors = configParseDiagnostics.length;
    if (shouldReportNoInputFiles(fileNames, canJsonReportNoInutFiles)) {
        configParseDiagnostics.push(getErrorForNoInputFiles(configFileSpecs, configFileName));
    }
    else {
        (0, ts_js_1.filterMutate)(configParseDiagnostics, error => !isErrorNoInputFiles(error));
    }
    return existingErrors !== configParseDiagnostics.length;
}
function isSuccessfulParsedTsconfig(value) {
    return !!value.options;
}
/**
 * This *just* extracts options/include/exclude/files out of a config file.
 * It does *not* resolve the included files.
 */
function parseConfig(json, sourceFile, host, basePath, configFileName, resolutionStack, errors, extendedConfigCache) {
    basePath = (0, ts_js_1.normalizeSlashes)(basePath);
    const resolvedPath = (0, ts_js_1.getNormalizedAbsolutePath)(configFileName || "", basePath);
    if (resolutionStack.includes(resolvedPath)) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Circularity_detected_while_resolving_configuration_Colon_0, [...resolutionStack, resolvedPath].join(" -> ")));
        return { raw: json || convertToObject(sourceFile, errors) };
    }
    const ownConfig = json ?
        parseOwnConfigOfJson(json, host, basePath, configFileName, errors) :
        parseOwnConfigOfJsonSourceFile(sourceFile, host, basePath, configFileName, errors);
    const ownRaw = checkedAdamicJsonObject(ownConfig.raw);
    if (ownConfig.options?.paths) {
        // If we end up needing to resolve relative paths from 'paths' relative to
        // the config file location, we'll need to know where that config file was.
        // Since 'paths' can be inherited from an extended config in another directory,
        // we wouldn't know which directory to use unless we store it here.
        ownConfig.options.pathsBasePath = basePath;
    }
    if (ownConfig.extendedConfigPath) {
        // copy the resolution stack so it is never reused between branches in potential diamond-problem scenarios.
        resolutionStack = resolutionStack.concat([resolvedPath]);
        const result = { options: {} };
        if ((0, ts_js_1.isString)(ownConfig.extendedConfigPath)) {
            applyExtendedConfig(result, ownConfig.extendedConfigPath);
        }
        else {
            ownConfig.extendedConfigPath.forEach(extendedConfigPath => applyExtendedConfig(result, extendedConfigPath));
        }
        if (result.include)
            ownRaw.include = result.include;
        if (result.exclude)
            ownRaw.exclude = result.exclude;
        if (result.files)
            ownRaw.files = result.files;
        if (ownRaw.compileOnSave === undefined && result.compileOnSave)
            ownRaw.compileOnSave = result.compileOnSave;
        if (sourceFile && result.extendedSourceFiles)
            sourceFile.extendedSourceFiles = (0, ts_js_1.arrayFrom)(result.extendedSourceFiles.keys());
        ownConfig.options = (0, ts_js_1.assign)(result.options, ownConfig.options);
        ownConfig.watchOptions = ownConfig.watchOptions && result.watchOptions ?
            assignWatchOptions(result, ownConfig.watchOptions) :
            ownConfig.watchOptions || result.watchOptions;
    }
    return ownConfig;
    function applyExtendedConfig(result, extendedConfigPath) {
        const extendedConfig = getExtendedConfig(sourceFile, extendedConfigPath, host, resolutionStack, errors, extendedConfigCache, result);
        if (extendedConfig && isSuccessfulParsedTsconfig(extendedConfig)) {
            const extendsRaw = checkedAdamicJsonObject(extendedConfig.raw);
            let relativeDifference;
            const setPropertyInResultIfNotUndefined = (propertyName) => {
                if (ownRaw[propertyName])
                    return; // No need to calculate if already set in own config
                const extendedSpecs = extendsRaw[propertyName];
                if (extendedSpecs) {
                    if (!(0, ts_js_1.isArray)(extendedSpecs) || !extendedSpecs.every(ts_js_1.isString))
                        throw new TypeError("Expected inherited string specs");
                    result[propertyName] = (0, ts_js_1.map)(extendedSpecs, (path) => startsWithConfigDirTemplate(path) || (0, ts_js_1.isRootedDiskPath)(path) ?
                        path :
                        (0, ts_js_1.combinePaths)(relativeDifference || (relativeDifference = (0, ts_js_1.convertToRelativePath)((0, ts_js_1.getDirectoryPath)(extendedConfigPath), basePath, (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames))), path));
                }
            };
            setPropertyInResultIfNotUndefined("include");
            setPropertyInResultIfNotUndefined("exclude");
            setPropertyInResultIfNotUndefined("files");
            if (extendsRaw.compileOnSave !== undefined) {
                result.compileOnSave = extendsRaw.compileOnSave;
            }
            (0, ts_js_1.assign)(result.options, extendedConfig.options);
            result.watchOptions = result.watchOptions && extendedConfig.watchOptions ?
                assignWatchOptions(result, extendedConfig.watchOptions) :
                result.watchOptions || extendedConfig.watchOptions;
            // TODO extend type typeAcquisition
        }
    }
    function assignWatchOptions(result, watchOptions) {
        if (result.watchOptionsCopied)
            return (0, ts_js_1.assign)(result.watchOptions, watchOptions);
        result.watchOptionsCopied = true;
        return (0, ts_js_1.assign)({}, result.watchOptions, watchOptions);
    }
}
function parseOwnConfigOfJson(json, host, basePath, configFileName, errors) {
    if ((0, ts_js_1.hasProperty)(json, "excludes")) {
        errors.push((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Unknown_option_excludes_Did_you_mean_exclude));
    }
    const options = convertCompilerOptionsFromJsonWorker(json.compilerOptions, basePath, errors, configFileName);
    const typeAcquisition = convertTypeAcquisitionFromJsonWorker(json.typeAcquisition, basePath, errors, configFileName);
    const watchOptions = convertWatchOptionsFromJsonWorker(json.watchOptions, basePath, errors);
    json.compileOnSave = convertCompileOnSaveOptionFromJson(json, basePath, errors);
    const extendedConfigPath = json.extends || json.extends === "" ?
        getExtendsConfigPathOrArray(json.extends, host, basePath, configFileName, errors) :
        undefined;
    return { raw: json, options, watchOptions, typeAcquisition, extendedConfigPath };
}
function getExtendsConfigPathOrArray(value, host, basePath, configFileName, errors, propertyAssignment, valueExpression, sourceFile) {
    let extendedConfigPath;
    const newBase = configFileName ? directoryOfCombinedPath(configFileName, basePath) : basePath;
    if ((0, ts_js_1.isString)(value)) {
        extendedConfigPath = getExtendsConfigPath(value, host, newBase, errors, valueExpression, sourceFile);
    }
    else if ((0, ts_js_1.isArray)(value)) {
        extendedConfigPath = [];
        for (let index = 0; index < value.length; index++) {
            const fileName = value[index];
            if ((0, ts_js_1.isString)(fileName)) {
                extendedConfigPath = (0, ts_js_1.append)(extendedConfigPath, getExtendsConfigPath(fileName, host, newBase, errors, valueExpression?.elements[index], sourceFile));
            }
            else {
                convertJsonOption(extendsOptionDeclaration.element, value, basePath, errors, propertyAssignment, valueExpression?.elements[index], sourceFile);
            }
        }
    }
    else {
        convertJsonOption(extendsOptionDeclaration, value, basePath, errors, propertyAssignment, valueExpression, sourceFile);
    }
    return extendedConfigPath;
}
function parseOwnConfigOfJsonSourceFile(sourceFile, host, basePath, configFileName, errors) {
    const options = getDefaultCompilerOptions(configFileName);
    let typeAcquisition;
    let watchOptions;
    let extendedConfigPath;
    let rootCompilerOptions;
    const rootOptions = getTsconfigRootOptionsMap();
    const json = convertConfigFileToObject(sourceFile, errors, { rootOptions, onPropertySet });
    if (!typeAcquisition) {
        typeAcquisition = getDefaultTypeAcquisition(configFileName);
    }
    if (rootCompilerOptions && json && json.compilerOptions === undefined) {
        errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, rootCompilerOptions[0], ts_js_1.Diagnostics._0_should_be_set_inside_the_compilerOptions_object_of_the_config_json_file, (0, ts_js_1.getTextOfPropertyName)(rootCompilerOptions[0])));
    }
    return { raw: json, options, watchOptions, typeAcquisition, extendedConfigPath };
    function onPropertySet(keyText, value, propertyAssignment, parentOption, option) {
        // Ensure value is verified except for extends which is handled in its own way for error reporting
        if (option && option !== extendsOptionDeclaration)
            value = convertJsonOption(option, value, basePath, errors, propertyAssignment, propertyAssignment.initializer, sourceFile);
        if (parentOption?.name) {
            if (option) {
                let currentOption;
                if (parentOption === compilerOptionsDeclaration)
                    currentOption = options;
                else if (parentOption === watchOptionsDeclaration)
                    currentOption = watchOptions ?? (watchOptions = {});
                else if (parentOption === typeAcquisitionDeclaration)
                    currentOption = typeAcquisition ?? (typeAcquisition = getDefaultTypeAcquisition(configFileName));
                else
                    ts_js_1.Debug.fail("Unknown option");
                currentOption[option.name] = value;
            }
            else if (keyText && parentOption?.extraKeyDiagnostics) {
                if (parentOption.elementOptions) {
                    errors.push(createUnknownOptionError(keyText, parentOption.extraKeyDiagnostics, 
                    /*unknownOptionErrorText*/ undefined, propertyAssignment.name, sourceFile));
                }
                else {
                    errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, propertyAssignment.name, parentOption.extraKeyDiagnostics.unknownOptionDiagnostic, keyText));
                }
            }
        }
        else if (parentOption === rootOptions) {
            if (option === extendsOptionDeclaration) {
                extendedConfigPath = getExtendsConfigPathOrArray(value, host, basePath, configFileName, errors, propertyAssignment, propertyAssignment.initializer, sourceFile);
            }
            else if (!option) {
                if (keyText === "excludes") {
                    errors.push((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, propertyAssignment.name, ts_js_1.Diagnostics.Unknown_option_excludes_Did_you_mean_exclude));
                }
                if ((0, ts_js_1.find)(commandOptionsWithoutBuild, opt => opt.name === keyText)) {
                    rootCompilerOptions = (0, ts_js_1.append)(rootCompilerOptions, propertyAssignment.name);
                }
            }
        }
    }
}
function getExtendsConfigPath(extendedConfig, host, basePath, errors, valueExpression, sourceFile) {
    extendedConfig = (0, ts_js_1.normalizeSlashes)(extendedConfig);
    if ((0, ts_js_1.isRootedDiskPath)(extendedConfig) || (0, ts_js_1.startsWith)(extendedConfig, "./") || (0, ts_js_1.startsWith)(extendedConfig, "../")) {
        let extendedConfigPath = (0, ts_js_1.getNormalizedAbsolutePath)(extendedConfig, basePath);
        if (!host.fileExists(extendedConfigPath) && !(0, ts_js_1.endsWith)(extendedConfigPath, ".json" /* Extension.Json */)) {
            extendedConfigPath = `${extendedConfigPath}.json`;
            if (!host.fileExists(extendedConfigPath)) {
                errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, ts_js_1.Diagnostics.File_0_not_found, extendedConfig));
                return undefined;
            }
        }
        return extendedConfigPath;
    }
    // If the path isn't a rooted or relative path, resolve like a module
    const resolved = (0, ts_js_1.nodeNextJsonConfigResolver)(extendedConfig, (0, ts_js_1.combinePaths)(basePath, "tsconfig.json"), host);
    if (resolved.resolvedModule) {
        return resolved.resolvedModule.resolvedFileName;
    }
    if (extendedConfig === "") {
        errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, ts_js_1.Diagnostics.Compiler_option_0_cannot_be_given_an_empty_string, "extends"));
    }
    else {
        errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, ts_js_1.Diagnostics.File_0_not_found, extendedConfig));
    }
    return undefined;
}
function getExtendedConfig(sourceFile, extendedConfigPath, host, resolutionStack, errors, extendedConfigCache, result) {
    const path = host.useCaseSensitiveFileNames ? extendedConfigPath : (0, ts_js_1.toFileNameLowerCase)(extendedConfigPath);
    let value;
    let extendedResult;
    let extendedConfig;
    if (extendedConfigCache && (value = extendedConfigCache.get(path))) {
        ({ extendedResult, extendedConfig } = value);
    }
    else {
        extendedResult = readJsonConfigFile(extendedConfigPath, path => host.readFile(path));
        if (!extendedResult.parseDiagnostics.length) {
            extendedConfig = parseConfig(/*json*/ undefined, extendedResult, host, (0, ts_js_1.getDirectoryPath)(extendedConfigPath), (0, ts_js_1.getBaseFileName)(extendedConfigPath), resolutionStack, errors, extendedConfigCache);
        }
        if (extendedConfigCache) {
            extendedConfigCache.set(path, { extendedResult, extendedConfig });
        }
    }
    if (sourceFile) {
        (result.extendedSourceFiles ?? (result.extendedSourceFiles = new Set())).add(extendedResult.fileName);
        if (extendedResult.extendedSourceFiles) {
            for (const extenedSourceFile of extendedResult.extendedSourceFiles) {
                result.extendedSourceFiles.add(extenedSourceFile);
            }
        }
    }
    if (extendedResult.parseDiagnostics.length) {
        errors.push(...extendedResult.parseDiagnostics);
        return undefined;
    }
    return extendedConfig;
}
function convertCompileOnSaveOptionFromJson(jsonOption, basePath, errors) {
    if (!(0, ts_js_1.hasProperty)(jsonOption, compileOnSaveCommandLineOption.name)) {
        return false;
    }
    const result = convertJsonOption(compileOnSaveCommandLineOption, jsonOption.compileOnSave, basePath, errors);
    return typeof result === "boolean" && result;
}
function convertCompilerOptionsFromJson(jsonOptions, basePath, configFileName) {
    const errors = [];
    const options = convertCompilerOptionsFromJsonWorker(jsonOptions, basePath, errors, configFileName);
    return { options, errors };
}
function convertTypeAcquisitionFromJson(jsonOptions, basePath, configFileName) {
    const errors = [];
    const options = convertTypeAcquisitionFromJsonWorker(jsonOptions, basePath, errors, configFileName);
    return { options, errors };
}
function getDefaultCompilerOptions(configFileName) {
    const options = configFileName && (0, ts_js_1.getBaseFileName)(configFileName) === "jsconfig.json"
        ? { allowJs: true, maxNodeModuleJsDepth: 2, allowSyntheticDefaultImports: true, skipLibCheck: true, noEmit: true }
        : {};
    return options;
}
function convertCompilerOptionsFromJsonWorker(jsonOptions, basePath, errors, configFileName) {
    const options = getDefaultCompilerOptions(configFileName);
    convertOptionsFromJson(getCommandLineCompilerOptionsMap(), jsonOptions, basePath, options, exports.compilerOptionsDidYouMeanDiagnostics, errors);
    if (configFileName) {
        options.configFilePath = (0, ts_js_1.normalizeSlashes)(configFileName);
    }
    return options;
}
function getDefaultTypeAcquisition(configFileName) {
    return { enable: !!configFileName && (0, ts_js_1.getBaseFileName)(configFileName) === "jsconfig.json", include: [], exclude: [] };
}
function convertTypeAcquisitionFromJsonWorker(jsonOptions, basePath, errors, configFileName) {
    const options = getDefaultTypeAcquisition(configFileName);
    convertOptionsFromJson(getCommandLineTypeAcquisitionMap(), jsonOptions, basePath, options, typeAcquisitionDidYouMeanDiagnostics, errors);
    return options;
}
function convertWatchOptionsFromJsonWorker(jsonOptions, basePath, errors) {
    return convertOptionsFromJson(getCommandLineWatchOptionsMap(), jsonOptions, basePath, /*defaultOptions*/ undefined, watchOptionsDidYouMeanDiagnostics, errors);
}
function convertOptionsFromJson(optionsNameMap, jsonOptions, basePath, defaultOptions, diagnostics, errors) {
    if (!jsonOptions) {
        return;
    }
    for (const id in jsonOptions) {
        const opt = optionsNameMap.get(id);
        if (opt) {
            (defaultOptions || (defaultOptions = {}))[opt.name] = convertJsonOption(opt, jsonOptions[id], basePath, errors);
        }
        else {
            errors.push(createUnknownOptionError(id, diagnostics));
        }
    }
    return defaultOptions;
}
function createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, node, message, ...args) {
    return sourceFile && node ?
        (0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, node, message, ...args) :
        (0, ts_js_1.createCompilerDiagnostic)(message, ...args);
}
/** @internal */
function convertJsonOption(opt, value, basePath, errors, propertyAssignment, valueExpression, sourceFile) {
    if (opt.isCommandLineOnly) {
        errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, propertyAssignment?.name, ts_js_1.Diagnostics.Option_0_can_only_be_specified_on_command_line, opt.name));
        return undefined;
    }
    if (isCompilerOptionsValue(opt, value)) {
        const optType = opt.type;
        if ((optType === "list") && (0, ts_js_1.isArray)(value)) {
            return convertJsonOptionOfListType(opt, value, basePath, errors, propertyAssignment, valueExpression, sourceFile);
        }
        else if (optType === "listOrElement") {
            return (0, ts_js_1.isArray)(value) ?
                convertJsonOptionOfListType(opt, value, basePath, errors, propertyAssignment, valueExpression, sourceFile) :
                convertJsonOption(opt.element, value, basePath, errors, propertyAssignment, valueExpression, sourceFile);
        }
        else if (!(0, ts_js_1.isString)(opt.type)) {
            return typeof value === "string" ? convertJsonOptionOfCustomType(opt, value, errors, valueExpression, sourceFile) : undefined;
        }
        const validatedValue = validateJsonOptionValue(opt, value, errors, valueExpression, sourceFile);
        return isNullOrUndefined(validatedValue) ? validatedValue : normalizeNonListOptionValue(opt, basePath, validatedValue);
    }
    else {
        errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, ts_js_1.Diagnostics.Compiler_option_0_requires_a_value_of_type_1, opt.name, getCompilerOptionValueTypeString(opt)));
    }
}
function normalizeNonListOptionValue(option, basePath, value) {
    if (option.isFilePath) {
        value = (0, ts_js_1.normalizeSlashes)(value);
        value = !startsWithConfigDirTemplate(value) ? (0, ts_js_1.getNormalizedAbsolutePath)(value, basePath) : value;
        if (value === "") {
            value = ".";
        }
    }
    return value;
}
function validateJsonOptionValue(opt, value, errors, valueExpression, sourceFile) {
    if (isNullOrUndefined(value))
        return undefined;
    const d = opt.extraValidation?.(value);
    if (!d)
        return value;
    errors.push(createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, ...d));
    return undefined;
}
function convertJsonOptionOfCustomType(opt, value, errors, valueExpression, sourceFile) {
    if (isNullOrUndefined(value))
        return undefined;
    const key = value.toLowerCase();
    const val = opt.type.get(key);
    if (val !== undefined) {
        return validateJsonOptionValue(opt, val, errors, valueExpression, sourceFile);
    }
    else {
        errors.push(createDiagnosticForInvalidCustomType(opt, (message, ...args) => createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(sourceFile, valueExpression, message, ...args)));
    }
}
function convertJsonOptionOfListType(option, values, basePath, errors, propertyAssignment, valueExpression, sourceFile) {
    return (0, ts_js_1.filter)((0, ts_js_1.map)(values, (v, index) => convertJsonOption(option.element, v, basePath, errors, propertyAssignment, valueExpression?.elements[index], sourceFile)), v => option.listPreserveFalsyValues ? true : !!v);
}
/**
 * Tests for a path that ends in a recursive directory wildcard.
 * Matches **, \**, **\, and \**\, but not a**b.
 *
 * NOTE: used \ in place of / above to avoid issues with multiline comments.
 *
 * Breakdown:
 *  (^|\/)      # matches either the beginning of the string or a directory separator.
 *  \*\*        # matches the recursive directory wildcard "**".
 *  \/?$        # matches an optional trailing directory separator at the end of the string.
 */
const invalidTrailingRecursionPattern = /(?:^|\/)\*\*\/?$/;
/**
 * Matches the portion of a wildcard path that does not contain wildcards.
 * Matches \a of \a\*, or \a\b\c of \a\b\c\?\d.
 *
 * NOTE: used \ in place of / above to avoid issues with multiline comments.
 *
 * Breakdown:
 *  ^                   # matches the beginning of the string
 *  [^*?]*              # matches any number of non-wildcard characters
 *  (?=\/[^/]*[*?])     # lookahead that matches a directory separator followed by
 *                      # a path component that contains at least one wildcard character (* or ?).
 */
const wildcardDirectoryPattern = /^[^*?]*(?=\/[^/]*[*?])/;
/**
 * Gets the file names from the provided config file specs that contain, files, include, exclude and
 * other properties needed to resolve the file names
 * @param configFileSpecs The config file specs extracted with file names to include, wildcards to include/exclude and other details
 * @param basePath The base path for any relative file specifications.
 * @param options Compiler options.
 * @param host The host used to resolve files and directories.
 * @param extraFileExtensions optionaly file extra file extension information from host
 *
 * @internal
 */
function getFileNamesFromConfigSpecs(configFileSpecs, basePath, options, host, extraFileExtensions = ts_js_1.emptyArray) {
    basePath = (0, ts_js_1.normalizePath)(basePath);
    const keyMapper = (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames);
    // Literal file names (provided via the "files" array in tsconfig.json) are stored in a
    // file map with a possibly case insensitive key. We use this map later when when including
    // wildcard paths.
    const literalFileMap = new Map();
    // Wildcard paths (provided via the "includes" array in tsconfig.json) are stored in a
    // file map with a possibly case insensitive key. We use this map to store paths matched
    // via wildcard, and to handle extension priority.
    const wildcardFileMap = new Map();
    // Wildcard paths of json files (provided via the "includes" array in tsconfig.json) are stored in a
    // file map with a possibly case insensitive key. We use this map to store paths matched
    // via wildcard of *.json kind
    const wildCardJsonFileMap = new Map();
    const { validatedFilesSpec, validatedIncludeSpecs, validatedExcludeSpecs } = configFileSpecs;
    // Rather than re-query this for each file and filespec, we query the supported extensions
    // once and store it on the expansion context.
    const supportedExtensions = (0, ts_js_1.getSupportedExtensions)(options, extraFileExtensions);
    const supportedExtensionsWithJsonIfResolveJsonModule = (0, ts_js_1.getSupportedExtensionsWithJsonIfResolveJsonModule)(options, supportedExtensions);
    // Literal files are always included verbatim. An "include" or "exclude" specification cannot
    // remove a literal file.
    if (validatedFilesSpec) {
        for (const fileName of validatedFilesSpec) {
            const file = (0, ts_js_1.getNormalizedAbsolutePath)(fileName, basePath);
            literalFileMap.set(keyMapper(file), file);
        }
    }
    let jsonOnlyIncludeRegexes;
    if (validatedIncludeSpecs && validatedIncludeSpecs.length > 0) {
        for (const file of host.readDirectory(basePath, (0, ts_js_1.flatten)(supportedExtensionsWithJsonIfResolveJsonModule), validatedExcludeSpecs, validatedIncludeSpecs, /*depth*/ undefined)) {
            if ((0, ts_js_1.fileExtensionIs)(file, ".json" /* Extension.Json */)) {
                // Valid only if *.json specified
                if (!jsonOnlyIncludeRegexes) {
                    const includes = validatedIncludeSpecs.filter(s => (0, ts_js_1.endsWith)(s, ".json" /* Extension.Json */));
                    const includeFilePatterns = (0, ts_js_1.map)((0, ts_js_1.getRegularExpressionsForWildcards)(includes, basePath, "files"), pattern => `^${pattern}$`);
                    jsonOnlyIncludeRegexes = includeFilePatterns ? includeFilePatterns.map(pattern => (0, ts_js_1.getRegexFromPattern)(pattern, host.useCaseSensitiveFileNames)) : ts_js_1.emptyArray;
                }
                const includeIndex = (0, ts_js_1.findIndex)(jsonOnlyIncludeRegexes, re => re.test(file));
                if (includeIndex !== -1) {
                    const key = keyMapper(file);
                    if (!literalFileMap.has(key) && !wildCardJsonFileMap.has(key)) {
                        wildCardJsonFileMap.set(key, file);
                    }
                }
                continue;
            }
            // If we have already included a literal or wildcard path with a
            // higher priority extension, we should skip this file.
            //
            // This handles cases where we may encounter both <file>.ts and
            // <file>.d.ts (or <file>.js if "allowJs" is enabled) in the same
            // directory when they are compilation outputs.
            if (hasFileWithHigherPriorityExtension(file, literalFileMap, wildcardFileMap, supportedExtensions, keyMapper)) {
                continue;
            }
            // We may have included a wildcard path with a lower priority
            // extension due to the user-defined order of entries in the
            // "include" array. If there is a lower priority extension in the
            // same directory, we should remove it.
            removeWildcardFilesWithLowerPriorityExtension(file, wildcardFileMap, supportedExtensions, keyMapper);
            const key = keyMapper(file);
            if (!literalFileMap.has(key) && !wildcardFileMap.has(key)) {
                wildcardFileMap.set(key, file);
            }
        }
    }
    const literalFiles = (0, ts_js_1.arrayFrom)(literalFileMap.values());
    const wildcardFiles = (0, ts_js_1.arrayFrom)(wildcardFileMap.values());
    return literalFiles.concat(wildcardFiles, (0, ts_js_1.arrayFrom)(wildCardJsonFileMap.values()));
}
/** @internal */
function isExcludedFile(pathToCheck, spec, basePath, useCaseSensitiveFileNames, currentDirectory) {
    const { validatedFilesSpec, validatedIncludeSpecs, validatedExcludeSpecs } = spec;
    if (!(0, ts_js_1.length)(validatedIncludeSpecs) || !(0, ts_js_1.length)(validatedExcludeSpecs))
        return false;
    basePath = (0, ts_js_1.normalizePath)(basePath);
    const keyMapper = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    if (validatedFilesSpec) {
        for (const fileName of validatedFilesSpec) {
            if (keyMapper((0, ts_js_1.getNormalizedAbsolutePath)(fileName, basePath)) === pathToCheck)
                return false;
        }
    }
    return matchesExcludeWorker(pathToCheck, validatedExcludeSpecs, useCaseSensitiveFileNames, currentDirectory, basePath);
}
function invalidDotDotAfterRecursiveWildcard(s) {
    // We used to use the regex /(^|\/)\*\*\/(.*\/)?\.\.($|\/)/ to check for this case, but
    // in v8, that has polynomial performance because the recursive wildcard match - **/ -
    // can be matched in many arbitrary positions when multiple are present, resulting
    // in bad backtracking (and we don't care which is matched - just that some /.. segment
    // comes after some **/ segment).
    const wildcardIndex = (0, ts_js_1.startsWith)(s, "**/") ? 0 : s.indexOf("/**/");
    if (wildcardIndex === -1) {
        return false;
    }
    const lastDotIndex = (0, ts_js_1.endsWith)(s, "/..") ? s.length : s.lastIndexOf("/../");
    return lastDotIndex > wildcardIndex;
}
/** @internal */
function matchesExclude(pathToCheck, excludeSpecs, useCaseSensitiveFileNames, currentDirectory) {
    return matchesExcludeWorker(pathToCheck, (0, ts_js_1.filter)(excludeSpecs, spec => !invalidDotDotAfterRecursiveWildcard(spec)), useCaseSensitiveFileNames, currentDirectory);
}
/** @internal */
function matchesExcludeWorker(pathToCheck, excludeSpecs, useCaseSensitiveFileNames, currentDirectory, basePath) {
    const excludePattern = (0, ts_js_1.getRegularExpressionForWildcard)(excludeSpecs, (0, ts_js_1.combinePaths)((0, ts_js_1.normalizePath)(currentDirectory), basePath), "exclude");
    const excludeRegex = excludePattern && (0, ts_js_1.getRegexFromPattern)(excludePattern, useCaseSensitiveFileNames);
    if (!excludeRegex)
        return false;
    if (excludeRegex.test(pathToCheck))
        return true;
    return !(0, ts_js_1.hasExtension)(pathToCheck) && excludeRegex.test((0, ts_js_1.ensureTrailingDirectorySeparator)(pathToCheck));
}
function validateSpecs(specs, errors, disallowTrailingRecursion, jsonSourceFile, specKey) {
    return specs.filter(spec => {
        if (!(0, ts_js_1.isString)(spec))
            return false;
        const diag = specToDiagnostic(spec, disallowTrailingRecursion);
        if (diag !== undefined) {
            errors.push(createDiagnostic(...diag));
        }
        return diag === undefined;
    });
    function createDiagnostic(message, spec) {
        const element = (0, ts_js_1.getTsConfigPropArrayElementValue)(jsonSourceFile, specKey, spec);
        return createDiagnosticForNodeInSourceFileOrCompilerDiagnostic(jsonSourceFile, element, message, spec);
    }
}
function specToDiagnostic(spec, disallowTrailingRecursion) {
    ts_js_1.Debug.assert(typeof spec === "string");
    if (disallowTrailingRecursion && invalidTrailingRecursionPattern.test(spec)) {
        return [ts_js_1.Diagnostics.File_specification_cannot_end_in_a_recursive_directory_wildcard_Asterisk_Asterisk_Colon_0, spec];
    }
    else if (invalidDotDotAfterRecursiveWildcard(spec)) {
        return [ts_js_1.Diagnostics.File_specification_cannot_contain_a_parent_directory_that_appears_after_a_recursive_directory_wildcard_Asterisk_Asterisk_Colon_0, spec];
    }
}
/**
 * Gets directories in a set of include patterns that should be watched for changes.
 */
function getWildcardDirectories({ validatedIncludeSpecs: include, validatedExcludeSpecs: exclude }, basePath, useCaseSensitiveFileNames) {
    // We watch a directory recursively if it contains a wildcard anywhere in a directory segment
    // of the pattern:
    //
    //  /a/b/**/d   - Watch /a/b recursively to catch changes to any d in any subfolder recursively
    //  /a/b/*/d    - Watch /a/b recursively to catch any d in any immediate subfolder, even if a new subfolder is added
    //  /a/b        - Watch /a/b recursively to catch changes to anything in any recursive subfoler
    //
    // We watch a directory without recursion if it contains a wildcard in the file segment of
    // the pattern:
    //
    //  /a/b/*      - Watch /a/b directly to catch any new file
    //  /a/b/a?z    - Watch /a/b directly to catch any new file matching a?z
    const rawExcludeRegex = (0, ts_js_1.getRegularExpressionForWildcard)(exclude, basePath, "exclude");
    const excludeRegex = rawExcludeRegex && new RegExp(rawExcludeRegex, useCaseSensitiveFileNames ? "" : "i");
    const wildcardDirectories = {};
    const wildCardKeyToPath = new Map();
    if (include !== undefined) {
        const recursiveKeys = [];
        for (const file of include) {
            const spec = (0, ts_js_1.normalizePath)((0, ts_js_1.combinePaths)(basePath, file));
            if (excludeRegex && excludeRegex.test(spec)) {
                continue;
            }
            const match = getWildcardDirectoryFromSpec(spec, useCaseSensitiveFileNames);
            if (match) {
                const { key, path, flags } = match;
                const existingPath = wildCardKeyToPath.get(key);
                const existingFlags = existingPath !== undefined ? wildcardDirectories[existingPath] : undefined;
                if (existingFlags === undefined || existingFlags < flags) {
                    wildcardDirectories[existingPath !== undefined ? existingPath : path] = flags;
                    if (existingPath === undefined)
                        wildCardKeyToPath.set(key, path);
                    if (flags === 1 /* WatchDirectoryFlags.Recursive */) {
                        recursiveKeys.push(key);
                    }
                }
            }
        }
        // Remove any subpaths under an existing recursively watched directory.
        for (const path in wildcardDirectories) {
            if ((0, ts_js_1.hasProperty)(wildcardDirectories, path)) {
                for (const recursiveKey of recursiveKeys) {
                    const key = toCanonicalKey(path, useCaseSensitiveFileNames);
                    if (key !== recursiveKey && (0, ts_js_1.containsPath)(recursiveKey, key, basePath, !useCaseSensitiveFileNames)) {
                        delete wildcardDirectories[path];
                    }
                }
            }
        }
    }
    return wildcardDirectories;
}
function toCanonicalKey(path, useCaseSensitiveFileNames) {
    return (useCaseSensitiveFileNames ? path : (0, ts_js_1.toFileNameLowerCase)(path));
}
function getWildcardDirectoryFromSpec(spec, useCaseSensitiveFileNames) {
    const match = wildcardDirectoryPattern.exec(spec);
    if (match) {
        // We check this with a few `indexOf` calls because 3 `indexOf`/`lastIndexOf` calls is
        // less algorithmically complex (roughly O(3n) worst-case) than the regex we used to use,
        // \/[^/]*?[*?][^/]*\/ which was polynominal in v8, since arbitrary sequences of wildcard
        // characters could match any of the central patterns, resulting in bad backtracking.
        const questionWildcardIndex = spec.indexOf("?");
        const starWildcardIndex = spec.indexOf("*");
        const lastDirectorySeperatorIndex = spec.lastIndexOf(ts_js_1.directorySeparator);
        return {
            key: toCanonicalKey(match[0], useCaseSensitiveFileNames),
            path: match[0],
            flags: (questionWildcardIndex !== -1 && questionWildcardIndex < lastDirectorySeperatorIndex)
                || (starWildcardIndex !== -1 && starWildcardIndex < lastDirectorySeperatorIndex)
                ? 1 /* WatchDirectoryFlags.Recursive */ : 0 /* WatchDirectoryFlags.None */,
        };
    }
    if ((0, ts_js_1.isImplicitGlob)(spec.substring(spec.lastIndexOf(ts_js_1.directorySeparator) + 1))) {
        const path = (0, ts_js_1.removeTrailingDirectorySeparator)(spec);
        return {
            key: toCanonicalKey(path, useCaseSensitiveFileNames),
            path,
            flags: 1 /* WatchDirectoryFlags.Recursive */,
        };
    }
    return undefined;
}
/**
 * Determines whether a literal or wildcard file has already been included that has a higher
 * extension priority.
 *
 * @param file The path to the file.
 */
function hasFileWithHigherPriorityExtension(file, literalFiles, wildcardFiles, extensions, keyMapper) {
    const extensionGroup = (0, ts_js_1.forEach)(extensions, group => (0, ts_js_1.fileExtensionIsOneOf)(file, group) ? group : undefined);
    if (!extensionGroup) {
        return false;
    }
    for (const ext of extensionGroup) {
        // d.ts files match with .ts extension and with case sensitive sorting the file order for same files with ts tsx and dts extension is
        // d.ts, .ts, .tsx in that order so we need to handle tsx and dts of same same name case here and in remove files with same extensions
        // So dont match .d.ts files with .ts extension
        if ((0, ts_js_1.fileExtensionIs)(file, ext) && (ext !== ".ts" /* Extension.Ts */ || !(0, ts_js_1.fileExtensionIs)(file, ".d.ts" /* Extension.Dts */))) {
            return false;
        }
        const higherPriorityPath = keyMapper((0, ts_js_1.changeExtension)(file, ext));
        if (literalFiles.has(higherPriorityPath) || wildcardFiles.has(higherPriorityPath)) {
            if (ext === ".d.ts" /* Extension.Dts */ && ((0, ts_js_1.fileExtensionIs)(file, ".js" /* Extension.Js */) || (0, ts_js_1.fileExtensionIs)(file, ".jsx" /* Extension.Jsx */))) {
                // LEGACY BEHAVIOR: An off-by-one bug somewhere in the extension priority system for wildcard module loading allowed declaration
                // files to be loaded alongside their js(x) counterparts. We regard this as generally undesirable, but retain the behavior to
                // prevent breakage.
                continue;
            }
            return true;
        }
    }
    return false;
}
/**
 * Removes files included via wildcard expansion with a lower extension priority that have
 * already been included.
 *
 * @param file The path to the file.
 */
function removeWildcardFilesWithLowerPriorityExtension(file, wildcardFiles, extensions, keyMapper) {
    const extensionGroup = (0, ts_js_1.forEach)(extensions, group => (0, ts_js_1.fileExtensionIsOneOf)(file, group) ? group : undefined);
    if (!extensionGroup) {
        return;
    }
    for (let i = extensionGroup.length - 1; i >= 0; i--) {
        const ext = extensionGroup[i];
        if ((0, ts_js_1.fileExtensionIs)(file, ext)) {
            return;
        }
        const lowerPriorityPath = keyMapper((0, ts_js_1.changeExtension)(file, ext));
        wildcardFiles.delete(lowerPriorityPath);
    }
}
/**
 * Produces a cleaned version of compiler options with personally identifying info (aka, paths) removed.
 * Also converts enum values back to strings.
 *
 * @internal
 */
function convertCompilerOptionsForTelemetry(opts) {
    const out = {};
    for (const key in opts) {
        if ((0, ts_js_1.hasProperty)(opts, key)) {
            const type = getOptionFromName(key);
            if (type !== undefined) { // Ignore unknown options
                out[key] = getOptionValueWithEmptyStrings(opts[key], type);
            }
        }
    }
    return out;
}
function getOptionValueWithEmptyStrings(value, option) {
    if (value === undefined)
        return value;
    switch (option.type) {
        case "object": // "paths". Can't get any useful information from the value since we blank out strings, so just return "".
            return "";
        case "string": // Could be any arbitrary string -- use empty string instead.
            return "";
        case "number": // Allow numbers, but be sure to check it's actually a number.
            return typeof value === "number" ? value : "";
        case "boolean":
            return typeof value === "boolean" ? value : "";
        case "listOrElement":
            if (!(0, ts_js_1.isArray)(value))
                return getOptionValueWithEmptyStrings(value, option.element);
        // fall through to list
        case "list":
            const elementType = option.element;
            return (0, ts_js_1.isArray)(value) ? (0, ts_js_1.mapDefined)(value, v => getOptionValueWithEmptyStrings(v, elementType)) : "";
        default:
            return (0, ts_js_1.forEachEntry)(option.type, (optionEnumValue, optionStringValue) => {
                if (optionEnumValue === value) {
                    return optionStringValue;
                }
            });
    }
}
