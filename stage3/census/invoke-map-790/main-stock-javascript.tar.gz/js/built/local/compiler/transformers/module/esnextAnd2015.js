"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformECMAScriptModule = transformECMAScriptModule;
const ts_js_1 = require("../../_namespaces/ts.js");
/** @internal */
function transformECMAScriptModule(context) {
    const { factory, getEmitHelperFactory: emitHelpers, } = context;
    const host = context.getEmitHost();
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const previousOnEmitNode = context.onEmitNode;
    const previousOnSubstituteNode = context.onSubstituteNode;
    context.onEmitNode = onEmitNode;
    context.onSubstituteNode = onSubstituteNode;
    context.enableEmitNotification(308 /* SyntaxKind.SourceFile */);
    context.enableSubstitution(80 /* SyntaxKind.Identifier */);
    const noSubstitution = new Set();
    let importsAndRequiresToRewriteOrShim;
    let helperNameSubstitutions;
    let currentSourceFile;
    let importRequireStatements;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        if ((0, ts_js_1.isExternalModule)(node) || (0, ts_js_1.getIsolatedModules)(compilerOptions)) {
            currentSourceFile = node;
            importRequireStatements = undefined;
            if (compilerOptions.rewriteRelativeImportExtensions && (currentSourceFile.flags & 4194304 /* NodeFlags.PossiblyContainsDynamicImport */ || (0, ts_js_1.isInJSFile)(node))) {
                (0, ts_js_1.forEachDynamicImportOrRequireCall)(node, /*includeTypeSpaceImports*/ false, /*requireStringLiteralLikeArgument*/ false, node => {
                    if (!(0, ts_js_1.isStringLiteralLike)(node.arguments[0]) || (0, ts_js_1.shouldRewriteModuleSpecifier)(node.arguments[0].text, compilerOptions)) {
                        importsAndRequiresToRewriteOrShim = (0, ts_js_1.append)(importsAndRequiresToRewriteOrShim, node);
                    }
                });
            }
            let result = updateExternalModule(node);
            (0, ts_js_1.addEmitHelpers)(result, context.readEmitHelpers());
            currentSourceFile = undefined;
            if (importRequireStatements) {
                result = factory.updateSourceFile(result, (0, ts_js_1.setTextRange)(factory.createNodeArray((0, ts_js_1.insertStatementsAfterCustomPrologue)(result.statements.slice(), importRequireStatements)), result.statements));
            }
            if (!(0, ts_js_1.isExternalModule)(node) || (0, ts_js_1.getEmitModuleKind)(compilerOptions) === ts_js_1.ModuleKind.Preserve || (0, ts_js_1.some)(result.statements, ts_js_1.isExternalModuleIndicator)) {
                return result;
            }
            return factory.updateSourceFile(result, (0, ts_js_1.setTextRange)(factory.createNodeArray([...result.statements, (0, ts_js_1.createEmptyExports)(factory)]), result.statements));
        }
        return node;
    }
    function updateExternalModule(node) {
        const externalHelpersImportDeclaration = (0, ts_js_1.createExternalHelpersImportDeclarationIfNeeded)(factory, emitHelpers(), node, compilerOptions);
        if (externalHelpersImportDeclaration) {
            const statements = [];
            const statementOffset = factory.copyPrologue(node.statements, statements);
            (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitArray)([externalHelpersImportDeclaration], visitor, ts_js_1.isStatement));
            (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(node.statements, visitor, ts_js_1.isStatement, statementOffset));
            return factory.updateSourceFile(node, (0, ts_js_1.setTextRange)(factory.createNodeArray(statements), node.statements));
        }
        else {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function visitor(node) {
        switch (node.kind) {
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                // Though an error in es2020 modules, in node-flavor es2020 modules, we can helpfully transform this to a synthetic `require` call
                // To give easy access to a synchronous `require` in node-flavor esm. We do the transform even in scenarios where we error, but `import.meta.url`
                // is available, just because the output is reasonable for a node-like runtime.
                return (0, ts_js_1.getEmitModuleKind)(compilerOptions) >= ts_js_1.ModuleKind.Node16 ? visitImportEqualsDeclaration(node) : undefined;
            case 278 /* SyntaxKind.ExportAssignment */:
                return visitExportAssignment(node);
            case 279 /* SyntaxKind.ExportDeclaration */:
                const exportDecl = node;
                return visitExportDeclaration(exportDecl);
            case 273 /* SyntaxKind.ImportDeclaration */:
                return visitImportDeclaration(node);
            case 214 /* SyntaxKind.CallExpression */:
                if (node === importsAndRequiresToRewriteOrShim?.[0]) {
                    return visitImportOrRequireCall(importsAndRequiresToRewriteOrShim.shift());
                }
            // fallthrough
            default:
                if (importsAndRequiresToRewriteOrShim?.length && (0, ts_js_1.rangeContainsRange)(node, importsAndRequiresToRewriteOrShim[0])) {
                    return (0, ts_js_1.visitEachChild)(node, visitor, context);
                }
        }
        return node;
    }
    function visitImportDeclaration(node) {
        if (!compilerOptions.rewriteRelativeImportExtensions) {
            return node;
        }
        const updatedModuleSpecifier = (0, ts_js_1.rewriteModuleSpecifier)(node.moduleSpecifier, compilerOptions);
        if (updatedModuleSpecifier === node.moduleSpecifier) {
            return node;
        }
        return factory.updateImportDeclaration(node, node.modifiers, node.importClause, updatedModuleSpecifier, node.attributes);
    }
    function visitImportOrRequireCall(node) {
        return factory.updateCallExpression(node, node.expression, node.typeArguments, [
            (0, ts_js_1.isStringLiteralLike)(node.arguments[0])
                ? (0, ts_js_1.rewriteModuleSpecifier)(node.arguments[0], compilerOptions)
                : emitHelpers().createRewriteRelativeImportExtensionsHelper(node.arguments[0]),
            ...node.arguments.slice(1),
        ]);
    }
    /**
     * Creates a `require()` call to import an external module.
     *
     * @param importNode The declaration to import.
     */
    function createRequireCall(importNode) {
        const moduleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, importNode, ts_js_1.Debug.checkDefined(currentSourceFile), host, resolver, compilerOptions);
        const args = [];
        if (moduleName) {
            args.push((0, ts_js_1.rewriteModuleSpecifier)(moduleName, compilerOptions));
        }
        if ((0, ts_js_1.getEmitModuleKind)(compilerOptions) === ts_js_1.ModuleKind.Preserve) {
            return factory.createCallExpression(factory.createIdentifier("require"), /*typeArguments*/ undefined, args);
        }
        if (!importRequireStatements) {
            const createRequireName = factory.createUniqueName("_createRequire", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            const importStatement = factory.createImportDeclaration(
            /*modifiers*/ undefined, factory.createImportClause(
            /*phaseModifier*/ undefined, 
            /*name*/ undefined, factory.createNamedImports([
                factory.createImportSpecifier(/*isTypeOnly*/ false, factory.createIdentifier("createRequire"), createRequireName),
            ])), factory.createStringLiteral("module"), 
            /*attributes*/ undefined);
            const requireHelperName = factory.createUniqueName("__require", 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */);
            const requireStatement = factory.createVariableStatement(
            /*modifiers*/ undefined, factory.createVariableDeclarationList([
                factory.createVariableDeclaration(requireHelperName, 
                /*exclamationToken*/ undefined, 
                /*type*/ undefined, factory.createCallExpression(factory.cloneNode(createRequireName), /*typeArguments*/ undefined, [
                    factory.createPropertyAccessExpression(factory.createMetaProperty(102 /* SyntaxKind.ImportKeyword */, factory.createIdentifier("meta")), factory.createIdentifier("url")),
                ])),
            ], 
            /*flags*/ languageVersion >= 2 /* ScriptTarget.ES2015 */ ? 2 /* NodeFlags.Const */ : 0 /* NodeFlags.None */));
            importRequireStatements = [importStatement, requireStatement];
        }
        const name = importRequireStatements[1].declarationList.declarations[0].name;
        ts_js_1.Debug.assertNode(name, ts_js_1.isIdentifier);
        return factory.createCallExpression(factory.cloneNode(name), /*typeArguments*/ undefined, args);
    }
    /**
     * Visits an ImportEqualsDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitImportEqualsDeclaration(node) {
        ts_js_1.Debug.assert((0, ts_js_1.isExternalModuleImportEqualsDeclaration)(node), "import= for internal module references should be handled in an earlier transformer.");
        let statements;
        statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableStatement(
        /*modifiers*/ undefined, factory.createVariableDeclarationList([
            factory.createVariableDeclaration(factory.cloneNode(node.name), 
            /*exclamationToken*/ undefined, 
            /*type*/ undefined, createRequireCall(node)),
        ], 
        /*flags*/ languageVersion >= 2 /* ScriptTarget.ES2015 */ ? 2 /* NodeFlags.Const */ : 0 /* NodeFlags.None */)), node), node));
        statements = appendExportsOfImportEqualsDeclaration(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    function appendExportsOfImportEqualsDeclaration(statements, node) {
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            statements = (0, ts_js_1.append)(statements, factory.createExportDeclaration(
            /*modifiers*/ undefined, node.isTypeOnly, factory.createNamedExports([factory.createExportSpecifier(/*isTypeOnly*/ false, /*propertyName*/ undefined, (0, ts_js_1.idText)(node.name))])));
        }
        return statements;
    }
    function visitExportAssignment(node) {
        if (node.isExportEquals) {
            if ((0, ts_js_1.getEmitModuleKind)(compilerOptions) === ts_js_1.ModuleKind.Preserve) {
                const statement = (0, ts_js_1.setOriginalNode)(factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(factory.createIdentifier("module"), "exports"), node.expression)), node);
                return statement;
            }
            // Elide `export=` as it is not legal with --module ES6
            return undefined;
        }
        return node;
    }
    function visitExportDeclaration(node) {
        const updatedModuleSpecifier = (0, ts_js_1.rewriteModuleSpecifier)(node.moduleSpecifier, compilerOptions);
        if ((compilerOptions.module !== undefined && compilerOptions.module > ts_js_1.ModuleKind.ES2015)
            || !node.exportClause || !(0, ts_js_1.isNamespaceExport)(node.exportClause) || !node.moduleSpecifier) {
            // Either ill-formed or don't need to be tranformed.
            return (!node.moduleSpecifier || updatedModuleSpecifier === node.moduleSpecifier) ? node :
                factory.updateExportDeclaration(node, node.modifiers, node.isTypeOnly, node.exportClause, updatedModuleSpecifier, node.attributes);
        }
        const oldIdentifier = node.exportClause.name;
        const synthName = factory.getGeneratedNameForNode(oldIdentifier);
        const importDecl = factory.createImportDeclaration(
        /*modifiers*/ undefined, factory.createImportClause(
        /*phaseModifier*/ undefined, 
        /*name*/ undefined, factory.createNamespaceImport(synthName)), updatedModuleSpecifier, node.attributes);
        (0, ts_js_1.setOriginalNode)(importDecl, node.exportClause);
        const exportDecl = (0, ts_js_1.isExportNamespaceAsDefaultDeclaration)(node) ? factory.createExportDefault(synthName) : factory.createExportDeclaration(
        /*modifiers*/ undefined, 
        /*isTypeOnly*/ false, factory.createNamedExports([factory.createExportSpecifier(/*isTypeOnly*/ false, synthName, oldIdentifier)]));
        (0, ts_js_1.setOriginalNode)(exportDecl, node);
        return [importDecl, exportDecl];
    }
    //
    // Emit Notification
    //
    /**
     * Hook for node emit.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emit A callback used to emit the node in the printer.
     */
    function onEmitNode(hint, node, emitCallback) {
        if ((0, ts_js_1.isSourceFile)(node)) {
            if (((0, ts_js_1.isExternalModule)(node) || (0, ts_js_1.getIsolatedModules)(compilerOptions)) && compilerOptions.importHelpers) {
                helperNameSubstitutions = new Map();
            }
            currentSourceFile = node;
            previousOnEmitNode(hint, node, emitCallback);
            currentSourceFile = undefined;
            helperNameSubstitutions = undefined;
        }
        else {
            previousOnEmitNode(hint, node, emitCallback);
        }
    }
    //
    // Substitutions
    //
    /**
     * Hooks node substitutions.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (node.id && noSubstitution.has(node.id)) {
            return node;
        }
        if ((0, ts_js_1.isIdentifier)(node) && (0, ts_js_1.getEmitFlags)(node) & 8192 /* EmitFlags.HelperName */) {
            return substituteHelperName(node);
        }
        return node;
    }
    function substituteHelperName(node) {
        const externalHelpersModuleName = currentSourceFile && (0, ts_js_1.getExternalHelpersModuleName)(currentSourceFile);
        if (externalHelpersModuleName) {
            noSubstitution.add((0, ts_js_1.getNodeId)(node));
            return factory.createPropertyAccessExpression(externalHelpersModuleName, node);
        }
        if (helperNameSubstitutions) {
            const name = (0, ts_js_1.idText)(node);
            let substitution = helperNameSubstitutions.get(name);
            if (!substitution) {
                helperNameSubstitutions.set(name, substitution = factory.createUniqueName(name, 16 /* GeneratedIdentifierFlags.Optimistic */ | 32 /* GeneratedIdentifierFlags.FileLevel */));
            }
            return substitution;
        }
        return node;
    }
}
