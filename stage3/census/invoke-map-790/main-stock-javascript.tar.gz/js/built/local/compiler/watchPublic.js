"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readBuilderProgram = readBuilderProgram;
exports.createIncrementalCompilerHost = createIncrementalCompilerHost;
exports.createIncrementalProgram = createIncrementalProgram;
exports.createWatchCompilerHost = createWatchCompilerHost;
exports.createWatchProgram = createWatchProgram;
const ts_js_1 = require("./_namespaces/ts.js");
function readBuilderProgram(compilerOptions, host) {
    const buildInfoPath = (0, ts_js_1.getTsBuildInfoEmitOutputFilePath)(compilerOptions);
    if (!buildInfoPath)
        return undefined;
    let buildInfo;
    if (host.getBuildInfo) {
        // host provides buildinfo, get it from there. This allows host to cache it
        buildInfo = host.getBuildInfo(buildInfoPath, compilerOptions.configFilePath);
    }
    else {
        const content = host.readFile(buildInfoPath);
        if (!content)
            return undefined;
        buildInfo = (0, ts_js_1.getBuildInfo)(buildInfoPath, content);
    }
    if (!buildInfo || buildInfo.version !== ts_js_1.version || !(0, ts_js_1.isIncrementalBuildInfo)(buildInfo))
        return undefined;
    return (0, ts_js_1.createBuilderProgramUsingIncrementalBuildInfo)(buildInfo, buildInfoPath, host);
}
function createIncrementalCompilerHost(options, system = ts_js_1.sys) {
    const host = (0, ts_js_1.createCompilerHostWorker)(options, /*setParentNodes*/ undefined, system);
    host.createHash = system.createHash?.bind(system);
    host.storeSignatureInfo = system.storeSignatureInfo;
    (0, ts_js_1.setGetSourceFileAsHashVersioned)(host);
    (0, ts_js_1.changeCompilerHostLikeToUseCache)(host, fileName => (0, ts_js_1.toPath)(fileName, host.getCurrentDirectory(), host.getCanonicalFileName));
    return host;
}
function createIncrementalProgram({ rootNames, options, configFileParsingDiagnostics, projectReferences, host, createProgram, }) {
    host = host || createIncrementalCompilerHost(options);
    createProgram = createProgram || ts_js_1.createEmitAndSemanticDiagnosticsBuilderProgram;
    const oldProgram = readBuilderProgram(options, host);
    return createProgram(rootNames, options, host, oldProgram, configFileParsingDiagnostics, projectReferences);
}
function createWatchCompilerHost(rootFilesOrConfigFileName, options, system, createProgram, reportDiagnostic, reportWatchStatus, projectReferencesOrWatchOptionsToExtend, watchOptionsOrExtraFileExtensions) {
    if ((0, ts_js_1.isArray)(rootFilesOrConfigFileName)) {
        return (0, ts_js_1.createWatchCompilerHostOfFilesAndCompilerOptions)({
            rootFiles: rootFilesOrConfigFileName,
            options: options,
            watchOptions: watchOptionsOrExtraFileExtensions,
            projectReferences: projectReferencesOrWatchOptionsToExtend,
            system,
            createProgram,
            reportDiagnostic,
            reportWatchStatus,
        });
    }
    else {
        return (0, ts_js_1.createWatchCompilerHostOfConfigFile)({
            configFileName: rootFilesOrConfigFileName,
            optionsToExtend: options,
            watchOptionsToExtend: projectReferencesOrWatchOptionsToExtend,
            extraFileExtensions: watchOptionsOrExtraFileExtensions,
            system,
            createProgram,
            reportDiagnostic,
            reportWatchStatus,
        });
    }
}
function createWatchProgram(host) {
    let builderProgram;
    let updateLevel; // level to indicate if the program needs to be reloaded from config file/just filenames etc
    let missingFilesMap; // Map of file watchers for the missing files
    let watchedWildcardDirectories; // map of watchers for the wild card directories in the config file
    /**
     * undefined - own watches are stale,
     * path - for referenced project which need to be watched
     */
    let staleWatches = new Map([[undefined, undefined]]);
    let timerToUpdateProgram; // timer callback to recompile the program
    let timerToInvalidateFailedLookupResolutions; // timer callback to invalidate resolutions for changes in failed lookup locations
    let parsedConfigs; // Parsed commandline and watching cached for referenced projects
    let sharedExtendedConfigFileWatchers; // Map of file watchers for extended files, shared between different referenced projects
    let extendedConfigCache = host.extendedConfigCache; // Cache for extended config evaluation
    let reportFileChangeDetectedOnCreateProgram = false; // True if synchronizeProgram should report "File change detected..." when a new program is created
    const sourceFilesCache = new Map(); // Cache that stores the source file and version info
    let missingFilePathsRequestedForRelease; // These paths are held temporarily so that we can remove the entry from source file cache if the file is not tracked by missing files
    let hasChangedCompilerOptions = false; // True if the compiler options have changed between compilations
    const useCaseSensitiveFileNames = host.useCaseSensitiveFileNames();
    const currentDirectory = host.getCurrentDirectory();
    const { configFileName, optionsToExtend: optionsToExtendForConfigFile = {}, watchOptionsToExtend, extraFileExtensions, createProgram } = host;
    let { rootFiles: rootFileNames, options: compilerOptions, watchOptions, projectReferences } = host;
    let wildcardDirectories;
    let configFileParsingDiagnostics;
    let canConfigFileJsonReportNoInputFiles = false;
    let hasChangedConfigFileParsingErrors = false;
    const cachedDirectoryStructureHost = configFileName === undefined ? undefined : (0, ts_js_1.createCachedDirectoryStructureHost)(host, currentDirectory, useCaseSensitiveFileNames);
    const directoryStructureHost = cachedDirectoryStructureHost || host;
    const parseConfigFileHost = (0, ts_js_1.parseConfigHostFromCompilerHostLike)(host, directoryStructureHost);
    // From tsc we want to get already parsed result and hence check for rootFileNames
    let newLine = updateNewLine();
    if (configFileName && host.configFileParsingResult) {
        setConfigFileParsingResult(host.configFileParsingResult);
        newLine = updateNewLine();
    }
    reportWatchDiagnostic(ts_js_1.Diagnostics.Starting_compilation_in_watch_mode);
    if (configFileName && !host.configFileParsingResult) {
        newLine = (0, ts_js_1.getNewLineCharacter)(optionsToExtendForConfigFile);
        ts_js_1.Debug.assert(!rootFileNames);
        parseConfigFile();
        newLine = updateNewLine();
    }
    ts_js_1.Debug.assert(compilerOptions);
    ts_js_1.Debug.assert(rootFileNames);
    const { watchFile, watchDirectory, writeLog } = (0, ts_js_1.createWatchFactory)(host, compilerOptions);
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    writeLog(`Current directory: ${currentDirectory} CaseSensitiveFileNames: ${useCaseSensitiveFileNames}`);
    let configFileWatcher;
    if (configFileName) {
        configFileWatcher = watchFile(configFileName, scheduleProgramReload, ts_js_1.PollingInterval.High, watchOptions, ts_js_1.WatchType.ConfigFile);
    }
    const compilerHost = (0, ts_js_1.createCompilerHostFromProgramHost)(host, () => compilerOptions, directoryStructureHost);
    (0, ts_js_1.setGetSourceFileAsHashVersioned)(compilerHost);
    // Members for CompilerHost
    const getNewSourceFile = compilerHost.getSourceFile;
    compilerHost.getSourceFile = (fileName, ...args) => getVersionedSourceFileByPath(fileName, toPath(fileName), ...args);
    compilerHost.getSourceFileByPath = getVersionedSourceFileByPath;
    compilerHost.getNewLine = () => newLine;
    compilerHost.fileExists = fileExists;
    compilerHost.onReleaseOldSourceFile = onReleaseOldSourceFile;
    compilerHost.onReleaseParsedCommandLine = onReleaseParsedCommandLine;
    // Members for ResolutionCacheHost
    compilerHost.toPath = toPath;
    compilerHost.getCompilationSettings = () => compilerOptions;
    compilerHost.useSourceOfProjectReferenceRedirect = host.useSourceOfProjectReferenceRedirect?.bind(host);
    compilerHost.preferNonRecursiveWatch = host.preferNonRecursiveWatch;
    compilerHost.watchDirectoryOfFailedLookupLocation = (dir, cb, flags) => watchDirectory(dir, cb, flags, watchOptions, ts_js_1.WatchType.FailedLookupLocations);
    compilerHost.watchAffectingFileLocation = (file, cb) => watchFile(file, cb, ts_js_1.PollingInterval.High, watchOptions, ts_js_1.WatchType.AffectingFileLocation);
    compilerHost.watchTypeRootsDirectory = (dir, cb, flags) => watchDirectory(dir, cb, flags, watchOptions, ts_js_1.WatchType.TypeRoots);
    compilerHost.getCachedDirectoryStructureHost = () => cachedDirectoryStructureHost;
    compilerHost.scheduleInvalidateResolutionsOfFailedLookupLocations = scheduleInvalidateResolutionsOfFailedLookupLocations;
    compilerHost.onInvalidatedResolution = scheduleProgramUpdate;
    compilerHost.onChangedAutomaticTypeDirectiveNames = scheduleProgramUpdate;
    compilerHost.fileIsOpen = ts_js_1.returnFalse;
    compilerHost.getCurrentProgram = getCurrentProgram;
    compilerHost.writeLog = writeLog;
    compilerHost.getParsedCommandLine = getParsedCommandLine;
    // Cache for the module resolution
    const resolutionCache = (0, ts_js_1.createResolutionCache)(compilerHost, configFileName ?
        (0, ts_js_1.getDirectoryPath)((0, ts_js_1.getNormalizedAbsolutePath)(configFileName, currentDirectory)) :
        currentDirectory, 
    /*logChangesWhenResolvingModule*/ false);
    // Resolve module using host module resolution strategy if provided otherwise use resolution cache to resolve module names
    compilerHost.resolveModuleNameLiterals = host.resolveModuleNameLiterals?.bind(host);
    compilerHost.resolveModuleNames = host.resolveModuleNames?.bind(host);
    if (!compilerHost.resolveModuleNameLiterals && !compilerHost.resolveModuleNames) {
        compilerHost.resolveModuleNameLiterals = resolutionCache.resolveModuleNameLiterals.bind(resolutionCache);
    }
    compilerHost.resolveTypeReferenceDirectiveReferences = host.resolveTypeReferenceDirectiveReferences?.bind(host);
    compilerHost.resolveTypeReferenceDirectives = host.resolveTypeReferenceDirectives?.bind(host);
    if (!compilerHost.resolveTypeReferenceDirectiveReferences && !compilerHost.resolveTypeReferenceDirectives) {
        compilerHost.resolveTypeReferenceDirectiveReferences = resolutionCache.resolveTypeReferenceDirectiveReferences.bind(resolutionCache);
    }
    compilerHost.resolveLibrary = !host.resolveLibrary ?
        resolutionCache.resolveLibrary.bind(resolutionCache) :
        host.resolveLibrary.bind(host);
    compilerHost.getModuleResolutionCache = host.resolveModuleNameLiterals || host.resolveModuleNames ?
        host.getModuleResolutionCache?.bind(host) :
        (() => resolutionCache.getModuleResolutionCache());
    const userProvidedResolution = !!host.resolveModuleNameLiterals || !!host.resolveTypeReferenceDirectiveReferences ||
        !!host.resolveModuleNames || !!host.resolveTypeReferenceDirectives;
    // All resolutions are invalid if user provided resolutions and didnt supply hasInvalidatedResolutions
    const customHasInvalidatedResolutions = userProvidedResolution ?
        host.hasInvalidatedResolutions?.bind(host) || ts_js_1.returnTrue :
        ts_js_1.returnFalse;
    const customHasInvalidLibResolutions = host.resolveLibrary ?
        host.hasInvalidatedLibResolutions?.bind(host) || ts_js_1.returnTrue :
        ts_js_1.returnFalse;
    builderProgram = readBuilderProgram(compilerOptions, compilerHost);
    synchronizeProgram();
    return configFileName ?
        { getCurrentProgram: getCurrentBuilderProgram, getProgram: updateProgram, close, getResolutionCache } :
        { getCurrentProgram: getCurrentBuilderProgram, getProgram: updateProgram, updateRootFileNames, close, getResolutionCache };
    function close() {
        clearInvalidateResolutionsOfFailedLookupLocations();
        resolutionCache.clear();
        (0, ts_js_1.clearMap)(sourceFilesCache, value => {
            if (value && value.fileWatcher) {
                value.fileWatcher.close();
                if (isFilePresenceUnknownOnHost(value))
                    value.fileWatcher = undefined;
            }
        });
        if (configFileWatcher) {
            configFileWatcher.close();
            configFileWatcher = undefined;
        }
        extendedConfigCache?.clear();
        extendedConfigCache = undefined;
        if (sharedExtendedConfigFileWatchers) {
            (0, ts_js_1.clearMap)(sharedExtendedConfigFileWatchers, ts_js_1.closeFileWatcherOf);
            sharedExtendedConfigFileWatchers = undefined;
        }
        if (watchedWildcardDirectories) {
            (0, ts_js_1.clearMap)(watchedWildcardDirectories, ts_js_1.closeFileWatcherOf);
            watchedWildcardDirectories = undefined;
        }
        if (missingFilesMap) {
            (0, ts_js_1.clearMap)(missingFilesMap, ts_js_1.closeFileWatcher);
            missingFilesMap = undefined;
        }
        if (parsedConfigs) {
            (0, ts_js_1.clearMap)(parsedConfigs, config => {
                config.watcher?.close();
                config.watcher = undefined;
                if (config.watchedDirectories)
                    (0, ts_js_1.clearMap)(config.watchedDirectories, ts_js_1.closeFileWatcherOf);
                config.watchedDirectories = undefined;
            });
            parsedConfigs = undefined;
        }
        builderProgram = undefined;
    }
    function getResolutionCache() {
        return resolutionCache;
    }
    function getCurrentBuilderProgram() {
        return builderProgram;
    }
    function getCurrentProgram() {
        return builderProgram && builderProgram.getProgramOrUndefined();
    }
    function synchronizeProgram() {
        writeLog(`Synchronizing program`);
        ts_js_1.Debug.assert(compilerOptions);
        ts_js_1.Debug.assert(rootFileNames);
        clearInvalidateResolutionsOfFailedLookupLocations();
        const program = getCurrentBuilderProgram();
        if (hasChangedCompilerOptions) {
            newLine = updateNewLine();
            if (program && (0, ts_js_1.changesAffectModuleResolution)(program.getCompilerOptions(), compilerOptions)) {
                resolutionCache.onChangesAffectModuleResolution();
            }
        }
        const { hasInvalidatedResolutions, hasInvalidatedLibResolutions } = resolutionCache.createHasInvalidatedResolutions(customHasInvalidatedResolutions, customHasInvalidLibResolutions);
        const { originalReadFile, originalFileExists, originalDirectoryExists, originalCreateDirectory, originalWriteFile, readFileWithCache, } = (0, ts_js_1.changeCompilerHostLikeToUseCache)(compilerHost, toPath);
        if ((0, ts_js_1.isProgramUptoDate)(getCurrentProgram(), rootFileNames, compilerOptions, path => getSourceVersion(path, readFileWithCache), fileName => compilerHost.fileExists(fileName), hasInvalidatedResolutions, hasInvalidatedLibResolutions, hasChangedAutomaticTypeDirectiveNames, getParsedCommandLine, projectReferences)) {
            if (hasChangedConfigFileParsingErrors) {
                if (reportFileChangeDetectedOnCreateProgram) {
                    reportWatchDiagnostic(ts_js_1.Diagnostics.File_change_detected_Starting_incremental_compilation);
                }
                builderProgram = createProgram(/*rootNames*/ undefined, /*options*/ undefined, compilerHost, builderProgram, configFileParsingDiagnostics, projectReferences);
                hasChangedConfigFileParsingErrors = false;
            }
        }
        else {
            if (reportFileChangeDetectedOnCreateProgram) {
                reportWatchDiagnostic(ts_js_1.Diagnostics.File_change_detected_Starting_incremental_compilation);
            }
            createNewProgram(hasInvalidatedResolutions, hasInvalidatedLibResolutions);
        }
        reportFileChangeDetectedOnCreateProgram = false;
        if (host.afterProgramCreate && program !== builderProgram) {
            host.afterProgramCreate(builderProgram);
        }
        compilerHost.readFile = originalReadFile;
        compilerHost.fileExists = originalFileExists;
        compilerHost.directoryExists = originalDirectoryExists;
        compilerHost.createDirectory = originalCreateDirectory;
        compilerHost.writeFile = originalWriteFile;
        staleWatches?.forEach((configFile, configPath) => {
            if (!configPath) {
                // Update the wild card directory watch
                watchConfigFileWildCardDirectories();
                // Update extended config file watch
                if (configFileName)
                    updateExtendedConfigFilesWatches(toPath(configFileName), compilerOptions, watchOptions, ts_js_1.WatchType.ExtendedConfigFile);
            }
            else {
                const config = parsedConfigs?.get(configPath);
                if (config)
                    watchReferencedProject(configFile, configPath, config);
            }
        });
        staleWatches = undefined;
        return builderProgram;
    }
    function createNewProgram(hasInvalidatedResolutions, hasInvalidatedLibResolutions) {
        // Compile the program
        writeLog("CreatingProgramWith::");
        writeLog(`  roots: ${JSON.stringify(rootFileNames)}`);
        writeLog(`  options: ${JSON.stringify(compilerOptions)}`);
        if (projectReferences)
            writeLog(`  projectReferences: ${JSON.stringify(projectReferences)}`);
        const needsUpdateInTypeRootWatch = hasChangedCompilerOptions || !getCurrentProgram();
        hasChangedCompilerOptions = false;
        hasChangedConfigFileParsingErrors = false;
        resolutionCache.startCachingPerDirectoryResolution();
        compilerHost.hasInvalidatedResolutions = hasInvalidatedResolutions;
        compilerHost.hasInvalidatedLibResolutions = hasInvalidatedLibResolutions;
        compilerHost.hasChangedAutomaticTypeDirectiveNames = hasChangedAutomaticTypeDirectiveNames;
        const oldProgram = getCurrentProgram();
        builderProgram = createProgram(rootFileNames, compilerOptions, compilerHost, builderProgram, configFileParsingDiagnostics, projectReferences);
        resolutionCache.finishCachingPerDirectoryResolution(builderProgram.getProgram(), oldProgram);
        // Update watches
        (0, ts_js_1.updateMissingFilePathsWatch)(builderProgram.getProgram(), missingFilesMap || (missingFilesMap = new Map()), watchMissingFilePath);
        if (needsUpdateInTypeRootWatch) {
            resolutionCache.updateTypeRootsWatch();
        }
        if (missingFilePathsRequestedForRelease) {
            // These are the paths that program creater told us as not in use any more but were missing on the disk.
            // We didnt remove the entry for them from sourceFiles cache so that we dont have to do File IO,
            // if there is already watcher for it (for missing files)
            // At this point our watches were updated, hence now we know that these paths are not tracked and need to be removed
            // so that at later time we have correct result of their presence
            for (const missingFilePath of missingFilePathsRequestedForRelease) {
                if (!missingFilesMap.has(missingFilePath)) {
                    sourceFilesCache.delete(missingFilePath);
                }
            }
            missingFilePathsRequestedForRelease = undefined;
        }
    }
    function updateRootFileNames(files) {
        ts_js_1.Debug.assert(!configFileName, "Cannot update root file names with config file watch mode");
        rootFileNames = files;
        scheduleProgramUpdate();
    }
    function updateNewLine() {
        return (0, ts_js_1.getNewLineCharacter)(compilerOptions || optionsToExtendForConfigFile);
    }
    function toPath(fileName) {
        return (0, ts_js_1.toPath)(fileName, currentDirectory, getCanonicalFileName);
    }
    function isFileMissingOnHost(hostSourceFile) {
        return typeof hostSourceFile === "boolean";
    }
    function isFilePresenceUnknownOnHost(hostSourceFile) {
        return typeof hostSourceFile.version === "boolean";
    }
    function fileExists(fileName) {
        const path = toPath(fileName);
        // If file is missing on host from cache, we can definitely say file doesnt exist
        // otherwise we need to ensure from the disk
        if (isFileMissingOnHost(sourceFilesCache.get(path))) {
            return false;
        }
        return directoryStructureHost.fileExists(fileName);
    }
    function getVersionedSourceFileByPath(fileName, path, languageVersionOrOptions, onError, shouldCreateNewSourceFile) {
        const hostSourceFile = sourceFilesCache.get(path);
        // No source file on the host
        if (isFileMissingOnHost(hostSourceFile)) {
            return undefined;
        }
        // Create new source file if requested or the versions dont match
        const impliedNodeFormat = typeof languageVersionOrOptions === "object" ? languageVersionOrOptions.impliedNodeFormat : undefined;
        if (hostSourceFile === undefined || shouldCreateNewSourceFile || isFilePresenceUnknownOnHost(hostSourceFile) || hostSourceFile.sourceFile.impliedNodeFormat !== impliedNodeFormat) {
            const sourceFile = getNewSourceFile(fileName, languageVersionOrOptions, onError);
            if (hostSourceFile) {
                if (sourceFile) {
                    // Set the source file and create file watcher now that file was present on the disk
                    hostSourceFile.sourceFile = sourceFile;
                    hostSourceFile.version = sourceFile.version;
                    if (!hostSourceFile.fileWatcher) {
                        hostSourceFile.fileWatcher = watchFilePath(path, fileName, onSourceFileChange, ts_js_1.PollingInterval.Low, watchOptions, ts_js_1.WatchType.SourceFile);
                    }
                }
                else {
                    // There is no source file on host any more, close the watch, missing file paths will track it
                    if (hostSourceFile.fileWatcher) {
                        hostSourceFile.fileWatcher.close();
                    }
                    sourceFilesCache.set(path, false);
                }
            }
            else {
                if (sourceFile) {
                    const fileWatcher = watchFilePath(path, fileName, onSourceFileChange, ts_js_1.PollingInterval.Low, watchOptions, ts_js_1.WatchType.SourceFile);
                    sourceFilesCache.set(path, { sourceFile, version: sourceFile.version, fileWatcher });
                }
                else {
                    sourceFilesCache.set(path, false);
                }
            }
            return sourceFile;
        }
        return hostSourceFile.sourceFile;
    }
    function nextSourceFileVersion(path) {
        const hostSourceFile = sourceFilesCache.get(path);
        if (hostSourceFile !== undefined) {
            if (isFileMissingOnHost(hostSourceFile)) {
                // The next version, lets set it as presence unknown file
                sourceFilesCache.set(path, { version: false });
            }
            else {
                hostSourceFile.version = false;
            }
        }
    }
    function getSourceVersion(path, readFileWithCache) {
        const hostSourceFile = sourceFilesCache.get(path);
        if (!hostSourceFile)
            return undefined;
        if (hostSourceFile.version)
            return hostSourceFile.version;
        // Read file and get new version
        const text = readFileWithCache(path);
        return text !== undefined ? (0, ts_js_1.getSourceFileVersionAsHashFromText)(compilerHost, text) : undefined;
    }
    function onReleaseOldSourceFile(oldSourceFile, _oldOptions, hasSourceFileByPath) {
        const hostSourceFileInfo = sourceFilesCache.get(oldSourceFile.resolvedPath);
        // If this is the source file thats in the cache and new program doesnt need it,
        // remove the cached entry.
        // Note we arent deleting entry if file became missing in new program or
        // there was version update and new source file was created.
        if (hostSourceFileInfo !== undefined) {
            // record the missing file paths so they can be removed later if watchers arent tracking them
            if (isFileMissingOnHost(hostSourceFileInfo)) {
                (missingFilePathsRequestedForRelease || (missingFilePathsRequestedForRelease = [])).push(oldSourceFile.path);
            }
            else if (hostSourceFileInfo.sourceFile === oldSourceFile) {
                if (hostSourceFileInfo.fileWatcher) {
                    hostSourceFileInfo.fileWatcher.close();
                }
                sourceFilesCache.delete(oldSourceFile.resolvedPath);
                if (!hasSourceFileByPath) {
                    resolutionCache.removeResolutionsOfFile(oldSourceFile.path);
                }
            }
        }
    }
    function reportWatchDiagnostic(message) {
        if (host.onWatchStatusChange) {
            host.onWatchStatusChange((0, ts_js_1.createCompilerDiagnostic)(message), newLine, compilerOptions || optionsToExtendForConfigFile);
        }
    }
    function hasChangedAutomaticTypeDirectiveNames() {
        return resolutionCache.hasChangedAutomaticTypeDirectiveNames();
    }
    function clearInvalidateResolutionsOfFailedLookupLocations() {
        if (!timerToInvalidateFailedLookupResolutions)
            return false;
        host.clearTimeout(timerToInvalidateFailedLookupResolutions);
        timerToInvalidateFailedLookupResolutions = undefined;
        return true;
    }
    function scheduleInvalidateResolutionsOfFailedLookupLocations() {
        if (!host.setTimeout || !host.clearTimeout) {
            return resolutionCache.invalidateResolutionsOfFailedLookupLocations();
        }
        const pending = clearInvalidateResolutionsOfFailedLookupLocations();
        writeLog(`Scheduling invalidateFailedLookup${pending ? ", Cancelled earlier one" : ""}`);
        timerToInvalidateFailedLookupResolutions = (() => {
            const timerHost = host;
            const callback = invalidateResolutionsOfFailedLookup;
            const timeoutDelay = 250;
            const t1 = "timerToInvalidateFailedLookupResolutions";
            return timerHost.setTimeout(() => callback(t1), timeoutDelay, t1);
        })();
    }
    function invalidateResolutionsOfFailedLookup(_timeoutType) {
        timerToInvalidateFailedLookupResolutions = undefined;
        if (resolutionCache.invalidateResolutionsOfFailedLookupLocations()) {
            scheduleProgramUpdate();
        }
    }
    // Upon detecting a file change, wait for 250ms and then perform a recompilation. This gives batch
    // operations (such as saving all modified files in an editor) a chance to complete before we kick
    // off a new compilation.
    function scheduleProgramUpdate() {
        if (!host.setTimeout || !host.clearTimeout) {
            return;
        }
        if (timerToUpdateProgram) {
            host.clearTimeout(timerToUpdateProgram);
        }
        writeLog("Scheduling update");
        timerToUpdateProgram = (() => {
            const timerHost = host;
            const callback = updateProgramWithWatchStatus;
            const timeoutDelay = 250;
            const t1 = "timerToUpdateProgram";
            return timerHost.setTimeout(() => callback(t1), timeoutDelay, t1);
        })();
    }
    function scheduleProgramReload() {
        ts_js_1.Debug.assert(!!configFileName);
        updateLevel = ts_js_1.ProgramUpdateLevel.Full;
        scheduleProgramUpdate();
    }
    function updateProgramWithWatchStatus(_timeoutType) {
        timerToUpdateProgram = undefined;
        reportFileChangeDetectedOnCreateProgram = true;
        updateProgram();
    }
    function updateProgram() {
        switch (updateLevel) {
            case ts_js_1.ProgramUpdateLevel.RootNamesAndUpdate:
                reloadFileNamesFromConfigFile();
                break;
            case ts_js_1.ProgramUpdateLevel.Full:
                reloadConfigFile();
                break;
            default:
                synchronizeProgram();
                break;
        }
        return getCurrentBuilderProgram();
    }
    function reloadFileNamesFromConfigFile() {
        writeLog("Reloading new file names and options");
        ts_js_1.Debug.assert(compilerOptions);
        ts_js_1.Debug.assert(configFileName);
        updateLevel = ts_js_1.ProgramUpdateLevel.Update;
        rootFileNames = (0, ts_js_1.getFileNamesFromConfigSpecs)(compilerOptions.configFile.configFileSpecs, (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getDirectoryPath)(configFileName), currentDirectory), compilerOptions, parseConfigFileHost, extraFileExtensions);
        if ((0, ts_js_1.updateErrorForNoInputFiles)(rootFileNames, (0, ts_js_1.getNormalizedAbsolutePath)(configFileName, currentDirectory), compilerOptions.configFile.configFileSpecs, configFileParsingDiagnostics, canConfigFileJsonReportNoInputFiles)) {
            hasChangedConfigFileParsingErrors = true;
        }
        // Update the program
        synchronizeProgram();
    }
    function reloadConfigFile() {
        ts_js_1.Debug.assert(configFileName);
        writeLog(`Reloading config file: ${configFileName}`);
        updateLevel = ts_js_1.ProgramUpdateLevel.Update;
        if (cachedDirectoryStructureHost) {
            cachedDirectoryStructureHost.clearCache();
        }
        parseConfigFile();
        hasChangedCompilerOptions = true;
        (staleWatches ?? (staleWatches = new Map())).set(undefined, undefined);
        synchronizeProgram();
    }
    function parseConfigFile() {
        ts_js_1.Debug.assert(configFileName);
        setConfigFileParsingResult((0, ts_js_1.getParsedCommandLineOfConfigFile)(configFileName, optionsToExtendForConfigFile, parseConfigFileHost, extendedConfigCache || (extendedConfigCache = new Map()), watchOptionsToExtend, extraFileExtensions)); // TODO: GH#18217
    }
    function setConfigFileParsingResult(configFileParseResult) {
        rootFileNames = configFileParseResult.fileNames;
        compilerOptions = configFileParseResult.options;
        watchOptions = configFileParseResult.watchOptions;
        projectReferences = configFileParseResult.projectReferences;
        wildcardDirectories = configFileParseResult.wildcardDirectories;
        configFileParsingDiagnostics = (0, ts_js_1.getConfigFileParsingDiagnostics)(configFileParseResult).slice();
        canConfigFileJsonReportNoInputFiles = (0, ts_js_1.canJsonReportNoInputFiles)(configFileParseResult.raw);
        hasChangedConfigFileParsingErrors = true;
    }
    function getParsedCommandLine(configFileName) {
        const configPath = toPath(configFileName);
        let config = parsedConfigs?.get(configPath);
        if (config) {
            if (!config.updateLevel)
                return config.parsedCommandLine;
            // With host implementing getParsedCommandLine we cant just update file names
            if (config.parsedCommandLine && config.updateLevel === ts_js_1.ProgramUpdateLevel.RootNamesAndUpdate && !host.getParsedCommandLine) {
                writeLog("Reloading new file names and options");
                ts_js_1.Debug.assert(compilerOptions);
                const fileNames = (0, ts_js_1.getFileNamesFromConfigSpecs)(config.parsedCommandLine.options.configFile.configFileSpecs, (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getDirectoryPath)(configFileName), currentDirectory), compilerOptions, parseConfigFileHost);
                config.parsedCommandLine = { ...config.parsedCommandLine, fileNames };
                config.updateLevel = undefined;
                return config.parsedCommandLine;
            }
        }
        writeLog(`Loading config file: ${configFileName}`);
        const parsedCommandLine = host.getParsedCommandLine ?
            host.getParsedCommandLine(configFileName) :
            getParsedCommandLineFromConfigFileHost(configFileName);
        if (config) {
            config.parsedCommandLine = parsedCommandLine;
            config.updateLevel = undefined;
        }
        else {
            (parsedConfigs || (parsedConfigs = new Map())).set(configPath, config = { parsedCommandLine });
        }
        (staleWatches ?? (staleWatches = new Map())).set(configPath, configFileName);
        return parsedCommandLine;
    }
    function getParsedCommandLineFromConfigFileHost(configFileName) {
        // Ignore the file absent errors
        const onUnRecoverableConfigFileDiagnostic = parseConfigFileHost.onUnRecoverableConfigFileDiagnostic;
        parseConfigFileHost.onUnRecoverableConfigFileDiagnostic = ts_js_1.noop;
        const parsedCommandLine = (0, ts_js_1.getParsedCommandLineOfConfigFile)(configFileName, 
        /*optionsToExtend*/ undefined, parseConfigFileHost, extendedConfigCache || (extendedConfigCache = new Map()), watchOptionsToExtend);
        parseConfigFileHost.onUnRecoverableConfigFileDiagnostic = onUnRecoverableConfigFileDiagnostic;
        return parsedCommandLine;
    }
    function onReleaseParsedCommandLine(fileName) {
        const path = toPath(fileName);
        const config = parsedConfigs?.get(path);
        if (!config)
            return;
        parsedConfigs.delete(path);
        if (config.watchedDirectories)
            (0, ts_js_1.clearMap)(config.watchedDirectories, ts_js_1.closeFileWatcherOf);
        config.watcher?.close();
        (0, ts_js_1.clearSharedExtendedConfigFileWatcher)(path, sharedExtendedConfigFileWatchers);
    }
    function watchFilePath(path, file, callback, pollingInterval, options, watchType) {
        return watchFile(file, (fileName, eventKind) => callback(fileName, eventKind, path), pollingInterval, options, watchType);
    }
    function onSourceFileChange(fileName, eventKind, path) {
        updateCachedSystemWithFile(fileName, path, eventKind);
        // Update the source file cache
        if (eventKind === ts_js_1.FileWatcherEventKind.Deleted && sourceFilesCache.has(path)) {
            resolutionCache.invalidateResolutionOfFile(path);
        }
        nextSourceFileVersion(path);
        // Update the program
        scheduleProgramUpdate();
    }
    function updateCachedSystemWithFile(fileName, path, eventKind) {
        if (cachedDirectoryStructureHost) {
            cachedDirectoryStructureHost.addOrDeleteFile(fileName, path, eventKind);
        }
    }
    function watchMissingFilePath(missingFilePath, missingFileName) {
        // If watching missing referenced config file, we are already watching it so no need for separate watcher
        return parsedConfigs?.has(missingFilePath) ?
            ts_js_1.noopFileWatcher :
            watchFilePath(missingFilePath, missingFileName, onMissingFileChange, ts_js_1.PollingInterval.Medium, watchOptions, ts_js_1.WatchType.MissingFile);
    }
    function onMissingFileChange(fileName, eventKind, missingFilePath) {
        updateCachedSystemWithFile(fileName, missingFilePath, eventKind);
        if (eventKind === ts_js_1.FileWatcherEventKind.Created && missingFilesMap.has(missingFilePath)) {
            missingFilesMap.get(missingFilePath).close();
            missingFilesMap.delete(missingFilePath);
            // Delete the entry in the source files cache so that new source file is created
            nextSourceFileVersion(missingFilePath);
            // When a missing file is created, we should update the graph.
            scheduleProgramUpdate();
        }
    }
    function watchConfigFileWildCardDirectories() {
        (0, ts_js_1.updateWatchingWildcardDirectories)(watchedWildcardDirectories || (watchedWildcardDirectories = new Map()), wildcardDirectories, watchWildcardDirectory);
    }
    function watchWildcardDirectory(directory, flags) {
        return watchDirectory(directory, fileOrDirectory => {
            ts_js_1.Debug.assert(configFileName);
            ts_js_1.Debug.assert(compilerOptions);
            const fileOrDirectoryPath = toPath(fileOrDirectory);
            // Since the file existence changed, update the sourceFiles cache
            if (cachedDirectoryStructureHost) {
                cachedDirectoryStructureHost.addOrDeleteFileOrDirectory(fileOrDirectory, fileOrDirectoryPath);
            }
            nextSourceFileVersion(fileOrDirectoryPath);
            if ((0, ts_js_1.isIgnoredFileFromWildCardWatching)({
                watchedDirPath: toPath(directory),
                fileOrDirectory,
                fileOrDirectoryPath,
                configFileName,
                extraFileExtensions,
                options: compilerOptions,
                program: getCurrentBuilderProgram() || rootFileNames,
                currentDirectory,
                useCaseSensitiveFileNames,
                writeLog,
                toPath,
            }))
                return;
            // Reload is pending, do the reload
            if (updateLevel !== ts_js_1.ProgramUpdateLevel.Full) {
                updateLevel = ts_js_1.ProgramUpdateLevel.RootNamesAndUpdate;
                // Schedule Update the program
                scheduleProgramUpdate();
            }
        }, flags, watchOptions, ts_js_1.WatchType.WildcardDirectory);
    }
    function updateExtendedConfigFilesWatches(forProjectPath, options, watchOptions, watchType) {
        (0, ts_js_1.updateSharedExtendedConfigFileWatcher)(forProjectPath, options, sharedExtendedConfigFileWatchers || (sharedExtendedConfigFileWatchers = new Map()), (extendedConfigFileName, extendedConfigFilePath) => watchFile(extendedConfigFileName, (_fileName, eventKind) => {
            updateCachedSystemWithFile(extendedConfigFileName, extendedConfigFilePath, eventKind);
            // Update extended config cache
            if (extendedConfigCache)
                (0, ts_js_1.cleanExtendedConfigCache)(extendedConfigCache, extendedConfigFilePath, toPath);
            // Update projects
            const projects = sharedExtendedConfigFileWatchers.get(extendedConfigFilePath)?.projects;
            // If there are no referenced projects this extended config file watcher depend on ignore
            if (!projects?.size)
                return;
            projects.forEach(projectPath => {
                if (configFileName && toPath(configFileName) === projectPath) {
                    // If this is the config file of the project, reload completely
                    updateLevel = ts_js_1.ProgramUpdateLevel.Full;
                }
                else {
                    // Reload config for the referenced projects and remove the resolutions from referenced projects since the config file changed
                    const config = parsedConfigs?.get(projectPath);
                    if (config)
                        config.updateLevel = ts_js_1.ProgramUpdateLevel.Full;
                    resolutionCache.removeResolutionsFromProjectReferenceRedirects(projectPath);
                }
                scheduleProgramUpdate();
            });
        }, ts_js_1.PollingInterval.High, watchOptions, watchType), toPath);
    }
    function watchReferencedProject(configFileName, configPath, commandLine) {
        // Watch file
        commandLine.watcher || (commandLine.watcher = watchFile(configFileName, (_fileName, eventKind) => {
            updateCachedSystemWithFile(configFileName, configPath, eventKind);
            const config = parsedConfigs?.get(configPath);
            if (config)
                config.updateLevel = ts_js_1.ProgramUpdateLevel.Full;
            resolutionCache.removeResolutionsFromProjectReferenceRedirects(configPath);
            scheduleProgramUpdate();
        }, ts_js_1.PollingInterval.High, commandLine.parsedCommandLine?.watchOptions || watchOptions, ts_js_1.WatchType.ConfigFileOfReferencedProject));
        // Watch Wild card
        (0, ts_js_1.updateWatchingWildcardDirectories)(commandLine.watchedDirectories || (commandLine.watchedDirectories = new Map()), commandLine.parsedCommandLine?.wildcardDirectories, (directory, flags) => watchDirectory(directory, fileOrDirectory => {
            const fileOrDirectoryPath = toPath(fileOrDirectory);
            // Since the file existence changed, update the sourceFiles cache
            if (cachedDirectoryStructureHost) {
                cachedDirectoryStructureHost.addOrDeleteFileOrDirectory(fileOrDirectory, fileOrDirectoryPath);
            }
            nextSourceFileVersion(fileOrDirectoryPath);
            const config = parsedConfigs?.get(configPath);
            if (!config?.parsedCommandLine)
                return;
            if ((0, ts_js_1.isIgnoredFileFromWildCardWatching)({
                watchedDirPath: toPath(directory),
                fileOrDirectory,
                fileOrDirectoryPath,
                configFileName,
                options: config.parsedCommandLine.options,
                program: config.parsedCommandLine.fileNames,
                currentDirectory,
                useCaseSensitiveFileNames,
                writeLog,
                toPath,
            }))
                return;
            // Reload is pending, do the reload
            if (config.updateLevel !== ts_js_1.ProgramUpdateLevel.Full) {
                config.updateLevel = ts_js_1.ProgramUpdateLevel.RootNamesAndUpdate;
                // Schedule Update the program
                scheduleProgramUpdate();
            }
        }, flags, commandLine.parsedCommandLine?.watchOptions || watchOptions, ts_js_1.WatchType.WildcardDirectoryOfReferencedProject));
        // Watch extended config files
        updateExtendedConfigFilesWatches(configPath, commandLine.parsedCommandLine?.options, commandLine.parsedCommandLine?.watchOptions || watchOptions, ts_js_1.WatchType.ExtendedConfigOfReferencedProject);
    }
}
