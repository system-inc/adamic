"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nullTimer = void 0;
exports.createTimerIf = createTimerIf;
exports.createTimer = createTimer;
exports.mark = mark;
exports.measure = measure;
exports.getCount = getCount;
exports.getDuration = getDuration;
exports.forEachMeasure = forEachMeasure;
exports.forEachMark = forEachMark;
exports.clearMeasures = clearMeasures;
exports.clearMarks = clearMarks;
exports.isEnabled = isEnabled;
exports.enable = enable;
exports.disable = disable;
const ts_js_1 = require("./_namespaces/ts.js");
let perfHooks;
// when set, indicates the implementation of `Performance` to use for user timing.
// when unset, indicates user timing is unavailable or disabled.
let performanceImpl;
/** @internal */
function createTimerIf(condition, measureName, startMarkName, endMarkName) {
    return condition ? createTimer(measureName, startMarkName, endMarkName) : exports.nullTimer;
}
/** @internal */
function createTimer(measureName, startMarkName, endMarkName) {
    let enterCount = 0;
    return {
        enter,
        exit,
    };
    function enter() {
        if (++enterCount === 1) {
            mark(startMarkName);
        }
    }
    function exit() {
        if (--enterCount === 0) {
            mark(endMarkName);
            measure(measureName, startMarkName, endMarkName);
        }
        else if (enterCount < 0) {
            ts_js_1.Debug.fail("enter/exit count does not match.");
        }
    }
}
/** @internal */
exports.nullTimer = { enter: ts_js_1.noop, exit: ts_js_1.noop };
let enabled = false;
let timeorigin = (0, ts_js_1.timestamp)();
const marks = new Map();
const counts = new Map();
const durations = new Map();
/**
 * Marks a performance event.
 *
 * @param markName The name of the mark.
 *
 * @internal
 */
function mark(markName) {
    if (enabled) {
        const count = counts.get(markName) ?? 0;
        counts.set(markName, count + 1);
        marks.set(markName, (0, ts_js_1.timestamp)());
        performanceImpl?.mark(markName);
        if (typeof onProfilerEvent === "function") {
            onProfilerEvent(markName);
        }
    }
}
/**
 * Adds a performance measurement with the specified name.
 *
 * @param measureName The name of the performance measurement.
 * @param startMarkName The name of the starting mark. If not supplied, the point at which the
 *      profiler was enabled is used.
 * @param endMarkName The name of the ending mark. If not supplied, the current timestamp is
 *      used.
 *
 * @internal
 */
function measure(measureName, startMarkName, endMarkName) {
    if (enabled) {
        const end = (endMarkName !== undefined ? marks.get(endMarkName) : undefined) ?? (0, ts_js_1.timestamp)();
        const start = (startMarkName !== undefined ? marks.get(startMarkName) : undefined) ?? timeorigin;
        const previousDuration = durations.get(measureName) || 0;
        durations.set(measureName, previousDuration + (end - start));
        performanceImpl?.measure(measureName, startMarkName, endMarkName);
    }
}
/**
 * Gets the number of times a marker was encountered.
 *
 * @param markName The name of the mark.
 *
 * @internal
 */
function getCount(markName) {
    return counts.get(markName) || 0;
}
/**
 * Gets the total duration of all measurements with the supplied name.
 *
 * @param measureName The name of the measure whose durations should be accumulated.
 *
 * @internal
 */
function getDuration(measureName) {
    return durations.get(measureName) || 0;
}
/**
 * Iterate over each measure, performing some action
 *
 * @param cb The action to perform for each measure
 *
 * @internal
 */
function forEachMeasure(cb) {
    durations.forEach((duration, measureName) => cb(measureName, duration));
}
/** @internal */
function forEachMark(cb) {
    marks.forEach((_time, markName) => cb(markName));
}
/** @internal */
function clearMeasures(name) {
    if (name !== undefined)
        durations.delete(name);
    else
        durations.clear();
    performanceImpl?.clearMeasures(name);
}
/** @internal */
function clearMarks(name) {
    if (name !== undefined) {
        counts.delete(name);
        marks.delete(name);
    }
    else {
        counts.clear();
        marks.clear();
    }
    performanceImpl?.clearMarks(name);
}
/**
 * Indicates whether the performance API is enabled.
 *
 * @internal
 */
function isEnabled() {
    return enabled;
}
/**
 * Enables (and resets) performance measurements for the compiler.
 *
 * @internal
 */
function enable(system = ts_js_1.sys) {
    if (!enabled) {
        enabled = true;
        perfHooks || (perfHooks = (0, ts_js_1.tryGetNativePerformanceHooks)());
        if (perfHooks?.performance) {
            timeorigin = perfHooks.performance.timeOrigin;
            // NodeJS's Web Performance API is currently slower than expected, but we'd still like
            // to be able to leverage native trace events when node is run with either `--cpu-prof`
            // or `--prof`, if we're running with our own `--generateCpuProfile` flag, or when
            // running in debug mode (since its possible to generate a cpu profile while debugging).
            if (perfHooks.shouldWriteNativeEvents || system?.cpuProfilingEnabled?.() || system?.debugMode) {
                performanceImpl = perfHooks.performance;
            }
        }
    }
    return true;
}
/**
 * Disables performance measurements for the compiler.
 *
 * @internal
 */
function disable() {
    if (enabled) {
        marks.clear();
        counts.clear();
        durations.clear();
        performanceImpl = undefined;
        enabled = false;
    }
}
