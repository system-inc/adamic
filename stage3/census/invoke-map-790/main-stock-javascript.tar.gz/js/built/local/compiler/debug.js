"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Debug = exports.LogLevel = void 0;
const ts = __importStar(require("./_namespaces/ts.js"));
const ts_js_1 = require("./_namespaces/ts.js");
/** @internal */
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["Off"] = 0] = "Off";
    LogLevel[LogLevel["Error"] = 1] = "Error";
    LogLevel[LogLevel["Warning"] = 2] = "Warning";
    LogLevel[LogLevel["Info"] = 3] = "Info";
    LogLevel[LogLevel["Verbose"] = 4] = "Verbose";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
/** @internal */
var Debug;
(function (Debug) {
    /* eslint-disable prefer-const */
    let currentAssertionLevel = 0 /* AssertionLevel.None */;
    Debug.currentLogLevel = LogLevel.Warning;
    Debug.isDebugging = false;
    function shouldLog(level) {
        return Debug.currentLogLevel <= level;
    }
    Debug.shouldLog = shouldLog;
    function logMessage(level, s) {
        if (Debug.loggingHost && shouldLog(level)) {
            Debug.loggingHost.log(level, s);
        }
    }
    function log(s) {
        logMessage(LogLevel.Info, s);
    }
    Debug.log = log;
    (function (log_1) {
        function error(s) {
            logMessage(LogLevel.Error, s);
        }
        log_1.error = error;
        function warn(s) {
            logMessage(LogLevel.Warning, s);
        }
        log_1.warn = warn;
        function log(s) {
            logMessage(LogLevel.Info, s);
        }
        log_1.log = log;
        function trace(s) {
            logMessage(LogLevel.Verbose, s);
        }
        log_1.trace = trace;
    })(log = Debug.log || (Debug.log = {}));
    function getAssertionLevel() {
        return currentAssertionLevel;
    }
    Debug.getAssertionLevel = getAssertionLevel;
    function setAssertionLevel(level) {
        currentAssertionLevel = level;
    }
    Debug.setAssertionLevel = setAssertionLevel;
    function shouldAssert(level) {
        return currentAssertionLevel >= level;
    }
    Debug.shouldAssert = shouldAssert;
    /**
     * Tests whether an assertion function should be executed at the current assertion level.
     * The level is read on every call, so `Debug.setAssertionLevel` applies to every later assertion.
     * @param level The minimum assertion level required.
     * @param name The name of the current assertion function.
     */
    function shouldAssertFunction(level, name) {
        return shouldAssert(level);
    }
    function fail(message, stackCrawlMark) {
        // eslint-disable-next-line no-debugger
        debugger;
        const e = new Error(message ? `Debug Failure. ${message}` : "Debug Failure.");
        if (Error.captureStackTrace) {
            Error.captureStackTrace(e, stackCrawlMark || fail);
        }
        throw e;
    }
    Debug.fail = fail;
    function failBadSyntaxKind(node, message, stackCrawlMark) {
        return fail(`${message || "Unexpected node."}\r\nNode ${formatSyntaxKind(node.kind)} was unexpected.`, stackCrawlMark || failBadSyntaxKind);
    }
    Debug.failBadSyntaxKind = failBadSyntaxKind;
    function assert(expression, message, verboseDebugInfo, stackCrawlMark) {
        if (!expression) {
            message = message ? `False expression: ${message}` : "False expression.";
            if (verboseDebugInfo) {
                message += "\r\nVerbose Debug Information: " + (typeof verboseDebugInfo === "string" ? verboseDebugInfo : verboseDebugInfo());
            }
            fail(message, stackCrawlMark || assert);
        }
    }
    Debug.assert = assert;
    function assertEqual(a, b, msg, msg2, stackCrawlMark) {
        if (a !== b) {
            const message = msg ? msg2 ? `${msg} ${msg2}` : msg : "";
            fail(`Expected ${a} === ${b}. ${message}`, stackCrawlMark || assertEqual);
        }
    }
    Debug.assertEqual = assertEqual;
    function assertLessThan(a, b, msg, stackCrawlMark) {
        if (a >= b) {
            fail(`Expected ${a} < ${b}. ${msg || ""}`, stackCrawlMark || assertLessThan);
        }
    }
    Debug.assertLessThan = assertLessThan;
    function assertLessThanOrEqual(a, b, stackCrawlMark) {
        if (a > b) {
            fail(`Expected ${a} <= ${b}`, stackCrawlMark || assertLessThanOrEqual);
        }
    }
    Debug.assertLessThanOrEqual = assertLessThanOrEqual;
    function assertGreaterThanOrEqual(a, b, stackCrawlMark) {
        if (a < b) {
            fail(`Expected ${a} >= ${b}`, stackCrawlMark || assertGreaterThanOrEqual);
        }
    }
    Debug.assertGreaterThanOrEqual = assertGreaterThanOrEqual;
    function assertIsDefined(value, message, stackCrawlMark) {
        // eslint-disable-next-line no-restricted-syntax
        if (value === undefined || value === null) {
            fail(message, stackCrawlMark || assertIsDefined);
        }
    }
    Debug.assertIsDefined = assertIsDefined;
    function checkDefined(value, message, stackCrawlMark) {
        assertIsDefined(value, message, stackCrawlMark || checkDefined);
        return value;
    }
    Debug.checkDefined = checkDefined;
    function assertEachIsDefined(value, message, stackCrawlMark) {
        for (const v of value) {
            assertIsDefined(v, message, stackCrawlMark || assertEachIsDefined);
        }
    }
    Debug.assertEachIsDefined = assertEachIsDefined;
    function checkEachDefined(value, message, stackCrawlMark) {
        assertEachIsDefined(value, message, stackCrawlMark || checkEachDefined);
        return value;
    }
    Debug.checkEachDefined = checkEachDefined;
    function assertNever(member, message = "Illegal value:", stackCrawlMark) {
        const detail = typeof member === "object" && (0, ts_js_1.hasProperty)(member, "kind") && (0, ts_js_1.hasProperty)(member, "pos") ? "SyntaxKind: " + formatSyntaxKind(member.kind) : JSON.stringify(member);
        return fail(`${message} ${detail}`, stackCrawlMark || assertNever);
    }
    Debug.assertNever = assertNever;
    function assertEachNode(nodes, test, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertEachNode")) {
            let passed = true;
            if (test !== undefined && nodes !== undefined) {
                for (const n of nodes) {
                    if (!test(n)) {
                        passed = false;
                        break;
                    }
                }
            }
            assert(passed, message || "Unexpected node.", () => `Node array did not pass test.`, stackCrawlMark || assertEachNode);
        }
    }
    Debug.assertEachNode = assertEachNode;
    function assertNode(node, test, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertNode")) {
            assert(node !== undefined && (test === undefined || test(node)), message || "Unexpected node.", () => `Node ${formatSyntaxKind(node?.kind)} did not pass test.`, stackCrawlMark || assertNode);
        }
    }
    Debug.assertNode = assertNode;
    function assertNotNode(node, test, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertNotNode")) {
            assert(node === undefined || test === undefined || !test(node), message || "Unexpected node.", () => `Node ${formatSyntaxKind(node.kind)} should not have passed test.`, stackCrawlMark || assertNotNode);
        }
    }
    Debug.assertNotNode = assertNotNode;
    function assertOptionalNode(node, test, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertOptionalNode")) {
            assert(test === undefined || node === undefined || test(node), message || "Unexpected node.", () => `Node ${formatSyntaxKind(node?.kind)} did not pass test.`, stackCrawlMark || assertOptionalNode);
        }
    }
    Debug.assertOptionalNode = assertOptionalNode;
    function assertOptionalToken(node, kind, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertOptionalToken")) {
            assert(kind === undefined || node === undefined || node.kind === kind, message || "Unexpected node.", () => `Node ${formatSyntaxKind(node?.kind)} was not a '${formatSyntaxKind(kind)}' token.`, stackCrawlMark || assertOptionalToken);
        }
    }
    Debug.assertOptionalToken = assertOptionalToken;
    function assertMissingNode(node, message, stackCrawlMark) {
        if (shouldAssertFunction(1 /* AssertionLevel.Normal */, "assertMissingNode")) {
            assert(node === undefined, message || "Unexpected node.", () => `Node ${formatSyntaxKind(node.kind)} was unexpected'.`, stackCrawlMark || assertMissingNode);
        }
    }
    Debug.assertMissingNode = assertMissingNode;
    function type(_value) { }
    Debug.type = type;
    function formatSymbol(symbol) {
        return `{ name: ${(0, ts_js_1.unescapeLeadingUnderscores)(symbol.escapedName)}; flags: ${formatSymbolFlags(symbol.flags)}; declarations: ${(0, ts_js_1.map)(symbol.declarations, node => formatSyntaxKind(node.kind))} }`;
    }
    Debug.formatSymbol = formatSymbol;
    /**
     * Formats an enum value as a string for debugging and debug assertions.
     */
    function formatEnum(value = 0, enumObject, isFlags) {
        const members = getEnumMembers(enumObject);
        if (value === 0) {
            return members.length > 0 && members[0][0] === 0 ? members[0][1] : "0";
        }
        if (isFlags) {
            const result = [];
            let remainingFlags = value;
            for (const [enumValue, enumName] of members) {
                if (enumValue > value) {
                    break;
                }
                if (enumValue !== 0 && enumValue & value) {
                    result.push(enumName);
                    remainingFlags &= ~enumValue;
                }
            }
            if (remainingFlags === 0) {
                return result.join("|");
            }
        }
        else {
            for (const [enumValue, enumName] of members) {
                if (enumValue === value) {
                    return enumName;
                }
            }
        }
        return value.toString();
    }
    Debug.formatEnum = formatEnum;
    const enumMemberCache = new Map();
    function getEnumMembers(enumObject) {
        // Assuming enum objects do not change at runtime, we can cache the enum members list
        // to reuse later. This saves us from reconstructing this each and every time we call
        // a formatting function (which can be expensive for large enums like SyntaxKind).
        const existing = enumMemberCache.get(enumObject);
        if (existing) {
            return existing;
        }
        const result = [];
        for (const name in enumObject) {
            const value = enumObject[name];
            if (typeof value === "number") {
                result.push([value, name]);
            }
        }
        const sorted = (0, ts_js_1.toSorted)(result, (x, y) => (0, ts_js_1.compareValues)(x[0], y[0]));
        enumMemberCache.set(enumObject, sorted);
        return sorted;
    }
    function formatSyntaxKind(kind) {
        return formatEnum(kind, ts.SyntaxKind, /*isFlags*/ false);
    }
    Debug.formatSyntaxKind = formatSyntaxKind;
    function formatSnippetKind(kind) {
        return formatEnum(kind, ts.SnippetKind, /*isFlags*/ false);
    }
    Debug.formatSnippetKind = formatSnippetKind;
    function formatScriptKind(kind) {
        return formatEnum(kind, ts.ScriptKind, /*isFlags*/ false);
    }
    Debug.formatScriptKind = formatScriptKind;
    function formatNodeFlags(flags) {
        return formatEnum(flags, ts.NodeFlags, /*isFlags*/ true);
    }
    Debug.formatNodeFlags = formatNodeFlags;
    function formatNodeCheckFlags(flags) {
        return formatEnum(flags, ts.NodeCheckFlags, /*isFlags*/ true);
    }
    Debug.formatNodeCheckFlags = formatNodeCheckFlags;
    function formatModifierFlags(flags) {
        return formatEnum(flags, ts.ModifierFlags, /*isFlags*/ true);
    }
    Debug.formatModifierFlags = formatModifierFlags;
    function formatTransformFlags(flags) {
        return formatEnum(flags, ts.TransformFlags, /*isFlags*/ true);
    }
    Debug.formatTransformFlags = formatTransformFlags;
    function formatEmitFlags(flags) {
        return formatEnum(flags, ts.EmitFlags, /*isFlags*/ true);
    }
    Debug.formatEmitFlags = formatEmitFlags;
    function formatSymbolFlags(flags) {
        return formatEnum(flags, ts.SymbolFlags, /*isFlags*/ true);
    }
    Debug.formatSymbolFlags = formatSymbolFlags;
    function formatTypeFlags(flags) {
        return formatEnum(flags, ts.TypeFlags, /*isFlags*/ true);
    }
    Debug.formatTypeFlags = formatTypeFlags;
    function formatSignatureFlags(flags) {
        return formatEnum(flags, ts.SignatureFlags, /*isFlags*/ true);
    }
    Debug.formatSignatureFlags = formatSignatureFlags;
    function formatObjectFlags(flags) {
        return formatEnum(flags, ts.ObjectFlags, /*isFlags*/ true);
    }
    Debug.formatObjectFlags = formatObjectFlags;
    function formatFlowFlags(flags) {
        return formatEnum(flags, ts.FlowFlags, /*isFlags*/ true);
    }
    Debug.formatFlowFlags = formatFlowFlags;
    function formatRelationComparisonResult(result) {
        return formatEnum(result, ts.RelationComparisonResult, /*isFlags*/ true);
    }
    Debug.formatRelationComparisonResult = formatRelationComparisonResult;
    function formatCheckMode(mode) {
        return formatEnum(mode, ts.CheckMode, /*isFlags*/ true);
    }
    Debug.formatCheckMode = formatCheckMode;
    function formatSignatureCheckMode(mode) {
        return formatEnum(mode, ts.SignatureCheckMode, /*isFlags*/ true);
    }
    Debug.formatSignatureCheckMode = formatSignatureCheckMode;
    function formatTypeFacts(facts) {
        return formatEnum(facts, ts.TypeFacts, /*isFlags*/ true);
    }
    Debug.formatTypeFacts = formatTypeFacts;
    let isDebugInfoEnabled = false;
    let flowNodeProto;
    function attachFlowNodeDebugInfoWorker(flowNode) {
    }
    function attachFlowNodeDebugInfo(flowNode) {
        return flowNode;
    }
    Debug.attachFlowNodeDebugInfo = attachFlowNodeDebugInfo;
    let nodeArrayProto;
    function attachNodeArrayDebugInfoWorker(array) {
    }
    function attachNodeArrayDebugInfo(array) {
    }
    Debug.attachNodeArrayDebugInfo = attachNodeArrayDebugInfo;
    /**
     * Injects debug information into frequently used types.
     */
    function enableDebugInfo() {
        if (isDebugInfoEnabled)
            return;
    }
    Debug.enableDebugInfo = enableDebugInfo;
    function formatVariance(varianceFlags) {
        const variance = varianceFlags & 7 /* VarianceFlags.VarianceMask */;
        let result = variance === 0 /* VarianceFlags.Invariant */ ? "in out" :
            variance === 3 /* VarianceFlags.Bivariant */ ? "[bivariant]" :
                variance === 2 /* VarianceFlags.Contravariant */ ? "in" :
                    variance === 1 /* VarianceFlags.Covariant */ ? "out" :
                        variance === 4 /* VarianceFlags.Independent */ ? "[independent]" : "";
        if (varianceFlags & 8 /* VarianceFlags.Unmeasurable */) {
            result += " (unmeasurable)";
        }
        else if (varianceFlags & 16 /* VarianceFlags.Unreliable */) {
            result += " (unreliable)";
        }
        return result;
    }
    Debug.formatVariance = formatVariance;
    class DebugTypeMapper {
        __debugToString() {
            type(this);
            switch (this.kind) {
                case 3 /* TypeMapKind.Function */:
                    return this.debugInfo?.() || "(function mapper)";
                case 0 /* TypeMapKind.Simple */: {
                    const source = this.source;
                    const sourceFormatter = typeof source === "object" && source !== null && "__debugTypeToString" in source ? source.__debugTypeToString : undefined;
                    Debug.assert(typeof sourceFormatter === "function", "Expected a debug type formatter.");
                    const sourceText = `${Reflect.apply(sourceFormatter, source, [])}`;
                    const target = this.target;
                    const targetFormatter = typeof target === "object" && target !== null && "__debugTypeToString" in target ? target.__debugTypeToString : undefined;
                    Debug.assert(typeof targetFormatter === "function", "Expected a debug type formatter.");
                    return `${sourceText} -> ${Reflect.apply(targetFormatter, target, [])}`;
                }
                case 1 /* TypeMapKind.Array */: {
                    const sources = this.sources;
                    const targets = this.targets;
                    return (0, ts_js_1.zipWith)(sources, targets || (0, ts_js_1.map)(this.sources, () => "any"), (s, t) => {
                        const sFormatter = typeof s === "object" && s !== null && "__debugTypeToString" in s ? s.__debugTypeToString : undefined;
                        Debug.assert(typeof sFormatter === "function", "Expected a debug type formatter.");
                        const sourceText = `${Reflect.apply(sFormatter, s, [])}`;
                        if (targets === undefined && typeof t === "string")
                            return `${sourceText} -> ${t}`;
                        const tFormatter = typeof t === "object" && t !== null && "__debugTypeToString" in t ? t.__debugTypeToString : undefined;
                        Debug.assert(typeof tFormatter === "function", "Expected a debug type formatter.");
                        return `${sourceText} -> ${Reflect.apply(tFormatter, t, [])}`;
                    }).join(", ");
                }
                case 2 /* TypeMapKind.Deferred */:
                    return (0, ts_js_1.zipWith)(this.sources, this.targets, (s, t) => {
                        const sFormatter = typeof s === "object" && s !== null && "__debugTypeToString" in s ? s.__debugTypeToString : undefined;
                        Debug.assert(typeof sFormatter === "function", "Expected a debug type formatter.");
                        const sourceText = `${Reflect.apply(sFormatter, s, [])}`;
                        const target = t();
                        const targetFormatter = typeof target === "object" && target !== null && "__debugTypeToString" in target ? target.__debugTypeToString : undefined;
                        Debug.assert(typeof targetFormatter === "function", "Expected a debug type formatter.");
                        return `${sourceText} -> ${Reflect.apply(targetFormatter, target, [])}`;
                    }).join(", ");
                case 5 /* TypeMapKind.Merged */:
                case 4 /* TypeMapKind.Composite */: {
                    const mapper1 = this.mapper1;
                    const mapper1Formatter = typeof mapper1 === "object" && mapper1 !== null && "__debugToString" in mapper1 ? mapper1.__debugToString : undefined;
                    Debug.assert(typeof mapper1Formatter === "function", "Expected a debug mapper formatter.");
                    const text1 = `${Reflect.apply(mapper1Formatter, mapper1, []).split("\n").join("\n    ")}`;
                    const mapper2 = this.mapper2;
                    const mapper2Formatter = typeof mapper2 === "object" && mapper2 !== null && "__debugToString" in mapper2 ? mapper2.__debugToString : undefined;
                    Debug.assert(typeof mapper2Formatter === "function", "Expected a debug mapper formatter.");
                    return `m1: ${text1}
m2: ${Reflect.apply(mapper2Formatter, mapper2, []).split("\n").join("\n    ")}`;
                }
                default:
                    return assertNever(this);
            }
        }
    }
    Debug.DebugTypeMapper = DebugTypeMapper;
    function attachDebugPrototypeIfDebug(mapper) {
        return mapper;
    }
    Debug.attachDebugPrototypeIfDebug = attachDebugPrototypeIfDebug;
})(Debug || (exports.Debug = Debug = {}));
