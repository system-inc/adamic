"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nullNodeConverters = void 0;
exports.createNodeConverters = createNodeConverters;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function createNodeConverters(factory) {
    return {
        convertToFunctionBlock,
        convertToFunctionExpression,
        convertToClassExpression,
        convertToArrayAssignmentElement,
        convertToObjectAssignmentElement,
        convertToAssignmentPattern,
        convertToObjectAssignmentPattern,
        convertToArrayAssignmentPattern,
        convertToAssignmentElementTarget,
    };
    function convertToFunctionBlock(node, multiLine) {
        if ((0, ts_js_1.isBlock)(node))
            return node;
        const returnStatement = factory.createReturnStatement(node);
        (0, ts_js_1.setTextRange)(returnStatement, node);
        const body = factory.createBlock([returnStatement], multiLine);
        (0, ts_js_1.setTextRange)(body, node);
        return body;
    }
    function convertToFunctionExpression(node) {
        if (!node.body)
            return ts_js_1.Debug.fail(`Cannot convert a FunctionDeclaration without a body`);
        const updated = factory.createFunctionExpression((0, ts_js_1.getModifiers)(node)?.filter(modifier => !(0, ts_js_1.isExportModifier)(modifier) && !(0, ts_js_1.isDefaultModifier)(modifier)), node.asteriskToken, node.name, node.typeParameters, node.parameters, node.type, node.body);
        (0, ts_js_1.setOriginalNode)(updated, node);
        (0, ts_js_1.setTextRange)(updated, node);
        if ((0, ts_js_1.getStartsOnNewLine)(node)) {
            (0, ts_js_1.setStartsOnNewLine)(updated, /*newLine*/ true);
        }
        return updated;
    }
    function convertToClassExpression(node) {
        const updated = factory.createClassExpression(node.modifiers?.filter(modifier => !(0, ts_js_1.isExportModifier)(modifier) && !(0, ts_js_1.isDefaultModifier)(modifier)), node.name, node.typeParameters, node.heritageClauses, node.members);
        (0, ts_js_1.setOriginalNode)(updated, node);
        (0, ts_js_1.setTextRange)(updated, node);
        if ((0, ts_js_1.getStartsOnNewLine)(node)) {
            (0, ts_js_1.setStartsOnNewLine)(updated, /*newLine*/ true);
        }
        return updated;
    }
    function convertToArrayAssignmentElement(element) {
        if ((0, ts_js_1.isBindingElement)(element)) {
            if (element.dotDotDotToken) {
                ts_js_1.Debug.assertNode(element.name, ts_js_1.isIdentifier);
                return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createSpreadElement(element.name), element), element);
            }
            const expression = convertToAssignmentElementTarget(element.name);
            return element.initializer
                ? (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createAssignment(expression, element.initializer), element), element)
                : expression;
        }
        return (0, ts_js_1.cast)(element, ts_js_1.isExpression);
    }
    function convertToObjectAssignmentElement(element) {
        if ((0, ts_js_1.isBindingElement)(element)) {
            if (element.dotDotDotToken) {
                ts_js_1.Debug.assertNode(element.name, ts_js_1.isIdentifier);
                return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createSpreadAssignment(element.name), element), element);
            }
            if (element.propertyName) {
                const expression = convertToAssignmentElementTarget(element.name);
                return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createPropertyAssignment(element.propertyName, element.initializer ? factory.createAssignment(expression, element.initializer) : expression), element), element);
            }
            ts_js_1.Debug.assertNode(element.name, ts_js_1.isIdentifier);
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createShorthandPropertyAssignment(element.name, element.initializer), element), element);
        }
        return (0, ts_js_1.cast)(element, ts_js_1.isObjectLiteralElementLike);
    }
    function convertToAssignmentPattern(node) {
        switch (node.kind) {
            case 208 /* SyntaxKind.ArrayBindingPattern */:
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
                return convertToArrayAssignmentPattern(node);
            case 207 /* SyntaxKind.ObjectBindingPattern */:
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                return convertToObjectAssignmentPattern(node);
        }
    }
    function convertToObjectAssignmentPattern(node) {
        if ((0, ts_js_1.isObjectBindingPattern)(node)) {
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createObjectLiteralExpression((0, ts_js_1.map)(node.elements, convertToObjectAssignmentElement)), node), node);
        }
        return (0, ts_js_1.cast)(node, ts_js_1.isObjectLiteralExpression);
    }
    function convertToArrayAssignmentPattern(node) {
        if ((0, ts_js_1.isArrayBindingPattern)(node)) {
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createArrayLiteralExpression((0, ts_js_1.map)(node.elements, convertToArrayAssignmentElement)), node), node);
        }
        return (0, ts_js_1.cast)(node, ts_js_1.isArrayLiteralExpression);
    }
    function convertToAssignmentElementTarget(node) {
        if ((0, ts_js_1.isBindingPattern)(node)) {
            return convertToAssignmentPattern(node);
        }
        return (0, ts_js_1.cast)(node, ts_js_1.isExpression);
    }
}
/** @internal */
exports.nullNodeConverters = {
    convertToFunctionBlock: ts_js_1.notImplemented,
    convertToFunctionExpression: ts_js_1.notImplemented,
    convertToClassExpression: ts_js_1.notImplemented,
    convertToArrayAssignmentElement: ts_js_1.notImplemented,
    convertToObjectAssignmentElement: ts_js_1.notImplemented,
    convertToAssignmentPattern: ts_js_1.notImplemented,
    convertToObjectAssignmentPattern: ts_js_1.notImplemented,
    convertToArrayAssignmentPattern: ts_js_1.notImplemented,
    convertToAssignmentElementTarget: ts_js_1.notImplemented,
};
