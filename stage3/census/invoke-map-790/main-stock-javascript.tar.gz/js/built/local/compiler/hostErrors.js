"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorCode = errorCode;
exports.errorMessage = errorMessage;
exports.propertyOf = propertyOf;
/** @internal */
function errorCode(error) {
    return typeof error === "object" && error !== null && "code" in error && typeof error.code === "string" ? error.code : undefined;
}
/** @internal */
function errorMessage(error) {
    return typeof error === "object" && error !== null && "message" in error && typeof error.message === "string" ? error.message : undefined;
}
/** @internal */
function propertyOf(value, key) {
    if (value === null || value === undefined) {
        throw new TypeError(`Cannot read properties of ${value === null ? "null" : "undefined"} (reading '${key}')`);
    }
    return Reflect.get(Object(value), key, value);
}
