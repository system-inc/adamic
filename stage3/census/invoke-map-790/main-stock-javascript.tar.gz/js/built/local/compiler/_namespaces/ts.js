"use strict";
/* Generated file to emulate the ts namespace. */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.performance = exports.moduleSpecifiers = void 0;
__exportStar(require("../corePublic.js"), exports);
__exportStar(require("../core.js"), exports);
__exportStar(require("../debug.js"), exports);
__exportStar(require("../semver.js"), exports);
__exportStar(require("../performanceCore.js"), exports);
__exportStar(require("../tracing.js"), exports);
__exportStar(require("../types.js"), exports);
__exportStar(require("../sys.js"), exports);
__exportStar(require("../hostErrors.js"), exports);
__exportStar(require("../path.js"), exports);
__exportStar(require("../diagnosticInformationMap.generated.js"), exports);
__exportStar(require("../scanner.js"), exports);
__exportStar(require("../utilitiesPublic.js"), exports);
__exportStar(require("../utilities.js"), exports);
__exportStar(require("../factory/baseNodeFactory.js"), exports);
__exportStar(require("../factory/parenthesizerRules.js"), exports);
__exportStar(require("../factory/nodeConverters.js"), exports);
__exportStar(require("../factory/nodeFactory.js"), exports);
__exportStar(require("../factory/emitNode.js"), exports);
__exportStar(require("../factory/emitHelpers.js"), exports);
__exportStar(require("../factory/nodeTests.js"), exports);
__exportStar(require("../factory/nodeChildren.js"), exports);
__exportStar(require("../factory/utilities.js"), exports);
__exportStar(require("../factory/utilitiesPublic.js"), exports);
__exportStar(require("../parser.js"), exports);
__exportStar(require("../commandLineParser.js"), exports);
__exportStar(require("../moduleNameResolver.js"), exports);
__exportStar(require("../binder.js"), exports);
__exportStar(require("../symbolWalker.js"), exports);
__exportStar(require("../checker.js"), exports);
__exportStar(require("../visitorPublic.js"), exports);
__exportStar(require("../sourcemap.js"), exports);
__exportStar(require("../transformers/utilities.js"), exports);
__exportStar(require("../transformers/destructuring.js"), exports);
__exportStar(require("../transformers/classThis.js"), exports);
__exportStar(require("../transformers/namedEvaluation.js"), exports);
__exportStar(require("../transformers/taggedTemplate.js"), exports);
__exportStar(require("../transformers/ts.js"), exports);
__exportStar(require("../transformers/classFields.js"), exports);
__exportStar(require("../transformers/typeSerializer.js"), exports);
__exportStar(require("../transformers/legacyDecorators.js"), exports);
__exportStar(require("../transformers/esDecorators.js"), exports);
__exportStar(require("../transformers/es2017.js"), exports);
__exportStar(require("../transformers/es2018.js"), exports);
__exportStar(require("../transformers/es2019.js"), exports);
__exportStar(require("../transformers/es2020.js"), exports);
__exportStar(require("../transformers/es2021.js"), exports);
__exportStar(require("../transformers/esnext.js"), exports);
__exportStar(require("../transformers/jsx.js"), exports);
__exportStar(require("../transformers/es2016.js"), exports);
__exportStar(require("../transformers/es2015.js"), exports);
__exportStar(require("../transformers/generators.js"), exports);
__exportStar(require("../transformers/module/module.js"), exports);
__exportStar(require("../transformers/module/system.js"), exports);
__exportStar(require("../transformers/module/esnextAnd2015.js"), exports);
__exportStar(require("../transformers/module/impliedNodeFormatDependent.js"), exports);
__exportStar(require("../transformers/declarations/diagnostics.js"), exports);
__exportStar(require("../transformers/declarations.js"), exports);
__exportStar(require("../transformer.js"), exports);
__exportStar(require("../emitter.js"), exports);
__exportStar(require("../watchUtilities.js"), exports);
__exportStar(require("../program.js"), exports);
__exportStar(require("../programDiagnostics.js"), exports);
__exportStar(require("../builderStatePublic.js"), exports);
__exportStar(require("../builderState.js"), exports);
__exportStar(require("../builder.js"), exports);
__exportStar(require("../builderPublic.js"), exports);
__exportStar(require("../resolutionCache.js"), exports);
__exportStar(require("../watch.js"), exports);
__exportStar(require("../watchPublic.js"), exports);
__exportStar(require("../tsbuild.js"), exports);
__exportStar(require("../tsbuildPublic.js"), exports);
__exportStar(require("../executeCommandLine.js"), exports);
__exportStar(require("../expressionToTypeNode.js"), exports);
const moduleSpecifiers = __importStar(require("./ts.moduleSpecifiers.js"));
exports.moduleSpecifiers = moduleSpecifiers;
const performance = __importStar(require("./ts.performance.js"));
exports.performance = performance;
