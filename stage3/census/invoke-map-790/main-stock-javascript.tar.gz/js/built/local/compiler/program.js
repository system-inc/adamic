"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitSkippedWithNoDiagnostics = exports.inferredTypesContainingFile = exports.moduleResolutionNameAndModeGetter = exports.ForegroundColorEscapeSequences = void 0;
exports.findConfigFile = findConfigFile;
exports.resolveTripleslashReference = resolveTripleslashReference;
exports.computeCommonSourceDirectoryOfFilenames = computeCommonSourceDirectoryOfFilenames;
exports.createCompilerHost = createCompilerHost;
exports.createGetSourceFile = createGetSourceFile;
exports.createWriteFileMeasuringIO = createWriteFileMeasuringIO;
exports.createCompilerHostWorker = createCompilerHostWorker;
exports.changeCompilerHostLikeToUseCache = changeCompilerHostLikeToUseCache;
exports.getPreEmitDiagnostics = getPreEmitDiagnostics;
exports.formatDiagnostics = formatDiagnostics;
exports.formatDiagnostic = formatDiagnostic;
exports.formatColorAndReset = formatColorAndReset;
exports.formatLocation = formatLocation;
exports.formatDiagnosticsWithColorAndContext = formatDiagnosticsWithColorAndContext;
exports.flattenDiagnosticMessageText = flattenDiagnosticMessageText;
exports.getModeForFileReference = getModeForFileReference;
exports.getModeForResolutionAtIndex = getModeForResolutionAtIndex;
exports.isExclusivelyTypeOnlyImportOrExport = isExclusivelyTypeOnlyImportOrExport;
exports.getModeForUsageLocation = getModeForUsageLocation;
exports.getResolutionModeOverride = getResolutionModeOverride;
exports.createModuleResolutionLoader = createModuleResolutionLoader;
exports.createTypeReferenceResolutionLoader = createTypeReferenceResolutionLoader;
exports.loadWithModeAwareCache = loadWithModeAwareCache;
exports.getInferredLibraryNameResolveFrom = getInferredLibraryNameResolveFrom;
exports.getLibraryNameFromLibFileName = getLibraryNameFromLibFileName;
exports.isReferencedFile = isReferencedFile;
exports.isReferenceFileLocation = isReferenceFileLocation;
exports.getReferencedFileLocation = getReferencedFileLocation;
exports.isProgramUptoDate = isProgramUptoDate;
exports.getConfigFileParsingDiagnostics = getConfigFileParsingDiagnostics;
exports.getImpliedNodeFormatForFile = getImpliedNodeFormatForFile;
exports.getImpliedNodeFormatForFileWorker = getImpliedNodeFormatForFileWorker;
exports.createProgram = createProgram;
exports.getEmitModuleFormatOfFileWorker = getEmitModuleFormatOfFileWorker;
exports.getImpliedNodeFormatForEmitWorker = getImpliedNodeFormatForEmitWorker;
exports.getDefaultResolutionModeForFileWorker = getDefaultResolutionModeForFileWorker;
exports.handleNoEmitOptions = handleNoEmitOptions;
exports.filterSemanticDiagnostics = filterSemanticDiagnostics;
exports.parseConfigHostFromCompilerHostLike = parseConfigHostFromCompilerHostLike;
exports.resolveProjectReferencePath = resolveProjectReferencePath;
exports.getResolutionDiagnostic = getResolutionDiagnostic;
exports.getModuleNameStringLiteralAt = getModuleNameStringLiteralAt;
const ts_js_1 = require("./_namespaces/ts.js");
const performance = __importStar(require("./_namespaces/ts.performance.js"));
const hostErrors_js_1 = require("./hostErrors.js");
function findConfigFile(searchPath, fileExists, configName = "tsconfig.json") {
    return (0, ts_js_1.forEachAncestorDirectory)(searchPath, ancestor => {
        const fileName = (0, ts_js_1.combinePaths)(ancestor, configName);
        return fileExists(fileName) ? fileName : undefined;
    });
}
function resolveTripleslashReference(moduleName, containingFile) {
    const basePath = (0, ts_js_1.getDirectoryPath)(containingFile);
    const referencedFileName = (0, ts_js_1.isRootedDiskPath)(moduleName) ? moduleName : (0, ts_js_1.combinePaths)(basePath, moduleName);
    return (0, ts_js_1.normalizePath)(referencedFileName);
}
/** @internal */
function computeCommonSourceDirectoryOfFilenames(fileNames, currentDirectory, getCanonicalFileName) {
    let commonPathComponents;
    const failed = (0, ts_js_1.forEach)(fileNames, sourceFile => {
        // Each file contributes into common source file path
        const sourcePathComponents = (0, ts_js_1.getNormalizedPathComponents)(sourceFile, currentDirectory);
        sourcePathComponents.pop(); // The base file name is not part of the common directory path
        if (!commonPathComponents) {
            // first file
            commonPathComponents = sourcePathComponents;
            return;
        }
        const n = Math.min(commonPathComponents.length, sourcePathComponents.length);
        for (let i = 0; i < n; i++) {
            if (getCanonicalFileName(commonPathComponents[i]) !== getCanonicalFileName(sourcePathComponents[i])) {
                if (i === 0) {
                    // Failed to find any common path component
                    return true;
                }
                // New common path found that is 0 -> i-1
                commonPathComponents.length = i;
                break;
            }
        }
        // If the sourcePathComponents was shorter than the commonPathComponents, truncate to the sourcePathComponents
        if (sourcePathComponents.length < commonPathComponents.length) {
            commonPathComponents.length = sourcePathComponents.length;
        }
    });
    // A common path can not be found when paths span multiple drives on windows, for example
    if (failed) {
        return "";
    }
    if (!commonPathComponents) { // Can happen when all input files are .d.ts files
        return currentDirectory;
    }
    return (0, ts_js_1.getPathFromPathComponents)(commonPathComponents);
}
function createCompilerHost(options, setParentNodes) {
    return createCompilerHostWorker(options, setParentNodes);
}
/** @internal */
function createGetSourceFile(readFile, setParentNodes) {
    return (fileName, languageVersionOrOptions, onError) => {
        let text;
        try {
            performance.mark("beforeIORead");
            text = readFile(fileName);
            performance.mark("afterIORead");
            performance.measure("I/O Read", "beforeIORead", "afterIORead");
        }
        catch (e) {
            if (onError) {
                onError(String((0, hostErrors_js_1.propertyOf)(e, "message")));
            }
            text = "";
        }
        return text !== undefined ? (0, ts_js_1.createSourceFile)(fileName, text, languageVersionOrOptions, setParentNodes) : undefined;
    };
}
/** @internal */
function createWriteFileMeasuringIO(actualWriteFile, createDirectory, directoryExists) {
    return (fileName, data, writeByteOrderMark, onError) => {
        try {
            performance.mark("beforeIOWrite");
            // NOTE: If patchWriteFileEnsuringDirectory has been called,
            // the system.writeFile will do its own directory creation and
            // the ensureDirectoriesExist call will always be redundant.
            (0, ts_js_1.writeFileEnsuringDirectories)(fileName, data, writeByteOrderMark, actualWriteFile, createDirectory, directoryExists);
            performance.mark("afterIOWrite");
            performance.measure("I/O Write", "beforeIOWrite", "afterIOWrite");
        }
        catch (e) {
            if (onError) {
                onError(String((0, hostErrors_js_1.propertyOf)(e, "message")));
            }
        }
    };
}
/** @internal */
function createCompilerHostWorker(options, setParentNodes, system = ts_js_1.sys) {
    const existingDirectories = new Map();
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(system.useCaseSensitiveFileNames);
    function directoryExists(directoryPath) {
        if (existingDirectories.has(directoryPath)) {
            return true;
        }
        if ((compilerHost.directoryExists || system.directoryExists)(directoryPath)) {
            existingDirectories.set(directoryPath, true);
            return true;
        }
        return false;
    }
    function getDefaultLibLocation() {
        return (0, ts_js_1.getDirectoryPath)((0, ts_js_1.normalizePath)(system.getExecutingFilePath()));
    }
    const newLine = (0, ts_js_1.getNewLineCharacter)(options);
    const realpath = system.realpath && ((path) => system.realpath(path));
    const compilerHost = {
        getSourceFile: createGetSourceFile(fileName => compilerHost.readFile(fileName), setParentNodes),
        getDefaultLibLocation,
        getDefaultLibFileName: options => (0, ts_js_1.combinePaths)(getDefaultLibLocation(), (0, ts_js_1.getDefaultLibFileName)(options)),
        writeFile: createWriteFileMeasuringIO((path, data, writeByteOrderMark) => system.writeFile(path, data, writeByteOrderMark), path => (compilerHost.createDirectory || system.createDirectory)(path), path => directoryExists(path)),
        getCurrentDirectory: (0, ts_js_1.memoize)(() => system.getCurrentDirectory()),
        useCaseSensitiveFileNames: () => system.useCaseSensitiveFileNames,
        getCanonicalFileName,
        getNewLine: () => newLine,
        fileExists: fileName => system.fileExists(fileName),
        readFile: fileName => system.readFile(fileName),
        trace: (s) => system.write(s + newLine),
        directoryExists: directoryName => system.directoryExists(directoryName),
        getEnvironmentVariable: name => system.getEnvironmentVariable ? system.getEnvironmentVariable(name) : "",
        getDirectories: (path) => system.getDirectories(path),
        realpath,
        readDirectory: (path, extensions, include, exclude, depth) => system.readDirectory(path, extensions, include, exclude, depth),
        createDirectory: d => system.createDirectory(d),
        createHash: system.createHash?.bind(system),
    };
    return compilerHost;
}
/** @internal */
function changeCompilerHostLikeToUseCache(host, toPath, getSourceFile) {
    const originalReadFile = host.readFile;
    const originalFileExists = host.fileExists;
    const originalDirectoryExists = host.directoryExists;
    const originalCreateDirectory = host.createDirectory;
    const originalWriteFile = host.writeFile;
    const readFileCache = new Map();
    const fileExistsCache = new Map();
    const directoryExistsCache = new Map();
    const sourceFileCache = new Map();
    const readFileWithCache = (fileName) => {
        const key = toPath(fileName);
        const value = readFileCache.get(key);
        if (value !== undefined)
            return value !== false ? value : undefined;
        return setReadFileCache(key, fileName);
    };
    const setReadFileCache = (key, fileName) => {
        const newValue = originalReadFile.call(host, fileName);
        readFileCache.set(key, newValue !== undefined ? newValue : false);
        return newValue;
    };
    host.readFile = fileName => {
        const key = toPath(fileName);
        const value = readFileCache.get(key);
        if (value !== undefined)
            return value !== false ? value : undefined; // could be .d.ts from output
        // Cache json or buildInfo
        if (!(0, ts_js_1.fileExtensionIs)(fileName, ".json" /* Extension.Json */) && !(0, ts_js_1.isBuildInfoFile)(fileName)) {
            return originalReadFile.call(host, fileName);
        }
        return setReadFileCache(key, fileName);
    };
    const getSourceFileWithCache = getSourceFile ? (fileName, languageVersionOrOptions, onError, shouldCreateNewSourceFile) => {
        const key = toPath(fileName);
        const impliedNodeFormat = typeof languageVersionOrOptions === "object" ? languageVersionOrOptions.impliedNodeFormat : undefined;
        const forImpliedNodeFormat = sourceFileCache.get(impliedNodeFormat);
        const value = forImpliedNodeFormat?.get(key);
        if (value)
            return value;
        const sourceFile = getSourceFile(fileName, languageVersionOrOptions, onError, shouldCreateNewSourceFile);
        if (sourceFile && ((0, ts_js_1.isDeclarationFileName)(fileName) || (0, ts_js_1.fileExtensionIs)(fileName, ".json" /* Extension.Json */))) {
            sourceFileCache.set(impliedNodeFormat, (forImpliedNodeFormat || new Map()).set(key, sourceFile));
        }
        return sourceFile;
    } : undefined;
    // fileExists for any kind of extension
    host.fileExists = fileName => {
        const key = toPath(fileName);
        const value = fileExistsCache.get(key);
        if (value !== undefined)
            return value;
        const newValue = originalFileExists.call(host, fileName);
        fileExistsCache.set(key, !!newValue);
        return newValue;
    };
    if (originalWriteFile) {
        host.writeFile = (fileName, data, ...rest) => {
            const key = toPath(fileName);
            fileExistsCache.delete(key);
            const value = readFileCache.get(key);
            if (value !== undefined && value !== data) {
                readFileCache.delete(key);
                sourceFileCache.forEach(map => map.delete(key));
            }
            else if (getSourceFileWithCache) {
                sourceFileCache.forEach(map => {
                    const sourceFile = map.get(key);
                    if (sourceFile && sourceFile.text !== data) {
                        map.delete(key);
                    }
                });
            }
            originalWriteFile.call(host, fileName, data, ...rest);
        };
    }
    // directoryExists
    if (originalDirectoryExists) {
        host.directoryExists = directory => {
            const key = toPath(directory);
            const value = directoryExistsCache.get(key);
            if (value !== undefined)
                return value;
            const newValue = originalDirectoryExists.call(host, directory);
            directoryExistsCache.set(key, !!newValue);
            return newValue;
        };
        if (originalCreateDirectory) {
            host.createDirectory = directory => {
                const key = toPath(directory);
                directoryExistsCache.delete(key);
                originalCreateDirectory.call(host, directory);
            };
        }
    }
    return {
        originalReadFile,
        originalFileExists,
        originalDirectoryExists,
        originalCreateDirectory,
        originalWriteFile,
        getSourceFileWithCache,
        readFileWithCache,
    };
}
function getPreEmitDiagnostics(program, sourceFile, cancellationToken) {
    let diagnostics;
    diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getConfigFileParsingDiagnostics());
    diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getOptionsDiagnostics(cancellationToken));
    diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getSyntacticDiagnostics(sourceFile, cancellationToken));
    diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getGlobalDiagnostics(cancellationToken));
    diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getSemanticDiagnostics(sourceFile, cancellationToken));
    if ((0, ts_js_1.getEmitDeclarations)(program.getCompilerOptions())) {
        diagnostics = (0, ts_js_1.addRange)(diagnostics, program.getDeclarationDiagnostics(sourceFile, cancellationToken));
    }
    return (0, ts_js_1.sortAndDeduplicateDiagnostics)(diagnostics || ts_js_1.emptyArray);
}
function formatDiagnostics(diagnostics, host) {
    let output = "";
    for (const diagnostic of diagnostics) {
        output += formatDiagnostic(diagnostic, host);
    }
    return output;
}
function formatDiagnostic(diagnostic, host) {
    const errorMessage = `${(0, ts_js_1.diagnosticCategoryName)(diagnostic)} TS${diagnostic.code}: ${flattenDiagnosticMessageText(diagnostic.messageText, host.getNewLine())}${host.getNewLine()}`;
    if (diagnostic.file) {
        const { line, character } = (0, ts_js_1.getLineAndCharacterOfPosition)(diagnostic.file, diagnostic.start); // TODO: GH#18217
        const fileName = diagnostic.file.fileName;
        const relativeFileName = (0, ts_js_1.convertToRelativePath)(fileName, host.getCurrentDirectory(), fileName => host.getCanonicalFileName(fileName));
        return `${relativeFileName}(${line + 1},${character + 1}): ` + errorMessage;
    }
    return errorMessage;
}
/** @internal */
var ForegroundColorEscapeSequences;
(function (ForegroundColorEscapeSequences) {
    ForegroundColorEscapeSequences["Grey"] = "\u001B[90m";
    ForegroundColorEscapeSequences["Red"] = "\u001B[91m";
    ForegroundColorEscapeSequences["Yellow"] = "\u001B[93m";
    ForegroundColorEscapeSequences["Blue"] = "\u001B[94m";
    ForegroundColorEscapeSequences["Cyan"] = "\u001B[96m";
})(ForegroundColorEscapeSequences || (exports.ForegroundColorEscapeSequences = ForegroundColorEscapeSequences = {}));
const gutterStyleSequence = "\u001b[7m";
const gutterSeparator = " ";
const resetEscapeSequence = "\u001b[0m";
const ellipsis = "...";
const halfIndent = "  ";
const indent = "    ";
function getCategoryFormat(category) {
    switch (category) {
        case ts_js_1.DiagnosticCategory.Error:
            return ForegroundColorEscapeSequences.Red;
        case ts_js_1.DiagnosticCategory.Warning:
            return ForegroundColorEscapeSequences.Yellow;
        case ts_js_1.DiagnosticCategory.Suggestion:
            return ts_js_1.Debug.fail("Should never get an Info diagnostic on the command line.");
        case ts_js_1.DiagnosticCategory.Message:
            return ForegroundColorEscapeSequences.Blue;
    }
}
/** @internal */
function formatColorAndReset(text, formatStyle) {
    return formatStyle + text + resetEscapeSequence;
}
function formatCodeSpan(file, start, length, indent, squiggleColor, host) {
    const { line: firstLine, character: firstLineChar } = (0, ts_js_1.getLineAndCharacterOfPosition)(file, start);
    const { line: lastLine, character: lastLineChar } = (0, ts_js_1.getLineAndCharacterOfPosition)(file, start + length);
    const lastLineInFile = (0, ts_js_1.getLineAndCharacterOfPosition)(file, file.text.length).line;
    const hasMoreThanFiveLines = (lastLine - firstLine) >= 4;
    let gutterWidth = (lastLine + 1 + "").length;
    if (hasMoreThanFiveLines) {
        gutterWidth = Math.max(ellipsis.length, gutterWidth);
    }
    let context = "";
    for (let i = firstLine; i <= lastLine; i++) {
        context += host.getNewLine();
        // If the error spans over 5 lines, we'll only show the first 2 and last 2 lines,
        // so we'll skip ahead to the second-to-last line.
        if (hasMoreThanFiveLines && firstLine + 1 < i && i < lastLine - 1) {
            context += indent + formatColorAndReset(ellipsis.padStart(gutterWidth), gutterStyleSequence) + gutterSeparator + host.getNewLine();
            i = lastLine - 1;
        }
        const lineStart = (0, ts_js_1.getPositionOfLineAndCharacter)(file, i, 0);
        const lineEnd = i < lastLineInFile ? (0, ts_js_1.getPositionOfLineAndCharacter)(file, i + 1, 0) : file.text.length;
        let lineContent = file.text.slice(lineStart, lineEnd);
        lineContent = lineContent.trimEnd(); // trim from end
        lineContent = lineContent.replace(/\t/g, " "); // convert tabs to single spaces
        // Output the gutter and the actual contents of the line.
        context += indent + formatColorAndReset((i + 1 + "").padStart(gutterWidth), gutterStyleSequence) + gutterSeparator;
        context += lineContent + host.getNewLine();
        // Output the gutter and the error span for the line using tildes.
        context += indent + formatColorAndReset("".padStart(gutterWidth), gutterStyleSequence) + gutterSeparator;
        context += squiggleColor;
        if (i === firstLine) {
            // If we're on the last line, then limit it to the last character of the last line.
            // Otherwise, we'll just squiggle the rest of the line, giving 'slice' no end position.
            const lastCharForLine = i === lastLine ? lastLineChar : undefined;
            context += lineContent.slice(0, firstLineChar).replace(/\S/g, " ");
            context += lineContent.slice(firstLineChar, lastCharForLine).replace(/./g, "~");
        }
        else if (i === lastLine) {
            context += lineContent.slice(0, lastLineChar).replace(/./g, "~");
        }
        else {
            // Squiggle the entire line.
            context += lineContent.replace(/./g, "~");
        }
        context += resetEscapeSequence;
    }
    return context;
}
/** @internal */
function formatLocation(file, start, host, color = formatColorAndReset) {
    const { line: firstLine, character: firstLineChar } = (0, ts_js_1.getLineAndCharacterOfPosition)(file, start); // TODO: GH#18217
    const relativeFileName = host ? (0, ts_js_1.convertToRelativePath)(file.fileName, host.getCurrentDirectory(), fileName => host.getCanonicalFileName(fileName)) : file.fileName;
    let output = "";
    output += color(relativeFileName, ForegroundColorEscapeSequences.Cyan);
    output += ":";
    output += color(`${firstLine + 1}`, ForegroundColorEscapeSequences.Yellow);
    output += ":";
    output += color(`${firstLineChar + 1}`, ForegroundColorEscapeSequences.Yellow);
    return output;
}
function formatDiagnosticsWithColorAndContext(diagnostics, host) {
    let output = "";
    for (const diagnostic of diagnostics) {
        if (diagnostic.file) {
            const { file, start } = diagnostic;
            output += formatLocation(file, start, host); // TODO: GH#18217
            output += " - ";
        }
        output += formatColorAndReset((0, ts_js_1.diagnosticCategoryName)(diagnostic), getCategoryFormat(diagnostic.category));
        output += formatColorAndReset(` TS${diagnostic.code}: `, ForegroundColorEscapeSequences.Grey);
        output += flattenDiagnosticMessageText(diagnostic.messageText, host.getNewLine());
        if (diagnostic.file && diagnostic.code !== ts_js_1.Diagnostics.File_appears_to_be_binary.code) {
            output += host.getNewLine();
            output += formatCodeSpan(diagnostic.file, diagnostic.start, diagnostic.length, "", getCategoryFormat(diagnostic.category), host); // TODO: GH#18217
        }
        if (diagnostic.relatedInformation) {
            output += host.getNewLine();
            for (const { file, start, length, messageText } of diagnostic.relatedInformation) {
                if (file) {
                    output += host.getNewLine();
                    output += halfIndent + formatLocation(file, start, host); // TODO: GH#18217
                    output += formatCodeSpan(file, start, length, indent, ForegroundColorEscapeSequences.Cyan, host); // TODO: GH#18217
                }
                output += host.getNewLine();
                output += indent + flattenDiagnosticMessageText(messageText, host.getNewLine());
            }
        }
        output += host.getNewLine();
    }
    return output;
}
function flattenDiagnosticMessageText(diag, newLine, indent = 0) {
    if ((0, ts_js_1.isString)(diag)) {
        return diag;
    }
    else if (diag === undefined) {
        return "";
    }
    let result = "";
    if (indent) {
        result += newLine;
        for (let i = 0; i < indent; i++) {
            result += "  ";
        }
    }
    result += diag.messageText;
    indent++;
    if (diag.next) {
        for (const kid of diag.next) {
            result += flattenDiagnosticMessageText(kid, newLine, indent);
        }
    }
    return result;
}
/**
 * Calculates the resulting resolution mode for some reference in some file - this is generally the explicitly
 * provided resolution mode in the reference, unless one is not present, in which case it is the mode of the containing file.
 */
function getModeForFileReference(ref, containingFileMode) {
    return ((0, ts_js_1.isString)(ref) ? containingFileMode : ref.resolutionMode) || containingFileMode;
}
function getModeForResolutionAtIndex(file, index, compilerOptions) {
    // we ensure all elements of file.imports and file.moduleAugmentations have the relevant parent pointers set during program setup,
    // so it's safe to use them even pre-bind
    return getModeForUsageLocationWorker(file, getModuleNameStringLiteralAt(file, index), compilerOptions);
}
/** @internal */
function isExclusivelyTypeOnlyImportOrExport(decl) {
    if ((0, ts_js_1.isExportDeclaration)(decl)) {
        return decl.isTypeOnly;
    }
    if (decl.importClause?.isTypeOnly) {
        return true;
    }
    return false;
}
/**
 * Use `program.getModeForUsageLocation`, which retrieves the correct `compilerOptions`, instead of this function whenever possible.
 * Calculates the final resolution mode for a given module reference node. This function only returns a result when module resolution
 * settings allow differing resolution between ESM imports and CJS requires, or when a mode is explicitly provided via import attributes,
 * which cause an `import` or `require` condition to be used during resolution regardless of module resolution settings. In absence of
 * overriding attributes, and in modes that support differing resolution, the result indicates the syntax the usage would emit to JavaScript.
 * Some examples:
 *
 * ```ts
 * // tsc foo.mts --module nodenext
 * import {} from "mod";
 * // Result: ESNext - the import emits as ESM due to `impliedNodeFormat` set by .mts file extension
 *
 * // tsc foo.cts --module nodenext
 * import {} from "mod";
 * // Result: CommonJS - the import emits as CJS due to `impliedNodeFormat` set by .cts file extension
 *
 * // tsc foo.ts --module preserve --moduleResolution bundler
 * import {} from "mod";
 * // Result: ESNext - the import emits as ESM due to `--module preserve` and `--moduleResolution bundler`
 * // supports conditional imports/exports
 *
 * // tsc foo.ts --module preserve --moduleResolution node10
 * import {} from "mod";
 * // Result: undefined - the import emits as ESM due to `--module preserve`, but `--moduleResolution node10`
 * // does not support conditional imports/exports
 *
 * // tsc foo.ts --module commonjs --moduleResolution node10
 * import type {} from "mod" with { "resolution-mode": "import" };
 * // Result: ESNext - conditional imports/exports always supported with "resolution-mode" attribute
 * ```
 *
 * @param file The file the import or import-like reference is contained within
 * @param usage The module reference string
 * @param compilerOptions The compiler options for the program that owns the file. If the file belongs to a referenced project, the compiler options
 * should be the options of the referenced project, not the referencing project.
 * @returns The final resolution mode of the import
 */
function getModeForUsageLocation(file, usage, compilerOptions) {
    return getModeForUsageLocationWorker(file, usage, compilerOptions);
}
function getModeForUsageLocationWorker(file, usage, compilerOptions) {
    if ((0, ts_js_1.isImportDeclaration)(usage.parent) || (0, ts_js_1.isExportDeclaration)(usage.parent) || (0, ts_js_1.isJSDocImportTag)(usage.parent)) {
        const isTypeOnly = isExclusivelyTypeOnlyImportOrExport(usage.parent);
        if (isTypeOnly) {
            const override = getResolutionModeOverride(usage.parent.attributes);
            if (override) {
                return override;
            }
        }
    }
    if (usage.parent.parent && (0, ts_js_1.isImportTypeNode)(usage.parent.parent)) {
        const override = getResolutionModeOverride(usage.parent.parent.attributes);
        if (override) {
            return override;
        }
    }
    if (compilerOptions && (0, ts_js_1.importSyntaxAffectsModuleResolution)(compilerOptions)) {
        return getEmitSyntaxForUsageLocationWorker(file, usage, compilerOptions);
    }
}
function getEmitSyntaxForUsageLocationWorker(file, usage, compilerOptions) {
    if (!compilerOptions) {
        // This should always be provided, but we try to fail somewhat
        // gracefully to allow projects like ts-node time to update.
        return undefined;
    }
    const exprParentParent = (0, ts_js_1.walkUpParenthesizedExpressions)(usage.parent)?.parent;
    if (exprParentParent && (0, ts_js_1.isImportEqualsDeclaration)(exprParentParent) || (0, ts_js_1.isRequireCall)(usage.parent, /*requireStringLiteralLikeArgument*/ false)) {
        return ts_js_1.ModuleKind.CommonJS;
    }
    if ((0, ts_js_1.isImportCall)((0, ts_js_1.walkUpParenthesizedExpressions)(usage.parent))) {
        return shouldTransformImportCallWorker(file, compilerOptions) ? ts_js_1.ModuleKind.CommonJS : ts_js_1.ModuleKind.ESNext;
    }
    // If we're in --module preserve on an input file, we know that an import
    // is an import. But if this is a declaration file, we'd prefer to use the
    // impliedNodeFormat. Since we want things to be consistent between the two,
    // we need to issue errors when the user writes ESM syntax in a definitely-CJS
    // file, until/unless declaration emit can indicate a true ESM import. On the
    // other hand, writing CJS syntax in a definitely-ESM file is fine, since declaration
    // emit preserves the CJS syntax.
    const fileEmitMode = getEmitModuleFormatOfFileWorker(file, compilerOptions);
    return fileEmitMode === ts_js_1.ModuleKind.CommonJS ? ts_js_1.ModuleKind.CommonJS :
        (0, ts_js_1.emitModuleKindIsNonNodeESM)(fileEmitMode) || fileEmitMode === ts_js_1.ModuleKind.Preserve ? ts_js_1.ModuleKind.ESNext :
            undefined;
}
/** @internal */
function getResolutionModeOverride(node, grammarErrorOnNode) {
    if (!node)
        return undefined;
    if ((0, ts_js_1.length)(node.elements) !== 1) {
        grammarErrorOnNode?.(node, node.token === 118 /* SyntaxKind.WithKeyword */
            ? ts_js_1.Diagnostics.Type_import_attributes_should_have_exactly_one_key_resolution_mode_with_value_import_or_require
            : ts_js_1.Diagnostics.Type_import_assertions_should_have_exactly_one_key_resolution_mode_with_value_import_or_require);
        return undefined;
    }
    const elem = node.elements[0];
    if (!(0, ts_js_1.isStringLiteralLike)(elem.name))
        return undefined;
    if (elem.name.text !== "resolution-mode") {
        grammarErrorOnNode?.(elem.name, node.token === 118 /* SyntaxKind.WithKeyword */
            ? ts_js_1.Diagnostics.resolution_mode_is_the_only_valid_key_for_type_import_attributes
            : ts_js_1.Diagnostics.resolution_mode_is_the_only_valid_key_for_type_import_assertions);
        return undefined;
    }
    if (!(0, ts_js_1.isStringLiteralLike)(elem.value))
        return undefined;
    if (elem.value.text !== "import" && elem.value.text !== "require") {
        grammarErrorOnNode?.(elem.value, ts_js_1.Diagnostics.resolution_mode_should_be_either_require_or_import);
        return undefined;
    }
    return elem.value.text === "import" ? ts_js_1.ModuleKind.ESNext : ts_js_1.ModuleKind.CommonJS;
}
const emptyResolution = {
    resolvedModule: undefined,
    resolvedTypeReferenceDirective: undefined,
};
function getModuleResolutionName(literal) {
    return literal.text;
}
/** @internal */
exports.moduleResolutionNameAndModeGetter = {
    getName: getModuleResolutionName,
    getMode: (entry, file, compilerOptions) => getModeForUsageLocation(file, entry, compilerOptions),
};
/** @internal */
function createModuleResolutionLoader(containingFile, redirectedReference, options, host, cache) {
    return {
        nameAndMode: exports.moduleResolutionNameAndModeGetter,
        resolve: (moduleName, resolutionMode) => (0, ts_js_1.resolveModuleName)(moduleName, containingFile, options, host, cache, redirectedReference, resolutionMode),
    };
}
function getTypeReferenceResolutionName(entry) {
    return !(0, ts_js_1.isString)(entry) ? entry.fileName : entry;
}
const typeReferenceResolutionNameAndModeGetter = {
    getName: getTypeReferenceResolutionName,
    getMode: (entry, file, compilerOptions) => getModeForFileReference(entry, file && getDefaultResolutionModeForFileWorker(file, compilerOptions)),
};
/** @internal */
function createTypeReferenceResolutionLoader(containingFile, redirectedReference, options, host, cache) {
    return {
        nameAndMode: typeReferenceResolutionNameAndModeGetter,
        resolve: (typeRef, resoluionMode) => (0, ts_js_1.resolveTypeReferenceDirective)(typeRef, containingFile, options, host, redirectedReference, cache, resoluionMode),
    };
}
/** @internal */
function loadWithModeAwareCache(entries, containingFile, redirectedReference, options, containingSourceFile, host, resolutionCache, createLoader) {
    if (entries.length === 0)
        return ts_js_1.emptyArray;
    const resolutions = [];
    const cache = new Map();
    const loader = createLoader(containingFile, redirectedReference, options, host, resolutionCache);
    for (const entry of entries) {
        const name = loader.nameAndMode.getName(entry);
        const mode = loader.nameAndMode.getMode(entry, containingSourceFile, redirectedReference?.commandLine.options || options);
        const key = (0, ts_js_1.createModeAwareCacheKey)(name, mode);
        let result = cache.get(key);
        if (!result) {
            cache.set(key, result = loader.resolve(name, mode));
        }
        resolutions.push(result);
    }
    return resolutions;
}
/** @internal */
exports.inferredTypesContainingFile = "__inferred type names__.ts";
/** @internal */
function getInferredLibraryNameResolveFrom(options, currentDirectory, libFileName) {
    const containingDirectory = options.configFilePath ? (0, ts_js_1.getDirectoryPath)(options.configFilePath) : currentDirectory;
    return (0, ts_js_1.combinePaths)(containingDirectory, `__lib_node_modules_lookup_${libFileName}__.ts`);
}
/** @internal */
function getLibraryNameFromLibFileName(libFileName) {
    // Support resolving to lib.dom.d.ts -> @typescript/lib-dom, and
    //                      lib.dom.iterable.d.ts -> @typescript/lib-dom/iterable
    //                      lib.es2015.symbol.wellknown.d.ts -> @typescript/lib-es2015/symbol-wellknown
    const components = libFileName.split(".");
    let path = components[1];
    let i = 2;
    while (components[i] && components[i] !== "d") {
        path += (i === 2 ? "/" : "-") + components[i];
        i++;
    }
    return "@typescript/lib-" + path;
}
/** @internal */
function isReferencedFile(reason) {
    switch (reason?.kind) {
        case ts_js_1.FileIncludeKind.Import:
        case ts_js_1.FileIncludeKind.ReferenceFile:
        case ts_js_1.FileIncludeKind.TypeReferenceDirective:
        case ts_js_1.FileIncludeKind.LibReferenceDirective:
            return true;
        default:
            return false;
    }
}
/** @internal */
function isReferenceFileLocation(location) {
    return location.pos !== undefined;
}
/** @internal */
function getReferencedFileLocation(program, ref) {
    const file = ts_js_1.Debug.checkDefined(program.getSourceFileByPath(ref.file));
    const { kind, index } = ref;
    let pos, end, packageId;
    switch (kind) {
        case ts_js_1.FileIncludeKind.Import:
            const importLiteral = getModuleNameStringLiteralAt(file, index);
            packageId = program.getResolvedModuleFromModuleSpecifier(importLiteral, file)?.resolvedModule?.packageId;
            if (importLiteral.pos === -1)
                return { file, packageId, text: importLiteral.text };
            pos = (0, ts_js_1.skipTrivia)(file.text, importLiteral.pos);
            end = importLiteral.end;
            break;
        case ts_js_1.FileIncludeKind.ReferenceFile:
            ({ pos, end } = file.referencedFiles[index]);
            break;
        case ts_js_1.FileIncludeKind.TypeReferenceDirective:
            ({ pos, end } = file.typeReferenceDirectives[index]);
            packageId = program.getResolvedTypeReferenceDirectiveFromTypeReferenceDirective(file.typeReferenceDirectives[index], file)?.resolvedTypeReferenceDirective?.packageId;
            break;
        case ts_js_1.FileIncludeKind.LibReferenceDirective:
            ({ pos, end } = file.libReferenceDirectives[index]);
            break;
        default:
            return ts_js_1.Debug.assertNever(kind);
    }
    return { file, pos, end, packageId };
}
/**
 * Determines if program structure is upto date or needs to be recreated
 *
 * @internal
 */
function isProgramUptoDate(program, rootFileNames, newOptions, getSourceVersion, fileExists, hasInvalidatedResolutions, hasInvalidatedLibResolutions, hasChangedAutomaticTypeDirectiveNames, getParsedCommandLine, projectReferences) {
    // If we haven't created a program yet or have changed automatic type directives, then it is not up-to-date
    if (!program || hasChangedAutomaticTypeDirectiveNames?.())
        return false;
    // If root file names don't match
    if (!(0, ts_js_1.arrayIsEqualTo)(program.getRootFileNames(), rootFileNames))
        return false;
    let seenResolvedRefs;
    // If project references don't match
    if (!(0, ts_js_1.arrayIsEqualTo)(program.getProjectReferences(), projectReferences, projectReferenceUptoDate))
        return false;
    // If any file is not up-to-date, then the whole program is not up-to-date
    if (program.getSourceFiles().some(sourceFileNotUptoDate))
        return false;
    // If any of the missing file paths are now created
    const missingPaths = program.getMissingFilePaths();
    if (missingPaths && (0, ts_js_1.forEachEntry)(missingPaths, fileExists))
        return false;
    const currentOptions = program.getCompilerOptions();
    // If the compilation settings do no match, then the program is not up-to-date
    if (!(0, ts_js_1.compareDataObjects)(currentOptions, newOptions))
        return false;
    // If library resolution is invalidated, then the program is not up-to-date
    if (program.resolvedLibReferences && (0, ts_js_1.forEachEntry)(program.resolvedLibReferences, (_value, libFileName) => hasInvalidatedLibResolutions(libFileName)))
        return false;
    // If everything matches but the text of config file is changed,
    // error locations can change for program options, so update the program
    if (currentOptions.configFile && newOptions.configFile)
        return currentOptions.configFile.text === newOptions.configFile.text;
    return true;
    function sourceFileNotUptoDate(sourceFile) {
        return !sourceFileVersionUptoDate(sourceFile) ||
            hasInvalidatedResolutions(sourceFile.path);
    }
    function sourceFileVersionUptoDate(sourceFile) {
        return sourceFile.version === getSourceVersion(sourceFile.resolvedPath, sourceFile.fileName);
    }
    function projectReferenceUptoDate(oldRef, newRef, index) {
        return (0, ts_js_1.projectReferenceIsEqualTo)(oldRef, newRef) &&
            resolvedProjectReferenceUptoDate(program.getResolvedProjectReferences()[index], oldRef);
    }
    function resolvedProjectReferenceUptoDate(oldResolvedRef, oldRef) {
        if (oldResolvedRef) {
            // Assume true
            if ((0, ts_js_1.contains)(seenResolvedRefs, oldResolvedRef))
                return true;
            const refPath = resolveProjectReferencePath(oldRef);
            const newParsedCommandLine = getParsedCommandLine(refPath);
            // Check if config file exists
            if (!newParsedCommandLine)
                return false;
            // If change in source file
            if (oldResolvedRef.commandLine.options.configFile !== newParsedCommandLine.options.configFile)
                return false;
            // check file names
            if (!(0, ts_js_1.arrayIsEqualTo)(oldResolvedRef.commandLine.fileNames, newParsedCommandLine.fileNames))
                return false;
            // Add to seen before checking the referenced paths of this config file
            (seenResolvedRefs || (seenResolvedRefs = [])).push(oldResolvedRef);
            // If child project references are upto date, this project reference is uptodate
            return !(0, ts_js_1.forEach)(oldResolvedRef.references, (childResolvedRef, index) => !resolvedProjectReferenceUptoDate(childResolvedRef, oldResolvedRef.commandLine.projectReferences[index]));
        }
        // In old program, not able to resolve project reference path,
        // so if config file doesnt exist, it is uptodate.
        const refPath = resolveProjectReferencePath(oldRef);
        return !getParsedCommandLine(refPath);
    }
}
function getConfigFileParsingDiagnostics(configFileParseResult) {
    return configFileParseResult.options.configFile ?
        [...configFileParseResult.options.configFile.parseDiagnostics, ...configFileParseResult.errors] :
        configFileParseResult.errors;
}
/**
 * A function for determining if a given file is esm or cjs format, assuming modern node module resolution rules, as configured by the
 * `options` parameter.
 *
 * @param fileName The file name to check the format of (it need not exist on disk)
 * @param [packageJsonInfoCache] A cache for package file lookups - it's best to have a cache when this function is called often
 * @param host The ModuleResolutionHost which can perform the filesystem lookups for package json data
 * @param options The compiler options to perform the analysis under - relevant options are `moduleResolution` and `traceResolution`
 * @returns `undefined` if the path has no relevant implied format, `ModuleKind.ESNext` for esm format, and `ModuleKind.CommonJS` for cjs format
 */
function getImpliedNodeFormatForFile(fileName, packageJsonInfoCache, host, options) {
    const result = getImpliedNodeFormatForFileWorker(fileName, packageJsonInfoCache, host, options);
    return typeof result === "object" ? result.impliedNodeFormat : result;
}
/** @internal */
function getImpliedNodeFormatForFileWorker(fileName, packageJsonInfoCache, host, options) {
    const moduleResolution = (0, ts_js_1.getEmitModuleResolutionKind)(options);
    const shouldLookupFromPackageJson = ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext
        || (0, ts_js_1.pathContainsNodeModules)(fileName);
    return (0, ts_js_1.fileExtensionIsOneOf)(fileName, [".d.mts" /* Extension.Dmts */, ".mts" /* Extension.Mts */, ".mjs" /* Extension.Mjs */]) ? ts_js_1.ModuleKind.ESNext :
        (0, ts_js_1.fileExtensionIsOneOf)(fileName, [".d.cts" /* Extension.Dcts */, ".cts" /* Extension.Cts */, ".cjs" /* Extension.Cjs */]) ? ts_js_1.ModuleKind.CommonJS :
            shouldLookupFromPackageJson && (0, ts_js_1.fileExtensionIsOneOf)(fileName, [".d.ts" /* Extension.Dts */, ".ts" /* Extension.Ts */, ".tsx" /* Extension.Tsx */, ".js" /* Extension.Js */, ".jsx" /* Extension.Jsx */]) ? lookupFromPackageJson() :
                undefined; // other extensions, like `json` or `tsbuildinfo`, are set as `undefined` here but they should never be fed through the transformer pipeline
    function lookupFromPackageJson() {
        const state = (0, ts_js_1.getTemporaryModuleResolutionState)(packageJsonInfoCache, host, options);
        const packageJsonLocations = [];
        state.failedLookupLocations = packageJsonLocations;
        state.affectingLocations = packageJsonLocations;
        const packageJsonScope = (0, ts_js_1.getPackageScopeForPath)((0, ts_js_1.getDirectoryPath)(fileName), state);
        const impliedNodeFormat = packageJsonScope?.contents.packageJsonContent.type === "module" ? ts_js_1.ModuleKind.ESNext : ts_js_1.ModuleKind.CommonJS;
        return { impliedNodeFormat, packageJsonLocations, packageJsonScope };
    }
}
const plainJSErrors = new Set([
    // binder errors
    ts_js_1.Diagnostics.Cannot_redeclare_block_scoped_variable_0.code,
    ts_js_1.Diagnostics.A_module_cannot_have_multiple_default_exports.code,
    ts_js_1.Diagnostics.Another_export_default_is_here.code,
    ts_js_1.Diagnostics.The_first_export_default_is_here.code,
    ts_js_1.Diagnostics.Identifier_expected_0_is_a_reserved_word_at_the_top_level_of_a_module.code,
    ts_js_1.Diagnostics.Identifier_expected_0_is_a_reserved_word_in_strict_mode_Modules_are_automatically_in_strict_mode.code,
    ts_js_1.Diagnostics.Identifier_expected_0_is_a_reserved_word_that_cannot_be_used_here.code,
    ts_js_1.Diagnostics.constructor_is_a_reserved_word.code,
    ts_js_1.Diagnostics.delete_cannot_be_called_on_an_identifier_in_strict_mode.code,
    ts_js_1.Diagnostics.Code_contained_in_a_class_is_evaluated_in_JavaScript_s_strict_mode_which_does_not_allow_this_use_of_0_For_more_information_see_https_Colon_Slash_Slashdeveloper_mozilla_org_Slashen_US_Slashdocs_SlashWeb_SlashJavaScript_SlashReference_SlashStrict_mode.code,
    ts_js_1.Diagnostics.Invalid_use_of_0_Modules_are_automatically_in_strict_mode.code,
    ts_js_1.Diagnostics.Invalid_use_of_0_in_strict_mode.code,
    ts_js_1.Diagnostics.A_label_is_not_allowed_here.code,
    ts_js_1.Diagnostics.with_statements_are_not_allowed_in_strict_mode.code,
    // grammar errors
    ts_js_1.Diagnostics.A_break_statement_can_only_be_used_within_an_enclosing_iteration_or_switch_statement.code,
    ts_js_1.Diagnostics.A_break_statement_can_only_jump_to_a_label_of_an_enclosing_statement.code,
    ts_js_1.Diagnostics.A_class_declaration_without_the_default_modifier_must_have_a_name.code,
    ts_js_1.Diagnostics.A_class_member_cannot_have_the_0_keyword.code,
    ts_js_1.Diagnostics.A_comma_expression_is_not_allowed_in_a_computed_property_name.code,
    ts_js_1.Diagnostics.A_continue_statement_can_only_be_used_within_an_enclosing_iteration_statement.code,
    ts_js_1.Diagnostics.A_continue_statement_can_only_jump_to_a_label_of_an_enclosing_iteration_statement.code,
    ts_js_1.Diagnostics.A_continue_statement_can_only_jump_to_a_label_of_an_enclosing_iteration_statement.code,
    ts_js_1.Diagnostics.A_default_clause_cannot_appear_more_than_once_in_a_switch_statement.code,
    ts_js_1.Diagnostics.A_default_export_must_be_at_the_top_level_of_a_file_or_module_declaration.code,
    ts_js_1.Diagnostics.A_definite_assignment_assertion_is_not_permitted_in_this_context.code,
    ts_js_1.Diagnostics.A_destructuring_declaration_must_have_an_initializer.code,
    ts_js_1.Diagnostics.A_get_accessor_cannot_have_parameters.code,
    ts_js_1.Diagnostics.A_rest_element_cannot_contain_a_binding_pattern.code,
    ts_js_1.Diagnostics.A_rest_element_cannot_have_a_property_name.code,
    ts_js_1.Diagnostics.A_rest_element_cannot_have_an_initializer.code,
    ts_js_1.Diagnostics.A_rest_element_must_be_last_in_a_destructuring_pattern.code,
    ts_js_1.Diagnostics.A_rest_parameter_cannot_have_an_initializer.code,
    ts_js_1.Diagnostics.A_rest_parameter_must_be_last_in_a_parameter_list.code,
    ts_js_1.Diagnostics.A_rest_parameter_or_binding_pattern_may_not_have_a_trailing_comma.code,
    ts_js_1.Diagnostics.A_return_statement_cannot_be_used_inside_a_class_static_block.code,
    ts_js_1.Diagnostics.A_set_accessor_cannot_have_rest_parameter.code,
    ts_js_1.Diagnostics.A_set_accessor_must_have_exactly_one_parameter.code,
    ts_js_1.Diagnostics.An_export_declaration_can_only_be_used_at_the_top_level_of_a_module.code,
    ts_js_1.Diagnostics.An_export_declaration_cannot_have_modifiers.code,
    ts_js_1.Diagnostics.An_import_declaration_can_only_be_used_at_the_top_level_of_a_module.code,
    ts_js_1.Diagnostics.An_import_declaration_cannot_have_modifiers.code,
    ts_js_1.Diagnostics.An_object_member_cannot_be_declared_optional.code,
    ts_js_1.Diagnostics.Argument_of_dynamic_import_cannot_be_spread_element.code,
    ts_js_1.Diagnostics.Cannot_assign_to_private_method_0_Private_methods_are_not_writable.code,
    ts_js_1.Diagnostics.Cannot_redeclare_identifier_0_in_catch_clause.code,
    ts_js_1.Diagnostics.Catch_clause_variable_cannot_have_an_initializer.code,
    ts_js_1.Diagnostics.Class_decorators_can_t_be_used_with_static_private_identifier_Consider_removing_the_experimental_decorator.code,
    ts_js_1.Diagnostics.Classes_can_only_extend_a_single_class.code,
    ts_js_1.Diagnostics.Classes_may_not_have_a_field_named_constructor.code,
    ts_js_1.Diagnostics.Did_you_mean_to_use_a_Colon_An_can_only_follow_a_property_name_when_the_containing_object_literal_is_part_of_a_destructuring_pattern.code,
    ts_js_1.Diagnostics.Duplicate_label_0.code,
    ts_js_1.Diagnostics.Dynamic_imports_can_only_accept_a_module_specifier_and_an_optional_set_of_attributes_as_arguments.code,
    ts_js_1.Diagnostics.for_await_loops_cannot_be_used_inside_a_class_static_block.code,
    ts_js_1.Diagnostics.JSX_attributes_must_only_be_assigned_a_non_empty_expression.code,
    ts_js_1.Diagnostics.JSX_elements_cannot_have_multiple_attributes_with_the_same_name.code,
    ts_js_1.Diagnostics.JSX_expressions_may_not_use_the_comma_operator_Did_you_mean_to_write_an_array.code,
    ts_js_1.Diagnostics.JSX_property_access_expressions_cannot_include_JSX_namespace_names.code,
    ts_js_1.Diagnostics.Jump_target_cannot_cross_function_boundary.code,
    ts_js_1.Diagnostics.Line_terminator_not_permitted_before_arrow.code,
    ts_js_1.Diagnostics.Modifiers_cannot_appear_here.code,
    ts_js_1.Diagnostics.Only_a_single_variable_declaration_is_allowed_in_a_for_in_statement.code,
    ts_js_1.Diagnostics.Only_a_single_variable_declaration_is_allowed_in_a_for_of_statement.code,
    ts_js_1.Diagnostics.Private_identifiers_are_not_allowed_outside_class_bodies.code,
    ts_js_1.Diagnostics.Private_identifiers_are_only_allowed_in_class_bodies_and_may_only_be_used_as_part_of_a_class_member_declaration_property_access_or_on_the_left_hand_side_of_an_in_expression.code,
    ts_js_1.Diagnostics.Property_0_is_not_accessible_outside_class_1_because_it_has_a_private_identifier.code,
    ts_js_1.Diagnostics.Tagged_template_expressions_are_not_permitted_in_an_optional_chain.code,
    ts_js_1.Diagnostics.The_left_hand_side_of_a_for_of_statement_may_not_be_async.code,
    ts_js_1.Diagnostics.The_variable_declaration_of_a_for_in_statement_cannot_have_an_initializer.code,
    ts_js_1.Diagnostics.The_variable_declaration_of_a_for_of_statement_cannot_have_an_initializer.code,
    ts_js_1.Diagnostics.Trailing_comma_not_allowed.code,
    ts_js_1.Diagnostics.Variable_declaration_list_cannot_be_empty.code,
    ts_js_1.Diagnostics._0_and_1_operations_cannot_be_mixed_without_parentheses.code,
    ts_js_1.Diagnostics._0_expected.code,
    ts_js_1.Diagnostics._0_is_not_a_valid_meta_property_for_keyword_1_Did_you_mean_2.code,
    ts_js_1.Diagnostics._0_list_cannot_be_empty.code,
    ts_js_1.Diagnostics._0_modifier_already_seen.code,
    ts_js_1.Diagnostics._0_modifier_cannot_appear_on_a_constructor_declaration.code,
    ts_js_1.Diagnostics._0_modifier_cannot_appear_on_a_module_or_namespace_element.code,
    ts_js_1.Diagnostics._0_modifier_cannot_appear_on_a_parameter.code,
    ts_js_1.Diagnostics._0_modifier_cannot_appear_on_class_elements_of_this_kind.code,
    ts_js_1.Diagnostics._0_modifier_cannot_be_used_here.code,
    ts_js_1.Diagnostics._0_modifier_must_precede_1_modifier.code,
    ts_js_1.Diagnostics._0_declarations_can_only_be_declared_inside_a_block.code,
    ts_js_1.Diagnostics._0_declarations_must_be_initialized.code,
    ts_js_1.Diagnostics.extends_clause_already_seen.code,
    ts_js_1.Diagnostics.let_is_not_allowed_to_be_used_as_a_name_in_let_or_const_declarations.code,
    ts_js_1.Diagnostics.Class_constructor_may_not_be_a_generator.code,
    ts_js_1.Diagnostics.Class_constructor_may_not_be_an_accessor.code,
    ts_js_1.Diagnostics.await_expressions_are_only_allowed_within_async_functions_and_at_the_top_levels_of_modules.code,
    ts_js_1.Diagnostics.await_using_statements_are_only_allowed_within_async_functions_and_at_the_top_levels_of_modules.code,
    ts_js_1.Diagnostics.Private_field_0_must_be_declared_in_an_enclosing_class.code,
    // Type errors
    ts_js_1.Diagnostics.This_condition_will_always_return_0_since_JavaScript_compares_objects_by_reference_not_value.code,
]);
/**
 * Determine if source file needs to be re-created even if its text hasn't changed
 */
function shouldProgramCreateNewSourceFiles(program, newOptions) {
    if (!program)
        return false;
    // If any compiler options change, we can't reuse old source file even if version match
    // The change in options like these could result in change in syntax tree or `sourceFile.bindDiagnostics`.
    return (0, ts_js_1.optionsHaveChanges)(program.getCompilerOptions(), newOptions, ts_js_1.sourceFileAffectingCompilerOptions);
}
function createCreateProgramOptions(rootNames, options, host, oldProgram, configFileParsingDiagnostics, typeScriptVersion) {
    return {
        rootNames,
        options,
        host,
        oldProgram,
        configFileParsingDiagnostics,
        typeScriptVersion,
    };
}
function createProgram(_rootNamesOrOptions, _options, _host, _oldProgram, _configFileParsingDiagnostics) {
    let _createProgramOptions = (0, ts_js_1.isArray)(_rootNamesOrOptions) ? createCreateProgramOptions(_rootNamesOrOptions, _options, _host, _oldProgram, _configFileParsingDiagnostics) : _rootNamesOrOptions; // TODO: GH#18217
    const { rootNames, options, configFileParsingDiagnostics, projectReferences, typeScriptVersion, host: createProgramOptionsHost } = _createProgramOptions;
    let { oldProgram } = _createProgramOptions;
    // Stop referencing these objects to ensure GC collects them.
    _createProgramOptions = undefined;
    _rootNamesOrOptions = undefined;
    for (const option of ts_js_1.commandLineOptionOfCustomType) {
        if ((0, ts_js_1.hasProperty)(options, option.name)) {
            if (typeof options[option.name] === "string") {
                throw new Error(`${option.name} is a string value; tsconfig JSON must be parsed with parseJsonSourceFileConfigFileContent or getParsedCommandLineOfConfigFile before passing to createProgram`);
            }
        }
    }
    const reportInvalidIgnoreDeprecations = (0, ts_js_1.memoize)(() => createOptionValueDiagnostic("ignoreDeprecations", ts_js_1.Diagnostics.Invalid_value_for_ignoreDeprecations));
    let processingDefaultLibFiles;
    let processingOtherFiles;
    let files;
    let symlinks;
    let typeChecker;
    let classifiableNames;
    let filesWithReferencesProcessed;
    let cachedBindAndCheckDiagnosticsForFile;
    let cachedDeclarationDiagnosticsForFile;
    const programDiagnostics = (0, ts_js_1.createProgramDiagnostics)(getCompilerOptionsObjectLiteralSyntax);
    let automaticTypeDirectiveNames;
    let automaticTypeDirectiveResolutions;
    let resolvedLibReferences;
    let resolvedLibProcessing;
    let resolvedModules;
    let resolvedModulesProcessing;
    let resolvedTypeReferenceDirectiveNames;
    let resolvedTypeReferenceDirectiveNamesProcessing;
    let packageMap;
    // The below settings are to track if a .js file should be add to the program if loaded via searching under node_modules.
    // This works as imported modules are discovered recursively in a depth first manner, specifically:
    // - For each root file, findSourceFile is called.
    // - This calls processImportedModules for each module imported in the source file.
    // - This calls resolveModuleNames, and then calls findSourceFile for each resolved module.
    // As all these operations happen - and are nested - within the createProgram call, they close over the below variables.
    // The current resolution depth is tracked by incrementing/decrementing as the depth first search progresses.
    const maxNodeModuleJsDepth = typeof options.maxNodeModuleJsDepth === "number" ? options.maxNodeModuleJsDepth : 0;
    let currentNodeModulesDepth = 0;
    // If a module has some of its imports skipped due to being at the depth limit under node_modules, then track
    // this, as it may be imported at a shallower depth later, and then it will need its skipped imports processed.
    const modulesWithElidedImports = new Map();
    // Track source files that are source files found by searching under node_modules, as these shouldn't be compiled.
    const sourceFilesFoundSearchingNodeModules = new Map();
    ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "createProgram", { configFilePath: options.configFilePath, rootDir: options.rootDir }, /*separateBeginAndEnd*/ true);
    performance.mark("beforeProgram");
    const host = createProgramOptionsHost || createCompilerHost(options);
    const configParsingHost = parseConfigHostFromCompilerHostLike(host);
    const getDefaultLibraryFileName = (0, ts_js_1.memoize)(() => host.getDefaultLibFileName(options));
    const defaultLibraryPath = host.getDefaultLibLocation ? host.getDefaultLibLocation() : (0, ts_js_1.getDirectoryPath)(getDefaultLibraryFileName());
    let skipVerifyCompilerOptions = false;
    const currentDirectory = host.getCurrentDirectory();
    const supportedExtensions = (0, ts_js_1.getSupportedExtensions)(options);
    const supportedExtensionsWithJsonIfResolveJsonModule = (0, ts_js_1.getSupportedExtensionsWithJsonIfResolveJsonModule)(options, supportedExtensions);
    // Map storing if there is emit blocking diagnostics for given input
    const hasEmitBlockingDiagnostics = new Map();
    let _compilerOptionsObjectLiteralSyntax;
    let _compilerOptionsPropertySyntax;
    let moduleResolutionCache;
    let actualResolveModuleNamesWorker;
    const hasInvalidatedResolutions = host.hasInvalidatedResolutions || ts_js_1.returnFalse;
    if (host.resolveModuleNameLiterals) {
        actualResolveModuleNamesWorker = host.resolveModuleNameLiterals.bind(host);
        moduleResolutionCache = host.getModuleResolutionCache?.();
    }
    else if (host.resolveModuleNames) {
        actualResolveModuleNamesWorker = (moduleNames, containingFile, redirectedReference, options, containingSourceFile, reusedNames) => host.resolveModuleNames(moduleNames.map(getModuleResolutionName), containingFile, reusedNames?.map(getModuleResolutionName), redirectedReference, options, containingSourceFile).map(resolved => resolved ?
            (resolved.extension !== undefined) ?
                { resolvedModule: resolved } :
                // An older host may have omitted extension, in which case we should infer it from the file extension of resolvedFileName.
                { resolvedModule: { ...resolved, extension: (0, ts_js_1.extensionFromPath)(resolved.resolvedFileName) } } :
            emptyResolution);
        moduleResolutionCache = host.getModuleResolutionCache?.();
    }
    else {
        moduleResolutionCache = (0, ts_js_1.createModuleResolutionCache)(currentDirectory, getCanonicalFileName, options);
        actualResolveModuleNamesWorker = (moduleNames, containingFile, redirectedReference, options, containingSourceFile) => loadWithModeAwareCache(moduleNames, containingFile, redirectedReference, options, containingSourceFile, host, moduleResolutionCache, createModuleResolutionLoader);
    }
    let actualResolveTypeReferenceDirectiveNamesWorker;
    if (host.resolveTypeReferenceDirectiveReferences) {
        actualResolveTypeReferenceDirectiveNamesWorker = host.resolveTypeReferenceDirectiveReferences.bind(host);
    }
    else if (host.resolveTypeReferenceDirectives) {
        actualResolveTypeReferenceDirectiveNamesWorker = (typeDirectiveNames, containingFile, redirectedReference, options, containingSourceFile) => host.resolveTypeReferenceDirectives(typeDirectiveNames.map(getTypeReferenceResolutionName), containingFile, redirectedReference, options, containingSourceFile?.impliedNodeFormat).map(resolvedTypeReferenceDirective => ({ resolvedTypeReferenceDirective }));
    }
    else {
        const typeReferenceDirectiveResolutionCache = (0, ts_js_1.createTypeReferenceDirectiveResolutionCache)(currentDirectory, getCanonicalFileName, 
        /*options*/ undefined, moduleResolutionCache?.getPackageJsonInfoCache(), moduleResolutionCache?.optionsToRedirectsKey);
        actualResolveTypeReferenceDirectiveNamesWorker = (typeDirectiveNames, containingFile, redirectedReference, options, containingSourceFile) => loadWithModeAwareCache(typeDirectiveNames, containingFile, redirectedReference, options, containingSourceFile, host, typeReferenceDirectiveResolutionCache, createTypeReferenceResolutionLoader);
    }
    const hasInvalidatedLibResolutions = host.hasInvalidatedLibResolutions || ts_js_1.returnFalse;
    let actualResolveLibrary;
    if (host.resolveLibrary) {
        actualResolveLibrary = host.resolveLibrary.bind(host);
    }
    else {
        const libraryResolutionCache = (0, ts_js_1.createModuleResolutionCache)(currentDirectory, getCanonicalFileName, options, moduleResolutionCache?.getPackageJsonInfoCache());
        actualResolveLibrary = (libraryName, resolveFrom, options) => (0, ts_js_1.resolveLibrary)(libraryName, resolveFrom, options, host, libraryResolutionCache);
    }
    // Map from a stringified PackageId to the source file with that id.
    // Only one source file may have a given packageId. Others become redirects (see createRedirectSourceFile).
    // `packageIdToSourceFile` is only used while building the program, while `sourceFileToPackageName` and `isSourceFileTargetOfRedirect` are kept around.
    const packageIdToSourceFile = new Map();
    // Maps from a SourceFile's `.path` to the name of the package it was imported with.
    let sourceFileToPackageName = new Map();
    // Key is a file name. Value is the (non-empty, or undefined) list of files that redirect to it.
    let redirectTargetsMap = (0, ts_js_1.createMultiMap)();
    let usesUriStyleNodeCoreModules;
    /**
     * map with
     * - SourceFile if present
     * - false if sourceFile missing for source of project reference redirect
     * - undefined otherwise
     */
    const filesByName = new Map();
    const libFiles = new Set();
    let missingFileNames = new Map();
    // stores 'filename -> file association' ignoring case
    // used to track cases when two file names differ only in casing
    const filesByNameIgnoreCase = host.useCaseSensitiveFileNames() ? new Map() : undefined;
    // A parallel array to projectReferences storing the results of reading in the referenced tsconfig files
    let resolvedProjectReferences;
    let projectReferenceRedirects;
    let mapSourceFileToResolvedRef;
    let mapOutputFileToResolvedRef;
    const useSourceOfProjectReferenceRedirect = !!host.useSourceOfProjectReferenceRedirect?.() &&
        !options.disableSourceOfProjectReferenceRedirect;
    const { onProgramCreateComplete, fileExists, directoryExists } = updateHostForUseSourceOfProjectReferenceRedirect({
        compilerHost: host,
        getSymlinkCache,
        useSourceOfProjectReferenceRedirect,
        toPath,
        getResolvedProjectReferences,
        getRedirectFromOutput,
        forEachResolvedProjectReference,
    });
    const readFile = host.readFile.bind(host);
    ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "shouldProgramCreateNewSourceFiles", { hasOldProgram: !!oldProgram });
    const shouldCreateNewSourceFile = shouldProgramCreateNewSourceFiles(oldProgram, options);
    ts_js_1.tracing?.pop();
    // We set `structuralIsReused` to `undefined` because `tryReuseStructureFromOldProgram` calls `tryReuseStructureFromOldProgram` which checks
    // `structuralIsReused`, which would be a TDZ violation if it was not set in advance to `undefined`.
    let structureIsReused;
    ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "tryReuseStructureFromOldProgram", {});
    structureIsReused = tryReuseStructureFromOldProgram();
    ts_js_1.tracing?.pop();
    if (structureIsReused !== 2 /* StructureIsReused.Completely */) {
        processingDefaultLibFiles = [];
        processingOtherFiles = [];
        if (projectReferences) {
            if (!resolvedProjectReferences) {
                resolvedProjectReferences = projectReferences.map(parseProjectReferenceConfigFile);
            }
            if (rootNames.length) {
                resolvedProjectReferences?.forEach((parsedRef, index) => {
                    if (!parsedRef)
                        return;
                    const out = parsedRef.commandLine.options.outFile;
                    if (useSourceOfProjectReferenceRedirect) {
                        if (out || (0, ts_js_1.getEmitModuleKind)(parsedRef.commandLine.options) === ts_js_1.ModuleKind.None) {
                            for (const fileName of parsedRef.commandLine.fileNames) {
                                processProjectReferenceFile(fileName, { kind: ts_js_1.FileIncludeKind.SourceFromProjectReference, index });
                            }
                        }
                    }
                    else {
                        if (out) {
                            processProjectReferenceFile((0, ts_js_1.changeExtension)(out, ".d.ts"), { kind: ts_js_1.FileIncludeKind.OutputFromProjectReference, index });
                        }
                        else if ((0, ts_js_1.getEmitModuleKind)(parsedRef.commandLine.options) === ts_js_1.ModuleKind.None) {
                            const getCommonSourceDirectory = (0, ts_js_1.memoize)(() => (0, ts_js_1.getCommonSourceDirectoryOfConfig)(parsedRef.commandLine, !host.useCaseSensitiveFileNames()));
                            for (const fileName of parsedRef.commandLine.fileNames) {
                                if (!(0, ts_js_1.isDeclarationFileName)(fileName) && !(0, ts_js_1.fileExtensionIs)(fileName, ".json" /* Extension.Json */)) {
                                    processProjectReferenceFile((0, ts_js_1.getOutputDeclarationFileName)(fileName, parsedRef.commandLine, !host.useCaseSensitiveFileNames(), getCommonSourceDirectory), { kind: ts_js_1.FileIncludeKind.OutputFromProjectReference, index });
                                }
                            }
                        }
                    }
                });
            }
        }
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "processRootFiles", { count: rootNames.length });
        (0, ts_js_1.forEach)(rootNames, (name, index) => processRootFile(name, /*isDefaultLib*/ false, { kind: ts_js_1.FileIncludeKind.RootFile, index }));
        ts_js_1.tracing?.pop();
        // load type declarations specified via 'types' argument or implicitly from types/ and node_modules/@types folders
        automaticTypeDirectiveNames ?? (automaticTypeDirectiveNames = rootNames.length ? (0, ts_js_1.getAutomaticTypeDirectiveNames)(options, host) : ts_js_1.emptyArray);
        automaticTypeDirectiveResolutions = (0, ts_js_1.createModeAwareCache)();
        if (automaticTypeDirectiveNames.length) {
            ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "processTypeReferences", { count: automaticTypeDirectiveNames.length });
            // This containingFilename needs to match with the one used in managed-side
            const containingDirectory = options.configFilePath ? (0, ts_js_1.getDirectoryPath)(options.configFilePath) : currentDirectory;
            const containingFilename = (0, ts_js_1.combinePaths)(containingDirectory, exports.inferredTypesContainingFile);
            const resolutions = resolveTypeReferenceDirectiveNamesReusingOldState(automaticTypeDirectiveNames, containingFilename);
            for (let i = 0; i < automaticTypeDirectiveNames.length; i++) {
                // under node16/nodenext module resolution, load `types`/ata include names as cjs resolution results by passing an `undefined` mode
                automaticTypeDirectiveResolutions.set(automaticTypeDirectiveNames[i], /*mode*/ undefined, resolutions[i]);
                processTypeReferenceDirective(automaticTypeDirectiveNames[i], 
                /*mode*/ undefined, resolutions[i], {
                    kind: ts_js_1.FileIncludeKind.AutomaticTypeDirectiveFile,
                    typeReference: automaticTypeDirectiveNames[i],
                    packageId: resolutions[i]?.resolvedTypeReferenceDirective?.packageId,
                });
            }
            ts_js_1.tracing?.pop();
        }
        if (rootNames.length && !options.noLib) {
            // If '--lib' is not specified, include default library file according to '--target'
            // otherwise, using options specified in '--lib' instead of '--target' default library file
            const defaultLibraryFileName = getDefaultLibraryFileName();
            if (!options.lib && defaultLibraryFileName) {
                libFiles.add(toPath(defaultLibraryFileName));
                processRootFile(defaultLibraryFileName, /*isDefaultLib*/ true, { kind: ts_js_1.FileIncludeKind.LibFile });
            }
            else {
                (0, ts_js_1.forEach)(options.lib, (libFileName, index) => {
                    processRootFile(pathForLibFile(libFileName), /*isDefaultLib*/ true, { kind: ts_js_1.FileIncludeKind.LibFile, index });
                });
            }
        }
        files = (0, ts_js_1.toSorted)(processingDefaultLibFiles, compareDefaultLibFiles).concat(processingOtherFiles);
        processingDefaultLibFiles = undefined;
        processingOtherFiles = undefined;
        filesWithReferencesProcessed = undefined;
    }
    // Release any files we have acquired in the old program but are
    // not part of the new program.
    if (oldProgram && host.onReleaseOldSourceFile) {
        const oldSourceFiles = oldProgram.getSourceFiles();
        for (const oldSourceFile of oldSourceFiles) {
            const newFile = getSourceFileByPath(oldSourceFile.resolvedPath);
            if (shouldCreateNewSourceFile || !newFile || newFile.impliedNodeFormat !== oldSourceFile.impliedNodeFormat ||
                // old file wasn't redirect but new file is
                (oldSourceFile.resolvedPath === oldSourceFile.path && newFile.resolvedPath !== oldSourceFile.path)) {
                host.onReleaseOldSourceFile(oldSourceFile, oldProgram.getCompilerOptions(), !!getSourceFileByPath(oldSourceFile.path), newFile);
            }
        }
        if (!host.getParsedCommandLine) {
            oldProgram.forEachResolvedProjectReference(resolvedProjectReference => {
                if (!getResolvedProjectReferenceByPath(resolvedProjectReference.sourceFile.path)) {
                    host.onReleaseOldSourceFile(resolvedProjectReference.sourceFile, oldProgram.getCompilerOptions(), /*hasSourceFileByPath*/ false, /*newSourceFileByResolvedPath*/ undefined);
                }
            });
        }
    }
    // Release commandlines that new program does not use
    if (oldProgram && host.onReleaseParsedCommandLine) {
        (0, ts_js_1.forEachProjectReference)(oldProgram.getProjectReferences(), oldProgram.getResolvedProjectReferences(), (oldResolvedRef, parent, index) => {
            const oldReference = parent?.commandLine.projectReferences[index] || oldProgram.getProjectReferences()[index];
            const oldRefPath = resolveProjectReferencePath(oldReference);
            if (!projectReferenceRedirects?.has(toPath(oldRefPath))) {
                host.onReleaseParsedCommandLine(oldRefPath, oldResolvedRef, oldProgram.getCompilerOptions());
            }
        });
    }
    // unconditionally set oldProgram to undefined to prevent it from being captured in closure
    oldProgram = undefined;
    resolvedLibProcessing = undefined;
    resolvedModulesProcessing = undefined;
    resolvedTypeReferenceDirectiveNamesProcessing = undefined;
    const program = {
        getRootFileNames: () => rootNames,
        getSourceFile,
        getSourceFileByPath,
        getSourceFiles: () => files,
        getMissingFilePaths: () => missingFileNames,
        getModuleResolutionCache: () => moduleResolutionCache,
        getFilesByNameMap: () => filesByName,
        getCompilerOptions: () => options,
        getSyntacticDiagnostics,
        getOptionsDiagnostics,
        getGlobalDiagnostics,
        getSemanticDiagnostics,
        getCachedSemanticDiagnostics,
        getSuggestionDiagnostics,
        getDeclarationDiagnostics,
        getBindAndCheckDiagnostics,
        getProgramDiagnostics,
        getTypeChecker,
        getClassifiableNames,
        getCommonSourceDirectory,
        emit,
        getCurrentDirectory: () => currentDirectory,
        getNodeCount: () => getTypeChecker().getNodeCount(),
        getIdentifierCount: () => getTypeChecker().getIdentifierCount(),
        getSymbolCount: () => getTypeChecker().getSymbolCount(),
        getTypeCount: () => getTypeChecker().getTypeCount(),
        getInstantiationCount: () => getTypeChecker().getInstantiationCount(),
        getRelationCacheSizes: () => getTypeChecker().getRelationCacheSizes(),
        getFileProcessingDiagnostics: () => programDiagnostics.getFileProcessingDiagnostics(),
        getAutomaticTypeDirectiveNames: () => automaticTypeDirectiveNames,
        getAutomaticTypeDirectiveResolutions: () => automaticTypeDirectiveResolutions,
        isSourceFileFromExternalLibrary,
        isSourceFileDefaultLibrary,
        getModeForUsageLocation,
        getEmitSyntaxForUsageLocation,
        getModeForResolutionAtIndex,
        getSourceFileFromReference,
        getLibFileFromReference,
        sourceFileToPackageName,
        redirectTargetsMap,
        usesUriStyleNodeCoreModules,
        resolvedModules,
        resolvedTypeReferenceDirectiveNames,
        resolvedLibReferences,
        getProgramDiagnosticsContainer: () => programDiagnostics,
        getResolvedModule,
        getResolvedModuleFromModuleSpecifier,
        getResolvedTypeReferenceDirective,
        getResolvedTypeReferenceDirectiveFromTypeReferenceDirective,
        forEachResolvedModule,
        forEachResolvedTypeReferenceDirective,
        getCurrentPackagesMap: () => packageMap,
        typesPackageExists,
        packageBundlesTypes,
        isEmittedFile,
        getConfigFileParsingDiagnostics,
        getProjectReferences,
        getResolvedProjectReferences,
        getRedirectFromSourceFile,
        getResolvedProjectReferenceByPath,
        forEachResolvedProjectReference,
        isSourceOfProjectReferenceRedirect,
        getRedirectFromOutput,
        getCompilerOptionsForFile,
        getDefaultResolutionModeForFile,
        getEmitModuleFormatOfFile,
        getImpliedNodeFormatForEmit,
        shouldTransformImportCall,
        emitBuildInfo,
        fileExists,
        readFile,
        directoryExists,
        getSymlinkCache,
        realpath: host.realpath?.bind(host),
        useCaseSensitiveFileNames: () => host.useCaseSensitiveFileNames(),
        getCanonicalFileName,
        getFileIncludeReasons: () => programDiagnostics.getFileReasons(),
        structureIsReused,
        writeFile,
        getGlobalTypingsCacheLocation: host.getGlobalTypingsCacheLocation?.bind(host),
    };
    onProgramCreateComplete();
    if (!skipVerifyCompilerOptions) {
        verifyCompilerOptions();
    }
    performance.mark("afterProgram");
    performance.measure("Program", "beforeProgram", "afterProgram");
    ts_js_1.tracing?.pop();
    return program;
    function getResolvedModule(file, moduleName, mode) {
        return resolvedModules?.get(file.path)?.get(moduleName, mode);
    }
    function getResolvedModuleFromModuleSpecifier(moduleSpecifier, sourceFile) {
        sourceFile ?? (sourceFile = (0, ts_js_1.getSourceFileOfNode)(moduleSpecifier));
        ts_js_1.Debug.assertIsDefined(sourceFile, "`moduleSpecifier` must have a `SourceFile` ancestor. Use `program.getResolvedModule` instead to provide the containing file and resolution mode.");
        return getResolvedModule(sourceFile, moduleSpecifier.text, getModeForUsageLocation(sourceFile, moduleSpecifier));
    }
    function getResolvedTypeReferenceDirective(file, typeDirectiveName, mode) {
        return resolvedTypeReferenceDirectiveNames?.get(file.path)?.get(typeDirectiveName, mode);
    }
    function getResolvedTypeReferenceDirectiveFromTypeReferenceDirective(typeRef, sourceFile) {
        return getResolvedTypeReferenceDirective(sourceFile, typeRef.fileName, getModeForTypeReferenceDirectiveInFile(typeRef, sourceFile));
    }
    function forEachResolvedModule(callback, file) {
        forEachResolution(resolvedModules, callback, file);
    }
    function forEachResolvedTypeReferenceDirective(callback, file) {
        forEachResolution(resolvedTypeReferenceDirectiveNames, callback, file);
    }
    function forEachResolution(resolutionCache, callback, file) {
        if (file)
            resolutionCache?.get(file.path)?.forEach((resolution, name, mode) => callback(resolution, name, mode, file.path));
        else
            resolutionCache?.forEach((resolutions, filePath) => resolutions.forEach((resolution, name, mode) => callback(resolution, name, mode, filePath)));
    }
    function getPackagesMap() {
        if (packageMap)
            return packageMap;
        packageMap = new Map();
        // A package name maps to true when we detect it has .d.ts files.
        // This is useful as an approximation of whether a package bundles its own types.
        // Note: we only look at files already found by module resolution,
        // so there may be files we did not consider.
        forEachResolvedModule(({ resolvedModule }) => {
            if (resolvedModule?.packageId)
                packageMap.set(resolvedModule.packageId.name, resolvedModule.extension === ".d.ts" /* Extension.Dts */ || !!packageMap.get(resolvedModule.packageId.name));
        });
        return packageMap;
    }
    function typesPackageExists(packageName) {
        return getPackagesMap().has((0, ts_js_1.getTypesPackageName)(packageName));
    }
    function packageBundlesTypes(packageName) {
        return !!getPackagesMap().get(packageName);
    }
    function addResolutionDiagnostics(resolution) {
        if (!resolution.resolutionDiagnostics?.length)
            return;
        programDiagnostics.addFileProcessingDiagnostic({
            kind: 2 /* FilePreprocessingDiagnosticsKind.ResolutionDiagnostics */,
            diagnostics: resolution.resolutionDiagnostics,
        });
    }
    function addResolutionDiagnosticsFromResolutionOrCache(containingFile, name, resolution, mode) {
        // diagnostics directly from the resolution
        if (host.resolveModuleNameLiterals || !host.resolveModuleNames)
            return addResolutionDiagnostics(resolution);
        if (!moduleResolutionCache || (0, ts_js_1.isExternalModuleNameRelative)(name))
            return;
        const containingFileName = (0, ts_js_1.getNormalizedAbsolutePath)(containingFile.originalFileName, currentDirectory);
        const containingDir = (0, ts_js_1.getDirectoryPath)(containingFileName);
        const redirectedReference = getRedirectReferenceForResolution(containingFile);
        // only nonrelative names hit the cache, and, at least as of right now, only nonrelative names can issue diagnostics
        // (Since diagnostics are only issued via import or export map lookup)
        // This may totally change if/when the issue of output paths not mapping to input files is fixed in a broader context
        // When it is, how we extract diagnostics from the module name resolver will have the be refined - the current cache
        // APIs wrapping the underlying resolver make it almost impossible to smuggle the diagnostics out in a generalized way
        const fromCache = moduleResolutionCache.getFromNonRelativeNameCache(name, mode, containingDir, redirectedReference);
        if (fromCache)
            addResolutionDiagnostics(fromCache);
    }
    function resolveModuleNamesWorker(moduleNames, containingFile, reusedNames) {
        const containingFileName = (0, ts_js_1.getNormalizedAbsolutePath)(containingFile.originalFileName, currentDirectory);
        const redirectedReference = getRedirectReferenceForResolution(containingFile);
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "resolveModuleNamesWorker", { containingFileName });
        performance.mark("beforeResolveModule");
        const result = actualResolveModuleNamesWorker(moduleNames, containingFileName, redirectedReference, options, containingFile, reusedNames);
        performance.mark("afterResolveModule");
        performance.measure("ResolveModule", "beforeResolveModule", "afterResolveModule");
        ts_js_1.tracing?.pop();
        return result;
    }
    function resolveTypeReferenceDirectiveNamesWorker(typeDirectiveNames, containingFile, reusedNames) {
        const containingSourceFile = !(0, ts_js_1.isString)(containingFile) ? containingFile : undefined;
        const containingFileName = !(0, ts_js_1.isString)(containingFile) ? (0, ts_js_1.getNormalizedAbsolutePath)(containingFile.originalFileName, currentDirectory) : containingFile;
        const redirectedReference = containingSourceFile && getRedirectReferenceForResolution(containingSourceFile);
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "resolveTypeReferenceDirectiveNamesWorker", { containingFileName });
        performance.mark("beforeResolveTypeReference");
        const result = actualResolveTypeReferenceDirectiveNamesWorker(typeDirectiveNames, containingFileName, redirectedReference, options, containingSourceFile, reusedNames);
        performance.mark("afterResolveTypeReference");
        performance.measure("ResolveTypeReference", "beforeResolveTypeReference", "afterResolveTypeReference");
        ts_js_1.tracing?.pop();
        return result;
    }
    function getRedirectReferenceForResolution(file) {
        const redirect = getRedirectFromSourceFile(file.originalFileName);
        if (redirect || !(0, ts_js_1.isDeclarationFileName)(file.originalFileName))
            return redirect?.resolvedRef;
        // The originalFileName could not be actual source file name if file found was d.ts from referecned project
        // So in this case try to look up if this is output from referenced project, if it is use the redirected project in that case
        const resultFromDts = getRedirectFromOutput(file.path)?.resolvedRef;
        if (resultFromDts)
            return resultFromDts;
        // If preserveSymlinks is true, module resolution wont jump the symlink
        // but the resolved real path may be the .d.ts from project reference
        // Note:: Currently we try the real path only if the
        // file is from node_modules to avoid having to run real path on all file paths
        if (!host.realpath || !options.preserveSymlinks || !file.originalFileName.includes(ts_js_1.nodeModulesPathPart))
            return undefined;
        const realDeclarationPath = toPath(host.realpath(file.originalFileName));
        return realDeclarationPath === file.path ? undefined : getRedirectFromOutput(realDeclarationPath)?.resolvedRef;
    }
    function compareDefaultLibFiles(a, b) {
        return (0, ts_js_1.compareValues)(getDefaultLibFilePriority(a), getDefaultLibFilePriority(b));
    }
    function getDefaultLibFilePriority(a) {
        if ((0, ts_js_1.containsPath)(defaultLibraryPath, a.fileName, /*ignoreCase*/ false)) {
            const basename = (0, ts_js_1.getBaseFileName)(a.fileName);
            if (basename === "lib.d.ts" || basename === "lib.es6.d.ts")
                return 0;
            const name = (0, ts_js_1.removeSuffix)((0, ts_js_1.removePrefix)(basename, "lib."), ".d.ts");
            const index = ts_js_1.libs.indexOf(name);
            if (index !== -1)
                return index + 1;
        }
        return ts_js_1.libs.length + 2;
    }
    function toPath(fileName) {
        return (0, ts_js_1.toPath)(fileName, currentDirectory, getCanonicalFileName);
    }
    function getCommonSourceDirectory() {
        let commonSourceDirectory = programDiagnostics.getCommonSourceDirectory();
        if (commonSourceDirectory !== undefined) {
            return commonSourceDirectory;
        }
        const emittedFiles = (0, ts_js_1.filter)(files, file => (0, ts_js_1.sourceFileMayBeEmitted)(file, program));
        commonSourceDirectory = (0, ts_js_1.getCommonSourceDirectory)(options, () => (0, ts_js_1.mapDefined)(emittedFiles, file => file.isDeclarationFile ? undefined : file.fileName), currentDirectory, getCanonicalFileName, commonSourceDirectory => checkSourceFilesBelongToPath(emittedFiles, commonSourceDirectory));
        programDiagnostics.setCommonSourceDirectory(commonSourceDirectory);
        return commonSourceDirectory;
    }
    function getClassifiableNames() {
        if (!classifiableNames) {
            // Initialize a checker so that all our files are bound.
            getTypeChecker();
            classifiableNames = new Set();
            for (const sourceFile of files) {
                sourceFile.classifiableNames?.forEach(value => classifiableNames.add(value));
            }
        }
        return classifiableNames;
    }
    function resolveModuleNamesReusingOldState(moduleNames, containingFile) {
        return resolveNamesReusingOldState({
            entries: moduleNames,
            containingFile,
            containingSourceFile: containingFile,
            redirectedReference: getRedirectReferenceForResolution(containingFile),
            nameAndModeGetter: exports.moduleResolutionNameAndModeGetter,
            resolutionWorker: resolveModuleNamesWorker,
            getResolutionFromOldProgram: (name, mode) => oldProgram?.getResolvedModule(containingFile, name, mode),
            getResolved: ts_js_1.getResolvedModuleFromResolution,
            canReuseResolutionsInFile: () => containingFile === oldProgram?.getSourceFile(containingFile.fileName) &&
                !hasInvalidatedResolutions(containingFile.path),
            resolveToOwnAmbientModule: true,
        });
    }
    function resolveTypeReferenceDirectiveNamesReusingOldState(typeDirectiveNames, containingFile) {
        const containingSourceFile = !(0, ts_js_1.isString)(containingFile) ? containingFile : undefined;
        return resolveNamesReusingOldState({
            entries: typeDirectiveNames,
            containingFile,
            containingSourceFile,
            redirectedReference: containingSourceFile && getRedirectReferenceForResolution(containingSourceFile),
            nameAndModeGetter: typeReferenceResolutionNameAndModeGetter,
            resolutionWorker: resolveTypeReferenceDirectiveNamesWorker,
            getResolutionFromOldProgram: (name, mode) => containingSourceFile ?
                oldProgram?.getResolvedTypeReferenceDirective(containingSourceFile, name, mode) :
                oldProgram?.getAutomaticTypeDirectiveResolutions()?.get(name, mode),
            getResolved: ts_js_1.getResolvedTypeReferenceDirectiveFromResolution,
            canReuseResolutionsInFile: () => typeof containingFile !== "string" ?
                containingFile === oldProgram?.getSourceFile(containingFile.fileName) && !hasInvalidatedResolutions(containingFile.path) :
                !hasInvalidatedResolutions(toPath(containingFile)),
        });
    }
    function resolveNamesReusingOldState({ entries, containingFile, containingSourceFile, redirectedReference, nameAndModeGetter, resolutionWorker, getResolutionFromOldProgram, getResolved, canReuseResolutionsInFile, resolveToOwnAmbientModule, }) {
        if (!entries.length)
            return ts_js_1.emptyArray;
        if (structureIsReused === 0 /* StructureIsReused.Not */ && (!resolveToOwnAmbientModule || !containingSourceFile.ambientModuleNames.length)) {
            // If the old program state does not permit reusing resolutions and `file` does not contain locally defined ambient modules,
            // the best we can do is fallback to the default logic.
            return resolutionWorker(entries, containingFile, 
            /*reusedNames*/ undefined);
        }
        /** An ordered list of module names for which we cannot recover the resolution. */
        let unknownEntries;
        let unknownEntryIndices;
        let result;
        let reusedNames;
        const reuseResolutions = canReuseResolutionsInFile();
        for (let i = 0; i < entries.length; i++) {
            const entry = entries[i];
            if (reuseResolutions) {
                const name = nameAndModeGetter.getName(entry);
                const mode = nameAndModeGetter.getMode(entry, containingSourceFile, redirectedReference?.commandLine.options ?? options);
                const oldResolution = getResolutionFromOldProgram(name, mode);
                const oldResolved = oldResolution && getResolved(oldResolution);
                if (oldResolved) {
                    if ((0, ts_js_1.isTraceEnabled)(options, host)) {
                        (0, ts_js_1.trace)(host, resolutionWorker === resolveModuleNamesWorker ?
                            oldResolved.packageId ?
                                ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                                ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2 :
                            oldResolved.packageId ?
                                ts_js_1.Diagnostics.Reusing_resolution_of_type_reference_directive_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                                ts_js_1.Diagnostics.Reusing_resolution_of_type_reference_directive_0_from_1_of_old_program_it_was_successfully_resolved_to_2, name, containingSourceFile ? (0, ts_js_1.getNormalizedAbsolutePath)(containingSourceFile.originalFileName, currentDirectory) : containingFile, oldResolved.resolvedFileName, oldResolved.packageId && (0, ts_js_1.packageIdToString)(oldResolved.packageId));
                    }
                    (result ?? (result = new Array(entries.length)))[i] = oldResolution;
                    (reusedNames ?? (reusedNames = [])).push(entry);
                    continue;
                }
            }
            if (resolveToOwnAmbientModule) {
                const name = nameAndModeGetter.getName(entry);
                // We know moduleName resolves to an ambient module provided that moduleName:
                // - is in the list of ambient modules locally declared in the current source file.
                if ((0, ts_js_1.contains)(containingSourceFile.ambientModuleNames, name)) {
                    if ((0, ts_js_1.isTraceEnabled)(options, host)) {
                        (0, ts_js_1.trace)(host, ts_js_1.Diagnostics.Module_0_was_resolved_as_locally_declared_ambient_module_in_file_1, name, (0, ts_js_1.getNormalizedAbsolutePath)(containingSourceFile.originalFileName, currentDirectory));
                    }
                    (result ?? (result = new Array(entries.length)))[i] = emptyResolution;
                    continue;
                }
            }
            // Resolution failed in the old program, or resolved to an ambient module for which we can't reuse the result.
            (unknownEntries ?? (unknownEntries = [])).push(entry);
            (unknownEntryIndices ?? (unknownEntryIndices = [])).push(i);
        }
        if (!unknownEntries)
            return result;
        const resolutions = resolutionWorker(unknownEntries, containingFile, reusedNames);
        if (!result)
            return resolutions;
        resolutions.forEach((resolution, index) => result[unknownEntryIndices[index]] = resolution);
        return result;
    }
    function canReuseProjectReferences() {
        return !(0, ts_js_1.forEachProjectReference)(oldProgram.getProjectReferences(), oldProgram.getResolvedProjectReferences(), (oldResolvedRef, parent, index) => {
            const newRef = (parent ? parent.commandLine.projectReferences : projectReferences)[index];
            const newResolvedRef = parseProjectReferenceConfigFile(newRef);
            if (oldResolvedRef) {
                // Resolved project reference has gone missing or changed
                return !newResolvedRef ||
                    newResolvedRef.sourceFile !== oldResolvedRef.sourceFile ||
                    !(0, ts_js_1.arrayIsEqualTo)(oldResolvedRef.commandLine.fileNames, newResolvedRef.commandLine.fileNames);
            }
            else {
                // A previously-unresolved reference may be resolved now
                return newResolvedRef !== undefined;
            }
        }, (oldProjectReferences, parent) => {
            // If array of references is changed, we cant resue old program
            const newReferences = parent ? getResolvedProjectReferenceByPath(parent.sourceFile.path).commandLine.projectReferences : projectReferences;
            return !(0, ts_js_1.arrayIsEqualTo)(oldProjectReferences, newReferences, ts_js_1.projectReferenceIsEqualTo);
        });
    }
    function tryReuseStructureFromOldProgram() {
        if (!oldProgram) {
            return 0 /* StructureIsReused.Not */;
        }
        // check properties that can affect structure of the program or module resolution strategy
        // if any of these properties has changed - structure cannot be reused
        const oldOptions = oldProgram.getCompilerOptions();
        if ((0, ts_js_1.changesAffectModuleResolution)(oldOptions, options)) {
            return 0 /* StructureIsReused.Not */;
        }
        // there is an old program, check if we can reuse its structure
        const oldRootNames = oldProgram.getRootFileNames();
        if (!(0, ts_js_1.arrayIsEqualTo)(oldRootNames, rootNames)) {
            return 0 /* StructureIsReused.Not */;
        }
        // Check if any referenced project tsconfig files are different
        if (!canReuseProjectReferences()) {
            return 0 /* StructureIsReused.Not */;
        }
        if (projectReferences) {
            resolvedProjectReferences = projectReferences.map(parseProjectReferenceConfigFile);
        }
        // check if program source files has changed in the way that can affect structure of the program
        const newSourceFiles = [];
        const modifiedSourceFiles = [];
        structureIsReused = 2 /* StructureIsReused.Completely */;
        // If the missing file paths are now present, it can change the progam structure,
        // and hence cant reuse the structure.
        // This is same as how we dont reuse the structure if one of the file from old program is now missing
        if ((0, ts_js_1.forEachEntry)(oldProgram.getMissingFilePaths(), missingFileName => host.fileExists(missingFileName))) {
            return 0 /* StructureIsReused.Not */;
        }
        const oldSourceFiles = oldProgram.getSourceFiles();
        let SeenPackageName;
        (function (SeenPackageName) {
            SeenPackageName[SeenPackageName["Exists"] = 0] = "Exists";
            SeenPackageName[SeenPackageName["Modified"] = 1] = "Modified";
        })(SeenPackageName || (SeenPackageName = {}));
        const seenPackageNames = new Map();
        for (const oldSourceFile of oldSourceFiles) {
            const sourceFileOptions = getCreateSourceFileOptions(oldSourceFile.fileName, moduleResolutionCache, host, options);
            let newSourceFile = host.getSourceFileByPath
                ? host.getSourceFileByPath(oldSourceFile.fileName, oldSourceFile.resolvedPath, sourceFileOptions, /*onError*/ undefined, shouldCreateNewSourceFile)
                : host.getSourceFile(oldSourceFile.fileName, sourceFileOptions, /*onError*/ undefined, shouldCreateNewSourceFile); // TODO: GH#18217
            if (!newSourceFile) {
                return 0 /* StructureIsReused.Not */;
            }
            newSourceFile.packageJsonLocations = sourceFileOptions.packageJsonLocations?.length ? sourceFileOptions.packageJsonLocations : undefined;
            newSourceFile.packageJsonScope = sourceFileOptions.packageJsonScope;
            ts_js_1.Debug.assert(!newSourceFile.redirectInfo, "Host should not return a redirect source file from `getSourceFile`");
            let fileChanged;
            if (oldSourceFile.redirectInfo) {
                // We got `newSourceFile` by path, so it is actually for the unredirected file.
                // This lets us know if the unredirected file has changed. If it has we should break the redirect.
                if (newSourceFile !== oldSourceFile.redirectInfo.unredirected) {
                    // Underlying file has changed. Might not redirect anymore. Must rebuild program.
                    return 0 /* StructureIsReused.Not */;
                }
                fileChanged = false;
                newSourceFile = oldSourceFile; // Use the redirect.
            }
            else if (oldProgram.redirectTargetsMap.has(oldSourceFile.path)) {
                // If a redirected-to source file changes, the redirect may be broken.
                if (newSourceFile !== oldSourceFile) {
                    return 0 /* StructureIsReused.Not */;
                }
                fileChanged = false;
            }
            else {
                fileChanged = newSourceFile !== oldSourceFile;
            }
            // Since the project references havent changed, its right to set originalFileName and resolvedPath here
            newSourceFile.path = oldSourceFile.path;
            newSourceFile.originalFileName = oldSourceFile.originalFileName;
            newSourceFile.resolvedPath = oldSourceFile.resolvedPath;
            newSourceFile.fileName = oldSourceFile.fileName;
            const packageName = oldProgram.sourceFileToPackageName.get(oldSourceFile.path);
            if (packageName !== undefined) {
                // If there are 2 different source files for the same package name and at least one of them changes,
                // they might become redirects. So we must rebuild the program.
                const prevKind = seenPackageNames.get(packageName);
                const newKind = fileChanged ? 1 /* SeenPackageName.Modified */ : 0 /* SeenPackageName.Exists */;
                if ((prevKind !== undefined && newKind === 1 /* SeenPackageName.Modified */) || prevKind === 1 /* SeenPackageName.Modified */) {
                    return 0 /* StructureIsReused.Not */;
                }
                seenPackageNames.set(packageName, newKind);
            }
            if (fileChanged) {
                if (oldSourceFile.impliedNodeFormat !== newSourceFile.impliedNodeFormat) {
                    structureIsReused = 1 /* StructureIsReused.SafeModules */;
                }
                // The `newSourceFile` object was created for the new program.
                else if (!(0, ts_js_1.arrayIsEqualTo)(oldSourceFile.libReferenceDirectives, newSourceFile.libReferenceDirectives, fileReferenceIsEqualTo)) {
                    // 'lib' references has changed. Matches behavior in changesAffectModuleResolution
                    structureIsReused = 1 /* StructureIsReused.SafeModules */;
                }
                // check tripleslash references
                else if (!(0, ts_js_1.arrayIsEqualTo)(oldSourceFile.referencedFiles, newSourceFile.referencedFiles, fileReferenceIsEqualTo)) {
                    // tripleslash references has changed
                    structureIsReused = 1 /* StructureIsReused.SafeModules */;
                }
                else {
                    // check imports and module augmentations
                    collectExternalModuleReferences(newSourceFile);
                    if (!(0, ts_js_1.arrayIsEqualTo)(oldSourceFile.imports, newSourceFile.imports, moduleNameIsEqualTo)) {
                        // imports has changed
                        structureIsReused = 1 /* StructureIsReused.SafeModules */;
                    }
                    else if (!(0, ts_js_1.arrayIsEqualTo)(oldSourceFile.moduleAugmentations, newSourceFile.moduleAugmentations, moduleNameIsEqualTo)) {
                        // moduleAugmentations has changed
                        structureIsReused = 1 /* StructureIsReused.SafeModules */;
                    }
                    else if ((oldSourceFile.flags & 12582912 /* NodeFlags.PermanentlySetIncrementalFlags */) !== (newSourceFile.flags & 12582912 /* NodeFlags.PermanentlySetIncrementalFlags */)) {
                        // dynamicImport has changed
                        structureIsReused = 1 /* StructureIsReused.SafeModules */;
                    }
                    else if (!(0, ts_js_1.arrayIsEqualTo)(oldSourceFile.typeReferenceDirectives, newSourceFile.typeReferenceDirectives, fileReferenceIsEqualTo)) {
                        // 'types' references has changed
                        structureIsReused = 1 /* StructureIsReused.SafeModules */;
                    }
                }
                // tentatively approve the file
                modifiedSourceFiles.push(newSourceFile);
            }
            else if (hasInvalidatedResolutions(oldSourceFile.path)) {
                // 'module/types' references could have changed
                structureIsReused = 1 /* StructureIsReused.SafeModules */;
                // add file to the modified list so that we will resolve it later
                modifiedSourceFiles.push(newSourceFile);
            }
            // if file has passed all checks it should be safe to reuse it
            newSourceFiles.push(newSourceFile);
        }
        if (structureIsReused !== 2 /* StructureIsReused.Completely */) {
            return structureIsReused;
        }
        // try to verify results of module resolution
        for (const newSourceFile of modifiedSourceFiles) {
            const moduleNames = getModuleNames(newSourceFile);
            const resolutions = resolveModuleNamesReusingOldState(moduleNames, newSourceFile);
            (resolvedModulesProcessing ?? (resolvedModulesProcessing = new Map())).set(newSourceFile.path, resolutions);
            const optionsForFile = getCompilerOptionsForFile(newSourceFile);
            // ensure that module resolution results are still correct
            const resolutionsChanged = (0, ts_js_1.hasChangesInResolutions)(moduleNames, resolutions, name => oldProgram.getResolvedModule(newSourceFile, name.text, getModeForUsageLocationWorker(newSourceFile, name, optionsForFile)), ts_js_1.moduleResolutionIsEqualTo);
            if (resolutionsChanged)
                structureIsReused = 1 /* StructureIsReused.SafeModules */;
            const typesReferenceDirectives = newSourceFile.typeReferenceDirectives;
            const typeReferenceResolutions = resolveTypeReferenceDirectiveNamesReusingOldState(typesReferenceDirectives, newSourceFile);
            (resolvedTypeReferenceDirectiveNamesProcessing ?? (resolvedTypeReferenceDirectiveNamesProcessing = new Map())).set(newSourceFile.path, typeReferenceResolutions);
            // ensure that types resolutions are still correct
            const typeReferenceResolutionsChanged = (0, ts_js_1.hasChangesInResolutions)(typesReferenceDirectives, typeReferenceResolutions, name => oldProgram.getResolvedTypeReferenceDirective(newSourceFile, getTypeReferenceResolutionName(name), getModeForTypeReferenceDirectiveInFile(name, newSourceFile)), ts_js_1.typeDirectiveIsEqualTo);
            if (typeReferenceResolutionsChanged)
                structureIsReused = 1 /* StructureIsReused.SafeModules */;
        }
        if (structureIsReused !== 2 /* StructureIsReused.Completely */) {
            return structureIsReused;
        }
        if ((0, ts_js_1.changesAffectingProgramStructure)(oldOptions, options)) {
            return 1 /* StructureIsReused.SafeModules */;
        }
        if (oldProgram.resolvedLibReferences &&
            (0, ts_js_1.forEachEntry)(oldProgram.resolvedLibReferences, (resolution, libFileName) => pathForLibFileWorker(libFileName).actual !== resolution.actual)) {
            return 1 /* StructureIsReused.SafeModules */;
        }
        if (host.hasChangedAutomaticTypeDirectiveNames) {
            if (host.hasChangedAutomaticTypeDirectiveNames())
                return 1 /* StructureIsReused.SafeModules */;
        }
        else {
            automaticTypeDirectiveNames = (0, ts_js_1.getAutomaticTypeDirectiveNames)(options, host);
            if (!(0, ts_js_1.arrayIsEqualTo)(oldProgram.getAutomaticTypeDirectiveNames(), automaticTypeDirectiveNames))
                return 1 /* StructureIsReused.SafeModules */;
        }
        missingFileNames = oldProgram.getMissingFilePaths();
        // update fileName -> file mapping
        ts_js_1.Debug.assert(newSourceFiles.length === oldProgram.getSourceFiles().length);
        for (const newSourceFile of newSourceFiles) {
            filesByName.set(newSourceFile.path, newSourceFile);
            if (oldProgram.isSourceFileDefaultLibrary(newSourceFile)) {
                libFiles.add(newSourceFile.path);
            }
        }
        const oldFilesByNameMap = oldProgram.getFilesByNameMap();
        oldFilesByNameMap.forEach((oldFile, path) => {
            if (!oldFile) {
                filesByName.set(path, oldFile);
                return;
            }
            if (oldFile.path === path) {
                // Set the file as found during node modules search if it was found that way in old progra,
                if (oldProgram.isSourceFileFromExternalLibrary(oldFile)) {
                    sourceFilesFoundSearchingNodeModules.set(oldFile.path, true);
                }
                return;
            }
            filesByName.set(path, filesByName.get(oldFile.path));
        });
        const isConfigIdentical = oldOptions.configFile && oldOptions.configFile === options.configFile
            || !oldOptions.configFile && !options.configFile && !(0, ts_js_1.optionsHaveChanges)(oldOptions, options, ts_js_1.optionDeclarations);
        programDiagnostics.reuseStateFromOldProgram(oldProgram.getProgramDiagnosticsContainer(), isConfigIdentical);
        skipVerifyCompilerOptions = isConfigIdentical;
        files = newSourceFiles;
        automaticTypeDirectiveNames = oldProgram.getAutomaticTypeDirectiveNames();
        automaticTypeDirectiveResolutions = oldProgram.getAutomaticTypeDirectiveResolutions();
        sourceFileToPackageName = oldProgram.sourceFileToPackageName;
        redirectTargetsMap = oldProgram.redirectTargetsMap;
        usesUriStyleNodeCoreModules = oldProgram.usesUriStyleNodeCoreModules;
        resolvedModules = oldProgram.resolvedModules;
        resolvedTypeReferenceDirectiveNames = oldProgram.resolvedTypeReferenceDirectiveNames;
        resolvedLibReferences = oldProgram.resolvedLibReferences;
        packageMap = oldProgram.getCurrentPackagesMap();
        return 2 /* StructureIsReused.Completely */;
    }
    function getEmitHost(writeFileCallback) {
        return {
            getCanonicalFileName,
            getCommonSourceDirectory: program.getCommonSourceDirectory,
            getCompilerOptions: program.getCompilerOptions,
            getCurrentDirectory: () => currentDirectory,
            getSourceFile: program.getSourceFile,
            getSourceFileByPath: program.getSourceFileByPath,
            getSourceFiles: program.getSourceFiles,
            isSourceFileFromExternalLibrary,
            getRedirectFromSourceFile,
            isSourceOfProjectReferenceRedirect,
            getSymlinkCache,
            writeFile: writeFileCallback || writeFile,
            isEmitBlocked,
            shouldTransformImportCall,
            getEmitModuleFormatOfFile,
            getDefaultResolutionModeForFile,
            getModeForResolutionAtIndex,
            readFile: f => host.readFile(f),
            fileExists: f => {
                // Use local caches
                const path = toPath(f);
                if (getSourceFileByPath(path))
                    return true;
                if (missingFileNames.has(path))
                    return false;
                // Before falling back to the host
                return host.fileExists(f);
            },
            realpath: host.realpath?.bind(host),
            useCaseSensitiveFileNames: () => host.useCaseSensitiveFileNames(),
            getBuildInfo: () => program.getBuildInfo?.(),
            getSourceFileFromReference: (file, ref) => program.getSourceFileFromReference(file, ref),
            redirectTargetsMap,
            getFileIncludeReasons: program.getFileIncludeReasons,
            createHash: host.createHash?.bind(host),
            getModuleResolutionCache: () => program.getModuleResolutionCache(),
            trace: host.trace?.bind(host),
            getGlobalTypingsCacheLocation: program.getGlobalTypingsCacheLocation,
        };
    }
    function writeFile(fileName, text, writeByteOrderMark, onError, sourceFiles, data) {
        host.writeFile(fileName, text, writeByteOrderMark, onError, sourceFiles, data);
    }
    function emitBuildInfo(writeFileCallback) {
        ts_js_1.tracing?.push("emit" /* tracing.Phase.Emit */, "emitBuildInfo", {}, /*separateBeginAndEnd*/ true);
        performance.mark("beforeEmit");
        const emitResult = (0, ts_js_1.emitFiles)(ts_js_1.notImplementedResolver, getEmitHost(writeFileCallback), 
        /*targetSourceFile*/ undefined, 
        /*transformers*/ ts_js_1.noTransformers, 
        /*emitOnly*/ false, 
        /*onlyBuildInfo*/ true);
        performance.mark("afterEmit");
        performance.measure("Emit", "beforeEmit", "afterEmit");
        ts_js_1.tracing?.pop();
        return emitResult;
    }
    function getResolvedProjectReferences() {
        return resolvedProjectReferences;
    }
    function getProjectReferences() {
        return projectReferences;
    }
    function isSourceFileFromExternalLibrary(file) {
        return !!sourceFilesFoundSearchingNodeModules.get(file.path);
    }
    function isSourceFileDefaultLibrary(file) {
        return libFiles.has(file.path);
    }
    function getTypeChecker() {
        return typeChecker || (typeChecker = (0, ts_js_1.createTypeChecker)(program));
    }
    function emit(sourceFile, writeFileCallback, cancellationToken, emitOnly, transformers, forceDtsEmit, skipBuildInfo) {
        ts_js_1.tracing?.push("emit" /* tracing.Phase.Emit */, "emit", { path: sourceFile?.path }, /*separateBeginAndEnd*/ true);
        const result = runWithCancellationToken(() => emitWorker(program, sourceFile, writeFileCallback, cancellationToken, emitOnly, transformers, forceDtsEmit, skipBuildInfo));
        ts_js_1.tracing?.pop();
        return result;
    }
    function isEmitBlocked(emitFileName) {
        return hasEmitBlockingDiagnostics.has(toPath(emitFileName));
    }
    function emitWorker(program, sourceFile, writeFileCallback, cancellationToken, emitOnly, customTransformers, forceDtsEmit, skipBuildInfo) {
        if (!forceDtsEmit) {
            const result = handleNoEmitOptions(program, sourceFile, writeFileCallback, cancellationToken);
            if (result)
                return result;
        }
        // Create the emit resolver outside of the "emitTime" tracking code below.  That way
        // any cost associated with it (like type checking) are appropriate associated with
        // the type-checking counter.
        //
        // If the -out option is specified, we should not pass the source file to getEmitResolver.
        // This is because in the -out scenario all files need to be emitted, and therefore all
        // files need to be type checked. And the way to specify that all files need to be type
        // checked is to not pass the file to getEmitResolver.
        const typeChecker = getTypeChecker();
        const emitResolver = typeChecker.getEmitResolver(options.outFile ? undefined : sourceFile, cancellationToken, (0, ts_js_1.emitResolverSkipsTypeChecking)(emitOnly, forceDtsEmit));
        performance.mark("beforeEmit");
        const emitResult = typeChecker.runWithCancellationToken(cancellationToken, () => (0, ts_js_1.emitFiles)(emitResolver, getEmitHost(writeFileCallback), sourceFile, (0, ts_js_1.getTransformers)(options, customTransformers, emitOnly), emitOnly, 
        /*onlyBuildInfo*/ false, forceDtsEmit, skipBuildInfo));
        performance.mark("afterEmit");
        performance.measure("Emit", "beforeEmit", "afterEmit");
        return emitResult;
    }
    function getSourceFile(fileName) {
        return getSourceFileByPath(toPath(fileName));
    }
    function getSourceFileByPath(path) {
        return filesByName.get(path) || undefined;
    }
    function getDiagnosticsHelper(sourceFile, getDiagnostics, cancellationToken) {
        if (sourceFile) {
            return (0, ts_js_1.sortAndDeduplicateDiagnostics)(getDiagnostics(sourceFile, cancellationToken));
        }
        return (0, ts_js_1.sortAndDeduplicateDiagnostics)((0, ts_js_1.flatMap)(program.getSourceFiles(), sourceFile => {
            if (cancellationToken) {
                cancellationToken.throwIfCancellationRequested();
            }
            return getDiagnostics(sourceFile, cancellationToken);
        }));
    }
    function getSyntacticDiagnostics(sourceFile, cancellationToken) {
        return getDiagnosticsHelper(sourceFile, getSyntacticDiagnosticsForFile, cancellationToken);
    }
    function getSemanticDiagnostics(sourceFile, cancellationToken, nodesToCheck) {
        return getDiagnosticsHelper(sourceFile, (sourceFile, cancellationToken) => getSemanticDiagnosticsForFile(sourceFile, cancellationToken, nodesToCheck), cancellationToken);
    }
    function getCachedSemanticDiagnostics(sourceFile) {
        return cachedBindAndCheckDiagnosticsForFile?.get(sourceFile.path);
    }
    function getBindAndCheckDiagnostics(sourceFile, cancellationToken) {
        return getBindAndCheckDiagnosticsForFile(sourceFile, cancellationToken, /*nodesToCheck*/ undefined);
    }
    function getProgramDiagnostics(sourceFile) {
        if ((0, ts_js_1.skipTypeChecking)(sourceFile, options, program)) {
            return ts_js_1.emptyArray;
        }
        const programDiagnosticsInFile = programDiagnostics.getCombinedDiagnostics(program).getDiagnostics(sourceFile.fileName);
        if (!sourceFile.commentDirectives?.length) {
            return programDiagnosticsInFile;
        }
        return getDiagnosticsWithPrecedingDirectives(sourceFile, sourceFile.commentDirectives, programDiagnosticsInFile).diagnostics;
    }
    function getDeclarationDiagnostics(sourceFile, cancellationToken) {
        return getDiagnosticsHelper(sourceFile, getDeclarationDiagnosticsForFile, cancellationToken);
    }
    function getSyntacticDiagnosticsForFile(sourceFile) {
        // For JavaScript files, we report semantic errors for using TypeScript-only
        // constructs from within a JavaScript file as syntactic errors.
        if ((0, ts_js_1.isSourceFileJS)(sourceFile)) {
            if (!sourceFile.additionalSyntacticDiagnostics) {
                sourceFile.additionalSyntacticDiagnostics = getJSSyntacticDiagnosticsForFile(sourceFile);
            }
            return (0, ts_js_1.concatenate)(sourceFile.additionalSyntacticDiagnostics, sourceFile.parseDiagnostics);
        }
        return sourceFile.parseDiagnostics;
    }
    function runWithCancellationToken(func) {
        try {
            return func();
        }
        catch (e) {
            if (e instanceof ts_js_1.OperationCanceledException) {
                // We were canceled while performing the operation.  Because our type checker
                // might be a bad state, we need to throw it away.
                typeChecker = undefined;
            }
            throw e;
        }
    }
    function getSemanticDiagnosticsForFile(sourceFile, cancellationToken, nodesToCheck) {
        return (0, ts_js_1.concatenate)(filterSemanticDiagnostics(getBindAndCheckDiagnosticsForFile(sourceFile, cancellationToken, nodesToCheck), options), getProgramDiagnostics(sourceFile));
    }
    function getBindAndCheckDiagnosticsForFile(sourceFile, cancellationToken, nodesToCheck) {
        if (nodesToCheck) {
            return getBindAndCheckDiagnosticsForFileNoCache(sourceFile, cancellationToken, nodesToCheck);
        }
        let result = cachedBindAndCheckDiagnosticsForFile?.get(sourceFile.path);
        if (!result) {
            (cachedBindAndCheckDiagnosticsForFile ?? (cachedBindAndCheckDiagnosticsForFile = new Map())).set(sourceFile.path, result = getBindAndCheckDiagnosticsForFileNoCache(sourceFile, cancellationToken));
        }
        return result;
    }
    function getBindAndCheckDiagnosticsForFileNoCache(sourceFile, cancellationToken, nodesToCheck) {
        return runWithCancellationToken(() => {
            if ((0, ts_js_1.skipTypeChecking)(sourceFile, options, program)) {
                return ts_js_1.emptyArray;
            }
            const typeChecker = getTypeChecker();
            ts_js_1.Debug.assert(!!sourceFile.bindDiagnostics);
            const isJs = sourceFile.scriptKind === 1 /* ScriptKind.JS */ || sourceFile.scriptKind === 2 /* ScriptKind.JSX */;
            const isPlainJs = (0, ts_js_1.isPlainJsFile)(sourceFile, options.checkJs);
            const isCheckJs = isJs && (0, ts_js_1.isCheckJsEnabledForFile)(sourceFile, options);
            let bindDiagnostics = sourceFile.bindDiagnostics;
            let checkDiagnostics = typeChecker.getDiagnostics(sourceFile, cancellationToken, nodesToCheck);
            if (isPlainJs) {
                bindDiagnostics = (0, ts_js_1.filter)(bindDiagnostics, d => plainJSErrors.has(d.code));
                checkDiagnostics = (0, ts_js_1.filter)(checkDiagnostics, d => plainJSErrors.has(d.code));
            }
            // skip ts-expect-error errors in plain JS files, and skip JSDoc errors except in checked JS
            return getMergedBindAndCheckDiagnostics(sourceFile, !isPlainJs, !!nodesToCheck, bindDiagnostics, checkDiagnostics, isCheckJs ? sourceFile.jsDocDiagnostics : undefined);
        });
    }
    function getMergedBindAndCheckDiagnostics(sourceFile, includeBindAndCheckDiagnostics, partialCheck, ...allDiagnostics) {
        const flatDiagnostics = (0, ts_js_1.flatten)(allDiagnostics);
        if (!includeBindAndCheckDiagnostics || !sourceFile.commentDirectives?.length) {
            return flatDiagnostics;
        }
        const { diagnostics, directives } = getDiagnosticsWithPrecedingDirectives(sourceFile, sourceFile.commentDirectives, flatDiagnostics);
        // When doing a partial check, we can't be sure a directive is unused.
        if (partialCheck) {
            return diagnostics;
        }
        for (const errorExpectation of directives.getUnusedExpectations()) {
            diagnostics.push((0, ts_js_1.createDiagnosticForRange)(sourceFile, errorExpectation.range, ts_js_1.Diagnostics.Unused_ts_expect_error_directive));
        }
        return diagnostics;
    }
    /**
     * Creates a map of comment directives along with the diagnostics immediately preceded by one of them.
     * Comments that match to any of those diagnostics are marked as used.
     */
    function getDiagnosticsWithPrecedingDirectives(sourceFile, commentDirectives, flatDiagnostics) {
        // Diagnostics are only reported if there is no comment directive preceding them
        // This will modify the directives map by marking "used" ones with a corresponding diagnostic
        const directives = (0, ts_js_1.createCommentDirectivesMap)(sourceFile, commentDirectives);
        const diagnostics = flatDiagnostics.filter(diagnostic => markPrecedingCommentDirectiveLine(diagnostic, directives) === -1);
        return { diagnostics, directives };
    }
    function getSuggestionDiagnostics(sourceFile, cancellationToken) {
        return runWithCancellationToken(() => {
            return getTypeChecker().getSuggestionDiagnostics(sourceFile, cancellationToken);
        });
    }
    /**
     * @returns The line index marked as preceding the diagnostic, or -1 if none was.
     */
    function markPrecedingCommentDirectiveLine(diagnostic, directives) {
        const { file, start } = diagnostic;
        if (!file) {
            return -1;
        }
        // Start out with the line just before the text
        const lineStarts = (0, ts_js_1.getLineStarts)(file);
        let line = (0, ts_js_1.computeLineAndCharacterOfPosition)(lineStarts, start).line - 1; // TODO: GH#18217
        while (line >= 0) {
            // As soon as that line is known to have a comment directive, use that
            if (directives.markUsed(line)) {
                return line;
            }
            // Stop searching if the line is not empty and not a comment
            const lineText = file.text.slice(lineStarts[line], lineStarts[line + 1]).trim();
            if (lineText !== "" && !/^\s*\/\/.*$/.test(lineText)) {
                return -1;
            }
            line--;
        }
        return -1;
    }
    function getJSSyntacticDiagnosticsForFile(sourceFile) {
        return runWithCancellationToken(() => {
            const diagnostics = [];
            walk(sourceFile, sourceFile);
            (0, ts_js_1.forEachChildRecursively)(sourceFile, walk, walkArray);
            return diagnostics;
            function walk(node, parent) {
                // Return directly from the case if the given node doesnt want to visit each child
                // Otherwise break to visit each child
                switch (parent.kind) {
                    case 170 /* SyntaxKind.Parameter */:
                    case 173 /* SyntaxKind.PropertyDeclaration */:
                    case 175 /* SyntaxKind.MethodDeclaration */:
                        if (parent.questionToken === node) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.The_0_modifier_can_only_be_used_in_TypeScript_files, "?"));
                            return "skip";
                        }
                    // falls through
                    case 174 /* SyntaxKind.MethodSignature */:
                    case 177 /* SyntaxKind.Constructor */:
                    case 178 /* SyntaxKind.GetAccessor */:
                    case 179 /* SyntaxKind.SetAccessor */:
                    case 219 /* SyntaxKind.FunctionExpression */:
                    case 263 /* SyntaxKind.FunctionDeclaration */:
                    case 220 /* SyntaxKind.ArrowFunction */:
                    case 261 /* SyntaxKind.VariableDeclaration */:
                        // type annotation
                        if (parent.type === node) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.Type_annotations_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                }
                switch (node.kind) {
                    case 274 /* SyntaxKind.ImportClause */:
                        if (node.isTypeOnly) {
                            diagnostics.push(createDiagnosticForNode(parent, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, "import type"));
                            return "skip";
                        }
                        break;
                    case 279 /* SyntaxKind.ExportDeclaration */:
                        if (node.isTypeOnly) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, "export type"));
                            return "skip";
                        }
                        break;
                    case 277 /* SyntaxKind.ImportSpecifier */:
                    case 282 /* SyntaxKind.ExportSpecifier */:
                        if (node.isTypeOnly) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, (0, ts_js_1.isImportSpecifier)(node) ? "import...type" : "export...type"));
                            return "skip";
                        }
                        break;
                    case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.import_can_only_be_used_in_TypeScript_files));
                        return "skip";
                    case 278 /* SyntaxKind.ExportAssignment */:
                        if (node.isExportEquals) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.export_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                        break;
                    case 299 /* SyntaxKind.HeritageClause */:
                        const heritageClause = node;
                        if (heritageClause.token === 119 /* SyntaxKind.ImplementsKeyword */) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.implements_clauses_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                        break;
                    case 265 /* SyntaxKind.InterfaceDeclaration */:
                        const interfaceKeyword = (0, ts_js_1.tokenToString)(120 /* SyntaxKind.InterfaceKeyword */);
                        ts_js_1.Debug.assertIsDefined(interfaceKeyword);
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, interfaceKeyword));
                        return "skip";
                    case 268 /* SyntaxKind.ModuleDeclaration */:
                        const moduleKeyword = node.flags & 32 /* NodeFlags.Namespace */ ? (0, ts_js_1.tokenToString)(145 /* SyntaxKind.NamespaceKeyword */) : (0, ts_js_1.tokenToString)(144 /* SyntaxKind.ModuleKeyword */);
                        ts_js_1.Debug.assertIsDefined(moduleKeyword);
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, moduleKeyword));
                        return "skip";
                    case 266 /* SyntaxKind.TypeAliasDeclaration */:
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.Type_aliases_can_only_be_used_in_TypeScript_files));
                        return "skip";
                    case 177 /* SyntaxKind.Constructor */:
                    case 175 /* SyntaxKind.MethodDeclaration */:
                    case 263 /* SyntaxKind.FunctionDeclaration */:
                        if (!node.body) {
                            diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.Signature_declarations_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                        return;
                    case 267 /* SyntaxKind.EnumDeclaration */:
                        const enumKeyword = ts_js_1.Debug.checkDefined((0, ts_js_1.tokenToString)(94 /* SyntaxKind.EnumKeyword */));
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics._0_declarations_can_only_be_used_in_TypeScript_files, enumKeyword));
                        return "skip";
                    case 236 /* SyntaxKind.NonNullExpression */:
                        diagnostics.push(createDiagnosticForNode(node, ts_js_1.Diagnostics.Non_null_assertions_can_only_be_used_in_TypeScript_files));
                        return "skip";
                    case 235 /* SyntaxKind.AsExpression */:
                        diagnostics.push(createDiagnosticForNode(node.type, ts_js_1.Diagnostics.Type_assertion_expressions_can_only_be_used_in_TypeScript_files));
                        return "skip";
                    case 239 /* SyntaxKind.SatisfiesExpression */:
                        diagnostics.push(createDiagnosticForNode(node.type, ts_js_1.Diagnostics.Type_satisfaction_expressions_can_only_be_used_in_TypeScript_files));
                        return "skip";
                    case 217 /* SyntaxKind.TypeAssertionExpression */:
                        ts_js_1.Debug.fail(); // Won't parse these in a JS file anyway, as they are interpreted as JSX.
                }
            }
            function walkArray(nodes, parent) {
                if ((0, ts_js_1.canHaveIllegalDecorators)(parent)) {
                    const decorator = (0, ts_js_1.find)(parent.modifiers, ts_js_1.isDecorator);
                    if (decorator) {
                        // report illegal decorator
                        diagnostics.push(createDiagnosticForNode(decorator, ts_js_1.Diagnostics.Decorators_are_not_valid_here));
                    }
                }
                else if ((0, ts_js_1.canHaveDecorators)(parent) && parent.modifiers) {
                    const decoratorIndex = (0, ts_js_1.findIndex)(parent.modifiers, ts_js_1.isDecorator);
                    if (decoratorIndex >= 0) {
                        if ((0, ts_js_1.isParameter)(parent) && !options.experimentalDecorators) {
                            // report illegall decorator on parameter
                            diagnostics.push(createDiagnosticForNode(parent.modifiers[decoratorIndex], ts_js_1.Diagnostics.Decorators_are_not_valid_here));
                        }
                        else if ((0, ts_js_1.isClassDeclaration)(parent)) {
                            const exportIndex = (0, ts_js_1.findIndex)(parent.modifiers, ts_js_1.isExportModifier);
                            if (exportIndex >= 0) {
                                const defaultIndex = (0, ts_js_1.findIndex)(parent.modifiers, ts_js_1.isDefaultModifier);
                                if (decoratorIndex > exportIndex && defaultIndex >= 0 && decoratorIndex < defaultIndex) {
                                    // report illegal decorator between `export` and `default`
                                    diagnostics.push(createDiagnosticForNode(parent.modifiers[decoratorIndex], ts_js_1.Diagnostics.Decorators_are_not_valid_here));
                                }
                                else if (exportIndex >= 0 && decoratorIndex < exportIndex) {
                                    const trailingDecoratorIndex = (0, ts_js_1.findIndex)(parent.modifiers, ts_js_1.isDecorator, exportIndex);
                                    if (trailingDecoratorIndex >= 0) {
                                        diagnostics.push((0, ts_js_1.addRelatedInfo)(createDiagnosticForNode(parent.modifiers[trailingDecoratorIndex], ts_js_1.Diagnostics.Decorators_may_not_appear_after_export_or_export_default_if_they_also_appear_before_export), createDiagnosticForNode(parent.modifiers[decoratorIndex], ts_js_1.Diagnostics.Decorator_used_before_export_here)));
                                    }
                                }
                            }
                        }
                    }
                }
                switch (parent.kind) {
                    case 264 /* SyntaxKind.ClassDeclaration */:
                    case 232 /* SyntaxKind.ClassExpression */:
                    case 175 /* SyntaxKind.MethodDeclaration */:
                    case 177 /* SyntaxKind.Constructor */:
                    case 178 /* SyntaxKind.GetAccessor */:
                    case 179 /* SyntaxKind.SetAccessor */:
                    case 219 /* SyntaxKind.FunctionExpression */:
                    case 263 /* SyntaxKind.FunctionDeclaration */:
                    case 220 /* SyntaxKind.ArrowFunction */:
                        // Check type parameters
                        if (nodes === parent.typeParameters) {
                            diagnostics.push(createDiagnosticForNodeArray(nodes, ts_js_1.Diagnostics.Type_parameter_declarations_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                    // falls through
                    case 244 /* SyntaxKind.VariableStatement */:
                        // Check modifiers
                        if (nodes === parent.modifiers) {
                            checkModifiers(parent.modifiers, parent.kind === 244 /* SyntaxKind.VariableStatement */);
                            return "skip";
                        }
                        break;
                    case 173 /* SyntaxKind.PropertyDeclaration */:
                        // Check modifiers of property declaration
                        if (nodes === parent.modifiers) {
                            for (const modifier of nodes) {
                                if ((0, ts_js_1.isModifier)(modifier)
                                    && modifier.kind !== 126 /* SyntaxKind.StaticKeyword */
                                    && modifier.kind !== 129 /* SyntaxKind.AccessorKeyword */) {
                                    diagnostics.push(createDiagnosticForNode(modifier, ts_js_1.Diagnostics.The_0_modifier_can_only_be_used_in_TypeScript_files, (0, ts_js_1.tokenToString)(modifier.kind)));
                                }
                            }
                            return "skip";
                        }
                        break;
                    case 170 /* SyntaxKind.Parameter */:
                        // Check modifiers of parameter declaration
                        if (nodes === parent.modifiers && (0, ts_js_1.some)(nodes, ts_js_1.isModifier)) {
                            diagnostics.push(createDiagnosticForNodeArray(nodes, ts_js_1.Diagnostics.Parameter_modifiers_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                        break;
                    case 214 /* SyntaxKind.CallExpression */:
                    case 215 /* SyntaxKind.NewExpression */:
                    case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
                    case 286 /* SyntaxKind.JsxSelfClosingElement */:
                    case 287 /* SyntaxKind.JsxOpeningElement */:
                    case 216 /* SyntaxKind.TaggedTemplateExpression */:
                        // Check type arguments
                        if (nodes === parent.typeArguments) {
                            diagnostics.push(createDiagnosticForNodeArray(nodes, ts_js_1.Diagnostics.Type_arguments_can_only_be_used_in_TypeScript_files));
                            return "skip";
                        }
                        break;
                }
            }
            function checkModifiers(modifiers, isConstValid) {
                for (const modifier of modifiers) {
                    switch (modifier.kind) {
                        case 87 /* SyntaxKind.ConstKeyword */:
                            if (isConstValid) {
                                continue;
                            }
                        // to report error,
                        // falls through
                        case 125 /* SyntaxKind.PublicKeyword */:
                        case 123 /* SyntaxKind.PrivateKeyword */:
                        case 124 /* SyntaxKind.ProtectedKeyword */:
                        case 148 /* SyntaxKind.ReadonlyKeyword */:
                        case 138 /* SyntaxKind.DeclareKeyword */:
                        case 128 /* SyntaxKind.AbstractKeyword */:
                        case 164 /* SyntaxKind.OverrideKeyword */:
                        case 103 /* SyntaxKind.InKeyword */:
                        case 147 /* SyntaxKind.OutKeyword */:
                            diagnostics.push(createDiagnosticForNode(modifier, ts_js_1.Diagnostics.The_0_modifier_can_only_be_used_in_TypeScript_files, (0, ts_js_1.tokenToString)(modifier.kind)));
                            break;
                        // These are all legal modifiers.
                        case 126 /* SyntaxKind.StaticKeyword */:
                        case 95 /* SyntaxKind.ExportKeyword */:
                        case 90 /* SyntaxKind.DefaultKeyword */:
                        case 129 /* SyntaxKind.AccessorKeyword */:
                    }
                }
            }
            function createDiagnosticForNodeArray(nodes, message, ...args) {
                const start = nodes.pos;
                return (0, ts_js_1.createFileDiagnostic)(sourceFile, start, nodes.end - start, message, ...args);
            }
            // Since these are syntactic diagnostics, parent might not have been set
            // this means the sourceFile cannot be infered from the node
            function createDiagnosticForNode(node, message, ...args) {
                return (0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile, node, message, ...args);
            }
        });
    }
    function getDeclarationDiagnosticsWorker(sourceFile, cancellationToken) {
        let result = cachedDeclarationDiagnosticsForFile?.get(sourceFile.path);
        if (!result) {
            (cachedDeclarationDiagnosticsForFile ?? (cachedDeclarationDiagnosticsForFile = new Map())).set(sourceFile.path, result = getDeclarationDiagnosticsForFileNoCache(sourceFile, cancellationToken));
        }
        return result;
    }
    function getDeclarationDiagnosticsForFileNoCache(sourceFile, cancellationToken) {
        return runWithCancellationToken(() => {
            const resolver = getTypeChecker().getEmitResolver(sourceFile, cancellationToken);
            // Don't actually write any files since we're just getting diagnostics.
            return (0, ts_js_1.getDeclarationDiagnostics)(getEmitHost(ts_js_1.noop), resolver, sourceFile) || ts_js_1.emptyArray;
        });
    }
    function getDeclarationDiagnosticsForFile(sourceFile, cancellationToken) {
        return sourceFile.isDeclarationFile ? ts_js_1.emptyArray : getDeclarationDiagnosticsWorker(sourceFile, cancellationToken);
    }
    function getOptionsDiagnostics() {
        return (0, ts_js_1.sortAndDeduplicateDiagnostics)((0, ts_js_1.concatenate)(programDiagnostics.getCombinedDiagnostics(program).getGlobalDiagnostics(), getOptionsDiagnosticsOfConfigFile()));
    }
    function getOptionsDiagnosticsOfConfigFile() {
        if (!options.configFile)
            return ts_js_1.emptyArray;
        let diagnostics = programDiagnostics.getCombinedDiagnostics(program).getDiagnostics(options.configFile.fileName);
        forEachResolvedProjectReference(resolvedRef => {
            diagnostics = (0, ts_js_1.concatenate)(diagnostics, programDiagnostics.getCombinedDiagnostics(program).getDiagnostics(resolvedRef.sourceFile.fileName));
        });
        return diagnostics;
    }
    function getGlobalDiagnostics() {
        return rootNames.length ? (0, ts_js_1.sortAndDeduplicateDiagnostics)(getTypeChecker().getGlobalDiagnostics().slice()) : ts_js_1.emptyArray;
    }
    function getConfigFileParsingDiagnostics() {
        return configFileParsingDiagnostics || ts_js_1.emptyArray;
    }
    function processRootFile(fileName, isDefaultLib, reason) {
        processSourceFile((0, ts_js_1.normalizePath)(fileName), isDefaultLib, /*packageId*/ undefined, reason);
    }
    function fileReferenceIsEqualTo(a, b) {
        return a.fileName === b.fileName;
    }
    function moduleNameIsEqualTo(a, b) {
        return a.kind === 80 /* SyntaxKind.Identifier */
            ? b.kind === 80 /* SyntaxKind.Identifier */ && a.escapedText === b.escapedText
            : b.kind === 11 /* SyntaxKind.StringLiteral */ && a.text === b.text;
    }
    function createSyntheticImport(text, file) {
        const externalHelpersModuleReference = ts_js_1.factory.createStringLiteral(text);
        const importDecl = ts_js_1.factory.createImportDeclaration(/*modifiers*/ undefined, /*importClause*/ undefined, externalHelpersModuleReference);
        (0, ts_js_1.addInternalEmitFlags)(importDecl, 2 /* InternalEmitFlags.NeverApplyImportHelper */);
        (0, ts_js_1.setParent)(externalHelpersModuleReference, importDecl);
        (0, ts_js_1.setParent)(importDecl, file);
        // explicitly unset the synthesized flag on these declarations so the checker API will answer questions about them
        // (which is required to build the dependency graph for incremental emit)
        externalHelpersModuleReference.flags &= ~16 /* NodeFlags.Synthesized */;
        importDecl.flags &= ~16 /* NodeFlags.Synthesized */;
        return externalHelpersModuleReference;
    }
    function collectExternalModuleReferences(file) {
        if (file.imports) {
            return;
        }
        const isJavaScriptFile = (0, ts_js_1.isSourceFileJS)(file);
        const isExternalModuleFile = (0, ts_js_1.isExternalModule)(file);
        // file.imports may not be undefined if there exists dynamic import
        let imports;
        let moduleAugmentations;
        let ambientModules;
        // If we are importing helpers, we need to add a synthetic reference to resolve the
        // helpers library. (A JavaScript file without `externalModuleIndicator` set might be
        // a CommonJS module; `commonJsModuleIndicator` doesn't get set until the binder has
        // run. We synthesize a helpers import for it just in case; it will never be used if
        // the binder doesn't find and set a `commonJsModuleIndicator`.)
        if (isJavaScriptFile || (!file.isDeclarationFile && ((0, ts_js_1.getIsolatedModules)(options) || (0, ts_js_1.isExternalModule)(file)))) {
            if (options.importHelpers) {
                // synthesize 'import "tslib"' declaration
                imports = [createSyntheticImport(ts_js_1.externalHelpersModuleNameText, file)];
            }
            const jsxImport = (0, ts_js_1.getJSXRuntimeImport)((0, ts_js_1.getJSXImplicitImportBase)(options, file), options);
            if (jsxImport) {
                // synthesize `import "base/jsx-runtime"` declaration
                (imports || (imports = [])).push(createSyntheticImport(jsxImport, file));
            }
        }
        for (const node of file.statements) {
            collectModuleReferences(node, /*inAmbientModule*/ false);
        }
        if ((file.flags & 4194304 /* NodeFlags.PossiblyContainsDynamicImport */) || isJavaScriptFile) {
            (0, ts_js_1.forEachDynamicImportOrRequireCall)(file, /*includeTypeSpaceImports*/ true, /*requireStringLiteralLikeArgument*/ true, (node, moduleSpecifier) => {
                (0, ts_js_1.setParentRecursive)(node, /*incremental*/ false); // we need parent data on imports before the program is fully bound, so we ensure it's set here
                imports = (0, ts_js_1.append)(imports, moduleSpecifier);
            });
        }
        file.imports = imports || ts_js_1.emptyArray;
        file.moduleAugmentations = moduleAugmentations || ts_js_1.emptyArray;
        file.ambientModuleNames = ambientModules || ts_js_1.emptyArray;
        return;
        function collectModuleReferences(node, inAmbientModule) {
            if ((0, ts_js_1.isAnyImportOrReExport)(node)) {
                const moduleNameExpr = (0, ts_js_1.getExternalModuleName)(node);
                // TypeScript 1.0 spec (April 2014): 12.1.6
                // An ExternalImportDeclaration in an AmbientExternalModuleDeclaration may reference other external modules
                // only through top - level external module names. Relative external module names are not permitted.
                if (moduleNameExpr && (0, ts_js_1.isStringLiteral)(moduleNameExpr) && moduleNameExpr.text && (!inAmbientModule || !(0, ts_js_1.isExternalModuleNameRelative)(moduleNameExpr.text))) {
                    (0, ts_js_1.setParentRecursive)(node, /*incremental*/ false); // we need parent data on imports before the program is fully bound, so we ensure it's set here
                    imports = (0, ts_js_1.append)(imports, moduleNameExpr);
                    if (!usesUriStyleNodeCoreModules && currentNodeModulesDepth === 0 && !file.isDeclarationFile) {
                        if ((0, ts_js_1.startsWith)(moduleNameExpr.text, "node:") && !ts_js_1.exclusivelyPrefixedNodeCoreModules.has(moduleNameExpr.text)) {
                            // Presence of `node:` prefix takes precedence over unprefixed node core modules
                            usesUriStyleNodeCoreModules = true;
                        }
                        else if (usesUriStyleNodeCoreModules === undefined && ts_js_1.unprefixedNodeCoreModules.has(moduleNameExpr.text)) {
                            // Avoid `unprefixedNodeCoreModules.has` for every import
                            usesUriStyleNodeCoreModules = false;
                        }
                    }
                }
            }
            else if ((0, ts_js_1.isModuleDeclaration)(node)) {
                if ((0, ts_js_1.isAmbientModule)(node) && (inAmbientModule || (0, ts_js_1.hasSyntacticModifier)(node, 128 /* ModifierFlags.Ambient */) || file.isDeclarationFile)) {
                    node.name.parent = node;
                    const nameText = (0, ts_js_1.getTextOfIdentifierOrLiteral)(node.name);
                    // Ambient module declarations can be interpreted as augmentations for some existing external modules.
                    // This will happen in two cases:
                    // - if current file is external module then module augmentation is a ambient module declaration defined in the top level scope
                    // - if current file is not external module then module augmentation is an ambient module declaration with non-relative module name
                    //   immediately nested in top level ambient module declaration .
                    if (isExternalModuleFile || (inAmbientModule && !(0, ts_js_1.isExternalModuleNameRelative)(nameText))) {
                        (moduleAugmentations || (moduleAugmentations = [])).push(node.name);
                    }
                    else if (!inAmbientModule) {
                        if (file.isDeclarationFile) {
                            // for global .d.ts files record name of ambient module
                            (ambientModules || (ambientModules = [])).push(nameText);
                        }
                        // An AmbientExternalModuleDeclaration declares an external module.
                        // This type of declaration is permitted only in the global module.
                        // The StringLiteral must specify a top - level external module name.
                        // Relative external module names are not permitted
                        // NOTE: body of ambient module is always a module block, if it exists
                        const body = node.body;
                        if (body) {
                            for (const statement of body.statements) {
                                collectModuleReferences(statement, /*inAmbientModule*/ true);
                            }
                        }
                    }
                }
            }
        }
    }
    function getLibFileFromReference(ref) {
        const libFileName = (0, ts_js_1.getLibFileNameFromLibReference)(ref);
        const actualFileName = libFileName && resolvedLibReferences?.get(libFileName)?.actual;
        return actualFileName !== undefined ? getSourceFile(actualFileName) : undefined;
    }
    /** This should have similar behavior to 'processSourceFile' without diagnostics or mutation. */
    function getSourceFileFromReference(referencingFile, ref) {
        return getSourceFileFromReferenceWorker(resolveTripleslashReference(ref.fileName, referencingFile.fileName), getSourceFile);
    }
    function getSourceFileFromReferenceWorker(fileName, getSourceFile, fail, reason) {
        if ((0, ts_js_1.hasExtension)(fileName)) {
            const canonicalFileName = host.getCanonicalFileName(fileName);
            if (!options.allowNonTsExtensions && !(0, ts_js_1.forEach)((0, ts_js_1.flatten)(supportedExtensionsWithJsonIfResolveJsonModule), extension => (0, ts_js_1.fileExtensionIs)(canonicalFileName, extension))) {
                if (fail) {
                    if ((0, ts_js_1.hasJSFileExtension)(canonicalFileName)) {
                        fail(ts_js_1.Diagnostics.File_0_is_a_JavaScript_file_Did_you_mean_to_enable_the_allowJs_option, fileName);
                    }
                    else {
                        fail(ts_js_1.Diagnostics.File_0_has_an_unsupported_extension_The_only_supported_extensions_are_1, fileName, "'" + (0, ts_js_1.flatten)(supportedExtensions).join("', '") + "'");
                    }
                }
                return undefined;
            }
            const sourceFile = getSourceFile(fileName);
            if (fail) {
                if (!sourceFile) {
                    const redirect = getRedirectFromSourceFile(fileName);
                    if (redirect?.outputDts) {
                        fail(ts_js_1.Diagnostics.Output_file_0_has_not_been_built_from_source_file_1, redirect.outputDts, fileName);
                    }
                    else {
                        fail(ts_js_1.Diagnostics.File_0_not_found, fileName);
                    }
                }
                else if (isReferencedFile(reason) && canonicalFileName === host.getCanonicalFileName(getSourceFileByPath(reason.file).fileName)) {
                    fail(ts_js_1.Diagnostics.A_file_cannot_have_a_reference_to_itself);
                }
            }
            return sourceFile;
        }
        else {
            const sourceFileNoExtension = options.allowNonTsExtensions && getSourceFile(fileName);
            if (sourceFileNoExtension)
                return sourceFileNoExtension;
            if (fail && options.allowNonTsExtensions) {
                fail(ts_js_1.Diagnostics.File_0_not_found, fileName);
                return undefined;
            }
            // Only try adding extensions from the first supported group (which should be .ts/.tsx/.d.ts)
            const sourceFileWithAddedExtension = (0, ts_js_1.forEach)(supportedExtensions[0], extension => getSourceFile(fileName + extension));
            if (fail && !sourceFileWithAddedExtension)
                fail(ts_js_1.Diagnostics.Could_not_resolve_the_path_0_with_the_extensions_Colon_1, fileName, "'" + (0, ts_js_1.flatten)(supportedExtensions).join("', '") + "'");
            return sourceFileWithAddedExtension;
        }
    }
    /** This has side effects through `findSourceFile`. */
    function processSourceFile(fileName, isDefaultLib, packageId, reason) {
        getSourceFileFromReferenceWorker(fileName, fileName => findSourceFile(fileName, isDefaultLib, reason, packageId), // TODO: GH#18217
        (diagnostic, ...args) => addFilePreprocessingFileExplainingDiagnostic(/*file*/ undefined, reason, diagnostic, args), reason);
    }
    function processProjectReferenceFile(fileName, reason) {
        return processSourceFile(fileName, /*isDefaultLib*/ false, /*packageId*/ undefined, reason);
    }
    function reportFileNamesDifferOnlyInCasingError(fileName, existingFile, reason) {
        const hasExistingReasonToReportErrorOn = !isReferencedFile(reason) && (0, ts_js_1.some)(programDiagnostics.getFileReasons().get(existingFile.path), isReferencedFile);
        if (hasExistingReasonToReportErrorOn) {
            addFilePreprocessingFileExplainingDiagnostic(existingFile, reason, ts_js_1.Diagnostics.Already_included_file_name_0_differs_from_file_name_1_only_in_casing, [existingFile.fileName, fileName]);
        }
        else {
            addFilePreprocessingFileExplainingDiagnostic(existingFile, reason, ts_js_1.Diagnostics.File_name_0_differs_from_already_included_file_name_1_only_in_casing, [fileName, existingFile.fileName]);
        }
    }
    function createRedirectedSourceFile(redirectTarget, unredirected, fileName, path, resolvedPath, originalFileName, sourceFileOptions) {
        const redirect = ts_js_1.parseNodeFactory.createRedirectedSourceFile({ redirectTarget, unredirected });
        redirect.fileName = fileName;
        redirect.path = path;
        redirect.resolvedPath = resolvedPath;
        redirect.originalFileName = originalFileName;
        redirect.packageJsonLocations = sourceFileOptions.packageJsonLocations?.length ? sourceFileOptions.packageJsonLocations : undefined;
        redirect.packageJsonScope = sourceFileOptions.packageJsonScope;
        sourceFilesFoundSearchingNodeModules.set(path, currentNodeModulesDepth > 0);
        return redirect;
    }
    // Get source file from normalized fileName
    function findSourceFile(fileName, isDefaultLib, reason, packageId) {
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "findSourceFile", {
            fileName,
            isDefaultLib: isDefaultLib || undefined,
            fileIncludeKind: ts_js_1.FileIncludeKind[reason.kind],
        });
        const result = findSourceFileWorker(fileName, isDefaultLib, reason, packageId);
        ts_js_1.tracing?.pop();
        return result;
    }
    function getCreateSourceFileOptions(fileName, moduleResolutionCache, host, options) {
        // It's a _little odd_ that we can't set `impliedNodeFormat` until the program step - but it's the first and only time we have a resolution cache
        // and a freshly made source file node on hand at the same time, and we need both to set the field. Persisting the resolution cache all the way
        // to the check and emit steps would be bad - so we much prefer detecting and storing the format information on the source file node upfront.
        const result = getImpliedNodeFormatForFileWorker((0, ts_js_1.getNormalizedAbsolutePath)(fileName, currentDirectory), moduleResolutionCache?.getPackageJsonInfoCache(), host, options);
        const languageVersion = (0, ts_js_1.getEmitScriptTarget)(options);
        const setExternalModuleIndicator = (0, ts_js_1.getSetExternalModuleIndicator)(options);
        return typeof result === "object" ?
            { ...result, languageVersion, setExternalModuleIndicator, jsDocParsingMode: host.jsDocParsingMode } :
            { languageVersion, impliedNodeFormat: result, setExternalModuleIndicator, jsDocParsingMode: host.jsDocParsingMode };
    }
    function findSourceFileWorker(fileName, isDefaultLib, reason, packageId) {
        const path = toPath(fileName);
        if (useSourceOfProjectReferenceRedirect) {
            let source = getRedirectFromOutput(path);
            // If preserveSymlinks is true, module resolution wont jump the symlink
            // but the resolved real path may be the .d.ts from project reference
            // Note:: Currently we try the real path only if the
            // file is from node_modules to avoid having to run real path on all file paths
            if (!source &&
                host.realpath &&
                options.preserveSymlinks &&
                (0, ts_js_1.isDeclarationFileName)(fileName) &&
                fileName.includes(ts_js_1.nodeModulesPathPart)) {
                const realPath = toPath(host.realpath(fileName));
                if (realPath !== path)
                    source = getRedirectFromOutput(realPath);
            }
            if (source?.source) {
                const file = findSourceFile(source.source, isDefaultLib, reason, packageId);
                if (file)
                    addFileToFilesByName(file, path, fileName, /*redirectedPath*/ undefined);
                return file;
            }
        }
        const originalFileName = fileName;
        if (filesByName.has(path)) {
            const file = filesByName.get(path);
            const addedReason = addFileIncludeReason(file || undefined, reason, /*checkExisting*/ true);
            // try to check if we've already seen this file but with a different casing in path
            // NOTE: this only makes sense for case-insensitive file systems, and only on files which are not redirected
            if (file && addedReason && !(options.forceConsistentCasingInFileNames === false)) {
                const checkedName = file.fileName;
                const isRedirect = toPath(checkedName) !== toPath(fileName);
                if (isRedirect) {
                    fileName = getRedirectFromSourceFile(fileName)?.outputDts || fileName;
                }
                // Check if it differs only in drive letters its ok to ignore that error:
                const checkedAbsolutePath = (0, ts_js_1.getNormalizedAbsolutePathWithoutRoot)(checkedName, currentDirectory);
                const inputAbsolutePath = (0, ts_js_1.getNormalizedAbsolutePathWithoutRoot)(fileName, currentDirectory);
                if (checkedAbsolutePath !== inputAbsolutePath) {
                    reportFileNamesDifferOnlyInCasingError(fileName, file, reason);
                }
            }
            // If the file was previously found via a node_modules search, but is now being processed as a root file,
            // then everything it sucks in may also be marked incorrectly, and needs to be checked again.
            if (file && sourceFilesFoundSearchingNodeModules.get(file.path) && currentNodeModulesDepth === 0) {
                sourceFilesFoundSearchingNodeModules.set(file.path, false);
                if (!options.noResolve) {
                    processReferencedFiles(file, isDefaultLib);
                    processTypeReferenceDirectives(file);
                }
                if (!options.noLib) {
                    processLibReferenceDirectives(file);
                }
                modulesWithElidedImports.set(file.path, false);
                processImportedModules(file);
            }
            // See if we need to reprocess the imports due to prior skipped imports
            else if (file && modulesWithElidedImports.get(file.path)) {
                if (currentNodeModulesDepth < maxNodeModuleJsDepth) {
                    modulesWithElidedImports.set(file.path, false);
                    processImportedModules(file);
                }
            }
            return file || undefined;
        }
        let redirectedPath;
        if (!useSourceOfProjectReferenceRedirect) {
            const redirectProject = getRedirectFromSourceFile(fileName);
            if (redirectProject?.outputDts) {
                if (redirectProject.resolvedRef.commandLine.options.outFile) {
                    // Shouldnt create many to 1 mapping file in --out scenario
                    return undefined;
                }
                fileName = redirectProject.outputDts;
                // Once we start redirecting to a file, we can potentially come back to it
                // via a back-reference from another file in the .d.ts folder. If that happens we'll
                // end up trying to add it to the program *again* because we were tracking it via its
                // original (un-redirected) name. So we have to map both the original path and the redirected path
                // to the source file we're about to find/create
                redirectedPath = toPath(redirectProject.outputDts);
            }
        }
        // We haven't looked for this file, do so now and cache result
        const sourceFileOptions = getCreateSourceFileOptions(fileName, moduleResolutionCache, host, options);
        const file = host.getSourceFile(fileName, sourceFileOptions, hostErrorMessage => addFilePreprocessingFileExplainingDiagnostic(/*file*/ undefined, reason, ts_js_1.Diagnostics.Cannot_read_file_0_Colon_1, [fileName, hostErrorMessage]), shouldCreateNewSourceFile);
        if (packageId) {
            const packageIdKey = (0, ts_js_1.packageIdToString)(packageId);
            const fileFromPackageId = packageIdToSourceFile.get(packageIdKey);
            if (fileFromPackageId) {
                // Some other SourceFile already exists with this package name and version.
                // Instead of creating a duplicate, just redirect to the existing one.
                const dupFile = createRedirectedSourceFile(fileFromPackageId, file, fileName, path, toPath(fileName), originalFileName, sourceFileOptions);
                (0, ts_js_1.multiMapAddValue)(redirectTargetsMap, fileFromPackageId.path, fileName);
                addFileToFilesByName(dupFile, path, fileName, redirectedPath);
                addFileIncludeReason(dupFile, reason, /*checkExisting*/ false);
                sourceFileToPackageName.set(path, (0, ts_js_1.packageIdToPackageName)(packageId));
                processingOtherFiles.push(dupFile);
                return dupFile;
            }
            else if (file) {
                // This is the first source file to have this packageId.
                packageIdToSourceFile.set(packageIdKey, file);
                sourceFileToPackageName.set(path, (0, ts_js_1.packageIdToPackageName)(packageId));
            }
        }
        addFileToFilesByName(file, path, fileName, redirectedPath);
        if (file) {
            sourceFilesFoundSearchingNodeModules.set(path, currentNodeModulesDepth > 0);
            file.fileName = fileName; // Ensure that source file has same name as what we were looking for
            file.path = path;
            file.resolvedPath = toPath(fileName);
            file.originalFileName = originalFileName;
            file.packageJsonLocations = sourceFileOptions.packageJsonLocations?.length ? sourceFileOptions.packageJsonLocations : undefined;
            file.packageJsonScope = sourceFileOptions.packageJsonScope;
            addFileIncludeReason(file, reason, /*checkExisting*/ false);
            if (host.useCaseSensitiveFileNames()) {
                const pathLowerCase = (0, ts_js_1.toFileNameLowerCase)(path);
                // for case-sensitive file systems check if we've already seen some file with similar filename ignoring case
                const existingFile = filesByNameIgnoreCase.get(pathLowerCase);
                if (existingFile) {
                    reportFileNamesDifferOnlyInCasingError(fileName, existingFile, reason);
                }
                else {
                    filesByNameIgnoreCase.set(pathLowerCase, file);
                }
            }
            if (!options.noResolve) {
                processReferencedFiles(file, isDefaultLib);
                processTypeReferenceDirectives(file);
            }
            if (!options.noLib) {
                processLibReferenceDirectives(file);
            }
            // always process imported modules to record module name resolutions
            processImportedModules(file);
            if (isDefaultLib) {
                processingDefaultLibFiles.push(file);
            }
            else {
                processingOtherFiles.push(file);
            }
            (filesWithReferencesProcessed ?? (filesWithReferencesProcessed = new Set())).add(file.path);
        }
        return file;
    }
    function addFileIncludeReason(file, reason, checkExisting) {
        if (file && (!checkExisting || !isReferencedFile(reason) || !filesWithReferencesProcessed?.has(reason.file))) {
            (0, ts_js_1.multiMapAddValue)(programDiagnostics.getFileReasons(), file.path, reason);
            return true;
        }
        return false;
    }
    function addFileToFilesByName(file, path, fileName, redirectedPath) {
        if (redirectedPath) {
            updateFilesByNameMap(fileName, redirectedPath, file);
            updateFilesByNameMap(fileName, path, file || false);
        }
        else {
            updateFilesByNameMap(fileName, path, file);
        }
    }
    function updateFilesByNameMap(fileName, path, file) {
        filesByName.set(path, file);
        if (file !== undefined)
            missingFileNames.delete(path);
        else
            missingFileNames.set(path, fileName);
    }
    /**
     * Get the referenced project if the file is input file from that reference project
     */
    function getRedirectFromSourceFile(fileName) {
        return mapSourceFileToResolvedRef?.get(toPath(fileName));
    }
    function forEachResolvedProjectReference(cb) {
        return (0, ts_js_1.forEachResolvedProjectReference)(resolvedProjectReferences, cb);
    }
    function getRedirectFromOutput(path) {
        return mapOutputFileToResolvedRef?.get(path);
    }
    function isSourceOfProjectReferenceRedirect(fileName) {
        return useSourceOfProjectReferenceRedirect && !!getRedirectFromSourceFile(fileName);
    }
    function getResolvedProjectReferenceByPath(projectReferencePath) {
        if (!projectReferenceRedirects) {
            return undefined;
        }
        return projectReferenceRedirects.get(projectReferencePath) || undefined;
    }
    function processReferencedFiles(file, isDefaultLib) {
        (0, ts_js_1.forEach)(file.referencedFiles, (ref, index) => {
            processSourceFile(resolveTripleslashReference(ref.fileName, file.fileName), isDefaultLib, 
            /*packageId*/ undefined, { kind: ts_js_1.FileIncludeKind.ReferenceFile, file: file.path, index });
        });
    }
    function processTypeReferenceDirectives(file) {
        const typeDirectives = file.typeReferenceDirectives;
        if (!typeDirectives.length)
            return;
        const resolutions = resolvedTypeReferenceDirectiveNamesProcessing?.get(file.path) ||
            resolveTypeReferenceDirectiveNamesReusingOldState(typeDirectives, file);
        const resolutionsInFile = (0, ts_js_1.createModeAwareCache)();
        (resolvedTypeReferenceDirectiveNames ?? (resolvedTypeReferenceDirectiveNames = new Map())).set(file.path, resolutionsInFile);
        for (let index = 0; index < typeDirectives.length; index++) {
            const ref = file.typeReferenceDirectives[index];
            const resolvedTypeReferenceDirective = resolutions[index];
            // store resolved type directive on the file
            const fileName = ref.fileName;
            const mode = getModeForTypeReferenceDirectiveInFile(ref, file);
            resolutionsInFile.set(fileName, mode, resolvedTypeReferenceDirective);
            processTypeReferenceDirective(fileName, mode, resolvedTypeReferenceDirective, { kind: ts_js_1.FileIncludeKind.TypeReferenceDirective, file: file.path, index });
        }
    }
    function getCompilerOptionsForFile(file) {
        return getRedirectReferenceForResolution(file)?.commandLine.options || options;
    }
    function processTypeReferenceDirective(typeReferenceDirective, mode, resolution, reason) {
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "processTypeReferenceDirective", { directive: typeReferenceDirective, hasResolved: !!resolution.resolvedTypeReferenceDirective, refKind: reason.kind, refPath: isReferencedFile(reason) ? reason.file : undefined });
        processTypeReferenceDirectiveWorker(typeReferenceDirective, mode, resolution, reason);
        ts_js_1.tracing?.pop();
    }
    function processTypeReferenceDirectiveWorker(typeReferenceDirective, mode, resolution, reason) {
        addResolutionDiagnostics(resolution);
        const { resolvedTypeReferenceDirective } = resolution;
        if (resolvedTypeReferenceDirective) {
            if (resolvedTypeReferenceDirective.isExternalLibraryImport)
                currentNodeModulesDepth++;
            // resolved from the primary path
            processSourceFile(resolvedTypeReferenceDirective.resolvedFileName, /*isDefaultLib*/ false, resolvedTypeReferenceDirective.packageId, reason); // TODO: GH#18217
            if (resolvedTypeReferenceDirective.isExternalLibraryImport)
                currentNodeModulesDepth--;
        }
        else {
            addFilePreprocessingFileExplainingDiagnostic(/*file*/ undefined, reason, ts_js_1.Diagnostics.Cannot_find_type_definition_file_for_0, [typeReferenceDirective]);
        }
    }
    function pathForLibFile(libFileName) {
        const existing = resolvedLibReferences?.get(libFileName);
        if (existing)
            return existing.actual;
        const result = pathForLibFileWorker(libFileName);
        (resolvedLibReferences ?? (resolvedLibReferences = new Map())).set(libFileName, result);
        libFiles.add(toPath(result.actual));
        return result.actual;
    }
    function pathForLibFileWorker(libFileName) {
        const existing = resolvedLibProcessing?.get(libFileName);
        if (existing)
            return existing;
        if (!options.libReplacement) {
            const result = {
                resolution: {
                    resolvedModule: undefined,
                },
                actual: (0, ts_js_1.combinePaths)(defaultLibraryPath, libFileName),
            };
            (resolvedLibProcessing ?? (resolvedLibProcessing = new Map())).set(libFileName, result);
            return result;
        }
        if (structureIsReused !== 0 /* StructureIsReused.Not */ && oldProgram && !hasInvalidatedLibResolutions(libFileName)) {
            const oldResolution = oldProgram.resolvedLibReferences?.get(libFileName);
            if (oldResolution) {
                if (oldResolution.resolution && (0, ts_js_1.isTraceEnabled)(options, host)) {
                    const libraryName = getLibraryNameFromLibFileName(libFileName);
                    const resolveFrom = getInferredLibraryNameResolveFrom(options, currentDirectory, libFileName);
                    (0, ts_js_1.trace)(host, oldResolution.resolution.resolvedModule ?
                        oldResolution.resolution.resolvedModule.packageId ?
                            ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2_with_Package_ID_3 :
                            ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_successfully_resolved_to_2 :
                        ts_js_1.Diagnostics.Reusing_resolution_of_module_0_from_1_of_old_program_it_was_not_resolved, libraryName, (0, ts_js_1.getNormalizedAbsolutePath)(resolveFrom, currentDirectory), oldResolution.resolution.resolvedModule?.resolvedFileName, oldResolution.resolution.resolvedModule?.packageId && (0, ts_js_1.packageIdToString)(oldResolution.resolution.resolvedModule.packageId));
                }
                (resolvedLibProcessing ?? (resolvedLibProcessing = new Map())).set(libFileName, oldResolution);
                return oldResolution;
            }
        }
        const libraryName = getLibraryNameFromLibFileName(libFileName);
        const resolveFrom = getInferredLibraryNameResolveFrom(options, currentDirectory, libFileName);
        ts_js_1.tracing?.push("program" /* tracing.Phase.Program */, "resolveLibrary", { resolveFrom });
        performance.mark("beforeResolveLibrary");
        const resolution = actualResolveLibrary(libraryName, resolveFrom, options, libFileName);
        performance.mark("afterResolveLibrary");
        performance.measure("ResolveLibrary", "beforeResolveLibrary", "afterResolveLibrary");
        ts_js_1.tracing?.pop();
        const result = {
            resolution,
            actual: resolution.resolvedModule ?
                resolution.resolvedModule.resolvedFileName :
                (0, ts_js_1.combinePaths)(defaultLibraryPath, libFileName),
        };
        (resolvedLibProcessing ?? (resolvedLibProcessing = new Map())).set(libFileName, result);
        return result;
    }
    function processLibReferenceDirectives(file) {
        (0, ts_js_1.forEach)(file.libReferenceDirectives, (libReference, index) => {
            const libFileName = (0, ts_js_1.getLibFileNameFromLibReference)(libReference);
            if (libFileName) {
                processRootFile(pathForLibFile(libFileName), /*isDefaultLib*/ true, { kind: ts_js_1.FileIncludeKind.LibReferenceDirective, file: file.path, index });
            }
            else {
                programDiagnostics.addFileProcessingDiagnostic({
                    kind: 0 /* FilePreprocessingDiagnosticsKind.FilePreprocessingLibReferenceDiagnostic */,
                    reason: { kind: ts_js_1.FileIncludeKind.LibReferenceDirective, file: file.path, index },
                });
            }
        });
    }
    function getCanonicalFileName(fileName) {
        return host.getCanonicalFileName(fileName);
    }
    function processImportedModules(file) {
        collectExternalModuleReferences(file);
        if (file.imports.length || file.moduleAugmentations.length) {
            // Because global augmentation doesn't have string literal name, we can check for global augmentation as such.
            const moduleNames = getModuleNames(file);
            const resolutions = resolvedModulesProcessing?.get(file.path) ||
                resolveModuleNamesReusingOldState(moduleNames, file);
            ts_js_1.Debug.assert(resolutions.length === moduleNames.length);
            const optionsForFile = getCompilerOptionsForFile(file);
            const resolutionsInFile = (0, ts_js_1.createModeAwareCache)();
            (resolvedModules ?? (resolvedModules = new Map())).set(file.path, resolutionsInFile);
            for (let index = 0; index < moduleNames.length; index++) {
                const resolution = resolutions[index].resolvedModule;
                const moduleName = moduleNames[index].text;
                const mode = getModeForUsageLocationWorker(file, moduleNames[index], optionsForFile);
                resolutionsInFile.set(moduleName, mode, resolutions[index]);
                addResolutionDiagnosticsFromResolutionOrCache(file, moduleName, resolutions[index], mode);
                if (!resolution) {
                    continue;
                }
                const isFromNodeModulesSearch = resolution.isExternalLibraryImport;
                // If this is js file source of project reference, dont treat it as js file but as d.ts
                const isJsFile = !(0, ts_js_1.resolutionExtensionIsTSOrJson)(resolution.extension) && !getRedirectFromSourceFile(resolution.resolvedFileName);
                const isJsFileFromNodeModules = isFromNodeModulesSearch && isJsFile && (!resolution.originalPath || (0, ts_js_1.pathContainsNodeModules)(resolution.resolvedFileName));
                const resolvedFileName = resolution.resolvedFileName;
                if (isFromNodeModulesSearch) {
                    currentNodeModulesDepth++;
                }
                // add file to program only if:
                // - resolution was successful
                // - noResolve is falsy
                // - module name comes from the list of imports
                // - it's not a top level JavaScript module that exceeded the search max
                const elideImport = isJsFileFromNodeModules && currentNodeModulesDepth > maxNodeModuleJsDepth;
                // Don't add the file if it has a bad extension (e.g. 'tsx' if we don't have '--allowJs')
                // This may still end up being an untyped module -- the file won't be included but imports will be allowed.
                const shouldAddFile = resolvedFileName
                    && !getResolutionDiagnostic(optionsForFile, resolution, file)
                    && !optionsForFile.noResolve
                    && index < file.imports.length
                    && !elideImport
                    && !(isJsFile && !(0, ts_js_1.getAllowJSCompilerOption)(optionsForFile))
                    && ((0, ts_js_1.isInJSFile)(file.imports[index]) || !(file.imports[index].flags & 16777216 /* NodeFlags.JSDoc */));
                if (elideImport) {
                    modulesWithElidedImports.set(file.path, true);
                }
                else if (shouldAddFile) {
                    findSourceFile(resolvedFileName, 
                    /*isDefaultLib*/ false, { kind: ts_js_1.FileIncludeKind.Import, file: file.path, index }, resolution.packageId);
                }
                if (isFromNodeModulesSearch) {
                    currentNodeModulesDepth--;
                }
            }
        }
    }
    function checkSourceFilesBelongToPath(sourceFiles, rootDirectory) {
        let allFilesBelongToPath = true;
        const absoluteRootDirectoryPath = host.getCanonicalFileName((0, ts_js_1.getNormalizedAbsolutePath)(rootDirectory, currentDirectory));
        for (const sourceFile of sourceFiles) {
            if (!sourceFile.isDeclarationFile) {
                const absoluteSourceFilePath = host.getCanonicalFileName((0, ts_js_1.getNormalizedAbsolutePath)(sourceFile.fileName, currentDirectory));
                if (absoluteSourceFilePath.indexOf(absoluteRootDirectoryPath) !== 0) {
                    programDiagnostics.addLazyConfigDiagnostic(sourceFile, ts_js_1.Diagnostics.File_0_is_not_under_rootDir_1_rootDir_is_expected_to_contain_all_source_files, sourceFile.fileName, rootDirectory);
                    allFilesBelongToPath = false;
                }
            }
        }
        return allFilesBelongToPath;
    }
    function parseProjectReferenceConfigFile(ref) {
        if (!projectReferenceRedirects) {
            projectReferenceRedirects = new Map();
        }
        // The actual filename (i.e. add "/tsconfig.json" if necessary)
        const refPath = resolveProjectReferencePath(ref);
        const sourceFilePath = toPath(refPath);
        const fromCache = projectReferenceRedirects.get(sourceFilePath);
        if (fromCache !== undefined) {
            return fromCache || undefined;
        }
        let commandLine;
        let sourceFile;
        if (host.getParsedCommandLine) {
            commandLine = host.getParsedCommandLine(refPath);
            if (!commandLine) {
                addFileToFilesByName(/*file*/ undefined, sourceFilePath, refPath, /*redirectedPath*/ undefined);
                projectReferenceRedirects.set(sourceFilePath, false);
                return undefined;
            }
            sourceFile = ts_js_1.Debug.checkDefined(commandLine.options.configFile);
            ts_js_1.Debug.assert(!sourceFile.path || sourceFile.path === sourceFilePath);
            addFileToFilesByName(sourceFile, sourceFilePath, refPath, /*redirectedPath*/ undefined);
        }
        else {
            // An absolute path pointing to the containing directory of the config file
            const basePath = (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getDirectoryPath)(refPath), currentDirectory);
            sourceFile = host.getSourceFile(refPath, 100 /* ScriptTarget.JSON */);
            addFileToFilesByName(sourceFile, sourceFilePath, refPath, /*redirectedPath*/ undefined);
            if (sourceFile === undefined) {
                projectReferenceRedirects.set(sourceFilePath, false);
                return undefined;
            }
            commandLine = (0, ts_js_1.parseJsonSourceFileConfigFileContent)(sourceFile, configParsingHost, basePath, /*existingOptions*/ undefined, refPath);
        }
        sourceFile.fileName = refPath;
        sourceFile.path = sourceFilePath;
        sourceFile.resolvedPath = sourceFilePath;
        sourceFile.originalFileName = refPath;
        const resolvedRef = { commandLine, sourceFile };
        projectReferenceRedirects.set(sourceFilePath, resolvedRef);
        if (options.configFile !== sourceFile) {
            mapSourceFileToResolvedRef ?? (mapSourceFileToResolvedRef = new Map());
            mapOutputFileToResolvedRef ?? (mapOutputFileToResolvedRef = new Map());
            let outDts;
            if (commandLine.options.outFile) {
                outDts = (0, ts_js_1.changeExtension)(commandLine.options.outFile, ".d.ts" /* Extension.Dts */);
                mapOutputFileToResolvedRef?.set(toPath(outDts), { resolvedRef });
            }
            const getCommonSourceDirectory = (0, ts_js_1.memoize)(() => (0, ts_js_1.getCommonSourceDirectoryOfConfig)(resolvedRef.commandLine, !host.useCaseSensitiveFileNames()));
            commandLine.fileNames.forEach(fileName => {
                const path = toPath(fileName);
                let outputDts;
                if (!(0, ts_js_1.isDeclarationFileName)(fileName) && !(0, ts_js_1.fileExtensionIs)(fileName, ".json" /* Extension.Json */)) {
                    if (!commandLine.options.outFile) {
                        outputDts = (0, ts_js_1.getOutputDeclarationFileName)(fileName, resolvedRef.commandLine, !host.useCaseSensitiveFileNames(), getCommonSourceDirectory);
                        mapOutputFileToResolvedRef.set(toPath(outputDts), { resolvedRef, source: fileName });
                    }
                    else {
                        outputDts = outDts;
                    }
                }
                mapSourceFileToResolvedRef.set(path, { resolvedRef, outputDts });
            });
        }
        if (commandLine.projectReferences) {
            resolvedRef.references = commandLine.projectReferences.map(parseProjectReferenceConfigFile);
        }
        return resolvedRef;
    }
    function verifyCompilerOptions() {
        if (options.strictPropertyInitialization && !(0, ts_js_1.getStrictOptionValue)(options, "strictNullChecks")) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1, "strictPropertyInitialization", "strictNullChecks");
        }
        if (options.exactOptionalPropertyTypes && !(0, ts_js_1.getStrictOptionValue)(options, "strictNullChecks")) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1, "exactOptionalPropertyTypes", "strictNullChecks");
        }
        if (options.isolatedModules || options.verbatimModuleSyntax) {
            if (options.outFile) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "outFile", options.verbatimModuleSyntax ? "verbatimModuleSyntax" : "isolatedModules");
            }
        }
        if (options.isolatedDeclarations) {
            if ((0, ts_js_1.getAllowJSCompilerOption)(options)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "allowJs", "isolatedDeclarations");
            }
            if (!(0, ts_js_1.getEmitDeclarations)(options)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1_or_option_2, "isolatedDeclarations", "declaration", "composite");
            }
        }
        if (options.inlineSourceMap) {
            if (options.sourceMap) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "sourceMap", "inlineSourceMap");
            }
            if (options.mapRoot) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "mapRoot", "inlineSourceMap");
            }
        }
        if (options.composite) {
            if (options.declaration === false) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Composite_projects_may_not_disable_declaration_emit, "declaration");
            }
            if (options.incremental === false) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Composite_projects_may_not_disable_incremental_compilation, "declaration");
            }
        }
        const outputFile = options.outFile;
        if (!options.tsBuildInfoFile && options.incremental && !outputFile && !options.configFilePath) {
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Option_incremental_can_only_be_specified_using_tsconfig_emitting_to_single_file_or_when_option_tsBuildInfoFile_is_specified));
        }
        verifyDeprecatedCompilerOptions();
        verifyProjectReferences();
        // List of collected files is complete; validate exhautiveness if this is a project with a file list
        if (options.composite) {
            const rootPaths = new Set(rootNames.map(toPath));
            for (const file of files) {
                // Ignore file that is not emitted
                if ((0, ts_js_1.sourceFileMayBeEmitted)(file, program) && !rootPaths.has(file.path)) {
                    programDiagnostics.addLazyConfigDiagnostic(file, ts_js_1.Diagnostics.File_0_is_not_listed_within_the_file_list_of_project_1_Projects_must_list_all_files_or_use_an_include_pattern, file.fileName, options.configFilePath || "");
                }
            }
        }
        if (options.paths) {
            for (const key in options.paths) {
                if (!(0, ts_js_1.hasProperty)(options.paths, key)) {
                    continue;
                }
                if (!(0, ts_js_1.hasZeroOrOneAsteriskCharacter)(key)) {
                    createDiagnosticForOptionPaths(/*onKey*/ true, key, ts_js_1.Diagnostics.Pattern_0_can_have_at_most_one_Asterisk_character, key);
                }
                if ((0, ts_js_1.isArray)(options.paths[key])) {
                    const len = options.paths[key].length;
                    if (len === 0) {
                        createDiagnosticForOptionPaths(/*onKey*/ false, key, ts_js_1.Diagnostics.Substitutions_for_pattern_0_shouldn_t_be_an_empty_array, key);
                    }
                    for (let i = 0; i < len; i++) {
                        const subst = options.paths[key][i];
                        const typeOfSubst = typeof subst;
                        if (typeof subst === "string") {
                            if (!(0, ts_js_1.hasZeroOrOneAsteriskCharacter)(subst)) {
                                createDiagnosticForOptionPathKeyValue(key, i, ts_js_1.Diagnostics.Substitution_0_in_pattern_1_can_have_at_most_one_Asterisk_character, subst, key);
                            }
                            if (!options.baseUrl && !(0, ts_js_1.pathIsRelative)(subst) && !(0, ts_js_1.pathIsAbsolute)(subst)) {
                                createDiagnosticForOptionPathKeyValue(key, i, ts_js_1.Diagnostics.Non_relative_paths_are_not_allowed_when_baseUrl_is_not_set_Did_you_forget_a_leading_Slash);
                            }
                        }
                        else {
                            createDiagnosticForOptionPathKeyValue(key, i, ts_js_1.Diagnostics.Substitution_0_for_pattern_1_has_incorrect_type_expected_string_got_2, subst, key, typeOfSubst);
                        }
                    }
                }
                else {
                    createDiagnosticForOptionPaths(/*onKey*/ false, key, ts_js_1.Diagnostics.Substitutions_for_pattern_0_should_be_an_array, key);
                }
            }
        }
        if (!options.sourceMap && !options.inlineSourceMap) {
            if (options.inlineSources) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_can_only_be_used_when_either_option_inlineSourceMap_or_option_sourceMap_is_provided, "inlineSources");
            }
            if (options.sourceRoot) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_can_only_be_used_when_either_option_inlineSourceMap_or_option_sourceMap_is_provided, "sourceRoot");
            }
        }
        if (options.mapRoot && !(options.sourceMap || options.declarationMap)) {
            // Error to specify --mapRoot without --sourcemap
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1_or_option_2, "mapRoot", "sourceMap", "declarationMap");
        }
        if (options.declarationDir) {
            if (!(0, ts_js_1.getEmitDeclarations)(options)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1_or_option_2, "declarationDir", "declaration", "composite");
            }
            if (outputFile) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "declarationDir", "outFile");
            }
        }
        if (options.declarationMap && !(0, ts_js_1.getEmitDeclarations)(options)) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1_or_option_2, "declarationMap", "declaration", "composite");
        }
        if (options.lib && options.noLib) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "lib", "noLib");
        }
        const languageVersion = (0, ts_js_1.getEmitScriptTarget)(options);
        const firstNonAmbientExternalModuleSourceFile = (0, ts_js_1.find)(files, f => (0, ts_js_1.isExternalModule)(f) && !f.isDeclarationFile);
        if (options.isolatedModules || options.verbatimModuleSyntax) {
            if (options.module === ts_js_1.ModuleKind.None && languageVersion < 2 /* ScriptTarget.ES2015 */ && options.isolatedModules) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_isolatedModules_can_only_be_used_when_either_option_module_is_provided_or_option_target_is_ES2015_or_higher, "isolatedModules", "target");
            }
            if (options.preserveConstEnums === false) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_preserveConstEnums_cannot_be_disabled_when_0_is_enabled, options.verbatimModuleSyntax ? "verbatimModuleSyntax" : "isolatedModules", "preserveConstEnums");
            }
        }
        else if (firstNonAmbientExternalModuleSourceFile && languageVersion < 2 /* ScriptTarget.ES2015 */ && options.module === ts_js_1.ModuleKind.None) {
            // We cannot use createDiagnosticFromNode because nodes do not have parents yet
            const span = (0, ts_js_1.getErrorSpanForNode)(firstNonAmbientExternalModuleSourceFile, typeof firstNonAmbientExternalModuleSourceFile.externalModuleIndicator === "boolean" ? firstNonAmbientExternalModuleSourceFile : firstNonAmbientExternalModuleSourceFile.externalModuleIndicator);
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createFileDiagnostic)(firstNonAmbientExternalModuleSourceFile, span.start, span.length, ts_js_1.Diagnostics.Cannot_use_imports_exports_or_module_augmentations_when_module_is_none));
        }
        // Cannot specify module gen that isn't amd or system with --out
        if (outputFile && !options.emitDeclarationOnly) {
            if (options.module && !(options.module === ts_js_1.ModuleKind.AMD || options.module === ts_js_1.ModuleKind.System)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Only_amd_and_system_modules_are_supported_alongside_0, "outFile", "module");
            }
            else if (options.module === undefined && firstNonAmbientExternalModuleSourceFile) {
                const span = (0, ts_js_1.getErrorSpanForNode)(firstNonAmbientExternalModuleSourceFile, typeof firstNonAmbientExternalModuleSourceFile.externalModuleIndicator === "boolean" ? firstNonAmbientExternalModuleSourceFile : firstNonAmbientExternalModuleSourceFile.externalModuleIndicator);
                programDiagnostics.addConfigDiagnostic((0, ts_js_1.createFileDiagnostic)(firstNonAmbientExternalModuleSourceFile, span.start, span.length, ts_js_1.Diagnostics.Cannot_compile_modules_using_option_0_unless_the_module_flag_is_amd_or_system, "outFile"));
            }
        }
        if ((0, ts_js_1.getResolveJsonModule)(options)) {
            if ((0, ts_js_1.getEmitModuleResolutionKind)(options) === ts_js_1.ModuleResolutionKind.Classic) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_resolveJsonModule_cannot_be_specified_when_moduleResolution_is_set_to_classic, "resolveJsonModule");
            }
            else if (!(0, ts_js_1.hasJsonModuleEmitEnabled)(options)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_resolveJsonModule_cannot_be_specified_when_module_is_set_to_none_system_or_umd, "resolveJsonModule", "module");
            }
        }
        // there has to be common source directory if user specified --outdir || --rootDir || --sourceRoot
        // if user specified --mapRoot, there needs to be common source directory if there would be multiple files being emitted
        if (options.outDir || // there is --outDir specified
            options.rootDir || // there is --rootDir specified
            options.sourceRoot || // there is --sourceRoot specified
            options.mapRoot || // there is --mapRoot specified
            ((0, ts_js_1.getEmitDeclarations)(options) && options.declarationDir) // there is --declarationDir specified
        ) {
            // Precalculate and cache the common source directory
            const dir = getCommonSourceDirectory();
            // If we failed to find a good common directory, but outDir is specified and at least one of our files is on a windows drive/URL/other resource, add a failure
            if (options.outDir && dir === "" && files.some(file => (0, ts_js_1.getRootLength)(file.fileName) > 1)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Cannot_find_the_common_subdirectory_path_for_the_input_files, "outDir");
            }
        }
        if (!options.noEmit &&
            !options.composite &&
            !options.rootDir &&
            options.configFilePath &&
            (options.outDir || // there is --outDir specified
                ((0, ts_js_1.getEmitDeclarations)(options) && options.declarationDir) || // there is --declarationDir specified
                options.outFile)) {
            // Check if rootDir inferred changed and issue diagnostic
            const dir = getCommonSourceDirectory();
            const emittedFiles = (0, ts_js_1.mapDefined)(files, file => !file.isDeclarationFile && (0, ts_js_1.sourceFileMayBeEmitted)(file, program) ? file.fileName : undefined);
            const dir59 = (0, ts_js_1.getComputedCommonSourceDirectory)(emittedFiles, currentDirectory, getCanonicalFileName);
            if (dir59 !== "" && getCanonicalFileName(dir) !== getCanonicalFileName(dir59)) {
                // change in layout
                createDiagnosticForOption(
                /*onKey*/ true, options.outFile ? "outFile" : options.outDir ? "outDir" : "declarationDir", !options.outFile && options.outDir ? "declarationDir" : undefined, (0, ts_js_1.chainDiagnosticMessages)((0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Visit_https_Colon_Slash_Slashaka_ms_Slashts6_for_migration_information), ts_js_1.Diagnostics.The_common_source_directory_of_0_is_1_The_rootDir_setting_must_be_explicitly_set_to_this_or_another_path_to_adjust_your_output_s_file_layout, (0, ts_js_1.getBaseFileName)(options.configFilePath), (0, ts_js_1.getRelativePathFromFile)(options.configFilePath, dir59, getCanonicalFileName)));
            }
        }
        if (options.checkJs && !(0, ts_js_1.getAllowJSCompilerOption)(options)) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1, "checkJs", "allowJs");
        }
        if (options.emitDeclarationOnly) {
            if (!(0, ts_js_1.getEmitDeclarations)(options)) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1_or_option_2, "emitDeclarationOnly", "declaration", "composite");
            }
        }
        if (options.emitDecoratorMetadata &&
            !options.experimentalDecorators) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1, "emitDecoratorMetadata", "experimentalDecorators");
        }
        if (options.jsxFactory) {
            if (options.reactNamespace) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_with_option_1, "reactNamespace", "jsxFactory");
            }
            if (options.jsx === 4 /* JsxEmit.ReactJSX */ || options.jsx === 5 /* JsxEmit.ReactJSXDev */) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_when_option_jsx_is_1, "jsxFactory", ts_js_1.inverseJsxOptionMap.get("" + options.jsx));
            }
            if (!(0, ts_js_1.parseIsolatedEntityName)(options.jsxFactory, languageVersion)) {
                createOptionValueDiagnostic("jsxFactory", ts_js_1.Diagnostics.Invalid_value_for_jsxFactory_0_is_not_a_valid_identifier_or_qualified_name, options.jsxFactory);
            }
        }
        else if (options.reactNamespace && !(0, ts_js_1.isIdentifierText)(options.reactNamespace, languageVersion)) {
            createOptionValueDiagnostic("reactNamespace", ts_js_1.Diagnostics.Invalid_value_for_reactNamespace_0_is_not_a_valid_identifier, options.reactNamespace);
        }
        if (options.jsxFragmentFactory) {
            if (!options.jsxFactory) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_without_specifying_option_1, "jsxFragmentFactory", "jsxFactory");
            }
            if (options.jsx === 4 /* JsxEmit.ReactJSX */ || options.jsx === 5 /* JsxEmit.ReactJSXDev */) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_when_option_jsx_is_1, "jsxFragmentFactory", ts_js_1.inverseJsxOptionMap.get("" + options.jsx));
            }
            if (!(0, ts_js_1.parseIsolatedEntityName)(options.jsxFragmentFactory, languageVersion)) {
                createOptionValueDiagnostic("jsxFragmentFactory", ts_js_1.Diagnostics.Invalid_value_for_jsxFragmentFactory_0_is_not_a_valid_identifier_or_qualified_name, options.jsxFragmentFactory);
            }
        }
        if (options.reactNamespace) {
            if (options.jsx === 4 /* JsxEmit.ReactJSX */ || options.jsx === 5 /* JsxEmit.ReactJSXDev */) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_when_option_jsx_is_1, "reactNamespace", ts_js_1.inverseJsxOptionMap.get("" + options.jsx));
            }
        }
        if (options.jsxImportSource) {
            if (options.jsx === 2 /* JsxEmit.React */) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_cannot_be_specified_when_option_jsx_is_1, "jsxImportSource", ts_js_1.inverseJsxOptionMap.get("" + options.jsx));
            }
        }
        const moduleKind = (0, ts_js_1.getEmitModuleKind)(options);
        if (options.verbatimModuleSyntax) {
            if (moduleKind === ts_js_1.ModuleKind.AMD || moduleKind === ts_js_1.ModuleKind.UMD || moduleKind === ts_js_1.ModuleKind.System) {
                createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_verbatimModuleSyntax_cannot_be_used_when_module_is_set_to_UMD_AMD_or_System, "verbatimModuleSyntax");
            }
        }
        if (options.allowImportingTsExtensions && !(options.noEmit || options.emitDeclarationOnly || options.rewriteRelativeImportExtensions)) {
            createOptionValueDiagnostic("allowImportingTsExtensions", ts_js_1.Diagnostics.Option_allowImportingTsExtensions_can_only_be_used_when_one_of_noEmit_emitDeclarationOnly_or_rewriteRelativeImportExtensions_is_set);
        }
        const moduleResolution = (0, ts_js_1.getEmitModuleResolutionKind)(options);
        if (options.resolvePackageJsonExports && !(0, ts_js_1.moduleResolutionSupportsPackageJsonExportsAndImports)(moduleResolution)) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_can_only_be_used_when_moduleResolution_is_set_to_node16_nodenext_or_bundler, "resolvePackageJsonExports");
        }
        if (options.resolvePackageJsonImports && !(0, ts_js_1.moduleResolutionSupportsPackageJsonExportsAndImports)(moduleResolution)) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_can_only_be_used_when_moduleResolution_is_set_to_node16_nodenext_or_bundler, "resolvePackageJsonImports");
        }
        if (options.customConditions && !(0, ts_js_1.moduleResolutionSupportsPackageJsonExportsAndImports)(moduleResolution)) {
            createDiagnosticForOptionName(ts_js_1.Diagnostics.Option_0_can_only_be_used_when_moduleResolution_is_set_to_node16_nodenext_or_bundler, "customConditions");
        }
        if (moduleResolution === ts_js_1.ModuleResolutionKind.Bundler && !(0, ts_js_1.emitModuleKindIsNonNodeESM)(moduleKind) && moduleKind !== ts_js_1.ModuleKind.Preserve && moduleKind !== ts_js_1.ModuleKind.CommonJS) {
            createOptionValueDiagnostic("moduleResolution", ts_js_1.Diagnostics.Option_0_can_only_be_used_when_module_is_set_to_preserve_commonjs_or_es2015_or_later, "bundler");
        }
        if (ts_js_1.ModuleKind[moduleKind] &&
            (ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext) &&
            !(ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext)) {
            const moduleKindName = ts_js_1.ModuleKind[moduleKind];
            const moduleResolutionName = ts_js_1.ModuleResolutionKind[moduleKindName] ? moduleKindName : "Node16";
            createOptionValueDiagnostic("moduleResolution", ts_js_1.Diagnostics.Option_moduleResolution_must_be_set_to_0_or_left_unspecified_when_option_module_is_set_to_1, moduleResolutionName, moduleKindName);
        }
        else if (ts_js_1.ModuleResolutionKind[moduleResolution] &&
            (ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext) &&
            !(ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext)) {
            const moduleResolutionName = ts_js_1.ModuleResolutionKind[moduleResolution];
            createOptionValueDiagnostic("module", ts_js_1.Diagnostics.Option_module_must_be_set_to_0_when_option_moduleResolution_is_set_to_1, moduleResolutionName, moduleResolutionName);
        }
        // If the emit is enabled make sure that every output file is unique and not overwriting any of the input files
        if (!options.noEmit && !options.suppressOutputPathCheck) {
            const emitHost = getEmitHost();
            const emitFilesSeen = new Set();
            (0, ts_js_1.forEachEmittedFile)(emitHost, emitFileNames => {
                if (!options.emitDeclarationOnly) {
                    verifyEmitFilePath(emitFileNames.jsFilePath, emitFilesSeen);
                }
                verifyEmitFilePath(emitFileNames.declarationFilePath, emitFilesSeen);
            });
        }
        // Verify that all the emit files are unique and don't overwrite input files
        function verifyEmitFilePath(emitFileName, emitFilesSeen) {
            if (emitFileName) {
                const emitFilePath = toPath(emitFileName);
                // Report error if the output overwrites input file
                if (filesByName.has(emitFilePath)) {
                    let chain;
                    if (!options.configFilePath) {
                        // The program is from either an inferred project or an external project
                        chain = (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Adding_a_tsconfig_json_file_will_help_organize_projects_that_contain_both_TypeScript_and_JavaScript_files_Learn_more_at_https_Colon_Slash_Slashaka_ms_Slashtsconfig);
                    }
                    chain = (0, ts_js_1.chainDiagnosticMessages)(chain, ts_js_1.Diagnostics.Cannot_write_file_0_because_it_would_overwrite_input_file, emitFileName);
                    blockEmittingOfFile(emitFileName, (0, ts_js_1.createCompilerDiagnosticFromMessageChain)(chain));
                }
                const emitFileKey = !host.useCaseSensitiveFileNames() ? (0, ts_js_1.toFileNameLowerCase)(emitFilePath) : emitFilePath;
                // Report error if multiple files write into same file
                if (emitFilesSeen.has(emitFileKey)) {
                    // Already seen the same emit file - report error
                    blockEmittingOfFile(emitFileName, (0, ts_js_1.createCompilerDiagnostic)(ts_js_1.Diagnostics.Cannot_write_file_0_because_it_would_be_overwritten_by_multiple_input_files, emitFileName));
                }
                else {
                    emitFilesSeen.add(emitFileKey);
                }
            }
        }
    }
    function getIgnoreDeprecationsVersion() {
        const ignoreDeprecations = options.ignoreDeprecations;
        if (ignoreDeprecations) {
            if (ignoreDeprecations === "5.0" || ignoreDeprecations === "6.0") {
                return new ts_js_1.Version(ignoreDeprecations);
            }
            reportInvalidIgnoreDeprecations();
        }
        return ts_js_1.Version.zero;
    }
    function checkDeprecations(deprecatedIn, removedIn, createDiagnostic, fn) {
        const deprecatedInVersion = new ts_js_1.Version(deprecatedIn);
        const removedInVersion = new ts_js_1.Version(removedIn);
        const typescriptVersion = new ts_js_1.Version(typeScriptVersion || ts_js_1.versionMajorMinor);
        const ignoreDeprecationsVersion = getIgnoreDeprecationsVersion();
        const mustBeRemoved = !(removedInVersion.compareTo(typescriptVersion) === 1 /* Comparison.GreaterThan */);
        const canBeSilenced = !mustBeRemoved && ignoreDeprecationsVersion.compareTo(deprecatedInVersion) === -1 /* Comparison.LessThan */;
        if (mustBeRemoved || canBeSilenced) {
            fn((name, value, useInstead, related) => {
                if (mustBeRemoved) {
                    if (value === undefined) {
                        createDiagnostic(name, value, useInstead, related, ts_js_1.Diagnostics.Option_0_has_been_removed_Please_remove_it_from_your_configuration, name);
                    }
                    else {
                        createDiagnostic(name, value, useInstead, related, ts_js_1.Diagnostics.Option_0_1_has_been_removed_Please_remove_it_from_your_configuration, name, value);
                    }
                }
                else {
                    if (value === undefined) {
                        createDiagnostic(name, value, useInstead, related, ts_js_1.Diagnostics.Option_0_is_deprecated_and_will_stop_functioning_in_TypeScript_1_Specify_compilerOption_ignoreDeprecations_Colon_2_to_silence_this_error, name, removedIn, deprecatedIn);
                    }
                    else {
                        createDiagnostic(name, value, useInstead, related, ts_js_1.Diagnostics.Option_0_1_is_deprecated_and_will_stop_functioning_in_TypeScript_2_Specify_compilerOption_ignoreDeprecations_Colon_3_to_silence_this_error, name, value, removedIn, deprecatedIn);
                    }
                }
            });
        }
    }
    function verifyDeprecatedCompilerOptions() {
        function createDiagnostic(name, value, useInstead, related, message, ...args) {
            if (useInstead) {
                let details = (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, ts_js_1.Diagnostics.Use_0_instead, useInstead);
                if (related) {
                    details = (0, ts_js_1.chainDiagnosticMessages)(details, related);
                }
                const chain = (0, ts_js_1.chainDiagnosticMessages)(details, message, ...args);
                createDiagnosticForOption(/*onKey*/ !value, name, /*option2*/ undefined, chain);
            }
            else {
                let details;
                if (related) {
                    details = (0, ts_js_1.chainDiagnosticMessages)(/*details*/ undefined, related);
                }
                const chain = (0, ts_js_1.chainDiagnosticMessages)(details, message, ...args);
                createDiagnosticForOption(/*onKey*/ !value, name, /*option2*/ undefined, chain);
            }
        }
        checkDeprecations("5.0", "5.5", createDiagnostic, createDeprecatedDiagnostic => {
            if (options.target === 0 /* ScriptTarget.ES3 */) {
                createDeprecatedDiagnostic("target", "ES3");
            }
            if (options.noImplicitUseStrict) {
                createDeprecatedDiagnostic("noImplicitUseStrict");
            }
            if (options.keyofStringsOnly) {
                createDeprecatedDiagnostic("keyofStringsOnly");
            }
            if (options.suppressExcessPropertyErrors) {
                createDeprecatedDiagnostic("suppressExcessPropertyErrors");
            }
            if (options.suppressImplicitAnyIndexErrors) {
                createDeprecatedDiagnostic("suppressImplicitAnyIndexErrors");
            }
            if (options.noStrictGenericChecks) {
                createDeprecatedDiagnostic("noStrictGenericChecks");
            }
            if (options.charset) {
                createDeprecatedDiagnostic("charset");
            }
            if (options.out) {
                createDeprecatedDiagnostic("out");
            }
            if (options.importsNotUsedAsValues) {
                createDeprecatedDiagnostic("importsNotUsedAsValues", /*value*/ undefined, "verbatimModuleSyntax");
            }
            if (options.preserveValueImports) {
                createDeprecatedDiagnostic("preserveValueImports", /*value*/ undefined, "verbatimModuleSyntax");
            }
        });
        checkDeprecations("6.0", "7.0", createDiagnostic, createDeprecatedDiagnostic => {
            if (options.alwaysStrict === false) {
                createDeprecatedDiagnostic("alwaysStrict", "false", /*useInstead*/ undefined, /*related*/ undefined);
            }
            if (options.target === 1 /* ScriptTarget.ES5 */) {
                createDeprecatedDiagnostic("target", "ES5");
            }
            if (options.moduleResolution === ts_js_1.ModuleResolutionKind.Node10) {
                createDeprecatedDiagnostic("moduleResolution", "node10", /*useInstead*/ undefined, ts_js_1.Diagnostics.Visit_https_Colon_Slash_Slashaka_ms_Slashts6_for_migration_information);
            }
            if (options.moduleResolution === ts_js_1.ModuleResolutionKind.Classic) {
                createDeprecatedDiagnostic("moduleResolution", "classic", /*useInstead*/ undefined, /*related*/ undefined);
            }
            if (options.baseUrl !== undefined) {
                createDeprecatedDiagnostic("baseUrl", /*value*/ undefined, /*useInstead*/ undefined, ts_js_1.Diagnostics.Visit_https_Colon_Slash_Slashaka_ms_Slashts6_for_migration_information);
            }
            if (options.esModuleInterop === false) {
                createDeprecatedDiagnostic("esModuleInterop", "false", /*useInstead*/ undefined, /*related*/ undefined);
            }
            if (options.allowSyntheticDefaultImports === false) {
                createDeprecatedDiagnostic("allowSyntheticDefaultImports", "false", /*useInstead*/ undefined, /*related*/ undefined);
            }
            if (options.outFile) {
                createDeprecatedDiagnostic("outFile");
            }
            if (options.module === ts_js_1.ModuleKind.None || options.module === ts_js_1.ModuleKind.AMD || options.module === ts_js_1.ModuleKind.UMD || options.module === ts_js_1.ModuleKind.System) {
                createDeprecatedDiagnostic("module", ts_js_1.ModuleKind[options.module], /*useInstead*/ undefined, /*related*/ undefined);
            }
            if (options.downlevelIteration !== undefined) {
                createDeprecatedDiagnostic("downlevelIteration");
            }
        });
    }
    function verifyDeprecatedProjectReference(ref, parentFile, index) {
        function createDiagnostic(_name, _value, _useInstead, _related, message, ...args) {
            createDiagnosticForReference(parentFile, index, message, ...args);
        }
        checkDeprecations("5.0", "5.5", createDiagnostic, createDeprecatedDiagnostic => {
            if (ref.prepend) {
                createDeprecatedDiagnostic("prepend");
            }
        });
    }
    function addFilePreprocessingFileExplainingDiagnostic(file, fileProcessingReason, diagnostic, args) {
        programDiagnostics.addFileProcessingDiagnostic({
            kind: 1 /* FilePreprocessingDiagnosticsKind.FilePreprocessingFileExplainingDiagnostic */,
            file: file && file.path,
            fileProcessingReason,
            diagnostic,
            args,
        });
    }
    function verifyProjectReferences() {
        const buildInfoPath = !options.suppressOutputPathCheck ? (0, ts_js_1.getTsBuildInfoEmitOutputFilePath)(options) : undefined;
        (0, ts_js_1.forEachProjectReference)(projectReferences, resolvedProjectReferences, (resolvedRef, parent, index) => {
            const ref = (parent ? parent.commandLine.projectReferences : projectReferences)[index];
            const parentFile = parent && parent.sourceFile;
            verifyDeprecatedProjectReference(ref, parentFile, index);
            if (!resolvedRef) {
                createDiagnosticForReference(parentFile, index, ts_js_1.Diagnostics.File_0_not_found, ref.path);
                return;
            }
            const options = resolvedRef.commandLine.options;
            if (!options.composite || options.noEmit) {
                // ok to not have composite if the current program is container only
                const inputs = parent ? parent.commandLine.fileNames : rootNames;
                if (inputs.length) {
                    if (!options.composite)
                        createDiagnosticForReference(parentFile, index, ts_js_1.Diagnostics.Referenced_project_0_must_have_setting_composite_Colon_true, ref.path);
                    if (options.noEmit)
                        createDiagnosticForReference(parentFile, index, ts_js_1.Diagnostics.Referenced_project_0_may_not_disable_emit, ref.path);
                }
            }
            if (!parent && buildInfoPath && buildInfoPath === (0, ts_js_1.getTsBuildInfoEmitOutputFilePath)(options)) {
                createDiagnosticForReference(parentFile, index, ts_js_1.Diagnostics.Cannot_write_file_0_because_it_will_overwrite_tsbuildinfo_file_generated_by_referenced_project_1, buildInfoPath, ref.path);
                hasEmitBlockingDiagnostics.set(toPath(buildInfoPath), true);
            }
        });
    }
    function createDiagnosticForOptionPathKeyValue(key, valueIndex, message, ...args) {
        let needCompilerDiagnostic = true;
        forEachOptionPathsSyntax(pathProp => {
            if ((0, ts_js_1.isObjectLiteralExpression)(pathProp.initializer)) {
                (0, ts_js_1.forEachPropertyAssignment)(pathProp.initializer, key, keyProps => {
                    const initializer = keyProps.initializer;
                    if ((0, ts_js_1.isArrayLiteralExpression)(initializer) && initializer.elements.length > valueIndex) {
                        programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeInSourceFile)(options.configFile, initializer.elements[valueIndex], message, ...args));
                        needCompilerDiagnostic = false;
                    }
                });
            }
        });
        if (needCompilerDiagnostic) {
            createCompilerOptionsDiagnostic(message, ...args);
        }
    }
    function createDiagnosticForOptionPaths(onKey, key, message, ...args) {
        let needCompilerDiagnostic = true;
        forEachOptionPathsSyntax(pathProp => {
            if ((0, ts_js_1.isObjectLiteralExpression)(pathProp.initializer) &&
                createOptionDiagnosticInObjectLiteralSyntax(pathProp.initializer, onKey, key, 
                /*key2*/ undefined, message, ...args)) {
                needCompilerDiagnostic = false;
            }
        });
        if (needCompilerDiagnostic) {
            createCompilerOptionsDiagnostic(message, ...args);
        }
    }
    function forEachOptionPathsSyntax(callback) {
        return (0, ts_js_1.forEachOptionsSyntaxByName)(getCompilerOptionsObjectLiteralSyntax(), "paths", callback);
    }
    function createDiagnosticForOptionName(message, option1, option2, option3) {
        // TODO(jakebailey): this code makes assumptions about the format of the diagnostic messages.
        createDiagnosticForOption(/*onKey*/ true, option1, option2, message, option1, option2, option3);
    }
    function createOptionValueDiagnostic(option1, message, ...args) {
        createDiagnosticForOption(/*onKey*/ false, option1, /*option2*/ undefined, message, ...args);
    }
    function createDiagnosticForReference(sourceFile, index, message, ...args) {
        const referencesSyntax = (0, ts_js_1.forEachTsConfigPropArray)(sourceFile || options.configFile, "references", property => (0, ts_js_1.isArrayLiteralExpression)(property.initializer) ? property.initializer : undefined);
        if (referencesSyntax && referencesSyntax.elements.length > index) {
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeInSourceFile)(sourceFile || options.configFile, referencesSyntax.elements[index], message, ...args));
        }
        else {
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createCompilerDiagnostic)(message, ...args));
        }
    }
    function createDiagnosticForOption(onKey, option1, option2, message, ...args) {
        const compilerOptionsObjectLiteralSyntax = getCompilerOptionsObjectLiteralSyntax();
        const needCompilerDiagnostic = !compilerOptionsObjectLiteralSyntax ||
            !createOptionDiagnosticInObjectLiteralSyntax(compilerOptionsObjectLiteralSyntax, onKey, option1, option2, message, ...args);
        if (needCompilerDiagnostic) {
            createCompilerOptionsDiagnostic(message, ...args);
        }
    }
    function createCompilerOptionsDiagnostic(message, ...args) {
        const compilerOptionsProperty = getCompilerOptionsPropertySyntax();
        if (compilerOptionsProperty) {
            // eslint-disable-next-line local/no-in-operator
            if ("messageText" in message) {
                programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeFromMessageChain)(options.configFile, compilerOptionsProperty.name, message));
            }
            else {
                programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeInSourceFile)(options.configFile, compilerOptionsProperty.name, message, ...args));
            }
        }
        // eslint-disable-next-line local/no-in-operator
        else if ("messageText" in message) {
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createCompilerDiagnosticFromMessageChain)(message));
        }
        else {
            programDiagnostics.addConfigDiagnostic((0, ts_js_1.createCompilerDiagnostic)(message, ...args));
        }
    }
    function getCompilerOptionsObjectLiteralSyntax() {
        if (_compilerOptionsObjectLiteralSyntax === undefined) {
            const compilerOptionsProperty = getCompilerOptionsPropertySyntax();
            _compilerOptionsObjectLiteralSyntax = compilerOptionsProperty ? (0, ts_js_1.tryCast)(compilerOptionsProperty.initializer, ts_js_1.isObjectLiteralExpression) || false : false;
        }
        return _compilerOptionsObjectLiteralSyntax || undefined;
    }
    function getCompilerOptionsPropertySyntax() {
        if (_compilerOptionsPropertySyntax === undefined) {
            _compilerOptionsPropertySyntax = (0, ts_js_1.forEachPropertyAssignment)((0, ts_js_1.getTsConfigObjectLiteralExpression)(options.configFile), "compilerOptions", ts_js_1.identity) || false;
        }
        return _compilerOptionsPropertySyntax || undefined;
    }
    function createOptionDiagnosticInObjectLiteralSyntax(objectLiteral, onKey, key1, key2, message, ...args) {
        let needsCompilerDiagnostic = false;
        (0, ts_js_1.forEachPropertyAssignment)(objectLiteral, key1, prop => {
            // eslint-disable-next-line local/no-in-operator
            if ("messageText" in message) {
                programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeFromMessageChain)(options.configFile, onKey ? prop.name : prop.initializer, message));
            }
            else {
                programDiagnostics.addConfigDiagnostic((0, ts_js_1.createDiagnosticForNodeInSourceFile)(options.configFile, onKey ? prop.name : prop.initializer, message, ...args));
            }
            needsCompilerDiagnostic = true;
        }, key2);
        return needsCompilerDiagnostic;
    }
    function blockEmittingOfFile(emitFileName, diag) {
        hasEmitBlockingDiagnostics.set(toPath(emitFileName), true);
        programDiagnostics.addConfigDiagnostic(diag);
    }
    function isEmittedFile(file) {
        if (options.noEmit) {
            return false;
        }
        // If this is source file, its not emitted file
        const filePath = toPath(file);
        if (getSourceFileByPath(filePath)) {
            return false;
        }
        // If options have --outFile or --out just check that
        const out = options.outFile;
        if (out) {
            return isSameFile(filePath, out) || isSameFile(filePath, (0, ts_js_1.removeFileExtension)(out) + ".d.ts" /* Extension.Dts */);
        }
        // If declarationDir is specified, return if its a file in that directory
        if (options.declarationDir && (0, ts_js_1.containsPath)(options.declarationDir, filePath, currentDirectory, !host.useCaseSensitiveFileNames())) {
            return true;
        }
        // If --outDir, check if file is in that directory
        if (options.outDir) {
            return (0, ts_js_1.containsPath)(options.outDir, filePath, currentDirectory, !host.useCaseSensitiveFileNames());
        }
        if ((0, ts_js_1.fileExtensionIsOneOf)(filePath, ts_js_1.supportedJSExtensionsFlat) || (0, ts_js_1.isDeclarationFileName)(filePath)) {
            // Otherwise just check if sourceFile with the name exists
            const filePathWithoutExtension = (0, ts_js_1.removeFileExtension)(filePath);
            return !!getSourceFileByPath((filePathWithoutExtension + ".ts" /* Extension.Ts */)) ||
                !!getSourceFileByPath((filePathWithoutExtension + ".tsx" /* Extension.Tsx */));
        }
        return false;
    }
    function isSameFile(file1, file2) {
        return (0, ts_js_1.comparePaths)(file1, file2, currentDirectory, !host.useCaseSensitiveFileNames()) === 0 /* Comparison.EqualTo */;
    }
    function getSymlinkCache() {
        if (host.getSymlinkCache) {
            return host.getSymlinkCache();
        }
        if (!symlinks) {
            symlinks = (0, ts_js_1.createSymlinkCache)(currentDirectory, getCanonicalFileName);
        }
        if (files && !symlinks.hasProcessedResolutions()) {
            symlinks.setSymlinksFromResolutions(forEachResolvedModule, forEachResolvedTypeReferenceDirective, automaticTypeDirectiveResolutions);
        }
        return symlinks;
    }
    function getModeForUsageLocation(file, usage) {
        return getModeForUsageLocationWorker(file, usage, getCompilerOptionsForFile(file));
    }
    function getEmitSyntaxForUsageLocation(file, usage) {
        return getEmitSyntaxForUsageLocationWorker(file, usage, getCompilerOptionsForFile(file));
    }
    function getModeForResolutionAtIndex(file, index) {
        return getModeForUsageLocation(file, getModuleNameStringLiteralAt(file, index));
    }
    function getDefaultResolutionModeForFile(sourceFile) {
        return getDefaultResolutionModeForFileWorker(sourceFile, getCompilerOptionsForFile(sourceFile));
    }
    function getImpliedNodeFormatForEmit(sourceFile) {
        return getImpliedNodeFormatForEmitWorker(sourceFile, getCompilerOptionsForFile(sourceFile));
    }
    function getEmitModuleFormatOfFile(sourceFile) {
        return getEmitModuleFormatOfFileWorker(sourceFile, getCompilerOptionsForFile(sourceFile));
    }
    function shouldTransformImportCall(sourceFile) {
        return shouldTransformImportCallWorker(sourceFile, getCompilerOptionsForFile(sourceFile));
    }
    function getModeForTypeReferenceDirectiveInFile(ref, sourceFile) {
        return ref.resolutionMode || getDefaultResolutionModeForFile(sourceFile);
    }
}
function shouldTransformImportCallWorker(sourceFile, options) {
    const moduleKind = (0, ts_js_1.getEmitModuleKind)(options);
    if (ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext || moduleKind === ts_js_1.ModuleKind.Preserve) {
        return false;
    }
    return getEmitModuleFormatOfFileWorker(sourceFile, options) < ts_js_1.ModuleKind.ES2015;
}
/** @internal Prefer `program.getEmitModuleFormatOfFile` when possible. */
function getEmitModuleFormatOfFileWorker(sourceFile, options) {
    return getImpliedNodeFormatForEmitWorker(sourceFile, options) ?? (0, ts_js_1.getEmitModuleKind)(options);
}
/** @internal Prefer `program.getImpliedNodeFormatForEmit` when possible. */
function getImpliedNodeFormatForEmitWorker(sourceFile, options) {
    const moduleKind = (0, ts_js_1.getEmitModuleKind)(options);
    if (ts_js_1.ModuleKind.Node16 <= moduleKind && moduleKind <= ts_js_1.ModuleKind.NodeNext) {
        return sourceFile.impliedNodeFormat;
    }
    if (sourceFile.impliedNodeFormat === ts_js_1.ModuleKind.CommonJS
        && (sourceFile.packageJsonScope?.contents.packageJsonContent.type === "commonjs"
            || (0, ts_js_1.fileExtensionIsOneOf)(sourceFile.fileName, [".cjs" /* Extension.Cjs */, ".cts" /* Extension.Cts */]))) {
        return ts_js_1.ModuleKind.CommonJS;
    }
    if (sourceFile.impliedNodeFormat === ts_js_1.ModuleKind.ESNext
        && (sourceFile.packageJsonScope?.contents.packageJsonContent.type === "module"
            || (0, ts_js_1.fileExtensionIsOneOf)(sourceFile.fileName, [".mjs" /* Extension.Mjs */, ".mts" /* Extension.Mts */]))) {
        return ts_js_1.ModuleKind.ESNext;
    }
    return undefined;
}
/** @internal Prefer `program.getDefaultResolutionModeForFile` when possible. */
function getDefaultResolutionModeForFileWorker(sourceFile, options) {
    return (0, ts_js_1.importSyntaxAffectsModuleResolution)(options) ? getImpliedNodeFormatForEmitWorker(sourceFile, options) : undefined;
}
function updateHostForUseSourceOfProjectReferenceRedirect(host) {
    let setOfDeclarationDirectories;
    const originalFileExists = host.compilerHost.fileExists;
    const originalDirectoryExists = host.compilerHost.directoryExists;
    const originalGetDirectories = host.compilerHost.getDirectories;
    const originalRealpath = host.compilerHost.realpath;
    if (!host.useSourceOfProjectReferenceRedirect)
        return { onProgramCreateComplete: ts_js_1.noop, fileExists };
    host.compilerHost.fileExists = fileExists;
    let directoryExists;
    if (originalDirectoryExists) {
        // This implementation of directoryExists checks if the directory being requested is
        // directory of .d.ts file for the referenced Project.
        // If it is it returns true irrespective of whether that directory exists on host
        directoryExists = host.compilerHost.directoryExists = path => {
            if (originalDirectoryExists.call(host.compilerHost, path)) {
                handleDirectoryCouldBeSymlink(path);
                return true;
            }
            if (!host.getResolvedProjectReferences())
                return false;
            if (!setOfDeclarationDirectories) {
                setOfDeclarationDirectories = new Set();
                host.forEachResolvedProjectReference(ref => {
                    const out = ref.commandLine.options.outFile;
                    if (out) {
                        setOfDeclarationDirectories.add((0, ts_js_1.getDirectoryPath)(host.toPath(out)));
                    }
                    else {
                        // Set declaration's in different locations only, if they are next to source the directory present doesnt change
                        const declarationDir = ref.commandLine.options.declarationDir || ref.commandLine.options.outDir;
                        if (declarationDir) {
                            setOfDeclarationDirectories.add(host.toPath(declarationDir));
                        }
                    }
                });
            }
            return fileOrDirectoryExistsUsingSource(path, /*isFile*/ false);
        };
    }
    if (originalGetDirectories) {
        // Call getDirectories only if directory actually present on the host
        // This is needed to ensure that we arent getting directories that we fake about presence for
        host.compilerHost.getDirectories = path => !host.getResolvedProjectReferences() || (originalDirectoryExists && originalDirectoryExists.call(host.compilerHost, path)) ?
            originalGetDirectories.call(host.compilerHost, path) :
            [];
    }
    // This is something we keep for life time of the host
    if (originalRealpath) {
        host.compilerHost.realpath = s => host.getSymlinkCache().getSymlinkedFiles()?.get(host.toPath(s)) ||
            originalRealpath.call(host.compilerHost, s);
    }
    return { onProgramCreateComplete, fileExists, directoryExists };
    function onProgramCreateComplete() {
        host.compilerHost.fileExists = originalFileExists;
        host.compilerHost.directoryExists = originalDirectoryExists;
        host.compilerHost.getDirectories = originalGetDirectories;
        // DO not revert realpath as it could be used later
    }
    // This implementation of fileExists checks if the file being requested is
    // .d.ts file for the referenced Project.
    // If it is it returns true irrespective of whether that file exists on host
    function fileExists(file) {
        if (originalFileExists.call(host.compilerHost, file))
            return true;
        if (!host.getResolvedProjectReferences())
            return false;
        if (!(0, ts_js_1.isDeclarationFileName)(file))
            return false;
        // Project references go to source file instead of .d.ts file
        return fileOrDirectoryExistsUsingSource(file, /*isFile*/ true);
    }
    function fileExistsIfProjectReferenceDts(file) {
        const source = host.getRedirectFromOutput(host.toPath(file));
        return source !== undefined ?
            (0, ts_js_1.isString)(source.source) ? originalFileExists.call(host.compilerHost, source.source) : true :
            undefined;
    }
    function directoryExistsIfProjectReferenceDeclDir(dir) {
        const dirPath = host.toPath(dir);
        const dirPathWithTrailingDirectorySeparator = `${dirPath}${ts_js_1.directorySeparator}`;
        return (0, ts_js_1.forEachKey)(setOfDeclarationDirectories, declDirPath => dirPath === declDirPath ||
            // Any parent directory of declaration dir
            (0, ts_js_1.startsWith)(declDirPath, dirPathWithTrailingDirectorySeparator) ||
            // Any directory inside declaration dir
            (0, ts_js_1.startsWith)(dirPath, `${declDirPath}/`));
    }
    function handleDirectoryCouldBeSymlink(directory) {
        if (!host.getResolvedProjectReferences() || (0, ts_js_1.containsIgnoredPath)(directory))
            return;
        // Because we already watch node_modules, handle symlinks in there
        if (!originalRealpath || !directory.includes(ts_js_1.nodeModulesPathPart))
            return;
        const symlinkCache = host.getSymlinkCache();
        const directoryPath = (0, ts_js_1.ensureTrailingDirectorySeparator)(host.toPath(directory));
        if (symlinkCache.getSymlinkedDirectories()?.has(directoryPath))
            return;
        const real = (0, ts_js_1.normalizePath)(originalRealpath.call(host.compilerHost, directory));
        let realPath;
        if (real === directory ||
            (realPath = (0, ts_js_1.ensureTrailingDirectorySeparator)(host.toPath(real))) === directoryPath) {
            // not symlinked
            symlinkCache.setSymlinkedDirectory(directoryPath, false);
            return;
        }
        symlinkCache.setSymlinkedDirectory(directory, {
            real: (0, ts_js_1.ensureTrailingDirectorySeparator)(real),
            realPath,
        });
    }
    function fileOrDirectoryExistsUsingSource(fileOrDirectory, isFile) {
        const fileOrDirectoryExistsUsingSource = isFile ?
            fileExistsIfProjectReferenceDts :
            directoryExistsIfProjectReferenceDeclDir;
        // Check current directory or file
        const result = fileOrDirectoryExistsUsingSource(fileOrDirectory);
        if (result !== undefined)
            return result;
        const symlinkCache = host.getSymlinkCache();
        const symlinkedDirectories = symlinkCache.getSymlinkedDirectories();
        if (!symlinkedDirectories)
            return false;
        const fileOrDirectoryPath = host.toPath(fileOrDirectory);
        if (!fileOrDirectoryPath.includes(ts_js_1.nodeModulesPathPart))
            return false;
        if (isFile && symlinkCache.getSymlinkedFiles()?.has(fileOrDirectoryPath))
            return true;
        // If it contains node_modules check if its one of the symlinked path we know of
        return (0, ts_js_1.firstDefinedIterator)(symlinkedDirectories.entries(), ([directoryPath, symlinkedDirectory]) => {
            if (!symlinkedDirectory || !(0, ts_js_1.startsWith)(fileOrDirectoryPath, directoryPath))
                return undefined;
            const result = fileOrDirectoryExistsUsingSource(fileOrDirectoryPath.replace(directoryPath, symlinkedDirectory.realPath));
            if (isFile && result) {
                // Store the real path for the file'
                const absolutePath = (0, ts_js_1.getNormalizedAbsolutePath)(fileOrDirectory, host.compilerHost.getCurrentDirectory());
                symlinkCache.setSymlinkedFile(fileOrDirectoryPath, `${symlinkedDirectory.real}${absolutePath.replace(new RegExp(directoryPath, "i"), "")}`);
            }
            return result;
        }) || false;
    }
}
/** @internal */
exports.emitSkippedWithNoDiagnostics = { diagnostics: ts_js_1.emptyArray, sourceMaps: undefined, emittedFiles: undefined, emitSkipped: true };
/** @internal */
function handleNoEmitOptions(program, sourceFile, writeFile, cancellationToken) {
    const options = program.getCompilerOptions();
    if (options.noEmit) {
        return sourceFile ?
            exports.emitSkippedWithNoDiagnostics :
            program.emitBuildInfo(writeFile, cancellationToken);
    }
    // If the noEmitOnError flag is set, then check if we have any errors so far.  If so,
    // immediately bail out.  Note that we pass 'undefined' for 'sourceFile' so that we
    // get any preEmit diagnostics, not just the ones
    if (!options.noEmitOnError)
        return undefined;
    let diagnostics = [
        ...program.getOptionsDiagnostics(cancellationToken),
        ...program.getSyntacticDiagnostics(sourceFile, cancellationToken),
        ...program.getGlobalDiagnostics(cancellationToken),
        ...program.getSemanticDiagnostics(sourceFile, cancellationToken),
    ];
    if (diagnostics.length === 0 && (0, ts_js_1.getEmitDeclarations)(program.getCompilerOptions())) {
        diagnostics = program.getDeclarationDiagnostics(/*sourceFile*/ undefined, cancellationToken);
    }
    if (!diagnostics.length)
        return undefined;
    let emittedFiles;
    if (!sourceFile) {
        const emitResult = program.emitBuildInfo(writeFile, cancellationToken);
        if (emitResult.diagnostics)
            diagnostics = [...diagnostics, ...emitResult.diagnostics];
        emittedFiles = emitResult.emittedFiles;
    }
    return { diagnostics, sourceMaps: undefined, emittedFiles, emitSkipped: true };
}
/** @internal */
function filterSemanticDiagnostics(diagnostic, option) {
    return (0, ts_js_1.filter)(diagnostic, d => !d.skippedOn || !option[d.skippedOn]);
}
/** @internal */
function parseConfigHostFromCompilerHostLike(host, directoryStructureHost = host) {
    return {
        fileExists: f => directoryStructureHost.fileExists(f),
        readDirectory(root, extensions, excludes, includes, depth) {
            ts_js_1.Debug.assertIsDefined(directoryStructureHost.readDirectory, "'CompilerHost.readDirectory' must be implemented to correctly process 'projectReferences'");
            return directoryStructureHost.readDirectory(root, extensions, excludes, includes, depth);
        },
        readFile: f => directoryStructureHost.readFile(f),
        directoryExists: directoryStructureHost.directoryExists?.bind(directoryStructureHost),
        getDirectories: directoryStructureHost.getDirectories?.bind(directoryStructureHost),
        realpath: directoryStructureHost.realpath?.bind(directoryStructureHost),
        useCaseSensitiveFileNames: host.useCaseSensitiveFileNames(),
        getCurrentDirectory: () => host.getCurrentDirectory(),
        onUnRecoverableConfigFileDiagnostic: host.onUnRecoverableConfigFileDiagnostic || ts_js_1.returnUndefined,
        trace: host.trace ? s => host.trace(s) : undefined,
    };
}
/**
 * Returns the target config filename of a project reference.
 * Note: The file might not exist.
 */
function resolveProjectReferencePath(ref) {
    return (0, ts_js_1.resolveConfigFileProjectName)(ref.path);
}
/**
 * Returns a DiagnosticMessage if we won't include a resolved module due to its extension.
 * The DiagnosticMessage's parameters are the imported module name, and the filename it resolved to.
 * This returns a diagnostic even if the module will be an untyped module.
 *
 * @internal
 */
function getResolutionDiagnostic(options, { extension }, { isDeclarationFile }) {
    switch (extension) {
        case ".ts" /* Extension.Ts */:
        case ".d.ts" /* Extension.Dts */:
        case ".mts" /* Extension.Mts */:
        case ".d.mts" /* Extension.Dmts */:
        case ".cts" /* Extension.Cts */:
        case ".d.cts" /* Extension.Dcts */:
            // These are always allowed.
            return undefined;
        case ".tsx" /* Extension.Tsx */:
            return needJsx();
        case ".jsx" /* Extension.Jsx */:
            return needJsx() || needAllowJs();
        case ".js" /* Extension.Js */:
        case ".mjs" /* Extension.Mjs */:
        case ".cjs" /* Extension.Cjs */:
            return needAllowJs();
        case ".json" /* Extension.Json */:
            return needResolveJsonModule();
        default:
            return needAllowArbitraryExtensions();
    }
    function needJsx() {
        return options.jsx ? undefined : ts_js_1.Diagnostics.Module_0_was_resolved_to_1_but_jsx_is_not_set;
    }
    function needAllowJs() {
        return (0, ts_js_1.getAllowJSCompilerOption)(options) || !(0, ts_js_1.getStrictOptionValue)(options, "noImplicitAny") ? undefined : ts_js_1.Diagnostics.Could_not_find_a_declaration_file_for_module_0_1_implicitly_has_an_any_type;
    }
    function needResolveJsonModule() {
        return (0, ts_js_1.getResolveJsonModule)(options) ? undefined : ts_js_1.Diagnostics.Module_0_was_resolved_to_1_but_resolveJsonModule_is_not_used;
    }
    function needAllowArbitraryExtensions() {
        // But don't report the allowArbitraryExtensions error from declaration files (no reason to report it, since the import doesn't have a runtime component)
        return isDeclarationFile || options.allowArbitraryExtensions ? undefined : ts_js_1.Diagnostics.Module_0_was_resolved_to_1_but_allowArbitraryExtensions_is_not_set;
    }
}
function getModuleNames({ imports, moduleAugmentations }) {
    const res = imports.map(i => i);
    for (const aug of moduleAugmentations) {
        if (aug.kind === 11 /* SyntaxKind.StringLiteral */) {
            res.push(aug);
        }
        // Do nothing if it's an Identifier; we don't need to do module resolution for `declare global`.
    }
    return res;
}
/** @internal */
function getModuleNameStringLiteralAt({ imports, moduleAugmentations }, index) {
    if (index < imports.length)
        return imports[index];
    let augIndex = imports.length;
    for (const aug of moduleAugmentations) {
        if (aug.kind === 11 /* SyntaxKind.StringLiteral */) {
            if (index === augIndex)
                return aug;
            augIndex++;
        }
        // Do nothing if it's an Identifier; we don't need to do module resolution for `declare global`.
    }
    ts_js_1.Debug.fail("should never ask for module name at index higher than possible module name");
}
