"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformES2019 = transformES2019;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function transformES2019(context) {
    const factory = context.factory;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitor(node) {
        if ((node.transformFlags & 64 /* TransformFlags.ContainsES2019 */) === 0) {
            return node;
        }
        switch (node.kind) {
            case 300 /* SyntaxKind.CatchClause */:
                return visitCatchClause(node);
            default:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function visitCatchClause(node) {
        if (!node.variableDeclaration) {
            return factory.updateCatchClause(node, factory.createVariableDeclaration(factory.createTempVariable(/*recordTempVariable*/ undefined)), (0, ts_js_1.visitNode)(node.block, visitor, ts_js_1.isBlock));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
}
