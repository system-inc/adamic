"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformGenerators = transformGenerators;
const ts_js_1 = require("../_namespaces/ts.js");
// dprint-ignore
var OpCode;
(function (OpCode) {
    OpCode[OpCode["Nop"] = 0] = "Nop";
    OpCode[OpCode["Statement"] = 1] = "Statement";
    OpCode[OpCode["Assign"] = 2] = "Assign";
    OpCode[OpCode["Break"] = 3] = "Break";
    OpCode[OpCode["BreakWhenTrue"] = 4] = "BreakWhenTrue";
    OpCode[OpCode["BreakWhenFalse"] = 5] = "BreakWhenFalse";
    OpCode[OpCode["Yield"] = 6] = "Yield";
    OpCode[OpCode["YieldStar"] = 7] = "YieldStar";
    OpCode[OpCode["Return"] = 8] = "Return";
    OpCode[OpCode["Throw"] = 9] = "Throw";
    OpCode[OpCode["Endfinally"] = 10] = "Endfinally";
})(OpCode || (OpCode = {}));
// whether a generated code block is opening or closing at the current operation for a FunctionBuilder
var BlockAction;
(function (BlockAction) {
    BlockAction[BlockAction["Open"] = 0] = "Open";
    BlockAction[BlockAction["Close"] = 1] = "Close";
})(BlockAction || (BlockAction = {}));
// the kind for a generated code block in a FunctionBuilder
var CodeBlockKind;
(function (CodeBlockKind) {
    CodeBlockKind[CodeBlockKind["Exception"] = 0] = "Exception";
    CodeBlockKind[CodeBlockKind["With"] = 1] = "With";
    CodeBlockKind[CodeBlockKind["Switch"] = 2] = "Switch";
    CodeBlockKind[CodeBlockKind["Loop"] = 3] = "Loop";
    CodeBlockKind[CodeBlockKind["Labeled"] = 4] = "Labeled";
})(CodeBlockKind || (CodeBlockKind = {}));
// the state for a generated code exception block
var ExceptionBlockState;
(function (ExceptionBlockState) {
    ExceptionBlockState[ExceptionBlockState["Try"] = 0] = "Try";
    ExceptionBlockState[ExceptionBlockState["Catch"] = 1] = "Catch";
    ExceptionBlockState[ExceptionBlockState["Finally"] = 2] = "Finally";
    ExceptionBlockState[ExceptionBlockState["Done"] = 3] = "Done";
})(ExceptionBlockState || (ExceptionBlockState = {}));
// NOTE: changes to this enum should be reflected in the __generator helper.
var Instruction;
(function (Instruction) {
    Instruction[Instruction["Next"] = 0] = "Next";
    Instruction[Instruction["Throw"] = 1] = "Throw";
    Instruction[Instruction["Return"] = 2] = "Return";
    Instruction[Instruction["Break"] = 3] = "Break";
    Instruction[Instruction["Yield"] = 4] = "Yield";
    Instruction[Instruction["YieldStar"] = 5] = "YieldStar";
    Instruction[Instruction["Catch"] = 6] = "Catch";
    Instruction[Instruction["Endfinally"] = 7] = "Endfinally";
})(Instruction || (Instruction = {}));
function getInstructionName(instruction) {
    switch (instruction) {
        case 2 /* Instruction.Return */:
            return "return";
        case 3 /* Instruction.Break */:
            return "break";
        case 4 /* Instruction.Yield */:
            return "yield";
        case 5 /* Instruction.YieldStar */:
            return "yield*";
        case 7 /* Instruction.Endfinally */:
            return "endfinally";
        default:
            return undefined; // TODO: GH#18217
    }
}
/** @internal */
function transformGenerators(context) {
    const { factory, getEmitHelperFactory: emitHelpers, resumeLexicalEnvironment, endLexicalEnvironment, hoistFunctionDeclaration, hoistVariableDeclaration, } = context;
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const resolver = context.getEmitResolver();
    const previousOnSubstituteNode = context.onSubstituteNode;
    context.onSubstituteNode = onSubstituteNode;
    let renamedCatchVariables;
    let renamedCatchVariableDeclarations;
    let inGeneratorFunctionBody;
    let inStatementContainingYield;
    // The following three arrays store information about generated code blocks.
    // All three arrays are correlated by their index. This approach is used over allocating
    // objects to store the same information to avoid GC overhead.
    //
    let blocks; // Information about the code block
    let blockOffsets; // The operation offset at which a code block begins or ends
    let blockActions; // Whether the code block is opened or closed
    let blockStack; // A stack of currently open code blocks
    // Labels are used to mark locations in the code that can be the target of a Break (jump)
    // operation. These are translated into case clauses in a switch statement.
    // The following two arrays are correlated by their index. This approach is used over
    // allocating objects to store the same information to avoid GC overhead.
    //
    let labelOffsets; // The operation offset at which the label is defined.
    let labelExpressions; // The NumericLiteral nodes bound to each label.
    let nextLabelId = 1; // The next label id to use.
    // Operations store information about generated code for the function body. This
    // Includes things like statements, assignments, breaks (jumps), and yields.
    // The following three arrays are correlated by their index. This approach is used over
    // allocating objects to store the same information to avoid GC overhead.
    //
    let operations; // The operation to perform.
    let operationArguments; // The arguments to the operation.
    let operationLocations; // The source map location for the operation.
    let state; // The name of the state object used by the generator at runtime.
    // The following variables store information used by the `build` function:
    //
    let blockIndex = 0; // The index of the current block.
    let labelNumber = 0; // The current label number.
    let labelNumbers;
    let lastOperationWasAbrupt; // Indicates whether the last operation was abrupt (break/continue).
    let lastOperationWasCompletion; // Indicates whether the last operation was a completion (return/throw).
    let clauses; // The case clauses generated for labels.
    let statements; // The statements for the current label.
    let exceptionBlockStack; // A stack of containing exception blocks.
    let currentExceptionBlock; // The current exception block.
    let withBlockStack; // A stack containing `with` blocks.
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile || (node.transformFlags & 2048 /* TransformFlags.ContainsGenerator */) === 0) {
            return node;
        }
        const visited = (0, ts_js_1.visitEachChild)(node, visitor, context);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        return visited;
    }
    /**
     * Visits a node.
     *
     * @param node The node to visit.
     */
    function visitor(node) {
        const transformFlags = node.transformFlags;
        if (inStatementContainingYield) {
            return visitJavaScriptInStatementContainingYield(node);
        }
        else if (inGeneratorFunctionBody) {
            return visitJavaScriptInGeneratorFunctionBody(node);
        }
        else if ((0, ts_js_1.isFunctionLikeDeclaration)(node) && node.asteriskToken) {
            return visitGenerator(node);
        }
        else if (transformFlags & 2048 /* TransformFlags.ContainsGenerator */) {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        else {
            return node;
        }
    }
    /**
     * Visits a node that is contained within a statement that contains yield.
     *
     * @param node The node to visit.
     */
    function visitJavaScriptInStatementContainingYield(node) {
        switch (node.kind) {
            case 247 /* SyntaxKind.DoStatement */:
                return visitDoStatement(node);
            case 248 /* SyntaxKind.WhileStatement */:
                return visitWhileStatement(node);
            case 256 /* SyntaxKind.SwitchStatement */:
                return visitSwitchStatement(node);
            case 257 /* SyntaxKind.LabeledStatement */:
                return visitLabeledStatement(node);
            default:
                return visitJavaScriptInGeneratorFunctionBody(node);
        }
    }
    /**
     * Visits a node that is contained within a generator function.
     *
     * @param node The node to visit.
     */
    function visitJavaScriptInGeneratorFunctionBody(node) {
        switch (node.kind) {
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return visitFunctionDeclaration(node);
            case 219 /* SyntaxKind.FunctionExpression */:
                return visitFunctionExpression(node);
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
                return visitAccessorDeclaration(node);
            case 244 /* SyntaxKind.VariableStatement */:
                return visitVariableStatement(node);
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node);
            case 250 /* SyntaxKind.ForInStatement */:
                return visitForInStatement(node);
            case 253 /* SyntaxKind.BreakStatement */:
                return visitBreakStatement(node);
            case 252 /* SyntaxKind.ContinueStatement */:
                return visitContinueStatement(node);
            case 254 /* SyntaxKind.ReturnStatement */:
                return visitReturnStatement(node);
            default:
                if (node.transformFlags & 1048576 /* TransformFlags.ContainsYield */) {
                    return visitJavaScriptContainingYield(node);
                }
                else if (node.transformFlags & (2048 /* TransformFlags.ContainsGenerator */ | 4194304 /* TransformFlags.ContainsHoistedDeclarationOrCompletion */)) {
                    return (0, ts_js_1.visitEachChild)(node, visitor, context);
                }
                else {
                    return node;
                }
        }
    }
    /**
     * Visits a node that contains a YieldExpression.
     *
     * @param node The node to visit.
     */
    function visitJavaScriptContainingYield(node) {
        switch (node.kind) {
            case 227 /* SyntaxKind.BinaryExpression */:
                return visitBinaryExpression(node);
            case 357 /* SyntaxKind.CommaListExpression */:
                return visitCommaListExpression(node);
            case 228 /* SyntaxKind.ConditionalExpression */:
                return visitConditionalExpression(node);
            case 230 /* SyntaxKind.YieldExpression */:
                return visitYieldExpression(node);
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
                return visitArrayLiteralExpression(node);
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                return visitObjectLiteralExpression(node);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return visitElementAccessExpression(node);
            case 214 /* SyntaxKind.CallExpression */:
                return visitCallExpression(node);
            case 215 /* SyntaxKind.NewExpression */:
                return visitNewExpression(node);
            default:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    /**
     * Visits a generator function.
     *
     * @param node The node to visit.
     */
    function visitGenerator(node) {
        switch (node.kind) {
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return visitFunctionDeclaration(node);
            case 219 /* SyntaxKind.FunctionExpression */:
                return visitFunctionExpression(node);
            default:
                return ts_js_1.Debug.failBadSyntaxKind(node);
        }
    }
    /**
     * Visits a function declaration.
     *
     * This will be called when one of the following conditions are met:
     * - The function declaration is a generator function.
     * - The function declaration is contained within the body of a generator function.
     *
     * @param node The node to visit.
     */
    function visitFunctionDeclaration(node) {
        // Currently, we only support generators that were originally async functions.
        if (node.asteriskToken) {
            node = (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createFunctionDeclaration(node.modifiers, 
            /*asteriskToken*/ undefined, node.name, 
            /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
            /*type*/ undefined, transformGeneratorFunctionBody(node.body)), 
            /*location*/ node), node);
        }
        else {
            const savedInGeneratorFunctionBody = inGeneratorFunctionBody;
            const savedInStatementContainingYield = inStatementContainingYield;
            inGeneratorFunctionBody = false;
            inStatementContainingYield = false;
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
            inGeneratorFunctionBody = savedInGeneratorFunctionBody;
            inStatementContainingYield = savedInStatementContainingYield;
        }
        if (inGeneratorFunctionBody) {
            // Function declarations in a generator function body are hoisted
            // to the top of the lexical scope and elided from the current statement.
            hoistFunctionDeclaration(node);
            return undefined;
        }
        else {
            return node;
        }
    }
    /**
     * Visits a function expression.
     *
     * This will be called when one of the following conditions are met:
     * - The function expression is a generator function.
     * - The function expression is contained within the body of a generator function.
     *
     * @param node The node to visit.
     */
    function visitFunctionExpression(node) {
        // Currently, we only support generators that were originally async functions.
        if (node.asteriskToken) {
            node = (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createFunctionExpression(
            /*modifiers*/ undefined, 
            /*asteriskToken*/ undefined, node.name, 
            /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
            /*type*/ undefined, transformGeneratorFunctionBody(node.body)), 
            /*location*/ node), node);
        }
        else {
            const savedInGeneratorFunctionBody = inGeneratorFunctionBody;
            const savedInStatementContainingYield = inStatementContainingYield;
            inGeneratorFunctionBody = false;
            inStatementContainingYield = false;
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
            inGeneratorFunctionBody = savedInGeneratorFunctionBody;
            inStatementContainingYield = savedInStatementContainingYield;
        }
        return node;
    }
    /**
     * Visits a get or set accessor declaration.
     *
     * This will be called when one of the following conditions are met:
     * - The accessor is contained within the body of a generator function.
     *
     * @param node The node to visit.
     */
    function visitAccessorDeclaration(node) {
        const savedInGeneratorFunctionBody = inGeneratorFunctionBody;
        const savedInStatementContainingYield = inStatementContainingYield;
        inGeneratorFunctionBody = false;
        inStatementContainingYield = false;
        node = (0, ts_js_1.visitEachChild)(node, visitor, context);
        inGeneratorFunctionBody = savedInGeneratorFunctionBody;
        inStatementContainingYield = savedInStatementContainingYield;
        return node;
    }
    /**
     * Transforms the body of a generator function declaration.
     *
     * @param node The function body to transform.
     */
    function transformGeneratorFunctionBody(body) {
        // Save existing generator state
        const statements = [];
        const savedInGeneratorFunctionBody = inGeneratorFunctionBody;
        const savedInStatementContainingYield = inStatementContainingYield;
        const savedBlocks = blocks;
        const savedBlockOffsets = blockOffsets;
        const savedBlockActions = blockActions;
        const savedBlockStack = blockStack;
        const savedLabelOffsets = labelOffsets;
        const savedLabelExpressions = labelExpressions;
        const savedNextLabelId = nextLabelId;
        const savedOperations = operations;
        const savedOperationArguments = operationArguments;
        const savedOperationLocations = operationLocations;
        const savedState = state;
        // Initialize generator state
        inGeneratorFunctionBody = true;
        inStatementContainingYield = false;
        blocks = undefined;
        blockOffsets = undefined;
        blockActions = undefined;
        blockStack = undefined;
        labelOffsets = undefined;
        labelExpressions = undefined;
        nextLabelId = 1;
        operations = undefined;
        operationArguments = undefined;
        operationLocations = undefined;
        state = factory.createTempVariable(/*recordTempVariable*/ undefined);
        // Build the generator
        resumeLexicalEnvironment();
        const statementOffset = factory.copyPrologue(body.statements, statements, /*ensureUseStrict*/ false, visitor);
        transformAndEmitStatements(body.statements, statementOffset);
        const buildResult = build();
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        statements.push(factory.createReturnStatement(buildResult));
        // Restore previous generator state
        inGeneratorFunctionBody = savedInGeneratorFunctionBody;
        inStatementContainingYield = savedInStatementContainingYield;
        blocks = savedBlocks;
        blockOffsets = savedBlockOffsets;
        blockActions = savedBlockActions;
        blockStack = savedBlockStack;
        labelOffsets = savedLabelOffsets;
        labelExpressions = savedLabelExpressions;
        nextLabelId = savedNextLabelId;
        operations = savedOperations;
        operationArguments = savedOperationArguments;
        operationLocations = savedOperationLocations;
        state = savedState;
        return (0, ts_js_1.setTextRange)(factory.createBlock(statements, body.multiLine), body);
    }
    /**
     * Visits a variable statement.
     *
     * This will be called when one of the following conditions are met:
     * - The variable statement is contained within the body of a generator function.
     *
     * @param node The node to visit.
     */
    function visitVariableStatement(node) {
        if (node.transformFlags & 1048576 /* TransformFlags.ContainsYield */) {
            transformAndEmitVariableDeclarationList(node.declarationList);
            return undefined;
        }
        else {
            // Do not hoist custom prologues.
            if ((0, ts_js_1.getEmitFlags)(node) & 2097152 /* EmitFlags.CustomPrologue */) {
                return node;
            }
            for (const variable of node.declarationList.declarations) {
                hoistVariableDeclaration(variable.name);
            }
            const variables = (0, ts_js_1.getInitializedVariables)(node.declarationList);
            if (variables.length === 0) {
                return undefined;
            }
            return (0, ts_js_1.setSourceMapRange)(factory.createExpressionStatement(factory.inlineExpressions((0, ts_js_1.map)(variables, transformInitializedVariable))), node);
        }
    }
    /**
     * Visits a binary expression.
     *
     * This will be called when one of the following conditions are met:
     * - The node contains a YieldExpression.
     *
     * @param node The node to visit.
     */
    function visitBinaryExpression(node) {
        const assoc = (0, ts_js_1.getExpressionAssociativity)(node);
        switch (assoc) {
            case 0 /* Associativity.Left */:
                return visitLeftAssociativeBinaryExpression(node);
            case 1 /* Associativity.Right */:
                return visitRightAssociativeBinaryExpression(node);
            default:
                return ts_js_1.Debug.assertNever(assoc);
        }
    }
    /**
     * Visits a right-associative binary expression containing `yield`.
     *
     * @param node The node to visit.
     */
    function visitRightAssociativeBinaryExpression(node) {
        const { left, right } = node;
        if (containsYield(right)) {
            let target;
            switch (left.kind) {
                case 212 /* SyntaxKind.PropertyAccessExpression */:
                    // [source]
                    //      a.b = yield;
                    //
                    // [intermediate]
                    //  .local _a
                    //      _a = a;
                    //  .yield resumeLabel
                    //  .mark resumeLabel
                    //      _a.b = %sent%;
                    target = factory.updatePropertyAccessExpression(left, cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(left.expression, visitor, ts_js_1.isLeftHandSideExpression))), left.name);
                    break;
                case 213 /* SyntaxKind.ElementAccessExpression */:
                    // [source]
                    //      a[b] = yield;
                    //
                    // [intermediate]
                    //  .local _a, _b
                    //      _a = a;
                    //      _b = b;
                    //  .yield resumeLabel
                    //  .mark resumeLabel
                    //      _a[_b] = %sent%;
                    target = factory.updateElementAccessExpression(left, cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(left.expression, visitor, ts_js_1.isLeftHandSideExpression))), cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(left.argumentExpression, visitor, ts_js_1.isExpression))));
                    break;
                default:
                    target = ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(left, visitor, ts_js_1.isExpression));
                    break;
            }
            const operator = node.operatorToken.kind;
            if ((0, ts_js_1.isCompoundAssignment)(operator)) {
                return (0, ts_js_1.setTextRange)(factory.createAssignment(target, (0, ts_js_1.setTextRange)(factory.createBinaryExpression(cacheExpression(target), (0, ts_js_1.getNonAssignmentOperatorForCompoundAssignment)(operator), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(right, visitor, ts_js_1.isExpression))), node)), node);
            }
            else {
                return factory.updateBinaryExpression(node, target, node.operatorToken, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(right, visitor, ts_js_1.isExpression)));
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitLeftAssociativeBinaryExpression(node) {
        if (containsYield(node.right)) {
            if ((0, ts_js_1.isLogicalOperator)(node.operatorToken.kind)) {
                return visitLogicalBinaryExpression(node);
            }
            else if (node.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
                return visitCommaExpression(node);
            }
            // [source]
            //      a() + (yield) + c()
            //
            // [intermediate]
            //  .local _a
            //      _a = a();
            //  .yield resumeLabel
            //      _a + %sent% + c()
            return factory.updateBinaryExpression(node, cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.left, visitor, ts_js_1.isExpression))), node.operatorToken, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.right, visitor, ts_js_1.isExpression)));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Visits a comma expression containing `yield`.
     *
     * @param node The node to visit.
     */
    function visitCommaExpression(node) {
        // [source]
        //      x = a(), yield, b();
        //
        // [intermediate]
        //      a();
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      x = %sent%, b();
        let pendingExpressions = [];
        visit(node.left);
        visit(node.right);
        return factory.inlineExpressions(pendingExpressions);
        function visit(node) {
            if ((0, ts_js_1.isBinaryExpression)(node) && node.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
                visit(node.left);
                visit(node.right);
            }
            else {
                if (containsYield(node) && pendingExpressions.length > 0) {
                    emitWorker(1 /* OpCode.Statement */, [factory.createExpressionStatement(factory.inlineExpressions(pendingExpressions))]);
                    pendingExpressions = [];
                }
                pendingExpressions.push(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isExpression)));
            }
        }
    }
    /**
     * Visits a comma-list expression.
     *
     * @param node The node to visit.
     */
    function visitCommaListExpression(node) {
        // flattened version of `visitCommaExpression`
        let pendingExpressions = [];
        for (const elem of node.elements) {
            if ((0, ts_js_1.isBinaryExpression)(elem) && elem.operatorToken.kind === 28 /* SyntaxKind.CommaToken */) {
                pendingExpressions.push(visitCommaExpression(elem));
            }
            else {
                if (containsYield(elem) && pendingExpressions.length > 0) {
                    emitWorker(1 /* OpCode.Statement */, [factory.createExpressionStatement(factory.inlineExpressions(pendingExpressions))]);
                    pendingExpressions = [];
                }
                pendingExpressions.push(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(elem, visitor, ts_js_1.isExpression)));
            }
        }
        return factory.inlineExpressions(pendingExpressions);
    }
    /**
     * Visits a logical binary expression containing `yield`.
     *
     * @param node A node to visit.
     */
    function visitLogicalBinaryExpression(node) {
        // Logical binary expressions (`&&` and `||`) are shortcutting expressions and need
        // to be transformed as such:
        //
        // [source]
        //      x = a() && yield;
        //
        // [intermediate]
        //  .local _a
        //      _a = a();
        //  .brfalse resultLabel, (_a)
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      _a = %sent%;
        //  .mark resultLabel
        //      x = _a;
        //
        // [source]
        //      x = a() || yield;
        //
        // [intermediate]
        //  .local _a
        //      _a = a();
        //  .brtrue resultLabel, (_a)
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      _a = %sent%;
        //  .mark resultLabel
        //      x = _a;
        const resultLabel = defineLabel();
        const resultLocal = declareLocal();
        emitAssignment(resultLocal, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.left, visitor, ts_js_1.isExpression)), /*location*/ node.left);
        if (node.operatorToken.kind === 56 /* SyntaxKind.AmpersandAmpersandToken */) {
            // Logical `&&` shortcuts when the left-hand operand is falsey.
            emitBreakWhenFalse(resultLabel, resultLocal, /*location*/ node.left);
        }
        else {
            // Logical `||` shortcuts when the left-hand operand is truthy.
            emitBreakWhenTrue(resultLabel, resultLocal, /*location*/ node.left);
        }
        emitAssignment(resultLocal, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.right, visitor, ts_js_1.isExpression)), /*location*/ node.right);
        markLabel(resultLabel);
        return resultLocal;
    }
    /**
     * Visits a conditional expression containing `yield`.
     *
     * @param node The node to visit.
     */
    function visitConditionalExpression(node) {
        // [source]
        //      x = a() ? yield : b();
        //
        // [intermediate]
        //  .local _a
        //  .brfalse whenFalseLabel, (a())
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      _a = %sent%;
        //  .br resultLabel
        //  .mark whenFalseLabel
        //      _a = b();
        //  .mark resultLabel
        //      x = _a;
        // We only need to perform a specific transformation if a `yield` expression exists
        // in either the `whenTrue` or `whenFalse` branches.
        // A `yield` in the condition will be handled by the normal visitor.
        if (containsYield(node.whenTrue) || containsYield(node.whenFalse)) {
            const whenFalseLabel = defineLabel();
            const resultLabel = defineLabel();
            const resultLocal = declareLocal();
            emitBreakWhenFalse(whenFalseLabel, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression)), /*location*/ node.condition);
            emitAssignment(resultLocal, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.whenTrue, visitor, ts_js_1.isExpression)), /*location*/ node.whenTrue);
            emitBreak(resultLabel);
            markLabel(whenFalseLabel);
            emitAssignment(resultLocal, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.whenFalse, visitor, ts_js_1.isExpression)), /*location*/ node.whenFalse);
            markLabel(resultLabel);
            return resultLocal;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Visits a `yield` expression.
     *
     * @param node The node to visit.
     */
    function visitYieldExpression(node) {
        // [source]
        //      x = yield a();
        //
        // [intermediate]
        //  .yield resumeLabel, (a())
        //  .mark resumeLabel
        //      x = %sent%;
        const resumeLabel = defineLabel();
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        if (node.asteriskToken) {
            // NOTE: `expression` must be defined for `yield*`.
            const iterator = ((0, ts_js_1.getEmitFlags)(node.expression) & 8388608 /* EmitFlags.Iterator */) === 0
                ? (0, ts_js_1.setTextRange)(emitHelpers().createValuesHelper(expression), node)
                : expression;
            emitYieldStar(iterator, /*location*/ node);
        }
        else {
            emitYield(expression, /*location*/ node);
        }
        markLabel(resumeLabel);
        return createGeneratorResume(/*location*/ node);
    }
    /**
     * Visits an ArrayLiteralExpression that contains a YieldExpression.
     *
     * @param node The node to visit.
     */
    function visitArrayLiteralExpression(node) {
        return visitElements(node.elements, /*leadingElement*/ undefined, /*location*/ undefined, node.multiLine);
    }
    /**
     * Visits an array of expressions containing one or more YieldExpression nodes
     * and returns an expression for the resulting value.
     *
     * @param elements The elements to visit.
     * @param multiLine Whether array literals created should be emitted on multiple lines.
     */
    function visitElements(elements, leadingElement, location, multiLine) {
        // [source]
        //      ar = [1, yield, 2];
        //
        // [intermediate]
        //  .local _a
        //      _a = [1];
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      ar = _a.concat([%sent%, 2]);
        const numInitialElements = countInitialNodesWithoutYield(elements);
        let temp;
        if (numInitialElements > 0) {
            temp = declareLocal();
            const initialElements = (0, ts_js_1.visitNodes)(elements, visitor, ts_js_1.isExpression, 0, numInitialElements);
            emitAssignment(temp, factory.createArrayLiteralExpression(leadingElement
                ? [leadingElement, ...initialElements]
                : initialElements));
            leadingElement = undefined;
        }
        const expressions = (0, ts_js_1.reduceLeft)(elements, reduceElement, [], numInitialElements);
        return temp
            ? factory.createArrayConcatCall(temp, [factory.createArrayLiteralExpression(expressions, multiLine)])
            : (0, ts_js_1.setTextRange)(factory.createArrayLiteralExpression(leadingElement ? [leadingElement, ...expressions] : expressions, multiLine), location);
        function reduceElement(expressions, element) {
            if (containsYield(element) && expressions.length > 0) {
                const hasAssignedTemp = temp !== undefined;
                if (!temp) {
                    temp = declareLocal();
                }
                emitAssignment(temp, hasAssignedTemp
                    ? factory.createArrayConcatCall(temp, [factory.createArrayLiteralExpression(expressions, multiLine)])
                    : factory.createArrayLiteralExpression(leadingElement ? [leadingElement, ...expressions] : expressions, multiLine));
                leadingElement = undefined;
                expressions = [];
            }
            expressions.push(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(element, visitor, ts_js_1.isExpression)));
            return expressions;
        }
    }
    function visitObjectLiteralExpression(node) {
        // [source]
        //      o = {
        //          a: 1,
        //          b: yield,
        //          c: 2
        //      };
        //
        // [intermediate]
        //  .local _a
        //      _a = {
        //          a: 1
        //      };
        //  .yield resumeLabel
        //  .mark resumeLabel
        //      o = (_a.b = %sent%,
        //          _a.c = 2,
        //          _a);
        const properties = node.properties;
        const multiLine = node.multiLine;
        const numInitialProperties = countInitialNodesWithoutYield(properties);
        const temp = declareLocal();
        emitAssignment(temp, factory.createObjectLiteralExpression((0, ts_js_1.visitNodes)(properties, visitor, ts_js_1.isObjectLiteralElementLike, 0, numInitialProperties), multiLine));
        const expressions = (0, ts_js_1.reduceLeft)(properties, reduceProperty, [], numInitialProperties);
        // TODO(rbuckton): Does this need to be parented?
        expressions.push(multiLine ? (0, ts_js_1.startOnNewLine)((0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(temp), temp), temp.parent)) : temp);
        return factory.inlineExpressions(expressions);
        function reduceProperty(expressions, property) {
            if (containsYield(property) && expressions.length > 0) {
                emitStatement(factory.createExpressionStatement(factory.inlineExpressions(expressions)));
                expressions = [];
            }
            const expression = (0, ts_js_1.createExpressionForObjectLiteralElementLike)(factory, node, property, temp);
            const visited = (0, ts_js_1.visitNode)(expression, visitor, ts_js_1.isExpression);
            if (visited) {
                if (multiLine) {
                    (0, ts_js_1.startOnNewLine)(visited);
                }
                expressions.push(visited);
            }
            return expressions;
        }
    }
    /**
     * Visits an ElementAccessExpression that contains a YieldExpression.
     *
     * @param node The node to visit.
     */
    function visitElementAccessExpression(node) {
        if (containsYield(node.argumentExpression)) {
            // [source]
            //      a = x[yield];
            //
            // [intermediate]
            //  .local _a
            //      _a = x;
            //  .yield resumeLabel
            //  .mark resumeLabel
            //      a = _a[%sent%]
            return factory.updateElementAccessExpression(node, cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isLeftHandSideExpression))), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.argumentExpression, visitor, ts_js_1.isExpression)));
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitCallExpression(node) {
        if (!(0, ts_js_1.isImportCall)(node) && (0, ts_js_1.forEach)(node.arguments, containsYield)) {
            // [source]
            //      a.b(1, yield, 2);
            //
            // [intermediate]
            //  .local _a, _b, _c
            //      _b = (_a = a).b;
            //      _c = [1];
            //  .yield resumeLabel
            //  .mark resumeLabel
            //      _b.apply(_a, _c.concat([%sent%, 2]));
            const { target, thisArg } = factory.createCallBinding(node.expression, hoistVariableDeclaration, languageVersion, /*cacheIdentifiers*/ true);
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createFunctionApplyCall(cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(target, visitor, ts_js_1.isLeftHandSideExpression))), thisArg, visitElements(node.arguments)), node), node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitNewExpression(node) {
        if ((0, ts_js_1.forEach)(node.arguments, containsYield)) {
            // [source]
            //      new a.b(1, yield, 2);
            //
            // [intermediate]
            //  .local _a, _b, _c
            //      _b = (_a = a.b).bind;
            //      _c = [1];
            //  .yield resumeLabel
            //  .mark resumeLabel
            //      new (_b.apply(_a, _c.concat([%sent%, 2])));
            const { target, thisArg } = factory.createCallBinding(factory.createPropertyAccessExpression(node.expression, "bind"), hoistVariableDeclaration);
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createNewExpression(factory.createFunctionApplyCall(cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(target, visitor, ts_js_1.isExpression))), thisArg, visitElements(node.arguments, 
            /*leadingElement*/ factory.createVoidZero())), 
            /*typeArguments*/ undefined, []), node), node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function transformAndEmitStatements(statements, start = 0) {
        const numStatements = statements.length;
        for (let i = start; i < numStatements; i++) {
            transformAndEmitStatement(statements[i]);
        }
    }
    function transformAndEmitEmbeddedStatement(node) {
        if ((0, ts_js_1.isBlock)(node)) {
            transformAndEmitStatements(node.statements);
        }
        else {
            transformAndEmitStatement(node);
        }
    }
    function transformAndEmitStatement(node) {
        const savedInStatementContainingYield = inStatementContainingYield;
        if (!inStatementContainingYield) {
            inStatementContainingYield = containsYield(node);
        }
        transformAndEmitStatementWorker(node);
        inStatementContainingYield = savedInStatementContainingYield;
    }
    function transformAndEmitStatementWorker(node) {
        switch (node.kind) {
            case 242 /* SyntaxKind.Block */:
                return transformAndEmitBlock(node);
            case 245 /* SyntaxKind.ExpressionStatement */:
                return transformAndEmitExpressionStatement(node);
            case 246 /* SyntaxKind.IfStatement */:
                return transformAndEmitIfStatement(node);
            case 247 /* SyntaxKind.DoStatement */:
                return transformAndEmitDoStatement(node);
            case 248 /* SyntaxKind.WhileStatement */:
                return transformAndEmitWhileStatement(node);
            case 249 /* SyntaxKind.ForStatement */:
                return transformAndEmitForStatement(node);
            case 250 /* SyntaxKind.ForInStatement */:
                return transformAndEmitForInStatement(node);
            case 252 /* SyntaxKind.ContinueStatement */:
                return transformAndEmitContinueStatement(node);
            case 253 /* SyntaxKind.BreakStatement */:
                return transformAndEmitBreakStatement(node);
            case 254 /* SyntaxKind.ReturnStatement */:
                return transformAndEmitReturnStatement(node);
            case 255 /* SyntaxKind.WithStatement */:
                return transformAndEmitWithStatement(node);
            case 256 /* SyntaxKind.SwitchStatement */:
                return transformAndEmitSwitchStatement(node);
            case 257 /* SyntaxKind.LabeledStatement */:
                return transformAndEmitLabeledStatement(node);
            case 258 /* SyntaxKind.ThrowStatement */:
                return transformAndEmitThrowStatement(node);
            case 259 /* SyntaxKind.TryStatement */:
                return transformAndEmitTryStatement(node);
            default:
                return emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function transformAndEmitBlock(node) {
        if (containsYield(node)) {
            transformAndEmitStatements(node.statements);
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function transformAndEmitExpressionStatement(node) {
        emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
    }
    function transformAndEmitVariableDeclarationList(node) {
        for (const variable of node.declarations) {
            const name = factory.cloneNode(variable.name);
            (0, ts_js_1.setCommentRange)(name, variable.name);
            hoistVariableDeclaration(name);
        }
        const variables = (0, ts_js_1.getInitializedVariables)(node);
        const numVariables = variables.length;
        let variablesWritten = 0;
        let pendingExpressions = [];
        while (variablesWritten < numVariables) {
            for (let i = variablesWritten; i < numVariables; i++) {
                const variable = variables[i];
                if (containsYield(variable.initializer) && pendingExpressions.length > 0) {
                    break;
                }
                pendingExpressions.push(transformInitializedVariable(variable));
            }
            if (pendingExpressions.length) {
                emitStatement(factory.createExpressionStatement(factory.inlineExpressions(pendingExpressions)));
                variablesWritten += pendingExpressions.length;
                pendingExpressions = [];
            }
        }
        return undefined;
    }
    function transformInitializedVariable(node) {
        return (0, ts_js_1.setSourceMapRange)(factory.createAssignment((0, ts_js_1.setSourceMapRange)(factory.cloneNode(node.name), node.name), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression))), node);
    }
    function transformAndEmitIfStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      if (x)
            //          /*thenStatement*/
            //      else
            //          /*elseStatement*/
            //
            // [intermediate]
            //  .brfalse elseLabel, (x)
            //      /*thenStatement*/
            //  .br endLabel
            //  .mark elseLabel
            //      /*elseStatement*/
            //  .mark endLabel
            if (containsYield(node.thenStatement) || containsYield(node.elseStatement)) {
                const endLabel = defineLabel();
                const elseLabel = node.elseStatement ? defineLabel() : undefined;
                emitBreakWhenFalse(node.elseStatement ? elseLabel : endLabel, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), /*location*/ node.expression);
                transformAndEmitEmbeddedStatement(node.thenStatement);
                if (node.elseStatement) {
                    emitBreak(endLabel);
                    markLabel(elseLabel);
                    transformAndEmitEmbeddedStatement(node.elseStatement);
                }
                markLabel(endLabel);
            }
            else {
                emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
            }
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function transformAndEmitDoStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      do {
            //          /*body*/
            //      }
            //      while (i < 10);
            //
            // [intermediate]
            //  .loop conditionLabel, endLabel
            //  .mark loopLabel
            //      /*body*/
            //  .mark conditionLabel
            //  .brtrue loopLabel, (i < 10)
            //  .endloop
            //  .mark endLabel
            const conditionLabel = defineLabel();
            const loopLabel = defineLabel();
            beginLoopBlock(/*continueLabel*/ conditionLabel);
            markLabel(loopLabel);
            transformAndEmitEmbeddedStatement(node.statement);
            markLabel(conditionLabel);
            emitBreakWhenTrue(loopLabel, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)));
            endLoopBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitDoStatement(node) {
        if (inStatementContainingYield) {
            beginScriptLoopBlock();
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
            endLoopBlock();
            return node;
        }
        else {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function transformAndEmitWhileStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      while (i < 10) {
            //          /*body*/
            //      }
            //
            // [intermediate]
            //  .loop loopLabel, endLabel
            //  .mark loopLabel
            //  .brfalse endLabel, (i < 10)
            //      /*body*/
            //  .br loopLabel
            //  .endloop
            //  .mark endLabel
            const loopLabel = defineLabel();
            const endLabel = beginLoopBlock(loopLabel);
            markLabel(loopLabel);
            emitBreakWhenFalse(endLabel, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)));
            transformAndEmitEmbeddedStatement(node.statement);
            emitBreak(loopLabel);
            endLoopBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitWhileStatement(node) {
        if (inStatementContainingYield) {
            beginScriptLoopBlock();
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
            endLoopBlock();
            return node;
        }
        else {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function transformAndEmitForStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      for (var i = 0; i < 10; i++) {
            //          /*body*/
            //      }
            //
            // [intermediate]
            //  .local i
            //      i = 0;
            //  .loop incrementLabel, endLoopLabel
            //  .mark conditionLabel
            //  .brfalse endLoopLabel, (i < 10)
            //      /*body*/
            //  .mark incrementLabel
            //      i++;
            //  .br conditionLabel
            //  .endloop
            //  .mark endLoopLabel
            const conditionLabel = defineLabel();
            const incrementLabel = defineLabel();
            const endLabel = beginLoopBlock(incrementLabel);
            if (node.initializer) {
                const initializer = node.initializer;
                if ((0, ts_js_1.isVariableDeclarationList)(initializer)) {
                    transformAndEmitVariableDeclarationList(initializer);
                }
                else {
                    emitStatement((0, ts_js_1.setTextRange)(factory.createExpressionStatement(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(initializer, visitor, ts_js_1.isExpression))), initializer));
                }
            }
            markLabel(conditionLabel);
            if (node.condition) {
                emitBreakWhenFalse(endLabel, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression)));
            }
            transformAndEmitEmbeddedStatement(node.statement);
            markLabel(incrementLabel);
            if (node.incrementor) {
                emitStatement((0, ts_js_1.setTextRange)(factory.createExpressionStatement(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.incrementor, visitor, ts_js_1.isExpression))), node.incrementor));
            }
            emitBreak(conditionLabel);
            endLoopBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitForStatement(node) {
        if (inStatementContainingYield) {
            beginScriptLoopBlock();
        }
        const initializer = node.initializer;
        if (initializer && (0, ts_js_1.isVariableDeclarationList)(initializer)) {
            for (const variable of initializer.declarations) {
                hoistVariableDeclaration(variable.name);
            }
            const variables = (0, ts_js_1.getInitializedVariables)(initializer);
            node = factory.updateForStatement(node, variables.length > 0
                ? factory.inlineExpressions((0, ts_js_1.map)(variables, transformInitializedVariable))
                : undefined, (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, visitor, context));
        }
        else {
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        if (inStatementContainingYield) {
            endLoopBlock();
        }
        return node;
    }
    function transformAndEmitForInStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      for (var p in o) {
            //          /*body*/
            //      }
            //
            // [intermediate]
            //  .local _b, _a, _c, _i
            //      _b = [];
            //      _a = o;
            //      for (_c in _a) _b.push(_c);
            //      _i = 0;
            //  .loop incrementLabel, endLoopLabel
            //  .mark conditionLabel
            //  .brfalse endLoopLabel, (_i < _b.length)
            //      _c = _b[_i];
            //  .brfalse incrementLabel, (_c in _a)
            //      p = _c;
            //      /*body*/
            //  .mark incrementLabel
            //      _c++;
            //  .br conditionLabel
            //  .endloop
            //  .mark endLoopLabel
            const obj = declareLocal(); // _a
            const keysArray = declareLocal(); // _b
            const key = declareLocal(); // _c
            const keysIndex = factory.createLoopVariable(); // _i
            const initializer = node.initializer;
            hoistVariableDeclaration(keysIndex);
            emitAssignment(obj, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)));
            emitAssignment(keysArray, factory.createArrayLiteralExpression());
            emitStatement(factory.createForInStatement(key, obj, factory.createExpressionStatement(factory.createCallExpression(factory.createPropertyAccessExpression(keysArray, "push"), 
            /*typeArguments*/ undefined, [key]))));
            emitAssignment(keysIndex, factory.createNumericLiteral(0));
            const conditionLabel = defineLabel();
            const incrementLabel = defineLabel();
            const endLoopLabel = beginLoopBlock(incrementLabel);
            markLabel(conditionLabel);
            emitBreakWhenFalse(endLoopLabel, factory.createLessThan(keysIndex, factory.createPropertyAccessExpression(keysArray, "length")));
            emitAssignment(key, factory.createElementAccessExpression(keysArray, keysIndex));
            emitBreakWhenFalse(incrementLabel, factory.createBinaryExpression(key, 103 /* SyntaxKind.InKeyword */, obj));
            let variable;
            if ((0, ts_js_1.isVariableDeclarationList)(initializer)) {
                for (const variable of initializer.declarations) {
                    hoistVariableDeclaration(variable.name);
                }
                variable = factory.cloneNode(initializer.declarations[0].name);
            }
            else {
                variable = ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(initializer, visitor, ts_js_1.isExpression));
                ts_js_1.Debug.assert((0, ts_js_1.isLeftHandSideExpression)(variable));
            }
            emitAssignment(variable, key);
            transformAndEmitEmbeddedStatement(node.statement);
            markLabel(incrementLabel);
            emitStatement(factory.createExpressionStatement(factory.createPostfixIncrement(keysIndex)));
            emitBreak(conditionLabel);
            endLoopBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitForInStatement(node) {
        // [source]
        //      for (var x in a) {
        //          /*body*/
        //      }
        //
        // [intermediate]
        //  .local x
        //  .loop
        //      for (x in a) {
        //          /*body*/
        //      }
        //  .endloop
        if (inStatementContainingYield) {
            beginScriptLoopBlock();
        }
        const initializer = node.initializer;
        if ((0, ts_js_1.isVariableDeclarationList)(initializer)) {
            for (const variable of initializer.declarations) {
                hoistVariableDeclaration(variable.name);
            }
            node = factory.updateForInStatement(node, initializer.declarations[0].name, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.statement, visitor, ts_js_1.isStatement, factory.liftToBlock)));
        }
        else {
            node = (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        if (inStatementContainingYield) {
            endLoopBlock();
        }
        return node;
    }
    function transformAndEmitContinueStatement(node) {
        const label = findContinueTarget(node.label ? (0, ts_js_1.idText)(node.label) : undefined);
        if (label > 0) {
            emitBreak(label, /*location*/ node);
        }
        else {
            // invalid continue without a containing loop. Leave the node as is, per #17875.
            emitStatement(node);
        }
    }
    function visitContinueStatement(node) {
        if (inStatementContainingYield) {
            const label = findContinueTarget(node.label && (0, ts_js_1.idText)(node.label));
            if (label > 0) {
                return createInlineBreak(label, /*location*/ node);
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function transformAndEmitBreakStatement(node) {
        const label = findBreakTarget(node.label ? (0, ts_js_1.idText)(node.label) : undefined);
        if (label > 0) {
            emitBreak(label, /*location*/ node);
        }
        else {
            // invalid break without a containing loop, switch, or labeled statement. Leave the node as is, per #17875.
            emitStatement(node);
        }
    }
    function visitBreakStatement(node) {
        if (inStatementContainingYield) {
            const label = findBreakTarget(node.label && (0, ts_js_1.idText)(node.label));
            if (label > 0) {
                return createInlineBreak(label, /*location*/ node);
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function transformAndEmitReturnStatement(node) {
        emitReturn((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), 
        /*location*/ node);
    }
    function visitReturnStatement(node) {
        return createInlineReturn((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), 
        /*location*/ node);
    }
    function transformAndEmitWithStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      with (x) {
            //          /*body*/
            //      }
            //
            // [intermediate]
            //  .with (x)
            //      /*body*/
            //  .endwith
            beginWithBlock(cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression))));
            transformAndEmitEmbeddedStatement(node.statement);
            endWithBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function transformAndEmitSwitchStatement(node) {
        if (containsYield(node.caseBlock)) {
            // [source]
            //      switch (x) {
            //          case a:
            //              /*caseStatements*/
            //          case b:
            //              /*caseStatements*/
            //          default:
            //              /*defaultStatements*/
            //      }
            //
            // [intermediate]
            //  .local _a
            //  .switch endLabel
            //      _a = x;
            //      switch (_a) {
            //          case a:
            //  .br clauseLabels[0]
            //      }
            //      switch (_a) {
            //          case b:
            //  .br clauseLabels[1]
            //      }
            //  .br clauseLabels[2]
            //  .mark clauseLabels[0]
            //      /*caseStatements*/
            //  .mark clauseLabels[1]
            //      /*caseStatements*/
            //  .mark clauseLabels[2]
            //      /*caseStatements*/
            //  .endswitch
            //  .mark endLabel
            const caseBlock = node.caseBlock;
            const numClauses = caseBlock.clauses.length;
            const endLabel = beginSwitchBlock();
            const expression = cacheExpression(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)));
            // Create labels for each clause and find the index of the first default clause.
            const clauseLabels = [];
            let defaultClauseIndex = -1;
            for (let i = 0; i < numClauses; i++) {
                const clause = caseBlock.clauses[i];
                clauseLabels.push(defineLabel());
                if (clause.kind === 298 /* SyntaxKind.DefaultClause */ && defaultClauseIndex === -1) {
                    defaultClauseIndex = i;
                }
            }
            // Emit switch statements for each run of case clauses either from the first case
            // clause or the next case clause with a `yield` in its expression, up to the next
            // case clause with a `yield` in its expression.
            let clausesWritten = 0;
            let pendingClauses = [];
            while (clausesWritten < numClauses) {
                let defaultClausesSkipped = 0;
                for (let i = clausesWritten; i < numClauses; i++) {
                    const clause = caseBlock.clauses[i];
                    if (clause.kind === 297 /* SyntaxKind.CaseClause */) {
                        if (containsYield(clause.expression) && pendingClauses.length > 0) {
                            break;
                        }
                        pendingClauses.push(factory.createCaseClause(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(clause.expression, visitor, ts_js_1.isExpression)), [
                            createInlineBreak(clauseLabels[i], /*location*/ clause.expression),
                        ]));
                    }
                    else {
                        defaultClausesSkipped++;
                    }
                }
                if (pendingClauses.length) {
                    emitStatement(factory.createSwitchStatement(expression, factory.createCaseBlock(pendingClauses)));
                    clausesWritten += pendingClauses.length;
                    pendingClauses = [];
                }
                if (defaultClausesSkipped > 0) {
                    clausesWritten += defaultClausesSkipped;
                    defaultClausesSkipped = 0;
                }
            }
            if (defaultClauseIndex >= 0) {
                emitBreak(clauseLabels[defaultClauseIndex]);
            }
            else {
                emitBreak(endLabel);
            }
            for (let i = 0; i < numClauses; i++) {
                markLabel(clauseLabels[i]);
                transformAndEmitStatements(caseBlock.clauses[i].statements);
            }
            endSwitchBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitSwitchStatement(node) {
        if (inStatementContainingYield) {
            beginScriptSwitchBlock();
        }
        node = (0, ts_js_1.visitEachChild)(node, visitor, context);
        if (inStatementContainingYield) {
            endSwitchBlock();
        }
        return node;
    }
    function transformAndEmitLabeledStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      x: {
            //          /*body*/
            //      }
            //
            // [intermediate]
            //  .labeled "x", endLabel
            //      /*body*/
            //  .endlabeled
            //  .mark endLabel
            beginLabeledBlock((0, ts_js_1.idText)(node.label));
            transformAndEmitEmbeddedStatement(node.statement);
            endLabeledBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement));
        }
    }
    function visitLabeledStatement(node) {
        if (inStatementContainingYield) {
            beginScriptLabeledBlock((0, ts_js_1.idText)(node.label));
        }
        node = (0, ts_js_1.visitEachChild)(node, visitor, context);
        if (inStatementContainingYield) {
            endLabeledBlock();
        }
        return node;
    }
    function transformAndEmitThrowStatement(node) {
        // TODO(rbuckton): `expression` should be required on `throw`.
        emitThrow(ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression ?? factory.createVoidZero(), visitor, ts_js_1.isExpression)), 
        /*location*/ node);
    }
    function transformAndEmitTryStatement(node) {
        if (containsYield(node)) {
            // [source]
            //      try {
            //          /*tryBlock*/
            //      }
            //      catch (e) {
            //          /*catchBlock*/
            //      }
            //      finally {
            //          /*finallyBlock*/
            //      }
            //
            // [intermediate]
            //  .local _a
            //  .try tryLabel, catchLabel, finallyLabel, endLabel
            //  .mark tryLabel
            //  .nop
            //      /*tryBlock*/
            //  .br endLabel
            //  .catch
            //  .mark catchLabel
            //      _a = %error%;
            //      /*catchBlock*/
            //  .br endLabel
            //  .finally
            //  .mark finallyLabel
            //      /*finallyBlock*/
            //  .endfinally
            //  .endtry
            //  .mark endLabel
            beginExceptionBlock();
            transformAndEmitEmbeddedStatement(node.tryBlock);
            if (node.catchClause) {
                beginCatchBlock(node.catchClause.variableDeclaration); // TODO: GH#18217
                transformAndEmitEmbeddedStatement(node.catchClause.block);
            }
            if (node.finallyBlock) {
                beginFinallyBlock();
                transformAndEmitEmbeddedStatement(node.finallyBlock);
            }
            endExceptionBlock();
        }
        else {
            emitStatement((0, ts_js_1.visitEachChild)(node, visitor, context));
        }
    }
    function containsYield(node) {
        return !!node && (node.transformFlags & 1048576 /* TransformFlags.ContainsYield */) !== 0;
    }
    function countInitialNodesWithoutYield(nodes) {
        const numNodes = nodes.length;
        for (let i = 0; i < numNodes; i++) {
            if (containsYield(nodes[i])) {
                return i;
            }
        }
        return -1;
    }
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (hint === 1 /* EmitHint.Expression */) {
            return substituteExpression(node);
        }
        return node;
    }
    function substituteExpression(node) {
        if ((0, ts_js_1.isIdentifier)(node)) {
            return substituteExpressionIdentifier(node);
        }
        return node;
    }
    function substituteExpressionIdentifier(node) {
        if (!(0, ts_js_1.isGeneratedIdentifier)(node) && renamedCatchVariables && renamedCatchVariables.has((0, ts_js_1.idText)(node))) {
            const original = (0, ts_js_1.getOriginalNode)(node);
            if ((0, ts_js_1.isIdentifier)(original) && original.parent) {
                const declaration = resolver.getReferencedValueDeclaration(original);
                if (declaration) {
                    const name = renamedCatchVariableDeclarations[(0, ts_js_1.getOriginalNodeId)(declaration)];
                    if (name) {
                        // TODO(rbuckton): Does this need to be parented?
                        const clone = (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(name), name), name.parent);
                        (0, ts_js_1.setSourceMapRange)(clone, node);
                        (0, ts_js_1.setCommentRange)(clone, node);
                        return clone;
                    }
                }
            }
        }
        return node;
    }
    function cacheExpression(node) {
        if ((0, ts_js_1.isGeneratedIdentifier)(node) || (0, ts_js_1.getEmitFlags)(node) & 8192 /* EmitFlags.HelperName */) {
            return node;
        }
        const temp = factory.createTempVariable(hoistVariableDeclaration);
        emitAssignment(temp, node, /*location*/ node);
        return temp;
    }
    function declareLocal(name) {
        const temp = name
            ? factory.createUniqueName(name)
            : factory.createTempVariable(/*recordTempVariable*/ undefined);
        hoistVariableDeclaration(temp);
        return temp;
    }
    /**
     * Defines a label, uses as the target of a Break operation.
     */
    function defineLabel() {
        if (!labelOffsets) {
            labelOffsets = [];
        }
        const label = nextLabelId;
        nextLabelId++;
        labelOffsets[label] = -1;
        return label;
    }
    /**
     * Marks the current operation with the specified label.
     */
    function markLabel(label) {
        ts_js_1.Debug.assert(labelOffsets !== undefined, "No labels were defined.");
        labelOffsets[label] = operations ? operations.length : 0;
    }
    /**
     * Begins a block operation (With, Break/Continue, Try/Catch/Finally)
     *
     * @param block Information about the block.
     */
    function beginBlock(block) {
        if (!blocks) {
            blocks = [];
            blockActions = [];
            blockOffsets = [];
            blockStack = [];
        }
        const index = blockActions.length;
        blockActions[index] = 0 /* BlockAction.Open */;
        blockOffsets[index] = operations ? operations.length : 0;
        blocks[index] = block;
        blockStack.push(block);
        return index;
    }
    /**
     * Ends the current block operation.
     */
    function endBlock() {
        const block = peekBlock();
        if (block === undefined)
            return ts_js_1.Debug.fail("beginBlock was never called.");
        const index = blockActions.length;
        blockActions[index] = 1 /* BlockAction.Close */;
        blockOffsets[index] = operations ? operations.length : 0;
        blocks[index] = block;
        blockStack.pop();
        return block;
    }
    /**
     * Gets the current open block.
     */
    function peekBlock() {
        return (0, ts_js_1.lastOrUndefined)(blockStack);
    }
    /**
     * Gets the kind of the current open block.
     */
    function peekBlockKind() {
        const block = peekBlock();
        return block && block.kind;
    }
    /**
     * Begins a code block for a generated `with` statement.
     *
     * @param expression An identifier representing expression for the `with` block.
     */
    function beginWithBlock(expression) {
        const startLabel = defineLabel();
        const endLabel = defineLabel();
        markLabel(startLabel);
        beginBlock({
            kind: 1 /* CodeBlockKind.With */,
            expression,
            startLabel,
            endLabel,
        });
    }
    /**
     * Ends a code block for a generated `with` statement.
     */
    function endWithBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 1 /* CodeBlockKind.With */);
        const block = endBlock();
        markLabel(block.endLabel);
    }
    /**
     * Begins a code block for a generated `try` statement.
     */
    function beginExceptionBlock() {
        const startLabel = defineLabel();
        const endLabel = defineLabel();
        markLabel(startLabel);
        beginBlock({
            kind: 0 /* CodeBlockKind.Exception */,
            state: 0 /* ExceptionBlockState.Try */,
            startLabel,
            endLabel,
        });
        emitNop();
        return endLabel;
    }
    /**
     * Enters the `catch` clause of a generated `try` statement.
     *
     * @param variable The catch variable.
     */
    function beginCatchBlock(variable) {
        ts_js_1.Debug.assert(peekBlockKind() === 0 /* CodeBlockKind.Exception */);
        // generated identifiers should already be unique within a file
        let name;
        if ((0, ts_js_1.isGeneratedIdentifier)(variable.name)) {
            name = variable.name;
            hoistVariableDeclaration(variable.name);
        }
        else {
            const text = (0, ts_js_1.idText)(variable.name);
            name = declareLocal(text);
            if (!renamedCatchVariables) {
                renamedCatchVariables = new Map();
                renamedCatchVariableDeclarations = [];
                context.enableSubstitution(80 /* SyntaxKind.Identifier */);
            }
            renamedCatchVariables.set(text, true);
            renamedCatchVariableDeclarations[(0, ts_js_1.getOriginalNodeId)(variable)] = name;
        }
        const exception = peekBlock();
        ts_js_1.Debug.assert(exception.state < 1 /* ExceptionBlockState.Catch */);
        const endLabel = exception.endLabel;
        emitBreak(endLabel);
        const catchLabel = defineLabel();
        markLabel(catchLabel);
        exception.state = 1 /* ExceptionBlockState.Catch */;
        exception.catchVariable = name;
        exception.catchLabel = catchLabel;
        emitAssignment(name, factory.createCallExpression(factory.createPropertyAccessExpression(state, "sent"), /*typeArguments*/ undefined, []));
        emitNop();
    }
    /**
     * Enters the `finally` block of a generated `try` statement.
     */
    function beginFinallyBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 0 /* CodeBlockKind.Exception */);
        const exception = peekBlock();
        ts_js_1.Debug.assert(exception.state < 2 /* ExceptionBlockState.Finally */);
        const endLabel = exception.endLabel;
        emitBreak(endLabel);
        const finallyLabel = defineLabel();
        markLabel(finallyLabel);
        exception.state = 2 /* ExceptionBlockState.Finally */;
        exception.finallyLabel = finallyLabel;
    }
    /**
     * Ends the code block for a generated `try` statement.
     */
    function endExceptionBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 0 /* CodeBlockKind.Exception */);
        const exception = endBlock();
        const state = exception.state;
        if (state < 2 /* ExceptionBlockState.Finally */) {
            emitBreak(exception.endLabel);
        }
        else {
            emitEndfinally();
        }
        markLabel(exception.endLabel);
        emitNop();
        exception.state = 3 /* ExceptionBlockState.Done */;
    }
    /**
     * Begins a code block that supports `break` or `continue` statements that are defined in
     * the source tree and not from generated code.
     *
     * @param labelText Names from containing labeled statements.
     */
    function beginScriptLoopBlock() {
        beginBlock({
            kind: 3 /* CodeBlockKind.Loop */,
            isScript: true,
            breakLabel: -1,
            continueLabel: -1,
        });
    }
    /**
     * Begins a code block that supports `break` or `continue` statements that are defined in
     * generated code. Returns a label used to mark the operation to which to jump when a
     * `break` statement targets this block.
     *
     * @param continueLabel A Label used to mark the operation to which to jump when a
     *                      `continue` statement targets this block.
     */
    function beginLoopBlock(continueLabel) {
        const breakLabel = defineLabel();
        beginBlock({
            kind: 3 /* CodeBlockKind.Loop */,
            isScript: false,
            breakLabel,
            continueLabel,
        });
        return breakLabel;
    }
    /**
     * Ends a code block that supports `break` or `continue` statements that are defined in
     * generated code or in the source tree.
     */
    function endLoopBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 3 /* CodeBlockKind.Loop */);
        const block = endBlock();
        const breakLabel = block.breakLabel;
        if (!block.isScript) {
            markLabel(breakLabel);
        }
    }
    /**
     * Begins a code block that supports `break` statements that are defined in the source
     * tree and not from generated code.
     */
    function beginScriptSwitchBlock() {
        beginBlock({
            kind: 2 /* CodeBlockKind.Switch */,
            isScript: true,
            breakLabel: -1,
        });
    }
    /**
     * Begins a code block that supports `break` statements that are defined in generated code.
     * Returns a label used to mark the operation to which to jump when a `break` statement
     * targets this block.
     */
    function beginSwitchBlock() {
        const breakLabel = defineLabel();
        beginBlock({
            kind: 2 /* CodeBlockKind.Switch */,
            isScript: false,
            breakLabel,
        });
        return breakLabel;
    }
    /**
     * Ends a code block that supports `break` statements that are defined in generated code.
     */
    function endSwitchBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 2 /* CodeBlockKind.Switch */);
        const block = endBlock();
        const breakLabel = block.breakLabel;
        if (!block.isScript) {
            markLabel(breakLabel);
        }
    }
    function beginScriptLabeledBlock(labelText) {
        beginBlock({
            kind: 4 /* CodeBlockKind.Labeled */,
            isScript: true,
            labelText,
            breakLabel: -1,
        });
    }
    function beginLabeledBlock(labelText) {
        const breakLabel = defineLabel();
        beginBlock({
            kind: 4 /* CodeBlockKind.Labeled */,
            isScript: false,
            labelText,
            breakLabel,
        });
    }
    function endLabeledBlock() {
        ts_js_1.Debug.assert(peekBlockKind() === 4 /* CodeBlockKind.Labeled */);
        const block = endBlock();
        if (!block.isScript) {
            markLabel(block.breakLabel);
        }
    }
    /**
     * Indicates whether the provided block supports `break` statements.
     *
     * @param block A code block.
     */
    function supportsUnlabeledBreak(block) {
        return block.kind === 2 /* CodeBlockKind.Switch */
            || block.kind === 3 /* CodeBlockKind.Loop */;
    }
    /**
     * Indicates whether the provided block supports `break` statements with labels.
     *
     * @param block A code block.
     */
    function supportsLabeledBreakOrContinue(block) {
        return block.kind === 4 /* CodeBlockKind.Labeled */;
    }
    /**
     * Indicates whether the provided block supports `continue` statements.
     *
     * @param block A code block.
     */
    function supportsUnlabeledContinue(block) {
        return block.kind === 3 /* CodeBlockKind.Loop */;
    }
    function hasImmediateContainingLabeledBlock(labelText, start) {
        for (let j = start; j >= 0; j--) {
            const containingBlock = blockStack[j];
            if (supportsLabeledBreakOrContinue(containingBlock)) {
                if (containingBlock.labelText === labelText) {
                    return true;
                }
            }
            else {
                break;
            }
        }
        return false;
    }
    /**
     * Finds the label that is the target for a `break` statement.
     *
     * @param labelText An optional name of a containing labeled statement.
     */
    function findBreakTarget(labelText) {
        if (blockStack) {
            if (labelText) {
                for (let i = blockStack.length - 1; i >= 0; i--) {
                    const block = blockStack[i];
                    if (supportsLabeledBreakOrContinue(block) && block.labelText === labelText) {
                        return block.breakLabel;
                    }
                    else if (supportsUnlabeledBreak(block) && hasImmediateContainingLabeledBlock(labelText, i - 1)) {
                        return block.breakLabel;
                    }
                }
            }
            else {
                for (let i = blockStack.length - 1; i >= 0; i--) {
                    const block = blockStack[i];
                    if (supportsUnlabeledBreak(block)) {
                        return block.breakLabel;
                    }
                }
            }
        }
        return 0;
    }
    /**
     * Finds the label that is the target for a `continue` statement.
     *
     * @param labelText An optional name of a containing labeled statement.
     */
    function findContinueTarget(labelText) {
        if (blockStack) {
            if (labelText) {
                for (let i = blockStack.length - 1; i >= 0; i--) {
                    const block = blockStack[i];
                    if (supportsUnlabeledContinue(block) && hasImmediateContainingLabeledBlock(labelText, i - 1)) {
                        return block.continueLabel;
                    }
                }
            }
            else {
                for (let i = blockStack.length - 1; i >= 0; i--) {
                    const block = blockStack[i];
                    if (supportsUnlabeledContinue(block)) {
                        return block.continueLabel;
                    }
                }
            }
        }
        return 0;
    }
    /**
     * Creates an expression that can be used to indicate the value for a label.
     *
     * @param label A label.
     */
    function createLabel(label) {
        if (label !== undefined && label > 0) {
            if (labelExpressions === undefined) {
                labelExpressions = [];
            }
            const expression = factory.createNumericLiteral(Number.MAX_SAFE_INTEGER);
            if (labelExpressions[label] === undefined) {
                labelExpressions[label] = [expression];
            }
            else {
                labelExpressions[label].push(expression);
            }
            return expression;
        }
        return factory.createOmittedExpression();
    }
    /**
     * Creates a numeric literal for the provided instruction.
     */
    function createInstruction(instruction) {
        const literal = factory.createNumericLiteral(instruction);
        (0, ts_js_1.addSyntheticTrailingComment)(literal, 3 /* SyntaxKind.MultiLineCommentTrivia */, getInstructionName(instruction));
        return literal;
    }
    /**
     * Creates a statement that can be used indicate a Break operation to the provided label.
     *
     * @param label A label.
     * @param location An optional source map location for the statement.
     */
    function createInlineBreak(label, location) {
        ts_js_1.Debug.assertLessThan(0, label, "Invalid label");
        return (0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(3 /* Instruction.Break */),
            createLabel(label),
        ])), location);
    }
    /**
     * Creates a statement that can be used indicate a Return operation.
     *
     * @param expression The expression for the return statement.
     * @param location An optional source map location for the statement.
     */
    function createInlineReturn(expression, location) {
        return (0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression(expression
            ? [createInstruction(2 /* Instruction.Return */), expression]
            : [createInstruction(2 /* Instruction.Return */)])), location);
    }
    /**
     * Creates an expression that can be used to resume from a Yield operation.
     */
    function createGeneratorResume(location) {
        return (0, ts_js_1.setTextRange)(factory.createCallExpression(factory.createPropertyAccessExpression(state, "sent"), 
        /*typeArguments*/ undefined, []), location);
    }
    /**
     * Emits an empty instruction.
     */
    function emitNop() {
        emitWorker(0 /* OpCode.Nop */);
    }
    /**
     * Emits a Statement.
     *
     * @param node A statement.
     */
    function emitStatement(node) {
        if (node) {
            emitWorker(1 /* OpCode.Statement */, [node]);
        }
        else {
            emitNop();
        }
    }
    /**
     * Emits an Assignment operation.
     *
     * @param left The left-hand side of the assignment.
     * @param right The right-hand side of the assignment.
     * @param location An optional source map location for the assignment.
     */
    function emitAssignment(left, right, location) {
        emitWorker(2 /* OpCode.Assign */, [left, right], location);
    }
    /**
     * Emits a Break operation to the specified label.
     *
     * @param label A label.
     * @param location An optional source map location for the assignment.
     */
    function emitBreak(label, location) {
        emitWorker(3 /* OpCode.Break */, [label], location);
    }
    /**
     * Emits a Break operation to the specified label when a condition evaluates to a truthy
     * value at runtime.
     *
     * @param label A label.
     * @param condition The condition.
     * @param location An optional source map location for the assignment.
     */
    function emitBreakWhenTrue(label, condition, location) {
        emitWorker(4 /* OpCode.BreakWhenTrue */, [label, condition], location);
    }
    /**
     * Emits a Break to the specified label when a condition evaluates to a falsey value at
     * runtime.
     *
     * @param label A label.
     * @param condition The condition.
     * @param location An optional source map location for the assignment.
     */
    function emitBreakWhenFalse(label, condition, location) {
        emitWorker(5 /* OpCode.BreakWhenFalse */, [label, condition], location);
    }
    /**
     * Emits a YieldStar operation for the provided expression.
     *
     * @param expression An optional value for the yield operation.
     * @param location An optional source map location for the assignment.
     */
    function emitYieldStar(expression, location) {
        emitWorker(7 /* OpCode.YieldStar */, [expression], location);
    }
    /**
     * Emits a Yield operation for the provided expression.
     *
     * @param expression An optional value for the yield operation.
     * @param location An optional source map location for the assignment.
     */
    function emitYield(expression, location) {
        emitWorker(6 /* OpCode.Yield */, [expression], location);
    }
    /**
     * Emits a Return operation for the provided expression.
     *
     * @param expression An optional value for the operation.
     * @param location An optional source map location for the assignment.
     */
    function emitReturn(expression, location) {
        emitWorker(8 /* OpCode.Return */, [expression], location);
    }
    /**
     * Emits a Throw operation for the provided expression.
     *
     * @param expression A value for the operation.
     * @param location An optional source map location for the assignment.
     */
    function emitThrow(expression, location) {
        emitWorker(9 /* OpCode.Throw */, [expression], location);
    }
    /**
     * Emits an Endfinally operation. This is used to handle `finally` block semantics.
     */
    function emitEndfinally() {
        emitWorker(10 /* OpCode.Endfinally */);
    }
    /**
     * Emits an operation.
     *
     * @param code The OpCode for the operation.
     * @param args The optional arguments for the operation.
     */
    function emitWorker(code, args, location) {
        if (operations === undefined) {
            operations = [];
            operationArguments = [];
            operationLocations = [];
        }
        if (labelOffsets === undefined) {
            // mark entry point
            markLabel(defineLabel());
        }
        const operationIndex = operations.length;
        operations[operationIndex] = code;
        operationArguments[operationIndex] = args;
        operationLocations[operationIndex] = location;
    }
    /**
     * Builds the generator function body.
     */
    function build() {
        blockIndex = 0;
        labelNumber = 0;
        labelNumbers = undefined;
        lastOperationWasAbrupt = false;
        lastOperationWasCompletion = false;
        clauses = undefined;
        statements = undefined;
        exceptionBlockStack = undefined;
        currentExceptionBlock = undefined;
        withBlockStack = undefined;
        const buildResult = buildStatements();
        return emitHelpers().createGeneratorHelper((0, ts_js_1.setEmitFlags)(factory.createFunctionExpression(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, state)], 
        /*type*/ undefined, factory.createBlock(buildResult, 
        /*multiLine*/ buildResult.length > 0)), 1048576 /* EmitFlags.ReuseTempVariableScope */));
    }
    /**
     * Builds the statements for the generator function body.
     */
    function buildStatements() {
        if (operations) {
            for (let operationIndex = 0; operationIndex < operations.length; operationIndex++) {
                writeOperation(operationIndex);
            }
            flushFinalLabel(operations.length);
        }
        else {
            flushFinalLabel(0);
        }
        if (clauses) {
            const labelExpression = factory.createPropertyAccessExpression(state, "label");
            const switchStatement = factory.createSwitchStatement(labelExpression, factory.createCaseBlock(clauses));
            return [(0, ts_js_1.startOnNewLine)(switchStatement)];
        }
        if (statements) {
            return statements;
        }
        return [];
    }
    /**
     * Flush the current label and advance to a new label.
     */
    function flushLabel() {
        if (!statements) {
            return;
        }
        appendLabel(/*markLabelEnd*/ !lastOperationWasAbrupt);
        lastOperationWasAbrupt = false;
        lastOperationWasCompletion = false;
        labelNumber++;
    }
    /**
     * Flush the final label of the generator function body.
     */
    function flushFinalLabel(operationIndex) {
        if (isFinalLabelReachable(operationIndex)) {
            tryEnterLabel(operationIndex);
            withBlockStack = undefined;
            writeReturn(/*expression*/ undefined, /*operationLocation*/ undefined);
        }
        if (statements && clauses) {
            appendLabel(/*markLabelEnd*/ false);
        }
        updateLabelExpressions();
    }
    /**
     * Tests whether the final label of the generator function body
     * is reachable by user code.
     */
    function isFinalLabelReachable(operationIndex) {
        // if the last operation was *not* a completion (return/throw) then
        // the final label is reachable.
        if (!lastOperationWasCompletion) {
            return true;
        }
        // if there are no labels defined or referenced, then the final label is
        // not reachable.
        if (!labelOffsets || !labelExpressions) {
            return false;
        }
        // if the label for this offset is referenced, then the final label
        // is reachable.
        for (let label = 0; label < labelOffsets.length; label++) {
            if (labelOffsets[label] === operationIndex && labelExpressions[label]) {
                return true;
            }
        }
        return false;
    }
    /**
     * Appends a case clause for the last label and sets the new label.
     *
     * @param markLabelEnd Indicates that the transition between labels was a fall-through
     *                     from a previous case clause and the change in labels should be
     *                     reflected on the `state` object.
     */
    function appendLabel(markLabelEnd) {
        if (!clauses) {
            clauses = [];
        }
        if (statements) {
            if (withBlockStack) {
                // The previous label was nested inside one or more `with` blocks, so we
                // surround the statements in generated `with` blocks to create the same environment.
                for (let i = withBlockStack.length - 1; i >= 0; i--) {
                    const withBlock = withBlockStack[i];
                    statements = [factory.createWithStatement(withBlock.expression, factory.createBlock(statements))];
                }
            }
            if (currentExceptionBlock) {
                // The previous label was nested inside of an exception block, so we must
                // indicate entry into a protected region by pushing the label numbers
                // for each block in the protected region.
                const { startLabel, catchLabel, finallyLabel, endLabel } = currentExceptionBlock;
                statements.unshift(factory.createExpressionStatement(factory.createCallExpression(factory.createPropertyAccessExpression(factory.createPropertyAccessExpression(state, "trys"), "push"), 
                /*typeArguments*/ undefined, [
                    factory.createArrayLiteralExpression([
                        createLabel(startLabel),
                        createLabel(catchLabel),
                        createLabel(finallyLabel),
                        createLabel(endLabel),
                    ]),
                ])));
                currentExceptionBlock = undefined;
            }
            if (markLabelEnd) {
                // The case clause for the last label falls through to this label, so we
                // add an assignment statement to reflect the change in labels.
                statements.push(factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(state, "label"), factory.createNumericLiteral(labelNumber + 1))));
            }
        }
        clauses.push(factory.createCaseClause(factory.createNumericLiteral(labelNumber), statements || []));
        statements = undefined;
    }
    /**
     * Tries to enter into a new label at the current operation index.
     */
    function tryEnterLabel(operationIndex) {
        if (!labelOffsets) {
            return;
        }
        for (let label = 0; label < labelOffsets.length; label++) {
            if (labelOffsets[label] === operationIndex) {
                flushLabel();
                if (labelNumbers === undefined) {
                    labelNumbers = [];
                }
                if (labelNumbers[labelNumber] === undefined) {
                    labelNumbers[labelNumber] = [label];
                }
                else {
                    labelNumbers[labelNumber].push(label);
                }
            }
        }
    }
    /**
     * Updates literal expressions for labels with actual label numbers.
     */
    function updateLabelExpressions() {
        if (labelExpressions !== undefined && labelNumbers !== undefined) {
            for (let labelNumber = 0; labelNumber < labelNumbers.length; labelNumber++) {
                const labels = labelNumbers[labelNumber];
                if (labels !== undefined) {
                    for (const label of labels) {
                        const expressions = labelExpressions[label];
                        if (expressions !== undefined) {
                            for (const expression of expressions) {
                                expression.text = String(labelNumber);
                            }
                        }
                    }
                }
            }
        }
    }
    /**
     * Tries to enter or leave a code block.
     */
    function tryEnterOrLeaveBlock(operationIndex) {
        if (blocks) {
            for (; blockIndex < blockActions.length && blockOffsets[blockIndex] <= operationIndex; blockIndex++) {
                const block = blocks[blockIndex];
                const blockAction = blockActions[blockIndex];
                switch (block.kind) {
                    case 0 /* CodeBlockKind.Exception */:
                        if (blockAction === 0 /* BlockAction.Open */) {
                            if (!exceptionBlockStack) {
                                exceptionBlockStack = [];
                            }
                            if (!statements) {
                                statements = [];
                            }
                            exceptionBlockStack.push(currentExceptionBlock);
                            currentExceptionBlock = block;
                        }
                        else if (blockAction === 1 /* BlockAction.Close */) {
                            currentExceptionBlock = exceptionBlockStack.pop();
                        }
                        break;
                    case 1 /* CodeBlockKind.With */:
                        if (blockAction === 0 /* BlockAction.Open */) {
                            if (!withBlockStack) {
                                withBlockStack = [];
                            }
                            withBlockStack.push(block);
                        }
                        else if (blockAction === 1 /* BlockAction.Close */) {
                            withBlockStack.pop();
                        }
                        break;
                    // default: do nothing
                }
            }
        }
    }
    /**
     * Writes an operation as a statement to the current label's statement list.
     *
     * @param operation The OpCode of the operation
     */
    function writeOperation(operationIndex) {
        tryEnterLabel(operationIndex);
        tryEnterOrLeaveBlock(operationIndex);
        // early termination, nothing else to process in this label
        if (lastOperationWasAbrupt) {
            return;
        }
        lastOperationWasAbrupt = false;
        lastOperationWasCompletion = false;
        const opcode = operations[operationIndex];
        if (opcode === 0 /* OpCode.Nop */) {
            return;
        }
        else if (opcode === 10 /* OpCode.Endfinally */) {
            return writeEndfinally();
        }
        const args = operationArguments[operationIndex];
        if (opcode === 1 /* OpCode.Statement */) {
            return writeStatement(args[0]);
        }
        const location = operationLocations[operationIndex];
        switch (opcode) {
            case 2 /* OpCode.Assign */:
                return writeAssign(args[0], args[1], location);
            case 3 /* OpCode.Break */:
                const breakLabel = args[0];
                ts_js_1.Debug.assert(typeof breakLabel === "number");
                return writeBreak(breakLabel, location);
            case 4 /* OpCode.BreakWhenTrue */:
                const breakWhenTrueLabel = args[0];
                ts_js_1.Debug.assert(typeof breakWhenTrueLabel === "number");
                return writeBreakWhenTrue(breakWhenTrueLabel, args[1], location);
            case 5 /* OpCode.BreakWhenFalse */:
                const breakWhenFalseLabel = args[0];
                ts_js_1.Debug.assert(typeof breakWhenFalseLabel === "number");
                return writeBreakWhenFalse(breakWhenFalseLabel, args[1], location);
            case 6 /* OpCode.Yield */:
                return writeYield(args[0], location);
            case 7 /* OpCode.YieldStar */:
                return writeYieldStar(args[0], location);
            case 8 /* OpCode.Return */:
                return writeReturn(args[0], location);
            case 9 /* OpCode.Throw */:
                return writeThrow(args[0], location);
        }
    }
    /**
     * Writes a statement to the current label's statement list.
     *
     * @param statement A statement to write.
     */
    function writeStatement(statement) {
        if (statement) {
            if (!statements) {
                statements = [statement];
            }
            else {
                statements.push(statement);
            }
        }
    }
    /**
     * Writes an Assign operation to the current label's statement list.
     *
     * @param left The left-hand side of the assignment.
     * @param right The right-hand side of the assignment.
     * @param operationLocation The source map location for the operation.
     */
    function writeAssign(left, right, operationLocation) {
        writeStatement((0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.createAssignment(left, right)), operationLocation));
    }
    /**
     * Writes a Throw operation to the current label's statement list.
     *
     * @param expression The value to throw.
     * @param operationLocation The source map location for the operation.
     */
    function writeThrow(expression, operationLocation) {
        lastOperationWasAbrupt = true;
        lastOperationWasCompletion = true;
        writeStatement((0, ts_js_1.setTextRange)(factory.createThrowStatement(expression), operationLocation));
    }
    /**
     * Writes a Return operation to the current label's statement list.
     *
     * @param expression The value to return.
     * @param operationLocation The source map location for the operation.
     */
    function writeReturn(expression, operationLocation) {
        lastOperationWasAbrupt = true;
        lastOperationWasCompletion = true;
        writeStatement((0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression(expression
            ? [createInstruction(2 /* Instruction.Return */), expression]
            : [createInstruction(2 /* Instruction.Return */)])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */));
    }
    /**
     * Writes a Break operation to the current label's statement list.
     *
     * @param label The label for the Break.
     * @param operationLocation The source map location for the operation.
     */
    function writeBreak(label, operationLocation) {
        lastOperationWasAbrupt = true;
        writeStatement((0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(3 /* Instruction.Break */),
            createLabel(label),
        ])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */));
    }
    /**
     * Writes a BreakWhenTrue operation to the current label's statement list.
     *
     * @param label The label for the Break.
     * @param condition The condition for the Break.
     * @param operationLocation The source map location for the operation.
     */
    function writeBreakWhenTrue(label, condition, operationLocation) {
        writeStatement((0, ts_js_1.setEmitFlags)(factory.createIfStatement(condition, (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(3 /* Instruction.Break */),
            createLabel(label),
        ])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */)), 1 /* EmitFlags.SingleLine */));
    }
    /**
     * Writes a BreakWhenFalse operation to the current label's statement list.
     *
     * @param label The label for the Break.
     * @param condition The condition for the Break.
     * @param operationLocation The source map location for the operation.
     */
    function writeBreakWhenFalse(label, condition, operationLocation) {
        writeStatement((0, ts_js_1.setEmitFlags)(factory.createIfStatement(factory.createLogicalNot(condition), (0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(3 /* Instruction.Break */),
            createLabel(label),
        ])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */)), 1 /* EmitFlags.SingleLine */));
    }
    /**
     * Writes a Yield operation to the current label's statement list.
     *
     * @param expression The expression to yield.
     * @param operationLocation The source map location for the operation.
     */
    function writeYield(expression, operationLocation) {
        lastOperationWasAbrupt = true;
        writeStatement((0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression(expression
            ? [createInstruction(4 /* Instruction.Yield */), expression]
            : [createInstruction(4 /* Instruction.Yield */)])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */));
    }
    /**
     * Writes a YieldStar instruction to the current label's statement list.
     *
     * @param expression The expression to yield.
     * @param operationLocation The source map location for the operation.
     */
    function writeYieldStar(expression, operationLocation) {
        lastOperationWasAbrupt = true;
        writeStatement((0, ts_js_1.setEmitFlags)((0, ts_js_1.setTextRange)(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(5 /* Instruction.YieldStar */),
            expression,
        ])), operationLocation), 768 /* EmitFlags.NoTokenSourceMaps */));
    }
    /**
     * Writes an Endfinally instruction to the current label's statement list.
     */
    function writeEndfinally() {
        lastOperationWasAbrupt = true;
        writeStatement(factory.createReturnStatement(factory.createArrayLiteralExpression([
            createInstruction(7 /* Instruction.Endfinally */),
        ])));
    }
}
