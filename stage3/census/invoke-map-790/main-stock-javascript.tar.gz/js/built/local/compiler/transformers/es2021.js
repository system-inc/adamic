"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformES2021 = transformES2021;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function transformES2021(context) {
    const { hoistVariableDeclaration, factory, } = context;
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitor(node) {
        if ((node.transformFlags & 16 /* TransformFlags.ContainsES2021 */) === 0) {
            return node;
        }
        if ((0, ts_js_1.isLogicalOrCoalescingAssignmentExpression)(node)) {
            return transformLogicalAssignment(node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function transformLogicalAssignment(binaryExpression) {
        const operator = binaryExpression.operatorToken;
        const nonAssignmentOperator = (0, ts_js_1.getNonAssignmentOperatorForCompoundAssignment)(operator.kind);
        let left = (0, ts_js_1.skipParentheses)((0, ts_js_1.visitNode)(binaryExpression.left, visitor, ts_js_1.isLeftHandSideExpression));
        let assignmentTarget = left;
        const right = (0, ts_js_1.skipParentheses)((0, ts_js_1.visitNode)(binaryExpression.right, visitor, ts_js_1.isExpression));
        if ((0, ts_js_1.isAccessExpression)(left)) {
            const propertyAccessTargetSimpleCopiable = (0, ts_js_1.isSimpleCopiableExpression)(left.expression);
            const propertyAccessTarget = propertyAccessTargetSimpleCopiable ? left.expression :
                factory.createTempVariable(hoistVariableDeclaration);
            const propertyAccessTargetAssignment = propertyAccessTargetSimpleCopiable ? left.expression : factory.createAssignment(propertyAccessTarget, left.expression);
            if ((0, ts_js_1.isPropertyAccessExpression)(left)) {
                assignmentTarget = factory.createPropertyAccessExpression(propertyAccessTarget, left.name);
                left = factory.createPropertyAccessExpression(propertyAccessTargetAssignment, left.name);
            }
            else {
                const elementAccessArgumentSimpleCopiable = (0, ts_js_1.isSimpleCopiableExpression)(left.argumentExpression);
                const elementAccessArgument = elementAccessArgumentSimpleCopiable ? left.argumentExpression :
                    factory.createTempVariable(hoistVariableDeclaration);
                assignmentTarget = factory.createElementAccessExpression(propertyAccessTarget, elementAccessArgument);
                left = factory.createElementAccessExpression(propertyAccessTargetAssignment, elementAccessArgumentSimpleCopiable ? left.argumentExpression : factory.createAssignment(elementAccessArgument, left.argumentExpression));
            }
        }
        return factory.createBinaryExpression(left, nonAssignmentOperator, factory.createParenthesizedExpression(factory.createAssignment(assignmentTarget, right)));
    }
}
