"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSyntacticTypeNodeBuilder = createSyntacticTypeNodeBuilder;
const ts_js_1 = require("./_namespaces/ts.js");
function syntacticResult(type, reportFallback = true) {
    return { type, reportFallback };
}
const notImplemented = syntacticResult(/*type*/ undefined, /*reportFallback*/ false);
const alreadyReported = syntacticResult(/*type*/ undefined, /*reportFallback*/ false);
const failed = syntacticResult(/*type*/ undefined, /*reportFallback*/ true);
/** @internal */
function createSyntacticTypeNodeBuilder(options, resolver) {
    const strictNullChecks = (0, ts_js_1.getStrictOptionValue)(options, "strictNullChecks");
    return {
        serializeTypeOfDeclaration,
        serializeReturnTypeForSignature,
        serializeTypeOfExpression,
        serializeTypeOfAccessor,
        tryReuseExistingTypeNode(context, existing) {
            if (!resolver.canReuseTypeNode(context, existing)) {
                return undefined;
            }
            return tryReuseExistingTypeNode(context, existing);
        },
    };
    function reuseNode(context, node, range = node) {
        return node === undefined ? undefined : resolver.markNodeReuse(context, node.flags & 16 /* NodeFlags.Synthesized */ ? node : ts_js_1.factory.cloneNode(node), range ?? node);
    }
    function tryReuseExistingTypeNode(context, existing) {
        const { finalizeBoundary, startRecoveryScope, hadError, markError } = resolver.createRecoveryBoundary(context);
        const transformed = (0, ts_js_1.visitNode)(existing, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
        if (!finalizeBoundary()) {
            return undefined;
        }
        context.approximateLength += existing.end - existing.pos;
        return transformed;
        function visitExistingNodeTreeSymbols(node) {
            // If there was an error in a sibling node bail early, the result will be discarded anyway
            if (hadError())
                return node;
            const recover = startRecoveryScope();
            const onExitNewScope = (0, ts_js_1.isNewScopeNode)(node) ? resolver.enterNewScope(context, node) : undefined;
            const result = visitExistingNodeTreeSymbolsWorker(node);
            onExitNewScope?.();
            // If there was an error, maybe we can recover by serializing the actual type of the node
            if (hadError()) {
                if ((0, ts_js_1.isTypeNode)(node) && !(0, ts_js_1.isTypePredicateNode)(node)) {
                    recover();
                    return resolver.serializeExistingTypeNode(context, node);
                }
                return node;
            }
            // We want to clone the subtree, so when we mark it up with __pos and __end in quickfixes,
            //  we don't get odd behavior because of reused nodes. We also need to clone to _remove_
            //  the position information if the node comes from a different file than the one the node builder
            //  is set to build for (even though we are reusing the node structure, the position information
            //  would make the printer print invalid spans for literals and identifiers, and the formatter would
            //  choke on the mismatched positonal spans between a parent and an injected child from another file).
            return result ? resolver.markNodeReuse(context, result, node) : undefined;
        }
        function tryVisitSimpleTypeNode(node) {
            const innerNode = (0, ts_js_1.skipTypeParentheses)(node);
            switch (innerNode.kind) {
                case 184 /* SyntaxKind.TypeReference */:
                    return tryVisitTypeReference(innerNode);
                case 187 /* SyntaxKind.TypeQuery */:
                    return tryVisitTypeQuery(innerNode);
                case 200 /* SyntaxKind.IndexedAccessType */:
                    return tryVisitIndexedAccess(innerNode);
                case 199 /* SyntaxKind.TypeOperator */:
                    const typeOperatorNode = innerNode;
                    if (typeOperatorNode.operator === 143 /* SyntaxKind.KeyOfKeyword */) {
                        return tryVisitKeyOf(typeOperatorNode);
                    }
            }
            return (0, ts_js_1.visitNode)(node, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
        }
        function tryVisitIndexedAccess(node) {
            const resultObjectType = tryVisitSimpleTypeNode(node.objectType);
            if (resultObjectType === undefined) {
                return undefined;
            }
            return ts_js_1.factory.updateIndexedAccessTypeNode(node, resultObjectType, (0, ts_js_1.visitNode)(node.indexType, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode));
        }
        function tryVisitKeyOf(node) {
            ts_js_1.Debug.assertEqual(node.operator, 143 /* SyntaxKind.KeyOfKeyword */);
            const type = tryVisitSimpleTypeNode(node.type);
            if (type === undefined) {
                return undefined;
            }
            return ts_js_1.factory.updateTypeOperatorNode(node, type);
        }
        function tryVisitTypeQuery(node) {
            const { introducesError, node: exprName } = resolver.trackExistingEntityName(context, node.exprName);
            if (!introducesError) {
                return ts_js_1.factory.updateTypeQueryNode(node, exprName, (0, ts_js_1.visitNodes)(node.typeArguments, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode));
            }
            const serializedName = resolver.serializeTypeName(context, node.exprName, /*isTypeOf*/ true);
            if (serializedName) {
                return resolver.markNodeReuse(context, serializedName, node.exprName);
            }
        }
        function tryVisitTypeReference(node) {
            if (resolver.canReuseTypeNode(context, node)) {
                const { introducesError, node: newName } = resolver.trackExistingEntityName(context, node.typeName);
                const typeArguments = (0, ts_js_1.visitNodes)(node.typeArguments, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
                if (!introducesError) {
                    const updated = ts_js_1.factory.updateTypeReferenceNode(node, newName, typeArguments);
                    return resolver.markNodeReuse(context, updated, node);
                }
                else {
                    const serializedName = resolver.serializeTypeName(context, node.typeName, /*isTypeOf*/ false, typeArguments);
                    if (serializedName) {
                        return resolver.markNodeReuse(context, serializedName, node.typeName);
                    }
                }
            }
        }
        function visitExistingNodeTreeSymbolsWorker(node) {
            if ((0, ts_js_1.isJSDocTypeExpression)(node)) {
                // Unwrap JSDocTypeExpressions
                return (0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
            }
            // We don't _actually_ support jsdoc namepath types, emit `any` instead
            if ((0, ts_js_1.isJSDocAllType)(node) || node.kind === 320 /* SyntaxKind.JSDocNamepathType */) {
                return ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
            }
            if ((0, ts_js_1.isJSDocUnknownType)(node)) {
                return ts_js_1.factory.createKeywordTypeNode(159 /* SyntaxKind.UnknownKeyword */);
            }
            if ((0, ts_js_1.isJSDocNullableType)(node)) {
                return ts_js_1.factory.createUnionTypeNode([(0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), ts_js_1.factory.createLiteralTypeNode(ts_js_1.factory.createNull())]);
            }
            if ((0, ts_js_1.isJSDocOptionalType)(node)) {
                return ts_js_1.factory.createUnionTypeNode([(0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), ts_js_1.factory.createKeywordTypeNode(157 /* SyntaxKind.UndefinedKeyword */)]);
            }
            if ((0, ts_js_1.isJSDocNonNullableType)(node)) {
                return (0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols);
            }
            if ((0, ts_js_1.isJSDocVariadicType)(node)) {
                return ts_js_1.factory.createArrayTypeNode((0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode));
            }
            if ((0, ts_js_1.isJSDocTypeLiteral)(node)) {
                return ts_js_1.factory.createTypeLiteralNode((0, ts_js_1.map)(node.jsDocPropertyTags, t => {
                    const name = (0, ts_js_1.visitNode)((0, ts_js_1.isIdentifier)(t.name) ? t.name : t.name.right, visitExistingNodeTreeSymbols, ts_js_1.isIdentifier);
                    const overrideTypeNode = resolver.getJsDocPropertyOverride(context, node, t);
                    return ts_js_1.factory.createPropertySignature(
                    /*modifiers*/ undefined, name, t.isBracketed || t.typeExpression && (0, ts_js_1.isJSDocOptionalType)(t.typeExpression.type) ? ts_js_1.factory.createToken(58 /* SyntaxKind.QuestionToken */) : undefined, overrideTypeNode || (t.typeExpression && (0, ts_js_1.visitNode)(t.typeExpression.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode)) || ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */));
                }));
            }
            if ((0, ts_js_1.isTypeReferenceNode)(node) && (0, ts_js_1.isIdentifier)(node.typeName) && node.typeName.escapedText === "") {
                return (0, ts_js_1.setOriginalNode)(ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */), node);
            }
            if (((0, ts_js_1.isExpressionWithTypeArguments)(node) || (0, ts_js_1.isTypeReferenceNode)(node)) && (0, ts_js_1.isJSDocIndexSignature)(node)) {
                return ts_js_1.factory.createTypeLiteralNode([ts_js_1.factory.createIndexSignature(
                    /*modifiers*/ undefined, [ts_js_1.factory.createParameterDeclaration(
                        /*modifiers*/ undefined, 
                        /*dotDotDotToken*/ undefined, "x", 
                        /*questionToken*/ undefined, (0, ts_js_1.visitNode)(node.typeArguments[0], visitExistingNodeTreeSymbols, ts_js_1.isTypeNode))], (0, ts_js_1.visitNode)(node.typeArguments[1], visitExistingNodeTreeSymbols, ts_js_1.isTypeNode))]);
            }
            if ((0, ts_js_1.isJSDocFunctionType)(node)) {
                if ((0, ts_js_1.isJSDocConstructSignature)(node)) {
                    let newTypeNode;
                    return ts_js_1.factory.createConstructorTypeNode(
                    /*modifiers*/ undefined, (0, ts_js_1.visitNodes)(node.typeParameters, visitExistingNodeTreeSymbols, ts_js_1.isTypeParameterDeclaration), (0, ts_js_1.mapDefined)(node.parameters, (p, i) => p.name && (0, ts_js_1.isIdentifier)(p.name) && p.name.escapedText === "new" ? (newTypeNode = p.type, undefined) : ts_js_1.factory.createParameterDeclaration(
                    /*modifiers*/ undefined, getEffectiveDotDotDotForParameter(p), resolver.markNodeReuse(context, ts_js_1.factory.createIdentifier(getNameForJSDocFunctionParameter(p, i)), p), ts_js_1.factory.cloneNode(p.questionToken), (0, ts_js_1.visitNode)(p.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), 
                    /*initializer*/ undefined)), (0, ts_js_1.visitNode)(newTypeNode || node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode) || ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */));
                }
                else {
                    return ts_js_1.factory.createFunctionTypeNode((0, ts_js_1.visitNodes)(node.typeParameters, visitExistingNodeTreeSymbols, ts_js_1.isTypeParameterDeclaration), (0, ts_js_1.map)(node.parameters, (p, i) => ts_js_1.factory.createParameterDeclaration(
                    /*modifiers*/ undefined, getEffectiveDotDotDotForParameter(p), resolver.markNodeReuse(context, ts_js_1.factory.createIdentifier(getNameForJSDocFunctionParameter(p, i)), p), ts_js_1.factory.cloneNode(p.questionToken), (0, ts_js_1.visitNode)(p.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), 
                    /*initializer*/ undefined)), (0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode) || ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */));
                }
            }
            if ((0, ts_js_1.isThisTypeNode)(node)) {
                if (resolver.canReuseTypeNode(context, node)) {
                    return node;
                }
                markError();
                return node;
            }
            if ((0, ts_js_1.isTypeParameterDeclaration)(node)) {
                const { node: newName } = resolver.trackExistingEntityName(context, node.name);
                return ts_js_1.factory.updateTypeParameterDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, visitExistingNodeTreeSymbols, ts_js_1.isModifier), 
                // resolver.markNodeReuse(context, typeParameterToName(getDeclaredTypeOfSymbol(getSymbolOfDeclaration(node)), context), node),
                newName, (0, ts_js_1.visitNode)(node.constraint, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), (0, ts_js_1.visitNode)(node.default, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode));
            }
            if ((0, ts_js_1.isIndexedAccessTypeNode)(node)) {
                const result = tryVisitIndexedAccess(node);
                if (!result) {
                    markError();
                    return node;
                }
                return result;
            }
            if ((0, ts_js_1.isTypeReferenceNode)(node)) {
                const result = tryVisitTypeReference(node);
                if (result) {
                    return result;
                }
                markError();
                return node;
            }
            if ((0, ts_js_1.isLiteralImportTypeNode)(node)) {
                // assert keyword in imported attributes is deprecated, so we don't reuse types that contain it
                // Ex: import("pkg", { assert: {} }
                if (node.attributes?.token === 132 /* SyntaxKind.AssertKeyword */) {
                    markError();
                    return node;
                }
                if (!resolver.canReuseTypeNode(context, node)) {
                    return resolver.serializeExistingTypeNode(context, node);
                }
                const specifier = rewriteModuleSpecifier(node, node.argument.literal);
                const literal = specifier === node.argument.literal ? reuseNode(context, node.argument.literal) : specifier;
                return ts_js_1.factory.updateImportTypeNode(node, literal === node.argument.literal ? reuseNode(context, node.argument) : ts_js_1.factory.createLiteralTypeNode(literal), (0, ts_js_1.visitNode)(node.attributes, visitExistingNodeTreeSymbols, ts_js_1.isImportAttributes), (0, ts_js_1.visitNode)(node.qualifier, visitExistingNodeTreeSymbols, ts_js_1.isEntityName), (0, ts_js_1.visitNodes)(node.typeArguments, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode), node.isTypeOf);
            }
            if ((0, ts_js_1.isNamedDeclaration)(node) && node.name.kind === 168 /* SyntaxKind.ComputedPropertyName */ && !resolver.hasLateBindableName(node)) {
                if (!(0, ts_js_1.hasDynamicName)(node)) {
                    return visitEachChild(node, visitExistingNodeTreeSymbols);
                }
                if (resolver.shouldRemoveDeclaration(context, node)) {
                    return undefined;
                }
            }
            if (((0, ts_js_1.isFunctionLike)(node) && !node.type)
                || ((0, ts_js_1.isPropertyDeclaration)(node) && !node.type && !node.initializer)
                || ((0, ts_js_1.isPropertySignature)(node) && !node.type && !node.initializer)
                || ((0, ts_js_1.isParameter)(node) && !node.type && !node.initializer)) {
                let visited = visitEachChild(node, visitExistingNodeTreeSymbols);
                if (visited === node) {
                    visited = resolver.markNodeReuse(context, ts_js_1.factory.cloneNode(node), node);
                }
                visited.type = ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
                if ((0, ts_js_1.isParameter)(node)) {
                    visited.modifiers = undefined;
                }
                return visited;
            }
            if ((0, ts_js_1.isTypeQueryNode)(node)) {
                const result = tryVisitTypeQuery(node);
                if (!result) {
                    markError();
                    return node;
                }
                return result;
            }
            if ((0, ts_js_1.isComputedPropertyName)(node) && (0, ts_js_1.isEntityNameExpression)(node.expression)) {
                const { node: result, introducesError } = resolver.trackExistingEntityName(context, node.expression);
                if (!introducesError) {
                    return ts_js_1.factory.updateComputedPropertyName(node, result);
                }
                else {
                    const computedPropertyNameType = resolver.serializeTypeOfExpression(context, node.expression);
                    let literal;
                    if ((0, ts_js_1.isLiteralTypeNode)(computedPropertyNameType)) {
                        literal = computedPropertyNameType.literal;
                    }
                    else {
                        const evaluated = resolver.evaluateEntityNameExpression(node.expression);
                        const literalNode = typeof evaluated.value === "string" ? ts_js_1.factory.createStringLiteral(evaluated.value, /*isSingleQuote*/ undefined) :
                            typeof evaluated.value === "number" ? ts_js_1.factory.createNumericLiteral(evaluated.value, /*numericLiteralFlags*/ 0) :
                                undefined;
                        if (!literalNode) {
                            if ((0, ts_js_1.isImportTypeNode)(computedPropertyNameType)) {
                                resolver.trackComputedName(context, node.expression);
                            }
                            return node;
                        }
                        literal = literalNode;
                    }
                    if (literal.kind === 11 /* SyntaxKind.StringLiteral */ && (0, ts_js_1.isIdentifierText)(literal.text, (0, ts_js_1.getEmitScriptTarget)(options))) {
                        return ts_js_1.factory.createIdentifier(literal.text);
                    }
                    if (literal.kind === 9 /* SyntaxKind.NumericLiteral */ && !literal.text.startsWith("-")) {
                        return literal;
                    }
                    return ts_js_1.factory.updateComputedPropertyName(node, literal);
                }
            }
            if ((0, ts_js_1.isTypePredicateNode)(node)) {
                let parameterName;
                if ((0, ts_js_1.isIdentifier)(node.parameterName)) {
                    const { node: result, introducesError } = resolver.trackExistingEntityName(context, node.parameterName);
                    // Should not usually happen the only case is when a type predicate comes from a JSDoc type annotation with it's own parameter symbol definition.
                    // /** @type {(v: unknown) => v is undefined} */
                    // const isUndef = v => v === undefined;
                    if (introducesError)
                        markError();
                    parameterName = result;
                }
                else {
                    parameterName = ts_js_1.factory.cloneNode(node.parameterName);
                }
                return ts_js_1.factory.updateTypePredicateNode(node, ts_js_1.factory.cloneNode(node.assertsModifier), parameterName, (0, ts_js_1.visitNode)(node.type, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode));
            }
            if ((0, ts_js_1.isTupleTypeNode)(node) || (0, ts_js_1.isTypeLiteralNode)(node) || (0, ts_js_1.isMappedTypeNode)(node)) {
                const visited = visitEachChild(node, visitExistingNodeTreeSymbols);
                const clone = resolver.markNodeReuse(context, visited === node ? ts_js_1.factory.cloneNode(node) : visited, node);
                const flags = (0, ts_js_1.getEmitFlags)(clone);
                (0, ts_js_1.setEmitFlags)(clone, flags | (context.flags & 1024 /* NodeBuilderFlags.MultilineObjectLiterals */ && (0, ts_js_1.isTypeLiteralNode)(node) ? 0 : 1 /* EmitFlags.SingleLine */));
                return clone;
            }
            if ((0, ts_js_1.isStringLiteral)(node) && !!(context.flags & 268435456 /* NodeBuilderFlags.UseSingleQuotesForStringLiteralType */) && !node.singleQuote) {
                const clone = ts_js_1.factory.cloneNode(node);
                clone.singleQuote = true;
                return clone;
            }
            if ((0, ts_js_1.isConditionalTypeNode)(node)) {
                const checkType = (0, ts_js_1.visitNode)(node.checkType, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
                const disposeScope = resolver.enterNewScope(context, node);
                const extendType = (0, ts_js_1.visitNode)(node.extendsType, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
                const trueType = (0, ts_js_1.visitNode)(node.trueType, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
                disposeScope();
                const falseType = (0, ts_js_1.visitNode)(node.falseType, visitExistingNodeTreeSymbols, ts_js_1.isTypeNode);
                return ts_js_1.factory.updateConditionalTypeNode(node, checkType, extendType, trueType, falseType);
            }
            if ((0, ts_js_1.isTypeOperatorNode)(node)) {
                if (node.operator === 158 /* SyntaxKind.UniqueKeyword */ && node.type.kind === 155 /* SyntaxKind.SymbolKeyword */) {
                    if (!resolver.canReuseTypeNode(context, node)) {
                        markError();
                        return node;
                    }
                }
                else if (node.operator === 143 /* SyntaxKind.KeyOfKeyword */) {
                    const result = tryVisitKeyOf(node);
                    if (!result) {
                        markError();
                        return node;
                    }
                    return result;
                }
            }
            return visitEachChild(node, visitExistingNodeTreeSymbols);
            function visitEachChild(node, visitor) {
                const nonlocalNode = !context.enclosingFile || context.enclosingFile !== (0, ts_js_1.getSourceFileOfNode)(node);
                return (0, ts_js_1.visitEachChild)(node, visitor, /*context*/ undefined, nonlocalNode ? visitNodesWithoutCopyingPositions : undefined);
            }
            function visitNodesWithoutCopyingPositions(nodes, visitor, test, start, count) {
                let result = (0, ts_js_1.visitNodes)(nodes, visitor, test, start, count);
                if (result) {
                    if (result.pos !== -1 || result.end !== -1) {
                        if (result === nodes) {
                            result = ts_js_1.factory.createNodeArray(nodes.slice(), nodes.hasTrailingComma);
                        }
                        (0, ts_js_1.setTextRangePosEnd)(result, -1, -1);
                    }
                }
                return result;
            }
            function getEffectiveDotDotDotForParameter(p) {
                return p.dotDotDotToken || (p.type && (0, ts_js_1.isJSDocVariadicType)(p.type) ? ts_js_1.factory.createToken(26 /* SyntaxKind.DotDotDotToken */) : undefined);
            }
            /** Note that `new:T` parameters are not handled, but should be before calling this function. */
            function getNameForJSDocFunctionParameter(p, index) {
                return p.name && (0, ts_js_1.isIdentifier)(p.name) && p.name.escapedText === "this" ? "this"
                    : getEffectiveDotDotDotForParameter(p) ? `args`
                        : `arg${index}`;
            }
            function rewriteModuleSpecifier(parent, lit) {
                const newName = resolver.getModuleSpecifierOverride(context, parent, lit);
                return newName ? (0, ts_js_1.setOriginalNode)(ts_js_1.factory.createStringLiteral(newName), lit) : lit;
            }
        }
    }
    function serializeExistingTypeNode(typeNode, context, addUndefined) {
        if (!typeNode)
            return undefined;
        let result;
        if ((!addUndefined || canAddUndefined(typeNode)) && resolver.canReuseTypeNode(context, typeNode)) {
            result = tryReuseExistingTypeNode(context, typeNode);
            if (result !== undefined) {
                result = addUndefinedIfNeeded(result, addUndefined, /*owner*/ undefined, context);
            }
        }
        return result;
    }
    function serializeTypeAnnotationOfDeclaration(declaredType, context, node, symbol, requiresAddingUndefined, useFallback = requiresAddingUndefined !== undefined) {
        if (!declaredType)
            return undefined;
        if (!resolver.canReuseTypeNodeAnnotation(context, node, declaredType, symbol, requiresAddingUndefined)) {
            // If we need to add undefined, can add undefined, and the resolver says we can reuse the type, we reuse the type
            // If we don't know syntactically that we can add the undefined, we will report the fallback below.
            if (!requiresAddingUndefined || !resolver.canReuseTypeNodeAnnotation(context, node, declaredType, symbol, /*requiresAddingUndefined*/ false)) {
                return undefined;
            }
        }
        let result;
        if (!requiresAddingUndefined || canAddUndefined(declaredType)) {
            result = serializeExistingTypeNode(declaredType, context, requiresAddingUndefined);
        }
        if (result !== undefined || !useFallback) {
            return result;
        }
        context.tracker.reportInferenceFallback(node);
        return resolver.serializeExistingTypeNode(context, declaredType, requiresAddingUndefined) ?? ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
    }
    function serializeExistingTypeNodeWithFallback(typeNode, context, addUndefined, targetNode) {
        if (!typeNode)
            return undefined;
        const result = serializeExistingTypeNode(typeNode, context, addUndefined);
        if (result !== undefined) {
            return result;
        }
        context.tracker.reportInferenceFallback(targetNode ?? typeNode);
        return resolver.serializeExistingTypeNode(context, typeNode, addUndefined) ?? ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
    }
    function serializeTypeOfAccessor(accessor, symbol, context) {
        return typeFromAccessor(accessor, symbol, context) ?? inferAccessorType(accessor, resolver.getAllAccessorDeclarations(accessor), context, symbol);
    }
    function serializeTypeOfExpression(expr, context, addUndefined, preserveLiterals) {
        const result = typeFromExpression(expr, context, /*isConstContext*/ false, addUndefined, preserveLiterals);
        return result.type !== undefined ? result.type : inferExpressionType(expr, context, result.reportFallback);
    }
    function serializeTypeOfDeclaration(node, symbol, context) {
        switch (node.kind) {
            case 170 /* SyntaxKind.Parameter */:
            case 342 /* SyntaxKind.JSDocParameterTag */:
                return typeFromParameter(node, symbol, context);
            case 261 /* SyntaxKind.VariableDeclaration */:
                return typeFromVariable(node, symbol, context);
            case 172 /* SyntaxKind.PropertySignature */:
            case 349 /* SyntaxKind.JSDocPropertyTag */:
            case 173 /* SyntaxKind.PropertyDeclaration */:
                return typeFromProperty(node, symbol, context);
            case 209 /* SyntaxKind.BindingElement */:
                return inferTypeOfDeclaration(node, symbol, context);
            case 278 /* SyntaxKind.ExportAssignment */:
                return serializeTypeOfExpression(node.expression, context, /*addUndefined*/ undefined, /*preserveLiterals*/ true);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
            case 213 /* SyntaxKind.ElementAccessExpression */:
            case 227 /* SyntaxKind.BinaryExpression */:
                return typeFromExpandoProperty(node, symbol, context);
            case 304 /* SyntaxKind.PropertyAssignment */:
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
                return typeFromPropertyAssignment(node, symbol, context);
            default:
                ts_js_1.Debug.assertNever(node, `Node needs to be an inferrable node, found ${ts_js_1.Debug.formatSyntaxKind(node.kind)}`);
        }
    }
    function typeFromPropertyAssignment(node, symbol, context) {
        const typeAnnotation = (0, ts_js_1.getEffectiveTypeAnnotationNode)(node);
        let result;
        if (typeAnnotation && resolver.canReuseTypeNodeAnnotation(context, node, typeAnnotation, symbol)) {
            result = serializeExistingTypeNode(typeAnnotation, context);
        }
        if (!result && node.kind === 304 /* SyntaxKind.PropertyAssignment */) {
            const initializer = node.initializer;
            const assertionNode = (0, ts_js_1.isJSDocTypeAssertion)(initializer) ? (0, ts_js_1.getJSDocTypeAssertionType)(initializer) :
                initializer.kind === 235 /* SyntaxKind.AsExpression */ || initializer.kind === 217 /* SyntaxKind.TypeAssertionExpression */ ? initializer.type :
                    undefined;
            if (assertionNode && !(0, ts_js_1.isConstTypeReference)(assertionNode) && resolver.canReuseTypeNodeAnnotation(context, node, assertionNode, symbol)) {
                result = serializeExistingTypeNode(assertionNode, context);
            }
        }
        return result ?? inferTypeOfDeclaration(node, symbol, context, /*reportFallback*/ false);
    }
    function serializeReturnTypeForSignature(node, symbol, context) {
        switch (node.kind) {
            case 178 /* SyntaxKind.GetAccessor */:
                return serializeTypeOfAccessor(node, symbol, context);
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 181 /* SyntaxKind.ConstructSignature */:
            case 174 /* SyntaxKind.MethodSignature */:
            case 180 /* SyntaxKind.CallSignature */:
            case 177 /* SyntaxKind.Constructor */:
            case 179 /* SyntaxKind.SetAccessor */:
            case 182 /* SyntaxKind.IndexSignature */:
            case 185 /* SyntaxKind.FunctionType */:
            case 186 /* SyntaxKind.ConstructorType */:
            case 219 /* SyntaxKind.FunctionExpression */:
            case 220 /* SyntaxKind.ArrowFunction */:
            case 318 /* SyntaxKind.JSDocFunctionType */:
            case 324 /* SyntaxKind.JSDocSignature */:
                return createReturnFromSignature(node, symbol, context);
            default:
                ts_js_1.Debug.assertNever(node, `Node needs to be an inferrable node, found ${ts_js_1.Debug.formatSyntaxKind(node.kind)}`);
        }
    }
    function getTypeAnnotationFromAccessor(accessor) {
        if (accessor) {
            return accessor.kind === 178 /* SyntaxKind.GetAccessor */
                ? ((0, ts_js_1.isInJSFile)(accessor) && (0, ts_js_1.getJSDocType)(accessor)) || (0, ts_js_1.getEffectiveReturnTypeNode)(accessor)
                : (0, ts_js_1.getEffectiveSetAccessorTypeAnnotationNode)(accessor);
        }
    }
    function getTypeAnnotationFromAllAccessorDeclarations(node, accessors) {
        let accessorType = getTypeAnnotationFromAccessor(node);
        if (!accessorType && node !== accessors.firstAccessor) {
            accessorType = getTypeAnnotationFromAccessor(accessors.firstAccessor);
        }
        if (!accessorType && accessors.secondAccessor && node !== accessors.secondAccessor) {
            accessorType = getTypeAnnotationFromAccessor(accessors.secondAccessor);
        }
        return accessorType;
    }
    function typeFromAccessor(node, symbol, context) {
        const accessorDeclarations = resolver.getAllAccessorDeclarations(node);
        const accessorType = getTypeAnnotationFromAllAccessorDeclarations(node, accessorDeclarations);
        if (accessorType && !(0, ts_js_1.isTypePredicateNode)(accessorType)) {
            return withNewScope(context, node, () => serializeTypeAnnotationOfDeclaration(accessorType, context, node, symbol) ?? inferTypeOfDeclaration(node, symbol, context));
        }
        if (accessorDeclarations.getAccessor) {
            return withNewScope(context, accessorDeclarations.getAccessor, () => createReturnFromSignature(accessorDeclarations.getAccessor, symbol, context));
        }
        return undefined;
    }
    function typeFromVariable(node, symbol, context) {
        const declaredType = (0, ts_js_1.getEffectiveTypeAnnotationNode)(node);
        let resultType = failed;
        if (declaredType) {
            resultType = syntacticResult(serializeTypeAnnotationOfDeclaration(declaredType, context, node, symbol));
        }
        else if (node.initializer && (symbol.declarations?.length === 1 || (0, ts_js_1.countWhere)(symbol.declarations, ts_js_1.isVariableDeclaration) === 1)) {
            if (!resolver.isExpandoFunctionDeclaration(node) && !isContextuallyTyped(node)) {
                resultType = typeFromExpression(node.initializer, context, /*isConstContext*/ undefined, /*requiresAddingUndefined*/ undefined, (0, ts_js_1.isVarConstLike)(node));
            }
        }
        return resultType.type !== undefined ? resultType.type : inferTypeOfDeclaration(node, symbol, context, resultType.reportFallback);
    }
    function typeFromParameter(node, symbol, context) {
        const parent = node.parent;
        if (parent.kind === 179 /* SyntaxKind.SetAccessor */) {
            return serializeTypeOfAccessor(parent, /*symbol*/ undefined, context);
        }
        const declaredType = (0, ts_js_1.getEffectiveTypeAnnotationNode)(node);
        const addUndefined = resolver.requiresAddingImplicitUndefined(node, symbol, context.enclosingDeclaration);
        let resultType = failed;
        if (declaredType) {
            resultType = syntacticResult(serializeTypeAnnotationOfDeclaration(declaredType, context, node, symbol, addUndefined));
        }
        else if ((0, ts_js_1.isParameter)(node) && node.initializer && (0, ts_js_1.isIdentifier)(node.name) && !isContextuallyTyped(node)) {
            resultType = typeFromExpression(node.initializer, context, /*isConstContext*/ undefined, addUndefined);
        }
        return resultType.type !== undefined ? resultType.type : inferTypeOfDeclaration(node, symbol, context, resultType.reportFallback);
    }
    /**
     * While expando poperies are errors in TSC, in JS we try to extract the type from the binary expression;
     */
    function typeFromExpandoProperty(node, symbol, context) {
        const declaredType = (0, ts_js_1.getEffectiveTypeAnnotationNode)(node);
        let result;
        if (declaredType) {
            result = serializeTypeAnnotationOfDeclaration(declaredType, context, node, symbol);
        }
        const oldSuppressReportInferenceFallback = context.suppressReportInferenceFallback;
        context.suppressReportInferenceFallback = true;
        const resultType = result ?? inferTypeOfDeclaration(node, symbol, context, /*reportFallback*/ false);
        context.suppressReportInferenceFallback = oldSuppressReportInferenceFallback;
        return resultType;
    }
    function typeFromProperty(node, symbol, context) {
        const declaredType = (0, ts_js_1.getEffectiveTypeAnnotationNode)(node);
        const requiresAddingUndefined = resolver.requiresAddingImplicitUndefined(node, symbol, context.enclosingDeclaration);
        let resultType = failed;
        if (declaredType) {
            resultType = syntacticResult(serializeTypeAnnotationOfDeclaration(declaredType, context, node, symbol, requiresAddingUndefined));
        }
        else {
            const initializer = (0, ts_js_1.isPropertyDeclaration)(node) ? node.initializer : undefined;
            if (initializer && !isContextuallyTyped(node)) {
                const isReadonly = (0, ts_js_1.isDeclarationReadonly)(node);
                resultType = typeFromExpression(initializer, context, /*isConstContext*/ undefined, requiresAddingUndefined, isReadonly);
            }
        }
        return resultType.type !== undefined ? resultType.type : inferTypeOfDeclaration(node, symbol, context, resultType.reportFallback);
    }
    function inferTypeOfDeclaration(node, symbol, context, reportFallback = true) {
        if (reportFallback) {
            context.tracker.reportInferenceFallback(node);
        }
        if (context.noInferenceFallback === true) {
            return ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
        }
        return resolver.serializeTypeOfDeclaration(context, node, symbol);
    }
    function inferExpressionType(node, context, reportFallback = true, requiresAddingUndefined) {
        ts_js_1.Debug.assert(!requiresAddingUndefined);
        if (reportFallback) {
            context.tracker.reportInferenceFallback(node);
        }
        if (context.noInferenceFallback === true) {
            return ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
        }
        return resolver.serializeTypeOfExpression(context, node) ?? ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
    }
    function inferReturnTypeOfSignatureSignature(node, context, symbol, reportFallback) {
        if (reportFallback) {
            context.tracker.reportInferenceFallback(node);
        }
        if (context.noInferenceFallback === true) {
            return ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
        }
        return resolver.serializeReturnTypeForSignature(context, node, symbol) ?? ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
    }
    function inferAccessorType(node, allAccessors, context, symbol, reportFallback = true) {
        if (node.kind === 178 /* SyntaxKind.GetAccessor */) {
            return createReturnFromSignature(node, symbol, context, reportFallback);
        }
        else {
            if (reportFallback) {
                context.tracker.reportInferenceFallback(node);
            }
            const result = allAccessors.getAccessor && createReturnFromSignature(allAccessors.getAccessor, symbol, context, reportFallback);
            return result ?? resolver.serializeTypeOfDeclaration(context, node, symbol) ?? ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
        }
    }
    function withNewScope(context, node, fn) {
        const cleanup = resolver.enterNewScope(context, node);
        const result = fn();
        cleanup();
        return result;
    }
    function typeFromTypeAssertion(expression, type, context, requiresAddingUndefined) {
        if ((0, ts_js_1.isConstTypeReference)(type)) {
            return typeFromExpression(expression, context, /*isConstContext*/ true, requiresAddingUndefined);
        }
        return syntacticResult(serializeExistingTypeNodeWithFallback(type, context, requiresAddingUndefined));
    }
    function typeFromExpression(node, context, isConstContext = false, requiresAddingUndefined = false, preserveLiterals = false) {
        switch (node.kind) {
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                if ((0, ts_js_1.isJSDocTypeAssertion)(node)) {
                    return typeFromTypeAssertion(node.expression, (0, ts_js_1.getJSDocTypeAssertionType)(node), context, requiresAddingUndefined);
                }
                return typeFromExpression(node.expression, context, isConstContext, requiresAddingUndefined);
            case 80 /* SyntaxKind.Identifier */:
                if (resolver.isUndefinedIdentifierExpression(node)) {
                    return syntacticResult(createUndefinedTypeNode());
                }
                break;
            case 106 /* SyntaxKind.NullKeyword */:
                if (strictNullChecks) {
                    return syntacticResult(addUndefinedIfNeeded(ts_js_1.factory.createLiteralTypeNode(ts_js_1.factory.createNull()), requiresAddingUndefined, node, context));
                }
                else {
                    return syntacticResult(ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */));
                }
            case 220 /* SyntaxKind.ArrowFunction */:
            case 219 /* SyntaxKind.FunctionExpression */:
                ts_js_1.Debug.assert((0, ts_js_1.isFunctionLikeDeclaration)(node) && (node.kind === 220 /* SyntaxKind.ArrowFunction */ || node.kind === 219 /* SyntaxKind.FunctionExpression */), "Expected a function expression or arrow function.");
                return withNewScope(context, node, () => typeFromFunctionLikeExpression(node, context));
            case 217 /* SyntaxKind.TypeAssertionExpression */:
            case 235 /* SyntaxKind.AsExpression */:
                const asExpression = node;
                return typeFromTypeAssertion(asExpression.expression, asExpression.type, context, requiresAddingUndefined);
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
                const unaryExpression = node;
                if ((0, ts_js_1.isPrimitiveLiteralValue)(unaryExpression)) {
                    return typeFromPrimitiveLiteral(unaryExpression.operator === 40 /* SyntaxKind.PlusToken */ ? unaryExpression.operand : unaryExpression, unaryExpression.operand.kind === 10 /* SyntaxKind.BigIntLiteral */ ? 163 /* SyntaxKind.BigIntKeyword */ : 150 /* SyntaxKind.NumberKeyword */, context, isConstContext || preserveLiterals, requiresAddingUndefined);
                }
                break;
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
                return typeFromArrayLiteral(node, context, isConstContext, requiresAddingUndefined);
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                return typeFromObjectLiteral(node, context, isConstContext, requiresAddingUndefined);
            case 232 /* SyntaxKind.ClassExpression */:
                return syntacticResult(inferExpressionType(node, context, /*reportFallback*/ true, requiresAddingUndefined));
            case 229 /* SyntaxKind.TemplateExpression */:
                if (!isConstContext && !preserveLiterals) {
                    return syntacticResult(ts_js_1.factory.createKeywordTypeNode(154 /* SyntaxKind.StringKeyword */));
                }
                break;
            default:
                let typeKind;
                let primitiveNode = node;
                switch (node.kind) {
                    case 9 /* SyntaxKind.NumericLiteral */:
                        typeKind = 150 /* SyntaxKind.NumberKeyword */;
                        break;
                    case 15 /* SyntaxKind.NoSubstitutionTemplateLiteral */:
                        primitiveNode = ts_js_1.factory.createStringLiteral(node.text);
                        typeKind = 154 /* SyntaxKind.StringKeyword */;
                        break;
                    case 11 /* SyntaxKind.StringLiteral */:
                        typeKind = 154 /* SyntaxKind.StringKeyword */;
                        break;
                    case 10 /* SyntaxKind.BigIntLiteral */:
                        typeKind = 163 /* SyntaxKind.BigIntKeyword */;
                        break;
                    case 112 /* SyntaxKind.TrueKeyword */:
                    case 97 /* SyntaxKind.FalseKeyword */:
                        typeKind = 136 /* SyntaxKind.BooleanKeyword */;
                        break;
                }
                if (typeKind) {
                    return typeFromPrimitiveLiteral(primitiveNode, typeKind, context, isConstContext || preserveLiterals, requiresAddingUndefined);
                }
        }
        return failed;
    }
    function typeFromFunctionLikeExpression(fnNode, context) {
        const returnType = createReturnFromSignature(fnNode, /*symbol*/ undefined, context);
        const typeParameters = reuseTypeParameters(fnNode.typeParameters, context);
        const parameters = fnNode.parameters.map(p => ensureParameter(p, context));
        return syntacticResult(ts_js_1.factory.createFunctionTypeNode(typeParameters, parameters, returnType));
    }
    function canGetTypeFromArrayLiteral(arrayLiteral, context, isConstContext) {
        if (!isConstContext) {
            context.tracker.reportInferenceFallback(arrayLiteral);
            return false;
        }
        for (const element of arrayLiteral.elements) {
            if (element.kind === 231 /* SyntaxKind.SpreadElement */) {
                context.tracker.reportInferenceFallback(element);
                return false;
            }
        }
        return true;
    }
    function typeFromArrayLiteral(arrayLiteral, context, isConstContext, requiresAddingUndefined) {
        if (!canGetTypeFromArrayLiteral(arrayLiteral, context, isConstContext)) {
            if (requiresAddingUndefined || (0, ts_js_1.isDeclaration)((0, ts_js_1.walkUpParenthesizedExpressions)(arrayLiteral).parent)) {
                return alreadyReported;
            }
            return syntacticResult(inferExpressionType(arrayLiteral, context, /*reportFallback*/ false, requiresAddingUndefined));
        }
        // Disable any inference fallback since we won't actually use the resulting type and we don't want to generate errors
        const oldNoInferenceFallback = context.noInferenceFallback;
        context.noInferenceFallback = true;
        const elementTypesInfo = [];
        for (const element of arrayLiteral.elements) {
            ts_js_1.Debug.assert(element.kind !== 231 /* SyntaxKind.SpreadElement */);
            if (element.kind === 233 /* SyntaxKind.OmittedExpression */) {
                elementTypesInfo.push(createUndefinedTypeNode());
            }
            else {
                const expressionType = typeFromExpression(element, context, isConstContext);
                const elementType = expressionType.type !== undefined ? expressionType.type : inferExpressionType(element, context, expressionType.reportFallback);
                elementTypesInfo.push(elementType);
            }
        }
        const tupleType = ts_js_1.factory.createTupleTypeNode(elementTypesInfo);
        tupleType.emitNode = { flags: 1, autoGenerate: undefined, internalFlags: 0 };
        context.noInferenceFallback = oldNoInferenceFallback;
        return notImplemented;
    }
    function canGetTypeFromObjectLiteral(objectLiteral, context) {
        let result = true;
        for (const prop of objectLiteral.properties) {
            if (prop.flags & 262144 /* NodeFlags.ThisNodeHasError */) {
                result = false;
                break; // Bail if parse errors
            }
            if (prop.kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */ || prop.kind === 306 /* SyntaxKind.SpreadAssignment */) {
                context.tracker.reportInferenceFallback(prop);
                result = false;
            }
            else if (prop.name.flags & 262144 /* NodeFlags.ThisNodeHasError */) {
                result = false;
                break; // Bail if parse errors
            }
            else if (prop.name.kind === 81 /* SyntaxKind.PrivateIdentifier */) {
                // Not valid in object literals but the compiler will complain about this, we just ignore it here.
                result = false;
            }
            else if (prop.name.kind === 168 /* SyntaxKind.ComputedPropertyName */) {
                const expression = prop.name.expression;
                if (!(0, ts_js_1.isPrimitiveLiteralValue)(expression, /*includeBigInt*/ false) && !resolver.isDefinitelyReferenceToGlobalSymbolObject(expression)) {
                    context.tracker.reportInferenceFallback(prop.name);
                    result = false;
                }
            }
        }
        return result;
    }
    function typeFromObjectLiteral(objectLiteral, context, isConstContext, requiresAddingUndefined) {
        if (!canGetTypeFromObjectLiteral(objectLiteral, context)) {
            if (requiresAddingUndefined || (0, ts_js_1.isDeclaration)((0, ts_js_1.walkUpParenthesizedExpressions)(objectLiteral).parent)) {
                return alreadyReported;
            }
            return syntacticResult(inferExpressionType(objectLiteral, context, /*reportFallback*/ false, requiresAddingUndefined));
        }
        // Disable any inference fallback since we won't actually use the resulting type and we don't want to generate errors
        const oldNoInferenceFallback = context.noInferenceFallback;
        context.noInferenceFallback = true;
        const properties = [];
        const oldFlags = context.flags;
        context.flags |= 4194304 /* NodeBuilderFlags.InObjectTypeLiteral */;
        for (const prop of objectLiteral.properties) {
            ts_js_1.Debug.assert(!(0, ts_js_1.isShorthandPropertyAssignment)(prop) && !(0, ts_js_1.isSpreadAssignment)(prop));
            const name = prop.name;
            let newProp;
            switch (prop.kind) {
                case 175 /* SyntaxKind.MethodDeclaration */:
                    newProp = withNewScope(context, prop, () => typeFromObjectLiteralMethod(prop, name, context, isConstContext));
                    break;
                case 304 /* SyntaxKind.PropertyAssignment */:
                    newProp = typeFromObjectLiteralPropertyAssignment(prop, name, context, isConstContext);
                    break;
                case 179 /* SyntaxKind.SetAccessor */:
                case 178 /* SyntaxKind.GetAccessor */:
                    newProp = typeFromObjectLiteralAccessor(prop, name, context);
                    break;
            }
            if (newProp) {
                (0, ts_js_1.setCommentRange)(newProp, prop);
                properties.push(newProp);
            }
        }
        context.flags = oldFlags;
        const typeNode = ts_js_1.factory.createTypeLiteralNode(properties);
        if (!(context.flags & 1024 /* NodeBuilderFlags.MultilineObjectLiterals */)) {
            (0, ts_js_1.setEmitFlags)(typeNode, 1 /* EmitFlags.SingleLine */);
        }
        context.noInferenceFallback = oldNoInferenceFallback;
        return notImplemented;
    }
    function typeFromObjectLiteralPropertyAssignment(prop, name, context, isConstContext) {
        const modifiers = isConstContext ?
            [ts_js_1.factory.createModifier(148 /* SyntaxKind.ReadonlyKeyword */)] :
            [];
        const expressionResult = typeFromExpression(prop.initializer, context, isConstContext);
        const typeNode = expressionResult.type !== undefined ? expressionResult.type : inferTypeOfDeclaration(prop, /*symbol*/ undefined, context, expressionResult.reportFallback);
        return ts_js_1.factory.createPropertySignature(modifiers, reuseNode(context, name), 
        /*questionToken*/ undefined, typeNode);
    }
    function ensureParameter(p, context) {
        return ts_js_1.factory.updateParameterDeclaration(p, 
        /*modifiers*/ undefined, reuseNode(context, p.dotDotDotToken), resolver.serializeNameOfParameter(context, p), resolver.isOptionalParameter(p) ? ts_js_1.factory.createToken(58 /* SyntaxKind.QuestionToken */) : undefined, typeFromParameter(p, /*symbol*/ undefined, context), // Ignore private param props, since this type is going straight back into a param
        /*initializer*/ undefined);
    }
    function reuseTypeParameters(typeParameters, context) {
        return typeParameters?.map(tp => {
            const { node: tpName } = resolver.trackExistingEntityName(context, tp.name);
            return ts_js_1.factory.updateTypeParameterDeclaration(tp, tp.modifiers?.map(m => reuseNode(context, m)), tpName, serializeExistingTypeNodeWithFallback(tp.constraint, context), serializeExistingTypeNodeWithFallback(tp.default, context));
        });
    }
    function typeFromObjectLiteralMethod(method, name, context, isConstContext) {
        const returnType = createReturnFromSignature(method, /*symbol*/ undefined, context);
        const typeParameters = reuseTypeParameters(method.typeParameters, context);
        const parameters = method.parameters.map(p => ensureParameter(p, context));
        if (isConstContext) {
            return ts_js_1.factory.createPropertySignature([ts_js_1.factory.createModifier(148 /* SyntaxKind.ReadonlyKeyword */)], reuseNode(context, name), reuseNode(context, method.questionToken), ts_js_1.factory.createFunctionTypeNode(typeParameters, parameters, returnType));
        }
        else {
            if ((0, ts_js_1.isIdentifier)(name) && name.escapedText === "new") {
                name = ts_js_1.factory.createStringLiteral("new");
            }
            return ts_js_1.factory.createMethodSignature([], reuseNode(context, name), reuseNode(context, method.questionToken), typeParameters, parameters, returnType);
        }
    }
    function typeFromObjectLiteralAccessor(accessor, name, context) {
        const allAccessors = resolver.getAllAccessorDeclarations(accessor);
        const getAccessorType = allAccessors.getAccessor && getTypeAnnotationFromAccessor(allAccessors.getAccessor);
        const setAccessorType = allAccessors.setAccessor && getTypeAnnotationFromAccessor(allAccessors.setAccessor);
        // We have types for both accessors, we can't know if they are the same type so we keep both accessors
        if (getAccessorType !== undefined && setAccessorType !== undefined) {
            return withNewScope(context, accessor, () => {
                const parameters = accessor.parameters.map(p => ensureParameter(p, context));
                if ((0, ts_js_1.isGetAccessor)(accessor)) {
                    return ts_js_1.factory.updateGetAccessorDeclaration(accessor, [], reuseNode(context, name), parameters, serializeExistingTypeNodeWithFallback(getAccessorType, context), 
                    /*body*/ undefined);
                }
                else {
                    return ts_js_1.factory.updateSetAccessorDeclaration(accessor, [], reuseNode(context, name), parameters, 
                    /*body*/ undefined);
                }
            });
        }
        else if (allAccessors.firstAccessor === accessor) {
            const foundType = getAccessorType ? withNewScope(context, allAccessors.getAccessor, () => serializeExistingTypeNodeWithFallback(getAccessorType, context)) :
                setAccessorType ? withNewScope(context, allAccessors.setAccessor, () => serializeExistingTypeNodeWithFallback(setAccessorType, context)) :
                    undefined;
            const propertyType = foundType ?? inferAccessorType(accessor, allAccessors, context, /*symbol*/ undefined);
            const propertySignature = ts_js_1.factory.createPropertySignature(allAccessors.setAccessor === undefined ? [ts_js_1.factory.createModifier(148 /* SyntaxKind.ReadonlyKeyword */)] : [], reuseNode(context, name), 
            /*questionToken*/ undefined, propertyType);
            return propertySignature;
        }
    }
    function createUndefinedTypeNode() {
        if (strictNullChecks) {
            return ts_js_1.factory.createKeywordTypeNode(157 /* SyntaxKind.UndefinedKeyword */);
        }
        else {
            return ts_js_1.factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
        }
    }
    function typeFromPrimitiveLiteral(node, baseType, context, preserveLiterals, requiresAddingUndefined) {
        let result;
        if (preserveLiterals) {
            if (node.kind === 225 /* SyntaxKind.PrefixUnaryExpression */ && node.operator === 40 /* SyntaxKind.PlusToken */) {
                result = ts_js_1.factory.createLiteralTypeNode(reuseNode(context, node.operand));
            }
            result = ts_js_1.factory.createLiteralTypeNode(reuseNode(context, node));
        }
        else {
            result = ts_js_1.factory.createKeywordTypeNode(baseType);
        }
        return syntacticResult(addUndefinedIfNeeded(result, requiresAddingUndefined, node, context));
    }
    function addUndefinedIfNeeded(node, addUndefined, owner, context) {
        const parentDeclaration = owner && (0, ts_js_1.walkUpParenthesizedExpressions)(owner).parent;
        const optionalDeclaration = parentDeclaration && (0, ts_js_1.isDeclaration)(parentDeclaration) && (0, ts_js_1.isOptionalDeclaration)(parentDeclaration);
        if (!strictNullChecks || !(addUndefined || optionalDeclaration))
            return node;
        if (!canAddUndefined(node)) {
            context.tracker.reportInferenceFallback(node);
        }
        if ((0, ts_js_1.isUnionTypeNode)(node)) {
            return ts_js_1.factory.createUnionTypeNode([...node.types, ts_js_1.factory.createKeywordTypeNode(157 /* SyntaxKind.UndefinedKeyword */)]);
        }
        return ts_js_1.factory.createUnionTypeNode([node, ts_js_1.factory.createKeywordTypeNode(157 /* SyntaxKind.UndefinedKeyword */)]);
    }
    function canAddUndefined(node) {
        if (!strictNullChecks)
            return true;
        if ((0, ts_js_1.isKeyword)(node.kind)
            || node.kind === 202 /* SyntaxKind.LiteralType */
            || node.kind === 185 /* SyntaxKind.FunctionType */
            || node.kind === 186 /* SyntaxKind.ConstructorType */
            || node.kind === 189 /* SyntaxKind.ArrayType */
            || node.kind === 190 /* SyntaxKind.TupleType */
            || node.kind === 188 /* SyntaxKind.TypeLiteral */
            || node.kind === 204 /* SyntaxKind.TemplateLiteralType */
            || node.kind === 198 /* SyntaxKind.ThisType */) {
            return true;
        }
        if (node.kind === 197 /* SyntaxKind.ParenthesizedType */) {
            return canAddUndefined(node.type);
        }
        if (node.kind === 193 /* SyntaxKind.UnionType */ || node.kind === 194 /* SyntaxKind.IntersectionType */) {
            return node.types.every(canAddUndefined);
        }
        return false;
    }
    function createReturnFromSignature(fn, symbol, context, reportFallback = true) {
        let returnType = failed;
        const returnTypeNode = (0, ts_js_1.isJSDocConstructSignature)(fn) ? (0, ts_js_1.getEffectiveTypeAnnotationNode)(fn.parameters[0]) : (0, ts_js_1.getEffectiveReturnTypeNode)(fn);
        if (returnTypeNode) {
            returnType = syntacticResult(serializeTypeAnnotationOfDeclaration(returnTypeNode, context, fn, symbol));
        }
        else if ((0, ts_js_1.isValueSignatureDeclaration)(fn)) {
            returnType = typeFromSingleReturnExpression(fn, context);
        }
        return returnType.type !== undefined ? returnType.type : inferReturnTypeOfSignatureSignature(fn, context, symbol, reportFallback && returnType.reportFallback && !returnTypeNode);
    }
    function typeFromSingleReturnExpression(declaration, context) {
        let candidateExpr;
        if (declaration && !(0, ts_js_1.nodeIsMissing)(declaration.body)) {
            const flags = (0, ts_js_1.getFunctionFlags)(declaration);
            if (flags & 3 /* FunctionFlags.AsyncGenerator */)
                return failed;
            const body = declaration.body;
            if (body && (0, ts_js_1.isBlock)(body)) {
                (0, ts_js_1.forEachReturnStatement)(body, s => {
                    if (s.parent !== body) {
                        candidateExpr = undefined;
                        return true;
                    }
                    if (!candidateExpr) {
                        candidateExpr = s.expression;
                    }
                    else {
                        candidateExpr = undefined;
                        return true;
                    }
                });
            }
            else {
                candidateExpr = body;
            }
        }
        if (candidateExpr) {
            if (isContextuallyTyped(candidateExpr)) {
                const type = (0, ts_js_1.isJSDocTypeAssertion)(candidateExpr) ? (0, ts_js_1.getJSDocTypeAssertionType)(candidateExpr) :
                    (0, ts_js_1.isAsExpression)(candidateExpr) || (0, ts_js_1.isTypeAssertionExpression)(candidateExpr) ? candidateExpr.type :
                        undefined;
                if (type && !(0, ts_js_1.isConstTypeReference)(type)) {
                    return syntacticResult(serializeExistingTypeNode(type, context));
                }
            }
            else {
                return typeFromExpression(candidateExpr, context);
            }
        }
        return failed;
    }
    function isContextuallyTyped(node) {
        return (0, ts_js_1.findAncestor)(node.parent, n => {
            // Functions calls or parent type annotations (but not the return type of a function expression) may impact the inferred type and local inference is unreliable
            return (0, ts_js_1.isCallExpression)(n) || (!(0, ts_js_1.isFunctionLikeDeclaration)(n) && !!(0, ts_js_1.getEffectiveTypeAnnotationNode)(n)) || (0, ts_js_1.isJsxElement)(n) || (0, ts_js_1.isJsxExpression)(n);
        });
    }
}
