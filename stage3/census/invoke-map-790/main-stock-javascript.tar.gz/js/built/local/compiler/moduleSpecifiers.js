"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelativePreference = void 0;
exports.getModuleSpecifierPreferences = getModuleSpecifierPreferences;
exports.updateModuleSpecifier = updateModuleSpecifier;
exports.getModuleSpecifier = getModuleSpecifier;
exports.getNodeModulesPackageName = getNodeModulesPackageName;
exports.tryGetModuleSpecifiersFromCache = tryGetModuleSpecifiersFromCache;
exports.getModuleSpecifiers = getModuleSpecifiers;
exports.getModuleSpecifiersWithCacheInfo = getModuleSpecifiersWithCacheInfo;
exports.getLocalModuleSpecifierBetweenFileNames = getLocalModuleSpecifierBetweenFileNames;
exports.countPathComponents = countPathComponents;
exports.forEachFileNameOfModule = forEachFileNameOfModule;
exports.tryGetRealFileNameForNonJsDeclarationFileName = tryGetRealFileNameForNonJsDeclarationFileName;
exports.tryGetJSExtensionForFile = tryGetJSExtensionForFile;
const ts_js_1 = require("./_namespaces/ts.js");
const stringToRegex = (0, ts_js_1.memoizeOne)((pattern) => {
    try {
        let slash = pattern.indexOf("/");
        if (slash !== 0) {
            // No leading slash, treat as a pattern
            return new RegExp(pattern);
        }
        const lastSlash = pattern.lastIndexOf("/");
        if (slash === lastSlash) {
            // Only one slash, treat as a pattern
            return new RegExp(pattern);
        }
        while ((slash = pattern.indexOf("/", slash + 1)) !== lastSlash) {
            if (pattern[slash - 1] !== "\\") {
                // Unescaped middle slash, treat as a pattern
                return new RegExp(pattern);
            }
        }
        // Only case-insensitive and unicode flags make sense
        const flags = pattern.substring(lastSlash + 1).replace(/[^iu]/g, "");
        pattern = pattern.substring(1, lastSlash);
        return new RegExp(pattern, flags);
    }
    catch {
        return undefined;
    }
});
// Used by importFixes, getEditsForFileRename, and declaration emit to synthesize import module specifiers.
/** @internal */
var RelativePreference;
(function (RelativePreference) {
    RelativePreference[RelativePreference["Relative"] = 0] = "Relative";
    RelativePreference[RelativePreference["NonRelative"] = 1] = "NonRelative";
    RelativePreference[RelativePreference["Shortest"] = 2] = "Shortest";
    RelativePreference[RelativePreference["ExternalNonRelative"] = 3] = "ExternalNonRelative";
})(RelativePreference || (exports.RelativePreference = RelativePreference = {}));
/** @internal */
function getModuleSpecifierPreferences({ importModuleSpecifierPreference, importModuleSpecifierEnding, autoImportSpecifierExcludeRegexes }, host, compilerOptions, importingSourceFile, oldImportSpecifier) {
    const filePreferredEnding = getPreferredEnding();
    return {
        excludeRegexes: autoImportSpecifierExcludeRegexes,
        relativePreference: oldImportSpecifier !== undefined ? ((0, ts_js_1.isExternalModuleNameRelative)(oldImportSpecifier) ?
            0 /* RelativePreference.Relative */ :
            1 /* RelativePreference.NonRelative */) :
            importModuleSpecifierPreference === "relative" ? 0 /* RelativePreference.Relative */ :
                importModuleSpecifierPreference === "non-relative" ? 1 /* RelativePreference.NonRelative */ :
                    importModuleSpecifierPreference === "project-relative" ? 3 /* RelativePreference.ExternalNonRelative */ :
                        2 /* RelativePreference.Shortest */,
        getAllowedEndingsInPreferredOrder: syntaxImpliedNodeFormat => {
            const impliedNodeFormat = getDefaultResolutionModeForFile(importingSourceFile, host, compilerOptions);
            const preferredEnding = syntaxImpliedNodeFormat !== impliedNodeFormat ? getPreferredEnding(syntaxImpliedNodeFormat) : filePreferredEnding;
            const moduleResolution = (0, ts_js_1.getEmitModuleResolutionKind)(compilerOptions);
            if ((syntaxImpliedNodeFormat ?? impliedNodeFormat) === ts_js_1.ModuleKind.ESNext && ts_js_1.ModuleResolutionKind.Node16 <= moduleResolution && moduleResolution <= ts_js_1.ModuleResolutionKind.NodeNext) {
                if ((0, ts_js_1.shouldAllowImportingTsExtension)(compilerOptions, importingSourceFile.fileName)) {
                    return [3 /* ModuleSpecifierEnding.TsExtension */, 2 /* ModuleSpecifierEnding.JsExtension */];
                }
                return [2 /* ModuleSpecifierEnding.JsExtension */];
            }
            if ((0, ts_js_1.getEmitModuleResolutionKind)(compilerOptions) === ts_js_1.ModuleResolutionKind.Classic) {
                return preferredEnding === 2 /* ModuleSpecifierEnding.JsExtension */
                    ? [2 /* ModuleSpecifierEnding.JsExtension */, 1 /* ModuleSpecifierEnding.Index */]
                    : [1 /* ModuleSpecifierEnding.Index */, 2 /* ModuleSpecifierEnding.JsExtension */];
            }
            const allowImportingTsExtension = (0, ts_js_1.shouldAllowImportingTsExtension)(compilerOptions, importingSourceFile.fileName);
            switch (preferredEnding) {
                case 2 /* ModuleSpecifierEnding.JsExtension */:
                    return allowImportingTsExtension
                        ? [2 /* ModuleSpecifierEnding.JsExtension */, 3 /* ModuleSpecifierEnding.TsExtension */, 0 /* ModuleSpecifierEnding.Minimal */, 1 /* ModuleSpecifierEnding.Index */]
                        : [2 /* ModuleSpecifierEnding.JsExtension */, 0 /* ModuleSpecifierEnding.Minimal */, 1 /* ModuleSpecifierEnding.Index */];
                case 3 /* ModuleSpecifierEnding.TsExtension */:
                    return [3 /* ModuleSpecifierEnding.TsExtension */, 0 /* ModuleSpecifierEnding.Minimal */, 2 /* ModuleSpecifierEnding.JsExtension */, 1 /* ModuleSpecifierEnding.Index */];
                case 1 /* ModuleSpecifierEnding.Index */:
                    return allowImportingTsExtension
                        ? [1 /* ModuleSpecifierEnding.Index */, 0 /* ModuleSpecifierEnding.Minimal */, 3 /* ModuleSpecifierEnding.TsExtension */, 2 /* ModuleSpecifierEnding.JsExtension */]
                        : [1 /* ModuleSpecifierEnding.Index */, 0 /* ModuleSpecifierEnding.Minimal */, 2 /* ModuleSpecifierEnding.JsExtension */];
                case 0 /* ModuleSpecifierEnding.Minimal */:
                    return allowImportingTsExtension
                        ? [0 /* ModuleSpecifierEnding.Minimal */, 1 /* ModuleSpecifierEnding.Index */, 3 /* ModuleSpecifierEnding.TsExtension */, 2 /* ModuleSpecifierEnding.JsExtension */]
                        : [0 /* ModuleSpecifierEnding.Minimal */, 1 /* ModuleSpecifierEnding.Index */, 2 /* ModuleSpecifierEnding.JsExtension */];
                default:
                    ts_js_1.Debug.assertNever(preferredEnding);
            }
        },
    };
    function getPreferredEnding(resolutionMode) {
        if (oldImportSpecifier !== undefined) {
            if ((0, ts_js_1.hasJSFileExtension)(oldImportSpecifier))
                return 2 /* ModuleSpecifierEnding.JsExtension */;
            if ((0, ts_js_1.endsWith)(oldImportSpecifier, "/index"))
                return 1 /* ModuleSpecifierEnding.Index */;
        }
        return (0, ts_js_1.getModuleSpecifierEndingPreference)(importModuleSpecifierEnding, resolutionMode ?? getDefaultResolutionModeForFile(importingSourceFile, host, compilerOptions), compilerOptions, (0, ts_js_1.isFullSourceFile)(importingSourceFile) ? importingSourceFile : undefined);
    }
}
// `importingSourceFile` and `importingSourceFileName`? Why not just use `importingSourceFile.path`?
// Because when this is called by the file renamer, `importingSourceFile` is the file being renamed,
// while `importingSourceFileName` its *new* name. We need a source file just to get its
// `impliedNodeFormat` and to detect certain preferences from existing import module specifiers.
/** @internal */
function updateModuleSpecifier(compilerOptions, importingSourceFile, importingSourceFileName, toFileName, host, oldImportSpecifier, options = {}) {
    const res = getModuleSpecifierWorker(compilerOptions, importingSourceFile, importingSourceFileName, toFileName, host, getModuleSpecifierPreferences({}, host, compilerOptions, importingSourceFile, oldImportSpecifier), {}, options);
    if (res === oldImportSpecifier)
        return undefined;
    return res;
}
// `importingSourceFile` and `importingSourceFileName`? Why not just use `importingSourceFile.path`?
// Because when this is called by the declaration emitter, `importingSourceFile` is the implementation
// file, but `importingSourceFileName` and `toFileName` refer to declaration files (the former to the
// one currently being produced; the latter to the one being imported). We need an implementation file
// just to get its `impliedNodeFormat` and to detect certain preferences from existing import module
// specifiers.
/** @internal */
function getModuleSpecifier(compilerOptions, importingSourceFile, importingSourceFileName, toFileName, host, options = {}) {
    return getModuleSpecifierWorker(compilerOptions, importingSourceFile, importingSourceFileName, toFileName, host, getModuleSpecifierPreferences({}, host, compilerOptions, importingSourceFile), {}, options);
}
/** @internal */
function getNodeModulesPackageName(compilerOptions, importingSourceFile, nodeModulesFileName, host, preferences, options = {}) {
    const info = getInfo(importingSourceFile.fileName, host);
    const modulePaths = getAllModulePaths(info, nodeModulesFileName, host, preferences, compilerOptions, options);
    return (0, ts_js_1.firstDefined)(modulePaths, modulePath => tryGetModuleNameAsNodeModule(modulePath, info, importingSourceFile, host, compilerOptions, preferences, /*packageNameOnly*/ true, options.overrideImportMode));
}
function getModuleSpecifierWorker(compilerOptions, importingSourceFile, importingSourceFileName, toFileName, host, preferences, userPreferences, options = {}) {
    const info = getInfo(importingSourceFileName, host);
    const modulePaths = getAllModulePaths(info, toFileName, host, userPreferences, compilerOptions, options);
    return (0, ts_js_1.firstDefined)(modulePaths, modulePath => tryGetModuleNameAsNodeModule(modulePath, info, importingSourceFile, host, compilerOptions, userPreferences, /*packageNameOnly*/ undefined, options.overrideImportMode)) ||
        getLocalModuleSpecifier(toFileName, info, compilerOptions, host, options.overrideImportMode || getDefaultResolutionModeForFile(importingSourceFile, host, compilerOptions), preferences);
}
/** @internal */
function tryGetModuleSpecifiersFromCache(moduleSymbol, importingSourceFile, host, userPreferences, options = {}) {
    const result = tryGetModuleSpecifiersFromCacheWorker(moduleSymbol, importingSourceFile, host, userPreferences, options);
    return result[1] && { kind: result[0], moduleSpecifiers: result[1], computedWithoutCache: false };
}
function tryGetModuleSpecifiersFromCacheWorker(moduleSymbol, importingSourceFile, host, userPreferences, options = {}) {
    const moduleSourceFile = (0, ts_js_1.getSourceFileOfModule)(moduleSymbol);
    if (!moduleSourceFile) {
        return ts_js_1.emptyArray;
    }
    const cache = host.getModuleSpecifierCache?.();
    const cached = cache?.get(importingSourceFile.path, moduleSourceFile.path, userPreferences, options);
    return [cached?.kind, cached?.moduleSpecifiers, moduleSourceFile, cached?.modulePaths, cache];
}
/**
 * Returns an import for each symlink and for the realpath.
 *
 * @internal
 */
function getModuleSpecifiers(moduleSymbol, checker, compilerOptions, importingSourceFile, host, userPreferences, options = {}) {
    return getModuleSpecifiersWithCacheInfo(moduleSymbol, checker, compilerOptions, importingSourceFile, host, userPreferences, options, 
    /*forAutoImport*/ false).moduleSpecifiers;
}
/** @internal */
function getModuleSpecifiersWithCacheInfo(moduleSymbol, checker, compilerOptions, importingSourceFile, host, userPreferences, options = {}, forAutoImport) {
    let computedWithoutCache = false;
    const ambient = tryGetModuleNameFromAmbientModule(moduleSymbol, checker);
    if (ambient) {
        return {
            kind: "ambient",
            moduleSpecifiers: !(forAutoImport && isExcludedByRegex(ambient, userPreferences.autoImportSpecifierExcludeRegexes)) ? [ambient] : ts_js_1.emptyArray,
            computedWithoutCache,
        };
    }
    // eslint-disable-next-line prefer-const
    let [kind, specifiers, moduleSourceFile, modulePaths, cache] = tryGetModuleSpecifiersFromCacheWorker(moduleSymbol, importingSourceFile, host, userPreferences, options);
    if (specifiers)
        return { kind, moduleSpecifiers: specifiers, computedWithoutCache };
    if (!moduleSourceFile)
        return { kind: undefined, moduleSpecifiers: ts_js_1.emptyArray, computedWithoutCache };
    computedWithoutCache = true;
    modulePaths || (modulePaths = getAllModulePathsWorker(getInfo(importingSourceFile.fileName, host), moduleSourceFile.originalFileName, host, compilerOptions, options));
    const result = computeModuleSpecifiers(modulePaths, compilerOptions, importingSourceFile, host, userPreferences, options, forAutoImport);
    cache?.set(importingSourceFile.path, moduleSourceFile.path, userPreferences, options, result.kind, modulePaths, result.moduleSpecifiers);
    return result;
}
/** @internal */
function getLocalModuleSpecifierBetweenFileNames(importingFile, targetFileName, compilerOptions, host, preferences, options = {}) {
    const info = getInfo(importingFile.fileName, host);
    const importMode = options.overrideImportMode ?? importingFile.impliedNodeFormat;
    return getLocalModuleSpecifier(targetFileName, info, compilerOptions, host, importMode, getModuleSpecifierPreferences(preferences, host, compilerOptions, importingFile));
}
function computeModuleSpecifiers(modulePaths, compilerOptions, importingSourceFile, host, userPreferences, options = {}, forAutoImport) {
    const info = getInfo(importingSourceFile.fileName, host);
    const preferences = getModuleSpecifierPreferences(userPreferences, host, compilerOptions, importingSourceFile);
    const existingSpecifier = (0, ts_js_1.isFullSourceFile)(importingSourceFile) && (0, ts_js_1.forEach)(modulePaths, modulePath => (0, ts_js_1.forEach)(host.getFileIncludeReasons().get((0, ts_js_1.toPath)(modulePath.path, host.getCurrentDirectory(), info.getCanonicalFileName)), reason => {
        if (reason.kind !== ts_js_1.FileIncludeKind.Import || reason.file !== importingSourceFile.path)
            return undefined;
        // If the candidate import mode doesn't match the mode we're generating for, don't consider it
        // TODO: maybe useful to keep around as an alternative option for certain contexts where the mode is overridable
        const existingMode = host.getModeForResolutionAtIndex(importingSourceFile, reason.index);
        const targetMode = options.overrideImportMode ?? host.getDefaultResolutionModeForFile(importingSourceFile);
        if (existingMode !== targetMode && existingMode !== undefined && targetMode !== undefined) {
            return undefined;
        }
        const specifier = (0, ts_js_1.getModuleNameStringLiteralAt)(importingSourceFile, reason.index).text;
        // If the preference is for non relative and the module specifier is relative, ignore it
        return preferences.relativePreference !== 1 /* RelativePreference.NonRelative */ || !(0, ts_js_1.pathIsRelative)(specifier) ?
            specifier :
            undefined;
    }));
    if (existingSpecifier) {
        return { kind: undefined, moduleSpecifiers: [existingSpecifier], computedWithoutCache: true };
    }
    const importedFileIsInNodeModules = (0, ts_js_1.some)(modulePaths, p => p.isInNodeModules);
    // Module specifier priority:
    //   1. "Bare package specifiers" (e.g. "@foo/bar") resulting from a path through node_modules to a package.json's "types" entry
    //   2. Specifiers generated using "paths" from tsconfig
    //   3. Non-relative specfiers resulting from a path through node_modules (e.g. "@foo/bar/path/to/file")
    //   4. Relative paths
    let nodeModulesSpecifiers;
    let pathsSpecifiers;
    let redirectPathsSpecifiers;
    let relativeSpecifiers;
    for (const modulePath of modulePaths) {
        const specifier = modulePath.isInNodeModules
            ? tryGetModuleNameAsNodeModule(modulePath, info, importingSourceFile, host, compilerOptions, userPreferences, /*packageNameOnly*/ undefined, options.overrideImportMode)
            : undefined;
        if (specifier && !(forAutoImport && isExcludedByRegex(specifier, preferences.excludeRegexes))) {
            nodeModulesSpecifiers = (0, ts_js_1.append)(nodeModulesSpecifiers, specifier);
            if (modulePath.isRedirect) {
                // If we got a specifier for a redirect, it was a bare package specifier (e.g. "@foo/bar",
                // not "@foo/bar/path/to/file"). No other specifier will be this good, so stop looking.
                return { kind: "node_modules", moduleSpecifiers: nodeModulesSpecifiers, computedWithoutCache: true };
            }
        }
        const local = getLocalModuleSpecifier(modulePath.path, info, compilerOptions, host, options.overrideImportMode || importingSourceFile.impliedNodeFormat, preferences, 
        /*pathsOnly*/ modulePath.isRedirect || !!specifier);
        if (!local || forAutoImport && isExcludedByRegex(local, preferences.excludeRegexes)) {
            continue;
        }
        if (modulePath.isRedirect) {
            redirectPathsSpecifiers = (0, ts_js_1.append)(redirectPathsSpecifiers, local);
        }
        else if ((0, ts_js_1.pathIsBareSpecifier)(local)) {
            if ((0, ts_js_1.pathContainsNodeModules)(local)) {
                // We could be in this branch due to inappropriate use of `baseUrl`, not intentional `paths`
                // usage. It's impossible to reason about where to prioritize baseUrl-generated module
                // specifiers, but if they contain `/node_modules/`, they're going to trigger a portability
                // error, so *at least* don't prioritize those.
                relativeSpecifiers = (0, ts_js_1.append)(relativeSpecifiers, local);
            }
            else {
                pathsSpecifiers = (0, ts_js_1.append)(pathsSpecifiers, local);
            }
        }
        else if (forAutoImport || !importedFileIsInNodeModules || modulePath.isInNodeModules) {
            // Why this extra conditional, not just an `else`? If some path to the file contained
            // 'node_modules', but we can't create a non-relative specifier (e.g. "@foo/bar/path/to/file"),
            // that means we had to go through a *sibling's* node_modules, not one we can access directly.
            // If some path to the file was in node_modules but another was not, this likely indicates that
            // we have a monorepo structure with symlinks. In this case, the non-node_modules path is
            // probably the realpath, e.g. "../bar/path/to/file", but a relative path to another package
            // in a monorepo is probably not portable. So, the module specifier we actually go with will be
            // the relative path through node_modules, so that the declaration emitter can produce a
            // portability error. (See declarationEmitReexportedSymlinkReference3)
            relativeSpecifiers = (0, ts_js_1.append)(relativeSpecifiers, local);
        }
    }
    return pathsSpecifiers?.length ? { kind: "paths", moduleSpecifiers: pathsSpecifiers, computedWithoutCache: true } :
        redirectPathsSpecifiers?.length ? { kind: "redirect", moduleSpecifiers: redirectPathsSpecifiers, computedWithoutCache: true } :
            nodeModulesSpecifiers?.length ? { kind: "node_modules", moduleSpecifiers: nodeModulesSpecifiers, computedWithoutCache: true } :
                { kind: "relative", moduleSpecifiers: relativeSpecifiers ?? ts_js_1.emptyArray, computedWithoutCache: true };
}
function isExcludedByRegex(moduleSpecifier, excludeRegexes) {
    return (0, ts_js_1.some)(excludeRegexes, pattern => !!stringToRegex(pattern)?.test(moduleSpecifier));
}
// importingSourceFileName is separate because getEditsForFileRename may need to specify an updated path
function getInfo(importingSourceFileName, host) {
    importingSourceFileName = (0, ts_js_1.getNormalizedAbsolutePath)(importingSourceFileName, host.getCurrentDirectory());
    const getCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(host.useCaseSensitiveFileNames ? host.useCaseSensitiveFileNames() : true);
    const sourceDirectory = (0, ts_js_1.getDirectoryPath)(importingSourceFileName);
    return {
        getCanonicalFileName,
        importingSourceFileName,
        sourceDirectory,
        canonicalSourceDirectory: getCanonicalFileName(sourceDirectory),
    };
}
function getLocalModuleSpecifier(moduleFileName, info, compilerOptions, host, importMode, { getAllowedEndingsInPreferredOrder: getAllowedEndingsInPrefererredOrder, relativePreference, excludeRegexes }, pathsOnly) {
    const { baseUrl, paths, rootDirs } = compilerOptions;
    if (pathsOnly && !paths) {
        return undefined;
    }
    const { sourceDirectory, canonicalSourceDirectory, getCanonicalFileName } = info;
    const allowedEndings = getAllowedEndingsInPrefererredOrder(importMode);
    const relativePath = rootDirs && tryGetModuleNameFromRootDirs(rootDirs, moduleFileName, sourceDirectory, getCanonicalFileName, allowedEndings, compilerOptions) ||
        processEnding((0, ts_js_1.ensurePathIsNonModuleName)((0, ts_js_1.getRelativePathFromDirectory)(sourceDirectory, moduleFileName, getCanonicalFileName)), allowedEndings, compilerOptions);
    if (!baseUrl && !paths && !(0, ts_js_1.getResolvePackageJsonImports)(compilerOptions) || relativePreference === 0 /* RelativePreference.Relative */) {
        return pathsOnly ? undefined : relativePath;
    }
    const baseDirectory = (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.getPathsBasePath)(compilerOptions, host) || baseUrl, host.getCurrentDirectory());
    const relativeToBaseUrl = getRelativePathIfInSameVolume(moduleFileName, baseDirectory, getCanonicalFileName);
    if (!relativeToBaseUrl) {
        return pathsOnly ? undefined : relativePath;
    }
    const fromPackageJsonImports = pathsOnly
        ? undefined
        : tryGetModuleNameFromPackageJsonImports(moduleFileName, sourceDirectory, compilerOptions, host, importMode, prefersTsExtension(allowedEndings));
    const fromPaths = pathsOnly || fromPackageJsonImports === undefined ? paths && tryGetModuleNameFromPaths(relativeToBaseUrl, paths, allowedEndings, baseDirectory, getCanonicalFileName, host, compilerOptions) : undefined;
    if (pathsOnly) {
        return fromPaths;
    }
    const maybeNonRelative = fromPackageJsonImports ?? (fromPaths === undefined && baseUrl !== undefined ? processEnding(relativeToBaseUrl, allowedEndings, compilerOptions) : fromPaths);
    if (!maybeNonRelative) {
        return relativePath;
    }
    const relativeIsExcluded = isExcludedByRegex(relativePath, excludeRegexes);
    const nonRelativeIsExcluded = isExcludedByRegex(maybeNonRelative, excludeRegexes);
    if (!relativeIsExcluded && nonRelativeIsExcluded) {
        return relativePath;
    }
    if (relativeIsExcluded && !nonRelativeIsExcluded) {
        return maybeNonRelative;
    }
    if (relativePreference === 1 /* RelativePreference.NonRelative */ && !(0, ts_js_1.pathIsRelative)(maybeNonRelative)) {
        return maybeNonRelative;
    }
    if (relativePreference === 3 /* RelativePreference.ExternalNonRelative */ && !(0, ts_js_1.pathIsRelative)(maybeNonRelative)) {
        const projectDirectory = compilerOptions.configFilePath ?
            (0, ts_js_1.toPath)((0, ts_js_1.getDirectoryPath)(compilerOptions.configFilePath), host.getCurrentDirectory(), info.getCanonicalFileName) :
            info.getCanonicalFileName(host.getCurrentDirectory());
        const modulePath = (0, ts_js_1.toPath)(moduleFileName, projectDirectory, getCanonicalFileName);
        const sourceIsInternal = (0, ts_js_1.startsWith)(canonicalSourceDirectory, projectDirectory);
        const targetIsInternal = (0, ts_js_1.startsWith)(modulePath, projectDirectory);
        if (sourceIsInternal && !targetIsInternal || !sourceIsInternal && targetIsInternal) {
            // 1. The import path crosses the boundary of the tsconfig.json-containing directory.
            //
            //      src/
            //        tsconfig.json
            //        index.ts -------
            //      lib/              | (path crosses tsconfig.json)
            //        imported.ts <---
            //
            return maybeNonRelative;
        }
        const nearestTargetPackageJson = getNearestAncestorDirectoryWithPackageJson(host, (0, ts_js_1.getDirectoryPath)(modulePath));
        const nearestSourcePackageJson = getNearestAncestorDirectoryWithPackageJson(host, sourceDirectory);
        const ignoreCase = !(0, ts_js_1.hostUsesCaseSensitiveFileNames)(host);
        if (!packageJsonPathsAreEqual(nearestTargetPackageJson, nearestSourcePackageJson, ignoreCase)) {
            // 2. The importing and imported files are part of different packages.
            //
            //      packages/a/
            //        package.json
            //        index.ts --------
            //      packages/b/        | (path crosses package.json)
            //        package.json     |
            //        component.ts <---
            //
            return maybeNonRelative;
        }
        return relativePath;
    }
    // Prefer a relative import over a baseUrl import if it has fewer components.
    return isPathRelativeToParent(maybeNonRelative) || countPathComponents(relativePath) < countPathComponents(maybeNonRelative) ? relativePath : maybeNonRelative;
}
function packageJsonPathsAreEqual(a, b, ignoreCase) {
    if (a === b)
        return true;
    if (a === undefined || b === undefined)
        return false;
    return (0, ts_js_1.comparePaths)(a, b, ignoreCase) === 0 /* Comparison.EqualTo */;
}
/** @internal */
function countPathComponents(path) {
    let count = 0;
    for (let i = (0, ts_js_1.startsWith)(path, "./") ? 2 : 0; i < path.length; i++) {
        if (path.charCodeAt(i) === 47 /* CharacterCodes.slash */)
            count++;
    }
    return count;
}
function comparePathsByRedirectAndNumberOfDirectorySeparators(a, b) {
    return (0, ts_js_1.compareBooleans)(b.isRedirect, a.isRedirect) || (0, ts_js_1.compareNumberOfDirectorySeparators)(a.path, b.path);
}
function getNearestAncestorDirectoryWithPackageJson(host, fileName) {
    if (host.getNearestAncestorDirectoryWithPackageJson) {
        return host.getNearestAncestorDirectoryWithPackageJson(fileName);
    }
    return (0, ts_js_1.forEachAncestorDirectoryStoppingAtGlobalCache)(host, fileName, directory => host.fileExists((0, ts_js_1.combinePaths)(directory, "package.json")) ?
        directory :
        undefined);
}
/** @internal */
function forEachFileNameOfModule(importingFileName, importedFileName, host, preferSymlinks, cb) {
    const getCanonicalFileName = (0, ts_js_1.hostGetCanonicalFileName)(host);
    const cwd = host.getCurrentDirectory();
    const referenceRedirect = host.isSourceOfProjectReferenceRedirect(importedFileName) ? host.getRedirectFromSourceFile(importedFileName)?.outputDts : undefined;
    const importedPath = (0, ts_js_1.toPath)(importedFileName, cwd, getCanonicalFileName);
    const redirects = host.redirectTargetsMap.get(importedPath) || ts_js_1.emptyArray;
    const importedFileNames = [...(referenceRedirect ? [referenceRedirect] : ts_js_1.emptyArray), importedFileName, ...redirects];
    const targets = importedFileNames.map(f => (0, ts_js_1.getNormalizedAbsolutePath)(f, cwd));
    let shouldFilterIgnoredPaths = !(0, ts_js_1.every)(targets, ts_js_1.containsIgnoredPath);
    if (!preferSymlinks) {
        // Symlinks inside ignored paths are already filtered out of the symlink cache,
        // so we only need to remove them from the realpath filenames.
        const result = (0, ts_js_1.forEach)(targets, p => !(shouldFilterIgnoredPaths && (0, ts_js_1.containsIgnoredPath)(p)) && cb(p, referenceRedirect === p));
        if (result)
            return result;
    }
    const symlinkedDirectories = host.getSymlinkCache?.().getSymlinkedDirectoriesByRealpath();
    const fullImportedFileName = (0, ts_js_1.getNormalizedAbsolutePath)(importedFileName, cwd);
    const result = symlinkedDirectories && (0, ts_js_1.forEachAncestorDirectoryStoppingAtGlobalCache)(host, (0, ts_js_1.getDirectoryPath)(fullImportedFileName), realPathDirectory => {
        const symlinkDirectories = symlinkedDirectories.get((0, ts_js_1.ensureTrailingDirectorySeparator)((0, ts_js_1.toPath)(realPathDirectory, cwd, getCanonicalFileName)));
        if (!symlinkDirectories)
            return undefined; // Continue to ancestor directory
        // Don't want to a package to globally import from itself (importNameCodeFix_symlink_own_package.ts)
        if ((0, ts_js_1.startsWithDirectory)(importingFileName, realPathDirectory, getCanonicalFileName)) {
            return false; // Stop search, each ancestor directory will also hit this condition
        }
        return (0, ts_js_1.forEach)(targets, target => {
            if (!(0, ts_js_1.startsWithDirectory)(target, realPathDirectory, getCanonicalFileName)) {
                return;
            }
            const relative = (0, ts_js_1.getRelativePathFromDirectory)(realPathDirectory, target, getCanonicalFileName);
            for (const symlinkDirectory of symlinkDirectories) {
                const option = (0, ts_js_1.resolvePath)(symlinkDirectory, relative);
                const result = cb(option, target === referenceRedirect);
                shouldFilterIgnoredPaths = true; // We found a non-ignored path in symlinks, so we can reject ignored-path realpaths
                if (result)
                    return result;
            }
        });
    });
    return result || (preferSymlinks
        ? (0, ts_js_1.forEach)(targets, p => shouldFilterIgnoredPaths && (0, ts_js_1.containsIgnoredPath)(p) ? undefined : cb(p, p === referenceRedirect))
        : undefined);
}
/**
 * Looks for existing imports that use symlinks to this module.
 * Symlinks will be returned first so they are preferred over the real path.
 */
function getAllModulePaths(info, importedFileName, host, preferences, compilerOptions, options = {}) {
    const importingFilePath = (0, ts_js_1.toPath)(info.importingSourceFileName, host.getCurrentDirectory(), (0, ts_js_1.hostGetCanonicalFileName)(host));
    const importedFilePath = (0, ts_js_1.toPath)(importedFileName, host.getCurrentDirectory(), (0, ts_js_1.hostGetCanonicalFileName)(host));
    const cache = host.getModuleSpecifierCache?.();
    if (cache) {
        const cached = cache.get(importingFilePath, importedFilePath, preferences, options);
        if (cached?.modulePaths)
            return cached.modulePaths;
    }
    const modulePaths = getAllModulePathsWorker(info, importedFileName, host, compilerOptions, options);
    if (cache) {
        cache.setModulePaths(importingFilePath, importedFilePath, preferences, options, modulePaths);
    }
    return modulePaths;
}
const runtimeDependencyFields = ["dependencies", "peerDependencies", "optionalDependencies"];
function getAllRuntimeDependencies(packageJson) {
    let result;
    for (const field of runtimeDependencyFields) {
        const deps = packageJson[field];
        if (deps && typeof deps === "object") {
            result = (0, ts_js_1.concatenate)(result, (0, ts_js_1.getOwnKeys)(deps));
        }
    }
    return result;
}
function getAllModulePathsWorker(info, importedFileName, host, compilerOptions, options) {
    const cache = host.getModuleResolutionCache?.();
    const links = host.getSymlinkCache?.();
    if (cache && links && host.readFile && !(0, ts_js_1.pathContainsNodeModules)(info.importingSourceFileName)) {
        ts_js_1.Debug.type(host);
        // Cache resolutions for all `dependencies` of the `package.json` context of the input file.
        // This should populate all the relevant symlinks in the symlink cache, and most, if not all, of these resolutions
        // should get (re)used.
        const state = (0, ts_js_1.getTemporaryModuleResolutionState)(cache.getPackageJsonInfoCache(), host, {});
        const packageJson = (0, ts_js_1.getPackageScopeForPath)((0, ts_js_1.getDirectoryPath)(info.importingSourceFileName), state);
        if (packageJson) {
            const toResolve = getAllRuntimeDependencies(packageJson.contents.packageJsonContent);
            for (const depName of (toResolve || ts_js_1.emptyArray)) {
                const resolved = (0, ts_js_1.resolveModuleName)(depName, (0, ts_js_1.combinePaths)(packageJson.packageDirectory, "package.json"), compilerOptions, host, cache, /*redirectedReference*/ undefined, options.overrideImportMode);
                links.setSymlinksFromResolution(resolved.resolvedModule);
            }
        }
    }
    const allFileNames = new Map();
    let importedFileFromNodeModules = false;
    forEachFileNameOfModule(info.importingSourceFileName, importedFileName, host, 
    /*preferSymlinks*/ true, (path, isRedirect) => {
        const isInNodeModules = (0, ts_js_1.pathContainsNodeModules)(path);
        allFileNames.set(path, { path: info.getCanonicalFileName(path), isRedirect, isInNodeModules });
        importedFileFromNodeModules = importedFileFromNodeModules || isInNodeModules;
        // don't return value, so we collect everything
    });
    // Sort by paths closest to importing file Name directory
    const sortedPaths = [];
    for (let directory = info.canonicalSourceDirectory; allFileNames.size !== 0;) {
        const directoryStart = (0, ts_js_1.ensureTrailingDirectorySeparator)(directory);
        let pathsInDirectory;
        allFileNames.forEach(({ path, isRedirect, isInNodeModules }, fileName) => {
            if ((0, ts_js_1.startsWith)(path, directoryStart)) {
                (pathsInDirectory || (pathsInDirectory = [])).push({ path: fileName, isRedirect, isInNodeModules });
                allFileNames.delete(fileName);
            }
        });
        if (pathsInDirectory) {
            if (pathsInDirectory.length > 1) {
                pathsInDirectory.sort(comparePathsByRedirectAndNumberOfDirectorySeparators);
            }
            sortedPaths.push(...pathsInDirectory);
        }
        const newDirectory = (0, ts_js_1.getDirectoryPath)(directory);
        if (newDirectory === directory)
            break;
        directory = newDirectory;
    }
    if (allFileNames.size) {
        const remainingPaths = (0, ts_js_1.arrayFrom)(allFileNames.entries(), ([fileName, { isRedirect, isInNodeModules }]) => ({ path: fileName, isRedirect, isInNodeModules }));
        if (remainingPaths.length > 1)
            remainingPaths.sort(comparePathsByRedirectAndNumberOfDirectorySeparators);
        sortedPaths.push(...remainingPaths);
    }
    return sortedPaths;
}
function tryGetModuleNameFromAmbientModule(moduleSymbol, checker) {
    const decl = moduleSymbol.declarations?.find(d => (0, ts_js_1.isNonGlobalAmbientModule)(d) && (!(0, ts_js_1.isExternalModuleAugmentation)(d) || !(0, ts_js_1.isExternalModuleNameRelative)((0, ts_js_1.getTextOfIdentifierOrLiteral)(d.name))));
    if (decl) {
        return decl.name.text;
    }
    // the module could be a namespace, which is export through "export=" from an ambient module.
    /**
     * declare module "m" {
     *     namespace ns {
     *         class c {}
     *     }
     *     export = ns;
     * }
     */
    // `import {c} from "m";` is valid, in which case, `moduleSymbol` is "ns", but the module name should be "m"
    const ambientModuleDeclareCandidates = (0, ts_js_1.mapDefined)(moduleSymbol.declarations, d => {
        if (!(0, ts_js_1.isModuleDeclaration)(d))
            return;
        const topNamespace = getTopNamespace(d);
        if (!(topNamespace?.parent?.parent
            && (0, ts_js_1.isModuleBlock)(topNamespace.parent)
            && (0, ts_js_1.isAmbientModule)(topNamespace.parent.parent)
            && (0, ts_js_1.isSourceFile)(topNamespace.parent.parent.parent)))
            return;
        const exportAssignment = topNamespace.parent.parent.symbol.exports?.get("export=")?.valueDeclaration?.expression;
        if (!exportAssignment)
            return;
        const exportSymbol = checker.getSymbolAtLocation(exportAssignment);
        if (!exportSymbol)
            return;
        const originalExportSymbol = exportSymbol?.flags & 2097152 /* SymbolFlags.Alias */ ? checker.getAliasedSymbol(exportSymbol) : exportSymbol;
        if (originalExportSymbol === d.symbol)
            return topNamespace.parent.parent;
        function getTopNamespace(namespaceDeclaration) {
            while (namespaceDeclaration.flags & 8 /* NodeFlags.NestedNamespace */) {
                namespaceDeclaration = namespaceDeclaration.parent;
            }
            return namespaceDeclaration;
        }
    });
    const ambientModuleDeclare = ambientModuleDeclareCandidates[0];
    if (ambientModuleDeclare) {
        return ambientModuleDeclare.name.text;
    }
}
function tryGetModuleNameFromPaths(relativeToBaseUrl, paths, allowedEndings, baseDirectory, getCanonicalFileName, host, compilerOptions) {
    for (const key in paths) {
        for (const patternText of paths[key]) {
            const normalized = (0, ts_js_1.normalizePath)(patternText);
            const pattern = getRelativePathIfInSameVolume(normalized, baseDirectory, getCanonicalFileName) ?? normalized;
            const indexOfStar = pattern.indexOf("*");
            // In module resolution, if `pattern` itself has an extension, a file with that extension is looked up directly,
            // meaning a '.ts' or '.d.ts' extension is allowed to resolve. This is distinct from the case where a '*' substitution
            // causes a module specifier to have an extension, i.e. the extension comes from the module specifier in a JS/TS file
            // and matches the '*'. For example:
            //
            // Module Specifier      | Path Mapping (key: [pattern]) | Interpolation       | Resolution Action
            // ---------------------->------------------------------->--------------------->---------------------------------------------------------------
            // import "@app/foo"    -> "@app/*": ["./src/app/*.ts"] -> "./src/app/foo.ts" -> tryFile("./src/app/foo.ts") || [continue resolution algorithm]
            // import "@app/foo.ts" -> "@app/*": ["./src/app/*"]    -> "./src/app/foo.ts" -> [continue resolution algorithm]
            //
            // (https://github.com/microsoft/TypeScript/blob/ad4ded80e1d58f0bf36ac16bea71bc10d9f09895/src/compiler/moduleNameResolver.ts#L2509-L2516)
            //
            // The interpolation produced by both scenarios is identical, but only in the former, where the extension is encoded in
            // the path mapping rather than in the module specifier, will we prioritize a file lookup on the interpolation result.
            // (In fact, currently, the latter scenario will necessarily fail since no resolution mode recognizes '.ts' as a valid
            // extension for a module specifier.)
            //
            // Here, this means we need to be careful about whether we generate a match from the target filename (typically with a
            // .ts extension) or the possible relative module specifiers representing that file:
            //
            // Filename            | Relative Module Specifier Candidates         | Path Mapping                 | Filename Result    | Module Specifier Results
            // --------------------<----------------------------------------------<------------------------------<-------------------||----------------------------
            // dist/haha.d.ts      <- dist/haha, dist/haha.js                     <- "@app/*": ["./dist/*.d.ts"] <- @app/haha        || (none)
            // dist/haha.d.ts      <- dist/haha, dist/haha.js                     <- "@app/*": ["./dist/*"]      <- (none)           || @app/haha, @app/haha.js
            // dist/foo/index.d.ts <- dist/foo, dist/foo/index, dist/foo/index.js <- "@app/*": ["./dist/*.d.ts"] <- @app/foo/index   || (none)
            // dist/foo/index.d.ts <- dist/foo, dist/foo/index, dist/foo/index.js <- "@app/*": ["./dist/*"]      <- (none)           || @app/foo, @app/foo/index, @app/foo/index.js
            // dist/wow.js.js      <- dist/wow.js, dist/wow.js.js                 <- "@app/*": ["./dist/*.js"]   <- @app/wow.js      || @app/wow, @app/wow.js
            //
            // The "Filename Result" can be generated only if `pattern` has an extension. Care must be taken that the list of
            // relative module specifiers to run the interpolation (a) is actually valid for the module resolution mode, (b) takes
            // into account the existence of other files (e.g. 'dist/wow.js' cannot refer to 'dist/wow.js.js' if 'dist/wow.js'
            // exists) and (c) that they are ordered by preference. The last row shows that the filename result and module
            // specifier results are not mutually exclusive. Note that the filename result is a higher priority in module
            // resolution, but as long criteria (b) above is met, I don't think its result needs to be the highest priority result
            // in module specifier generation. I have included it last, as it's difficult to tell exactly where it should be
            // sorted among the others for a particular value of `importModuleSpecifierEnding`.
            const candidates = allowedEndings.map(ending => ({
                ending,
                value: processEnding(relativeToBaseUrl, [ending], compilerOptions),
            }));
            if ((0, ts_js_1.tryGetExtensionFromPath)(pattern)) {
                candidates.push({ ending: undefined, value: relativeToBaseUrl });
            }
            if (indexOfStar !== -1) {
                const prefix = pattern.substring(0, indexOfStar);
                const suffix = pattern.substring(indexOfStar + 1);
                for (const { ending, value } of candidates) {
                    if (value.length >= prefix.length + suffix.length &&
                        (0, ts_js_1.startsWith)(value, prefix) &&
                        (0, ts_js_1.endsWith)(value, suffix) &&
                        validateEnding({ ending, value })) {
                        const matchedStar = value.substring(prefix.length, value.length - suffix.length);
                        if (!(0, ts_js_1.pathIsRelative)(matchedStar)) {
                            return (0, ts_js_1.replaceFirstStar)(key, matchedStar);
                        }
                    }
                }
            }
            else if ((0, ts_js_1.some)(candidates, c => c.ending !== 0 /* ModuleSpecifierEnding.Minimal */ && pattern === c.value) ||
                (0, ts_js_1.some)(candidates, c => c.ending === 0 /* ModuleSpecifierEnding.Minimal */ && pattern === c.value && validateEnding(c))) {
                return key;
            }
        }
    }
    function validateEnding({ ending, value }) {
        // Optimization: `removeExtensionAndIndexPostFix` can query the file system (a good bit) if `ending` is `Minimal`, the basename
        // is 'index', and a `host` is provided. To avoid that until it's unavoidable, we ran the function with no `host` above. Only
        // here, after we've checked that the minimal ending is indeed a match (via the length and prefix/suffix checks / `some` calls),
        // do we check that the host-validated result is consistent with the answer we got before. If it's not, it falls back to the
        // `ModuleSpecifierEnding.Index` result, which should already be in the list of candidates if `Minimal` was. (Note: the assumption here is
        // that every module resolution mode that supports dropping extensions also supports dropping `/index`. Like literally
        // everything else in this file, this logic needs to be updated if that's not true in some future module resolution mode.)
        return ending !== 0 /* ModuleSpecifierEnding.Minimal */ || value === processEnding(relativeToBaseUrl, [ending], compilerOptions, host);
    }
}
var MatchingMode;
(function (MatchingMode) {
    MatchingMode[MatchingMode["Exact"] = 0] = "Exact";
    MatchingMode[MatchingMode["Directory"] = 1] = "Directory";
    MatchingMode[MatchingMode["Pattern"] = 2] = "Pattern";
})(MatchingMode || (MatchingMode = {}));
function tryGetModuleNameFromExportsOrImports(options, host, targetFilePath, packageDirectory, packageName, exports, conditions, mode, isImports, preferTsExtension) {
    if (typeof exports === "string") {
        const ignoreCase = !(0, ts_js_1.hostUsesCaseSensitiveFileNames)(host);
        const getCommonSourceDirectory = () => host.getCommonSourceDirectory();
        const outputFile = isImports && (0, ts_js_1.getOutputJSFileNameWorker)(targetFilePath, options, ignoreCase, getCommonSourceDirectory);
        const declarationFile = isImports && (0, ts_js_1.getOutputDeclarationFileNameWorker)(targetFilePath, options, ignoreCase, getCommonSourceDirectory);
        const pathOrPattern = (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.combinePaths)(packageDirectory, exports), /*currentDirectory*/ undefined);
        const extensionSwappedTarget = (0, ts_js_1.hasTSFileExtension)(targetFilePath) ? (0, ts_js_1.removeFileExtension)(targetFilePath) + tryGetJSExtensionForFile(targetFilePath, options) : undefined;
        const canTryTsExtension = preferTsExtension && (0, ts_js_1.hasImplementationTSFileExtension)(targetFilePath);
        switch (mode) {
            case 0 /* MatchingMode.Exact */:
                if (extensionSwappedTarget && (0, ts_js_1.comparePaths)(extensionSwappedTarget, pathOrPattern, ignoreCase) === 0 /* Comparison.EqualTo */ ||
                    (0, ts_js_1.comparePaths)(targetFilePath, pathOrPattern, ignoreCase) === 0 /* Comparison.EqualTo */ ||
                    outputFile && (0, ts_js_1.comparePaths)(outputFile, pathOrPattern, ignoreCase) === 0 /* Comparison.EqualTo */ ||
                    declarationFile && (0, ts_js_1.comparePaths)(declarationFile, pathOrPattern, ignoreCase) === 0 /* Comparison.EqualTo */) {
                    return { moduleFileToTry: packageName };
                }
                break;
            case 1 /* MatchingMode.Directory */:
                if (canTryTsExtension && (0, ts_js_1.containsPath)(targetFilePath, pathOrPattern, ignoreCase)) {
                    const fragment = (0, ts_js_1.getRelativePathFromDirectory)(pathOrPattern, targetFilePath, /*ignoreCase*/ false);
                    return { moduleFileToTry: (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.combinePaths)((0, ts_js_1.combinePaths)(packageName, exports), fragment), /*currentDirectory*/ undefined) };
                }
                if (extensionSwappedTarget && (0, ts_js_1.containsPath)(pathOrPattern, extensionSwappedTarget, ignoreCase)) {
                    const fragment = (0, ts_js_1.getRelativePathFromDirectory)(pathOrPattern, extensionSwappedTarget, /*ignoreCase*/ false);
                    return { moduleFileToTry: (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.combinePaths)((0, ts_js_1.combinePaths)(packageName, exports), fragment), /*currentDirectory*/ undefined) };
                }
                if (!canTryTsExtension && (0, ts_js_1.containsPath)(pathOrPattern, targetFilePath, ignoreCase)) {
                    const fragment = (0, ts_js_1.getRelativePathFromDirectory)(pathOrPattern, targetFilePath, /*ignoreCase*/ false);
                    return { moduleFileToTry: (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.combinePaths)((0, ts_js_1.combinePaths)(packageName, exports), fragment), /*currentDirectory*/ undefined) };
                }
                if (outputFile && (0, ts_js_1.containsPath)(pathOrPattern, outputFile, ignoreCase)) {
                    const fragment = (0, ts_js_1.getRelativePathFromDirectory)(pathOrPattern, outputFile, /*ignoreCase*/ false);
                    return { moduleFileToTry: (0, ts_js_1.combinePaths)(packageName, fragment) };
                }
                if (declarationFile && (0, ts_js_1.containsPath)(pathOrPattern, declarationFile, ignoreCase)) {
                    const fragment = (0, ts_js_1.changeFullExtension)((0, ts_js_1.getRelativePathFromDirectory)(pathOrPattern, declarationFile, /*ignoreCase*/ false), getJSExtensionForFile(declarationFile, options));
                    return { moduleFileToTry: (0, ts_js_1.combinePaths)(packageName, fragment) };
                }
                break;
            case 2 /* MatchingMode.Pattern */:
                const starPos = pathOrPattern.indexOf("*");
                const leadingSlice = pathOrPattern.slice(0, starPos);
                const trailingSlice = pathOrPattern.slice(starPos + 1);
                if (canTryTsExtension && (0, ts_js_1.startsWith)(targetFilePath, leadingSlice, ignoreCase) && (0, ts_js_1.endsWith)(targetFilePath, trailingSlice, ignoreCase)) {
                    const starReplacement = targetFilePath.slice(leadingSlice.length, targetFilePath.length - trailingSlice.length);
                    return { moduleFileToTry: (0, ts_js_1.replaceFirstStar)(packageName, starReplacement) };
                }
                if (extensionSwappedTarget && (0, ts_js_1.startsWith)(extensionSwappedTarget, leadingSlice, ignoreCase) && (0, ts_js_1.endsWith)(extensionSwappedTarget, trailingSlice, ignoreCase)) {
                    const starReplacement = extensionSwappedTarget.slice(leadingSlice.length, extensionSwappedTarget.length - trailingSlice.length);
                    return { moduleFileToTry: (0, ts_js_1.replaceFirstStar)(packageName, starReplacement) };
                }
                if (!canTryTsExtension && (0, ts_js_1.startsWith)(targetFilePath, leadingSlice, ignoreCase) && (0, ts_js_1.endsWith)(targetFilePath, trailingSlice, ignoreCase)) {
                    const starReplacement = targetFilePath.slice(leadingSlice.length, targetFilePath.length - trailingSlice.length);
                    return { moduleFileToTry: (0, ts_js_1.replaceFirstStar)(packageName, starReplacement) };
                }
                if (outputFile && (0, ts_js_1.startsWith)(outputFile, leadingSlice, ignoreCase) && (0, ts_js_1.endsWith)(outputFile, trailingSlice, ignoreCase)) {
                    const starReplacement = outputFile.slice(leadingSlice.length, outputFile.length - trailingSlice.length);
                    return { moduleFileToTry: (0, ts_js_1.replaceFirstStar)(packageName, starReplacement) };
                }
                if (declarationFile && (0, ts_js_1.startsWith)(declarationFile, leadingSlice, ignoreCase) && (0, ts_js_1.endsWith)(declarationFile, trailingSlice, ignoreCase)) {
                    const starReplacement = declarationFile.slice(leadingSlice.length, declarationFile.length - trailingSlice.length);
                    const substituted = (0, ts_js_1.replaceFirstStar)(packageName, starReplacement);
                    const jsExtension = tryGetJSExtensionForFile(declarationFile, options);
                    return jsExtension ? { moduleFileToTry: (0, ts_js_1.changeFullExtension)(substituted, jsExtension) } : undefined;
                }
                break;
        }
    }
    else if (Array.isArray(exports)) {
        return (0, ts_js_1.forEach)(exports, e => tryGetModuleNameFromExportsOrImports(options, host, targetFilePath, packageDirectory, packageName, e, conditions, mode, isImports, preferTsExtension));
    }
    else if (typeof exports === "object" && exports !== null) { // eslint-disable-line no-restricted-syntax
        // conditional mapping
        for (const key of (0, ts_js_1.getOwnKeys)(exports)) {
            if (key === "default" || conditions.indexOf(key) >= 0 || (0, ts_js_1.isApplicableVersionedTypesKey)(conditions, key)) {
                const subTarget = exports[key];
                const result = tryGetModuleNameFromExportsOrImports(options, host, targetFilePath, packageDirectory, packageName, subTarget, conditions, mode, isImports, preferTsExtension);
                if (result) {
                    return result;
                }
            }
        }
    }
    return undefined;
}
function tryGetModuleNameFromExports(options, host, targetFilePath, packageDirectory, packageName, exports, conditions) {
    if (typeof exports === "object" && exports !== null && !Array.isArray(exports) && (0, ts_js_1.allKeysStartWithDot)(exports)) { // eslint-disable-line no-restricted-syntax
        // sub-mappings
        // 3 cases:
        // * directory mappings (legacyish, key ends with / (technically allows index/extension resolution under cjs mode))
        // * pattern mappings (contains a *)
        // * exact mappings (no *, does not end with /)
        return (0, ts_js_1.forEach)((0, ts_js_1.getOwnKeys)(exports), k => {
            const subPackageName = (0, ts_js_1.getNormalizedAbsolutePath)((0, ts_js_1.combinePaths)(packageName, k), /*currentDirectory*/ undefined);
            const mode = (0, ts_js_1.endsWith)(k, "/") ? 1 /* MatchingMode.Directory */
                : k.includes("*") ? 2 /* MatchingMode.Pattern */
                    : 0 /* MatchingMode.Exact */;
            return tryGetModuleNameFromExportsOrImports(options, host, targetFilePath, packageDirectory, subPackageName, exports[k], conditions, mode, /*isImports*/ false, /*preferTsExtension*/ false);
        });
    }
    return tryGetModuleNameFromExportsOrImports(options, host, targetFilePath, packageDirectory, packageName, exports, conditions, 0 /* MatchingMode.Exact */, /*isImports*/ false, /*preferTsExtension*/ false);
}
function tryGetModuleNameFromPackageJsonImports(moduleFileName, sourceDirectory, options, host, importMode, preferTsExtension) {
    if (!host.readFile || !(0, ts_js_1.getResolvePackageJsonImports)(options)) {
        return undefined;
    }
    const ancestorDirectoryWithPackageJson = getNearestAncestorDirectoryWithPackageJson(host, sourceDirectory);
    if (!ancestorDirectoryWithPackageJson) {
        return undefined;
    }
    const packageJsonPath = (0, ts_js_1.combinePaths)(ancestorDirectoryWithPackageJson, "package.json");
    const cachedPackageJson = host.getPackageJsonInfoCache?.()?.getPackageJsonInfo(packageJsonPath);
    if ((0, ts_js_1.isMissingPackageJsonInfo)(cachedPackageJson) || !host.fileExists(packageJsonPath)) {
        return undefined;
    }
    const packageJsonContent = cachedPackageJson?.contents.packageJsonContent || (0, ts_js_1.tryParseJson)(host.readFile(packageJsonPath));
    const imports = packageJsonContent?.imports;
    if (!imports) {
        return undefined;
    }
    const conditions = (0, ts_js_1.getConditions)(options, importMode);
    return (0, ts_js_1.forEach)((0, ts_js_1.getOwnKeys)(imports), k => {
        if (!(0, ts_js_1.startsWith)(k, "#") || k === "#" || (0, ts_js_1.startsWith)(k, "#/"))
            return undefined;
        const mode = (0, ts_js_1.endsWith)(k, "/") ? 1 /* MatchingMode.Directory */
            : k.includes("*") ? 2 /* MatchingMode.Pattern */
                : 0 /* MatchingMode.Exact */;
        return tryGetModuleNameFromExportsOrImports(options, host, moduleFileName, ancestorDirectoryWithPackageJson, k, imports[k], conditions, mode, /*isImports*/ true, preferTsExtension);
    })?.moduleFileToTry;
}
function tryGetModuleNameFromRootDirs(rootDirs, moduleFileName, sourceDirectory, getCanonicalFileName, allowedEndings, compilerOptions) {
    const normalizedTargetPaths = getPathsRelativeToRootDirs(moduleFileName, rootDirs, getCanonicalFileName);
    if (normalizedTargetPaths === undefined) {
        return undefined;
    }
    const normalizedSourcePaths = getPathsRelativeToRootDirs(sourceDirectory, rootDirs, getCanonicalFileName);
    const relativePaths = (0, ts_js_1.flatMap)(normalizedSourcePaths, sourcePath => {
        return (0, ts_js_1.map)(normalizedTargetPaths, targetPath => (0, ts_js_1.ensurePathIsNonModuleName)((0, ts_js_1.getRelativePathFromDirectory)(sourcePath, targetPath, getCanonicalFileName)));
    });
    const shortest = (0, ts_js_1.min)(relativePaths, ts_js_1.compareNumberOfDirectorySeparators);
    if (!shortest) {
        return undefined;
    }
    return processEnding(shortest, allowedEndings, compilerOptions);
}
function tryGetModuleNameAsNodeModule({ path, isRedirect }, { getCanonicalFileName, canonicalSourceDirectory }, importingSourceFile, host, options, userPreferences, packageNameOnly, overrideMode) {
    if (!host.fileExists || !host.readFile) {
        return undefined;
    }
    const parts = (0, ts_js_1.getNodeModulePathParts)(path);
    if (!parts) {
        return undefined;
    }
    // Simplify the full file path to something that can be resolved by Node.
    const preferences = getModuleSpecifierPreferences(userPreferences, host, options, importingSourceFile);
    const allowedEndings = preferences.getAllowedEndingsInPreferredOrder();
    let moduleSpecifier = path;
    let isPackageRootPath = false;
    if (!packageNameOnly) {
        let packageRootIndex = parts.packageRootIndex;
        let moduleFileName;
        while (true) {
            // If the module could be imported by a directory name, use that directory's name
            const { moduleFileToTry, packageRootPath, blockedByExports, verbatimFromExports } = tryDirectoryWithPackageJson(packageRootIndex);
            if ((0, ts_js_1.getEmitModuleResolutionKind)(options) !== ts_js_1.ModuleResolutionKind.Classic) {
                if (blockedByExports) {
                    return undefined; // File is under this package.json, but is not publicly exported - there's no way to name it via `node_modules` resolution
                }
                if (verbatimFromExports) {
                    return moduleFileToTry;
                }
            }
            if (packageRootPath) {
                moduleSpecifier = packageRootPath;
                isPackageRootPath = true;
                break;
            }
            if (!moduleFileName)
                moduleFileName = moduleFileToTry;
            // try with next level of directory
            packageRootIndex = path.indexOf(ts_js_1.directorySeparator, packageRootIndex + 1);
            if (packageRootIndex === -1) {
                moduleSpecifier = processEnding(moduleFileName, allowedEndings, options, host);
                break;
            }
        }
    }
    if (isRedirect && !isPackageRootPath) {
        return undefined;
    }
    const globalTypingsCacheLocation = host.getGlobalTypingsCacheLocation && host.getGlobalTypingsCacheLocation();
    // Get a path that's relative to node_modules or the importing file's path
    // if node_modules folder is in this folder or any of its parent folders, no need to keep it.
    const pathToTopLevelNodeModules = getCanonicalFileName(moduleSpecifier.substring(0, parts.topLevelNodeModulesIndex));
    if (!((0, ts_js_1.startsWith)(canonicalSourceDirectory, pathToTopLevelNodeModules) || globalTypingsCacheLocation && (0, ts_js_1.startsWith)(getCanonicalFileName(globalTypingsCacheLocation), pathToTopLevelNodeModules))) {
        return undefined;
    }
    // If the module was found in @types, get the actual Node package name
    const nodeModulesDirectoryName = moduleSpecifier.substring(parts.topLevelPackageNameIndex + 1);
    const packageName = (0, ts_js_1.getPackageNameFromTypesPackageName)(nodeModulesDirectoryName);
    // For classic resolution, only allow importing from node_modules/@types, not other node_modules
    return (0, ts_js_1.getEmitModuleResolutionKind)(options) === ts_js_1.ModuleResolutionKind.Classic && packageName === nodeModulesDirectoryName ? undefined : packageName;
    function tryDirectoryWithPackageJson(packageRootIndex) {
        const packageRootPath = path.substring(0, packageRootIndex);
        const packageJsonPath = (0, ts_js_1.combinePaths)(packageRootPath, "package.json");
        let moduleFileToTry = path;
        let maybeBlockedByTypesVersions = false;
        const cachedPackageJson = host.getPackageJsonInfoCache?.()?.getPackageJsonInfo(packageJsonPath);
        if ((0, ts_js_1.isPackageJsonInfo)(cachedPackageJson) || cachedPackageJson === undefined && host.fileExists(packageJsonPath)) {
            const packageJsonContent = cachedPackageJson?.contents.packageJsonContent || (0, ts_js_1.tryParseJson)(host.readFile(packageJsonPath));
            const importMode = overrideMode || getDefaultResolutionModeForFile(importingSourceFile, host, options);
            if ((0, ts_js_1.getResolvePackageJsonExports)(options)) {
                // The package name that we found in node_modules could be different from the package
                // name in the package.json content via url/filepath dependency specifiers. We need to
                // use the actual directory name, so don't look at `packageJsonContent.name` here.
                const nodeModulesDirectoryName = packageRootPath.substring(parts.topLevelPackageNameIndex + 1);
                const packageName = (0, ts_js_1.getPackageNameFromTypesPackageName)(nodeModulesDirectoryName);
                const conditions = (0, ts_js_1.getConditions)(options, importMode);
                const fromExports = packageJsonContent?.exports
                    ? tryGetModuleNameFromExports(options, host, path, packageRootPath, packageName, packageJsonContent.exports, conditions)
                    : undefined;
                if (fromExports) {
                    return { ...fromExports, verbatimFromExports: true };
                }
                if (packageJsonContent?.exports) {
                    return { moduleFileToTry: path, blockedByExports: true };
                }
            }
            const versionPaths = packageJsonContent?.typesVersions
                ? (0, ts_js_1.getPackageJsonTypesVersionsPaths)(packageJsonContent.typesVersions)
                : undefined;
            if (versionPaths) {
                const subModuleName = path.slice(packageRootPath.length + 1);
                const fromPaths = tryGetModuleNameFromPaths(subModuleName, versionPaths.paths, allowedEndings, packageRootPath, getCanonicalFileName, host, options);
                if (fromPaths === undefined) {
                    maybeBlockedByTypesVersions = true;
                }
                else {
                    moduleFileToTry = (0, ts_js_1.combinePaths)(packageRootPath, fromPaths);
                }
            }
            // If the file is the main module, it can be imported by the package name
            const mainFileRelative = packageJsonContent?.typings || packageJsonContent?.types || packageJsonContent?.main || "index.js";
            if ((0, ts_js_1.isString)(mainFileRelative) && !(maybeBlockedByTypesVersions && (0, ts_js_1.matchPatternOrExact)((0, ts_js_1.tryParsePatterns)(versionPaths.paths), mainFileRelative))) {
                // The 'main' file is also subject to mapping through typesVersions, and we couldn't come up with a path
                // explicitly through typesVersions, so if it matches a key in typesVersions now, it's not reachable.
                // (The only way this can happen is if some file in a package that's not resolvable from outside the
                // package got pulled into the program anyway, e.g. transitively through a file that *is* reachable. It
                // happens very easily in fourslash tests though, since every test file listed gets included. See
                // importNameCodeFix_typesVersions.ts for an example.)
                const mainExportFile = (0, ts_js_1.toPath)(mainFileRelative, packageRootPath, getCanonicalFileName);
                const canonicalModuleFileToTry = getCanonicalFileName(moduleFileToTry);
                if ((0, ts_js_1.removeFileExtension)(mainExportFile) === (0, ts_js_1.removeFileExtension)(canonicalModuleFileToTry)) {
                    // ^ An arbitrary removal of file extension for this comparison is almost certainly wrong
                    return { packageRootPath, moduleFileToTry };
                }
                else if (packageJsonContent?.type !== "module" &&
                    !(0, ts_js_1.fileExtensionIsOneOf)(canonicalModuleFileToTry, ts_js_1.extensionsNotSupportingExtensionlessResolution) &&
                    (0, ts_js_1.startsWith)(canonicalModuleFileToTry, mainExportFile) &&
                    (0, ts_js_1.getDirectoryPath)(canonicalModuleFileToTry) === (0, ts_js_1.removeTrailingDirectorySeparator)(mainExportFile) &&
                    (0, ts_js_1.removeFileExtension)((0, ts_js_1.getBaseFileName)(canonicalModuleFileToTry)) === "index") {
                    // if mainExportFile is a directory, which contains moduleFileToTry, we just try index file
                    // example mainExportFile: `pkg/lib` and moduleFileToTry: `pkg/lib/index`, we can use packageRootPath
                    // but this behavior is deprecated for packages with "type": "module", so we only do this for packages without "type": "module"
                    // and make sure that the extension on index.{???} is something that supports omitting the extension
                    return { packageRootPath, moduleFileToTry };
                }
            }
        }
        else {
            // No package.json exists; an index.js will still resolve as the package name
            const fileName = getCanonicalFileName(moduleFileToTry.substring(parts.packageRootIndex + 1));
            if (fileName === "index.d.ts" || fileName === "index.js" || fileName === "index.ts" || fileName === "index.tsx") {
                return { moduleFileToTry, packageRootPath };
            }
        }
        return { moduleFileToTry };
    }
}
function tryGetAnyFileFromPath(host, path) {
    if (!host.fileExists)
        return;
    // We check all js, `node` and `json` extensions in addition to TS, since node module resolution would also choose those over the directory
    const extensions = (0, ts_js_1.flatten)((0, ts_js_1.getSupportedExtensions)({ allowJs: true }, [{ extension: "node", isMixedContent: false }, { extension: "json", isMixedContent: false, scriptKind: 6 /* ScriptKind.JSON */ }]));
    for (const e of extensions) {
        const fullPath = path + e;
        if (host.fileExists(fullPath)) {
            return fullPath;
        }
    }
}
function getPathsRelativeToRootDirs(path, rootDirs, getCanonicalFileName) {
    return (0, ts_js_1.mapDefined)(rootDirs, rootDir => {
        const relativePath = getRelativePathIfInSameVolume(path, rootDir, getCanonicalFileName);
        return relativePath !== undefined && isPathRelativeToParent(relativePath) ? undefined : relativePath;
    });
}
function processEnding(fileName, allowedEndings, options, host) {
    if ((0, ts_js_1.fileExtensionIsOneOf)(fileName, [".json" /* Extension.Json */, ".mjs" /* Extension.Mjs */, ".cjs" /* Extension.Cjs */])) {
        return fileName;
    }
    const noExtension = (0, ts_js_1.removeFileExtension)(fileName);
    if (fileName === noExtension) {
        return fileName;
    }
    const jsPriority = allowedEndings.indexOf(2 /* ModuleSpecifierEnding.JsExtension */);
    const tsPriority = allowedEndings.indexOf(3 /* ModuleSpecifierEnding.TsExtension */);
    if ((0, ts_js_1.fileExtensionIsOneOf)(fileName, [".mts" /* Extension.Mts */, ".cts" /* Extension.Cts */]) && tsPriority !== -1 && tsPriority < jsPriority) {
        return fileName;
    }
    else if ((0, ts_js_1.fileExtensionIsOneOf)(fileName, [".d.mts" /* Extension.Dmts */, ".mts" /* Extension.Mts */, ".d.cts" /* Extension.Dcts */, ".cts" /* Extension.Cts */])) {
        return noExtension + getJSExtensionForFile(fileName, options);
    }
    else if (!(0, ts_js_1.fileExtensionIsOneOf)(fileName, [".d.ts" /* Extension.Dts */]) && (0, ts_js_1.fileExtensionIsOneOf)(fileName, [".ts" /* Extension.Ts */]) && fileName.includes(".d.")) {
        // `foo.d.json.ts` and the like - remap back to `foo.json`
        return tryGetRealFileNameForNonJsDeclarationFileName(fileName);
    }
    switch (allowedEndings[0]) {
        case 0 /* ModuleSpecifierEnding.Minimal */:
            const withoutIndex = (0, ts_js_1.removeSuffix)(noExtension, "/index");
            if (host && withoutIndex !== noExtension && tryGetAnyFileFromPath(host, withoutIndex)) {
                // Can't remove index if there's a file by the same name as the directory.
                // Probably more callers should pass `host` so we can determine this?
                return noExtension;
            }
            return withoutIndex;
        case 1 /* ModuleSpecifierEnding.Index */:
            return noExtension;
        case 2 /* ModuleSpecifierEnding.JsExtension */:
            return noExtension + getJSExtensionForFile(fileName, options);
        case 3 /* ModuleSpecifierEnding.TsExtension */:
            // For now, we don't know if this import is going to be type-only, which means we don't
            // know if a .d.ts extension is valid, so use no extension or a .js extension
            if ((0, ts_js_1.isDeclarationFileName)(fileName)) {
                const extensionlessPriority = allowedEndings.findIndex(e => e === 0 /* ModuleSpecifierEnding.Minimal */ || e === 1 /* ModuleSpecifierEnding.Index */);
                return extensionlessPriority !== -1 && extensionlessPriority < jsPriority
                    ? noExtension
                    : noExtension + getJSExtensionForFile(fileName, options);
            }
            return fileName;
        default:
            return ts_js_1.Debug.assertNever(allowedEndings[0]);
    }
}
/** @internal */
function tryGetRealFileNameForNonJsDeclarationFileName(fileName) {
    const baseName = (0, ts_js_1.getBaseFileName)(fileName);
    if (!(0, ts_js_1.endsWith)(fileName, ".ts" /* Extension.Ts */) || !baseName.includes(".d.") || (0, ts_js_1.fileExtensionIsOneOf)(baseName, [".d.ts" /* Extension.Dts */]))
        return undefined;
    const noExtension = (0, ts_js_1.removeExtension)(fileName, ".ts" /* Extension.Ts */);
    const ext = noExtension.substring(noExtension.lastIndexOf("."));
    return noExtension.substring(0, noExtension.indexOf(".d.")) + ext;
}
function getJSExtensionForFile(fileName, options) {
    return tryGetJSExtensionForFile(fileName, options) ?? ts_js_1.Debug.fail(`Extension ${(0, ts_js_1.extensionFromPath)(fileName)} is unsupported:: FileName:: ${fileName}`);
}
/** @internal */
function tryGetJSExtensionForFile(fileName, options) {
    const ext = (0, ts_js_1.tryGetExtensionFromPath)(fileName);
    switch (ext) {
        case ".ts" /* Extension.Ts */:
        case ".d.ts" /* Extension.Dts */:
            return ".js" /* Extension.Js */;
        case ".tsx" /* Extension.Tsx */:
            return options.jsx === 1 /* JsxEmit.Preserve */ ? ".jsx" /* Extension.Jsx */ : ".js" /* Extension.Js */;
        case ".js" /* Extension.Js */:
        case ".jsx" /* Extension.Jsx */:
        case ".json" /* Extension.Json */:
            return ext;
        case ".d.mts" /* Extension.Dmts */:
        case ".mts" /* Extension.Mts */:
        case ".mjs" /* Extension.Mjs */:
            return ".mjs" /* Extension.Mjs */;
        case ".d.cts" /* Extension.Dcts */:
        case ".cts" /* Extension.Cts */:
        case ".cjs" /* Extension.Cjs */:
            return ".cjs" /* Extension.Cjs */;
        default:
            return undefined;
    }
}
function getRelativePathIfInSameVolume(path, directoryPath, getCanonicalFileName) {
    const relativePath = (0, ts_js_1.getRelativePathToDirectoryOrUrl)(directoryPath, path, directoryPath, getCanonicalFileName, /*isAbsolutePathAnUrl*/ false);
    return (0, ts_js_1.isRootedDiskPath)(relativePath) ? undefined : relativePath;
}
function isPathRelativeToParent(path) {
    return (0, ts_js_1.startsWith)(path, "..");
}
function getDefaultResolutionModeForFile(file, host, compilerOptions) {
    return (0, ts_js_1.isFullSourceFile)(file) ? host.getDefaultResolutionModeForFile(file) : (0, ts_js_1.getDefaultResolutionModeForFileWorker)(file, compilerOptions);
}
function prefersTsExtension(allowedEndings) {
    const tsPriority = allowedEndings.indexOf(3 /* ModuleSpecifierEnding.TsExtension */);
    return tsPriority > -1 && tsPriority < allowedEndings.indexOf(2 /* ModuleSpecifierEnding.JsExtension */);
}
