"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.sys = exports.FileSystemEntryKind = exports.ignoredPaths = exports.unchangedPollThresholds = exports.missingFileModifiedTime = exports.PollingInterval = exports.FileWatcherEventKind = void 0;
exports.generateDjb2Hash = generateDjb2Hash;
exports.setStackTraceLimit = setStackTraceLimit;
exports.getModifiedTime = getModifiedTime;
exports.getFileWatcherEventKind = getFileWatcherEventKind;
exports.sysLog = sysLog;
exports.setSysLog = setSysLog;
exports.createSystemWatchFunctions = createSystemWatchFunctions;
exports.patchWriteFileEnsuringDirectory = patchWriteFileEnsuringDirectory;
exports.setSys = setSys;
const ts_js_1 = require("./_namespaces/ts.js");
const hostErrors_js_1 = require("./hostErrors.js");
const _fs = __importStar(require("node:fs"));
const _path = __importStar(require("node:path"));
const _os = __importStar(require("node:os"));
const _crypto = __importStar(require("node:crypto"));
/**
 * djb2 hashing algorithm
 * http://www.cse.yorku.ca/~oz/hash.html
 *
 * @internal
 */
function generateDjb2Hash(data) {
    let acc = 5381;
    for (let i = 0; i < data.length; i++) {
        acc = ((acc << 5) + acc) + data.charCodeAt(i);
    }
    return acc.toString();
}
/**
 * Set a high stack trace limit to provide more information in case of an error.
 * Called for command-line and server use cases.
 * Not called if TypeScript is used as a library.
 *
 * @internal
 */
function setStackTraceLimit() {
    if (Error.stackTraceLimit < 100) { // Also tests that we won't set the property if it doesn't exist.
        Error.stackTraceLimit = 100;
    }
}
var FileWatcherEventKind;
(function (FileWatcherEventKind) {
    FileWatcherEventKind[FileWatcherEventKind["Created"] = 0] = "Created";
    FileWatcherEventKind[FileWatcherEventKind["Changed"] = 1] = "Changed";
    FileWatcherEventKind[FileWatcherEventKind["Deleted"] = 2] = "Deleted";
})(FileWatcherEventKind || (exports.FileWatcherEventKind = FileWatcherEventKind = {}));
/** @internal */
var PollingInterval;
(function (PollingInterval) {
    PollingInterval[PollingInterval["High"] = 2000] = "High";
    PollingInterval[PollingInterval["Medium"] = 500] = "Medium";
    PollingInterval[PollingInterval["Low"] = 250] = "Low";
})(PollingInterval || (exports.PollingInterval = PollingInterval = {}));
/** @internal */
exports.missingFileModifiedTime = new Date(0); // Any subsequent modification will occur after this time
/** @internal */
function getModifiedTime(host, fileName) {
    return host.getModifiedTime(fileName) || exports.missingFileModifiedTime;
}
function createPollingIntervalBasedLevels(levels) {
    return {
        [PollingInterval.Low]: levels.Low,
        [PollingInterval.Medium]: levels.Medium,
        [PollingInterval.High]: levels.High,
    };
}
const defaultChunkLevels = { Low: 32, Medium: 64, High: 256 };
let pollingChunkSize = createPollingIntervalBasedLevels(defaultChunkLevels);
/** @internal */
exports.unchangedPollThresholds = createPollingIntervalBasedLevels(defaultChunkLevels);
function setCustomPollingValues(system) {
    if (!system.getEnvironmentVariable) {
        return;
    }
    const pollingIntervalChanged = !!getCustomLevels("TSC_WATCH_POLLINGINTERVAL");
    pollingChunkSize = getCustomPollingBasedLevels("TSC_WATCH_POLLINGCHUNKSIZE", defaultChunkLevels) || pollingChunkSize;
    exports.unchangedPollThresholds = getCustomPollingBasedLevels("TSC_WATCH_UNCHANGEDPOLLTHRESHOLDS", defaultChunkLevels) || exports.unchangedPollThresholds;
    function getLevel(envVar, level) {
        return system.getEnvironmentVariable(`${envVar}_${level.toUpperCase()}`);
    }
    function getCustomLevels(baseVariable) {
        let customLevels;
        setCustomLevel("Low");
        setCustomLevel("Medium");
        setCustomLevel("High");
        return customLevels;
        function setCustomLevel(level) {
            const customLevel = getLevel(baseVariable, level);
            if (customLevel) {
                (customLevels || (customLevels = {}))[level] = Number(customLevel);
            }
        }
    }
    function getCustomPollingBasedLevels(baseVariable, defaultLevels) {
        const customLevels = getCustomLevels(baseVariable);
        return (pollingIntervalChanged || customLevels) &&
            createPollingIntervalBasedLevels(customLevels ? { ...defaultLevels, ...customLevels } : defaultLevels);
    }
}
function pollWatchedFileQueue(host, queue, pollIndex, chunkSize, callbackOnWatchFileStat) {
    let definedValueCopyToIndex = pollIndex;
    // Max visit would be all elements of the queue
    for (let canVisit = queue.length; chunkSize && canVisit; nextPollIndex(), canVisit--) {
        const watchedFile = queue[pollIndex];
        if (!watchedFile) {
            continue;
        }
        else if (watchedFile.isClosed) {
            queue[pollIndex] = undefined;
            continue;
        }
        // Only files polled count towards chunkSize
        chunkSize--;
        const fileChanged = onWatchedFileStat(watchedFile, getModifiedTime(host, watchedFile.fileName));
        if (watchedFile.isClosed) {
            // Closed watcher as part of callback
            queue[pollIndex] = undefined;
            continue;
        }
        callbackOnWatchFileStat?.(watchedFile, pollIndex, fileChanged);
        // Defragment the queue while we are at it
        if (queue[pollIndex]) {
            // Copy this file to the non hole location
            if (definedValueCopyToIndex < pollIndex) {
                queue[definedValueCopyToIndex] = watchedFile;
                queue[pollIndex] = undefined;
            }
            definedValueCopyToIndex++;
        }
    }
    // Return next poll index
    return pollIndex;
    function nextPollIndex() {
        pollIndex++;
        if (pollIndex === queue.length) {
            if (definedValueCopyToIndex < pollIndex) {
                // There are holes from definedValueCopyToIndex to end of queue, change queue size
                queue.length = definedValueCopyToIndex;
            }
            pollIndex = 0;
            definedValueCopyToIndex = 0;
        }
    }
}
function createDynamicPriorityPollingWatchFile(host) {
    const watchedFiles = [];
    const changedFilesInLastPoll = [];
    const lowPollingIntervalQueue = createPollingIntervalQueue(PollingInterval.Low);
    const mediumPollingIntervalQueue = createPollingIntervalQueue(PollingInterval.Medium);
    const highPollingIntervalQueue = createPollingIntervalQueue(PollingInterval.High);
    return watchFile;
    function watchFile(fileName, callback, defaultPollingInterval) {
        const file = {
            fileName,
            callback,
            unchangedPolls: 0,
            mtime: getModifiedTime(host, fileName),
        };
        watchedFiles.push(file);
        addToPollingIntervalQueue(file, defaultPollingInterval);
        return {
            close: () => {
                file.isClosed = true;
                // Remove from watchedFiles
                (0, ts_js_1.unorderedRemoveItem)(watchedFiles, file);
                // Do not update polling interval queue since that will happen as part of polling
            },
        };
    }
    function createPollingIntervalQueue(pollingInterval) {
        return { files: [], pollingInterval, pollIndex: 0, pollScheduled: false };
    }
    function pollPollingIntervalQueue(_timeoutType, queue) {
        queue.pollIndex = pollQueue(queue.files, queue.pollingInterval, queue.pollIndex, pollingChunkSize[queue.pollingInterval]);
        // Set the next polling index and timeout
        if (queue.files.length) {
            scheduleNextPoll(queue.pollingInterval);
        }
        else {
            ts_js_1.Debug.assert(queue.pollIndex === 0);
            queue.pollScheduled = false;
        }
    }
    function pollLowPollingIntervalQueue(_timeoutType, queue) {
        // Always poll complete list of changedFilesInLastPoll
        pollQueue(changedFilesInLastPoll, PollingInterval.Low, /*pollIndex*/ 0, changedFilesInLastPoll.length);
        // Finally do the actual polling of the queue
        pollPollingIntervalQueue(_timeoutType, queue);
        // Schedule poll if there are files in changedFilesInLastPoll but no files in the actual queue
        // as pollPollingIntervalQueue wont schedule for next poll
        if (!queue.pollScheduled && changedFilesInLastPoll.length) {
            scheduleNextPoll(PollingInterval.Low);
        }
    }
    function pollQueue(queue, pollingInterval, pollIndex, chunkSize) {
        return pollWatchedFileQueue(host, queue, pollIndex, chunkSize, onWatchFileStat);
        function onWatchFileStat(watchedFile, pollIndex, fileChanged) {
            if (fileChanged) {
                watchedFile.unchangedPolls = 0;
                // Changed files go to changedFilesInLastPoll queue
                if (queue !== changedFilesInLastPoll) {
                    queue[pollIndex] = undefined;
                    addChangedFileToLowPollingIntervalQueue(watchedFile);
                }
            }
            else if (watchedFile.unchangedPolls !== exports.unchangedPollThresholds[pollingInterval]) {
                watchedFile.unchangedPolls++;
            }
            else if (queue === changedFilesInLastPoll) {
                // Restart unchangedPollCount for unchanged file and move to low polling interval queue
                watchedFile.unchangedPolls = 1;
                queue[pollIndex] = undefined;
                addToPollingIntervalQueue(watchedFile, PollingInterval.Low);
            }
            else if (pollingInterval !== PollingInterval.High) {
                watchedFile.unchangedPolls++;
                queue[pollIndex] = undefined;
                addToPollingIntervalQueue(watchedFile, pollingInterval === PollingInterval.Low ? PollingInterval.Medium : PollingInterval.High);
            }
        }
    }
    function pollingIntervalQueue(pollingInterval) {
        switch (pollingInterval) {
            case PollingInterval.Low:
                return lowPollingIntervalQueue;
            case PollingInterval.Medium:
                return mediumPollingIntervalQueue;
            case PollingInterval.High:
                return highPollingIntervalQueue;
        }
    }
    function addToPollingIntervalQueue(file, pollingInterval) {
        pollingIntervalQueue(pollingInterval).files.push(file);
        scheduleNextPollIfNotAlreadyScheduled(pollingInterval);
    }
    function addChangedFileToLowPollingIntervalQueue(file) {
        changedFilesInLastPoll.push(file);
        scheduleNextPollIfNotAlreadyScheduled(PollingInterval.Low);
    }
    function scheduleNextPollIfNotAlreadyScheduled(pollingInterval) {
        if (!pollingIntervalQueue(pollingInterval).pollScheduled) {
            scheduleNextPoll(pollingInterval);
        }
    }
    function scheduleNextPoll(pollingInterval) {
        pollingIntervalQueue(pollingInterval).pollScheduled = (() => {
            const timerHost = host;
            const callback = pollingInterval === PollingInterval.Low ? pollLowPollingIntervalQueue : pollPollingIntervalQueue;
            const timeoutDelay = pollingInterval;
            const t1 = pollingInterval === PollingInterval.Low ? "pollLowPollingIntervalQueue" : "pollPollingIntervalQueue";
            const t2 = pollingIntervalQueue(pollingInterval);
            return timerHost.setTimeout(() => callback(t1, t2), timeoutDelay, t1);
        })();
    }
}
function createUseFsEventsOnParentDirectoryWatchFile(fsWatch, useCaseSensitiveFileNames, getModifiedTime, fsWatchWithTimestamp) {
    // One file can have multiple watchers
    const fileWatcherCallbacks = (0, ts_js_1.createMultiMap)();
    const fileTimestamps = fsWatchWithTimestamp ? new Map() : undefined;
    const dirWatchers = new Map();
    const toCanonicalName = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    return nonPollingWatchFile;
    function nonPollingWatchFile(fileName, callback, _pollingInterval, fallbackOptions) {
        const filePath = toCanonicalName(fileName);
        if ((0, ts_js_1.multiMapAddValue)(fileWatcherCallbacks, filePath, callback).length === 1 && fileTimestamps) {
            fileTimestamps.set(filePath, getModifiedTime(fileName) || exports.missingFileModifiedTime);
        }
        const dirPath = (0, ts_js_1.getDirectoryPath)(filePath) || ".";
        const watcher = dirWatchers.get(dirPath) ||
            createDirectoryWatcher((0, ts_js_1.getDirectoryPath)(fileName) || ".", dirPath, fallbackOptions);
        watcher.referenceCount++;
        return {
            close: () => {
                if (watcher.referenceCount === 1) {
                    watcher.close();
                    dirWatchers.delete(dirPath);
                }
                else {
                    watcher.referenceCount--;
                }
                (0, ts_js_1.multiMapRemoveValue)(fileWatcherCallbacks, filePath, callback);
            },
        };
    }
    function createDirectoryWatcher(dirName, dirPath, fallbackOptions) {
        const watcher = fsWatch(dirName, 1 /* FileSystemEntryKind.Directory */, (eventName, relativeFileName) => {
            // When files are deleted from disk, the triggered "rename" event would have a relativefileName of "undefined"
            if (!(0, ts_js_1.isString)(relativeFileName))
                return;
            const fileName = (0, ts_js_1.getNormalizedAbsolutePath)(relativeFileName, dirName);
            const filePath = toCanonicalName(fileName);
            // Some applications save a working file via rename operations
            const callbacks = fileName && fileWatcherCallbacks.get(filePath);
            if (callbacks) {
                let currentModifiedTime;
                let eventKind = FileWatcherEventKind.Changed;
                if (fileTimestamps) {
                    const existingTime = fileTimestamps.get(filePath);
                    if (eventName === "change") {
                        currentModifiedTime = getModifiedTime(fileName) || exports.missingFileModifiedTime;
                        if (currentModifiedTime.getTime() === existingTime.getTime())
                            return;
                    }
                    currentModifiedTime || (currentModifiedTime = getModifiedTime(fileName) || exports.missingFileModifiedTime);
                    fileTimestamps.set(filePath, currentModifiedTime);
                    if (existingTime === exports.missingFileModifiedTime)
                        eventKind = FileWatcherEventKind.Created;
                    else if (currentModifiedTime === exports.missingFileModifiedTime)
                        eventKind = FileWatcherEventKind.Deleted;
                }
                for (const fileCallback of callbacks) {
                    fileCallback(fileName, eventKind, currentModifiedTime);
                }
            }
        }, 
        /*recursive*/ false, PollingInterval.Medium, fallbackOptions);
        watcher.referenceCount = 0;
        dirWatchers.set(dirPath, watcher);
        return watcher;
    }
}
function createFixedChunkSizePollingWatchFile(host) {
    const watchedFiles = [];
    let pollIndex = 0;
    let pollScheduled;
    return watchFile;
    function watchFile(fileName, callback) {
        const file = {
            fileName,
            callback,
            mtime: getModifiedTime(host, fileName),
        };
        watchedFiles.push(file);
        scheduleNextPoll();
        return {
            close: () => {
                file.isClosed = true;
                (0, ts_js_1.unorderedRemoveItem)(watchedFiles, file);
            },
        };
    }
    function pollQueue(_timeoutType) {
        pollScheduled = undefined;
        pollIndex = pollWatchedFileQueue(host, watchedFiles, pollIndex, pollingChunkSize[PollingInterval.Low]);
        scheduleNextPoll();
    }
    function scheduleNextPoll() {
        if (!watchedFiles.length || pollScheduled)
            return;
        pollScheduled = (() => {
            const timerHost = host;
            const callback = pollQueue;
            const timeoutDelay = PollingInterval.High;
            const t1 = "pollQueue";
            return timerHost.setTimeout(() => callback(t1), timeoutDelay, t1);
        })();
    }
}
function createSingleWatcherPerName(cache, useCaseSensitiveFileNames, name, callback, createWatcher, createForwarder) {
    const toCanonicalFileName = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    const path = toCanonicalFileName(name);
    const existing = cache.get(path);
    if (existing) {
        existing.callbacks.push(callback);
    }
    else {
        cache.set(path, {
            watcher: createWatcher(createForwarder(() => cache.get(path)?.callbacks.slice())),
            callbacks: [callback],
        });
    }
    return {
        close: () => {
            const watcher = cache.get(path);
            // Watcher is not expected to be undefined, but if it is normally its because
            // exception was thrown somewhere else and watch state is not what it should be
            if (!watcher)
                return;
            if (!(0, ts_js_1.orderedRemoveItem)(watcher.callbacks, callback) || watcher.callbacks.length)
                return;
            cache.delete(path);
            (0, ts_js_1.closeFileWatcherOf)(watcher);
        },
    };
}
/**
 * Returns true if file status changed
 */
function onWatchedFileStat(watchedFile, modifiedTime) {
    const oldTime = watchedFile.mtime.getTime();
    const newTime = modifiedTime.getTime();
    if (oldTime !== newTime) {
        watchedFile.mtime = modifiedTime;
        // Pass modified times so tsc --build can use it
        watchedFile.callback(watchedFile.fileName, getFileWatcherEventKind(oldTime, newTime), modifiedTime);
        return true;
    }
    return false;
}
/** @internal */
function getFileWatcherEventKind(oldTime, newTime) {
    return oldTime === 0
        ? FileWatcherEventKind.Created
        : newTime === 0
            ? FileWatcherEventKind.Deleted
            : FileWatcherEventKind.Changed;
}
/** @internal */
exports.ignoredPaths = ["/node_modules/.", "/.git", "/.#"];
let curSysLog = ts_js_1.noop;
/** @internal */
function sysLog(s) {
    return curSysLog(s);
}
/** @internal */
function setSysLog(logger) {
    curSysLog = logger;
}
/**
 * Watch the directory recursively using host provided method to watch child directories
 * that means if this is recursive watcher, watch the children directories as well
 * (eg on OS that dont support recursive watch using fs.watch use fs.watchFile)
 */
function createDirectoryWatcherSupportingRecursive({ watchDirectory, useCaseSensitiveFileNames, getCurrentDirectory, getAccessibleSortedChildDirectories, fileSystemEntryExists, realpath, setTimeout, clearTimeout, }) {
    const cache = new Map();
    const callbackCache = (0, ts_js_1.createMultiMap)();
    const cacheToUpdateChildWatches = new Map();
    let timerToUpdateChildWatches;
    const filePathComparer = (0, ts_js_1.getStringComparer)(!useCaseSensitiveFileNames);
    const toCanonicalFilePath = (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames);
    return (dirName, callback, recursive, options) => recursive ?
        createDirectoryWatcher(dirName, options, callback) :
        watchDirectory(dirName, callback, recursive, options);
    /**
     * Create the directory watcher for the dirPath.
     */
    function createDirectoryWatcher(dirName, options, callback, link) {
        const dirPath = toCanonicalFilePath(dirName);
        let directoryWatcher = cache.get(dirPath);
        if (directoryWatcher) {
            directoryWatcher.refCount++;
        }
        else {
            directoryWatcher = {
                watcher: watchDirectory(dirName, fileName => {
                    if (isIgnoredPath(fileName, options))
                        return;
                    if (options?.synchronousWatchDirectory) {
                        // Call the actual callback
                        if (!cache.get(dirPath)?.targetWatcher)
                            invokeCallbacks(dirName, dirPath, fileName);
                        // Iterate through existing children and update the watches if needed
                        updateChildWatches(dirName, dirPath, options);
                    }
                    else {
                        nonSyncUpdateChildWatches(dirName, dirPath, fileName, options);
                    }
                }, 
                /*recursive*/ false, options),
                refCount: 1,
                childWatches: ts_js_1.emptyArray,
                targetWatcher: undefined,
                links: undefined,
            };
            cache.set(dirPath, directoryWatcher);
            updateChildWatches(dirName, dirPath, options);
        }
        if (link)
            (directoryWatcher.links ?? (directoryWatcher.links = new Set())).add(link);
        const callbackToAdd = callback && { dirName, callback };
        if (callbackToAdd) {
            (0, ts_js_1.multiMapAddValue)(callbackCache, dirPath, callbackToAdd);
        }
        return {
            dirName,
            close: () => {
                const directoryWatcher = ts_js_1.Debug.checkDefined(cache.get(dirPath));
                if (callbackToAdd)
                    (0, ts_js_1.multiMapRemoveValue)(callbackCache, dirPath, callbackToAdd);
                if (link)
                    directoryWatcher.links?.delete(link);
                directoryWatcher.refCount--;
                if (directoryWatcher.refCount)
                    return;
                cache.delete(dirPath);
                directoryWatcher.links = undefined;
                (0, ts_js_1.closeFileWatcherOf)(directoryWatcher);
                closeTargetWatcher(directoryWatcher);
                directoryWatcher.childWatches.forEach(ts_js_1.closeFileWatcher);
            },
        };
    }
    function invokeCallbacks(dirName, dirPath, fileNameOrInvokeMap, fileNames) {
        let fileName;
        let invokeMap;
        if ((0, ts_js_1.isString)(fileNameOrInvokeMap)) {
            fileName = fileNameOrInvokeMap;
        }
        else {
            invokeMap = fileNameOrInvokeMap;
        }
        // Call the actual callback
        callbackCache.forEach((callbacks, rootDirName) => {
            if (invokeMap && invokeMap.get(rootDirName) === true)
                return;
            if (rootDirName === dirPath || ((0, ts_js_1.startsWith)(dirPath, rootDirName) && dirPath[rootDirName.length] === ts_js_1.directorySeparator)) {
                if (invokeMap) {
                    if (fileNames) {
                        const existing = invokeMap.get(rootDirName);
                        if (existing) {
                            if (Array.isArray(existing))
                                existing.push(...fileNames);
                        }
                        else {
                            invokeMap.set(rootDirName, fileNames.slice());
                        }
                    }
                    else {
                        invokeMap.set(rootDirName, true);
                    }
                }
                else {
                    callbacks.forEach(({ callback }) => callback(fileName));
                }
            }
        });
        cache.get(dirPath)?.links?.forEach(link => {
            const toPathInLink = (fileName) => (0, ts_js_1.combinePaths)(link, (0, ts_js_1.getRelativePathFromDirectory)(dirName, fileName, toCanonicalFilePath));
            if (invokeMap) {
                invokeCallbacks(link, toCanonicalFilePath(link), invokeMap, fileNames?.map(toPathInLink));
            }
            else {
                invokeCallbacks(link, toCanonicalFilePath(link), toPathInLink(fileName));
            }
        });
    }
    function nonSyncUpdateChildWatches(dirName, dirPath, fileName, options) {
        // Iterate through existing children and update the watches if needed
        const parentWatcher = cache.get(dirPath);
        if (parentWatcher && fileSystemEntryExists(dirName, 1 /* FileSystemEntryKind.Directory */)) {
            // Schedule the update and postpone invoke for callbacks
            scheduleUpdateChildWatches(dirName, dirPath, fileName, options);
            return;
        }
        // Call the actual callbacks and remove child watches
        invokeCallbacks(dirName, dirPath, fileName);
        closeTargetWatcher(parentWatcher);
        removeChildWatches(parentWatcher);
    }
    function scheduleUpdateChildWatches(dirName, dirPath, fileName, options) {
        const existing = cacheToUpdateChildWatches.get(dirPath);
        if (existing) {
            existing.fileNames.push(fileName);
        }
        else {
            cacheToUpdateChildWatches.set(dirPath, { dirName, options, fileNames: [fileName] });
        }
        if (timerToUpdateChildWatches) {
            clearTimeout(timerToUpdateChildWatches);
            timerToUpdateChildWatches = undefined;
        }
        timerToUpdateChildWatches = (() => {
            const callback = onTimerToUpdateChildWatches;
            const timeoutDelay = 1000;
            const t1 = "timerToUpdateChildWatches";
            return setTimeout(() => callback(t1), timeoutDelay, t1);
        })();
    }
    function onTimerToUpdateChildWatches(_timeoutType) {
        timerToUpdateChildWatches = undefined;
        sysLog(`sysLog:: onTimerToUpdateChildWatches:: ${cacheToUpdateChildWatches.size}`);
        const start = (0, ts_js_1.timestamp)();
        const invokeMap = new Map();
        while (!timerToUpdateChildWatches && cacheToUpdateChildWatches.size) {
            const result = cacheToUpdateChildWatches.entries().next();
            ts_js_1.Debug.assert(!result.done);
            const { value: [dirPath, { dirName, options, fileNames }] } = result;
            cacheToUpdateChildWatches.delete(dirPath);
            // Because the child refresh is fresh, we would need to invalidate whole root directory being watched
            // to ensure that all the changes are reflected at this time
            const hasChanges = updateChildWatches(dirName, dirPath, options);
            if (!cache.get(dirPath)?.targetWatcher)
                invokeCallbacks(dirName, dirPath, invokeMap, hasChanges ? undefined : fileNames);
        }
        sysLog(`sysLog:: invokingWatchers:: Elapsed:: ${(0, ts_js_1.timestamp)() - start}ms:: ${cacheToUpdateChildWatches.size}`);
        callbackCache.forEach((callbacks, rootDirName) => {
            const existing = invokeMap.get(rootDirName);
            if (existing) {
                callbacks.forEach(({ callback, dirName }) => {
                    if ((0, ts_js_1.isArray)(existing)) {
                        existing.forEach(callback);
                    }
                    else {
                        callback(dirName);
                    }
                });
            }
        });
        const elapsed = (0, ts_js_1.timestamp)() - start;
        sysLog(`sysLog:: Elapsed:: ${elapsed}ms:: onTimerToUpdateChildWatches:: ${cacheToUpdateChildWatches.size} ${timerToUpdateChildWatches}`);
    }
    function removeChildWatches(parentWatcher) {
        if (!parentWatcher)
            return;
        const existingChildWatches = parentWatcher.childWatches;
        parentWatcher.childWatches = ts_js_1.emptyArray;
        for (const childWatcher of existingChildWatches) {
            childWatcher.close();
            removeChildWatches(cache.get(toCanonicalFilePath(childWatcher.dirName)));
        }
    }
    function closeTargetWatcher(watcher) {
        if (watcher?.targetWatcher) {
            watcher.targetWatcher.close();
            watcher.targetWatcher = undefined;
        }
    }
    function updateChildWatches(parentDir, parentDirPath, options) {
        // Iterate through existing children and update the watches if needed
        const parentWatcher = cache.get(parentDirPath);
        if (!parentWatcher)
            return false;
        const target = (0, ts_js_1.normalizePath)(realpath(parentDir));
        let hasChanges;
        let newChildWatches;
        if (filePathComparer(target, parentDir) === 0 /* Comparison.EqualTo */) {
            // if (parentWatcher.target) closeFileWatcher
            hasChanges = (0, ts_js_1.enumerateInsertsAndDeletes)(fileSystemEntryExists(parentDir, 1 /* FileSystemEntryKind.Directory */) ? (0, ts_js_1.mapDefined)(getAccessibleSortedChildDirectories(parentDir), child => {
                const childFullName = (0, ts_js_1.getNormalizedAbsolutePath)(child, parentDir);
                // Filter our the symbolic link directories since those arent included in recursive watch
                // which is same behaviour when recursive: true is passed to fs.watch
                return !isIgnoredPath(childFullName, options) && filePathComparer(childFullName, (0, ts_js_1.normalizePath)(realpath(childFullName))) === 0 /* Comparison.EqualTo */ ? childFullName : undefined;
            }) : ts_js_1.emptyArray, parentWatcher.childWatches, (child, childWatcher) => filePathComparer(child, childWatcher.dirName), createAndAddChildDirectoryWatcher, ts_js_1.closeFileWatcher, addChildDirectoryWatcher);
        }
        else if (parentWatcher.targetWatcher && filePathComparer(target, parentWatcher.targetWatcher.dirName) === 0 /* Comparison.EqualTo */) {
            hasChanges = false;
            ts_js_1.Debug.assert(parentWatcher.childWatches === ts_js_1.emptyArray);
        }
        else {
            closeTargetWatcher(parentWatcher);
            parentWatcher.targetWatcher = createDirectoryWatcher(target, options, /*callback*/ undefined, parentDir);
            parentWatcher.childWatches.forEach(ts_js_1.closeFileWatcher);
            hasChanges = true;
        }
        parentWatcher.childWatches = newChildWatches || ts_js_1.emptyArray;
        return hasChanges;
        /**
         * Create new childDirectoryWatcher and add it to the new ChildDirectoryWatcher list
         */
        function createAndAddChildDirectoryWatcher(childName) {
            const result = createDirectoryWatcher(childName, options);
            addChildDirectoryWatcher(result);
        }
        /**
         * Add child directory watcher to the new ChildDirectoryWatcher list
         */
        function addChildDirectoryWatcher(childWatcher) {
            (newChildWatches || (newChildWatches = [])).push(childWatcher);
        }
    }
    function isIgnoredPath(path, options) {
        return (0, ts_js_1.some)(exports.ignoredPaths, searchPath => isInPath(path, searchPath)) ||
            isIgnoredByWatchOptions(path, options, useCaseSensitiveFileNames, getCurrentDirectory);
    }
    function isInPath(path, searchPath) {
        if (path.includes(searchPath))
            return true;
        if (useCaseSensitiveFileNames)
            return false;
        return toCanonicalFilePath(path).includes(searchPath);
    }
}
/** @internal */
var FileSystemEntryKind;
(function (FileSystemEntryKind) {
    FileSystemEntryKind[FileSystemEntryKind["File"] = 0] = "File";
    FileSystemEntryKind[FileSystemEntryKind["Directory"] = 1] = "Directory";
})(FileSystemEntryKind || (exports.FileSystemEntryKind = FileSystemEntryKind = {}));
function createFileWatcherCallback(callback) {
    return (_fileName, eventKind, modifiedTime) => callback(eventKind === FileWatcherEventKind.Changed ? "change" : "rename", "", modifiedTime);
}
function createFsWatchCallbackForFileWatcherCallback(fileName, callback, getModifiedTime) {
    return (eventName, _relativeFileName, modifiedTime) => {
        if (eventName === "rename") {
            // Check time stamps rather than file system entry checks
            modifiedTime || (modifiedTime = getModifiedTime(fileName) || exports.missingFileModifiedTime);
            callback(fileName, modifiedTime !== exports.missingFileModifiedTime ? FileWatcherEventKind.Created : FileWatcherEventKind.Deleted, modifiedTime);
        }
        else {
            // Change
            callback(fileName, FileWatcherEventKind.Changed, modifiedTime);
        }
    };
}
function isIgnoredByWatchOptions(pathToCheck, options, useCaseSensitiveFileNames, getCurrentDirectory) {
    return (options?.excludeDirectories || options?.excludeFiles) && ((0, ts_js_1.matchesExclude)(pathToCheck, options?.excludeFiles, useCaseSensitiveFileNames, getCurrentDirectory()) ||
        (0, ts_js_1.matchesExclude)(pathToCheck, options?.excludeDirectories, useCaseSensitiveFileNames, getCurrentDirectory()));
}
function createFsWatchCallbackForDirectoryWatcherCallback(directoryName, callback, options, useCaseSensitiveFileNames, getCurrentDirectory) {
    return (eventName, relativeFileName) => {
        // In watchDirectory we only care about adding and removing files (when event name is
        // "rename"); changes made within files are handled by corresponding fileWatchers (when
        // event name is "change")
        if (eventName === "rename") {
            // When deleting a file, the passed baseFileName is null
            const fileName = !relativeFileName ? directoryName : (0, ts_js_1.normalizePath)((0, ts_js_1.combinePaths)(directoryName, relativeFileName));
            if (!relativeFileName || !isIgnoredByWatchOptions(fileName, options, useCaseSensitiveFileNames, getCurrentDirectory)) {
                callback(fileName);
            }
        }
    };
}
/** @internal */
function createSystemWatchFunctions({ pollingWatchFileWorker, getModifiedTime, setTimeout, clearTimeout, fsWatchWorker, fileSystemEntryExists, useCaseSensitiveFileNames, getCurrentDirectory, fsSupportsRecursiveFsWatch, getAccessibleSortedChildDirectories, realpath, tscWatchFile, useNonPollingWatchers, tscWatchDirectory, inodeWatching, fsWatchWithTimestamp, sysLog, }) {
    const pollingWatches = new Map();
    const fsWatches = new Map();
    const fsWatchesRecursive = new Map();
    let dynamicPollingWatchFile;
    let fixedChunkSizePollingWatchFile;
    let nonPollingWatchFile;
    let hostRecursiveDirectoryWatcher;
    let hitSystemWatcherLimit = false;
    return {
        watchFile,
        watchDirectory,
    };
    function watchFile(fileName, callback, pollingInterval, options) {
        options = updateOptionsForWatchFile(options, useNonPollingWatchers);
        const watchFileKind = ts_js_1.Debug.checkDefined(options.watchFile);
        switch (watchFileKind) {
            case ts_js_1.WatchFileKind.FixedPollingInterval:
                return pollingWatchFile(fileName, callback, PollingInterval.Low, /*options*/ undefined);
            case ts_js_1.WatchFileKind.PriorityPollingInterval:
                return pollingWatchFile(fileName, callback, pollingInterval, /*options*/ undefined);
            case ts_js_1.WatchFileKind.DynamicPriorityPolling:
                return ensureDynamicPollingWatchFile()(fileName, callback, pollingInterval, /*options*/ undefined);
            case ts_js_1.WatchFileKind.FixedChunkSizePolling:
                return ensureFixedChunkSizePollingWatchFile()(fileName, callback, /* pollingInterval */ undefined, /*options*/ undefined);
            case ts_js_1.WatchFileKind.UseFsEvents:
                return fsWatch(fileName, 0 /* FileSystemEntryKind.File */, createFsWatchCallbackForFileWatcherCallback(fileName, callback, getModifiedTime), 
                /*recursive*/ false, pollingInterval, (0, ts_js_1.getFallbackOptions)(options));
            case ts_js_1.WatchFileKind.UseFsEventsOnParentDirectory:
                if (!nonPollingWatchFile) {
                    nonPollingWatchFile = createUseFsEventsOnParentDirectoryWatchFile(fsWatch, useCaseSensitiveFileNames, getModifiedTime, fsWatchWithTimestamp);
                }
                return nonPollingWatchFile(fileName, callback, pollingInterval, (0, ts_js_1.getFallbackOptions)(options));
            default:
                ts_js_1.Debug.assertNever(watchFileKind);
        }
    }
    function ensureDynamicPollingWatchFile() {
        return dynamicPollingWatchFile || (dynamicPollingWatchFile = createDynamicPriorityPollingWatchFile({ getModifiedTime, setTimeout }));
    }
    function ensureFixedChunkSizePollingWatchFile() {
        return fixedChunkSizePollingWatchFile || (fixedChunkSizePollingWatchFile = createFixedChunkSizePollingWatchFile({ getModifiedTime, setTimeout }));
    }
    function updateOptionsForWatchFile(options, useNonPollingWatchers) {
        if (options && options.watchFile !== undefined)
            return options;
        switch (tscWatchFile) {
            case "PriorityPollingInterval":
                // Use polling interval based on priority when create watch using host.watchFile
                return { watchFile: ts_js_1.WatchFileKind.PriorityPollingInterval };
            case "DynamicPriorityPolling":
                // Use polling interval but change the interval depending on file changes and their default polling interval
                return { watchFile: ts_js_1.WatchFileKind.DynamicPriorityPolling };
            case "UseFsEvents":
                // Use notifications from FS to watch with falling back to fs.watchFile
                return generateWatchFileOptions(ts_js_1.WatchFileKind.UseFsEvents, ts_js_1.PollingWatchKind.PriorityInterval, options);
            case "UseFsEventsWithFallbackDynamicPolling":
                // Use notifications from FS to watch with falling back to dynamic watch file
                return generateWatchFileOptions(ts_js_1.WatchFileKind.UseFsEvents, ts_js_1.PollingWatchKind.DynamicPriority, options);
            case "UseFsEventsOnParentDirectory":
                useNonPollingWatchers = true;
            // fall through
            default:
                return useNonPollingWatchers ?
                    // Use notifications from FS to watch with falling back to fs.watchFile
                    generateWatchFileOptions(ts_js_1.WatchFileKind.UseFsEventsOnParentDirectory, ts_js_1.PollingWatchKind.PriorityInterval, options) :
                    // Default to using fs events
                    { watchFile: ts_js_1.WatchFileKind.UseFsEvents };
        }
    }
    function generateWatchFileOptions(watchFile, fallbackPolling, options) {
        const defaultFallbackPolling = options?.fallbackPolling;
        return {
            watchFile,
            fallbackPolling: defaultFallbackPolling === undefined ?
                fallbackPolling :
                defaultFallbackPolling,
        };
    }
    function watchDirectory(directoryName, callback, recursive, options) {
        if (fsSupportsRecursiveFsWatch) {
            return fsWatch(directoryName, 1 /* FileSystemEntryKind.Directory */, createFsWatchCallbackForDirectoryWatcherCallback(directoryName, callback, options, useCaseSensitiveFileNames, getCurrentDirectory), recursive, PollingInterval.Medium, (0, ts_js_1.getFallbackOptions)(options));
        }
        if (!hostRecursiveDirectoryWatcher) {
            hostRecursiveDirectoryWatcher = createDirectoryWatcherSupportingRecursive({
                useCaseSensitiveFileNames,
                getCurrentDirectory,
                fileSystemEntryExists,
                getAccessibleSortedChildDirectories,
                watchDirectory: nonRecursiveWatchDirectory,
                realpath,
                setTimeout,
                clearTimeout,
            });
        }
        return hostRecursiveDirectoryWatcher(directoryName, callback, recursive, options);
    }
    function nonRecursiveWatchDirectory(directoryName, callback, recursive, options) {
        ts_js_1.Debug.assert(!recursive);
        const watchDirectoryOptions = updateOptionsForWatchDirectory(options);
        const watchDirectoryKind = ts_js_1.Debug.checkDefined(watchDirectoryOptions.watchDirectory);
        switch (watchDirectoryKind) {
            case ts_js_1.WatchDirectoryKind.FixedPollingInterval:
                return pollingWatchFile(directoryName, () => callback(directoryName), PollingInterval.Medium, 
                /*options*/ undefined);
            case ts_js_1.WatchDirectoryKind.DynamicPriorityPolling:
                return ensureDynamicPollingWatchFile()(directoryName, () => callback(directoryName), PollingInterval.Medium, 
                /*options*/ undefined);
            case ts_js_1.WatchDirectoryKind.FixedChunkSizePolling:
                return ensureFixedChunkSizePollingWatchFile()(directoryName, () => callback(directoryName), 
                /* pollingInterval */ undefined, 
                /*options*/ undefined);
            case ts_js_1.WatchDirectoryKind.UseFsEvents:
                return fsWatch(directoryName, 1 /* FileSystemEntryKind.Directory */, createFsWatchCallbackForDirectoryWatcherCallback(directoryName, callback, options, useCaseSensitiveFileNames, getCurrentDirectory), recursive, PollingInterval.Medium, (0, ts_js_1.getFallbackOptions)(watchDirectoryOptions));
            default:
                ts_js_1.Debug.assertNever(watchDirectoryKind);
        }
    }
    function updateOptionsForWatchDirectory(options) {
        if (options && options.watchDirectory !== undefined)
            return options;
        switch (tscWatchDirectory) {
            case "RecursiveDirectoryUsingFsWatchFile":
                // Use polling interval based on priority when create watch using host.watchFile
                return { watchDirectory: ts_js_1.WatchDirectoryKind.FixedPollingInterval };
            case "RecursiveDirectoryUsingDynamicPriorityPolling":
                // Use polling interval but change the interval depending on file changes and their default polling interval
                return { watchDirectory: ts_js_1.WatchDirectoryKind.DynamicPriorityPolling };
            default:
                const defaultFallbackPolling = options?.fallbackPolling;
                return {
                    watchDirectory: ts_js_1.WatchDirectoryKind.UseFsEvents,
                    fallbackPolling: defaultFallbackPolling !== undefined ?
                        defaultFallbackPolling :
                        undefined,
                };
        }
    }
    function pollingWatchFile(fileName, callback, pollingInterval, options) {
        return createSingleWatcherPerName(pollingWatches, useCaseSensitiveFileNames, fileName, callback, cb => pollingWatchFileWorker(fileName, cb, pollingInterval, options), (getCallbacks) => (param1, param2, param3) => { const callbacks = getCallbacks(); if (callbacks)
            callbacks.forEach(cb => cb(param1, param2, param3)); });
    }
    function fsWatch(fileOrDirectory, entryKind, callback, recursive, fallbackPollingInterval, fallbackOptions) {
        return createSingleWatcherPerName(recursive ? fsWatchesRecursive : fsWatches, useCaseSensitiveFileNames, fileOrDirectory, callback, cb => fsWatchHandlingExistenceOnHost(fileOrDirectory, entryKind, cb, recursive, fallbackPollingInterval, fallbackOptions), (getCallbacks) => (param1, param2, param3) => { const callbacks = getCallbacks(); if (callbacks)
            callbacks.forEach(cb => cb(param1, param2, param3)); });
    }
    function fsWatchHandlingExistenceOnHost(fileOrDirectory, entryKind, callback, recursive, fallbackPollingInterval, fallbackOptions) {
        let lastDirectoryPartWithDirectorySeparator;
        let lastDirectoryPart;
        if (inodeWatching) {
            lastDirectoryPartWithDirectorySeparator = fileOrDirectory.substring(fileOrDirectory.lastIndexOf(ts_js_1.directorySeparator));
            lastDirectoryPart = lastDirectoryPartWithDirectorySeparator.slice(ts_js_1.directorySeparator.length);
        }
        /** Watcher for the file system entry depending on whether it is missing or present */
        let watcher = !fileSystemEntryExists(fileOrDirectory, entryKind) ?
            watchMissingFileSystemEntry() :
            watchPresentFileSystemEntry();
        return {
            close: () => {
                // Close the watcher (either existing file system entry watcher or missing file system entry watcher)
                if (watcher) {
                    watcher.close();
                    watcher = undefined;
                }
            },
        };
        function updateWatcher(createWatcher) {
            // If watcher is not closed, update it
            if (watcher) {
                sysLog(`sysLog:: ${fileOrDirectory}:: Changing watcher to ${createWatcher === watchPresentFileSystemEntry ? "Present" : "Missing"}FileSystemEntryWatcher`);
                watcher.close();
                watcher = createWatcher();
            }
        }
        /**
         * Watch the file or directory that is currently present
         * and when the watched file or directory is deleted, switch to missing file system entry watcher
         */
        function watchPresentFileSystemEntry() {
            if (hitSystemWatcherLimit) {
                sysLog(`sysLog:: ${fileOrDirectory}:: Defaulting to watchFile`);
                return watchPresentFileSystemEntryWithFsWatchFile();
            }
            try {
                const presentWatcher = (entryKind === 1 /* FileSystemEntryKind.Directory */ || !fsWatchWithTimestamp ? fsWatchWorker : fsWatchWorkerHandlingTimestamp)(fileOrDirectory, recursive, inodeWatching ?
                    callbackChangingToMissingFileSystemEntry :
                    callback);
                // Watch the missing file or directory or error
                presentWatcher.on("error", () => {
                    callback("rename", "");
                    updateWatcher(watchMissingFileSystemEntry);
                });
                return presentWatcher;
            }
            catch (e) {
                // Catch the exception and use polling instead
                // Eg. on linux the number of watches are limited and one could easily exhaust watches and the exception ENOSPC is thrown when creating watcher at that point
                // so instead of throwing error, use fs.watchFile
                hitSystemWatcherLimit || (hitSystemWatcherLimit = (0, hostErrors_js_1.propertyOf)(e, "code") === "ENOSPC");
                sysLog(`sysLog:: ${fileOrDirectory}:: Changing to watchFile`);
                return watchPresentFileSystemEntryWithFsWatchFile();
            }
        }
        function callbackChangingToMissingFileSystemEntry(event, relativeName) {
            // In some scenarios, file save operation fires event with fileName.ext~ instead of fileName.ext
            // To ensure we see the file going missing and coming back up (file delete and then recreated)
            // and watches being updated correctly we are calling back with fileName.ext as well as fileName.ext~
            // The worst is we have fired event that was not needed but we wont miss any changes
            // especially in cases where file goes missing and watches wrong inode
            let originalRelativeName;
            if (relativeName && (0, ts_js_1.endsWith)(relativeName, "~")) {
                originalRelativeName = relativeName;
                relativeName = relativeName.slice(0, relativeName.length - 1);
            }
            // because relativeName is not guaranteed to be correct we need to check on each rename with few combinations
            // Eg on ubuntu while watching app/node_modules the relativeName is "node_modules" which is neither relative nor full path
            if (event === "rename" &&
                (!relativeName ||
                    relativeName === lastDirectoryPart ||
                    (0, ts_js_1.endsWith)(relativeName, lastDirectoryPartWithDirectorySeparator))) {
                const modifiedTime = getModifiedTime(fileOrDirectory) || exports.missingFileModifiedTime;
                if (originalRelativeName)
                    callback(event, originalRelativeName, modifiedTime);
                callback(event, relativeName, modifiedTime);
                if (inodeWatching) {
                    // If this was rename event, inode has changed means we need to update watcher
                    updateWatcher(modifiedTime === exports.missingFileModifiedTime ? watchMissingFileSystemEntry : watchPresentFileSystemEntry);
                }
                else if (modifiedTime === exports.missingFileModifiedTime) {
                    updateWatcher(watchMissingFileSystemEntry);
                }
            }
            else {
                if (originalRelativeName)
                    callback(event, originalRelativeName);
                callback(event, relativeName);
            }
        }
        /**
         * Watch the file or directory using fs.watchFile since fs.watch threw exception
         * Eg. on linux the number of watches are limited and one could easily exhaust watches and the exception ENOSPC is thrown when creating watcher at that point
         */
        function watchPresentFileSystemEntryWithFsWatchFile() {
            return watchFile(fileOrDirectory, createFileWatcherCallback(callback), fallbackPollingInterval, fallbackOptions);
        }
        /**
         * Watch the file or directory that is missing
         * and switch to existing file or directory when the missing filesystem entry is created
         */
        function watchMissingFileSystemEntry() {
            return watchFile(fileOrDirectory, (_fileName, eventKind, modifiedTime) => {
                if (eventKind === FileWatcherEventKind.Created) {
                    modifiedTime || (modifiedTime = getModifiedTime(fileOrDirectory) || exports.missingFileModifiedTime);
                    if (modifiedTime !== exports.missingFileModifiedTime) {
                        callback("rename", "", modifiedTime);
                        // Call the callback for current file or directory
                        // For now it could be callback for the inner directory creation,
                        // but just return current directory, better than current no-op
                        updateWatcher(watchPresentFileSystemEntry);
                    }
                }
            }, fallbackPollingInterval, fallbackOptions);
        }
    }
    function fsWatchWorkerHandlingTimestamp(fileOrDirectory, recursive, callback) {
        let modifiedTime = getModifiedTime(fileOrDirectory) || exports.missingFileModifiedTime;
        return fsWatchWorker(fileOrDirectory, recursive, (eventName, relativeFileName, currentModifiedTime) => {
            if (eventName === "change") {
                currentModifiedTime || (currentModifiedTime = getModifiedTime(fileOrDirectory) || exports.missingFileModifiedTime);
                if (currentModifiedTime.getTime() === modifiedTime.getTime())
                    return;
            }
            modifiedTime = currentModifiedTime || getModifiedTime(fileOrDirectory) || exports.missingFileModifiedTime;
            callback(eventName, relativeFileName, modifiedTime);
        });
    }
}
/**
 * patch writefile to create folder before writing the file
 *
 * @internal
 */
function patchWriteFileEnsuringDirectory(sys) {
    // patch writefile to create folder before writing the file
    const originalWriteFile = sys.writeFile;
    sys.writeFile = (path, data, writeBom) => (0, ts_js_1.writeFileEnsuringDirectories)(path, data, !!writeBom, (path, data, writeByteOrderMark) => originalWriteFile.call(sys, path, data, writeByteOrderMark), path => sys.createDirectory(path), path => sys.directoryExists(path));
}
// TODO: GH#18217 this is used as if it's certainly defined in many places.
exports.sys = (() => {
    // NodeJS detects "\uFEFF" at the start of the string and *replaces* it with the actual
    // byte order mark from the specified encoding. Using any other byte order mark does
    // not actually work.
    const byteOrderMarkIndicator = "\uFEFF";
    function getNodeSystem() {
        const nativePattern = /^native |^\([^)]+\)$|^(?:internal[\\/]|[\w\s]+(?:\.js)?$)/;
        let activeSession;
        let profilePath = "./profile.cpuprofile";
        const isMacOs = process.platform === "darwin";
        const isLinuxOrMacOs = process.platform === "linux" || isMacOs;
        const statSyncOptions = { throwIfNoEntry: false };
        const platform = _os.platform();
        const useCaseSensitiveFileNames = isFileSystemCaseSensitive();
        const fsRealpath = !!_fs.realpathSync.native ? process.platform === "win32" ? fsRealPathHandlingLongPath : _fs.realpathSync.native : _fs.realpathSync;
        // If our filename is "sys.js", then we are executing unbundled on the raw tsc output.
        // In that case, simulate a faked path in the directory where a bundle would normally
        // appear (e.g. the directory containing lib.*.d.ts files).
        //
        // Note that if we ever emit as files like cjs/mjs, this check will be wrong.
        const executingFilePath = __filename.endsWith("sys.js") ? _path.join(_path.dirname(__dirname), "__fake__.js") : __filename;
        const fsSupportsRecursiveFsWatch = process.platform === "win32" || isMacOs;
        const getCurrentDirectory = (0, ts_js_1.memoize)(() => process.cwd());
        const { watchFile, watchDirectory } = createSystemWatchFunctions({
            pollingWatchFileWorker: fsWatchFileWorker,
            getModifiedTime,
            setTimeout: (callback, ms, label) => setTimeout(callback, ms, label),
            clearTimeout: (timeoutId) => { clearTimeout(timeoutId); },
            fsWatchWorker,
            useCaseSensitiveFileNames,
            getCurrentDirectory,
            fileSystemEntryExists,
            // Node 4.0 `fs.watch` function supports the "recursive" option on both OSX and Windows
            // (ref: https://github.com/nodejs/node/pull/2649 and https://github.com/Microsoft/TypeScript/issues/4643)
            fsSupportsRecursiveFsWatch,
            getAccessibleSortedChildDirectories: path => getAccessibleFileSystemEntries(path).directories,
            realpath,
            tscWatchFile: process.env.TSC_WATCHFILE,
            useNonPollingWatchers: !!process.env.TSC_NONPOLLING_WATCHER,
            tscWatchDirectory: process.env.TSC_WATCHDIRECTORY,
            inodeWatching: isLinuxOrMacOs,
            fsWatchWithTimestamp: isMacOs,
            sysLog,
        });
        const nodeSystem = {
            args: process.argv.slice(2),
            newLine: _os.EOL,
            useCaseSensitiveFileNames,
            write(s) {
                process.stdout.write(s);
            },
            getWidthOfTerminal() {
                return process.stdout.columns ?? 0;
            },
            writeOutputIsTTY() {
                return !!process.stdout.isTTY;
            },
            readFile,
            writeFile,
            watchFile,
            watchDirectory,
            preferNonRecursiveWatch: !fsSupportsRecursiveFsWatch,
            resolvePath: path => _path.resolve(path),
            fileExists,
            directoryExists,
            getAccessibleFileSystemEntries,
            createDirectory(directoryName) {
                if (!nodeSystem.directoryExists(directoryName)) {
                    // Wrapped in a try-catch to prevent crashing if we are in a race
                    // with another copy of ourselves to create the same directory
                    try {
                        _fs.mkdirSync(directoryName);
                    }
                    catch (e) {
                        if ((0, hostErrors_js_1.errorCode)(e) !== "EEXIST") {
                            // Failed for some other reason (access denied?); still throw
                            throw e;
                        }
                    }
                }
            },
            getExecutingFilePath() {
                return executingFilePath;
            },
            getCurrentDirectory,
            getDirectories,
            getEnvironmentVariable(name) {
                return process.env[name] || "";
            },
            readDirectory,
            getModifiedTime,
            setModifiedTime,
            deleteFile,
            createHash: createSHA256Hash,
            createSHA256Hash,
            getMemoryUsage() {
                if (global.gc) {
                    global.gc();
                }
                return process.memoryUsage().heapUsed;
            },
            getFileSize(path) {
                const stat = statSync(path);
                if (stat?.isFile()) {
                    return stat.size;
                }
                return 0;
            },
            exit(exitCode) {
                disableCPUProfiler(() => process.exit(exitCode));
            },
            enableCPUProfiler,
            disableCPUProfiler,
            cpuProfilingEnabled: () => !!activeSession || (0, ts_js_1.contains)(process.execArgv, "--cpu-prof") || (0, ts_js_1.contains)(process.execArgv, "--prof"),
            realpath,
            debugMode: !!process.env.NODE_INSPECTOR_IPC || !!process.env.VSCODE_INSPECTOR_OPTIONS || (0, ts_js_1.some)(process.execArgv, arg => /^--(?:inspect|debug)(?:-brk)?(?:=\d+)?$/i.test(arg)) || !!process.recordreplay,
            tryEnableSourceMapsForHost() {
                try {
                    require("source-map-support").install();
                }
                catch {
                    // Could not enable source maps.
                }
            },
            setTimeout: (callback, ms, label) => setTimeout(callback, ms, label),
            clearTimeout: (timeoutId) => { clearTimeout(timeoutId); },
            clearScreen: () => {
                process.stdout.write("\x1B[2J\x1B[3J\x1B[H");
            },
            setBlocking: () => {
                const handle = process.stdout?._handle;
                if (handle && handle.setBlocking) {
                    handle.setBlocking(true);
                }
            },
            base64decode: input => Buffer.from(input, "base64").toString("utf8"),
            base64encode: input => Buffer.from(input).toString("base64"),
            require: (baseDir, moduleName) => {
                try {
                    const modulePath = (0, ts_js_1.resolveJSModule)(moduleName, baseDir, nodeSystem);
                    return { module: require(modulePath), modulePath, error: undefined };
                }
                catch (error) {
                    return { module: undefined, modulePath: undefined, error };
                }
            },
        };
        return nodeSystem;
        /** Calls fs.statSync, returning undefined if any errors are thrown */
        function statSync(path) {
            // throwIfNoEntry is available in Node 14.17 and above, which matches our supported range.
            try {
                return _fs.statSync(path, statSyncOptions);
            }
            catch {
                // This should never happen as we are passing throwIfNoEntry: false,
                // but guard against this just in case (e.g. a polyfill doesn't check this flag).
                return undefined;
            }
        }
        /**
         * Uses the builtin inspector APIs to capture a CPU profile
         * See https://nodejs.org/api/inspector.html#inspector_example_usage for details
         */
        function enableCPUProfiler(path, cb) {
            if (activeSession) {
                cb();
                return false;
            }
            const inspector = require("inspector");
            if (!inspector || !inspector.Session) {
                cb();
                return false;
            }
            const session = new inspector.Session();
            session.connect();
            session.post("Profiler.enable", () => {
                session.post("Profiler.start", () => {
                    activeSession = session;
                    profilePath = path;
                    cb();
                });
            });
            return true;
        }
        /**
         * Strips non-TS paths from the profile, so users with private projects shouldn't
         * need to worry about leaking paths by submitting a cpu profile to us
         */
        function cleanupPaths(profile) {
            let externalFileCounter = 0;
            const remappedPaths = new Map();
            const normalizedDir = (0, ts_js_1.normalizeSlashes)(_path.dirname(executingFilePath));
            // Windows rooted dir names need an extra `/` prepended to be valid file:/// urls
            const fileUrlRoot = `file://${(0, ts_js_1.getRootLength)(normalizedDir) === 1 ? "" : "/"}${normalizedDir}`;
            for (const node of profile.nodes) {
                if (node.callFrame.url) {
                    const url = (0, ts_js_1.normalizeSlashes)(node.callFrame.url);
                    if ((0, ts_js_1.containsPath)(fileUrlRoot, url, useCaseSensitiveFileNames)) {
                        node.callFrame.url = (0, ts_js_1.getRelativePathToDirectoryOrUrl)(fileUrlRoot, url, fileUrlRoot, (0, ts_js_1.createGetCanonicalFileName)(useCaseSensitiveFileNames), /*isAbsolutePathAnUrl*/ true);
                    }
                    else if (!nativePattern.test(url)) {
                        node.callFrame.url = (remappedPaths.has(url) ? remappedPaths : remappedPaths.set(url, `external${externalFileCounter}.js`)).get(url);
                        externalFileCounter++;
                    }
                }
            }
            return profile;
        }
        function disableCPUProfiler(cb) {
            if (activeSession && activeSession !== "stopping") {
                const s = activeSession;
                activeSession.post("Profiler.stop", (err, { profile }) => {
                    if (!err) {
                        if (statSync(profilePath)?.isDirectory()) {
                            profilePath = _path.join(profilePath, `${(new Date()).toISOString().replace(/:/g, "-")}+P${process.pid}.cpuprofile`);
                        }
                        try {
                            _fs.mkdirSync(_path.dirname(profilePath), { recursive: true });
                        }
                        catch {
                            // do nothing and ignore fallible fs operation
                        }
                        _fs.writeFileSync(profilePath, JSON.stringify(cleanupPaths(profile)));
                    }
                    activeSession = undefined;
                    s.disconnect();
                    cb();
                });
                activeSession = "stopping";
                return true;
            }
            else {
                cb();
                return false;
            }
        }
        function isFileSystemCaseSensitive() {
            // win32\win64 are case insensitive platforms
            if (platform === "win32" || platform === "win64") {
                return false;
            }
            // If this file exists under a different case, we must be case-insensitve.
            return !fileExists(swapCase(__filename));
        }
        /** Convert all lowercase chars to uppercase, and vice-versa */
        function swapCase(s) {
            return s.replace(/\w/g, ch => {
                const up = ch.toUpperCase();
                return ch === up ? ch.toLowerCase() : up;
            });
        }
        function fsWatchFileWorker(fileName, callback, pollingInterval) {
            _fs.watchFile(fileName, { persistent: true, interval: pollingInterval }, fileChanged);
            let eventKind;
            return {
                close: () => _fs.unwatchFile(fileName, fileChanged),
            };
            function fileChanged(curr, prev) {
                // previous event kind check is to ensure we recongnize the file as previously also missing when it is restored or renamed twice (that is it disappears and reappears)
                // In such case, prevTime returned is same as prev time of event when file was deleted as per node documentation
                const isPreviouslyDeleted = +prev.mtime === 0 || eventKind === FileWatcherEventKind.Deleted;
                if (+curr.mtime === 0) {
                    if (isPreviouslyDeleted) {
                        // Already deleted file, no need to callback again
                        return;
                    }
                    eventKind = FileWatcherEventKind.Deleted;
                }
                else if (isPreviouslyDeleted) {
                    eventKind = FileWatcherEventKind.Created;
                }
                // If there is no change in modified time, ignore the event
                else if (+curr.mtime === +prev.mtime) {
                    return;
                }
                else {
                    // File changed
                    eventKind = FileWatcherEventKind.Changed;
                }
                callback(fileName, eventKind, curr.mtime);
            }
        }
        function fsWatchWorker(fileOrDirectory, recursive, callback) {
            // Node 4.0 `fs.watch` function supports the "recursive" option on both OSX and Windows
            // (ref: https://github.com/nodejs/node/pull/2649 and https://github.com/Microsoft/TypeScript/issues/4643)
            return _fs.watch(fileOrDirectory, fsSupportsRecursiveFsWatch ?
                { persistent: true, recursive: !!recursive } : { persistent: true }, callback);
        }
        function readFile(fileName, _encoding) {
            let buffer;
            try {
                buffer = _fs.readFileSync(fileName);
            }
            catch {
                return undefined;
            }
            let len = buffer.length;
            if (len >= 2 && buffer[0] === 0xFE && buffer[1] === 0xFF) {
                // Big endian UTF-16 byte order mark detected. Since big endian is not supported by node.js,
                // flip all byte pairs and treat as little endian.
                len &= ~1; // Round down to a multiple of 2
                for (let i = 0; i < len; i += 2) {
                    const temp = buffer[i];
                    buffer[i] = buffer[i + 1];
                    buffer[i + 1] = temp;
                }
                return buffer.toString("utf16le", 2);
            }
            if (len >= 2 && buffer[0] === 0xFF && buffer[1] === 0xFE) {
                // Little endian UTF-16 byte order mark detected
                return buffer.toString("utf16le", 2);
            }
            if (len >= 3 && buffer[0] === 0xEF && buffer[1] === 0xBB && buffer[2] === 0xBF) {
                // UTF-8 byte order mark detected
                return buffer.toString("utf8", 3);
            }
            // Default is UTF-8 with no byte order mark
            return buffer.toString("utf8");
        }
        function writeFile(fileName, data, writeByteOrderMark) {
            // If a BOM is required, emit one
            if (writeByteOrderMark) {
                data = byteOrderMarkIndicator + data;
            }
            let fd;
            try {
                fd = _fs.openSync(fileName, "w");
                _fs.writeSync(fd, data, /*position*/ undefined, "utf8");
            }
            finally {
                if (fd !== undefined) {
                    _fs.closeSync(fd);
                }
            }
        }
        function getAccessibleFileSystemEntries(path) {
            try {
                const entries = _fs.readdirSync(path || ".", { withFileTypes: true });
                const files = [];
                const directories = [];
                for (const dirent of entries) {
                    // withFileTypes is not supported before Node 10.10.
                    const entry = typeof dirent === "string" ? dirent : dirent.name;
                    // This is necessary because on some file system node fails to exclude
                    // "." and "..". See https://github.com/nodejs/node/issues/4002
                    if (entry === "." || entry === "..") {
                        continue;
                    }
                    let stat;
                    if (typeof dirent === "string" || dirent.isSymbolicLink()) {
                        const name = (0, ts_js_1.combinePaths)(path, entry);
                        stat = statSync(name);
                        if (!stat) {
                            continue;
                        }
                    }
                    else {
                        stat = dirent;
                    }
                    if (stat.isFile()) {
                        files.push(entry);
                    }
                    else if (stat.isDirectory()) {
                        directories.push(entry);
                    }
                }
                files.sort();
                directories.sort();
                return { files, directories };
            }
            catch {
                return ts_js_1.emptyFileSystemEntries;
            }
        }
        function readDirectory(path, extensions, excludes, includes, depth) {
            return (0, ts_js_1.matchFiles)(path, extensions, excludes, includes, useCaseSensitiveFileNames, process.cwd(), depth, getAccessibleFileSystemEntries, realpath);
        }
        function fileSystemEntryExists(path, entryKind) {
            const stat = statSync(path);
            if (!stat) {
                return false;
            }
            switch (entryKind) {
                case 0 /* FileSystemEntryKind.File */:
                    return stat.isFile();
                case 1 /* FileSystemEntryKind.Directory */:
                    return stat.isDirectory();
                default:
                    return false;
            }
        }
        function fileExists(path) {
            return fileSystemEntryExists(path, 0 /* FileSystemEntryKind.File */);
        }
        function directoryExists(path) {
            return fileSystemEntryExists(path, 1 /* FileSystemEntryKind.Directory */);
        }
        function getDirectories(path) {
            return getAccessibleFileSystemEntries(path).directories.slice();
        }
        function fsRealPathHandlingLongPath(path) {
            return path.length < 260 ? _fs.realpathSync.native(path) : _fs.realpathSync(path);
        }
        function realpath(path) {
            try {
                return fsRealpath(path);
            }
            catch {
                return path;
            }
        }
        function getModifiedTime(path) {
            return statSync(path)?.mtime;
        }
        function setModifiedTime(path, time) {
            try {
                _fs.utimesSync(path, time, time);
            }
            catch {
                return;
            }
        }
        function deleteFile(path) {
            try {
                return _fs.unlinkSync(path);
            }
            catch {
                return;
            }
        }
        function createSHA256Hash(data) {
            const hash = _crypto.createHash("sha256");
            hash.update(data);
            return hash.digest("hex");
        }
    }
    let sys;
    if ((0, ts_js_1.isNodeLikeSystem)()) {
        sys = getNodeSystem();
    }
    if (sys) {
        // patch writefile to create folder before writing the file
        patchWriteFileEnsuringDirectory(sys);
    }
    return sys;
})();
/** @internal @knipignore */
function setSys(s) {
    exports.sys = s;
}
if (exports.sys && exports.sys.getEnvironmentVariable) {
    setCustomPollingValues(exports.sys);
    ts_js_1.Debug.setAssertionLevel(/^development$/i.test(exports.sys.getEnvironmentVariable("NODE_ENV"))
        ? 1 /* AssertionLevel.Normal */
        : 0 /* AssertionLevel.None */);
}
if (exports.sys && exports.sys.debugMode) {
    ts_js_1.Debug.isDebugging = true;
}
