"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.timestamp = void 0;
exports.tryGetNativePerformanceHooks = tryGetNativePerformanceHooks;
const ts_js_1 = require("./_namespaces/ts.js");
const perfHooks = __importStar(require("node:perf_hooks"));
function tryGetPerformance() {
    if ((0, ts_js_1.isNodeLikeSystem)()) {
        try {
            // By default, only write native events when generating a cpu profile or using the v8 profiler.
            // Some environments may polyfill this module with an empty object; verify the object has the expected shape.
            const { performance } = perfHooks;
            if (performance) {
                return {
                    shouldWriteNativeEvents: false,
                    performance,
                };
            }
        }
        catch {
            // ignore errors
        }
    }
    if (typeof performance === "object") {
        // For now we always write native performance events when running in the browser. We may
        // make this conditional in the future if we find that native web performance hooks
        // in the browser also slow down compilation.
        return {
            shouldWriteNativeEvents: true,
            performance,
        };
    }
    return undefined;
}
function tryGetPerformanceHooks() {
    const p = tryGetPerformance();
    if (!p)
        return undefined;
    const { shouldWriteNativeEvents, performance } = p;
    const hooks = {
        shouldWriteNativeEvents,
        performance: undefined,
        performanceTime: undefined,
    };
    if (typeof performance.timeOrigin === "number" && typeof performance.now === "function") {
        hooks.performanceTime = performance;
    }
    if (hooks.performanceTime &&
        typeof performance.mark === "function" &&
        typeof performance.measure === "function" &&
        typeof performance.clearMarks === "function" &&
        typeof performance.clearMeasures === "function") {
        hooks.performance = performance;
    }
    return hooks;
}
const nativePerformanceHooks = tryGetPerformanceHooks();
const nativePerformanceTime = nativePerformanceHooks?.performanceTime;
/** @internal */
function tryGetNativePerformanceHooks() {
    return nativePerformanceHooks;
}
/**
 * Gets a timestamp with (at least) ms resolution
 *
 * @internal
 */
exports.timestamp = nativePerformanceTime ? () => nativePerformanceTime.now() : Date.now;
