"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canProduceDiagnostics = canProduceDiagnostics;
exports.createGetSymbolAccessibilityDiagnosticForNodeName = createGetSymbolAccessibilityDiagnosticForNodeName;
exports.createGetSymbolAccessibilityDiagnosticForNode = createGetSymbolAccessibilityDiagnosticForNode;
exports.createGetIsolatedDeclarationErrors = createGetIsolatedDeclarationErrors;
const ts_js_1 = require("../../_namespaces/ts.js");
/** @internal */
function canProduceDiagnostics(node) {
    return (0, ts_js_1.isVariableDeclaration)(node) ||
        (0, ts_js_1.isPropertyDeclaration)(node) ||
        (0, ts_js_1.isPropertySignature)(node) ||
        (0, ts_js_1.isBindingElement)(node) ||
        (0, ts_js_1.isSetAccessor)(node) ||
        (0, ts_js_1.isGetAccessor)(node) ||
        (0, ts_js_1.isConstructSignatureDeclaration)(node) ||
        (0, ts_js_1.isCallSignatureDeclaration)(node) ||
        (0, ts_js_1.isMethodDeclaration)(node) ||
        (0, ts_js_1.isMethodSignature)(node) ||
        (0, ts_js_1.isFunctionDeclaration)(node) ||
        (0, ts_js_1.isParameter)(node) ||
        (0, ts_js_1.isTypeParameterDeclaration)(node) ||
        (0, ts_js_1.isExpressionWithTypeArguments)(node) ||
        (0, ts_js_1.isImportEqualsDeclaration)(node) ||
        (0, ts_js_1.isTypeAliasDeclaration)(node) ||
        (0, ts_js_1.isConstructorDeclaration)(node) ||
        (0, ts_js_1.isIndexSignatureDeclaration)(node) ||
        (0, ts_js_1.isPropertyAccessExpression)(node) ||
        (0, ts_js_1.isElementAccessExpression)(node) ||
        (0, ts_js_1.isBinaryExpression)(node) ||
        (0, ts_js_1.isJSDocTypeAlias)(node);
}
/** @internal */
function createGetSymbolAccessibilityDiagnosticForNodeName(node) {
    if ((0, ts_js_1.isSetAccessor)(node) || (0, ts_js_1.isGetAccessor)(node)) {
        return getAccessorNameVisibilityError;
    }
    else if ((0, ts_js_1.isMethodSignature)(node) || (0, ts_js_1.isMethodDeclaration)(node)) {
        return getMethodNameVisibilityError;
    }
    else {
        return createGetSymbolAccessibilityDiagnosticForNode(node);
    }
    function getAccessorNameVisibilityError(symbolAccessibilityResult) {
        const diagnosticMessage = getAccessorNameVisibilityDiagnosticMessage(symbolAccessibilityResult);
        return diagnosticMessage !== undefined ? {
            diagnosticMessage,
            errorNode: node,
            typeName: node.name,
        } : undefined;
    }
    function getAccessorNameVisibilityDiagnosticMessage(symbolAccessibilityResult) {
        if ((0, ts_js_1.isStatic)(node)) {
            return symbolAccessibilityResult.errorModuleName ?
                symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                    ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                    ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_private_name_1;
        }
        else if (node.parent.kind === 264 /* SyntaxKind.ClassDeclaration */) {
            return symbolAccessibilityResult.errorModuleName ?
                symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                    ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                    ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_private_name_1;
        }
        else {
            return symbolAccessibilityResult.errorModuleName ?
                ts_js_1.Diagnostics.Property_0_of_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Property_0_of_exported_interface_has_or_is_using_private_name_1;
        }
    }
    function getMethodNameVisibilityError(symbolAccessibilityResult) {
        const diagnosticMessage = getMethodNameVisibilityDiagnosticMessage(symbolAccessibilityResult);
        return diagnosticMessage !== undefined ? {
            diagnosticMessage,
            errorNode: node,
            typeName: node.name,
        } : undefined;
    }
    function getMethodNameVisibilityDiagnosticMessage(symbolAccessibilityResult) {
        if ((0, ts_js_1.isStatic)(node)) {
            return symbolAccessibilityResult.errorModuleName ?
                symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                    ts_js_1.Diagnostics.Public_static_method_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                    ts_js_1.Diagnostics.Public_static_method_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Public_static_method_0_of_exported_class_has_or_is_using_private_name_1;
        }
        else if (node.parent.kind === 264 /* SyntaxKind.ClassDeclaration */) {
            return symbolAccessibilityResult.errorModuleName ?
                symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                    ts_js_1.Diagnostics.Public_method_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                    ts_js_1.Diagnostics.Public_method_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Public_method_0_of_exported_class_has_or_is_using_private_name_1;
        }
        else {
            return symbolAccessibilityResult.errorModuleName ?
                ts_js_1.Diagnostics.Method_0_of_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Method_0_of_exported_interface_has_or_is_using_private_name_1;
        }
    }
}
/** @internal */
function createGetSymbolAccessibilityDiagnosticForNode(node) {
    if ((0, ts_js_1.isVariableDeclaration)(node) || (0, ts_js_1.isPropertyDeclaration)(node) || (0, ts_js_1.isPropertySignature)(node) || (0, ts_js_1.isPropertyAccessExpression)(node) || (0, ts_js_1.isElementAccessExpression)(node) || (0, ts_js_1.isBinaryExpression)(node) || (0, ts_js_1.isBindingElement)(node) || (0, ts_js_1.isConstructorDeclaration)(node)) {
        return getVariableDeclarationTypeVisibilityError;
    }
    else if ((0, ts_js_1.isSetAccessor)(node) || (0, ts_js_1.isGetAccessor)(node)) {
        return getAccessorDeclarationTypeVisibilityError;
    }
    else if ((0, ts_js_1.isConstructSignatureDeclaration)(node) || (0, ts_js_1.isCallSignatureDeclaration)(node) || (0, ts_js_1.isMethodDeclaration)(node) || (0, ts_js_1.isMethodSignature)(node) || (0, ts_js_1.isFunctionDeclaration)(node) || (0, ts_js_1.isIndexSignatureDeclaration)(node)) {
        return getReturnTypeVisibilityError;
    }
    else if ((0, ts_js_1.isParameter)(node)) {
        if ((0, ts_js_1.isParameterPropertyDeclaration)(node, node.parent) && (0, ts_js_1.hasSyntacticModifier)(node.parent, 2 /* ModifierFlags.Private */)) {
            return getVariableDeclarationTypeVisibilityError;
        }
        return getParameterDeclarationTypeVisibilityError;
    }
    else if ((0, ts_js_1.isTypeParameterDeclaration)(node)) {
        return getTypeParameterConstraintVisibilityError;
    }
    else if ((0, ts_js_1.isExpressionWithTypeArguments)(node)) {
        return getHeritageClauseVisibilityError;
    }
    else if ((0, ts_js_1.isImportEqualsDeclaration)(node)) {
        return getImportEntityNameVisibilityError;
    }
    else if ((0, ts_js_1.isTypeAliasDeclaration)(node) || (0, ts_js_1.isJSDocTypeAlias)(node)) {
        return getTypeAliasDeclarationVisibilityError;
    }
    else {
        return ts_js_1.Debug.assertNever(node, `Attempted to set a declaration diagnostic context for unhandled node kind: ${ts_js_1.Debug.formatSyntaxKind(node.kind)}`);
    }
    function getVariableDeclarationTypeVisibilityDiagnosticMessage(symbolAccessibilityResult) {
        if (node.kind === 261 /* SyntaxKind.VariableDeclaration */ || node.kind === 209 /* SyntaxKind.BindingElement */) {
            return symbolAccessibilityResult.errorModuleName ?
                symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                    ts_js_1.Diagnostics.Exported_variable_0_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                    ts_js_1.Diagnostics.Exported_variable_0_has_or_is_using_name_1_from_private_module_2 :
                ts_js_1.Diagnostics.Exported_variable_0_has_or_is_using_private_name_1;
        }
        // This check is to ensure we don't report error on constructor parameter property as that error would be reported during parameter emit
        // The only exception here is if the constructor was marked as private. we are not emitting the constructor parameters at all.
        else if (node.kind === 173 /* SyntaxKind.PropertyDeclaration */ || node.kind === 212 /* SyntaxKind.PropertyAccessExpression */ || node.kind === 213 /* SyntaxKind.ElementAccessExpression */ || node.kind === 227 /* SyntaxKind.BinaryExpression */ || node.kind === 172 /* SyntaxKind.PropertySignature */ ||
            (node.kind === 170 /* SyntaxKind.Parameter */ && (0, ts_js_1.hasSyntacticModifier)(node.parent, 2 /* ModifierFlags.Private */))) {
            // TODO(jfreeman): Deal with computed properties in error reporting.
            if ((0, ts_js_1.isStatic)(node)) {
                return symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Public_static_property_0_of_exported_class_has_or_is_using_private_name_1;
            }
            else if (node.parent.kind === 264 /* SyntaxKind.ClassDeclaration */ || node.kind === 170 /* SyntaxKind.Parameter */) {
                return symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Public_property_0_of_exported_class_has_or_is_using_private_name_1;
            }
            else {
                // Interfaces cannot have types that cannot be named
                return symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Property_0_of_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Property_0_of_exported_interface_has_or_is_using_private_name_1;
            }
        }
    }
    function getVariableDeclarationTypeVisibilityError(symbolAccessibilityResult) {
        const diagnosticMessage = getVariableDeclarationTypeVisibilityDiagnosticMessage(symbolAccessibilityResult);
        return diagnosticMessage !== undefined ? {
            diagnosticMessage,
            errorNode: node,
            typeName: node.name,
        } : undefined;
    }
    function getAccessorDeclarationTypeVisibilityError(symbolAccessibilityResult) {
        let diagnosticMessage;
        if (node.kind === 179 /* SyntaxKind.SetAccessor */) {
            // Getters can infer the return type from the returned expression, but setters cannot, so the
            // "_from_external_module_1_but_cannot_be_named" case cannot occur.
            if ((0, ts_js_1.isStatic)(node)) {
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Parameter_type_of_public_static_setter_0_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_type_of_public_static_setter_0_from_exported_class_has_or_is_using_private_name_1;
            }
            else {
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Parameter_type_of_public_setter_0_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_type_of_public_setter_0_from_exported_class_has_or_is_using_private_name_1;
            }
        }
        else {
            if ((0, ts_js_1.isStatic)(node)) {
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Return_type_of_public_static_getter_0_from_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Return_type_of_public_static_getter_0_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Return_type_of_public_static_getter_0_from_exported_class_has_or_is_using_private_name_1;
            }
            else {
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Return_type_of_public_getter_0_from_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Return_type_of_public_getter_0_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Return_type_of_public_getter_0_from_exported_class_has_or_is_using_private_name_1;
            }
        }
        return {
            diagnosticMessage,
            errorNode: node.name,
            typeName: node.name,
        };
    }
    function getReturnTypeVisibilityError(symbolAccessibilityResult) {
        let diagnosticMessage;
        switch (node.kind) {
            case 181 /* SyntaxKind.ConstructSignature */:
                // Interfaces cannot have return types that cannot be named
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Return_type_of_constructor_signature_from_exported_interface_has_or_is_using_name_0_from_private_module_1 :
                    ts_js_1.Diagnostics.Return_type_of_constructor_signature_from_exported_interface_has_or_is_using_private_name_0;
                break;
            case 180 /* SyntaxKind.CallSignature */:
                // Interfaces cannot have return types that cannot be named
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Return_type_of_call_signature_from_exported_interface_has_or_is_using_name_0_from_private_module_1 :
                    ts_js_1.Diagnostics.Return_type_of_call_signature_from_exported_interface_has_or_is_using_private_name_0;
                break;
            case 182 /* SyntaxKind.IndexSignature */:
                // Interfaces cannot have return types that cannot be named
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Return_type_of_index_signature_from_exported_interface_has_or_is_using_name_0_from_private_module_1 :
                    ts_js_1.Diagnostics.Return_type_of_index_signature_from_exported_interface_has_or_is_using_private_name_0;
                break;
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 174 /* SyntaxKind.MethodSignature */:
                if ((0, ts_js_1.isStatic)(node)) {
                    diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                        symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                            ts_js_1.Diagnostics.Return_type_of_public_static_method_from_exported_class_has_or_is_using_name_0_from_external_module_1_but_cannot_be_named :
                            ts_js_1.Diagnostics.Return_type_of_public_static_method_from_exported_class_has_or_is_using_name_0_from_private_module_1 :
                        ts_js_1.Diagnostics.Return_type_of_public_static_method_from_exported_class_has_or_is_using_private_name_0;
                }
                else if (node.parent.kind === 264 /* SyntaxKind.ClassDeclaration */) {
                    diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                        symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                            ts_js_1.Diagnostics.Return_type_of_public_method_from_exported_class_has_or_is_using_name_0_from_external_module_1_but_cannot_be_named :
                            ts_js_1.Diagnostics.Return_type_of_public_method_from_exported_class_has_or_is_using_name_0_from_private_module_1 :
                        ts_js_1.Diagnostics.Return_type_of_public_method_from_exported_class_has_or_is_using_private_name_0;
                }
                else {
                    // Interfaces cannot have return types that cannot be named
                    diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                        ts_js_1.Diagnostics.Return_type_of_method_from_exported_interface_has_or_is_using_name_0_from_private_module_1 :
                        ts_js_1.Diagnostics.Return_type_of_method_from_exported_interface_has_or_is_using_private_name_0;
                }
                break;
            case 263 /* SyntaxKind.FunctionDeclaration */:
                diagnosticMessage = symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Return_type_of_exported_function_has_or_is_using_name_0_from_external_module_1_but_cannot_be_named :
                        ts_js_1.Diagnostics.Return_type_of_exported_function_has_or_is_using_name_0_from_private_module_1 :
                    ts_js_1.Diagnostics.Return_type_of_exported_function_has_or_is_using_private_name_0;
                break;
            default:
                return ts_js_1.Debug.fail("This is unknown kind for signature: " + node.kind);
        }
        return {
            diagnosticMessage,
            errorNode: node.name || node,
        };
    }
    function getParameterDeclarationTypeVisibilityError(symbolAccessibilityResult) {
        const diagnosticMessage = getParameterDeclarationTypeVisibilityDiagnosticMessage(symbolAccessibilityResult);
        return diagnosticMessage !== undefined ? {
            diagnosticMessage,
            errorNode: node,
            typeName: node.name,
        } : undefined;
    }
    function getParameterDeclarationTypeVisibilityDiagnosticMessage(symbolAccessibilityResult) {
        switch (node.parent.kind) {
            case 177 /* SyntaxKind.Constructor */:
                return symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Parameter_0_of_constructor_from_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Parameter_0_of_constructor_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_constructor_from_exported_class_has_or_is_using_private_name_1;
            case 181 /* SyntaxKind.ConstructSignature */:
            case 186 /* SyntaxKind.ConstructorType */:
                // Interfaces cannot have parameter types that cannot be named
                return symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Parameter_0_of_constructor_signature_from_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_constructor_signature_from_exported_interface_has_or_is_using_private_name_1;
            case 180 /* SyntaxKind.CallSignature */:
                // Interfaces cannot have parameter types that cannot be named
                return symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Parameter_0_of_call_signature_from_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_call_signature_from_exported_interface_has_or_is_using_private_name_1;
            case 182 /* SyntaxKind.IndexSignature */:
                // Interfaces cannot have parameter types that cannot be named
                return symbolAccessibilityResult.errorModuleName ?
                    ts_js_1.Diagnostics.Parameter_0_of_index_signature_from_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_index_signature_from_exported_interface_has_or_is_using_private_name_1;
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 174 /* SyntaxKind.MethodSignature */:
                if ((0, ts_js_1.isStatic)(node.parent)) {
                    return symbolAccessibilityResult.errorModuleName ?
                        symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                            ts_js_1.Diagnostics.Parameter_0_of_public_static_method_from_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                            ts_js_1.Diagnostics.Parameter_0_of_public_static_method_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                        ts_js_1.Diagnostics.Parameter_0_of_public_static_method_from_exported_class_has_or_is_using_private_name_1;
                }
                else if (node.parent.parent.kind === 264 /* SyntaxKind.ClassDeclaration */) {
                    return symbolAccessibilityResult.errorModuleName ?
                        symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                            ts_js_1.Diagnostics.Parameter_0_of_public_method_from_exported_class_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                            ts_js_1.Diagnostics.Parameter_0_of_public_method_from_exported_class_has_or_is_using_name_1_from_private_module_2 :
                        ts_js_1.Diagnostics.Parameter_0_of_public_method_from_exported_class_has_or_is_using_private_name_1;
                }
                else {
                    // Interfaces cannot have parameter types that cannot be named
                    return symbolAccessibilityResult.errorModuleName ?
                        ts_js_1.Diagnostics.Parameter_0_of_method_from_exported_interface_has_or_is_using_name_1_from_private_module_2 :
                        ts_js_1.Diagnostics.Parameter_0_of_method_from_exported_interface_has_or_is_using_private_name_1;
                }
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 185 /* SyntaxKind.FunctionType */:
                return symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Parameter_0_of_exported_function_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Parameter_0_of_exported_function_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_exported_function_has_or_is_using_private_name_1;
            case 179 /* SyntaxKind.SetAccessor */:
            case 178 /* SyntaxKind.GetAccessor */:
                return symbolAccessibilityResult.errorModuleName ?
                    symbolAccessibilityResult.accessibility === 2 /* SymbolAccessibility.CannotBeNamed */ ?
                        ts_js_1.Diagnostics.Parameter_0_of_accessor_has_or_is_using_name_1_from_external_module_2_but_cannot_be_named :
                        ts_js_1.Diagnostics.Parameter_0_of_accessor_has_or_is_using_name_1_from_private_module_2 :
                    ts_js_1.Diagnostics.Parameter_0_of_accessor_has_or_is_using_private_name_1;
            default:
                return ts_js_1.Debug.fail(`Unknown parent for parameter: ${ts_js_1.Debug.formatSyntaxKind(node.parent.kind)}`);
        }
    }
    function getTypeParameterConstraintVisibilityError() {
        // Type parameter constraints are named by user so we should always be able to name it
        let diagnosticMessage;
        switch (node.parent.kind) {
            case 264 /* SyntaxKind.ClassDeclaration */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_exported_class_has_or_is_using_private_name_1;
                break;
            case 265 /* SyntaxKind.InterfaceDeclaration */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_exported_interface_has_or_is_using_private_name_1;
                break;
            case 201 /* SyntaxKind.MappedType */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_exported_mapped_object_type_is_using_private_name_1;
                break;
            case 186 /* SyntaxKind.ConstructorType */:
            case 181 /* SyntaxKind.ConstructSignature */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_constructor_signature_from_exported_interface_has_or_is_using_private_name_1;
                break;
            case 180 /* SyntaxKind.CallSignature */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_call_signature_from_exported_interface_has_or_is_using_private_name_1;
                break;
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 174 /* SyntaxKind.MethodSignature */:
                if ((0, ts_js_1.isStatic)(node.parent)) {
                    diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_public_static_method_from_exported_class_has_or_is_using_private_name_1;
                }
                else if (node.parent.parent.kind === 264 /* SyntaxKind.ClassDeclaration */) {
                    diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_public_method_from_exported_class_has_or_is_using_private_name_1;
                }
                else {
                    diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_method_from_exported_interface_has_or_is_using_private_name_1;
                }
                break;
            case 185 /* SyntaxKind.FunctionType */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_exported_function_has_or_is_using_private_name_1;
                break;
            case 196 /* SyntaxKind.InferType */:
                diagnosticMessage = ts_js_1.Diagnostics.Extends_clause_for_inferred_type_0_has_or_is_using_private_name_1;
                break;
            case 266 /* SyntaxKind.TypeAliasDeclaration */:
                diagnosticMessage = ts_js_1.Diagnostics.Type_parameter_0_of_exported_type_alias_has_or_is_using_private_name_1;
                break;
            default:
                return ts_js_1.Debug.fail("This is unknown parent for type parameter: " + node.parent.kind);
        }
        return {
            diagnosticMessage,
            errorNode: node,
            typeName: node.name,
        };
    }
    function getHeritageClauseVisibilityError() {
        let diagnosticMessage;
        // Heritage clause is written by user so it can always be named
        if ((0, ts_js_1.isClassDeclaration)(node.parent.parent)) {
            // Class or Interface implemented/extended is inaccessible
            diagnosticMessage = (0, ts_js_1.isHeritageClause)(node.parent) && node.parent.token === 119 /* SyntaxKind.ImplementsKeyword */ ?
                ts_js_1.Diagnostics.Implements_clause_of_exported_class_0_has_or_is_using_private_name_1 :
                node.parent.parent.name ? ts_js_1.Diagnostics.extends_clause_of_exported_class_0_has_or_is_using_private_name_1 :
                    ts_js_1.Diagnostics.extends_clause_of_exported_class_has_or_is_using_private_name_0;
        }
        else {
            // interface is inaccessible
            diagnosticMessage = ts_js_1.Diagnostics.extends_clause_of_exported_interface_0_has_or_is_using_private_name_1;
        }
        return {
            diagnosticMessage,
            errorNode: node,
            typeName: (0, ts_js_1.getNameOfDeclaration)(node.parent.parent),
        };
    }
    function getImportEntityNameVisibilityError() {
        return {
            diagnosticMessage: ts_js_1.Diagnostics.Import_declaration_0_is_using_private_name_1,
            errorNode: node,
            typeName: node.name,
        };
    }
    function getTypeAliasDeclarationVisibilityError(symbolAccessibilityResult) {
        return {
            diagnosticMessage: symbolAccessibilityResult.errorModuleName
                ? ts_js_1.Diagnostics.Exported_type_alias_0_has_or_is_using_private_name_1_from_module_2
                : ts_js_1.Diagnostics.Exported_type_alias_0_has_or_is_using_private_name_1,
            errorNode: (0, ts_js_1.isJSDocTypeAlias)(node) ? ts_js_1.Debug.checkDefined(node.typeExpression) : node.type,
            typeName: (0, ts_js_1.isJSDocTypeAlias)(node) ? (0, ts_js_1.getNameOfDeclaration)(node) : node.name,
        };
    }
}
/** @internal */
function createGetIsolatedDeclarationErrors(resolver) {
    const relatedSuggestionByDeclarationKind = {
        [220 /* SyntaxKind.ArrowFunction */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_function_expression,
        [219 /* SyntaxKind.FunctionExpression */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_function_expression,
        [175 /* SyntaxKind.MethodDeclaration */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_method,
        [178 /* SyntaxKind.GetAccessor */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_get_accessor_declaration,
        [179 /* SyntaxKind.SetAccessor */]: ts_js_1.Diagnostics.Add_a_type_to_parameter_of_the_set_accessor_declaration,
        [263 /* SyntaxKind.FunctionDeclaration */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_function_declaration,
        [181 /* SyntaxKind.ConstructSignature */]: ts_js_1.Diagnostics.Add_a_return_type_to_the_function_declaration,
        [170 /* SyntaxKind.Parameter */]: ts_js_1.Diagnostics.Add_a_type_annotation_to_the_parameter_0,
        [261 /* SyntaxKind.VariableDeclaration */]: ts_js_1.Diagnostics.Add_a_type_annotation_to_the_variable_0,
        [173 /* SyntaxKind.PropertyDeclaration */]: ts_js_1.Diagnostics.Add_a_type_annotation_to_the_property_0,
        [172 /* SyntaxKind.PropertySignature */]: ts_js_1.Diagnostics.Add_a_type_annotation_to_the_property_0,
        [278 /* SyntaxKind.ExportAssignment */]: ts_js_1.Diagnostics.Move_the_expression_in_default_export_to_a_variable_and_add_a_type_annotation_to_it,
    };
    const errorByDeclarationKind = {
        [219 /* SyntaxKind.FunctionExpression */]: ts_js_1.Diagnostics.Function_must_have_an_explicit_return_type_annotation_with_isolatedDeclarations,
        [263 /* SyntaxKind.FunctionDeclaration */]: ts_js_1.Diagnostics.Function_must_have_an_explicit_return_type_annotation_with_isolatedDeclarations,
        [220 /* SyntaxKind.ArrowFunction */]: ts_js_1.Diagnostics.Function_must_have_an_explicit_return_type_annotation_with_isolatedDeclarations,
        [175 /* SyntaxKind.MethodDeclaration */]: ts_js_1.Diagnostics.Method_must_have_an_explicit_return_type_annotation_with_isolatedDeclarations,
        [181 /* SyntaxKind.ConstructSignature */]: ts_js_1.Diagnostics.Method_must_have_an_explicit_return_type_annotation_with_isolatedDeclarations,
        [178 /* SyntaxKind.GetAccessor */]: ts_js_1.Diagnostics.At_least_one_accessor_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [179 /* SyntaxKind.SetAccessor */]: ts_js_1.Diagnostics.At_least_one_accessor_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [170 /* SyntaxKind.Parameter */]: ts_js_1.Diagnostics.Parameter_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [261 /* SyntaxKind.VariableDeclaration */]: ts_js_1.Diagnostics.Variable_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [173 /* SyntaxKind.PropertyDeclaration */]: ts_js_1.Diagnostics.Property_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [172 /* SyntaxKind.PropertySignature */]: ts_js_1.Diagnostics.Property_must_have_an_explicit_type_annotation_with_isolatedDeclarations,
        [168 /* SyntaxKind.ComputedPropertyName */]: ts_js_1.Diagnostics.Computed_property_names_on_class_or_object_literals_cannot_be_inferred_with_isolatedDeclarations,
        [306 /* SyntaxKind.SpreadAssignment */]: ts_js_1.Diagnostics.Objects_that_contain_spread_assignments_can_t_be_inferred_with_isolatedDeclarations,
        [305 /* SyntaxKind.ShorthandPropertyAssignment */]: ts_js_1.Diagnostics.Objects_that_contain_shorthand_properties_can_t_be_inferred_with_isolatedDeclarations,
        [210 /* SyntaxKind.ArrayLiteralExpression */]: ts_js_1.Diagnostics.Only_const_arrays_can_be_inferred_with_isolatedDeclarations,
        [278 /* SyntaxKind.ExportAssignment */]: ts_js_1.Diagnostics.Default_exports_can_t_be_inferred_with_isolatedDeclarations,
        [231 /* SyntaxKind.SpreadElement */]: ts_js_1.Diagnostics.Arrays_with_spread_elements_can_t_inferred_with_isolatedDeclarations,
    };
    return getDiagnostic;
    function getDiagnostic(node) {
        const heritageClause = (0, ts_js_1.findAncestor)(node, ts_js_1.isHeritageClause);
        if (heritageClause) {
            return (0, ts_js_1.createDiagnosticForNode)(node, ts_js_1.Diagnostics.Extends_clause_can_t_contain_an_expression_with_isolatedDeclarations);
        }
        if (((0, ts_js_1.isPartOfTypeNode)(node) || (0, ts_js_1.isTypeQueryNode)(node.parent)) && ((0, ts_js_1.isEntityName)(node) || (0, ts_js_1.isEntityNameExpression)(node))) {
            return createEntityInTypeNodeError(node);
        }
        switch (node.kind) {
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
                ts_js_1.Debug.assert((0, ts_js_1.isGetAccessor)(node) || (0, ts_js_1.isSetAccessor)(node));
                return createAccessorTypeError(node);
            case 168 /* SyntaxKind.ComputedPropertyName */:
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            case 306 /* SyntaxKind.SpreadAssignment */:
                ts_js_1.Debug.assert((0, ts_js_1.isComputedPropertyName)(node) || (0, ts_js_1.isShorthandPropertyAssignment)(node) || (0, ts_js_1.isSpreadAssignment)(node));
                return createObjectLiteralError(node);
            case 210 /* SyntaxKind.ArrayLiteralExpression */:
            case 231 /* SyntaxKind.SpreadElement */:
                ts_js_1.Debug.assert((0, ts_js_1.isArrayLiteralExpression)(node) || (0, ts_js_1.isSpreadElement)(node));
                return createArrayLiteralError(node);
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 181 /* SyntaxKind.ConstructSignature */:
            case 219 /* SyntaxKind.FunctionExpression */:
            case 220 /* SyntaxKind.ArrowFunction */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
                ts_js_1.Debug.assert((0, ts_js_1.isMethodDeclaration)(node) || (0, ts_js_1.isConstructSignatureDeclaration)(node) || (0, ts_js_1.isFunctionExpression)(node) || (0, ts_js_1.isArrowFunction)(node) || (0, ts_js_1.isFunctionDeclaration)(node));
                return createReturnTypeError(node);
            case 209 /* SyntaxKind.BindingElement */:
                ts_js_1.Debug.assert((0, ts_js_1.isBindingElement)(node));
                return createBindingElementError(node);
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 261 /* SyntaxKind.VariableDeclaration */:
                ts_js_1.Debug.assert((0, ts_js_1.isPropertyDeclaration)(node) || (0, ts_js_1.isVariableDeclaration)(node));
                return createVariableOrPropertyError(node);
            case 170 /* SyntaxKind.Parameter */:
                ts_js_1.Debug.assert((0, ts_js_1.isParameter)(node));
                return createParameterError(node);
            case 304 /* SyntaxKind.PropertyAssignment */:
                ts_js_1.Debug.assert((0, ts_js_1.isPropertyAssignment)(node));
                return createExpressionError(node.initializer);
            case 232 /* SyntaxKind.ClassExpression */:
                ts_js_1.Debug.assert((0, ts_js_1.isClassExpression)(node));
                return createClassExpressionError(node);
            default:
                (0, ts_js_1.assertType)(node.kind);
                return createExpressionError(node);
        }
    }
    function findNearestDeclaration(node) {
        const result = (0, ts_js_1.findAncestor)(node, n => (0, ts_js_1.isExportAssignment)(n) || (0, ts_js_1.isStatement)(n) || (0, ts_js_1.isVariableDeclaration)(n) || (0, ts_js_1.isPropertyDeclaration)(n) || (0, ts_js_1.isParameter)(n));
        if (!result)
            return undefined;
        if ((0, ts_js_1.isExportAssignment)(result))
            return result;
        if ((0, ts_js_1.isReturnStatement)(result)) {
            return (0, ts_js_1.findAncestor)(result, (n) => (0, ts_js_1.isFunctionLikeDeclaration)(n) && !(0, ts_js_1.isConstructorDeclaration)(n));
        }
        return ((0, ts_js_1.isStatement)(result) ? undefined : result);
    }
    function createAccessorTypeError(node) {
        const { getAccessor, setAccessor } = (0, ts_js_1.getAllAccessorDeclarations)(node.symbol.declarations, node);
        const targetNode = ((0, ts_js_1.isSetAccessor)(node) ? node.parameters[0] : node) ?? node;
        const diag = (0, ts_js_1.createDiagnosticForNode)(targetNode, errorByDeclarationKind[node.kind]);
        if (setAccessor) {
            (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(setAccessor, relatedSuggestionByDeclarationKind[setAccessor.kind]));
        }
        if (getAccessor) {
            (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(getAccessor, relatedSuggestionByDeclarationKind[getAccessor.kind]));
        }
        return diag;
    }
    function addParentDeclarationRelatedInfo(node, diag) {
        const parentDeclaration = findNearestDeclaration(node);
        if (parentDeclaration) {
            const targetStr = (0, ts_js_1.isExportAssignment)(parentDeclaration) || !parentDeclaration.name ? "" : (0, ts_js_1.getTextOfNode)(parentDeclaration.name, /*includeTrivia*/ false);
            (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(parentDeclaration, relatedSuggestionByDeclarationKind[parentDeclaration.kind], targetStr));
        }
        return diag;
    }
    function createObjectLiteralError(node) {
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, errorByDeclarationKind[node.kind]);
        addParentDeclarationRelatedInfo(node, diag);
        return diag;
    }
    function createArrayLiteralError(node) {
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, errorByDeclarationKind[node.kind]);
        addParentDeclarationRelatedInfo(node, diag);
        return diag;
    }
    function createReturnTypeError(node) {
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, errorByDeclarationKind[node.kind]);
        addParentDeclarationRelatedInfo(node, diag);
        (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(node, relatedSuggestionByDeclarationKind[node.kind]));
        return diag;
    }
    function createBindingElementError(node) {
        return (0, ts_js_1.createDiagnosticForNode)(node, ts_js_1.Diagnostics.Binding_elements_can_t_be_exported_directly_with_isolatedDeclarations);
    }
    function createVariableOrPropertyError(node) {
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, errorByDeclarationKind[node.kind]);
        const targetStr = (0, ts_js_1.getTextOfNode)(node.name, /*includeTrivia*/ false);
        (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(node, relatedSuggestionByDeclarationKind[node.kind], targetStr));
        return diag;
    }
    function createParameterError(node) {
        if ((0, ts_js_1.isSetAccessor)(node.parent)) {
            return createAccessorTypeError(node.parent);
        }
        const addUndefined = resolver.requiresAddingImplicitUndefined(node, node.parent);
        if (!addUndefined && node.initializer) {
            return createExpressionError(node.initializer);
        }
        const message = addUndefined ?
            ts_js_1.Diagnostics.Declaration_emit_for_this_parameter_requires_implicitly_adding_undefined_to_its_type_This_is_not_supported_with_isolatedDeclarations :
            errorByDeclarationKind[node.kind];
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, message);
        const targetStr = (0, ts_js_1.getTextOfNode)(node.name, /*includeTrivia*/ false);
        (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(node, relatedSuggestionByDeclarationKind[node.kind], targetStr));
        return diag;
    }
    function createClassExpressionError(node) {
        return createExpressionError(node, ts_js_1.Diagnostics.Inference_from_class_expressions_is_not_supported_with_isolatedDeclarations);
    }
    function createEntityInTypeNodeError(node) {
        const diag = (0, ts_js_1.createDiagnosticForNode)(node, ts_js_1.Diagnostics.Type_containing_private_name_0_can_t_be_used_with_isolatedDeclarations, (0, ts_js_1.getTextOfNode)(node, /*includeTrivia*/ false));
        addParentDeclarationRelatedInfo(node, diag);
        return diag;
    }
    function createExpressionError(node, diagnosticMessage) {
        const parentDeclaration = findNearestDeclaration(node);
        let diag;
        if (parentDeclaration) {
            const targetStr = (0, ts_js_1.isExportAssignment)(parentDeclaration) || !parentDeclaration.name ? "" : (0, ts_js_1.getTextOfNode)(parentDeclaration.name, /*includeTrivia*/ false);
            const parent = (0, ts_js_1.findAncestor)(node.parent, n => (0, ts_js_1.isExportAssignment)(n) || ((0, ts_js_1.isStatement)(n) ? "quit" : !(0, ts_js_1.isParenthesizedExpression)(n) && !(0, ts_js_1.isTypeAssertionExpression)(n) && !(0, ts_js_1.isAsExpression)(n)));
            if (parentDeclaration === parent) {
                diag = (0, ts_js_1.createDiagnosticForNode)(node, diagnosticMessage ?? errorByDeclarationKind[parentDeclaration.kind]);
                (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(parentDeclaration, relatedSuggestionByDeclarationKind[parentDeclaration.kind], targetStr));
            }
            else {
                diag = (0, ts_js_1.createDiagnosticForNode)(node, diagnosticMessage ?? ts_js_1.Diagnostics.Expression_type_can_t_be_inferred_with_isolatedDeclarations);
                (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(parentDeclaration, relatedSuggestionByDeclarationKind[parentDeclaration.kind], targetStr));
                (0, ts_js_1.addRelatedInfo)(diag, (0, ts_js_1.createDiagnosticForNode)(node, ts_js_1.Diagnostics.Add_satisfies_and_a_type_assertion_to_this_expression_satisfies_T_as_T_to_make_the_type_explicit));
            }
        }
        else {
            diag = (0, ts_js_1.createDiagnosticForNode)(node, diagnosticMessage ?? ts_js_1.Diagnostics.Expression_type_can_t_be_inferred_with_isolatedDeclarations);
        }
        return diag;
    }
}
