"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformImpliedNodeFormatDependentModule = transformImpliedNodeFormatDependentModule;
const ts_js_1 = require("../../_namespaces/ts.js");
/** @internal */
function transformImpliedNodeFormatDependentModule(context) {
    const previousOnSubstituteNode = context.onSubstituteNode;
    const previousOnEmitNode = context.onEmitNode;
    const esmTransform = (0, ts_js_1.transformECMAScriptModule)(context);
    const esmOnSubstituteNode = context.onSubstituteNode;
    const esmOnEmitNode = context.onEmitNode;
    context.onSubstituteNode = previousOnSubstituteNode;
    context.onEmitNode = previousOnEmitNode;
    const cjsTransform = (0, ts_js_1.transformModule)(context);
    const cjsOnSubstituteNode = context.onSubstituteNode;
    const cjsOnEmitNode = context.onEmitNode;
    const getEmitModuleFormatOfFile = (file) => context.getEmitHost().getEmitModuleFormatOfFile(file);
    context.onSubstituteNode = onSubstituteNode;
    context.onEmitNode = onEmitNode;
    context.enableSubstitution(308 /* SyntaxKind.SourceFile */);
    context.enableEmitNotification(308 /* SyntaxKind.SourceFile */);
    let currentSourceFile;
    return transformSourceFileOrBundle;
    function onSubstituteNode(hint, node) {
        if ((0, ts_js_1.isSourceFile)(node)) {
            currentSourceFile = node;
            // Neither component transform wants substitution notifications for `SourceFile`s, and, in fact, relies on
            // the source file emit notification to setup scope variables for substitutions (so we _cannot_ call their substitute
            // functions on source files safely, as that context only gets setup in a later pipeline phase!)
            return previousOnSubstituteNode(hint, node);
        }
        else {
            if (!currentSourceFile) {
                return previousOnSubstituteNode(hint, node);
            }
            if (getEmitModuleFormatOfFile(currentSourceFile) >= ts_js_1.ModuleKind.ES2015) {
                return esmOnSubstituteNode(hint, node);
            }
            return cjsOnSubstituteNode(hint, node);
        }
    }
    function onEmitNode(hint, node, emitCallback) {
        if ((0, ts_js_1.isSourceFile)(node)) {
            currentSourceFile = node;
        }
        if (!currentSourceFile) {
            return previousOnEmitNode(hint, node, emitCallback);
        }
        if (getEmitModuleFormatOfFile(currentSourceFile) >= ts_js_1.ModuleKind.ES2015) {
            return esmOnEmitNode(hint, node, emitCallback);
        }
        return cjsOnEmitNode(hint, node, emitCallback);
    }
    function getModuleTransformForFile(file) {
        return getEmitModuleFormatOfFile(file) >= ts_js_1.ModuleKind.ES2015 ? esmTransform : cjsTransform;
    }
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        currentSourceFile = node;
        const result = getModuleTransformForFile(node)(node);
        currentSourceFile = undefined;
        ts_js_1.Debug.assert((0, ts_js_1.isSourceFile)(result));
        return result;
    }
    function transformSourceFileOrBundle(node) {
        return node.kind === 308 /* SyntaxKind.SourceFile */ ? transformSourceFile(node) : transformBundle(node);
    }
    function transformBundle(node) {
        return context.factory.createBundle((0, ts_js_1.map)(node.sourceFiles, transformSourceFile));
    }
}
