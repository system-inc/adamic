"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.dumpTracingLegend = exports.startTracing = exports.tracingEnabled = exports.tracing = void 0;
const ts_js_1 = require("./_namespaces/ts.js");
const performance = __importStar(require("./_namespaces/ts.performance.js"));
const fs = __importStar(require("node:fs"));
// enable the above using startTracing()
/**
 * Do not use this directly; instead @see {tracing}.
 * @internal
 */
var tracingEnabled;
(function (tracingEnabled) {
    let traceCount = 0;
    let traceFd = 0;
    let mode;
    const typeCatalog = []; // NB: id is index + 1
    let legendPath;
    const legend = [];
    /** Starts tracing for the given project. */
    function startTracing(tracingMode, traceDir, configFilePath) {
        ts_js_1.Debug.assert(!exports.tracing, "Tracing already started");
        mode = tracingMode;
        typeCatalog.splice(0);
        if (legendPath === undefined) {
            legendPath = (0, ts_js_1.combinePaths)(traceDir, "legend.json");
        }
        // Note that writing will fail later on if it exists and is not a directory
        if (!fs.existsSync(traceDir)) {
            fs.mkdirSync(traceDir, { recursive: true });
        }
        const countPart = mode === "build" ? `.${process.pid}-${++traceCount}`
            : mode === "server" ? `.${process.pid}`
                : ``;
        const tracePath = (0, ts_js_1.combinePaths)(traceDir, `trace${countPart}.json`);
        const typesPath = (0, ts_js_1.combinePaths)(traceDir, `types${countPart}.json`);
        legend.push({
            configFilePath,
            tracePath,
            typesPath,
        });
        traceFd = fs.openSync(tracePath, "w");
        exports.tracing = tracingEnabled; // only when traceFd is properly set
        // Start with a prefix that contains some metadata that the devtools profiler expects (also avoids a warning on import)
        const meta = { cat: "__metadata", ph: "M", ts: 1000 * (0, ts_js_1.timestamp)(), pid: 1, tid: 1 };
        fs.writeSync(traceFd, "[\n"
            + [{ name: "process_name", args: { name: "tsc" }, cat: meta.cat, ph: meta.ph, ts: meta.ts, pid: meta.pid, tid: meta.tid }, { name: "thread_name", args: { name: "Main" }, cat: meta.cat, ph: meta.ph, ts: meta.ts, pid: meta.pid, tid: meta.tid }, { name: "TracingStartedInBrowser", cat: "disabled-by-default-devtools.timeline", ph: meta.ph, ts: meta.ts, pid: meta.pid, tid: meta.tid }]
                .map(v => JSON.stringify(v)).join(",\n"));
    }
    tracingEnabled.startTracing = startTracing;
    /** Stops tracing for the in-progress project and dumps the type catalog. */
    function stopTracing() {
        ts_js_1.Debug.assert(!!exports.tracing, "Tracing is not in progress");
        ts_js_1.Debug.assert(!!typeCatalog.length === (mode !== "server")); // Have a type catalog iff not in server mode
        fs.writeSync(traceFd, `\n]\n`);
        fs.closeSync(traceFd);
        exports.tracing = undefined;
        if (typeCatalog.length) {
            dumpTypes(typeCatalog);
        }
        else {
            // We pre-computed this path for convenience, but clear it
            // now that the file won't be created.
            legend[legend.length - 1].typesPath = undefined;
        }
    }
    tracingEnabled.stopTracing = stopTracing;
    function recordType(type) {
        if (mode !== "server") {
            typeCatalog.push(type);
        }
    }
    tracingEnabled.recordType = recordType;
    let Phase;
    (function (Phase) {
        Phase["Parse"] = "parse";
        Phase["Program"] = "program";
        Phase["Bind"] = "bind";
        Phase["Check"] = "check";
        Phase["CheckTypes"] = "checkTypes";
        Phase["Emit"] = "emit";
        Phase["Session"] = "session";
    })(Phase = tracingEnabled.Phase || (tracingEnabled.Phase = {}));
    function instant(phase, name, args) {
        writeEvent("I", phase, name, args, `"s":"g"`);
    }
    tracingEnabled.instant = instant;
    const eventStack = [];
    /**
     * @param separateBeginAndEnd - used for special cases where we need the trace point even if the event
     * never terminates (typically for reducing a scenario too big to trace to one that can be completed).
     * In the future we might implement an exit handler to dump unfinished events which would deprecate
     * these operations.
     */
    function push(phase, name, args, separateBeginAndEnd = false) {
        if (separateBeginAndEnd) {
            writeEvent("B", phase, name, args);
        }
        eventStack.push({ phase, name, args, time: 1000 * (0, ts_js_1.timestamp)(), separateBeginAndEnd });
    }
    tracingEnabled.push = push;
    function pop(results) {
        ts_js_1.Debug.assert(eventStack.length > 0);
        writeStackEvent(eventStack.length - 1, 1000 * (0, ts_js_1.timestamp)(), results);
        if (eventStack.length === 0)
            throw new RangeError("Invalid array length");
        eventStack.splice(eventStack.length - 1);
    }
    tracingEnabled.pop = pop;
    function popAll() {
        const endTime = 1000 * (0, ts_js_1.timestamp)();
        for (let i = eventStack.length - 1; i >= 0; i--) {
            writeStackEvent(i, endTime);
        }
        eventStack.splice(0);
    }
    tracingEnabled.popAll = popAll;
    // sample every 10ms
    const sampleInterval = 1000 * 10;
    function writeStackEvent(index, endTime, results) {
        const { phase, name, args, time, separateBeginAndEnd } = eventStack[index];
        if (separateBeginAndEnd) {
            ts_js_1.Debug.assert(!results, "`results` are not supported for events with `separateBeginAndEnd`");
            writeEvent("E", phase, name, args, /*extras*/ undefined, endTime);
        }
        // test if [time,endTime) straddles a sampling point
        else if (sampleInterval - (time % sampleInterval) <= endTime - time) {
            writeEvent("X", phase, name, { ...args, results }, `"dur":${endTime - time}`, time);
        }
    }
    function writeEvent(eventType, phase, name, args, extras, time = 1000 * (0, ts_js_1.timestamp)()) {
        // In server mode, there's no easy way to dump type information, so we drop events that would require it.
        if (mode === "server" && phase === "checkTypes" /* Phase.CheckTypes */)
            return;
        performance.mark("beginTracing");
        fs.writeSync(traceFd, `,\n{"pid":1,"tid":1,"ph":"${eventType}","cat":"${phase}","ts":${time},"name":"${name}"`);
        if (extras)
            fs.writeSync(traceFd, `,${extras}`);
        if (args)
            fs.writeSync(traceFd, `,"args":${JSON.stringify(args)}`);
        fs.writeSync(traceFd, `}`);
        performance.mark("endTracing");
        performance.measure("Tracing", "beginTracing", "endTracing");
    }
    function getLocation(node) {
        const file = (0, ts_js_1.getSourceFileOfNode)(node);
        return !file
            ? undefined
            : {
                path: file.path,
                start: indexFromOne((0, ts_js_1.getLineAndCharacterOfPosition)(file, node.pos)),
                end: indexFromOne((0, ts_js_1.getLineAndCharacterOfPosition)(file, node.end)),
            };
        function indexFromOne(lc) {
            return {
                line: lc.line + 1,
                character: lc.character + 1,
            };
        }
    }
    function dumpTypes(types) {
        performance.mark("beginDumpTypes");
        const typesPath = legend[legend.length - 1].typesPath;
        const typesFd = fs.openSync(typesPath, "w");
        const recursionIdentityMap = new Map();
        // Cleverness: no line break here so that the type ID will match the line number
        fs.writeSync(typesFd, "[");
        const numTypes = types.length;
        for (let i = 0; i < numTypes; i++) {
            const type = types[i];
            const objectFlags = (0, ts_js_1.getObjectFlags)(type);
            const symbol = type.aliasSymbol ?? type.symbol;
            // It's slow to compute the display text, so skip it unless it's really valuable (or cheap)
            let display;
            if ((objectFlags & 16 /* ObjectFlags.Anonymous */) | (type.flags & 15360 /* TypeFlags.Literal */)) {
                try {
                    display = type.checker?.typeToString(type);
                }
                catch {
                    display = undefined;
                }
            }
            let indexedAccessProperties = {};
            if (type.flags & 33554432 /* TypeFlags.IndexedAccess */) {
                const indexedAccessType = type;
                indexedAccessProperties = {
                    indexedAccessObjectType: indexedAccessType.objectType?.id,
                    indexedAccessIndexType: indexedAccessType.indexType?.id,
                };
            }
            let referenceProperties = {};
            if (objectFlags & 4 /* ObjectFlags.Reference */) {
                const referenceType = type;
                referenceProperties = {
                    instantiatedType: referenceType.target?.id,
                    typeArguments: referenceType.resolvedTypeArguments?.map(t => t.id),
                    referenceLocation: getLocation(referenceType.node),
                };
            }
            let conditionalProperties = {};
            if (type.flags & 67108864 /* TypeFlags.Conditional */) {
                const conditionalType = type;
                conditionalProperties = {
                    conditionalCheckType: conditionalType.checkType?.id,
                    conditionalExtendsType: conditionalType.extendsType?.id,
                    conditionalTrueType: conditionalType.resolvedTrueType?.id ?? -1,
                    conditionalFalseType: conditionalType.resolvedFalseType?.id ?? -1,
                };
            }
            let substitutionProperties = {};
            if (type.flags & 16777216 /* TypeFlags.Substitution */) {
                const substitutionType = type;
                substitutionProperties = {
                    substitutionBaseType: substitutionType.baseType?.id,
                    constraintType: substitutionType.constraint?.id,
                };
            }
            let reverseMappedProperties = {};
            if (objectFlags & 1024 /* ObjectFlags.ReverseMapped */) {
                const reverseMappedType = type;
                reverseMappedProperties = {
                    reverseMappedSourceType: reverseMappedType.source?.id,
                    reverseMappedMappedType: reverseMappedType.mappedType?.id,
                    reverseMappedConstraintType: reverseMappedType.constraintType?.id,
                };
            }
            let evolvingArrayProperties = {};
            if (objectFlags & 256 /* ObjectFlags.EvolvingArray */) {
                const evolvingArrayType = type;
                evolvingArrayProperties = {
                    evolvingArrayElementType: evolvingArrayType.elementType.id,
                    evolvingArrayFinalType: evolvingArrayType.finalArrayType?.id,
                };
            }
            // We can't print out an arbitrary object, so just assign each one a unique number.
            // Don't call it an "id" so people don't treat it as a type id.
            let recursionToken;
            const recursionIdentity = type.checker.getRecursionIdentity(type);
            if (recursionIdentity) {
                recursionToken = recursionIdentityMap.get(recursionIdentity);
                if (!recursionToken) {
                    recursionToken = recursionIdentityMap.size;
                    recursionIdentityMap.set(recursionIdentity, recursionToken);
                }
            }
            const descriptor = {
                id: type.id,
                intrinsicName: type.flags & 402431 /* TypeFlags.Intrinsic */ ? type.intrinsicName : undefined,
                symbolName: symbol?.escapedName && (0, ts_js_1.unescapeLeadingUnderscores)(symbol.escapedName),
                recursionId: recursionToken,
                isTuple: objectFlags & 8 /* ObjectFlags.Tuple */ ? true : undefined,
                unionTypes: (type.flags & 134217728 /* TypeFlags.Union */) ? type.types?.map(t => t.id) : undefined,
                intersectionTypes: (type.flags & 268435456 /* TypeFlags.Intersection */) ? type.types.map(t => t.id) : undefined,
                aliasTypeArguments: type.aliasTypeArguments?.map(t => t.id),
                keyofType: (type.flags & 2097152 /* TypeFlags.Index */) ? type.type?.id : undefined,
                ...indexedAccessProperties,
                ...referenceProperties,
                ...conditionalProperties,
                ...substitutionProperties,
                ...reverseMappedProperties,
                ...evolvingArrayProperties,
                destructuringPattern: getLocation(type.pattern),
                firstDeclaration: getLocation(symbol?.declarations?.[0]),
                flags: ts_js_1.Debug.formatTypeFlags(type.flags).split("|"),
                display,
            };
            fs.writeSync(typesFd, JSON.stringify(descriptor));
            if (i < numTypes - 1) {
                fs.writeSync(typesFd, ",\n");
            }
        }
        fs.writeSync(typesFd, "]\n");
        fs.closeSync(typesFd);
        performance.mark("endDumpTypes");
        performance.measure("Dump types", "beginDumpTypes", "endDumpTypes");
    }
    function dumpLegend() {
        if (!legendPath) {
            return;
        }
        fs.writeFileSync(legendPath, JSON.stringify(legend));
    }
    tracingEnabled.dumpLegend = dumpLegend;
})(tracingEnabled || (exports.tracingEnabled = tracingEnabled = {}));
// define after tracingEnabled is initialized
/** @internal */
exports.startTracing = tracingEnabled.startTracing;
/** @internal */
exports.dumpTracingLegend = tracingEnabled.dumpLegend;
