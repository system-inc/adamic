"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformTypeScript = transformTypeScript;
const ts_js_1 = require("../_namespaces/ts.js");
/**
 * Indicates whether to emit type metadata in the new format.
 */
const USE_NEW_TYPE_METADATA_FORMAT = false;
var TypeScriptSubstitutionFlags;
(function (TypeScriptSubstitutionFlags) {
    TypeScriptSubstitutionFlags[TypeScriptSubstitutionFlags["None"] = 0] = "None";
    /** Enables substitutions for namespace exports. */
    TypeScriptSubstitutionFlags[TypeScriptSubstitutionFlags["NamespaceExports"] = 2] = "NamespaceExports";
    /* Enables substitutions for unqualified enum members */
    TypeScriptSubstitutionFlags[TypeScriptSubstitutionFlags["NonQualifiedEnumMembers"] = 8] = "NonQualifiedEnumMembers";
})(TypeScriptSubstitutionFlags || (TypeScriptSubstitutionFlags = {}));
var ClassFacts;
(function (ClassFacts) {
    ClassFacts[ClassFacts["None"] = 0] = "None";
    ClassFacts[ClassFacts["HasStaticInitializedProperties"] = 1] = "HasStaticInitializedProperties";
    ClassFacts[ClassFacts["HasClassOrConstructorParameterDecorators"] = 2] = "HasClassOrConstructorParameterDecorators";
    ClassFacts[ClassFacts["HasMemberDecorators"] = 4] = "HasMemberDecorators";
    ClassFacts[ClassFacts["IsExportOfNamespace"] = 8] = "IsExportOfNamespace";
    ClassFacts[ClassFacts["IsNamedExternalExport"] = 16] = "IsNamedExternalExport";
    ClassFacts[ClassFacts["IsDefaultExternalExport"] = 32] = "IsDefaultExternalExport";
    ClassFacts[ClassFacts["IsDerivedClass"] = 64] = "IsDerivedClass";
    ClassFacts[ClassFacts["HasAnyDecorators"] = 6] = "HasAnyDecorators";
    ClassFacts[ClassFacts["MayNeedImmediatelyInvokedFunctionExpression"] = 7] = "MayNeedImmediatelyInvokedFunctionExpression";
    ClassFacts[ClassFacts["IsExported"] = 56] = "IsExported";
})(ClassFacts || (ClassFacts = {}));
/** @internal */
function transformTypeScript(context) {
    const { factory, getEmitHelperFactory: emitHelpers, startLexicalEnvironment, resumeLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const resolver = context.getEmitResolver();
    const compilerOptions = context.getCompilerOptions();
    const languageVersion = (0, ts_js_1.getEmitScriptTarget)(compilerOptions);
    const moduleKind = (0, ts_js_1.getEmitModuleKind)(compilerOptions);
    const legacyDecorators = !!compilerOptions.experimentalDecorators;
    const typeSerializer = compilerOptions.emitDecoratorMetadata ? (0, ts_js_1.createRuntimeTypeSerializer)(context) : undefined;
    // Save the previous transformation hooks.
    const previousOnEmitNode = context.onEmitNode;
    const previousOnSubstituteNode = context.onSubstituteNode;
    // Set new transformation hooks.
    context.onEmitNode = onEmitNode;
    context.onSubstituteNode = onSubstituteNode;
    // Enable substitution for property/element access to emit const enum values.
    context.enableSubstitution(212 /* SyntaxKind.PropertyAccessExpression */);
    context.enableSubstitution(213 /* SyntaxKind.ElementAccessExpression */);
    // These variables contain state that changes as we descend into the tree.
    let currentSourceFile;
    let currentNamespace;
    let currentNamespaceContainerName;
    let currentLexicalScope;
    let currentScopeFirstDeclarationsOfName;
    /**
     * Keeps track of whether expression substitution has been enabled for specific edge cases.
     * They are persisted between each SourceFile transformation and should not be reset.
     */
    let enabledSubstitutions = 0 /* TypeScriptSubstitutionFlags.None */;
    /**
     * Keeps track of whether we are within any containing namespaces when performing
     * just-in-time substitution while printing an expression identifier.
     */
    let applicableSubstitutions;
    return transformSourceFileOrBundle;
    function transformSourceFileOrBundle(node) {
        if (node.kind === 309 /* SyntaxKind.Bundle */) {
            return transformBundle(node);
        }
        return transformSourceFile(node);
    }
    function transformBundle(node) {
        return factory.createBundle(node.sourceFiles.map(transformSourceFile));
    }
    /**
     * Transform TypeScript-specific syntax in a SourceFile.
     *
     * @param node A SourceFile node.
     */
    function transformSourceFile(node) {
        if (node.isDeclarationFile) {
            return node;
        }
        currentSourceFile = node;
        const visited = saveStateAndInvoke(node, visitSourceFile);
        (0, ts_js_1.addEmitHelpers)(visited, context.readEmitHelpers());
        currentSourceFile = undefined;
        return visited;
    }
    /**
     * Visits a node, saving and restoring state variables on the stack.
     *
     * @param node The node to visit.
     */
    function saveStateAndInvoke(node, f) {
        // Save state
        const savedCurrentScope = currentLexicalScope;
        const savedCurrentScopeFirstDeclarationsOfName = currentScopeFirstDeclarationsOfName;
        // Handle state changes before visiting a node.
        onBeforeVisitNode(node);
        const visited = f(node);
        // Restore state
        if (currentLexicalScope !== savedCurrentScope) {
            currentScopeFirstDeclarationsOfName = savedCurrentScopeFirstDeclarationsOfName;
        }
        currentLexicalScope = savedCurrentScope;
        return visited;
    }
    /**
     * Performs actions that should always occur immediately before visiting a node.
     *
     * @param node The node to visit.
     */
    function onBeforeVisitNode(node) {
        switch (node.kind) {
            case 308 /* SyntaxKind.SourceFile */:
            case 270 /* SyntaxKind.CaseBlock */:
            case 269 /* SyntaxKind.ModuleBlock */:
            case 242 /* SyntaxKind.Block */:
                currentLexicalScope = node;
                currentScopeFirstDeclarationsOfName = undefined;
                break;
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 263 /* SyntaxKind.FunctionDeclaration */:
                if ((0, ts_js_1.hasSyntacticModifier)(node, 128 /* ModifierFlags.Ambient */)) {
                    break;
                }
                // Record these declarations provided that they have a name.
                if (node.name) {
                    recordEmittedDeclarationInScope(node);
                }
                else {
                    // These nodes should always have names unless they are default-exports;
                    // however, class declaration parsing allows for undefined names, so syntactically invalid
                    // programs may also have an undefined name.
                    ts_js_1.Debug.assert(node.kind === 264 /* SyntaxKind.ClassDeclaration */ || (0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */));
                }
                break;
        }
    }
    /**
     * General-purpose node visitor.
     *
     * @param node The node to visit.
     */
    function visitor(node) {
        return saveStateAndInvoke(node, visitorWorker);
    }
    /**
     * Visits and possibly transforms any node.
     *
     * @param node The node to visit.
     */
    function visitorWorker(node) {
        if (node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */) {
            return visitTypeScript(node);
        }
        return node;
    }
    /**
     * Specialized visitor that visits the immediate children of a SourceFile.
     *
     * @param node The node to visit.
     */
    function sourceElementVisitor(node) {
        return saveStateAndInvoke(node, sourceElementVisitorWorker);
    }
    /**
     * Specialized visitor that visits the immediate children of a SourceFile.
     *
     * @param node The node to visit.
     */
    function sourceElementVisitorWorker(node) {
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            case 278 /* SyntaxKind.ExportAssignment */:
            case 279 /* SyntaxKind.ExportDeclaration */:
                return visitElidableStatement(node);
            default:
                return visitorWorker(node);
        }
    }
    /**
     * Determines whether import/export elision is blocked for this statement.
     *
     * @description
     * We generally block import/export elision if the statement was modified by a `before` custom
     * transform, although we will continue to allow it if the statement hasn't replaced a node of a different kind and
     * as long as the local bindings for the declarations are unchanged.
     */
    function isElisionBlocked(node) {
        const parsed = (0, ts_js_1.getParseTreeNode)(node);
        if (parsed === node || (0, ts_js_1.isExportAssignment)(node)) {
            return false;
        }
        if (!parsed || parsed.kind !== node.kind) {
            // no longer safe to elide as the declaration was replaced with a node of a different kind
            return true;
        }
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
                ts_js_1.Debug.assertNode(parsed, ts_js_1.isImportDeclaration);
                if (node.importClause !== parsed.importClause) {
                    return true; // no longer safe to elide as the import clause has changed
                }
                if (node.attributes !== parsed.attributes) {
                    return true; // no longer safe to elide as the import attributes have changed
                }
                break;
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                ts_js_1.Debug.assertNode(parsed, ts_js_1.isImportEqualsDeclaration);
                if (node.name !== parsed.name) {
                    return true; // no longer safe to elide as local binding has changed
                }
                if (node.isTypeOnly !== parsed.isTypeOnly) {
                    return true; // no longer safe to elide as `type` modifier has changed
                }
                if (node.moduleReference !== parsed.moduleReference && ((0, ts_js_1.isEntityName)(node.moduleReference) || (0, ts_js_1.isEntityName)(parsed.moduleReference))) {
                    return true; // no longer safe to elide as EntityName reference has changed.
                }
                break;
            case 279 /* SyntaxKind.ExportDeclaration */:
                ts_js_1.Debug.assertNode(parsed, ts_js_1.isExportDeclaration);
                if (node.exportClause !== parsed.exportClause) {
                    return true; // no longer safe to elide as the export clause has changed
                }
                if (node.attributes !== parsed.attributes) {
                    return true; // no longer safe to elide as the export attributes have changed
                }
                break;
        }
        return false;
    }
    function visitElidableStatement(node) {
        if (isElisionBlocked(node)) {
            // We do not reuse `visitorWorker`, as the ellidable statement syntax kinds are technically unrecognized by
            // the switch-case in `visitTypeScript`, and will trigger debug failures when debug verbosity is turned up.
            if (node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */) {
                // This node contains TypeScript, so we should visit its children.
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            }
            // Otherwise, we can just return the node
            return node;
        }
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
                return visitImportDeclaration(node);
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                return visitImportEqualsDeclaration(node);
            case 278 /* SyntaxKind.ExportAssignment */:
                return visitExportAssignment(node);
            case 279 /* SyntaxKind.ExportDeclaration */:
                return visitExportDeclaration(node);
            default:
                ts_js_1.Debug.fail("Unhandled ellided statement");
        }
    }
    /**
     * Specialized visitor that visits the immediate children of a namespace.
     *
     * @param node The node to visit.
     */
    function namespaceElementVisitor(node) {
        return saveStateAndInvoke(node, namespaceElementVisitorWorker);
    }
    /**
     * Specialized visitor that visits the immediate children of a namespace.
     *
     * @param node The node to visit.
     */
    function namespaceElementVisitorWorker(node) {
        if (node.kind === 279 /* SyntaxKind.ExportDeclaration */ ||
            node.kind === 273 /* SyntaxKind.ImportDeclaration */ ||
            node.kind === 274 /* SyntaxKind.ImportClause */ ||
            (node.kind === 272 /* SyntaxKind.ImportEqualsDeclaration */ &&
                node.moduleReference.kind === 284 /* SyntaxKind.ExternalModuleReference */)) {
            // do not emit ES6 imports and exports since they are illegal inside a namespace
            return undefined;
        }
        else if (node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */ || (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            return visitTypeScript(node);
        }
        return node;
    }
    /**
     * Gets a specialized visitor that visits the immediate children of a class with TypeScript syntax.
     *
     * @param parent The class containing the elements to visit.
     */
    function getClassElementVisitor(parent) {
        return node => saveStateAndInvoke(node, n => classElementVisitorWorker(n, parent));
    }
    /**
     * Specialized visitor that visits the immediate children of a class with TypeScript syntax.
     *
     * @param node The node to visit.
     */
    function classElementVisitorWorker(node, parent) {
        switch (node.kind) {
            case 177 /* SyntaxKind.Constructor */:
                return visitConstructor(node);
            case 173 /* SyntaxKind.PropertyDeclaration */:
                // Property declarations are not TypeScript syntax, but they must be visited
                // for the decorator transformation.
                return visitPropertyDeclaration(node, parent);
            case 178 /* SyntaxKind.GetAccessor */:
                // Get Accessors can have TypeScript modifiers, decorators, and type annotations.
                return visitGetAccessor(node, parent);
            case 179 /* SyntaxKind.SetAccessor */:
                // Set Accessors can have TypeScript modifiers and type annotations.
                return visitSetAccessor(node, parent);
            case 175 /* SyntaxKind.MethodDeclaration */:
                // TypeScript method declarations may have decorators, modifiers
                // or type annotations.
                return visitMethodDeclaration(node, parent);
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
            case 241 /* SyntaxKind.SemicolonClassElement */:
                return node;
            case 182 /* SyntaxKind.IndexSignature */:
                // Index signatures are elided
                return;
            default:
                return ts_js_1.Debug.failBadSyntaxKind(node);
        }
    }
    function getObjectLiteralElementVisitor(parent) {
        return node => saveStateAndInvoke(node, n => objectLiteralElementVisitorWorker(n, parent));
    }
    function objectLiteralElementVisitorWorker(node, parent) {
        switch (node.kind) {
            case 304 /* SyntaxKind.PropertyAssignment */:
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            case 306 /* SyntaxKind.SpreadAssignment */:
                return visitor(node);
            case 178 /* SyntaxKind.GetAccessor */:
                // Get Accessors can have TypeScript modifiers, decorators, and type annotations.
                return visitGetAccessor(node, parent);
            case 179 /* SyntaxKind.SetAccessor */:
                // Set Accessors can have TypeScript modifiers and type annotations.
                return visitSetAccessor(node, parent);
            case 175 /* SyntaxKind.MethodDeclaration */:
                // TypeScript method declarations may have decorators, modifiers
                // or type annotations.
                return visitMethodDeclaration(node, parent);
            default:
                return ts_js_1.Debug.failBadSyntaxKind(node);
        }
    }
    function decoratorElidingVisitor(node) {
        return (0, ts_js_1.isDecorator)(node) ? undefined : visitor(node);
    }
    function modifierElidingVisitor(node) {
        return (0, ts_js_1.isModifier)(node) ? undefined : visitor(node);
    }
    function modifierVisitor(node) {
        if ((0, ts_js_1.isDecorator)(node))
            return undefined;
        if ((0, ts_js_1.modifierToFlag)(node.kind) & 28895 /* ModifierFlags.TypeScriptModifier */) {
            return undefined;
        }
        else if (currentNamespace && node.kind === 95 /* SyntaxKind.ExportKeyword */) {
            return undefined;
        }
        return node;
    }
    /**
     * Branching visitor, visits a TypeScript syntax node.
     *
     * @param node The node to visit.
     */
    function visitTypeScript(node) {
        if ((0, ts_js_1.isStatement)(node) && (0, ts_js_1.hasSyntacticModifier)(node, 128 /* ModifierFlags.Ambient */)) {
            // TypeScript ambient declarations are elided, but some comments may be preserved.
            // See the implementation of `getLeadingComments` in comments.ts for more details.
            return factory.createNotEmittedStatement(node);
        }
        switch (node.kind) {
            case 95 /* SyntaxKind.ExportKeyword */:
            case 90 /* SyntaxKind.DefaultKeyword */:
                // ES6 export and default modifiers are elided when inside a namespace.
                return currentNamespace ? undefined : node;
            case 125 /* SyntaxKind.PublicKeyword */:
            case 123 /* SyntaxKind.PrivateKeyword */:
            case 124 /* SyntaxKind.ProtectedKeyword */:
            case 128 /* SyntaxKind.AbstractKeyword */:
            case 164 /* SyntaxKind.OverrideKeyword */:
            case 87 /* SyntaxKind.ConstKeyword */:
            case 138 /* SyntaxKind.DeclareKeyword */:
            case 148 /* SyntaxKind.ReadonlyKeyword */:
            case 103 /* SyntaxKind.InKeyword */:
            case 147 /* SyntaxKind.OutKeyword */:
            // TypeScript accessibility and readonly modifiers are elided
            // falls through
            case 189 /* SyntaxKind.ArrayType */:
            case 190 /* SyntaxKind.TupleType */:
            case 191 /* SyntaxKind.OptionalType */:
            case 192 /* SyntaxKind.RestType */:
            case 188 /* SyntaxKind.TypeLiteral */:
            case 183 /* SyntaxKind.TypePredicate */:
            case 169 /* SyntaxKind.TypeParameter */:
            case 133 /* SyntaxKind.AnyKeyword */:
            case 159 /* SyntaxKind.UnknownKeyword */:
            case 136 /* SyntaxKind.BooleanKeyword */:
            case 154 /* SyntaxKind.StringKeyword */:
            case 150 /* SyntaxKind.NumberKeyword */:
            case 146 /* SyntaxKind.NeverKeyword */:
            case 116 /* SyntaxKind.VoidKeyword */:
            case 155 /* SyntaxKind.SymbolKeyword */:
            case 186 /* SyntaxKind.ConstructorType */:
            case 185 /* SyntaxKind.FunctionType */:
            case 187 /* SyntaxKind.TypeQuery */:
            case 184 /* SyntaxKind.TypeReference */:
            case 193 /* SyntaxKind.UnionType */:
            case 194 /* SyntaxKind.IntersectionType */:
            case 195 /* SyntaxKind.ConditionalType */:
            case 197 /* SyntaxKind.ParenthesizedType */:
            case 198 /* SyntaxKind.ThisType */:
            case 199 /* SyntaxKind.TypeOperator */:
            case 200 /* SyntaxKind.IndexedAccessType */:
            case 201 /* SyntaxKind.MappedType */:
            case 202 /* SyntaxKind.LiteralType */:
            // TypeScript type nodes are elided.
            // falls through
            case 182 /* SyntaxKind.IndexSignature */:
                // TypeScript index signatures are elided.
                return undefined;
            case 266 /* SyntaxKind.TypeAliasDeclaration */:
                // TypeScript type-only declarations are elided.
                return factory.createNotEmittedStatement(node);
            case 271 /* SyntaxKind.NamespaceExportDeclaration */:
                // TypeScript namespace export declarations are elided.
                return undefined;
            case 265 /* SyntaxKind.InterfaceDeclaration */:
                // TypeScript interfaces are elided, but some comments may be preserved.
                // See the implementation of `getLeadingComments` in comments.ts for more details.
                return factory.createNotEmittedStatement(node);
            case 264 /* SyntaxKind.ClassDeclaration */:
                // This may be a class declaration with TypeScript syntax extensions.
                //
                // TypeScript class syntax extensions include:
                // - decorators
                // - optional `implements` heritage clause
                // - parameter property assignments in the constructor
                // - index signatures
                // - method overload signatures
                return visitClassDeclaration(node);
            case 232 /* SyntaxKind.ClassExpression */:
                // This may be a class expression with TypeScript syntax extensions.
                //
                // TypeScript class syntax extensions include:
                // - decorators
                // - optional `implements` heritage clause
                // - parameter property assignments in the constructor
                // - index signatures
                // - method overload signatures
                return visitClassExpression(node);
            case 299 /* SyntaxKind.HeritageClause */:
                // This may be a heritage clause with TypeScript syntax extensions.
                //
                // TypeScript heritage clause extensions include:
                // - `implements` clause
                return visitHeritageClause(node);
            case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
                // TypeScript supports type arguments on an expression in an `extends` heritage clause.
                return visitExpressionWithTypeArguments(node);
            case 211 /* SyntaxKind.ObjectLiteralExpression */:
                return visitObjectLiteralExpression(node);
            case 177 /* SyntaxKind.Constructor */:
            case 173 /* SyntaxKind.PropertyDeclaration */:
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return ts_js_1.Debug.fail("Class and object literal elements must be visited with their respective visitors");
            case 263 /* SyntaxKind.FunctionDeclaration */:
                // Typescript function declarations can have modifiers, decorators, and type annotations.
                return visitFunctionDeclaration(node);
            case 219 /* SyntaxKind.FunctionExpression */:
                // TypeScript function expressions can have modifiers and type annotations.
                return visitFunctionExpression(node);
            case 220 /* SyntaxKind.ArrowFunction */:
                // TypeScript arrow functions can have modifiers and type annotations.
                return visitArrowFunction(node);
            case 170 /* SyntaxKind.Parameter */:
                // This may be a parameter declaration with TypeScript syntax extensions.
                //
                // TypeScript parameter declaration syntax extensions include:
                // - decorators
                // - accessibility modifiers
                // - the question mark (?) token for optional parameters
                // - type annotations
                // - this parameters
                return visitParameter(node);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                // ParenthesizedExpressions are TypeScript if their expression is a
                // TypeAssertion or AsExpression
                return visitParenthesizedExpression(node);
            case 217 /* SyntaxKind.TypeAssertionExpression */:
            case 235 /* SyntaxKind.AsExpression */:
                // TypeScript type assertions are removed, but their subtrees are preserved.
                return visitAssertionExpression(node);
            case 239 /* SyntaxKind.SatisfiesExpression */:
                return visitSatisfiesExpression(node);
            case 214 /* SyntaxKind.CallExpression */:
                return visitCallExpression(node);
            case 215 /* SyntaxKind.NewExpression */:
                return visitNewExpression(node);
            case 216 /* SyntaxKind.TaggedTemplateExpression */:
                return visitTaggedTemplateExpression(node);
            case 236 /* SyntaxKind.NonNullExpression */:
                // TypeScript non-null expressions are removed, but their subtrees are preserved.
                return visitNonNullExpression(node);
            case 267 /* SyntaxKind.EnumDeclaration */:
                // TypeScript enum declarations do not exist in ES6 and must be rewritten.
                return visitEnumDeclaration(node);
            case 244 /* SyntaxKind.VariableStatement */:
                // TypeScript namespace exports for variable statements must be transformed.
                return visitVariableStatement(node);
            case 261 /* SyntaxKind.VariableDeclaration */:
                return visitVariableDeclaration(node);
            case 268 /* SyntaxKind.ModuleDeclaration */:
                // TypeScript namespace declarations must be transformed.
                return visitModuleDeclaration(node);
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                // TypeScript namespace or external module import.
                return visitImportEqualsDeclaration(node);
            case 286 /* SyntaxKind.JsxSelfClosingElement */:
                return visitJsxSelfClosingElement(node);
            case 287 /* SyntaxKind.JsxOpeningElement */:
                return visitJsxJsxOpeningElement(node);
            default:
                // node contains some other TypeScript syntax
                return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function visitSourceFile(node) {
        const alwaysStrict = (0, ts_js_1.getAlwaysStrict)(compilerOptions) &&
            !((0, ts_js_1.isExternalModule)(node) && moduleKind >= ts_js_1.ModuleKind.ES2015) &&
            !(0, ts_js_1.isJsonSourceFile)(node);
        return factory.updateSourceFile(node, (0, ts_js_1.visitLexicalEnvironment)(node.statements, sourceElementVisitor, context, /*start*/ 0, alwaysStrict));
    }
    function visitObjectLiteralExpression(node) {
        return factory.updateObjectLiteralExpression(node, (0, ts_js_1.visitNodes)(node.properties, getObjectLiteralElementVisitor(node), ts_js_1.isObjectLiteralElementLike));
    }
    function getClassFacts(node) {
        let facts = 0 /* ClassFacts.None */;
        if ((0, ts_js_1.some)((0, ts_js_1.getProperties)(node, /*requireInitializer*/ true, /*isStatic*/ true)))
            facts |= 1 /* ClassFacts.HasStaticInitializedProperties */;
        const extendsClauseElement = (0, ts_js_1.getEffectiveBaseTypeNode)(node);
        if (extendsClauseElement && (0, ts_js_1.skipOuterExpressions)(extendsClauseElement.expression).kind !== 106 /* SyntaxKind.NullKeyword */)
            facts |= 64 /* ClassFacts.IsDerivedClass */;
        if ((0, ts_js_1.classOrConstructorParameterIsDecorated)(legacyDecorators, node))
            facts |= 2 /* ClassFacts.HasClassOrConstructorParameterDecorators */;
        if ((0, ts_js_1.childIsDecorated)(legacyDecorators, node))
            facts |= 4 /* ClassFacts.HasMemberDecorators */;
        if (isExportOfNamespace(node))
            facts |= 8 /* ClassFacts.IsExportOfNamespace */;
        else if (isDefaultExternalModuleExport(node))
            facts |= 32 /* ClassFacts.IsDefaultExternalExport */;
        else if (isNamedExternalModuleExport(node))
            facts |= 16 /* ClassFacts.IsNamedExternalExport */;
        return facts;
    }
    function hasTypeScriptClassSyntax(node) {
        return !!(node.transformFlags & 8192 /* TransformFlags.ContainsTypeScriptClassSyntax */);
    }
    function isClassLikeDeclarationWithTypeScriptSyntax(node) {
        return (0, ts_js_1.hasDecorators)(node)
            || (0, ts_js_1.some)(node.typeParameters)
            || (0, ts_js_1.some)(node.heritageClauses, hasTypeScriptClassSyntax)
            || (0, ts_js_1.some)(node.members, hasTypeScriptClassSyntax);
    }
    function visitClassDeclaration(node) {
        const facts = getClassFacts(node);
        const promoteToIIFE = languageVersion < 2 /* ScriptTarget.ES2015 */ &&
            !!(facts & 7 /* ClassFacts.MayNeedImmediatelyInvokedFunctionExpression */);
        if (!isClassLikeDeclarationWithTypeScriptSyntax(node) &&
            !(0, ts_js_1.classOrConstructorParameterIsDecorated)(legacyDecorators, node) &&
            !isExportOfNamespace(node)) {
            return factory.updateClassDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), node.name, 
            /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause), (0, ts_js_1.visitNodes)(node.members, getClassElementVisitor(node), ts_js_1.isClassElement));
        }
        if (promoteToIIFE) {
            context.startLexicalEnvironment();
        }
        const moveModifiers = promoteToIIFE ||
            facts & 8 /* ClassFacts.IsExportOfNamespace */;
        // elide modifiers on the declaration if we are emitting an IIFE or the class is
        // a namespace export
        let modifiers = moveModifiers ?
            (0, ts_js_1.visitNodes)(node.modifiers, modifierElidingVisitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike);
        // inject metadata only if the class is decorated
        if (facts & 2 /* ClassFacts.HasClassOrConstructorParameterDecorators */) {
            modifiers = injectClassTypeMetadata(modifiers, node);
        }
        const needsName = moveModifiers && !node.name ||
            facts & 4 /* ClassFacts.HasMemberDecorators */ ||
            facts & 1 /* ClassFacts.HasStaticInitializedProperties */;
        const name = needsName ?
            node.name ?? factory.getGeneratedNameForNode(node) :
            node.name;
        //  ${modifiers} class ${name} ${heritageClauses} {
        //      ${members}
        //  }
        const classDeclaration = factory.updateClassDeclaration(node, modifiers, name, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause), transformClassMembers(node));
        // To better align with the old emitter, we should not emit a trailing source map
        // entry if the class has static properties.
        let emitFlags = (0, ts_js_1.getEmitFlags)(node);
        if (facts & 1 /* ClassFacts.HasStaticInitializedProperties */) {
            emitFlags |= 64 /* EmitFlags.NoTrailingSourceMap */;
        }
        (0, ts_js_1.setEmitFlags)(classDeclaration, emitFlags);
        let statement;
        if (promoteToIIFE) {
            // When we emit a TypeScript class down to ES5, we must wrap it in an IIFE so that the
            // 'es2015' transformer can properly nest static initializers and decorators. The result
            // looks something like:
            //
            //  var C = function () {
            //      class C {
            //      }
            //      C.static_prop = 1;
            //      return C;
            //  }();
            //
            const statements = [classDeclaration];
            const closingBraceLocation = (0, ts_js_1.createTokenRange)((0, ts_js_1.skipTrivia)(currentSourceFile.text, node.members.end), 20 /* SyntaxKind.CloseBraceToken */);
            const localName = factory.getInternalName(node);
            // The following partially-emitted expression exists purely to align our sourcemap
            // emit with the original emitter.
            const outer = factory.createPartiallyEmittedExpression(localName);
            (0, ts_js_1.setTextRangeEnd)(outer, closingBraceLocation.end);
            (0, ts_js_1.setEmitFlags)(outer, 3072 /* EmitFlags.NoComments */);
            const returnStatement = factory.createReturnStatement(outer);
            (0, ts_js_1.setTextRangePos)(returnStatement, closingBraceLocation.pos);
            (0, ts_js_1.setEmitFlags)(returnStatement, 3072 /* EmitFlags.NoComments */ | 768 /* EmitFlags.NoTokenSourceMaps */);
            statements.push(returnStatement);
            (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, context.endLexicalEnvironment());
            const iife = factory.createImmediatelyInvokedArrowFunction(statements);
            (0, ts_js_1.setInternalEmitFlags)(iife, 1 /* InternalEmitFlags.TypeScriptClassWrapper */);
            //  let C = (() => { ... })();
            const varDecl = factory.createVariableDeclaration(factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ false), 
            /*exclamationToken*/ undefined, 
            /*type*/ undefined, iife);
            (0, ts_js_1.setOriginalNode)(varDecl, node);
            const varStatement = factory.createVariableStatement(
            /*modifiers*/ undefined, factory.createVariableDeclarationList([varDecl], 1 /* NodeFlags.Let */));
            (0, ts_js_1.setOriginalNode)(varStatement, node);
            (0, ts_js_1.setCommentRange)(varStatement, node);
            (0, ts_js_1.setSourceMapRange)(varStatement, (0, ts_js_1.moveRangePastDecorators)(node));
            (0, ts_js_1.startOnNewLine)(varStatement);
            statement = varStatement;
        }
        else {
            statement = classDeclaration;
        }
        if (moveModifiers) {
            if (facts & 8 /* ClassFacts.IsExportOfNamespace */) {
                return [
                    statement,
                    createExportMemberAssignmentStatement(node),
                ];
            }
            if (facts & 32 /* ClassFacts.IsDefaultExternalExport */) {
                return [
                    statement,
                    factory.createExportDefault(factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ true)),
                ];
            }
            if (facts & 16 /* ClassFacts.IsNamedExternalExport */) {
                return [
                    statement,
                    factory.createExternalModuleExport(factory.getDeclarationName(node, /*allowComments*/ false, /*allowSourceMaps*/ true)),
                ];
            }
        }
        return statement;
    }
    function visitClassExpression(node) {
        let modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierElidingVisitor, ts_js_1.isModifierLike);
        if ((0, ts_js_1.classOrConstructorParameterIsDecorated)(legacyDecorators, node)) {
            modifiers = injectClassTypeMetadata(modifiers, node);
        }
        return factory.updateClassExpression(node, modifiers, node.name, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause), transformClassMembers(node));
    }
    /**
     * Transforms the members of a class.
     *
     * @param node The current class.
     */
    function transformClassMembers(node) {
        const members = (0, ts_js_1.visitNodes)(node.members, getClassElementVisitor(node), ts_js_1.isClassElement);
        let newMembers;
        const constructor = (0, ts_js_1.getFirstConstructorWithBody)(node);
        const parametersWithPropertyAssignments = constructor &&
            (0, ts_js_1.filter)(constructor.parameters, (p) => (0, ts_js_1.isParameterPropertyDeclaration)(p, constructor));
        if (parametersWithPropertyAssignments) {
            for (const parameter of parametersWithPropertyAssignments) {
                // Ignore parameter properties with destructured names; we will have errored on them earlier.
                if (!(0, ts_js_1.isIdentifier)(parameter.name)) {
                    continue;
                }
                const parameterProperty = factory.createPropertyDeclaration(
                /*modifiers*/ undefined, parameter.name, 
                /*questionOrExclamationToken*/ undefined, 
                /*type*/ undefined, 
                /*initializer*/ undefined);
                (0, ts_js_1.setOriginalNode)(parameterProperty, parameter);
                newMembers = (0, ts_js_1.append)(newMembers, parameterProperty);
            }
        }
        if (newMembers) {
            newMembers = (0, ts_js_1.addRange)(newMembers, members);
            return (0, ts_js_1.setTextRange)(factory.createNodeArray(newMembers), /*location*/ node.members);
        }
        return members;
    }
    function injectClassTypeMetadata(modifiers, node) {
        const metadata = getTypeMetadata(node, node);
        if ((0, ts_js_1.some)(metadata)) {
            const modifiersArray = [];
            (0, ts_js_1.addRange)(modifiersArray, (0, ts_js_1.takeWhile)(modifiers, ts_js_1.isExportOrDefaultModifier));
            (0, ts_js_1.addRange)(modifiersArray, (0, ts_js_1.filter)(modifiers, ts_js_1.isDecorator));
            (0, ts_js_1.addRange)(modifiersArray, metadata);
            (0, ts_js_1.addRange)(modifiersArray, (0, ts_js_1.filter)((0, ts_js_1.skipWhile)(modifiers, ts_js_1.isExportOrDefaultModifier), ts_js_1.isModifier));
            modifiers = (0, ts_js_1.setTextRange)(factory.createNodeArray(modifiersArray), modifiers);
        }
        return modifiers;
    }
    function injectClassElementTypeMetadata(modifiers, node, container) {
        if ((0, ts_js_1.isClassLike)(container) && (0, ts_js_1.classElementOrClassElementParameterIsDecorated)(legacyDecorators, node, container)) {
            const metadata = getTypeMetadata(node, container);
            if ((0, ts_js_1.some)(metadata)) {
                const modifiersArray = [];
                (0, ts_js_1.addRange)(modifiersArray, (0, ts_js_1.filter)(modifiers, ts_js_1.isDecorator));
                (0, ts_js_1.addRange)(modifiersArray, metadata);
                (0, ts_js_1.addRange)(modifiersArray, (0, ts_js_1.filter)(modifiers, ts_js_1.isModifier));
                modifiers = (0, ts_js_1.setTextRange)(factory.createNodeArray(modifiersArray), modifiers);
            }
        }
        return modifiers;
    }
    /**
     * Gets optional type metadata for a declaration.
     *
     * @param node The declaration node.
     */
    function getTypeMetadata(node, container) {
        // Decorator metadata is not yet supported for ES decorators.
        if (!legacyDecorators)
            return undefined;
        return USE_NEW_TYPE_METADATA_FORMAT ?
            getNewTypeMetadata(node, container) :
            getOldTypeMetadata(node, container);
    }
    function getOldTypeMetadata(node, container) {
        if (typeSerializer) {
            let decorators;
            if (shouldAddTypeMetadata(node)) {
                const typeMetadata = emitHelpers().createMetadataHelper("design:type", typeSerializer.serializeTypeOfNode({ currentLexicalScope, currentNameScope: container }, node, container));
                decorators = (0, ts_js_1.append)(decorators, factory.createDecorator(typeMetadata));
            }
            if (shouldAddParamTypesMetadata(node)) {
                const paramTypesMetadata = emitHelpers().createMetadataHelper("design:paramtypes", typeSerializer.serializeParameterTypesOfNode({ currentLexicalScope, currentNameScope: container }, node, container));
                decorators = (0, ts_js_1.append)(decorators, factory.createDecorator(paramTypesMetadata));
            }
            if (shouldAddReturnTypeMetadata(node)) {
                const returnTypeMetadata = emitHelpers().createMetadataHelper("design:returntype", typeSerializer.serializeReturnTypeOfNode({ currentLexicalScope, currentNameScope: container }, node));
                decorators = (0, ts_js_1.append)(decorators, factory.createDecorator(returnTypeMetadata));
            }
            return decorators;
        }
    }
    function getNewTypeMetadata(node, container) {
        if (typeSerializer) {
            let properties;
            if (shouldAddTypeMetadata(node)) {
                const typeProperty = factory.createPropertyAssignment("type", factory.createArrowFunction(/*modifiers*/ undefined, /*typeParameters*/ undefined, [], /*type*/ undefined, factory.createToken(39 /* SyntaxKind.EqualsGreaterThanToken */), typeSerializer.serializeTypeOfNode({ currentLexicalScope, currentNameScope: container }, node, container)));
                properties = (0, ts_js_1.append)(properties, typeProperty);
            }
            if (shouldAddParamTypesMetadata(node)) {
                const paramTypeProperty = factory.createPropertyAssignment("paramTypes", factory.createArrowFunction(/*modifiers*/ undefined, /*typeParameters*/ undefined, [], /*type*/ undefined, factory.createToken(39 /* SyntaxKind.EqualsGreaterThanToken */), typeSerializer.serializeParameterTypesOfNode({ currentLexicalScope, currentNameScope: container }, node, container)));
                properties = (0, ts_js_1.append)(properties, paramTypeProperty);
            }
            if (shouldAddReturnTypeMetadata(node)) {
                const returnTypeProperty = factory.createPropertyAssignment("returnType", factory.createArrowFunction(/*modifiers*/ undefined, /*typeParameters*/ undefined, [], /*type*/ undefined, factory.createToken(39 /* SyntaxKind.EqualsGreaterThanToken */), typeSerializer.serializeReturnTypeOfNode({ currentLexicalScope, currentNameScope: container }, node)));
                properties = (0, ts_js_1.append)(properties, returnTypeProperty);
            }
            if (properties) {
                const typeInfoMetadata = emitHelpers().createMetadataHelper("design:typeinfo", factory.createObjectLiteralExpression(properties, /*multiLine*/ true));
                return [factory.createDecorator(typeInfoMetadata)];
            }
        }
    }
    /**
     * Determines whether to emit the "design:type" metadata based on the node's kind.
     * The caller should have already tested whether the node has decorators and whether the
     * emitDecoratorMetadata compiler option is set.
     *
     * @param node The node to test.
     */
    function shouldAddTypeMetadata(node) {
        const kind = node.kind;
        return kind === 175 /* SyntaxKind.MethodDeclaration */
            || kind === 178 /* SyntaxKind.GetAccessor */
            || kind === 179 /* SyntaxKind.SetAccessor */
            || kind === 173 /* SyntaxKind.PropertyDeclaration */;
    }
    /**
     * Determines whether to emit the "design:returntype" metadata based on the node's kind.
     * The caller should have already tested whether the node has decorators and whether the
     * emitDecoratorMetadata compiler option is set.
     *
     * @param node The node to test.
     */
    function shouldAddReturnTypeMetadata(node) {
        return node.kind === 175 /* SyntaxKind.MethodDeclaration */;
    }
    /**
     * Determines whether to emit the "design:paramtypes" metadata based on the node's kind.
     * The caller should have already tested whether the node has decorators and whether the
     * emitDecoratorMetadata compiler option is set.
     *
     * @param node The node to test.
     */
    function shouldAddParamTypesMetadata(node) {
        switch (node.kind) {
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 232 /* SyntaxKind.ClassExpression */:
                return (0, ts_js_1.getFirstConstructorWithBody)(node) !== undefined;
            case 175 /* SyntaxKind.MethodDeclaration */:
            case 178 /* SyntaxKind.GetAccessor */:
            case 179 /* SyntaxKind.SetAccessor */:
                return true;
        }
        return false;
    }
    /**
     * Gets an expression that represents a property name (for decorated properties or enums).
     * For a computed property, a name is generated for the node.
     *
     * @param member The member whose name should be converted into an expression.
     */
    function getExpressionForPropertyName(member, generateNameForComputedPropertyName) {
        const name = member.name;
        if ((0, ts_js_1.isPrivateIdentifier)(name)) {
            return factory.createIdentifier("");
        }
        else if ((0, ts_js_1.isComputedPropertyName)(name)) {
            return generateNameForComputedPropertyName && !(0, ts_js_1.isSimpleInlineableExpression)(name.expression)
                ? factory.getGeneratedNameForNode(name)
                : name.expression;
        }
        else if ((0, ts_js_1.isIdentifier)(name)) {
            return factory.createStringLiteral((0, ts_js_1.idText)(name));
        }
        else {
            return factory.cloneNode(name);
        }
    }
    /**
     * Visits the property name of a class element, for use when emitting property
     * initializers. For a computed property on a node with decorators, a temporary
     * value is stored for later use.
     *
     * @param member The member whose name should be visited.
     */
    function visitPropertyNameOfClassElement(member) {
        const name = member.name;
        // Computed property names need to be transformed into a hoisted variable when they are used more than once.
        // The names are used more than once when the property has a decorator.
        if (legacyDecorators && (0, ts_js_1.isComputedPropertyName)(name) && (0, ts_js_1.hasDecorators)(member)) {
            const expression = (0, ts_js_1.visitNode)(name.expression, visitor, ts_js_1.isExpression);
            ts_js_1.Debug.assert(expression);
            const innerExpression = (0, ts_js_1.skipPartiallyEmittedExpressions)(expression);
            if (!(0, ts_js_1.isSimpleInlineableExpression)(innerExpression)) {
                const generatedName = factory.getGeneratedNameForNode(name);
                hoistVariableDeclaration(generatedName);
                return factory.updateComputedPropertyName(name, factory.createAssignment(generatedName, expression));
            }
        }
        return ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(name, visitor, ts_js_1.isPropertyName));
    }
    /**
     * Transforms a HeritageClause with TypeScript syntax.
     *
     * This function will only be called when one of the following conditions are met:
     * - The node is a non-`extends` heritage clause that should be elided.
     * - The node is an `extends` heritage clause that should be visited, but only allow a single type.
     *
     * @param node The HeritageClause to transform.
     */
    function visitHeritageClause(node) {
        if (node.token === 119 /* SyntaxKind.ImplementsKeyword */) {
            // implements clauses are elided
            return undefined;
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Transforms an ExpressionWithTypeArguments with TypeScript syntax.
     *
     * This function will only be called when one of the following conditions are met:
     * - The node contains type arguments that should be elided.
     *
     * @param node The ExpressionWithTypeArguments to transform.
     */
    function visitExpressionWithTypeArguments(node) {
        return factory.updateExpressionWithTypeArguments(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isLeftHandSideExpression)), 
        /*typeArguments*/ undefined);
    }
    /**
     * Determines whether to emit a function-like declaration. We should not emit the
     * declaration if it does not have a body.
     *
     * @param node The declaration node.
     */
    function shouldEmitFunctionLikeDeclaration(node) {
        return !(0, ts_js_1.nodeIsMissing)(node.body);
    }
    function visitPropertyDeclaration(node, parent) {
        const isAmbient = node.flags & 33554432 /* NodeFlags.Ambient */ || (0, ts_js_1.hasSyntacticModifier)(node, 64 /* ModifierFlags.Abstract */);
        if (isAmbient && !(legacyDecorators && (0, ts_js_1.hasDecorators)(node))) {
            return undefined;
        }
        let modifiers = (0, ts_js_1.isClassLike)(parent) ? !isAmbient ?
            (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, modifierElidingVisitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, decoratorElidingVisitor, ts_js_1.isModifierLike);
        modifiers = injectClassElementTypeMetadata(modifiers, node, parent);
        // Preserve a `declare x` property with decorators to be handled by the decorators transform
        if (isAmbient) {
            return factory.updatePropertyDeclaration(node, (0, ts_js_1.concatenate)(modifiers, factory.createModifiersFromModifierFlags(128 /* ModifierFlags.Ambient */)), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isPropertyName)), 
            /*questionOrExclamationToken*/ undefined, 
            /*type*/ undefined, 
            /*initializer*/ undefined);
        }
        return factory.updatePropertyDeclaration(node, modifiers, visitPropertyNameOfClassElement(node), 
        /*questionOrExclamationToken*/ undefined, 
        /*type*/ undefined, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression));
    }
    function visitConstructor(node) {
        if (!shouldEmitFunctionLikeDeclaration(node)) {
            return undefined;
        }
        return factory.updateConstructorDeclaration(node, 
        /*modifiers*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), transformConstructorBody(node.body, node));
    }
    function transformConstructorBodyWorker(statementsOut, statementsIn, statementOffset, superPath, superPathDepth, initializerStatements) {
        const superStatementIndex = superPath[superPathDepth];
        const superStatement = statementsIn[superStatementIndex];
        (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, statementOffset, superStatementIndex - statementOffset));
        if ((0, ts_js_1.isTryStatement)(superStatement)) {
            const tryBlockStatements = [];
            transformConstructorBodyWorker(tryBlockStatements, superStatement.tryBlock.statements, 
            /*statementOffset*/ 0, superPath, superPathDepth + 1, initializerStatements);
            const tryBlockStatementsArray = factory.createNodeArray(tryBlockStatements);
            (0, ts_js_1.setTextRange)(tryBlockStatementsArray, superStatement.tryBlock.statements);
            statementsOut.push(factory.updateTryStatement(superStatement, factory.updateBlock(superStatement.tryBlock, tryBlockStatements), (0, ts_js_1.visitNode)(superStatement.catchClause, visitor, ts_js_1.isCatchClause), (0, ts_js_1.visitNode)(superStatement.finallyBlock, visitor, ts_js_1.isBlock)));
        }
        else {
            (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, superStatementIndex, 1));
            (0, ts_js_1.addRange)(statementsOut, initializerStatements);
        }
        (0, ts_js_1.addRange)(statementsOut, (0, ts_js_1.visitNodes)(statementsIn, visitor, ts_js_1.isStatement, superStatementIndex + 1));
    }
    function transformConstructorBody(body, constructor) {
        const parametersWithPropertyAssignments = constructor &&
            (0, ts_js_1.filter)(constructor.parameters, p => (0, ts_js_1.isParameterPropertyDeclaration)(p, constructor));
        if (!(0, ts_js_1.some)(parametersWithPropertyAssignments)) {
            return (0, ts_js_1.visitFunctionBody)(body, visitor, context);
        }
        let statements = [];
        resumeLexicalEnvironment();
        const prologueStatementCount = factory.copyPrologue(body.statements, statements, /*ensureUseStrict*/ false, visitor);
        const superPath = (0, ts_js_1.findSuperStatementIndexPath)(body.statements, prologueStatementCount);
        // Transform parameters into property assignments. Transforms this:
        //
        //  constructor (public x, public y) {
        //  }
        //
        // Into this:
        //
        //  constructor (x, y) {
        //      this.x = x;
        //      this.y = y;
        //  }
        //
        const parameterPropertyAssignments = (0, ts_js_1.mapDefined)(parametersWithPropertyAssignments, transformParameterWithPropertyAssignment);
        if (superPath.length) {
            transformConstructorBodyWorker(statements, body.statements, prologueStatementCount, superPath, /*superPathDepth*/ 0, parameterPropertyAssignments);
        }
        else {
            (0, ts_js_1.addRange)(statements, parameterPropertyAssignments);
            (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(body.statements, visitor, ts_js_1.isStatement, prologueStatementCount));
        }
        // End the lexical environment.
        statements = factory.mergeLexicalEnvironment(statements, endLexicalEnvironment());
        const block = factory.createBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(statements), body.statements), /*multiLine*/ true);
        (0, ts_js_1.setTextRange)(block, /*location*/ body);
        (0, ts_js_1.setOriginalNode)(block, body);
        return block;
    }
    /**
     * Transforms a parameter into a property assignment statement.
     *
     * @param node The parameter declaration.
     */
    function transformParameterWithPropertyAssignment(node) {
        const name = node.name;
        if (!(0, ts_js_1.isIdentifier)(name)) {
            return undefined;
        }
        // TODO(rbuckton): Does this need to be parented?
        const propertyName = (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(name), name), name.parent);
        (0, ts_js_1.setEmitFlags)(propertyName, 3072 /* EmitFlags.NoComments */ | 96 /* EmitFlags.NoSourceMap */);
        // TODO(rbuckton): Does this need to be parented?
        const localName = (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(name), name), name.parent);
        (0, ts_js_1.setEmitFlags)(localName, 3072 /* EmitFlags.NoComments */);
        return (0, ts_js_1.startOnNewLine)((0, ts_js_1.removeAllComments)((0, ts_js_1.setTextRange)((0, ts_js_1.setOriginalNode)(factory.createExpressionStatement(factory.createAssignment((0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.createThis(), propertyName), node.name), localName)), node), (0, ts_js_1.moveRangePos)(node, -1))));
    }
    function visitMethodDeclaration(node, parent) {
        if (!(node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */)) {
            return node;
        }
        if (!shouldEmitFunctionLikeDeclaration(node)) {
            return undefined;
        }
        let modifiers = (0, ts_js_1.isClassLike)(parent) ?
            (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, decoratorElidingVisitor, ts_js_1.isModifierLike);
        modifiers = injectClassElementTypeMetadata(modifiers, node, parent);
        return factory.updateMethodDeclaration(node, modifiers, node.asteriskToken, visitPropertyNameOfClassElement(node), 
        /*questionToken*/ undefined, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, (0, ts_js_1.visitFunctionBody)(node.body, visitor, context));
    }
    /**
     * Determines whether to emit an accessor declaration. We should not emit the
     * declaration if it does not have a body and is abstract.
     *
     * @param node The declaration node.
     */
    function shouldEmitAccessorDeclaration(node) {
        return !((0, ts_js_1.nodeIsMissing)(node.body) && (0, ts_js_1.hasSyntacticModifier)(node, 64 /* ModifierFlags.Abstract */));
    }
    function visitGetAccessor(node, parent) {
        if (!(node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */)) {
            return node;
        }
        if (!shouldEmitAccessorDeclaration(node)) {
            return undefined;
        }
        let modifiers = (0, ts_js_1.isClassLike)(parent) ?
            (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, decoratorElidingVisitor, ts_js_1.isModifierLike);
        modifiers = injectClassElementTypeMetadata(modifiers, node, parent);
        return factory.updateGetAccessorDeclaration(node, modifiers, visitPropertyNameOfClassElement(node), (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, (0, ts_js_1.visitFunctionBody)(node.body, visitor, context) || factory.createBlock([]));
    }
    function visitSetAccessor(node, parent) {
        if (!(node.transformFlags & 1 /* TransformFlags.ContainsTypeScript */)) {
            return node;
        }
        if (!shouldEmitAccessorDeclaration(node)) {
            return undefined;
        }
        let modifiers = (0, ts_js_1.isClassLike)(parent) ?
            (0, ts_js_1.visitNodes)(node.modifiers, visitor, ts_js_1.isModifierLike) :
            (0, ts_js_1.visitNodes)(node.modifiers, decoratorElidingVisitor, ts_js_1.isModifierLike);
        modifiers = injectClassElementTypeMetadata(modifiers, node, parent);
        return factory.updateSetAccessorDeclaration(node, modifiers, visitPropertyNameOfClassElement(node), (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), (0, ts_js_1.visitFunctionBody)(node.body, visitor, context) || factory.createBlock([]));
    }
    function visitFunctionDeclaration(node) {
        if (!shouldEmitFunctionLikeDeclaration(node)) {
            return factory.createNotEmittedStatement(node);
        }
        const updated = factory.updateFunctionDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, (0, ts_js_1.visitFunctionBody)(node.body, visitor, context) || factory.createBlock([]));
        if (isExportOfNamespace(node)) {
            const statements = [updated];
            addExportMemberAssignment(statements, node);
            return statements;
        }
        return updated;
    }
    function visitFunctionExpression(node) {
        if (!shouldEmitFunctionLikeDeclaration(node)) {
            return factory.createOmittedExpression();
        }
        const updated = factory.updateFunctionExpression(node, (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), node.asteriskToken, node.name, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, (0, ts_js_1.visitFunctionBody)(node.body, visitor, context) || factory.createBlock([]));
        return updated;
    }
    function visitArrowFunction(node) {
        const updated = factory.updateArrowFunction(node, (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), 
        /*typeParameters*/ undefined, (0, ts_js_1.visitParameterList)(node.parameters, visitor, context), 
        /*type*/ undefined, node.equalsGreaterThanToken, (0, ts_js_1.visitFunctionBody)(node.body, visitor, context));
        return updated;
    }
    function visitParameter(node) {
        if ((0, ts_js_1.parameterIsThisKeyword)(node)) {
            return undefined;
        }
        const updated = factory.updateParameterDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, node => (0, ts_js_1.isDecorator)(node) ? visitor(node) : undefined, ts_js_1.isModifierLike), node.dotDotDotToken, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isBindingName)), 
        /*questionToken*/ undefined, 
        /*type*/ undefined, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression));
        if (updated !== node) {
            // While we emit the source map for the node after skipping decorators and modifiers,
            // we need to emit the comments for the original range.
            (0, ts_js_1.setCommentRange)(updated, node);
            (0, ts_js_1.setTextRange)(updated, (0, ts_js_1.moveRangePastModifiers)(node));
            (0, ts_js_1.setSourceMapRange)(updated, (0, ts_js_1.moveRangePastModifiers)(node));
            (0, ts_js_1.setEmitFlags)(updated.name, 64 /* EmitFlags.NoTrailingSourceMap */);
        }
        return updated;
    }
    function visitVariableStatement(node) {
        if (isExportOfNamespace(node)) {
            const variables = (0, ts_js_1.getInitializedVariables)(node.declarationList);
            if (variables.length === 0) {
                // elide statement if there are no initialized variables.
                return undefined;
            }
            return (0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.inlineExpressions((0, ts_js_1.map)(variables, transformInitializedVariable))), node);
        }
        else {
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
    }
    function transformInitializedVariable(node) {
        const name = node.name;
        if ((0, ts_js_1.isBindingPattern)(name)) {
            return (0, ts_js_1.flattenDestructuringAssignment)(node, visitor, context, 0 /* FlattenLevel.All */, 
            /*needsValue*/ false, createNamespaceExportExpression);
        }
        else {
            return (0, ts_js_1.setTextRange)(factory.createAssignment(getNamespaceMemberNameWithSourceMapsAndWithoutComments(name), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression))), 
            /*location*/ node);
        }
    }
    function visitVariableDeclaration(node) {
        const updated = factory.updateVariableDeclaration(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isBindingName)), 
        /*exclamationToken*/ undefined, 
        /*type*/ undefined, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression));
        if (node.type) {
            (0, ts_js_1.setTypeNode)(updated.name, node.type);
        }
        return updated;
    }
    function visitParenthesizedExpression(node) {
        const innerExpression = (0, ts_js_1.skipOuterExpressions)(node.expression, ~(38 /* OuterExpressionKinds.Assertions */ | 16 /* OuterExpressionKinds.ExpressionsWithTypeArguments */));
        if ((0, ts_js_1.isAssertionExpression)(innerExpression) || (0, ts_js_1.isSatisfiesExpression)(innerExpression)) {
            // Make sure we consider all nested cast expressions, e.g.:
            // (<any><number><any>-A).x;
            const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
            ts_js_1.Debug.assert(expression);
            // We have an expression of the form: (<Type>SubExpr). Emitting this as (SubExpr)
            // is really not desirable. We would like to emit the subexpression as-is. Omitting
            // the parentheses, however, could cause change in the semantics of the generated
            // code if the casted expression has a lower precedence than the rest of the
            // expression.
            //
            // To preserve comments, we return a "PartiallyEmittedExpression" here which will
            // preserve the position information of the original expression.
            //
            // Due to the auto-parenthesization rules used by the visitor and factory functions
            // we can safely elide the parentheses here, as a new synthetic
            // ParenthesizedExpression will be inserted if we remove parentheses too
            // aggressively.
            //
            // If there are leading comments on the expression itself, the emitter will handle ASI
            // for return, throw, and yield by re-introducing parenthesis during emit on an as-need
            // basis.
            return factory.createPartiallyEmittedExpression(expression, node);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    function visitAssertionExpression(node) {
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        ts_js_1.Debug.assert(expression);
        return factory.createPartiallyEmittedExpression(expression, node);
    }
    function visitNonNullExpression(node) {
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isLeftHandSideExpression);
        ts_js_1.Debug.assert(expression);
        return factory.createPartiallyEmittedExpression(expression, node);
    }
    function visitSatisfiesExpression(node) {
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        ts_js_1.Debug.assert(expression);
        return factory.createPartiallyEmittedExpression(expression, node);
    }
    function visitCallExpression(node) {
        return factory.updateCallExpression(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), 
        /*typeArguments*/ undefined, (0, ts_js_1.visitNodes)(node.arguments, visitor, ts_js_1.isExpression));
    }
    function visitNewExpression(node) {
        return factory.updateNewExpression(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression)), 
        /*typeArguments*/ undefined, (0, ts_js_1.visitNodes)(node.arguments, visitor, ts_js_1.isExpression));
    }
    function visitTaggedTemplateExpression(node) {
        return factory.updateTaggedTemplateExpression(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.tag, visitor, ts_js_1.isExpression)), 
        /*typeArguments*/ undefined, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.template, visitor, ts_js_1.isTemplateLiteral)));
    }
    function visitJsxSelfClosingElement(node) {
        return factory.updateJsxSelfClosingElement(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.tagName, visitor, ts_js_1.isJsxTagNameExpression)), 
        /*typeArguments*/ undefined, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.attributes, visitor, ts_js_1.isJsxAttributes)));
    }
    function visitJsxJsxOpeningElement(node) {
        return factory.updateJsxOpeningElement(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.tagName, visitor, ts_js_1.isJsxTagNameExpression)), 
        /*typeArguments*/ undefined, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.attributes, visitor, ts_js_1.isJsxAttributes)));
    }
    /**
     * Determines whether to emit an enum declaration.
     *
     * @param node The enum declaration node.
     */
    function shouldEmitEnumDeclaration(node) {
        return !(0, ts_js_1.isEnumConst)(node)
            || (0, ts_js_1.shouldPreserveConstEnums)(compilerOptions);
    }
    /**
     * Visits an enum declaration.
     *
     * This function will be called any time a TypeScript enum is encountered.
     *
     * @param node The enum declaration node.
     */
    function visitEnumDeclaration(node) {
        if (!shouldEmitEnumDeclaration(node)) {
            return factory.createNotEmittedStatement(node);
        }
        const statements = [];
        // We request to be advised when the printer is about to print this node. This allows
        // us to set up the correct state for later substitutions.
        let emitFlags = 4 /* EmitFlags.AdviseOnEmitNode */;
        // If needed, we should emit a variable declaration for the enum. If we emit
        // a leading variable declaration, we should not emit leading comments for the
        // enum body.
        const varAdded = addVarForEnumOrModuleDeclaration(statements, node);
        if (varAdded) {
            // We should still emit the comments if we are emitting a system module.
            if (moduleKind !== ts_js_1.ModuleKind.System || currentLexicalScope !== currentSourceFile) {
                emitFlags |= 1024 /* EmitFlags.NoLeadingComments */;
            }
        }
        // `parameterName` is the declaration name used inside of the enum.
        const parameterName = getNamespaceParameterName(node);
        // `containerName` is the expression used inside of the enum for assignments.
        const containerName = getNamespaceContainerName(node);
        // `exportName` is the expression used within this node's container for any exported references.
        const exportName = isExportOfNamespace(node)
            ? factory.getExternalModuleOrNamespaceExportName(currentNamespaceContainerName, node, /*allowComments*/ false, /*allowSourceMaps*/ true)
            : factory.getDeclarationName(node, /*allowComments*/ false, /*allowSourceMaps*/ true);
        //  x || (x = {})
        //  exports.x || (exports.x = {})
        let moduleArg = factory.createLogicalOr(exportName, factory.createAssignment(exportName, factory.createObjectLiteralExpression()));
        if (isExportOfNamespace(node)) {
            // `localName` is the expression used within this node's containing scope for any local references.
            const localName = factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ true);
            //  x = (exports.x || (exports.x = {}))
            moduleArg = factory.createAssignment(localName, moduleArg);
        }
        //  (function (x) {
        //      x[x["y"] = 0] = "y";
        //      ...
        //  })(x || (x = {}));
        const enumStatement = factory.createExpressionStatement(factory.createCallExpression(factory.createFunctionExpression(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, parameterName)], 
        /*type*/ undefined, transformEnumBody(node, containerName)), 
        /*typeArguments*/ undefined, [moduleArg]));
        (0, ts_js_1.setOriginalNode)(enumStatement, node);
        if (varAdded) {
            // If a variable was added, synthetic comments are emitted on it, not on the moduleStatement.
            (0, ts_js_1.setSyntheticLeadingComments)(enumStatement, undefined);
            (0, ts_js_1.setSyntheticTrailingComments)(enumStatement, undefined);
        }
        (0, ts_js_1.setTextRange)(enumStatement, node);
        (0, ts_js_1.addEmitFlags)(enumStatement, emitFlags);
        statements.push(enumStatement);
        return statements;
    }
    /**
     * Transforms the body of an enum declaration.
     *
     * @param node The enum declaration node.
     */
    function transformEnumBody(node, localName) {
        const savedCurrentNamespaceLocalName = currentNamespaceContainerName;
        currentNamespaceContainerName = localName;
        const statements = [];
        startLexicalEnvironment();
        const members = (0, ts_js_1.map)(node.members, transformEnumMember);
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        (0, ts_js_1.addRange)(statements, members);
        currentNamespaceContainerName = savedCurrentNamespaceLocalName;
        return factory.createBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(statements), /*location*/ node.members), 
        /*multiLine*/ true);
    }
    /**
     * Transforms an enum member into a statement.
     *
     * @param member The enum member node.
     */
    function transformEnumMember(member) {
        // enums don't support computed properties
        // we pass false as 'generateNameForComputedPropertyName' for a backward compatibility purposes
        // old emitter always generate 'expression' part of the name as-is.
        const name = getExpressionForPropertyName(member, /*generateNameForComputedPropertyName*/ false);
        const evaluated = resolver.getEnumMemberValue(member);
        const valueExpression = transformEnumMemberDeclarationValue(member, evaluated?.value);
        const innerAssignment = factory.createAssignment(factory.createElementAccessExpression(currentNamespaceContainerName, name), valueExpression);
        const outerAssignment = typeof evaluated?.value === "string" || evaluated?.isSyntacticallyString ?
            innerAssignment :
            factory.createAssignment(factory.createElementAccessExpression(currentNamespaceContainerName, innerAssignment), name);
        return (0, ts_js_1.setTextRange)(factory.createExpressionStatement((0, ts_js_1.setTextRange)(outerAssignment, member)), member);
    }
    /**
     * Transforms the value of an enum member.
     *
     * @param member The enum member node.
     */
    function transformEnumMemberDeclarationValue(member, constantValue) {
        if (constantValue !== undefined) {
            return typeof constantValue === "string" ? factory.createStringLiteral(constantValue) :
                constantValue < 0 ? factory.createPrefixUnaryExpression(41 /* SyntaxKind.MinusToken */, factory.createNumericLiteral(-constantValue)) :
                    factory.createNumericLiteral(constantValue);
        }
        else {
            enableSubstitutionForNonQualifiedEnumMembers();
            if (member.initializer) {
                return ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(member.initializer, visitor, ts_js_1.isExpression));
            }
            else {
                return factory.createVoidZero();
            }
        }
    }
    /**
     * Determines whether to elide a module declaration.
     *
     * @param node The module declaration node.
     */
    function shouldEmitModuleDeclaration(nodeIn) {
        const node = (0, ts_js_1.getParseTreeNode)(nodeIn, ts_js_1.isModuleDeclaration);
        if (!node) {
            // If we can't find a parse tree node, assume the node is instantiated.
            return true;
        }
        return (0, ts_js_1.isInstantiatedModule)(node, (0, ts_js_1.shouldPreserveConstEnums)(compilerOptions));
    }
    /**
     * Records that a declaration was emitted in the current scope, if it was the first
     * declaration for the provided symbol.
     */
    function recordEmittedDeclarationInScope(node) {
        if (!currentScopeFirstDeclarationsOfName) {
            currentScopeFirstDeclarationsOfName = new Map();
        }
        const name = declaredNameInScope(node);
        if (!currentScopeFirstDeclarationsOfName.has(name)) {
            currentScopeFirstDeclarationsOfName.set(name, node);
        }
    }
    /**
     * Determines whether a declaration is the first declaration with
     * the same name emitted in the current scope.
     */
    function isFirstEmittedDeclarationInScope(node) {
        if (currentScopeFirstDeclarationsOfName) {
            const name = declaredNameInScope(node);
            return currentScopeFirstDeclarationsOfName.get(name) === node;
        }
        return true;
    }
    function declaredNameInScope(node) {
        ts_js_1.Debug.assertNode(node.name, ts_js_1.isIdentifier);
        return node.name.escapedText;
    }
    /**
     * Adds a leading VariableStatement for a enum or module declaration.
     */
    function addVarForEnumOrModuleDeclaration(statements, node) {
        // Emit a variable statement for the module. We emit top-level enums as a `var`
        // declaration to avoid static errors in global scripts scripts due to redeclaration.
        // enums in any other scope are emitted as a `let` declaration.
        const varDecl = factory.createVariableDeclaration(factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ true));
        const varFlags = currentLexicalScope.kind === 308 /* SyntaxKind.SourceFile */ ? 0 /* NodeFlags.None */ : 1 /* NodeFlags.Let */;
        const statement = factory.createVariableStatement((0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), factory.createVariableDeclarationList([varDecl], varFlags));
        (0, ts_js_1.setOriginalNode)(varDecl, node);
        (0, ts_js_1.setSyntheticLeadingComments)(varDecl, undefined);
        (0, ts_js_1.setSyntheticTrailingComments)(varDecl, undefined);
        (0, ts_js_1.setOriginalNode)(statement, node);
        recordEmittedDeclarationInScope(node);
        if (isFirstEmittedDeclarationInScope(node)) {
            // Adjust the source map emit to match the old emitter.
            if (node.kind === 267 /* SyntaxKind.EnumDeclaration */) {
                (0, ts_js_1.setSourceMapRange)(statement.declarationList, node);
            }
            else {
                (0, ts_js_1.setSourceMapRange)(statement, node);
            }
            // Trailing comments for module declaration should be emitted after the function closure
            // instead of the variable statement:
            //
            //     /** Module comment*/
            //     module m1 {
            //         function foo4Export() {
            //         }
            //     } // trailing comment module
            //
            // Should emit:
            //
            //     /** Module comment*/
            //     var m1;
            //     (function (m1) {
            //         function foo4Export() {
            //         }
            //     })(m1 || (m1 = {})); // trailing comment module
            //
            (0, ts_js_1.setCommentRange)(statement, node);
            (0, ts_js_1.addEmitFlags)(statement, 2048 /* EmitFlags.NoTrailingComments */);
            statements.push(statement);
            return true;
        }
        // For an EnumDeclaration or ModuleDeclaration that merges with a preceeding
        // declaration we do not emit a leading variable declaration.
        return false;
    }
    /**
     * Visits a module declaration node.
     *
     * This function will be called any time a TypeScript namespace (ModuleDeclaration) is encountered.
     *
     * @param node The module declaration node.
     */
    function visitModuleDeclaration(node) {
        if (!shouldEmitModuleDeclaration(node)) {
            return factory.createNotEmittedStatement(node);
        }
        ts_js_1.Debug.assertNode(node.name, ts_js_1.isIdentifier, "A TypeScript namespace should have an Identifier name.");
        enableSubstitutionForNamespaceExports();
        const statements = [];
        // We request to be advised when the printer is about to print this node. This allows
        // us to set up the correct state for later substitutions.
        let emitFlags = 4 /* EmitFlags.AdviseOnEmitNode */;
        // If needed, we should emit a variable declaration for the module. If we emit
        // a leading variable declaration, we should not emit leading comments for the
        // module body.
        const varAdded = addVarForEnumOrModuleDeclaration(statements, node);
        if (varAdded) {
            // We should still emit the comments if we are emitting a system module.
            if (moduleKind !== ts_js_1.ModuleKind.System || currentLexicalScope !== currentSourceFile) {
                emitFlags |= 1024 /* EmitFlags.NoLeadingComments */;
            }
        }
        // `parameterName` is the declaration name used inside of the namespace.
        const parameterName = getNamespaceParameterName(node);
        // `containerName` is the expression used inside of the namespace for exports.
        const containerName = getNamespaceContainerName(node);
        // `exportName` is the expression used within this node's container for any exported references.
        const exportName = isExportOfNamespace(node)
            ? factory.getExternalModuleOrNamespaceExportName(currentNamespaceContainerName, node, /*allowComments*/ false, /*allowSourceMaps*/ true)
            : factory.getDeclarationName(node, /*allowComments*/ false, /*allowSourceMaps*/ true);
        //  x || (x = {})
        //  exports.x || (exports.x = {})
        let moduleArg = factory.createLogicalOr(exportName, factory.createAssignment(exportName, factory.createObjectLiteralExpression()));
        if (isExportOfNamespace(node)) {
            // `localName` is the expression used within this node's containing scope for any local references.
            const localName = factory.getLocalName(node, /*allowComments*/ false, /*allowSourceMaps*/ true);
            //  x = (exports.x || (exports.x = {}))
            moduleArg = factory.createAssignment(localName, moduleArg);
        }
        //  (function (x_1) {
        //      x_1.y = ...;
        //  })(x || (x = {}));
        const moduleStatement = factory.createExpressionStatement(factory.createCallExpression(factory.createFunctionExpression(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, parameterName)], 
        /*type*/ undefined, transformModuleBody(node, containerName)), 
        /*typeArguments*/ undefined, [moduleArg]));
        (0, ts_js_1.setOriginalNode)(moduleStatement, node);
        if (varAdded) {
            // If a variable was added, synthetic comments are emitted on it, not on the moduleStatement.
            (0, ts_js_1.setSyntheticLeadingComments)(moduleStatement, undefined);
            (0, ts_js_1.setSyntheticTrailingComments)(moduleStatement, undefined);
        }
        (0, ts_js_1.setTextRange)(moduleStatement, node);
        (0, ts_js_1.addEmitFlags)(moduleStatement, emitFlags);
        statements.push(moduleStatement);
        return statements;
    }
    /**
     * Transforms the body of a module declaration.
     *
     * @param node The module declaration node.
     */
    function transformModuleBody(node, namespaceLocalName) {
        const savedCurrentNamespaceContainerName = currentNamespaceContainerName;
        const savedCurrentNamespace = currentNamespace;
        const savedCurrentScopeFirstDeclarationsOfName = currentScopeFirstDeclarationsOfName;
        currentNamespaceContainerName = namespaceLocalName;
        currentNamespace = node;
        currentScopeFirstDeclarationsOfName = undefined;
        const statements = [];
        startLexicalEnvironment();
        let statementsLocation;
        let blockLocation;
        if (node.body) {
            if (node.body.kind === 269 /* SyntaxKind.ModuleBlock */) {
                saveStateAndInvoke(node.body, body => (0, ts_js_1.addRange)(statements, (0, ts_js_1.visitNodes)(body.statements, namespaceElementVisitor, ts_js_1.isStatement)));
                statementsLocation = node.body.statements;
                blockLocation = node.body;
            }
            else {
                const result = visitModuleDeclaration(node.body);
                if (result) {
                    if ((0, ts_js_1.isArray)(result)) {
                        (0, ts_js_1.addRange)(statements, result);
                    }
                    else {
                        statements.push(result);
                    }
                }
                const moduleBlock = getInnerMostModuleDeclarationFromDottedModule(node).body;
                statementsLocation = (0, ts_js_1.moveRangePos)(moduleBlock.statements, -1);
            }
        }
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        currentNamespaceContainerName = savedCurrentNamespaceContainerName;
        currentNamespace = savedCurrentNamespace;
        currentScopeFirstDeclarationsOfName = savedCurrentScopeFirstDeclarationsOfName;
        const block = factory.createBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(statements), 
        /*location*/ statementsLocation), 
        /*multiLine*/ true);
        (0, ts_js_1.setTextRange)(block, blockLocation);
        // namespace hello.hi.world {
        //      function foo() {}
        //
        //      // TODO, blah
        // }
        //
        // should be emitted as
        //
        // var hello;
        // (function (hello) {
        //     var hi;
        //     (function (hi) {
        //         var world;
        //         (function (world) {
        //             function foo() { }
        //             // TODO, blah
        //         })(world = hi.world || (hi.world = {}));
        //     })(hi = hello.hi || (hello.hi = {}));
        // })(hello || (hello = {}));
        // We only want to emit comment on the namespace which contains block body itself, not the containing namespaces.
        if (!node.body || node.body.kind !== 269 /* SyntaxKind.ModuleBlock */) {
            (0, ts_js_1.setEmitFlags)(block, (0, ts_js_1.getEmitFlags)(block) | 3072 /* EmitFlags.NoComments */);
        }
        return block;
    }
    function getInnerMostModuleDeclarationFromDottedModule(moduleDeclaration) {
        if (moduleDeclaration.body.kind === 268 /* SyntaxKind.ModuleDeclaration */) {
            const recursiveInnerModule = getInnerMostModuleDeclarationFromDottedModule(moduleDeclaration.body);
            return recursiveInnerModule || moduleDeclaration.body;
        }
    }
    /**
     * Visits an import declaration, eliding it if it is type-only or if it has an import clause that may be elided.
     *
     * @param node The import declaration node.
     */
    function visitImportDeclaration(node) {
        if (!node.importClause) {
            // Do not elide a side-effect only import declaration.
            //  import "foo";
            return node;
        }
        if (node.importClause.isTypeOnly) {
            // Always elide type-only imports
            return undefined;
        }
        // Elide the declaration if the import clause was elided.
        const importClause = (0, ts_js_1.visitNode)(node.importClause, visitImportClause, ts_js_1.isImportClause);
        return importClause
            ? factory.updateImportDeclaration(node, 
            /*modifiers*/ undefined, importClause, node.moduleSpecifier, node.attributes)
            : undefined;
    }
    /**
     * Visits an import clause, eliding it if its `name` and `namedBindings` may both be elided.
     *
     * @param node The import clause node.
     */
    function visitImportClause(node) {
        ts_js_1.Debug.assert(node.phaseModifier !== 156 /* SyntaxKind.TypeKeyword */);
        // Elide the import clause if we elide both its name and its named bindings.
        const name = shouldEmitAliasDeclaration(node) ? node.name : undefined;
        const namedBindings = (0, ts_js_1.visitNode)(node.namedBindings, visitNamedImportBindings, ts_js_1.isNamedImportBindings);
        return (name || namedBindings) ? factory.updateImportClause(node, node.phaseModifier, name, namedBindings) : undefined;
    }
    /**
     * Visits named import bindings, eliding them if their targets, their references, and the compilation settings allow.
     *
     * @param node The named import bindings node.
     */
    function visitNamedImportBindings(node) {
        if (node.kind === 275 /* SyntaxKind.NamespaceImport */) {
            // Elide a namespace import if it is not referenced.
            return shouldEmitAliasDeclaration(node) ? node : undefined;
        }
        else {
            // Elide named imports if all of its import specifiers are elided and settings allow.
            const allowEmpty = compilerOptions.verbatimModuleSyntax;
            const elements = (0, ts_js_1.visitNodes)(node.elements, visitImportSpecifier, ts_js_1.isImportSpecifier);
            return allowEmpty || (0, ts_js_1.some)(elements) ? factory.updateNamedImports(node, elements) : undefined;
        }
    }
    /**
     * Visits an import specifier, eliding it if its target, its references, and the compilation settings allow.
     *
     * @param node The import specifier node.
     */
    function visitImportSpecifier(node) {
        return !node.isTypeOnly && shouldEmitAliasDeclaration(node) ? node : undefined;
    }
    /**
     * Visits an export assignment, eliding it if it does not contain a clause that resolves
     * to a value.
     *
     * @param node The export assignment node.
     */
    function visitExportAssignment(node) {
        // Elide the export assignment if it does not reference a value.
        return compilerOptions.verbatimModuleSyntax || resolver.isValueAliasDeclaration(node)
            ? (0, ts_js_1.visitEachChild)(node, visitor, context)
            : undefined;
    }
    /**
     * Visits an export declaration, eliding it if it does not contain a clause that resolves to a value.
     *
     * @param node The export declaration node.
     */
    function visitExportDeclaration(node) {
        if (node.isTypeOnly) {
            return undefined;
        }
        if (!node.exportClause || (0, ts_js_1.isNamespaceExport)(node.exportClause)) {
            // never elide `export <whatever> from <whereever>` declarations -
            // they should be kept for sideffects/untyped exports, even when the
            // type checker doesn't know about any exports
            return factory.updateExportDeclaration(node, node.modifiers, node.isTypeOnly, node.exportClause, node.moduleSpecifier, node.attributes);
        }
        // Elide the export declaration if all of its named exports are elided.
        const allowEmpty = !!compilerOptions.verbatimModuleSyntax;
        const exportClause = (0, ts_js_1.visitNode)(node.exportClause, (bindings) => visitNamedExportBindings(bindings, allowEmpty), ts_js_1.isNamedExportBindings);
        return exportClause
            ? factory.updateExportDeclaration(node, 
            /*modifiers*/ undefined, node.isTypeOnly, exportClause, node.moduleSpecifier, node.attributes)
            : undefined;
    }
    /**
     * Visits named exports, eliding it if it does not contain an export specifier that
     * resolves to a value.
     *
     * @param node The named exports node.
     */
    function visitNamedExports(node, allowEmpty) {
        // Elide the named exports if all of its export specifiers were elided.
        const elements = (0, ts_js_1.visitNodes)(node.elements, visitExportSpecifier, ts_js_1.isExportSpecifier);
        return allowEmpty || (0, ts_js_1.some)(elements) ? factory.updateNamedExports(node, elements) : undefined;
    }
    function visitNamespaceExports(node) {
        return factory.updateNamespaceExport(node, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.name, visitor, ts_js_1.isIdentifier)));
    }
    function visitNamedExportBindings(node, allowEmpty) {
        return (0, ts_js_1.isNamespaceExport)(node) ? visitNamespaceExports(node) : visitNamedExports(node, allowEmpty);
    }
    /**
     * Visits an export specifier, eliding it if it does not resolve to a value.
     *
     * @param node The export specifier node.
     */
    function visitExportSpecifier(node) {
        // Elide an export specifier if it does not reference a value.
        return !node.isTypeOnly && (compilerOptions.verbatimModuleSyntax || resolver.isValueAliasDeclaration(node)) ? node : undefined;
    }
    /**
     * Determines whether to emit an import equals declaration.
     *
     * @param node The import equals declaration node.
     */
    function shouldEmitImportEqualsDeclaration(node) {
        // preserve old compiler's behavior: emit 'var' for import declaration (even if we do not consider them referenced) when
        // - current file is not external module
        // - import declaration is top level and target is value imported by entity name
        return shouldEmitAliasDeclaration(node)
            || (!(0, ts_js_1.isExternalModule)(currentSourceFile)
                && resolver.isTopLevelValueImportEqualsWithEntityName(node));
    }
    /**
     * Visits an import equals declaration.
     *
     * @param node The import equals declaration node.
     */
    function visitImportEqualsDeclaration(node) {
        // Always elide type-only imports
        if (node.isTypeOnly) {
            return undefined;
        }
        if ((0, ts_js_1.isExternalModuleImportEqualsDeclaration)(node)) {
            if (!shouldEmitAliasDeclaration(node)) {
                return undefined;
            }
            return (0, ts_js_1.visitEachChild)(node, visitor, context);
        }
        if (!shouldEmitImportEqualsDeclaration(node)) {
            return undefined;
        }
        const moduleReference = (0, ts_js_1.createExpressionFromEntityName)(factory, node.moduleReference);
        (0, ts_js_1.setEmitFlags)(moduleReference, 3072 /* EmitFlags.NoComments */ | 4096 /* EmitFlags.NoNestedComments */);
        if (isNamedExternalModuleExport(node) || !isExportOfNamespace(node)) {
            //  export var ${name} = ${moduleReference};
            //  var ${name} = ${moduleReference};
            return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createVariableStatement((0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifier), factory.createVariableDeclarationList([
                (0, ts_js_1.setOriginalNode)(factory.createVariableDeclaration(node.name, 
                /*exclamationToken*/ undefined, 
                /*type*/ undefined, moduleReference), node),
            ])), node), node);
        }
        else {
            // exports.${name} = ${moduleReference};
            return (0, ts_js_1.setOriginalNode)(createNamespaceExport(node.name, moduleReference, node), node);
        }
    }
    /**
     * Gets a value indicating whether the node is exported from a namespace.
     *
     * @param node The node to test.
     */
    function isExportOfNamespace(node) {
        return currentNamespace !== undefined && (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
    }
    /**
     * Gets a value indicating whether the node is exported from an external module.
     *
     * @param node The node to test.
     */
    function isExternalModuleExport(node) {
        return currentNamespace === undefined && (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
    }
    /**
     * Gets a value indicating whether the node is a named export from an external module.
     *
     * @param node The node to test.
     */
    function isNamedExternalModuleExport(node) {
        return isExternalModuleExport(node)
            && !(0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */);
    }
    /**
     * Gets a value indicating whether the node is the default export of an external module.
     *
     * @param node The node to test.
     */
    function isDefaultExternalModuleExport(node) {
        return isExternalModuleExport(node)
            && (0, ts_js_1.hasSyntacticModifier)(node, 2048 /* ModifierFlags.Default */);
    }
    function createExportMemberAssignmentStatement(node) {
        const expression = factory.createAssignment(factory.getExternalModuleOrNamespaceExportName(currentNamespaceContainerName, node, /*allowComments*/ false, /*allowSourceMaps*/ true), factory.getLocalName(node));
        (0, ts_js_1.setSourceMapRange)(expression, (0, ts_js_1.createRange)(node.name ? node.name.pos : node.pos, node.end));
        const statement = factory.createExpressionStatement(expression);
        (0, ts_js_1.setSourceMapRange)(statement, (0, ts_js_1.createRange)(-1, node.end));
        return statement;
    }
    function addExportMemberAssignment(statements, node) {
        statements.push(createExportMemberAssignmentStatement(node));
    }
    function createNamespaceExport(exportName, exportValue, location) {
        return (0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.createAssignment(factory.getNamespaceMemberName(currentNamespaceContainerName, exportName, /*allowComments*/ false, /*allowSourceMaps*/ true), exportValue)), location);
    }
    function createNamespaceExportExpression(exportName, exportValue, location) {
        return (0, ts_js_1.setTextRange)(factory.createAssignment(getNamespaceMemberNameWithSourceMapsAndWithoutComments(exportName), exportValue), location);
    }
    function getNamespaceMemberNameWithSourceMapsAndWithoutComments(name) {
        return factory.getNamespaceMemberName(currentNamespaceContainerName, name, /*allowComments*/ false, /*allowSourceMaps*/ true);
    }
    /**
     * Gets the declaration name used inside of a namespace or enum.
     */
    function getNamespaceParameterName(node) {
        const name = factory.getGeneratedNameForNode(node);
        (0, ts_js_1.setSourceMapRange)(name, node.name);
        return name;
    }
    /**
     * Gets the expression used to refer to a namespace or enum within the body
     * of its declaration.
     */
    function getNamespaceContainerName(node) {
        return factory.getGeneratedNameForNode(node);
    }
    function enableSubstitutionForNonQualifiedEnumMembers() {
        if ((enabledSubstitutions & 8 /* TypeScriptSubstitutionFlags.NonQualifiedEnumMembers */) === 0) {
            enabledSubstitutions |= 8 /* TypeScriptSubstitutionFlags.NonQualifiedEnumMembers */;
            context.enableSubstitution(80 /* SyntaxKind.Identifier */);
        }
    }
    function enableSubstitutionForNamespaceExports() {
        if ((enabledSubstitutions & 2 /* TypeScriptSubstitutionFlags.NamespaceExports */) === 0) {
            enabledSubstitutions |= 2 /* TypeScriptSubstitutionFlags.NamespaceExports */;
            // We need to enable substitutions for identifiers and shorthand property assignments. This allows us to
            // substitute the names of exported members of a namespace.
            context.enableSubstitution(80 /* SyntaxKind.Identifier */);
            context.enableSubstitution(305 /* SyntaxKind.ShorthandPropertyAssignment */);
            // We need to be notified when entering and exiting namespaces.
            context.enableEmitNotification(268 /* SyntaxKind.ModuleDeclaration */);
        }
    }
    function isTransformedModuleDeclaration(node) {
        return (0, ts_js_1.getOriginalNode)(node).kind === 268 /* SyntaxKind.ModuleDeclaration */;
    }
    function isTransformedEnumDeclaration(node) {
        return (0, ts_js_1.getOriginalNode)(node).kind === 267 /* SyntaxKind.EnumDeclaration */;
    }
    /**
     * Hook for node emit.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emit A callback used to emit the node in the printer.
     */
    function onEmitNode(hint, node, emitCallback) {
        const savedApplicableSubstitutions = applicableSubstitutions;
        const savedCurrentSourceFile = currentSourceFile;
        if ((0, ts_js_1.isSourceFile)(node)) {
            currentSourceFile = node;
        }
        if (enabledSubstitutions & 2 /* TypeScriptSubstitutionFlags.NamespaceExports */ && isTransformedModuleDeclaration(node)) {
            applicableSubstitutions |= 2 /* TypeScriptSubstitutionFlags.NamespaceExports */;
        }
        if (enabledSubstitutions & 8 /* TypeScriptSubstitutionFlags.NonQualifiedEnumMembers */ && isTransformedEnumDeclaration(node)) {
            applicableSubstitutions |= 8 /* TypeScriptSubstitutionFlags.NonQualifiedEnumMembers */;
        }
        previousOnEmitNode(hint, node, emitCallback);
        applicableSubstitutions = savedApplicableSubstitutions;
        currentSourceFile = savedCurrentSourceFile;
    }
    /**
     * Hooks node substitutions.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (hint === 1 /* EmitHint.Expression */) {
            return substituteExpression(node);
        }
        else if ((0, ts_js_1.isShorthandPropertyAssignment)(node)) {
            return substituteShorthandPropertyAssignment(node);
        }
        return node;
    }
    function substituteShorthandPropertyAssignment(node) {
        if (enabledSubstitutions & 2 /* TypeScriptSubstitutionFlags.NamespaceExports */) {
            const name = node.name;
            const exportedName = trySubstituteNamespaceExportedName(name);
            if (exportedName) {
                // A shorthand property with an assignment initializer is probably part of a
                // destructuring assignment
                if (node.objectAssignmentInitializer) {
                    const initializer = factory.createAssignment(exportedName, node.objectAssignmentInitializer);
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(name, initializer), node);
                }
                return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(name, exportedName), node);
            }
        }
        return node;
    }
    function substituteExpression(node) {
        switch (node.kind) {
            case 80 /* SyntaxKind.Identifier */:
                return substituteExpressionIdentifier(node);
            case 212 /* SyntaxKind.PropertyAccessExpression */:
                return substitutePropertyAccessExpression(node);
            case 213 /* SyntaxKind.ElementAccessExpression */:
                return substituteElementAccessExpression(node);
        }
        return node;
    }
    function substituteExpressionIdentifier(node) {
        return trySubstituteNamespaceExportedName(node)
            || node;
    }
    function trySubstituteNamespaceExportedName(node) {
        // If this is explicitly a local name, do not substitute.
        if (enabledSubstitutions & applicableSubstitutions && !(0, ts_js_1.isGeneratedIdentifier)(node) && !(0, ts_js_1.isLocalName)(node)) {
            // If we are nested within a namespace declaration, we may need to qualifiy
            // an identifier that is exported from a merged namespace.
            const container = resolver.getReferencedExportContainer(node, /*prefixLocals*/ false);
            if (container && container.kind !== 308 /* SyntaxKind.SourceFile */) {
                const substitute = (applicableSubstitutions & 2 /* TypeScriptSubstitutionFlags.NamespaceExports */ && container.kind === 268 /* SyntaxKind.ModuleDeclaration */) ||
                    (applicableSubstitutions & 8 /* TypeScriptSubstitutionFlags.NonQualifiedEnumMembers */ && container.kind === 267 /* SyntaxKind.EnumDeclaration */);
                if (substitute) {
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.getGeneratedNameForNode(container), node), 
                    /*location*/ node);
                }
            }
        }
        return undefined;
    }
    function substitutePropertyAccessExpression(node) {
        return substituteConstantValue(node);
    }
    function substituteElementAccessExpression(node) {
        return substituteConstantValue(node);
    }
    function safeMultiLineComment(value) {
        return value.replace(/\*\//g, "*_/");
    }
    function substituteConstantValue(node) {
        const constantValue = tryGetConstEnumValue(node);
        if (constantValue !== undefined) {
            // track the constant value on the node for the printer in mayNeedDotDotForPropertyAccess
            (0, ts_js_1.setConstantValue)(node, constantValue);
            const substitute = typeof constantValue === "string" ? factory.createStringLiteral(constantValue) :
                constantValue < 0 ? factory.createPrefixUnaryExpression(41 /* SyntaxKind.MinusToken */, factory.createNumericLiteral(-constantValue)) :
                    factory.createNumericLiteral(constantValue);
            if (!compilerOptions.removeComments) {
                const originalNode = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isAccessExpression);
                (0, ts_js_1.addSyntheticTrailingComment)(substitute, 3 /* SyntaxKind.MultiLineCommentTrivia */, ` ${safeMultiLineComment((0, ts_js_1.getTextOfNode)(originalNode))} `);
            }
            return substitute;
        }
        return node;
    }
    function tryGetConstEnumValue(node) {
        if ((0, ts_js_1.getIsolatedModules)(compilerOptions)) {
            return undefined;
        }
        return (0, ts_js_1.isPropertyAccessExpression)(node) || (0, ts_js_1.isElementAccessExpression)(node) ? resolver.getConstantValue(node) : undefined;
    }
    function shouldEmitAliasDeclaration(node) {
        return compilerOptions.verbatimModuleSyntax || (0, ts_js_1.isInJSFile)(node) || resolver.isReferencedAliasDeclaration(node);
    }
}
