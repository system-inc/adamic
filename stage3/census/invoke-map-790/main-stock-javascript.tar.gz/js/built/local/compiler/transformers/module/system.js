"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformSystemModule = transformSystemModule;
const ts_js_1 = require("../../_namespaces/ts.js");
/** @internal */
function transformSystemModule(context) {
    const { factory, startLexicalEnvironment, endLexicalEnvironment, hoistVariableDeclaration, } = context;
    const compilerOptions = context.getCompilerOptions();
    const resolver = context.getEmitResolver();
    const host = context.getEmitHost();
    const previousOnSubstituteNode = context.onSubstituteNode;
    const previousOnEmitNode = context.onEmitNode;
    context.onSubstituteNode = onSubstituteNode;
    context.onEmitNode = onEmitNode;
    context.enableSubstitution(80 /* SyntaxKind.Identifier */); // Substitutes expression identifiers for imported symbols.
    context.enableSubstitution(305 /* SyntaxKind.ShorthandPropertyAssignment */); // Substitutes expression identifiers for imported symbols
    context.enableSubstitution(227 /* SyntaxKind.BinaryExpression */); // Substitutes assignments to exported symbols.
    context.enableSubstitution(237 /* SyntaxKind.MetaProperty */); // Substitutes 'import.meta'
    context.enableEmitNotification(308 /* SyntaxKind.SourceFile */); // Restore state when substituting nodes in a file.
    const moduleInfoMap = []; // The ExternalModuleInfo for each file.
    const exportFunctionsMap = []; // The export function associated with a source file.
    const noSubstitutionMap = []; // Set of nodes for which substitution rules should be ignored for each file.
    const contextObjectMap = []; // The context object associated with a source file.
    let currentSourceFile; // The current file.
    let moduleInfo; // ExternalModuleInfo for the current file.
    let exportFunction; // The export function for the current file.
    let contextObject; // The context object for the current file.
    let hoistedStatements;
    let enclosingBlockScopedContainer;
    let noSubstitution; // Set of nodes for which substitution rules should be ignored.
    return (0, ts_js_1.chainBundle)(context, transformSourceFile);
    /**
     * Transforms the module aspects of a SourceFile.
     *
     * @param node The SourceFile node.
     */
    function transformSourceFile(node) {
        if (node.isDeclarationFile || !((0, ts_js_1.isEffectiveExternalModule)(node, compilerOptions) || node.transformFlags & 8388608 /* TransformFlags.ContainsDynamicImport */)) {
            return node;
        }
        const id = (0, ts_js_1.getOriginalNodeId)(node);
        currentSourceFile = node;
        enclosingBlockScopedContainer = node;
        // System modules have the following shape:
        //
        //     System.register(['dep-1', ... 'dep-n'], function(exports) {/* module body function */})
        //
        // The parameter 'exports' here is a callback '<T>(name: string, value: T) => T' that
        // is used to publish exported values. 'exports' returns its 'value' argument so in
        // most cases expressions that mutate exported values can be rewritten as:
        //
        //     expr -> exports('name', expr)
        //
        // The only exception in this rule is postfix unary operators,
        // see comment to 'substitutePostfixUnaryExpression' for more details
        // Collect information about the external module and dependency groups.
        moduleInfo = moduleInfoMap[id] = (0, ts_js_1.collectExternalModuleInfo)(context, node);
        // Make sure that the name of the 'exports' function does not conflict with
        // existing identifiers.
        exportFunction = factory.createUniqueName("exports");
        exportFunctionsMap[id] = exportFunction;
        contextObject = contextObjectMap[id] = factory.createUniqueName("context");
        // Add the body of the module.
        const dependencyGroups = collectDependencyGroups(moduleInfo.externalImports);
        const moduleBodyBlock = createSystemModuleBody(node, dependencyGroups);
        const moduleBodyFunction = factory.createFunctionExpression(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, 
        /*name*/ undefined, 
        /*typeParameters*/ undefined, [
            factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, exportFunction),
            factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, contextObject),
        ], 
        /*type*/ undefined, moduleBodyBlock);
        // Write the call to `System.register`
        // Clear the emit-helpers flag for later passes since we'll have already used it in the module body
        // So the helper will be emit at the correct position instead of at the top of the source-file
        const moduleName = (0, ts_js_1.tryGetModuleNameFromFile)(factory, node, host, compilerOptions);
        const dependencies = factory.createArrayLiteralExpression((0, ts_js_1.map)(dependencyGroups, dependencyGroup => dependencyGroup.name));
        const updated = (0, ts_js_1.setEmitFlags)(factory.updateSourceFile(node, (0, ts_js_1.setTextRange)(factory.createNodeArray([
            factory.createExpressionStatement(factory.createCallExpression(factory.createPropertyAccessExpression(factory.createIdentifier("System"), "register"), 
            /*typeArguments*/ undefined, moduleName
                ? [moduleName, dependencies, moduleBodyFunction]
                : [dependencies, moduleBodyFunction])),
        ]), node.statements)), 2048 /* EmitFlags.NoTrailingComments */);
        if (!compilerOptions.outFile) {
            (0, ts_js_1.moveEmitHelpers)(updated, moduleBodyBlock, helper => !helper.scoped);
        }
        if (noSubstitution) {
            noSubstitutionMap[id] = noSubstitution;
            noSubstitution = undefined;
        }
        currentSourceFile = undefined;
        moduleInfo = undefined;
        exportFunction = undefined;
        contextObject = undefined;
        hoistedStatements = undefined;
        enclosingBlockScopedContainer = undefined;
        return updated;
    }
    /**
     * Collects the dependency groups for this files imports.
     *
     * @param externalImports The imports for the file.
     */
    function collectDependencyGroups(externalImports) {
        const groupIndices = new Map();
        const dependencyGroups = [];
        for (const externalImport of externalImports) {
            const externalModuleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, externalImport, currentSourceFile, host, resolver, compilerOptions);
            if (externalModuleName) {
                const text = externalModuleName.text;
                const groupIndex = groupIndices.get(text);
                if (groupIndex !== undefined) {
                    // deduplicate/group entries in dependency list by the dependency name
                    dependencyGroups[groupIndex].externalImports.push(externalImport);
                }
                else {
                    groupIndices.set(text, dependencyGroups.length);
                    dependencyGroups.push({
                        name: externalModuleName,
                        externalImports: [externalImport],
                    });
                }
            }
        }
        return dependencyGroups;
    }
    /**
     * Adds the statements for the module body function for the source file.
     *
     * @param node The source file for the module.
     * @param dependencyGroups The grouped dependencies of the module.
     */
    function createSystemModuleBody(node, dependencyGroups) {
        // Shape of the body in system modules:
        //
        //  function (exports) {
        //      <list of local aliases for imports>
        //      <hoisted variable declarations>
        //      <hoisted function declarations>
        //      return {
        //          setters: [
        //              <list of setter function for imports>
        //          ],
        //          execute: function() {
        //              <module statements>
        //          }
        //      }
        //      <temp declarations>
        //  }
        //
        // i.e:
        //
        //   import {x} from 'file1'
        //   var y = 1;
        //   export function foo() { return y + x(); }
        //   console.log(y);
        //
        // Will be transformed to:
        //
        //  function(exports) {
        //      function foo() { return y + file_1.x(); }
        //      exports("foo", foo);
        //      var file_1, y;
        //      return {
        //          setters: [
        //              function(v) { file_1 = v }
        //          ],
        //          execute(): function() {
        //              y = 1;
        //              console.log(y);
        //          }
        //      };
        //  }
        const statements = [];
        // We start a new lexical environment in this function body, but *not* in the
        // body of the execute function. This allows us to emit temporary declarations
        // only in the outer module body and not in the inner one.
        startLexicalEnvironment();
        // Add any prologue directives.
        const ensureUseStrict = (0, ts_js_1.getAlwaysStrict)(compilerOptions) || (0, ts_js_1.isExternalModule)(currentSourceFile);
        const statementOffset = factory.copyPrologue(node.statements, statements, ensureUseStrict, topLevelVisitor);
        // var __moduleName = context_1 && context_1.id;
        statements.push(factory.createVariableStatement(
        /*modifiers*/ undefined, factory.createVariableDeclarationList([
            factory.createVariableDeclaration("__moduleName", 
            /*exclamationToken*/ undefined, 
            /*type*/ undefined, factory.createLogicalAnd(contextObject, factory.createPropertyAccessExpression(contextObject, "id"))),
        ])));
        // Visit the synthetic external helpers import declaration if present
        (0, ts_js_1.visitNode)(moduleInfo.externalHelpersImportDeclaration, topLevelVisitor, ts_js_1.isStatement);
        // Visit the statements of the source file, emitting any transformations into
        // the `executeStatements` array. We do this *before* we fill the `setters` array
        // as we both emit transformations as well as aggregate some data used when creating
        // setters. This allows us to reduce the number of times we need to loop through the
        // statements of the source file.
        const executeStatements = (0, ts_js_1.visitNodes)(node.statements, topLevelVisitor, ts_js_1.isStatement, statementOffset);
        // Emit early exports for function declarations.
        (0, ts_js_1.addRange)(statements, hoistedStatements);
        // We emit hoisted variables early to align roughly with our previous emit output.
        // Two key differences in this approach are:
        // - Temporary variables will appear at the top rather than at the bottom of the file
        (0, ts_js_1.insertStatementsAfterStandardPrologue)(statements, endLexicalEnvironment());
        const exportStarFunction = addExportStarIfNeeded(statements); // TODO: GH#18217
        const modifiers = node.transformFlags & 2097152 /* TransformFlags.ContainsAwait */ ?
            factory.createModifiersFromModifierFlags(1024 /* ModifierFlags.Async */) :
            undefined;
        const moduleObject = factory.createObjectLiteralExpression([
            factory.createPropertyAssignment("setters", createSettersArray(exportStarFunction, dependencyGroups)),
            factory.createPropertyAssignment("execute", factory.createFunctionExpression(modifiers, 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, 
            /*parameters*/ [], 
            /*type*/ undefined, factory.createBlock(executeStatements, /*multiLine*/ true))),
        ], /*multiLine*/ true);
        statements.push(factory.createReturnStatement(moduleObject));
        return factory.createBlock(statements, /*multiLine*/ true);
    }
    /**
     * Adds an exportStar function to a statement list if it is needed for the file.
     *
     * @param statements A statement list.
     */
    function addExportStarIfNeeded(statements) {
        if (!moduleInfo.hasExportStarsToExportValues) {
            return;
        }
        // when resolving exports local exported entries/indirect exported entries in the module
        // should always win over entries with similar names that were added via star exports
        // to support this we store names of local/indirect exported entries in a set.
        // this set is used to filter names brought by star expors.
        // local names set should only be added if we have anything exported
        if (!(0, ts_js_1.some)(moduleInfo.exportedNames) && moduleInfo.exportedFunctions.size === 0 && moduleInfo.exportSpecifiers.size === 0) {
            // no exported declarations (export var ...) or export specifiers (export {x})
            // check if we have any non star export declarations.
            let hasExportDeclarationWithExportClause = false;
            for (const externalImport of moduleInfo.externalImports) {
                if (externalImport.kind === 279 /* SyntaxKind.ExportDeclaration */ && externalImport.exportClause) {
                    hasExportDeclarationWithExportClause = true;
                    break;
                }
            }
            if (!hasExportDeclarationWithExportClause) {
                // we still need to emit exportStar helper
                const exportStarFunction = createExportStarFunction(/*localNames*/ undefined);
                statements.push(exportStarFunction);
                return exportStarFunction.name;
            }
        }
        const exportedNames = [];
        if (moduleInfo.exportedNames) {
            for (const exportedLocalName of moduleInfo.exportedNames) {
                if ((0, ts_js_1.moduleExportNameIsDefault)(exportedLocalName)) {
                    continue;
                }
                // write name of exported declaration, i.e 'export var x...'
                exportedNames.push(factory.createPropertyAssignment(factory.createStringLiteralFromNode(exportedLocalName), factory.createTrue()));
            }
        }
        for (const f of moduleInfo.exportedFunctions) {
            if ((0, ts_js_1.hasSyntacticModifier)(f, 2048 /* ModifierFlags.Default */)) {
                continue;
            }
            ts_js_1.Debug.assert(!!f.name);
            // write name of exported declaration, i.e 'export var x...'
            exportedNames.push(factory.createPropertyAssignment(factory.createStringLiteralFromNode(f.name), factory.createTrue()));
        }
        const exportedNamesStorageRef = factory.createUniqueName("exportedNames");
        statements.push(factory.createVariableStatement(
        /*modifiers*/ undefined, factory.createVariableDeclarationList([
            factory.createVariableDeclaration(exportedNamesStorageRef, 
            /*exclamationToken*/ undefined, 
            /*type*/ undefined, factory.createObjectLiteralExpression(exportedNames, /*multiLine*/ true)),
        ])));
        const exportStarFunction = createExportStarFunction(exportedNamesStorageRef);
        statements.push(exportStarFunction);
        return exportStarFunction.name;
    }
    /**
     * Creates an exportStar function for the file, with an optional set of excluded local
     * names.
     *
     * @param localNames An optional reference to an object containing a set of excluded local
     * names.
     */
    function createExportStarFunction(localNames) {
        const exportStarFunction = factory.createUniqueName("exportStar");
        const m = factory.createIdentifier("m");
        const n = factory.createIdentifier("n");
        const exports = factory.createIdentifier("exports");
        let condition = factory.createStrictInequality(n, factory.createStringLiteral("default"));
        if (localNames) {
            condition = factory.createLogicalAnd(condition, factory.createLogicalNot(factory.createCallExpression(factory.createPropertyAccessExpression(localNames, "hasOwnProperty"), 
            /*typeArguments*/ undefined, [n])));
        }
        return factory.createFunctionDeclaration(
        /*modifiers*/ undefined, 
        /*asteriskToken*/ undefined, exportStarFunction, 
        /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, m)], 
        /*type*/ undefined, factory.createBlock([
            factory.createVariableStatement(
            /*modifiers*/ undefined, factory.createVariableDeclarationList([
                factory.createVariableDeclaration(exports, 
                /*exclamationToken*/ undefined, 
                /*type*/ undefined, factory.createObjectLiteralExpression([])),
            ])),
            factory.createForInStatement(factory.createVariableDeclarationList([
                factory.createVariableDeclaration(n),
            ]), m, factory.createBlock([
                (0, ts_js_1.setEmitFlags)(factory.createIfStatement(condition, factory.createExpressionStatement(factory.createAssignment(factory.createElementAccessExpression(exports, n), factory.createElementAccessExpression(m, n)))), 1 /* EmitFlags.SingleLine */),
            ])),
            factory.createExpressionStatement(factory.createCallExpression(exportFunction, 
            /*typeArguments*/ undefined, [exports])),
        ], /*multiLine*/ true));
    }
    /**
     * Creates an array setter callbacks for each dependency group.
     *
     * @param exportStarFunction A reference to an exportStarFunction for the file.
     * @param dependencyGroups An array of grouped dependencies.
     */
    function createSettersArray(exportStarFunction, dependencyGroups) {
        const setters = [];
        for (const group of dependencyGroups) {
            // derive a unique name for parameter from the first named entry in the group
            const localName = (0, ts_js_1.forEach)(group.externalImports, i => (0, ts_js_1.getLocalNameForExternalImport)(factory, i, currentSourceFile));
            const parameterName = localName ? factory.getGeneratedNameForNode(localName) : factory.createUniqueName("");
            const statements = [];
            for (const entry of group.externalImports) {
                const importVariableName = (0, ts_js_1.getLocalNameForExternalImport)(factory, entry, currentSourceFile); // TODO: GH#18217
                switch (entry.kind) {
                    case 273 /* SyntaxKind.ImportDeclaration */:
                        if (!entry.importClause) {
                            // 'import "..."' case
                            // module is imported only for side-effects, no emit required
                            break;
                        }
                    // falls through
                    case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                        ts_js_1.Debug.assert(importVariableName !== undefined);
                        // save import into the local
                        statements.push(factory.createExpressionStatement(factory.createAssignment(importVariableName, parameterName)));
                        if ((0, ts_js_1.hasSyntacticModifier)(entry, 32 /* ModifierFlags.Export */)) {
                            statements.push(factory.createExpressionStatement(factory.createCallExpression(exportFunction, 
                            /*typeArguments*/ undefined, [
                                factory.createStringLiteral((0, ts_js_1.idText)(importVariableName)),
                                parameterName,
                            ])));
                        }
                        break;
                    case 279 /* SyntaxKind.ExportDeclaration */:
                        ts_js_1.Debug.assert(importVariableName !== undefined);
                        if (entry.exportClause) {
                            if ((0, ts_js_1.isNamedExports)(entry.exportClause)) {
                                //  export {a, b as c} from 'foo'
                                //
                                // emit as:
                                //
                                //  exports_({
                                //     "a": _["a"],
                                //     "c": _["b"]
                                //  });
                                const properties = [];
                                for (const e of entry.exportClause.elements) {
                                    properties.push(factory.createPropertyAssignment(factory.createStringLiteral((0, ts_js_1.moduleExportNameTextUnescaped)(e.name)), factory.createElementAccessExpression(parameterName, factory.createStringLiteral((0, ts_js_1.moduleExportNameTextUnescaped)(e.propertyName || e.name)))));
                                }
                                statements.push(factory.createExpressionStatement(factory.createCallExpression(exportFunction, 
                                /*typeArguments*/ undefined, [factory.createObjectLiteralExpression(properties, /*multiLine*/ true)])));
                            }
                            else {
                                statements.push(factory.createExpressionStatement(factory.createCallExpression(exportFunction, 
                                /*typeArguments*/ undefined, [
                                    factory.createStringLiteral((0, ts_js_1.moduleExportNameTextUnescaped)(entry.exportClause.name)),
                                    parameterName,
                                ])));
                            }
                        }
                        else {
                            //  export * from 'foo'
                            //
                            // emit as:
                            //
                            //  exportStar(foo_1_1);
                            statements.push(factory.createExpressionStatement(factory.createCallExpression(exportStarFunction, 
                            /*typeArguments*/ undefined, [parameterName])));
                        }
                        break;
                }
            }
            setters.push(factory.createFunctionExpression(
            /*modifiers*/ undefined, 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, [factory.createParameterDeclaration(/*modifiers*/ undefined, /*dotDotDotToken*/ undefined, parameterName)], 
            /*type*/ undefined, factory.createBlock(statements, /*multiLine*/ true)));
        }
        return factory.createArrayLiteralExpression(setters, /*multiLine*/ true);
    }
    //
    // Top-level Source Element Visitors
    //
    /**
     * Visit source elements at the top-level of a module.
     *
     * @param node The node to visit.
     */
    function topLevelVisitor(node) {
        switch (node.kind) {
            case 273 /* SyntaxKind.ImportDeclaration */:
                return visitImportDeclaration(node);
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
                return visitImportEqualsDeclaration(node);
            case 279 /* SyntaxKind.ExportDeclaration */:
                return visitExportDeclaration(node);
            case 278 /* SyntaxKind.ExportAssignment */:
                return visitExportAssignment(node);
            default:
                return topLevelNestedVisitor(node);
        }
    }
    /**
     * Visits an ImportDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitImportDeclaration(node) {
        let statements;
        if (node.importClause) {
            hoistVariableDeclaration((0, ts_js_1.getLocalNameForExternalImport)(factory, node, currentSourceFile)); // TODO: GH#18217
        }
        return (0, ts_js_1.singleOrMany)(appendExportsOfImportDeclaration(statements, node));
    }
    function visitExportDeclaration(node) {
        ts_js_1.Debug.assertIsDefined(node);
        return undefined;
    }
    /**
     * Visits an ImportEqualsDeclaration node.
     *
     * @param node The node to visit.
     */
    function visitImportEqualsDeclaration(node) {
        ts_js_1.Debug.assert((0, ts_js_1.isExternalModuleImportEqualsDeclaration)(node), "import= for internal module references should be handled in an earlier transformer.");
        let statements;
        hoistVariableDeclaration((0, ts_js_1.getLocalNameForExternalImport)(factory, node, currentSourceFile)); // TODO: GH#18217
        return (0, ts_js_1.singleOrMany)(appendExportsOfImportEqualsDeclaration(statements, node));
    }
    /**
     * Visits an ExportAssignment node.
     *
     * @param node The node to visit.
     */
    function visitExportAssignment(node) {
        if (node.isExportEquals) {
            // Elide `export=` as it is illegal in a SystemJS module.
            return undefined;
        }
        const expression = (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression);
        return createExportStatement(factory.createIdentifier("default"), expression, /*allowComments*/ true);
    }
    /**
     * Visits a FunctionDeclaration, hoisting it to the outer module body function.
     *
     * @param node The node to visit.
     */
    function visitFunctionDeclaration(node) {
        if ((0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */)) {
            hoistedStatements = (0, ts_js_1.append)(hoistedStatements, factory.updateFunctionDeclaration(node, (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifierLike), node.asteriskToken, factory.getDeclarationName(node, /*allowComments*/ true, /*allowSourceMaps*/ true), 
            /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.parameters, visitor, ts_js_1.isParameter), 
            /*type*/ undefined, (0, ts_js_1.visitNode)(node.body, visitor, ts_js_1.isBlock)));
        }
        else {
            hoistedStatements = (0, ts_js_1.append)(hoistedStatements, (0, ts_js_1.visitEachChild)(node, visitor, context));
        }
        hoistedStatements = appendExportsOfHoistedDeclaration(hoistedStatements, node);
        return undefined;
    }
    /**
     * Visits a ClassDeclaration, hoisting its name to the outer module body function.
     *
     * @param node The node to visit.
     */
    function visitClassDeclaration(node) {
        let statements;
        // Hoist the name of the class declaration to the outer module body function.
        const name = factory.getLocalName(node);
        hoistVariableDeclaration(name);
        // Rewrite the class declaration into an assignment of a class expression.
        statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.createAssignment(name, (0, ts_js_1.setTextRange)(factory.createClassExpression((0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifierLike), node.name, 
        /*typeParameters*/ undefined, (0, ts_js_1.visitNodes)(node.heritageClauses, visitor, ts_js_1.isHeritageClause), (0, ts_js_1.visitNodes)(node.members, visitor, ts_js_1.isClassElement)), node))), node));
        statements = appendExportsOfHoistedDeclaration(statements, node);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Visits a variable statement, hoisting declared names to the top-level module body.
     * Each declaration is rewritten into an assignment expression.
     *
     * @param node The node to visit.
     */
    function visitVariableStatement(node) {
        if (!shouldHoistVariableDeclarationList(node.declarationList)) {
            return (0, ts_js_1.visitNode)(node, visitor, ts_js_1.isStatement);
        }
        let statements;
        // `using` and `await using` declarations cannot be hoisted directly, so we will hoist the variable name
        // as a normal variable, and declare it as a temp variable that remains as a `using` to ensure the correct
        // lifetime.
        if ((0, ts_js_1.isVarUsing)(node.declarationList) || (0, ts_js_1.isVarAwaitUsing)(node.declarationList)) {
            const modifiers = (0, ts_js_1.visitNodes)(node.modifiers, modifierVisitor, ts_js_1.isModifierLike);
            const declarations = [];
            for (const variable of node.declarationList.declarations) {
                declarations.push(factory.updateVariableDeclaration(variable, factory.getGeneratedNameForNode(variable.name), 
                /*exclamationToken*/ undefined, 
                /*type*/ undefined, transformInitializedVariable(variable, /*isExportedDeclaration*/ false)));
            }
            const declarationList = factory.updateVariableDeclarationList(node.declarationList, declarations);
            statements = (0, ts_js_1.append)(statements, factory.updateVariableStatement(node, modifiers, declarationList));
        }
        else {
            let expressions;
            const isExportedDeclaration = (0, ts_js_1.hasSyntacticModifier)(node, 32 /* ModifierFlags.Export */);
            for (const variable of node.declarationList.declarations) {
                if (variable.initializer) {
                    expressions = (0, ts_js_1.append)(expressions, transformInitializedVariable(variable, isExportedDeclaration));
                }
                else {
                    hoistBindingElement(variable);
                }
            }
            if (expressions) {
                statements = (0, ts_js_1.append)(statements, (0, ts_js_1.setTextRange)(factory.createExpressionStatement(factory.inlineExpressions(expressions)), node));
            }
        }
        statements = appendExportsOfVariableStatement(statements, node, /*exportSelf*/ false);
        return (0, ts_js_1.singleOrMany)(statements);
    }
    /**
     * Hoists the declared names of a VariableDeclaration or BindingElement.
     *
     * @param node The declaration to hoist.
     */
    function hoistBindingElement(node) {
        if ((0, ts_js_1.isBindingPattern)(node.name)) {
            for (const element of node.name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    hoistBindingElement(element);
                }
            }
        }
        else {
            hoistVariableDeclaration(factory.cloneNode(node.name));
        }
    }
    /**
     * Determines whether a VariableDeclarationList should be hoisted.
     *
     * @param node The node to test.
     */
    function shouldHoistVariableDeclarationList(node) {
        // hoist only non-block scoped declarations or block scoped declarations parented by source file
        return ((0, ts_js_1.getEmitFlags)(node) & 4194304 /* EmitFlags.NoHoisting */) === 0
            && (enclosingBlockScopedContainer.kind === 308 /* SyntaxKind.SourceFile */
                || ((0, ts_js_1.getOriginalNode)(node).flags & 7 /* NodeFlags.BlockScoped */) === 0);
    }
    /**
     * Transform an initialized variable declaration into an expression.
     *
     * @param node The node to transform.
     * @param isExportedDeclaration A value indicating whether the variable is exported.
     */
    function transformInitializedVariable(node, isExportedDeclaration) {
        const createAssignment = isExportedDeclaration ? createExportedVariableAssignment : createNonExportedVariableAssignment;
        return (0, ts_js_1.isBindingPattern)(node.name)
            ? (0, ts_js_1.flattenDestructuringAssignment)(node, visitor, context, 0 /* FlattenLevel.All */, 
            /*needsValue*/ false, createAssignment)
            : node.initializer ? createAssignment(node.name, (0, ts_js_1.visitNode)(node.initializer, visitor, ts_js_1.isExpression)) : node.name;
    }
    /**
     * Creates an assignment expression for an exported variable declaration.
     *
     * @param name The name of the variable.
     * @param value The value of the variable's initializer.
     * @param location The source map location for the assignment.
     */
    function createExportedVariableAssignment(name, value, location) {
        return createVariableAssignment(name, value, location, /*isExportedDeclaration*/ true);
    }
    /**
     * Creates an assignment expression for a non-exported variable declaration.
     *
     * @param name The name of the variable.
     * @param value The value of the variable's initializer.
     * @param location The source map location for the assignment.
     */
    function createNonExportedVariableAssignment(name, value, location) {
        return createVariableAssignment(name, value, location, /*isExportedDeclaration*/ false);
    }
    /**
     * Creates an assignment expression for a variable declaration.
     *
     * @param name The name of the variable.
     * @param value The value of the variable's initializer.
     * @param location The source map location for the assignment.
     * @param isExportedDeclaration A value indicating whether the variable is exported.
     */
    function createVariableAssignment(name, value, location, isExportedDeclaration) {
        hoistVariableDeclaration(factory.cloneNode(name));
        return isExportedDeclaration
            ? createExportExpression(name, preventSubstitution((0, ts_js_1.setTextRange)(factory.createAssignment(name, value), location)))
            : preventSubstitution((0, ts_js_1.setTextRange)(factory.createAssignment(name, value), location));
    }
    /**
     * Appends the exports of an ImportDeclaration to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfImportDeclaration(statements, decl) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        const importClause = decl.importClause;
        if (!importClause) {
            return statements;
        }
        if (importClause.name) {
            statements = appendExportsOfDeclaration(statements, importClause);
        }
        const namedBindings = importClause.namedBindings;
        if (namedBindings) {
            switch (namedBindings.kind) {
                case 275 /* SyntaxKind.NamespaceImport */:
                    statements = appendExportsOfDeclaration(statements, namedBindings);
                    break;
                case 276 /* SyntaxKind.NamedImports */:
                    for (const importBinding of namedBindings.elements) {
                        statements = appendExportsOfDeclaration(statements, importBinding);
                    }
                    break;
            }
        }
        return statements;
    }
    /**
     * Appends the export of an ImportEqualsDeclaration to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfImportEqualsDeclaration(statements, decl) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        return appendExportsOfDeclaration(statements, decl);
    }
    /**
     * Appends the exports of a VariableStatement to a statement list, returning the statement
     * list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param node The VariableStatement whose exports are to be recorded.
     * @param exportSelf A value indicating whether to also export each VariableDeclaration of
     * `nodes` declaration list.
     */
    function appendExportsOfVariableStatement(statements, node, exportSelf) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        for (const decl of node.declarationList.declarations) {
            if (decl.initializer || exportSelf) {
                statements = appendExportsOfBindingElement(statements, decl, exportSelf);
            }
        }
        return statements;
    }
    /**
     * Appends the exports of a VariableDeclaration or BindingElement to a statement list,
     * returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     * @param exportSelf A value indicating whether to also export the declaration itself.
     */
    function appendExportsOfBindingElement(statements, decl, exportSelf) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        if ((0, ts_js_1.isBindingPattern)(decl.name)) {
            for (const element of decl.name.elements) {
                if (!(0, ts_js_1.isOmittedExpression)(element)) {
                    statements = appendExportsOfBindingElement(statements, element, exportSelf);
                }
            }
        }
        else if (!(0, ts_js_1.isGeneratedIdentifier)(decl.name)) {
            let excludeName;
            if (exportSelf) {
                statements = appendExportStatement(statements, decl.name, factory.getLocalName(decl));
                excludeName = (0, ts_js_1.idText)(decl.name);
            }
            statements = appendExportsOfDeclaration(statements, decl, excludeName);
        }
        return statements;
    }
    /**
     * Appends the exports of a ClassDeclaration or FunctionDeclaration to a statement list,
     * returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration whose exports are to be recorded.
     */
    function appendExportsOfHoistedDeclaration(statements, decl) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        let excludeName;
        if ((0, ts_js_1.hasSyntacticModifier)(decl, 32 /* ModifierFlags.Export */)) {
            const exportName = (0, ts_js_1.hasSyntacticModifier)(decl, 2048 /* ModifierFlags.Default */) ? factory.createStringLiteral("default") : decl.name;
            statements = appendExportStatement(statements, exportName, factory.getLocalName(decl));
            excludeName = (0, ts_js_1.getTextOfIdentifierOrLiteral)(exportName);
        }
        if (decl.name) {
            statements = appendExportsOfDeclaration(statements, decl, excludeName);
        }
        return statements;
    }
    /**
     * Appends the exports of a declaration to a statement list, returning the statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param decl The declaration to export.
     * @param excludeName An optional name to exclude from exports.
     */
    function appendExportsOfDeclaration(statements, decl, excludeName) {
        if (moduleInfo.exportEquals) {
            return statements;
        }
        const name = factory.getDeclarationName(decl);
        const exportSpecifiers = moduleInfo.exportSpecifiers.get(name);
        if (exportSpecifiers) {
            for (const exportSpecifier of exportSpecifiers) {
                if ((0, ts_js_1.moduleExportNameTextUnescaped)(exportSpecifier.name) !== excludeName) {
                    statements = appendExportStatement(statements, exportSpecifier.name, name);
                }
            }
        }
        return statements;
    }
    /**
     * Appends the down-level representation of an export to a statement list, returning the
     * statement list.
     *
     * @param statements A statement list to which the down-level export statements are to be
     * appended. If `statements` is `undefined`, a new array is allocated if statements are
     * appended.
     * @param exportName The name of the export.
     * @param expression The expression to export.
     * @param allowComments Whether to allow comments on the export.
     */
    function appendExportStatement(statements, exportName, expression, allowComments) {
        statements = (0, ts_js_1.append)(statements, createExportStatement(exportName, expression, allowComments));
        return statements;
    }
    /**
     * Creates a call to the current file's export function to export a value.
     *
     * @param name The bound name of the export.
     * @param value The exported value.
     * @param allowComments An optional value indicating whether to emit comments for the statement.
     */
    function createExportStatement(name, value, allowComments) {
        const statement = factory.createExpressionStatement(createExportExpression(name, value));
        (0, ts_js_1.startOnNewLine)(statement);
        if (!allowComments) {
            (0, ts_js_1.setEmitFlags)(statement, 3072 /* EmitFlags.NoComments */);
        }
        return statement;
    }
    /**
     * Creates a call to the current file's export function to export a value.
     *
     * @param name The bound name of the export.
     * @param value The exported value.
     */
    function createExportExpression(name, value) {
        const exportName = (0, ts_js_1.isIdentifier)(name) ? factory.createStringLiteralFromNode(name) : name;
        (0, ts_js_1.setEmitFlags)(value, (0, ts_js_1.getEmitFlags)(value) | 3072 /* EmitFlags.NoComments */);
        return (0, ts_js_1.setCommentRange)(factory.createCallExpression(exportFunction, /*typeArguments*/ undefined, [exportName, value]), value);
    }
    //
    // Top-Level or Nested Source Element Visitors
    //
    /**
     * Visit nested elements at the top-level of a module.
     *
     * @param node The node to visit.
     */
    function topLevelNestedVisitor(node) {
        switch (node.kind) {
            case 244 /* SyntaxKind.VariableStatement */:
                return visitVariableStatement(node);
            case 263 /* SyntaxKind.FunctionDeclaration */:
                return visitFunctionDeclaration(node);
            case 264 /* SyntaxKind.ClassDeclaration */:
                return visitClassDeclaration(node);
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node, /*isTopLevel*/ true);
            case 250 /* SyntaxKind.ForInStatement */:
                return visitForInStatement(node);
            case 251 /* SyntaxKind.ForOfStatement */:
                return visitForOfStatement(node);
            case 247 /* SyntaxKind.DoStatement */:
                return visitDoStatement(node);
            case 248 /* SyntaxKind.WhileStatement */:
                return visitWhileStatement(node);
            case 257 /* SyntaxKind.LabeledStatement */:
                return visitLabeledStatement(node);
            case 255 /* SyntaxKind.WithStatement */:
                return visitWithStatement(node);
            case 246 /* SyntaxKind.IfStatement */:
                return visitIfStatement(node);
            case 256 /* SyntaxKind.SwitchStatement */:
                return visitSwitchStatement(node);
            case 270 /* SyntaxKind.CaseBlock */:
                return visitCaseBlock(node);
            case 297 /* SyntaxKind.CaseClause */:
                return visitCaseClause(node);
            case 298 /* SyntaxKind.DefaultClause */:
                return visitDefaultClause(node);
            case 259 /* SyntaxKind.TryStatement */:
                return visitTryStatement(node);
            case 300 /* SyntaxKind.CatchClause */:
                return visitCatchClause(node);
            case 242 /* SyntaxKind.Block */:
                return visitBlock(node);
            default:
                return visitor(node);
        }
    }
    /**
     * Visits the body of a ForStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitForStatement(node, isTopLevel) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = factory.updateForStatement(node, (0, ts_js_1.visitNode)(node.initializer, isTopLevel ? visitForInitializer : discardedValueVisitor, ts_js_1.isForInitializer), (0, ts_js_1.visitNode)(node.condition, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.incrementor, discardedValueVisitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, isTopLevel ? topLevelNestedVisitor : visitor, context));
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    /**
     * Visits the body of a ForInStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitForInStatement(node) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = factory.updateForInStatement(node, visitForInitializer(node.initializer), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    /**
     * Visits the body of a ForOfStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitForOfStatement(node) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = factory.updateForOfStatement(node, node.awaitModifier, visitForInitializer(node.initializer), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    /**
     * Determines whether to hoist the initializer of a ForStatement, ForInStatement, or
     * ForOfStatement.
     *
     * @param node The node to test.
     */
    function shouldHoistForInitializer(node) {
        return (0, ts_js_1.isVariableDeclarationList)(node)
            && shouldHoistVariableDeclarationList(node);
    }
    /**
     * Visits the initializer of a ForStatement, ForInStatement, or ForOfStatement
     *
     * @param node The node to visit.
     */
    function visitForInitializer(node) {
        if (shouldHoistForInitializer(node)) {
            let expressions;
            for (const variable of node.declarations) {
                expressions = (0, ts_js_1.append)(expressions, transformInitializedVariable(variable, /*isExportedDeclaration*/ false));
                if (!variable.initializer) {
                    hoistBindingElement(variable);
                }
            }
            return expressions ? factory.inlineExpressions(expressions) : factory.createOmittedExpression();
        }
        else {
            return (0, ts_js_1.visitNode)(node, discardedValueVisitor, ts_js_1.isForInitializer);
        }
    }
    /**
     * Visits the body of a DoStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitDoStatement(node) {
        return factory.updateDoStatement(node, (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context), (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression));
    }
    /**
     * Visits the body of a WhileStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitWhileStatement(node) {
        return factory.updateWhileStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitIterationBody)(node.statement, topLevelNestedVisitor, context));
    }
    /**
     * Visits the body of a LabeledStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitLabeledStatement(node) {
        return factory.updateLabeledStatement(node, node.label, (0, ts_js_1.visitNode)(node.statement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock) ?? factory.createExpressionStatement(factory.createIdentifier("")));
    }
    /**
     * Visits the body of a WithStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitWithStatement(node) {
        return factory.updateWithStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.statement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock)));
    }
    /**
     * Visits the body of a IfStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitIfStatement(node) {
        return factory.updateIfStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNode)(node.thenStatement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock) ?? factory.createBlock([]), (0, ts_js_1.visitNode)(node.elseStatement, topLevelNestedVisitor, ts_js_1.isStatement, factory.liftToBlock));
    }
    /**
     * Visits the body of a SwitchStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitSwitchStatement(node) {
        return factory.updateSwitchStatement(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.caseBlock, topLevelNestedVisitor, ts_js_1.isCaseBlock)));
    }
    /**
     * Visits the body of a CaseBlock to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCaseBlock(node) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = factory.updateCaseBlock(node, (0, ts_js_1.visitNodes)(node.clauses, topLevelNestedVisitor, ts_js_1.isCaseOrDefaultClause));
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    /**
     * Visits the body of a CaseClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCaseClause(node) {
        return factory.updateCaseClause(node, (0, ts_js_1.visitNode)(node.expression, visitor, ts_js_1.isExpression), (0, ts_js_1.visitNodes)(node.statements, topLevelNestedVisitor, ts_js_1.isStatement));
    }
    /**
     * Visits the body of a DefaultClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitDefaultClause(node) {
        return (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
    }
    /**
     * Visits the body of a TryStatement to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitTryStatement(node) {
        return (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
    }
    /**
     * Visits the body of a CatchClause to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitCatchClause(node) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = factory.updateCatchClause(node, node.variableDeclaration, ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(node.block, topLevelNestedVisitor, ts_js_1.isBlock)));
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    /**
     * Visits the body of a Block to hoist declarations.
     *
     * @param node The node to visit.
     */
    function visitBlock(node) {
        const savedEnclosingBlockScopedContainer = enclosingBlockScopedContainer;
        enclosingBlockScopedContainer = node;
        node = (0, ts_js_1.visitEachChild)(node, topLevelNestedVisitor, context);
        enclosingBlockScopedContainer = savedEnclosingBlockScopedContainer;
        return node;
    }
    //
    // Destructuring Assignment Visitors
    //
    /**
     * Visit nodes to flatten destructuring assignments to exported symbols.
     *
     * @param node The node to visit.
     */
    function visitorWorker(node, valueIsDiscarded) {
        if (!(node.transformFlags & (4096 /* TransformFlags.ContainsDestructuringAssignment */ | 8388608 /* TransformFlags.ContainsDynamicImport */ | 268435456 /* TransformFlags.ContainsUpdateExpressionForIdentifier */))) {
            return node;
        }
        switch (node.kind) {
            case 249 /* SyntaxKind.ForStatement */:
                return visitForStatement(node, /*isTopLevel*/ false);
            case 245 /* SyntaxKind.ExpressionStatement */:
                return visitExpressionStatement(node);
            case 218 /* SyntaxKind.ParenthesizedExpression */:
                return visitParenthesizedExpression(node, valueIsDiscarded);
            case 356 /* SyntaxKind.PartiallyEmittedExpression */:
                return visitPartiallyEmittedExpression(node, valueIsDiscarded);
            case 227 /* SyntaxKind.BinaryExpression */:
                if ((0, ts_js_1.isDestructuringAssignment)(node)) {
                    return visitDestructuringAssignment(node, valueIsDiscarded);
                }
                break;
            case 214 /* SyntaxKind.CallExpression */:
                if ((0, ts_js_1.isImportCall)(node)) {
                    return visitImportCallExpression(node);
                }
                break;
            case 225 /* SyntaxKind.PrefixUnaryExpression */:
            case 226 /* SyntaxKind.PostfixUnaryExpression */:
                return visitPrefixOrPostfixUnaryExpression(node, valueIsDiscarded);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Visit nodes to flatten destructuring assignments to exported symbols.
     *
     * @param node The node to visit.
     */
    function visitor(node) {
        return visitorWorker(node, /*valueIsDiscarded*/ false);
    }
    function discardedValueVisitor(node) {
        return visitorWorker(node, /*valueIsDiscarded*/ true);
    }
    function visitExpressionStatement(node) {
        return factory.updateExpressionStatement(node, (0, ts_js_1.visitNode)(node.expression, discardedValueVisitor, ts_js_1.isExpression));
    }
    function visitParenthesizedExpression(node, valueIsDiscarded) {
        return factory.updateParenthesizedExpression(node, (0, ts_js_1.visitNode)(node.expression, valueIsDiscarded ? discardedValueVisitor : visitor, ts_js_1.isExpression));
    }
    function visitPartiallyEmittedExpression(node, valueIsDiscarded) {
        return factory.updatePartiallyEmittedExpression(node, (0, ts_js_1.visitNode)(node.expression, valueIsDiscarded ? discardedValueVisitor : visitor, ts_js_1.isExpression));
    }
    function visitImportCallExpression(node) {
        // import("./blah")
        // emit as
        // System.register([], function (_export, _context) {
        //     return {
        //         setters: [],
        //         execute: () => {
        //             _context.import('./blah');
        //         }
        //     };
        // });
        const externalModuleName = (0, ts_js_1.getExternalModuleNameLiteral)(factory, node, currentSourceFile, host, resolver, compilerOptions);
        const firstArgument = (0, ts_js_1.visitNode)((0, ts_js_1.firstOrUndefined)(node.arguments), visitor, ts_js_1.isExpression);
        // Only use the external module name if it differs from the first argument. This allows us to preserve the quote style of the argument on output.
        const argument = externalModuleName && (!firstArgument || !(0, ts_js_1.isStringLiteral)(firstArgument) || firstArgument.text !== externalModuleName.text) ? externalModuleName : firstArgument;
        return factory.createCallExpression(factory.createPropertyAccessExpression(contextObject, factory.createIdentifier("import")), 
        /*typeArguments*/ undefined, argument ? [argument] : []);
    }
    /**
     * Visits a DestructuringAssignment to flatten destructuring to exported symbols.
     *
     * @param node The node to visit.
     */
    function visitDestructuringAssignment(node, valueIsDiscarded) {
        if (hasExportedReferenceInDestructuringTarget(node.left)) {
            return (0, ts_js_1.flattenDestructuringAssignment)(node, visitor, context, 0 /* FlattenLevel.All */, !valueIsDiscarded);
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    /**
     * Determines whether the target of a destructuring assignment refers to an exported symbol.
     *
     * @param node The destructuring target.
     */
    function hasExportedReferenceInDestructuringTarget(node) {
        if ((0, ts_js_1.isAssignmentExpression)(node, /*excludeCompoundAssignment*/ true)) {
            return hasExportedReferenceInDestructuringTarget(node.left);
        }
        else if ((0, ts_js_1.isSpreadElement)(node)) {
            return hasExportedReferenceInDestructuringTarget(node.expression);
        }
        else if ((0, ts_js_1.isObjectLiteralExpression)(node)) {
            return (0, ts_js_1.some)(node.properties, hasExportedReferenceInDestructuringTarget);
        }
        else if ((0, ts_js_1.isArrayLiteralExpression)(node)) {
            return (0, ts_js_1.some)(node.elements, hasExportedReferenceInDestructuringTarget);
        }
        else if ((0, ts_js_1.isShorthandPropertyAssignment)(node)) {
            return hasExportedReferenceInDestructuringTarget(node.name);
        }
        else if ((0, ts_js_1.isPropertyAssignment)(node)) {
            return hasExportedReferenceInDestructuringTarget(node.initializer);
        }
        else if ((0, ts_js_1.isIdentifier)(node)) {
            const container = resolver.getReferencedExportContainer(node);
            return container !== undefined && container.kind === 308 /* SyntaxKind.SourceFile */;
        }
        else {
            return false;
        }
    }
    function visitPrefixOrPostfixUnaryExpression(node, valueIsDiscarded) {
        // When we see a prefix or postfix increment expression whose operand is an exported
        // symbol, we should ensure all exports of that symbol are updated with the correct
        // value.
        //
        // - We do not transform generated identifiers for any reason.
        // - We do not transform identifiers tagged with the LocalName flag.
        // - We do not transform identifiers that were originally the name of an enum or
        //   namespace due to how they are transformed in TypeScript.
        // - We only transform identifiers that are exported at the top level.
        if ((node.operator === 46 /* SyntaxKind.PlusPlusToken */ || node.operator === 47 /* SyntaxKind.MinusMinusToken */)
            && (0, ts_js_1.isIdentifier)(node.operand)
            && !(0, ts_js_1.isGeneratedIdentifier)(node.operand)
            && !(0, ts_js_1.isLocalName)(node.operand)
            && !(0, ts_js_1.isDeclarationNameOfEnumOrNamespace)(node.operand)) {
            const exportedNames = getExports(node.operand);
            if (exportedNames) {
                let temp;
                let expression = (0, ts_js_1.visitNode)(node.operand, visitor, ts_js_1.isExpression);
                if ((0, ts_js_1.isPrefixUnaryExpression)(node)) {
                    expression = factory.updatePrefixUnaryExpression(node, expression);
                }
                else {
                    expression = factory.updatePostfixUnaryExpression(node, expression);
                    if (!valueIsDiscarded) {
                        temp = factory.createTempVariable(hoistVariableDeclaration);
                        expression = factory.createAssignment(temp, expression);
                        (0, ts_js_1.setTextRange)(expression, node);
                    }
                    expression = factory.createComma(expression, factory.cloneNode(node.operand));
                    (0, ts_js_1.setTextRange)(expression, node);
                }
                for (const exportName of exportedNames) {
                    expression = createExportExpression(exportName, preventSubstitution(expression));
                }
                if (temp) {
                    expression = factory.createComma(expression, temp);
                    (0, ts_js_1.setTextRange)(expression, node);
                }
                return expression;
            }
        }
        return (0, ts_js_1.visitEachChild)(node, visitor, context);
    }
    //
    // Modifier Visitors
    //
    /**
     * Visit nodes to elide module-specific modifiers.
     *
     * @param node The node to visit.
     */
    function modifierVisitor(node) {
        switch (node.kind) {
            case 95 /* SyntaxKind.ExportKeyword */:
            case 90 /* SyntaxKind.DefaultKeyword */:
                return undefined;
        }
        return node;
    }
    //
    // Emit Notification
    //
    /**
     * Hook for node emit notifications.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to emit.
     * @param emitCallback A callback used to emit the node in the printer.
     */
    function onEmitNode(hint, node, emitCallback) {
        if (node.kind === 308 /* SyntaxKind.SourceFile */) {
            const id = (0, ts_js_1.getOriginalNodeId)(node);
            currentSourceFile = node;
            moduleInfo = moduleInfoMap[id];
            exportFunction = exportFunctionsMap[id];
            noSubstitution = noSubstitutionMap[id];
            contextObject = contextObjectMap[id];
            if (noSubstitution) {
                delete noSubstitutionMap[id];
            }
            previousOnEmitNode(hint, node, emitCallback);
            currentSourceFile = undefined;
            moduleInfo = undefined;
            exportFunction = undefined;
            contextObject = undefined;
            noSubstitution = undefined;
        }
        else {
            previousOnEmitNode(hint, node, emitCallback);
        }
    }
    //
    // Substitutions
    //
    /**
     * Hooks node substitutions.
     *
     * @param hint A hint as to the intended usage of the node.
     * @param node The node to substitute.
     */
    function onSubstituteNode(hint, node) {
        node = previousOnSubstituteNode(hint, node);
        if (isSubstitutionPrevented(node)) {
            return node;
        }
        if (hint === 1 /* EmitHint.Expression */) {
            return substituteExpression(node);
        }
        else if (hint === 4 /* EmitHint.Unspecified */) {
            return substituteUnspecified(node);
        }
        return node;
    }
    /**
     * Substitute the node, if necessary.
     *
     * @param node The node to substitute.
     */
    function substituteUnspecified(node) {
        switch (node.kind) {
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
                return substituteShorthandPropertyAssignment(node);
        }
        return node;
    }
    /**
     * Substitution for a ShorthandPropertyAssignment whose name that may contain an imported or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteShorthandPropertyAssignment(node) {
        const name = node.name;
        if (!(0, ts_js_1.isGeneratedIdentifier)(name) && !(0, ts_js_1.isLocalName)(name)) {
            const importDeclaration = resolver.getReferencedImportDeclaration(name);
            if (importDeclaration) {
                if ((0, ts_js_1.isImportClause)(importDeclaration)) {
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(factory.cloneNode(name), factory.createPropertyAccessExpression(factory.getGeneratedNameForNode(importDeclaration.parent), factory.createIdentifier("default"))), 
                    /*location*/ node);
                }
                else if ((0, ts_js_1.isImportSpecifier)(importDeclaration)) {
                    const importedName = importDeclaration.propertyName || importDeclaration.name;
                    const target = factory.getGeneratedNameForNode(importDeclaration.parent?.parent?.parent || importDeclaration);
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAssignment(factory.cloneNode(name), importedName.kind === 11 /* SyntaxKind.StringLiteral */
                        ? factory.createElementAccessExpression(target, factory.cloneNode(importedName))
                        : factory.createPropertyAccessExpression(target, factory.cloneNode(importedName))), 
                    /*location*/ node);
                }
            }
        }
        return node;
    }
    /**
     * Substitute the expression, if necessary.
     *
     * @param node The node to substitute.
     */
    function substituteExpression(node) {
        switch (node.kind) {
            case 80 /* SyntaxKind.Identifier */:
                return substituteExpressionIdentifier(node);
            case 227 /* SyntaxKind.BinaryExpression */:
                return substituteBinaryExpression(node);
            case 237 /* SyntaxKind.MetaProperty */:
                return substituteMetaProperty(node);
        }
        return node;
    }
    /**
     * Substitution for an Identifier expression that may contain an imported or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteExpressionIdentifier(node) {
        if ((0, ts_js_1.getEmitFlags)(node) & 8192 /* EmitFlags.HelperName */) {
            const externalHelpersModuleName = (0, ts_js_1.getExternalHelpersModuleName)(currentSourceFile);
            if (externalHelpersModuleName) {
                return factory.createPropertyAccessExpression(externalHelpersModuleName, node);
            }
            return node;
        }
        // When we see an identifier in an expression position that
        // points to an imported symbol, we should substitute a qualified
        // reference to the imported symbol if one is needed.
        //
        // - We do not substitute generated identifiers for any reason.
        // - We do not substitute identifiers tagged with the LocalName flag.
        if (!(0, ts_js_1.isGeneratedIdentifier)(node) && !(0, ts_js_1.isLocalName)(node)) {
            const importDeclaration = resolver.getReferencedImportDeclaration(node);
            if (importDeclaration) {
                if ((0, ts_js_1.isImportClause)(importDeclaration)) {
                    return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(factory.getGeneratedNameForNode(importDeclaration.parent), factory.createIdentifier("default")), 
                    /*location*/ node);
                }
                else if ((0, ts_js_1.isImportSpecifier)(importDeclaration)) {
                    const importedName = importDeclaration.propertyName || importDeclaration.name;
                    const target = factory.getGeneratedNameForNode(importDeclaration.parent?.parent?.parent || importDeclaration);
                    return (0, ts_js_1.setTextRange)(importedName.kind === 11 /* SyntaxKind.StringLiteral */
                        ? factory.createElementAccessExpression(target, factory.cloneNode(importedName))
                        : factory.createPropertyAccessExpression(target, factory.cloneNode(importedName)), 
                    /*location*/ node);
                }
            }
        }
        return node;
    }
    /**
     * Substitution for a BinaryExpression that may contain an imported or exported symbol.
     *
     * @param node The node to substitute.
     */
    function substituteBinaryExpression(node) {
        // When we see an assignment expression whose left-hand side is an exported symbol,
        // we should ensure all exports of that symbol are updated with the correct value.
        //
        // - We do not substitute generated identifiers unless they are file-level reserved names.
        // - We do not substitute identifiers tagged with the LocalName flag.
        // - We only substitute identifiers that are exported at the top level.
        if ((0, ts_js_1.isAssignmentOperator)(node.operatorToken.kind)
            && (0, ts_js_1.isIdentifier)(node.left)
            && (!(0, ts_js_1.isGeneratedIdentifier)(node.left) || (0, ts_js_1.isFileLevelReservedGeneratedIdentifier)(node.left))
            && !(0, ts_js_1.isLocalName)(node.left)) {
            const exportedNames = getExports(node.left);
            if (exportedNames) {
                // For each additional export of the declaration, apply an export assignment.
                let expression = node;
                for (const exportName of exportedNames) {
                    expression = createExportExpression(exportName, preventSubstitution(expression));
                }
                return expression;
            }
        }
        return node;
    }
    function substituteMetaProperty(node) {
        if ((0, ts_js_1.isImportMeta)(node)) {
            return factory.createPropertyAccessExpression(contextObject, factory.createIdentifier("meta"));
        }
        return node;
    }
    /**
     * Gets the exports of a name.
     *
     * @param name The name.
     */
    function getExports(name) {
        let exportedNames;
        const valueDeclaration = getReferencedDeclaration(name);
        if (valueDeclaration) {
            const exportContainer = resolver.getReferencedExportContainer(name, /*prefixLocals*/ false);
            if (exportContainer && exportContainer.kind === 308 /* SyntaxKind.SourceFile */) {
                exportedNames = (0, ts_js_1.append)(exportedNames, factory.getDeclarationName(valueDeclaration));
            }
            exportedNames = (0, ts_js_1.addRange)(exportedNames, moduleInfo?.exportedBindings[(0, ts_js_1.getOriginalNodeId)(valueDeclaration)]);
        }
        else if ((0, ts_js_1.isGeneratedIdentifier)(name) && (0, ts_js_1.isFileLevelReservedGeneratedIdentifier)(name)) {
            const exportSpecifiers = moduleInfo?.exportSpecifiers.get(name);
            if (exportSpecifiers) {
                const exportedNames = [];
                for (const exportSpecifier of exportSpecifiers) {
                    exportedNames.push(exportSpecifier.name);
                }
                return exportedNames;
            }
        }
        return exportedNames;
    }
    function getReferencedDeclaration(name) {
        if (!(0, ts_js_1.isGeneratedIdentifier)(name)) {
            const importDeclaration = resolver.getReferencedImportDeclaration(name);
            if (importDeclaration)
                return importDeclaration;
            const valueDeclaration = resolver.getReferencedValueDeclaration(name);
            if (valueDeclaration && moduleInfo?.exportedBindings[(0, ts_js_1.getOriginalNodeId)(valueDeclaration)])
                return valueDeclaration;
            // An exported namespace or enum may merge with an ambient declaration, which won't show up in
            // .js emit. When that happens, try to find bindings associated with a non-ambient declaration.
            const declarations = resolver.getReferencedValueDeclarations(name);
            if (declarations) {
                for (const declaration of declarations) {
                    if (declaration !== valueDeclaration && moduleInfo?.exportedBindings[(0, ts_js_1.getOriginalNodeId)(declaration)])
                        return declaration;
                }
            }
            return valueDeclaration;
        }
    }
    /**
     * Prevent substitution of a node for this transformer.
     *
     * @param node The node which should not be substituted.
     */
    function preventSubstitution(node) {
        if (noSubstitution === undefined)
            noSubstitution = [];
        noSubstitution[(0, ts_js_1.getNodeId)(node)] = true;
        return node;
    }
    /**
     * Determines whether a node should not be substituted.
     *
     * @param node The node to test.
     */
    function isSubstitutionPrevented(node) {
        return noSubstitution && node.id && noSubstitution[node.id];
    }
}
