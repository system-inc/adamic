"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEmptyExports = createEmptyExports;
exports.createMemberAccessForPropertyName = createMemberAccessForPropertyName;
exports.createJsxFactoryExpression = createJsxFactoryExpression;
exports.createExpressionForJsxElement = createExpressionForJsxElement;
exports.createExpressionForJsxFragment = createExpressionForJsxFragment;
exports.createForOfBindingStatement = createForOfBindingStatement;
exports.createExpressionFromEntityName = createExpressionFromEntityName;
exports.createExpressionForPropertyName = createExpressionForPropertyName;
exports.createExpressionForObjectLiteralElementLike = createExpressionForObjectLiteralElementLike;
exports.expandPreOrPostfixIncrementOrDecrementExpression = expandPreOrPostfixIncrementOrDecrementExpression;
exports.isInternalName = isInternalName;
exports.isLocalName = isLocalName;
exports.isExportName = isExportName;
exports.findUseStrictPrologue = findUseStrictPrologue;
exports.startsWithUseStrict = startsWithUseStrict;
exports.isCommaExpression = isCommaExpression;
exports.isCommaSequence = isCommaSequence;
exports.isJSDocTypeAssertion = isJSDocTypeAssertion;
exports.getJSDocTypeAssertionType = getJSDocTypeAssertionType;
exports.isOuterExpression = isOuterExpression;
exports.skipOuterExpressions = skipOuterExpressions;
exports.walkUpOuterExpressions = walkUpOuterExpressions;
exports.startOnNewLine = startOnNewLine;
exports.getExternalHelpersModuleName = getExternalHelpersModuleName;
exports.hasRecordedExternalHelpers = hasRecordedExternalHelpers;
exports.createExternalHelpersImportDeclarationIfNeeded = createExternalHelpersImportDeclarationIfNeeded;
exports.getLocalNameForExternalImport = getLocalNameForExternalImport;
exports.getExternalModuleNameLiteral = getExternalModuleNameLiteral;
exports.tryGetModuleNameFromFile = tryGetModuleNameFromFile;
exports.getInitializerOfBindingOrAssignmentElement = getInitializerOfBindingOrAssignmentElement;
exports.getTargetOfBindingOrAssignmentElement = getTargetOfBindingOrAssignmentElement;
exports.getRestIndicatorOfBindingOrAssignmentElement = getRestIndicatorOfBindingOrAssignmentElement;
exports.getPropertyNameOfBindingOrAssignmentElement = getPropertyNameOfBindingOrAssignmentElement;
exports.tryGetPropertyNameOfBindingOrAssignmentElement = tryGetPropertyNameOfBindingOrAssignmentElement;
exports.getElementsOfBindingOrAssignmentPattern = getElementsOfBindingOrAssignmentPattern;
exports.getJSDocTypeAliasName = getJSDocTypeAliasName;
exports.canHaveIllegalType = canHaveIllegalType;
exports.canHaveIllegalTypeParameters = canHaveIllegalTypeParameters;
exports.canHaveIllegalDecorators = canHaveIllegalDecorators;
exports.canHaveIllegalModifiers = canHaveIllegalModifiers;
exports.isQuestionOrExclamationToken = isQuestionOrExclamationToken;
exports.isIdentifierOrThisTypeNode = isIdentifierOrThisTypeNode;
exports.isReadonlyKeywordOrPlusOrMinusToken = isReadonlyKeywordOrPlusOrMinusToken;
exports.isQuestionOrPlusOrMinusToken = isQuestionOrPlusOrMinusToken;
exports.isModuleName = isModuleName;
exports.isShiftOperatorOrHigher = isShiftOperatorOrHigher;
exports.isBinaryOperatorToken = isBinaryOperatorToken;
exports.createBinaryExpressionTrampoline = createBinaryExpressionTrampoline;
exports.isExportOrDefaultModifier = isExportOrDefaultModifier;
exports.elideNodes = elideNodes;
exports.getNodeForGeneratedName = getNodeForGeneratedName;
exports.formatGeneratedNamePart = formatGeneratedNamePart;
exports.formatGeneratedName = formatGeneratedName;
exports.createAccessorPropertyBackingField = createAccessorPropertyBackingField;
exports.createAccessorPropertyGetRedirector = createAccessorPropertyGetRedirector;
exports.createAccessorPropertySetRedirector = createAccessorPropertySetRedirector;
exports.findComputedPropertyNameCacheAssignment = findComputedPropertyNameCacheAssignment;
exports.flattenCommaList = flattenCommaList;
exports.containsObjectRestOrSpread = containsObjectRestOrSpread;
const ts_js_1 = require("../_namespaces/ts.js");
// Compound nodes
/** @internal */
function createEmptyExports(factory) {
    return factory.createExportDeclaration(/*modifiers*/ undefined, /*isTypeOnly*/ false, factory.createNamedExports([]), /*moduleSpecifier*/ undefined);
}
/** @internal */
function createMemberAccessForPropertyName(factory, target, memberName, location) {
    if ((0, ts_js_1.isComputedPropertyName)(memberName)) {
        return (0, ts_js_1.setTextRange)(factory.createElementAccessExpression(target, memberName.expression), location);
    }
    else {
        const expression = (0, ts_js_1.setTextRange)((0, ts_js_1.isMemberName)(memberName)
            ? factory.createPropertyAccessExpression(target, memberName)
            : factory.createElementAccessExpression(target, memberName), memberName);
        (0, ts_js_1.addEmitFlags)(expression, 128 /* EmitFlags.NoNestedSourceMaps */);
        return expression;
    }
}
function createReactNamespace(reactNamespace, parent) {
    // To ensure the emit resolver can properly resolve the namespace, we need to
    // treat this identifier as if it were a source tree node by clearing the `Synthesized`
    // flag and setting a parent node.
    const react = ts_js_1.parseNodeFactory.createIdentifier(reactNamespace || "React");
    // Set the parent that is in parse tree
    // this makes sure that parent chain is intact for checker to traverse complete scope tree
    (0, ts_js_1.setParent)(react, (0, ts_js_1.getParseTreeNode)(parent));
    return react;
}
function createJsxFactoryExpressionFromEntityName(factory, jsxFactory, parent) {
    if ((0, ts_js_1.isQualifiedName)(jsxFactory)) {
        const left = createJsxFactoryExpressionFromEntityName(factory, jsxFactory.left, parent);
        const right = factory.createIdentifier((0, ts_js_1.idText)(jsxFactory.right));
        right.escapedText = jsxFactory.right.escapedText;
        return factory.createPropertyAccessExpression(left, right);
    }
    else {
        return createReactNamespace((0, ts_js_1.idText)(jsxFactory), parent);
    }
}
/** @internal */
function createJsxFactoryExpression(factory, jsxFactoryEntity, reactNamespace, parent) {
    return jsxFactoryEntity ?
        createJsxFactoryExpressionFromEntityName(factory, jsxFactoryEntity, parent) :
        factory.createPropertyAccessExpression(createReactNamespace(reactNamespace, parent), "createElement");
}
function createJsxFragmentFactoryExpression(factory, jsxFragmentFactoryEntity, reactNamespace, parent) {
    return jsxFragmentFactoryEntity ?
        createJsxFactoryExpressionFromEntityName(factory, jsxFragmentFactoryEntity, parent) :
        factory.createPropertyAccessExpression(createReactNamespace(reactNamespace, parent), "Fragment");
}
/** @internal */
function createExpressionForJsxElement(factory, callee, tagName, props, children, location) {
    const argumentsList = [tagName];
    if (props) {
        argumentsList.push(props);
    }
    if (children && children.length > 0) {
        if (!props) {
            argumentsList.push(factory.createNull());
        }
        if (children.length > 1) {
            for (const child of children) {
                startOnNewLine(child);
                argumentsList.push(child);
            }
        }
        else {
            argumentsList.push(children[0]);
        }
    }
    return (0, ts_js_1.setTextRange)(factory.createCallExpression(callee, 
    /*typeArguments*/ undefined, argumentsList), location);
}
/** @internal */
function createExpressionForJsxFragment(factory, jsxFactoryEntity, jsxFragmentFactoryEntity, reactNamespace, children, parentElement, location) {
    const tagName = createJsxFragmentFactoryExpression(factory, jsxFragmentFactoryEntity, reactNamespace, parentElement);
    const argumentsList = [tagName, factory.createNull()];
    if (children && children.length > 0) {
        if (children.length > 1) {
            for (const child of children) {
                startOnNewLine(child);
                argumentsList.push(child);
            }
        }
        else {
            argumentsList.push(children[0]);
        }
    }
    return (0, ts_js_1.setTextRange)(factory.createCallExpression(createJsxFactoryExpression(factory, jsxFactoryEntity, reactNamespace, parentElement), 
    /*typeArguments*/ undefined, argumentsList), location);
}
// Utilities
/** @internal */
function createForOfBindingStatement(factory, node, boundValue) {
    if ((0, ts_js_1.isVariableDeclarationList)(node)) {
        const firstDeclaration = (0, ts_js_1.first)(node.declarations);
        const updatedDeclaration = factory.updateVariableDeclaration(firstDeclaration, firstDeclaration.name, 
        /*exclamationToken*/ undefined, 
        /*type*/ undefined, boundValue);
        return (0, ts_js_1.setTextRange)(factory.createVariableStatement(
        /*modifiers*/ undefined, factory.updateVariableDeclarationList(node, [updatedDeclaration])), 
        /*location*/ node);
    }
    else {
        const updatedExpression = (0, ts_js_1.setTextRange)(factory.createAssignment(node, boundValue), /*location*/ node);
        return (0, ts_js_1.setTextRange)(factory.createExpressionStatement(updatedExpression), /*location*/ node);
    }
}
/** @internal */
function createExpressionFromEntityName(factory, node) {
    if ((0, ts_js_1.isQualifiedName)(node)) {
        const left = createExpressionFromEntityName(factory, node.left);
        // TODO(rbuckton): Does this need to be parented?
        const right = (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(node.right), node.right), node.right.parent);
        return (0, ts_js_1.setTextRange)(factory.createPropertyAccessExpression(left, right), node);
    }
    else {
        // TODO(rbuckton): Does this need to be parented?
        return (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(node), node), node.parent);
    }
}
/** @internal */
function createExpressionForPropertyName(factory, memberName) {
    if ((0, ts_js_1.isIdentifier)(memberName)) {
        return factory.createStringLiteralFromNode(memberName);
    }
    else if ((0, ts_js_1.isComputedPropertyName)(memberName)) {
        // TODO(rbuckton): Does this need to be parented?
        return (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(memberName.expression), memberName.expression), memberName.expression.parent);
    }
    else {
        // TODO(rbuckton): Does this need to be parented?
        return (0, ts_js_1.setParent)((0, ts_js_1.setTextRange)(factory.cloneNode(memberName), memberName), memberName.parent);
    }
}
function createExpressionForAccessorDeclaration(factory, properties, property, receiver, multiLine) {
    const { firstAccessor, getAccessor, setAccessor } = (0, ts_js_1.getAllAccessorDeclarations)(properties, property);
    if (property === firstAccessor) {
        return (0, ts_js_1.setTextRange)(factory.createObjectDefinePropertyCall(receiver, createExpressionForPropertyName(factory, property.name), factory.createPropertyDescriptor({
            enumerable: factory.createFalse(),
            configurable: true,
            get: getAccessor && (0, ts_js_1.setTextRange)((0, ts_js_1.setOriginalNode)(factory.createFunctionExpression((0, ts_js_1.getModifiers)(getAccessor), 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, getAccessor.parameters, 
            /*type*/ undefined, getAccessor.body), getAccessor), getAccessor),
            set: setAccessor && (0, ts_js_1.setTextRange)((0, ts_js_1.setOriginalNode)(factory.createFunctionExpression((0, ts_js_1.getModifiers)(setAccessor), 
            /*asteriskToken*/ undefined, 
            /*name*/ undefined, 
            /*typeParameters*/ undefined, setAccessor.parameters, 
            /*type*/ undefined, setAccessor.body), setAccessor), setAccessor),
        }, !multiLine)), firstAccessor);
    }
    return undefined;
}
function createExpressionForPropertyAssignment(factory, property, receiver) {
    return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createAssignment(createMemberAccessForPropertyName(factory, receiver, property.name, /*location*/ property.name), property.initializer), property), property);
}
function createExpressionForShorthandPropertyAssignment(factory, property, receiver) {
    return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createAssignment(createMemberAccessForPropertyName(factory, receiver, property.name, /*location*/ property.name), factory.cloneNode(property.name)), 
    /*location*/ property), 
    /*original*/ property);
}
function createExpressionForMethodDeclaration(factory, method, receiver) {
    return (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createAssignment(createMemberAccessForPropertyName(factory, receiver, method.name, /*location*/ method.name), (0, ts_js_1.setOriginalNode)((0, ts_js_1.setTextRange)(factory.createFunctionExpression((0, ts_js_1.getModifiers)(method), method.asteriskToken, 
    /*name*/ undefined, 
    /*typeParameters*/ undefined, method.parameters, 
    /*type*/ undefined, method.body), 
    /*location*/ method), 
    /*original*/ method)), 
    /*location*/ method), 
    /*original*/ method);
}
/** @internal */
function createExpressionForObjectLiteralElementLike(factory, node, property, receiver) {
    if (property.name && (0, ts_js_1.isPrivateIdentifier)(property.name)) {
        ts_js_1.Debug.failBadSyntaxKind(property.name, "Private identifiers are not allowed in object literals.");
    }
    switch (property.kind) {
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
            return createExpressionForAccessorDeclaration(factory, node.properties, property, receiver, !!node.multiLine);
        case 304 /* SyntaxKind.PropertyAssignment */:
            return createExpressionForPropertyAssignment(factory, property, receiver);
        case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
            return createExpressionForShorthandPropertyAssignment(factory, property, receiver);
        case 175 /* SyntaxKind.MethodDeclaration */:
            return createExpressionForMethodDeclaration(factory, property, receiver);
    }
}
/**
 * Expand the read and increment/decrement operations a pre- or post-increment or pre- or post-decrement expression.
 *
 * ```ts
 * // input
 * <expression>++
 * // output (if result is not discarded)
 * var <temp>;
 * (<temp> = <expression>, <resultVariable> = <temp>++, <temp>)
 * // output (if result is discarded)
 * var <temp>;
 * (<temp> = <expression>, <temp>++, <temp>)
 *
 * // input
 * ++<expression>
 * // output (if result is not discarded)
 * var <temp>;
 * (<temp> = <expression>, <resultVariable> = ++<temp>)
 * // output (if result is discarded)
 * var <temp>;
 * (<temp> = <expression>, ++<temp>)
 * ```
 *
 * It is up to the caller to supply a temporary variable for `<resultVariable>` if one is needed.
 * The temporary variable `<temp>` is injected so that `++` and `--` work uniformly with `number` and `bigint`.
 * The result of the expression is always the final result of incrementing or decrementing the expression, so that it can be used for storage.
 *
 * @param factory {@link NodeFactory} used to create the expanded representation.
 * @param node The original prefix or postfix unary node.
 * @param expression The expression to use as the value to increment or decrement
 * @param resultVariable A temporary variable in which to store the result. Pass `undefined` if the result is discarded, or if the value of `<temp>` is the expected result.
 *
 * @internal
 */
function expandPreOrPostfixIncrementOrDecrementExpression(factory, node, expression, recordTempVariable, resultVariable) {
    const operator = node.operator;
    ts_js_1.Debug.assert(operator === 46 /* SyntaxKind.PlusPlusToken */ || operator === 47 /* SyntaxKind.MinusMinusToken */, "Expected 'node' to be a pre- or post-increment or pre- or post-decrement expression");
    const temp = factory.createTempVariable(recordTempVariable);
    expression = factory.createAssignment(temp, expression);
    (0, ts_js_1.setTextRange)(expression, node.operand);
    let operation = (0, ts_js_1.isPrefixUnaryExpression)(node) ?
        factory.createPrefixUnaryExpression(operator, temp) :
        factory.createPostfixUnaryExpression(temp, operator);
    (0, ts_js_1.setTextRange)(operation, node);
    if (resultVariable) {
        operation = factory.createAssignment(resultVariable, operation);
        (0, ts_js_1.setTextRange)(operation, node);
    }
    expression = factory.createComma(expression, operation);
    (0, ts_js_1.setTextRange)(expression, node);
    if ((0, ts_js_1.isPostfixUnaryExpression)(node)) {
        expression = factory.createComma(expression, temp);
        (0, ts_js_1.setTextRange)(expression, node);
    }
    return expression;
}
/**
 * Gets whether an identifier should only be referred to by its internal name.
 *
 * @internal
 */
function isInternalName(node) {
    return ((0, ts_js_1.getEmitFlags)(node) & 65536 /* EmitFlags.InternalName */) !== 0;
}
/**
 * Gets whether an identifier should only be referred to by its local name.
 *
 * @internal
 */
function isLocalName(node) {
    return ((0, ts_js_1.getEmitFlags)(node) & 32768 /* EmitFlags.LocalName */) !== 0;
}
/**
 * Gets whether an identifier should only be referred to by its export representation if the
 * name points to an exported symbol.
 *
 * @internal
 */
function isExportName(node) {
    return ((0, ts_js_1.getEmitFlags)(node) & 16384 /* EmitFlags.ExportName */) !== 0;
}
function isUseStrictPrologue(node) {
    return (0, ts_js_1.isStringLiteral)(node.expression) && node.expression.text === "use strict";
}
/** @internal */
function findUseStrictPrologue(statements) {
    for (const statement of statements) {
        if ((0, ts_js_1.isPrologueDirective)(statement)) {
            if (isUseStrictPrologue(statement)) {
                return statement;
            }
        }
        else {
            break;
        }
    }
    return undefined;
}
/** @internal */
function startsWithUseStrict(statements) {
    const firstStatement = (0, ts_js_1.firstOrUndefined)(statements);
    return firstStatement !== undefined
        && (0, ts_js_1.isPrologueDirective)(firstStatement)
        && isUseStrictPrologue(firstStatement);
}
/** @internal */
function isCommaExpression(node) {
    return node.kind === 227 /* SyntaxKind.BinaryExpression */ && node.operatorToken.kind === 28 /* SyntaxKind.CommaToken */;
}
/** @internal */
function isCommaSequence(node) {
    return isCommaExpression(node) || (0, ts_js_1.isCommaListExpression)(node);
}
/** @internal */
function isJSDocTypeAssertion(node) {
    return (0, ts_js_1.isParenthesizedExpression)(node)
        && (0, ts_js_1.isInJSFile)(node)
        && !!(0, ts_js_1.getJSDocTypeTag)(node);
}
/** @internal */
function getJSDocTypeAssertionType(node) {
    const type = (0, ts_js_1.getJSDocType)(node);
    ts_js_1.Debug.assertIsDefined(type);
    return type;
}
/** @internal */
function isOuterExpression(node, kinds = 63 /* OuterExpressionKinds.All */) {
    switch (node.kind) {
        case 218 /* SyntaxKind.ParenthesizedExpression */:
            if (kinds & -2147483648 /* OuterExpressionKinds.ExcludeJSDocTypeAssertion */ && isJSDocTypeAssertion(node)) {
                return false;
            }
            return (kinds & 1 /* OuterExpressionKinds.Parentheses */) !== 0;
        case 217 /* SyntaxKind.TypeAssertionExpression */:
        case 235 /* SyntaxKind.AsExpression */:
            return (kinds & 2 /* OuterExpressionKinds.TypeAssertions */) !== 0;
        case 239 /* SyntaxKind.SatisfiesExpression */:
            return (kinds & (2 /* OuterExpressionKinds.TypeAssertions */ | 32 /* OuterExpressionKinds.Satisfies */)) !== 0;
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
            return (kinds & 16 /* OuterExpressionKinds.ExpressionsWithTypeArguments */) !== 0;
        case 236 /* SyntaxKind.NonNullExpression */:
            return (kinds & 4 /* OuterExpressionKinds.NonNullAssertions */) !== 0;
        case 356 /* SyntaxKind.PartiallyEmittedExpression */:
            return (kinds & 8 /* OuterExpressionKinds.PartiallyEmittedExpressions */) !== 0;
    }
    return false;
}
/** @internal */
function skipOuterExpressions(node, kinds = 63 /* OuterExpressionKinds.All */) {
    while (isOuterExpression(node, kinds)) {
        node = node.expression;
    }
    return node;
}
/** @internal */
function walkUpOuterExpressions(node, kinds = 63 /* OuterExpressionKinds.All */) {
    let parent = node.parent;
    while (isOuterExpression(parent, kinds)) {
        parent = parent.parent;
        ts_js_1.Debug.assert(parent);
    }
    return parent;
}
/** @internal */
function startOnNewLine(node) {
    return (0, ts_js_1.setStartsOnNewLine)(node, /*newLine*/ true);
}
/** @internal */
function getExternalHelpersModuleName(node) {
    const parseNode = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isSourceFile);
    const emitNode = parseNode && parseNode.emitNode;
    return emitNode && emitNode.externalHelpersModuleName;
}
/** @internal */
function hasRecordedExternalHelpers(sourceFile) {
    const parseNode = (0, ts_js_1.getOriginalNode)(sourceFile, ts_js_1.isSourceFile);
    const emitNode = parseNode && parseNode.emitNode;
    return !!emitNode && (!!emitNode.externalHelpersModuleName || !!emitNode.externalHelpers);
}
/** @internal */
function createExternalHelpersImportDeclarationIfNeeded(nodeFactory, helperFactory, sourceFile, compilerOptions, hasExportStarsToExportValues, hasImportStar, hasImportDefault) {
    if (compilerOptions.importHelpers && (0, ts_js_1.isEffectiveExternalModule)(sourceFile, compilerOptions)) {
        const moduleKind = (0, ts_js_1.getEmitModuleKind)(compilerOptions);
        const impliedModuleKind = (0, ts_js_1.getImpliedNodeFormatForEmitWorker)(sourceFile, compilerOptions);
        const helpers = getImportedHelpers(sourceFile);
        if (impliedModuleKind !== ts_js_1.ModuleKind.CommonJS &&
            ((moduleKind >= ts_js_1.ModuleKind.ES2015 && moduleKind <= ts_js_1.ModuleKind.ESNext) ||
                impliedModuleKind === ts_js_1.ModuleKind.ESNext ||
                impliedModuleKind === undefined && moduleKind === ts_js_1.ModuleKind.Preserve)) {
            // When we emit as an ES module, generate an `import` declaration that uses named imports for helpers.
            // If we cannot determine the implied module kind under `module: preserve` we assume ESM.
            if (helpers) {
                const helperNames = [];
                for (const helper of helpers) {
                    const importName = helper.importName;
                    if (importName) {
                        (0, ts_js_1.pushIfUnique)(helperNames, importName);
                    }
                }
                if ((0, ts_js_1.some)(helperNames)) {
                    helperNames.sort(ts_js_1.compareStringsCaseSensitive);
                    // Alias the imports if the names are used somewhere in the file.
                    // NOTE: We don't need to care about global import collisions as this is a module.
                    const namedBindings = nodeFactory.createNamedImports((0, ts_js_1.map)(helperNames, name => (0, ts_js_1.isFileLevelUniqueName)(sourceFile, name)
                        ? nodeFactory.createImportSpecifier(/*isTypeOnly*/ false, /*propertyName*/ undefined, nodeFactory.createIdentifier(name))
                        : nodeFactory.createImportSpecifier(/*isTypeOnly*/ false, nodeFactory.createIdentifier(name), helperFactory.getUnscopedHelperName(name))));
                    const parseNode = (0, ts_js_1.getOriginalNode)(sourceFile, ts_js_1.isSourceFile);
                    const emitNode = (0, ts_js_1.getOrCreateEmitNode)(parseNode);
                    emitNode.externalHelpers = true;
                    const externalHelpersImportDeclaration = nodeFactory.createImportDeclaration(
                    /*modifiers*/ undefined, nodeFactory.createImportClause(/*phaseModifier*/ undefined, /*name*/ undefined, namedBindings), nodeFactory.createStringLiteral(ts_js_1.externalHelpersModuleNameText), 
                    /*attributes*/ undefined);
                    (0, ts_js_1.addInternalEmitFlags)(externalHelpersImportDeclaration, 2 /* InternalEmitFlags.NeverApplyImportHelper */);
                    return externalHelpersImportDeclaration;
                }
            }
        }
        else {
            // When we emit to a non-ES module, generate a synthetic `import tslib = require("tslib")` to be further transformed.
            const externalHelpersModuleName = getOrCreateExternalHelpersModuleNameIfNeeded(nodeFactory, sourceFile, compilerOptions, helpers, hasExportStarsToExportValues, hasImportStar || hasImportDefault);
            if (externalHelpersModuleName) {
                const externalHelpersImportDeclaration = nodeFactory.createImportEqualsDeclaration(
                /*modifiers*/ undefined, 
                /*isTypeOnly*/ false, externalHelpersModuleName, nodeFactory.createExternalModuleReference(nodeFactory.createStringLiteral(ts_js_1.externalHelpersModuleNameText)));
                (0, ts_js_1.addInternalEmitFlags)(externalHelpersImportDeclaration, 2 /* InternalEmitFlags.NeverApplyImportHelper */);
                return externalHelpersImportDeclaration;
            }
        }
    }
}
function getImportedHelpers(sourceFile) {
    return (0, ts_js_1.filter)((0, ts_js_1.getEmitHelpers)(sourceFile), helper => !helper.scoped);
}
function getOrCreateExternalHelpersModuleNameIfNeeded(factory, node, compilerOptions, helpers, hasExportStarsToExportValues, hasImportStarOrImportDefault) {
    const externalHelpersModuleName = getExternalHelpersModuleName(node);
    if (externalHelpersModuleName) {
        return externalHelpersModuleName;
    }
    const create = (0, ts_js_1.some)(helpers)
        || (hasExportStarsToExportValues || ((0, ts_js_1.getESModuleInterop)(compilerOptions) && hasImportStarOrImportDefault))
            && (0, ts_js_1.getEmitModuleFormatOfFileWorker)(node, compilerOptions) < ts_js_1.ModuleKind.System;
    if (create) {
        const parseNode = (0, ts_js_1.getOriginalNode)(node, ts_js_1.isSourceFile);
        const emitNode = (0, ts_js_1.getOrCreateEmitNode)(parseNode);
        return emitNode.externalHelpersModuleName || (emitNode.externalHelpersModuleName = factory.createUniqueName(ts_js_1.externalHelpersModuleNameText));
    }
}
/**
 * Get the name of that target module from an import or export declaration
 *
 * @internal
 */
function getLocalNameForExternalImport(factory, node, sourceFile) {
    const namespaceDeclaration = (0, ts_js_1.getNamespaceDeclarationNode)(node);
    if (namespaceDeclaration && !(0, ts_js_1.isDefaultImport)(node) && !(0, ts_js_1.isExportNamespaceAsDefaultDeclaration)(node)) {
        const name = namespaceDeclaration.name;
        if (name.kind === 11 /* SyntaxKind.StringLiteral */) {
            return factory.getGeneratedNameForNode(node);
        }
        return (0, ts_js_1.isGeneratedIdentifier)(name) ? name : factory.createIdentifier((0, ts_js_1.getSourceTextOfNodeFromSourceFile)(sourceFile, name) || (0, ts_js_1.idText)(name));
    }
    if (node.kind === 273 /* SyntaxKind.ImportDeclaration */ && node.importClause) {
        return factory.getGeneratedNameForNode(node);
    }
    if (node.kind === 279 /* SyntaxKind.ExportDeclaration */ && node.moduleSpecifier) {
        return factory.getGeneratedNameForNode(node);
    }
    return undefined;
}
/**
 * Get the name of a target module from an import/export declaration as should be written in the emitted output.
 * The emitted output name can be different from the input if:
 *  1. The module has a /// <amd-module name="<new name>" />
 *  2. --out or --outFile is used, making the name relative to the rootDir
 *  3- The containing SourceFile has an entry in renamedDependencies for the import as requested by some module loaders (e.g. System).
 * Otherwise, a new StringLiteral node representing the module name will be returned.
 *
 * @internal
 */
function getExternalModuleNameLiteral(factory, importNode, sourceFile, host, resolver, compilerOptions) {
    const moduleName = (0, ts_js_1.getExternalModuleName)(importNode);
    if (moduleName && (0, ts_js_1.isStringLiteral)(moduleName)) {
        return tryGetModuleNameFromDeclaration(importNode, host, factory, resolver, compilerOptions)
            || tryRenameExternalModule(factory, moduleName, sourceFile)
            || factory.cloneNode(moduleName);
    }
    return undefined;
}
/**
 * Some bundlers (SystemJS builder) sometimes want to rename dependencies.
 * Here we check if alternative name was provided for a given moduleName and return it if possible.
 */
function tryRenameExternalModule(factory, moduleName, sourceFile) {
    const rename = sourceFile.renamedDependencies && sourceFile.renamedDependencies.get(moduleName.text);
    return rename ? factory.createStringLiteral(rename) : undefined;
}
/**
 * Get the name of a module as should be written in the emitted output.
 * The emitted output name can be different from the input if:
 *  1. The module has a /// <amd-module name="<new name>" />
 *  2. --out or --outFile is used, making the name relative to the rootDir
 * Otherwise, a new StringLiteral node representing the module name will be returned.
 *
 * @internal
 */
function tryGetModuleNameFromFile(factory, file, host, options) {
    if (!file) {
        return undefined;
    }
    if (file.moduleName) {
        return factory.createStringLiteral(file.moduleName);
    }
    if (!file.isDeclarationFile && options.outFile) {
        return factory.createStringLiteral((0, ts_js_1.getExternalModuleNameFromPath)(host, file.fileName));
    }
    return undefined;
}
function tryGetModuleNameFromDeclaration(declaration, host, factory, resolver, compilerOptions) {
    return tryGetModuleNameFromFile(factory, resolver.getExternalModuleFileFromDeclaration(declaration), host, compilerOptions);
}
/**
 * Gets the initializer of an BindingOrAssignmentElement.
 *
 * @internal
 */
function getInitializerOfBindingOrAssignmentElement(bindingElement) {
    if ((0, ts_js_1.isDeclarationBindingElement)(bindingElement)) {
        // `1` in `let { a = 1 } = ...`
        // `1` in `let { a: b = 1 } = ...`
        // `1` in `let { a: {b} = 1 } = ...`
        // `1` in `let { a: [b] = 1 } = ...`
        // `1` in `let [a = 1] = ...`
        // `1` in `let [{a} = 1] = ...`
        // `1` in `let [[a] = 1] = ...`
        return bindingElement.initializer;
    }
    if ((0, ts_js_1.isPropertyAssignment)(bindingElement)) {
        // `1` in `({ a: b = 1 } = ...)`
        // `1` in `({ a: {b} = 1 } = ...)`
        // `1` in `({ a: [b] = 1 } = ...)`
        const initializer = bindingElement.initializer;
        return (0, ts_js_1.isAssignmentExpression)(initializer, /*excludeCompoundAssignment*/ true)
            ? initializer.right
            : undefined;
    }
    if ((0, ts_js_1.isShorthandPropertyAssignment)(bindingElement)) {
        // `1` in `({ a = 1 } = ...)`
        return bindingElement.objectAssignmentInitializer;
    }
    if ((0, ts_js_1.isAssignmentExpression)(bindingElement, /*excludeCompoundAssignment*/ true)) {
        // `1` in `[a = 1] = ...`
        // `1` in `[{a} = 1] = ...`
        // `1` in `[[a] = 1] = ...`
        return bindingElement.right;
    }
    if ((0, ts_js_1.isSpreadElement)(bindingElement)) {
        // Recovery consistent with existing emit.
        return getInitializerOfBindingOrAssignmentElement(bindingElement.expression);
    }
}
/**
 * Gets the name of an BindingOrAssignmentElement.
 *
 * @internal
 */
function getTargetOfBindingOrAssignmentElement(bindingElement) {
    if ((0, ts_js_1.isDeclarationBindingElement)(bindingElement)) {
        // `a` in `let { a } = ...`
        // `a` in `let { a = 1 } = ...`
        // `b` in `let { a: b } = ...`
        // `b` in `let { a: b = 1 } = ...`
        // `a` in `let { ...a } = ...`
        // `{b}` in `let { a: {b} } = ...`
        // `{b}` in `let { a: {b} = 1 } = ...`
        // `[b]` in `let { a: [b] } = ...`
        // `[b]` in `let { a: [b] = 1 } = ...`
        // `a` in `let [a] = ...`
        // `a` in `let [a = 1] = ...`
        // `a` in `let [...a] = ...`
        // `{a}` in `let [{a}] = ...`
        // `{a}` in `let [{a} = 1] = ...`
        // `[a]` in `let [[a]] = ...`
        // `[a]` in `let [[a] = 1] = ...`
        return bindingElement.name;
    }
    if ((0, ts_js_1.isObjectLiteralElementLike)(bindingElement)) {
        switch (bindingElement.kind) {
            case 304 /* SyntaxKind.PropertyAssignment */:
                // `b` in `({ a: b } = ...)`
                // `b` in `({ a: b = 1 } = ...)`
                // `{b}` in `({ a: {b} } = ...)`
                // `{b}` in `({ a: {b} = 1 } = ...)`
                // `[b]` in `({ a: [b] } = ...)`
                // `[b]` in `({ a: [b] = 1 } = ...)`
                // `b.c` in `({ a: b.c } = ...)`
                // `b.c` in `({ a: b.c = 1 } = ...)`
                // `b[0]` in `({ a: b[0] } = ...)`
                // `b[0]` in `({ a: b[0] = 1 } = ...)`
                return getTargetOfBindingOrAssignmentElement(bindingElement.initializer);
            case 305 /* SyntaxKind.ShorthandPropertyAssignment */:
                // `a` in `({ a } = ...)`
                // `a` in `({ a = 1 } = ...)`
                return bindingElement.name;
            case 306 /* SyntaxKind.SpreadAssignment */:
                // `a` in `({ ...a } = ...)`
                return getTargetOfBindingOrAssignmentElement(bindingElement.expression);
        }
        // no target
        return undefined;
    }
    if ((0, ts_js_1.isAssignmentExpression)(bindingElement, /*excludeCompoundAssignment*/ true)) {
        // `a` in `[a = 1] = ...`
        // `{a}` in `[{a} = 1] = ...`
        // `[a]` in `[[a] = 1] = ...`
        // `a.b` in `[a.b = 1] = ...`
        // `a[0]` in `[a[0] = 1] = ...`
        return getTargetOfBindingOrAssignmentElement(bindingElement.left);
    }
    if ((0, ts_js_1.isSpreadElement)(bindingElement)) {
        // `a` in `[...a] = ...`
        return getTargetOfBindingOrAssignmentElement(bindingElement.expression);
    }
    // `a` in `[a] = ...`
    // `{a}` in `[{a}] = ...`
    // `[a]` in `[[a]] = ...`
    // `a.b` in `[a.b] = ...`
    // `a[0]` in `[a[0]] = ...`
    return bindingElement;
}
/**
 * Determines whether an BindingOrAssignmentElement is a rest element.
 *
 * @internal
 */
function getRestIndicatorOfBindingOrAssignmentElement(bindingElement) {
    switch (bindingElement.kind) {
        case 170 /* SyntaxKind.Parameter */:
        case 209 /* SyntaxKind.BindingElement */:
            // `...` in `let [...a] = ...`
            return bindingElement.dotDotDotToken;
        case 231 /* SyntaxKind.SpreadElement */:
        case 306 /* SyntaxKind.SpreadAssignment */:
            // `...` in `[...a] = ...`
            return bindingElement;
    }
    return undefined;
}
/**
 * Gets the property name of a BindingOrAssignmentElement
 *
 * @internal
 */
function getPropertyNameOfBindingOrAssignmentElement(bindingElement) {
    const propertyName = tryGetPropertyNameOfBindingOrAssignmentElement(bindingElement);
    ts_js_1.Debug.assert(!!propertyName || (0, ts_js_1.isSpreadAssignment)(bindingElement), "Invalid property name for binding element.");
    return propertyName;
}
/** @internal */
function tryGetPropertyNameOfBindingOrAssignmentElement(bindingElement) {
    switch (bindingElement.kind) {
        case 209 /* SyntaxKind.BindingElement */:
            // `a` in `let { a: b } = ...`
            // `[a]` in `let { [a]: b } = ...`
            // `"a"` in `let { "a": b } = ...`
            // `1` in `let { 1: b } = ...`
            if (bindingElement.propertyName) {
                const propertyName = bindingElement.propertyName;
                if ((0, ts_js_1.isPrivateIdentifier)(propertyName)) {
                    return ts_js_1.Debug.failBadSyntaxKind(propertyName);
                }
                return (0, ts_js_1.isComputedPropertyName)(propertyName) && isStringOrNumericLiteral(propertyName.expression)
                    ? propertyName.expression
                    : propertyName;
            }
            break;
        case 304 /* SyntaxKind.PropertyAssignment */:
            // `a` in `({ a: b } = ...)`
            // `[a]` in `({ [a]: b } = ...)`
            // `"a"` in `({ "a": b } = ...)`
            // `1` in `({ 1: b } = ...)`
            if (bindingElement.name) {
                const propertyName = bindingElement.name;
                if ((0, ts_js_1.isPrivateIdentifier)(propertyName)) {
                    return ts_js_1.Debug.failBadSyntaxKind(propertyName);
                }
                return (0, ts_js_1.isComputedPropertyName)(propertyName) && isStringOrNumericLiteral(propertyName.expression)
                    ? propertyName.expression
                    : propertyName;
            }
            break;
        case 306 /* SyntaxKind.SpreadAssignment */:
            // `a` in `({ ...a } = ...)`
            if (bindingElement.name && (0, ts_js_1.isPrivateIdentifier)(bindingElement.name)) {
                return ts_js_1.Debug.failBadSyntaxKind(bindingElement.name);
            }
            return bindingElement.name;
    }
    const target = getTargetOfBindingOrAssignmentElement(bindingElement);
    if (target && (0, ts_js_1.isPropertyName)(target)) {
        return target;
    }
}
function isStringOrNumericLiteral(node) {
    const kind = node.kind;
    return kind === 11 /* SyntaxKind.StringLiteral */
        || kind === 9 /* SyntaxKind.NumericLiteral */;
}
/**
 * Gets the elements of a BindingOrAssignmentPattern
 *
 * @internal
 */
function getElementsOfBindingOrAssignmentPattern(name) {
    switch (name.kind) {
        case 207 /* SyntaxKind.ObjectBindingPattern */:
        case 208 /* SyntaxKind.ArrayBindingPattern */:
        case 210 /* SyntaxKind.ArrayLiteralExpression */:
            // `a` in `{a}`
            // `a` in `[a]`
            return name.elements;
        case 211 /* SyntaxKind.ObjectLiteralExpression */:
            // `a` in `{a}`
            return name.properties;
    }
}
/** @internal */
function getJSDocTypeAliasName(fullName) {
    if (fullName) {
        let rightNode = fullName;
        while (true) {
            if ((0, ts_js_1.isIdentifier)(rightNode) || !rightNode.body) {
                return (0, ts_js_1.isIdentifier)(rightNode) ? rightNode : rightNode.name;
            }
            rightNode = rightNode.body;
        }
    }
}
/** @internal @knipignore */
function canHaveIllegalType(node) {
    const kind = node.kind;
    return kind === 177 /* SyntaxKind.Constructor */
        || kind === 179 /* SyntaxKind.SetAccessor */;
}
/** @internal */
function canHaveIllegalTypeParameters(node) {
    const kind = node.kind;
    return kind === 177 /* SyntaxKind.Constructor */
        || kind === 178 /* SyntaxKind.GetAccessor */
        || kind === 179 /* SyntaxKind.SetAccessor */;
}
/** @internal */
function canHaveIllegalDecorators(node) {
    const kind = node.kind;
    return kind === 304 /* SyntaxKind.PropertyAssignment */
        || kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */
        || kind === 263 /* SyntaxKind.FunctionDeclaration */
        || kind === 177 /* SyntaxKind.Constructor */
        || kind === 182 /* SyntaxKind.IndexSignature */
        || kind === 176 /* SyntaxKind.ClassStaticBlockDeclaration */
        || kind === 283 /* SyntaxKind.MissingDeclaration */
        || kind === 244 /* SyntaxKind.VariableStatement */
        || kind === 265 /* SyntaxKind.InterfaceDeclaration */
        || kind === 266 /* SyntaxKind.TypeAliasDeclaration */
        || kind === 267 /* SyntaxKind.EnumDeclaration */
        || kind === 268 /* SyntaxKind.ModuleDeclaration */
        || kind === 272 /* SyntaxKind.ImportEqualsDeclaration */
        || kind === 273 /* SyntaxKind.ImportDeclaration */
        || kind === 271 /* SyntaxKind.NamespaceExportDeclaration */
        || kind === 279 /* SyntaxKind.ExportDeclaration */
        || kind === 278 /* SyntaxKind.ExportAssignment */;
}
/** @internal */
function canHaveIllegalModifiers(node) {
    const kind = node.kind;
    return kind === 176 /* SyntaxKind.ClassStaticBlockDeclaration */
        || kind === 304 /* SyntaxKind.PropertyAssignment */
        || kind === 305 /* SyntaxKind.ShorthandPropertyAssignment */
        || kind === 283 /* SyntaxKind.MissingDeclaration */
        || kind === 271 /* SyntaxKind.NamespaceExportDeclaration */;
}
function isQuestionOrExclamationToken(node) {
    return (0, ts_js_1.isQuestionToken)(node) || (0, ts_js_1.isExclamationToken)(node);
}
function isIdentifierOrThisTypeNode(node) {
    return (0, ts_js_1.isIdentifier)(node) || (0, ts_js_1.isThisTypeNode)(node);
}
function isReadonlyKeywordOrPlusOrMinusToken(node) {
    return (0, ts_js_1.isReadonlyKeyword)(node) || (0, ts_js_1.isPlusToken)(node) || (0, ts_js_1.isMinusToken)(node);
}
function isQuestionOrPlusOrMinusToken(node) {
    return (0, ts_js_1.isQuestionToken)(node) || (0, ts_js_1.isPlusToken)(node) || (0, ts_js_1.isMinusToken)(node);
}
function isModuleName(node) {
    return (0, ts_js_1.isIdentifier)(node) || (0, ts_js_1.isStringLiteral)(node);
}
function isExponentiationOperator(kind) {
    return kind === 43 /* SyntaxKind.AsteriskAsteriskToken */;
}
function isMultiplicativeOperator(kind) {
    return kind === 42 /* SyntaxKind.AsteriskToken */
        || kind === 44 /* SyntaxKind.SlashToken */
        || kind === 45 /* SyntaxKind.PercentToken */;
}
function isMultiplicativeOperatorOrHigher(kind) {
    return isExponentiationOperator(kind)
        || isMultiplicativeOperator(kind);
}
function isAdditiveOperator(kind) {
    return kind === 40 /* SyntaxKind.PlusToken */
        || kind === 41 /* SyntaxKind.MinusToken */;
}
function isAdditiveOperatorOrHigher(kind) {
    return isAdditiveOperator(kind)
        || isMultiplicativeOperatorOrHigher(kind);
}
function isShiftOperator(kind) {
    return kind === 48 /* SyntaxKind.LessThanLessThanToken */
        || kind === 49 /* SyntaxKind.GreaterThanGreaterThanToken */
        || kind === 50 /* SyntaxKind.GreaterThanGreaterThanGreaterThanToken */;
}
/** @internal */
function isShiftOperatorOrHigher(kind) {
    return isShiftOperator(kind)
        || isAdditiveOperatorOrHigher(kind);
}
function isRelationalOperator(kind) {
    return kind === 30 /* SyntaxKind.LessThanToken */
        || kind === 33 /* SyntaxKind.LessThanEqualsToken */
        || kind === 32 /* SyntaxKind.GreaterThanToken */
        || kind === 34 /* SyntaxKind.GreaterThanEqualsToken */
        || kind === 104 /* SyntaxKind.InstanceOfKeyword */
        || kind === 103 /* SyntaxKind.InKeyword */;
}
function isRelationalOperatorOrHigher(kind) {
    return isRelationalOperator(kind)
        || isShiftOperatorOrHigher(kind);
}
function isEqualityOperator(kind) {
    return kind === 35 /* SyntaxKind.EqualsEqualsToken */
        || kind === 37 /* SyntaxKind.EqualsEqualsEqualsToken */
        || kind === 36 /* SyntaxKind.ExclamationEqualsToken */
        || kind === 38 /* SyntaxKind.ExclamationEqualsEqualsToken */;
}
function isEqualityOperatorOrHigher(kind) {
    return isEqualityOperator(kind)
        || isRelationalOperatorOrHigher(kind);
}
function isBitwiseOperator(kind) {
    return kind === 51 /* SyntaxKind.AmpersandToken */
        || kind === 52 /* SyntaxKind.BarToken */
        || kind === 53 /* SyntaxKind.CaretToken */;
}
function isBitwiseOperatorOrHigher(kind) {
    return isBitwiseOperator(kind)
        || isEqualityOperatorOrHigher(kind);
}
// NOTE: The version in utilities includes ExclamationToken, which is not a binary operator.
function isLogicalOperator(kind) {
    return kind === 56 /* SyntaxKind.AmpersandAmpersandToken */
        || kind === 57 /* SyntaxKind.BarBarToken */;
}
function isLogicalOperatorOrHigher(kind) {
    return isLogicalOperator(kind)
        || isBitwiseOperatorOrHigher(kind);
}
function isAssignmentOperatorOrHigher(kind) {
    return kind === 61 /* SyntaxKind.QuestionQuestionToken */
        || isLogicalOperatorOrHigher(kind)
        || (0, ts_js_1.isAssignmentOperator)(kind);
}
function isBinaryOperator(kind) {
    return isAssignmentOperatorOrHigher(kind)
        || kind === 28 /* SyntaxKind.CommaToken */;
}
function isBinaryOperatorToken(node) {
    return isBinaryOperator(node.kind);
}
var BinaryExpressionState;
(function (BinaryExpressionState) {
    /**
     * Handles walking into a `BinaryExpression`.
     * @param machine State machine handler functions
     * @param frame The current frame
     * @returns The new frame
     */
    function enter(machine, stackIndex, stateStack, nodeStack, userStateStack, _resultHolder, outerState) {
        const prevUserState = stackIndex > 0 ? userStateStack[stackIndex - 1] : undefined;
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], enter);
        userStateStack[stackIndex] = machine.onEnter(nodeStack[stackIndex], prevUserState, outerState);
        stateStack[stackIndex] = nextState(machine, enter);
        return stackIndex;
    }
    BinaryExpressionState.enter = enter;
    /**
     * Handles walking the `left` side of a `BinaryExpression`.
     * @param machine State machine handler functions
     * @param frame The current frame
     * @returns The new frame
     */
    function left(machine, stackIndex, stateStack, nodeStack, userStateStack, _resultHolder, _outerState) {
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], left);
        ts_js_1.Debug.assertIsDefined(machine.onLeft);
        stateStack[stackIndex] = nextState(machine, left);
        const nextNode = machine.onLeft(nodeStack[stackIndex].left, userStateStack[stackIndex], nodeStack[stackIndex]);
        if (nextNode) {
            checkCircularity(stackIndex, nodeStack, nextNode);
            return pushStack(stackIndex, stateStack, nodeStack, userStateStack, nextNode);
        }
        return stackIndex;
    }
    BinaryExpressionState.left = left;
    /**
     * Handles walking the `operatorToken` of a `BinaryExpression`.
     * @param machine State machine handler functions
     * @param frame The current frame
     * @returns The new frame
     */
    function operator(machine, stackIndex, stateStack, nodeStack, userStateStack, _resultHolder, _outerState) {
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], operator);
        ts_js_1.Debug.assertIsDefined(machine.onOperator);
        stateStack[stackIndex] = nextState(machine, operator);
        machine.onOperator(nodeStack[stackIndex].operatorToken, userStateStack[stackIndex], nodeStack[stackIndex]);
        return stackIndex;
    }
    BinaryExpressionState.operator = operator;
    /**
     * Handles walking the `right` side of a `BinaryExpression`.
     * @param machine State machine handler functions
     * @param frame The current frame
     * @returns The new frame
     */
    function right(machine, stackIndex, stateStack, nodeStack, userStateStack, _resultHolder, _outerState) {
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], right);
        ts_js_1.Debug.assertIsDefined(machine.onRight);
        stateStack[stackIndex] = nextState(machine, right);
        const nextNode = machine.onRight(nodeStack[stackIndex].right, userStateStack[stackIndex], nodeStack[stackIndex]);
        if (nextNode) {
            checkCircularity(stackIndex, nodeStack, nextNode);
            return pushStack(stackIndex, stateStack, nodeStack, userStateStack, nextNode);
        }
        return stackIndex;
    }
    BinaryExpressionState.right = right;
    /**
     * Handles walking out of a `BinaryExpression`.
     * @param machine State machine handler functions
     * @param frame The current frame
     * @returns The new frame
     */
    function exit(machine, stackIndex, stateStack, nodeStack, userStateStack, resultHolder, _outerState) {
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], exit);
        stateStack[stackIndex] = nextState(machine, exit);
        const result = machine.onExit(nodeStack[stackIndex], userStateStack[stackIndex]);
        if (stackIndex > 0) {
            stackIndex--;
            if (machine.foldState) {
                const side = stateStack[stackIndex] === exit ? "right" : "left";
                userStateStack[stackIndex] = machine.foldState(userStateStack[stackIndex], result, side);
            }
        }
        else {
            resultHolder.value = result;
        }
        return stackIndex;
    }
    BinaryExpressionState.exit = exit;
    /**
     * Handles a frame that is already done.
     * @returns The `done` state.
     */
    function done(_machine, stackIndex, stateStack, _nodeStack, _userStateStack, _resultHolder, _outerState) {
        ts_js_1.Debug.assertEqual(stateStack[stackIndex], done);
        return stackIndex;
    }
    BinaryExpressionState.done = done;
    function nextState(machine, currentState) {
        switch (currentState) {
            case enter:
                if (machine.onLeft)
                    return left;
            // falls through
            case left:
                if (machine.onOperator)
                    return operator;
            // falls through
            case operator:
                if (machine.onRight)
                    return right;
            // falls through
            case right:
                return exit;
            case exit:
                return done;
            case done:
                return done;
            default:
                ts_js_1.Debug.fail("Invalid state");
        }
    }
    BinaryExpressionState.nextState = nextState;
    function pushStack(stackIndex, stateStack, nodeStack, userStateStack, node) {
        stackIndex++;
        stateStack[stackIndex] = enter;
        nodeStack[stackIndex] = node;
        userStateStack[stackIndex] = undefined;
        return stackIndex;
    }
    function checkCircularity(stackIndex, nodeStack, node) {
        if (ts_js_1.Debug.shouldAssert(2 /* AssertionLevel.Aggressive */)) {
            while (stackIndex >= 0) {
                ts_js_1.Debug.assert(nodeStack[stackIndex] !== node, "Circular traversal detected.");
                stackIndex--;
            }
        }
    }
})(BinaryExpressionState || (BinaryExpressionState = {}));
/**
 * Holds state machine handler functions
 */
class BinaryExpressionStateMachine {
    constructor(onEnter, onLeft, onOperator, onRight, onExit, foldState) {
        this.onEnter = onEnter;
        this.onLeft = onLeft;
        this.onOperator = onOperator;
        this.onRight = onRight;
        this.onExit = onExit;
        this.foldState = foldState;
    }
}
/** @internal */
function createBinaryExpressionTrampoline(onEnter, onLeft, onOperator, onRight, onExit, foldState) {
    const machine = new BinaryExpressionStateMachine(onEnter, onLeft, onOperator, onRight, onExit, foldState);
    return trampoline;
    function trampoline(node, outerState) {
        const resultHolder = { value: undefined };
        const stateStack = [BinaryExpressionState.enter];
        const nodeStack = [node];
        const userStateStack = [undefined];
        let stackIndex = 0;
        while (stateStack[stackIndex] !== BinaryExpressionState.done) {
            stackIndex = stateStack[stackIndex](machine, stackIndex, stateStack, nodeStack, userStateStack, resultHolder, outerState);
        }
        ts_js_1.Debug.assertEqual(stackIndex, 0);
        return resultHolder.value;
    }
}
function isExportOrDefaultKeywordKind(kind) {
    return kind === 95 /* SyntaxKind.ExportKeyword */ || kind === 90 /* SyntaxKind.DefaultKeyword */;
}
/** @internal */
function isExportOrDefaultModifier(node) {
    const kind = node.kind;
    return isExportOrDefaultKeywordKind(kind);
}
/** @internal */
function elideNodes(factory, nodes) {
    if (nodes === undefined)
        return undefined;
    if (nodes.length === 0)
        return nodes;
    return (0, ts_js_1.setTextRange)(factory.createNodeArray([], nodes.hasTrailingComma), nodes);
}
/**
 * Gets the node from which a name should be generated.
 *
 * @internal
 */
function getNodeForGeneratedName(name) {
    const autoGenerate = name.emitNode.autoGenerate;
    if (autoGenerate.flags & 4 /* GeneratedIdentifierFlags.Node */) {
        const autoGenerateId = autoGenerate.id;
        let node = name;
        let original = node.original;
        while (original) {
            node = original;
            const autoGenerate = node.emitNode?.autoGenerate;
            // if "node" is a different generated name (having a different "autoGenerateId"), use it and stop traversing.
            if ((0, ts_js_1.isMemberName)(node) && (autoGenerate === undefined ||
                !!(autoGenerate.flags & 4 /* GeneratedIdentifierFlags.Node */) &&
                    autoGenerate.id !== autoGenerateId)) {
                break;
            }
            original = node.original;
        }
        // otherwise, return the original node for the source
        return node;
    }
    return name;
}
/** @internal */
function formatGeneratedNamePart(part, generateName) {
    return typeof part === "object" ? formatGeneratedName(/*privateName*/ false, part.prefix, part.node, part.suffix, generateName) :
        typeof part === "string" ? part.length > 0 && part.charCodeAt(0) === 35 /* CharacterCodes.hash */ ? part.slice(1) : part :
            "";
}
function formatIdentifier(name, generateName) {
    return typeof name === "string" ? name :
        formatIdentifierWorker(name, ts_js_1.Debug.checkDefined(generateName));
}
function formatIdentifierWorker(node, generateName) {
    return (0, ts_js_1.isGeneratedPrivateIdentifier)(node) ? generateName(node).slice(1) :
        (0, ts_js_1.isGeneratedIdentifier)(node) ? generateName(node) :
            (0, ts_js_1.isPrivateIdentifier)(node) ? node.escapedText.slice(1) :
                (0, ts_js_1.idText)(node);
}
/** @internal */
function formatGeneratedName(privateName, prefix, baseName, suffix, generateName) {
    prefix = formatGeneratedNamePart(prefix, generateName);
    suffix = formatGeneratedNamePart(suffix, generateName);
    baseName = formatIdentifier(baseName, generateName);
    return `${privateName ? "#" : ""}${prefix}${baseName}${suffix}`;
}
/**
 * Creates a private backing field for an `accessor` {@link PropertyDeclaration}.
 *
 * @internal
 */
function createAccessorPropertyBackingField(factory, node, modifiers, initializer) {
    return factory.updatePropertyDeclaration(node, modifiers, factory.getGeneratedPrivateNameForNode(node.name, /*prefix*/ undefined, "_accessor_storage"), 
    /*questionOrExclamationToken*/ undefined, 
    /*type*/ undefined, initializer);
}
/**
 * Creates a {@link GetAccessorDeclaration} that reads from a private backing field.
 *
 * @internal
 */
function createAccessorPropertyGetRedirector(factory, node, modifiers, name, receiver = factory.createThis()) {
    return factory.createGetAccessorDeclaration(modifiers, name, [], 
    /*type*/ undefined, factory.createBlock([
        factory.createReturnStatement(factory.createPropertyAccessExpression(receiver, factory.getGeneratedPrivateNameForNode(node.name, /*prefix*/ undefined, "_accessor_storage"))),
    ]));
}
/**
 * Creates a {@link SetAccessorDeclaration} that writes to a private backing field.
 *
 * @internal
 */
function createAccessorPropertySetRedirector(factory, node, modifiers, name, receiver = factory.createThis()) {
    return factory.createSetAccessorDeclaration(modifiers, name, [factory.createParameterDeclaration(
        /*modifiers*/ undefined, 
        /*dotDotDotToken*/ undefined, "value")], factory.createBlock([
        factory.createExpressionStatement(factory.createAssignment(factory.createPropertyAccessExpression(receiver, factory.getGeneratedPrivateNameForNode(node.name, /*prefix*/ undefined, "_accessor_storage")), factory.createIdentifier("value"))),
    ]));
}
/** @internal */
function findComputedPropertyNameCacheAssignment(name) {
    let node = name.expression;
    while (true) {
        node = skipOuterExpressions(node);
        if ((0, ts_js_1.isCommaListExpression)(node)) {
            node = (0, ts_js_1.last)(node.elements);
            continue;
        }
        if (isCommaExpression(node)) {
            node = node.right;
            continue;
        }
        if ((0, ts_js_1.isAssignmentExpression)(node, /*excludeCompoundAssignment*/ true) && (0, ts_js_1.isGeneratedIdentifier)(node.left)) {
            return node;
        }
        break;
    }
}
function isSyntheticParenthesizedExpression(node) {
    return (0, ts_js_1.isParenthesizedExpression)(node)
        && (0, ts_js_1.nodeIsSynthesized)(node)
        && !node.emitNode;
}
function flattenCommaListWorker(node, expressions) {
    if (isSyntheticParenthesizedExpression(node)) {
        flattenCommaListWorker(node.expression, expressions);
    }
    else if (isCommaExpression(node)) {
        flattenCommaListWorker(node.left, expressions);
        flattenCommaListWorker(node.right, expressions);
    }
    else if ((0, ts_js_1.isCommaListExpression)(node)) {
        for (const child of node.elements) {
            flattenCommaListWorker(child, expressions);
        }
    }
    else {
        expressions.push(node);
    }
}
/**
 * Flatten a CommaExpression or CommaListExpression into an array of one or more expressions, unwrapping any nested
 * comma expressions and synthetic parens.
 *
 * @internal
 */
function flattenCommaList(node) {
    const expressions = [];
    flattenCommaListWorker(node, expressions);
    return expressions;
}
/**
 * Walk an AssignmentPattern to determine if it contains object rest (`...`) syntax. We cannot rely on
 * propagation of `TransformFlags.ContainsObjectRestOrSpread` since it isn't propagated by default in
 * ObjectLiteralExpression and ArrayLiteralExpression since we do not know whether they belong to an
 * AssignmentPattern at the time the nodes are parsed.
 *
 * @internal
 */
function containsObjectRestOrSpread(node) {
    if (node.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */)
        return true;
    if (node.transformFlags & 128 /* TransformFlags.ContainsES2018 */) {
        // check for nested spread assignments, otherwise '{ x: { a, ...b } = foo } = c'
        // will not be correctly interpreted by the ES2018 transformer
        for (const element of getElementsOfBindingOrAssignmentPattern(node)) {
            const target = getTargetOfBindingOrAssignmentElement(element);
            if (target && (0, ts_js_1.isAssignmentPattern)(target)) {
                if (target.transformFlags & 65536 /* TransformFlags.ContainsObjectRestOrSpread */) {
                    return true;
                }
                if (target.transformFlags & 128 /* TransformFlags.ContainsES2018 */) {
                    if (containsObjectRestOrSpread(target))
                        return true;
                }
            }
        }
    }
    return false;
}
