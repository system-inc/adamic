"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDeclarationDiagnostics = getDeclarationDiagnostics;
exports.transformDeclarations = transformDeclarations;
const ts_js_1 = require("../_namespaces/ts.js");
/** @internal */
function getDeclarationDiagnostics(host, resolver, file) {
    const compilerOptions = host.getCompilerOptions();
    const files = (0, ts_js_1.filter)((0, ts_js_1.getSourceFilesToEmit)(host, file), ts_js_1.isSourceFileNotJson);
    return (0, ts_js_1.contains)(files, file) ?
        (0, ts_js_1.transformNodes)(resolver, host, ts_js_1.factory, compilerOptions, [file], [transformDeclarations], 
        /*allowDtsFiles*/ false).diagnostics :
        undefined;
}
const declarationEmitNodeBuilderFlags = 1024 /* NodeBuilderFlags.MultilineObjectLiterals */ |
    2048 /* NodeBuilderFlags.WriteClassExpressionAsTypeLiteral */ |
    4096 /* NodeBuilderFlags.UseTypeOfFunction */ |
    8 /* NodeBuilderFlags.UseStructuralFallback */ |
    524288 /* NodeBuilderFlags.AllowEmptyTuple */ |
    4 /* NodeBuilderFlags.GenerateNamesForShadowedTypeParams */ |
    1 /* NodeBuilderFlags.NoTruncation */;
const declarationEmitInternalNodeBuilderFlags = 8 /* InternalNodeBuilderFlags.AllowUnresolvedNames */;
/**
 * Transforms a ts file into a .d.ts file
 * This process requires type information, which is retrieved through the emit resolver. Because of this,
 * in many places this transformer assumes it will be operating on parse tree nodes directly.
 * This means that _no transforms should be allowed to occur before this one_.
 *
 * @internal
 */
function transformDeclarations(context) {
    const throwDiagnostic = () => ts_js_1.Debug.fail("Diagnostic emitted without context");
    let getSymbolAccessibilityDiagnostic = throwDiagnostic;
    let needsDeclare = true;
    let isBundledEmit = false;
    let resultHasExternalModuleIndicator = false;
    let needsScopeFixMarker = false;
    let resultHasScopeMarker = false;
    let enclosingDeclaration;
    let lateMarkedStatements;
    let lateStatementReplacementMap;
    let suppressNewDiagnosticContexts;
    const { factory } = context;
    const host = context.getEmitHost();
    let restoreFallbackNode = () => void 0;
    const symbolTracker = {
        trackSymbol,
        reportInaccessibleThisError,
        reportInaccessibleUniqueSymbolError,
        reportCyclicStructureError,
        reportPrivateInBaseOfClassExpression,
        reportLikelyUnsafeImportRequiredError,
        reportTruncationError,
        moduleResolverHost: host,
        reportNonlocalAugmentation,
        reportNonSerializableProperty,
        reportInferenceFallback,
        pushErrorFallbackNode(node) {
            const currentFallback = errorFallbackNode;
            const currentRestore = restoreFallbackNode;
            restoreFallbackNode = () => {
                restoreFallbackNode = currentRestore;
                errorFallbackNode = currentFallback;
            };
            errorFallbackNode = node;
        },
        popErrorFallbackNode() {
            restoreFallbackNode();
        },
    };
    let errorNameNode;
    let errorFallbackNode;
    let currentSourceFile;
    let rawReferencedFiles;
    let rawTypeReferenceDirectives;
    let rawLibReferenceDirectives;
    const resolver = context.getEmitResolver();
    const options = context.getCompilerOptions();
    const getIsolatedDeclarationError = (0, ts_js_1.createGetIsolatedDeclarationErrors)(resolver);
    const { stripInternal, isolatedDeclarations } = options;
    return transformRoot;
    function reportExpandoFunctionErrors(node) {
        resolver.getPropertiesOfContainerFunction(node).forEach(p => {
            if ((0, ts_js_1.isExpandoPropertyDeclaration)(p.valueDeclaration)) {
                const errorTarget = (0, ts_js_1.isBinaryExpression)(p.valueDeclaration) ?
                    p.valueDeclaration.left :
                    p.valueDeclaration;
                context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(errorTarget, ts_js_1.Diagnostics.Assigning_properties_to_functions_without_declaring_them_is_not_supported_with_isolatedDeclarations_Add_an_explicit_declaration_for_the_properties_assigned_to_this_function));
            }
        });
    }
    function reportInferenceFallback(node) {
        if (!isolatedDeclarations || (0, ts_js_1.isSourceFileJS)(currentSourceFile))
            return;
        if ((0, ts_js_1.getSourceFileOfNode)(node) !== currentSourceFile)
            return; // Nested error on a declaration in another file - ignore, will be reemitted if file is in the output file set
        if ((0, ts_js_1.isVariableDeclaration)(node) && resolver.isExpandoFunctionDeclaration(node)) {
            reportExpandoFunctionErrors(node);
        }
        else {
            context.addDiagnostic(getIsolatedDeclarationError(node));
        }
    }
    function handleSymbolAccessibilityError(symbolAccessibilityResult) {
        if (symbolAccessibilityResult.accessibility === 0 /* SymbolAccessibility.Accessible */) {
            // Add aliases back onto the possible imports list if they're not there so we can try them again with updated visibility info
            if (symbolAccessibilityResult.aliasesToMakeVisible) {
                if (!lateMarkedStatements) {
                    lateMarkedStatements = symbolAccessibilityResult.aliasesToMakeVisible;
                }
                else {
                    for (const ref of symbolAccessibilityResult.aliasesToMakeVisible) {
                        (0, ts_js_1.pushIfUnique)(lateMarkedStatements, ref);
                    }
                }
            }
            // TODO: Do all these accessibility checks inside/after the first pass in the checker when declarations are enabled, if possible
        }
        // The checker should issue errors on unresolvable names, skip the declaration emit error for using a private/unreachable name for those
        else if (symbolAccessibilityResult.accessibility !== 3 /* SymbolAccessibility.NotResolved */) {
            // Report error
            const errorInfo = getSymbolAccessibilityDiagnostic(symbolAccessibilityResult);
            if (errorInfo) {
                if (errorInfo.typeName) {
                    context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(symbolAccessibilityResult.errorNode || errorInfo.errorNode, errorInfo.diagnosticMessage, (0, ts_js_1.getTextOfNode)(errorInfo.typeName), symbolAccessibilityResult.errorSymbolName, symbolAccessibilityResult.errorModuleName));
                }
                else {
                    context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(symbolAccessibilityResult.errorNode || errorInfo.errorNode, errorInfo.diagnosticMessage, symbolAccessibilityResult.errorSymbolName, symbolAccessibilityResult.errorModuleName));
                }
                return true;
            }
        }
        return false;
    }
    function trackSymbol(symbol, enclosingDeclaration, meaning) {
        if (symbol.flags & 262144 /* SymbolFlags.TypeParameter */)
            return false;
        const issuedDiagnostic = handleSymbolAccessibilityError(resolver.isSymbolAccessible(symbol, enclosingDeclaration, meaning, /*shouldComputeAliasToMarkVisible*/ true));
        return issuedDiagnostic;
    }
    function reportPrivateInBaseOfClassExpression(propertyName) {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.addRelatedInfo)((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.Property_0_of_exported_anonymous_class_type_may_not_be_private_or_protected, propertyName), ...((0, ts_js_1.isVariableDeclaration)((errorNameNode || errorFallbackNode).parent) ? [(0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.Add_a_type_annotation_to_the_variable_0, errorDeclarationNameWithFallback())] : [])));
        }
    }
    function errorDeclarationNameWithFallback() {
        return errorNameNode ? (0, ts_js_1.declarationNameToString)(errorNameNode) :
            errorFallbackNode && (0, ts_js_1.getNameOfDeclaration)(errorFallbackNode) ? (0, ts_js_1.declarationNameToString)((0, ts_js_1.getNameOfDeclaration)(errorFallbackNode)) :
                errorFallbackNode && (0, ts_js_1.isExportAssignment)(errorFallbackNode) ? errorFallbackNode.isExportEquals ? "export=" : "default" :
                    "(Missing)"; // same fallback declarationNameToString uses when node is zero-width (ie, nameless)
    }
    function reportInaccessibleUniqueSymbolError() {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_0_references_an_inaccessible_1_type_A_type_annotation_is_necessary, errorDeclarationNameWithFallback(), "unique symbol"));
        }
    }
    function reportCyclicStructureError() {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_0_references_a_type_with_a_cyclic_structure_which_cannot_be_trivially_serialized_A_type_annotation_is_necessary, errorDeclarationNameWithFallback()));
        }
    }
    function reportInaccessibleThisError() {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_0_references_an_inaccessible_1_type_A_type_annotation_is_necessary, errorDeclarationNameWithFallback(), "this"));
        }
    }
    function reportLikelyUnsafeImportRequiredError(specifier, symbolName) {
        if (errorNameNode || errorFallbackNode) {
            if (symbolName) {
                context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_0_cannot_be_named_without_a_reference_to_2_from_1_This_is_likely_not_portable_A_type_annotation_is_necessary, errorDeclarationNameWithFallback(), specifier, symbolName));
            }
            else {
                context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_0_cannot_be_named_without_a_reference_to_1_This_is_likely_not_portable_A_type_annotation_is_necessary, errorDeclarationNameWithFallback(), specifier));
            }
        }
    }
    function reportTruncationError() {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_inferred_type_of_this_node_exceeds_the_maximum_length_the_compiler_will_serialize_An_explicit_type_annotation_is_needed));
        }
    }
    function reportNonlocalAugmentation(containingFile, parentSymbol, symbol) {
        const primaryDeclaration = parentSymbol.declarations?.find(d => (0, ts_js_1.getSourceFileOfNode)(d) === containingFile);
        const augmentingDeclarations = (0, ts_js_1.filter)(symbol.declarations, d => (0, ts_js_1.getSourceFileOfNode)(d) !== containingFile);
        if (primaryDeclaration && augmentingDeclarations) {
            for (const augmentations of augmentingDeclarations) {
                context.addDiagnostic((0, ts_js_1.addRelatedInfo)((0, ts_js_1.createDiagnosticForNode)(augmentations, ts_js_1.Diagnostics.Declaration_augments_declaration_in_another_file_This_cannot_be_serialized), (0, ts_js_1.createDiagnosticForNode)(primaryDeclaration, ts_js_1.Diagnostics.This_is_the_declaration_being_augmented_Consider_moving_the_augmenting_declaration_into_the_same_file)));
            }
        }
    }
    function reportNonSerializableProperty(propertyName) {
        if (errorNameNode || errorFallbackNode) {
            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)((errorNameNode || errorFallbackNode), ts_js_1.Diagnostics.The_type_of_this_node_cannot_be_serialized_because_its_property_0_cannot_be_serialized, propertyName));
        }
    }
    function transformDeclarationsForJS(sourceFile) {
        const oldDiag = getSymbolAccessibilityDiagnostic;
        getSymbolAccessibilityDiagnostic = s => (s.errorNode && (0, ts_js_1.canProduceDiagnostics)(s.errorNode) ? (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(s.errorNode)(s) : ({
            diagnosticMessage: s.errorModuleName
                ? ts_js_1.Diagnostics.Declaration_emit_for_this_file_requires_using_private_name_0_from_module_1_An_explicit_type_annotation_may_unblock_declaration_emit
                : ts_js_1.Diagnostics.Declaration_emit_for_this_file_requires_using_private_name_0_An_explicit_type_annotation_may_unblock_declaration_emit,
            errorNode: s.errorNode || sourceFile,
        }));
        const result = resolver.getDeclarationStatementsForSourceFile(sourceFile, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags, symbolTracker);
        getSymbolAccessibilityDiagnostic = oldDiag;
        return result;
    }
    function transformRoot(node) {
        if (node.kind === 308 /* SyntaxKind.SourceFile */ && node.isDeclarationFile) {
            return node;
        }
        if (node.kind === 309 /* SyntaxKind.Bundle */) {
            isBundledEmit = true;
            rawReferencedFiles = [];
            rawTypeReferenceDirectives = [];
            rawLibReferenceDirectives = [];
            const bundle = factory.createBundle((0, ts_js_1.map)(node.sourceFiles, sourceFile => {
                if (sourceFile.isDeclarationFile)
                    return undefined; // Omit declaration files from bundle results, too // TODO: GH#18217
                currentSourceFile = sourceFile;
                enclosingDeclaration = sourceFile;
                lateMarkedStatements = undefined;
                suppressNewDiagnosticContexts = false;
                lateStatementReplacementMap = new Map();
                getSymbolAccessibilityDiagnostic = throwDiagnostic;
                needsScopeFixMarker = false;
                resultHasScopeMarker = false;
                collectFileReferences(sourceFile);
                if ((0, ts_js_1.isExternalOrCommonJsModule)(sourceFile) || (0, ts_js_1.isJsonSourceFile)(sourceFile)) {
                    resultHasExternalModuleIndicator = false; // unused in external module bundle emit (all external modules are within module blocks, therefore are known to be modules)
                    needsDeclare = false;
                    const statements = (0, ts_js_1.isSourceFileJS)(sourceFile) ? factory.createNodeArray(transformDeclarationsForJS(sourceFile)) : (0, ts_js_1.visitNodes)(sourceFile.statements, visitDeclarationStatements, ts_js_1.isStatement);
                    const newFile = factory.updateSourceFile(sourceFile, [factory.createModuleDeclaration([factory.createModifier(138 /* SyntaxKind.DeclareKeyword */)], factory.createStringLiteral((0, ts_js_1.getResolvedExternalModuleName)(context.getEmitHost(), sourceFile)), factory.createModuleBlock((0, ts_js_1.setTextRange)(factory.createNodeArray(transformAndReplaceLatePaintedStatements(statements)), sourceFile.statements)))], 
                    /*isDeclarationFile*/ true, 
                    /*referencedFiles*/ [], 
                    /*typeReferences*/ [], 
                    /*hasNoDefaultLib*/ false, 
                    /*libReferences*/ []);
                    return newFile;
                }
                needsDeclare = true;
                const updated = (0, ts_js_1.isSourceFileJS)(sourceFile) ? factory.createNodeArray(transformDeclarationsForJS(sourceFile)) : (0, ts_js_1.visitNodes)(sourceFile.statements, visitDeclarationStatements, ts_js_1.isStatement);
                return factory.updateSourceFile(sourceFile, transformAndReplaceLatePaintedStatements(updated), /*isDeclarationFile*/ true, /*referencedFiles*/ [], /*typeReferences*/ [], /*hasNoDefaultLib*/ false, /*libReferences*/ []);
            }));
            const outputFilePath = (0, ts_js_1.getDirectoryPath)((0, ts_js_1.normalizeSlashes)((0, ts_js_1.getOutputPathsFor)(node, host, /*forceDtsPaths*/ true).declarationFilePath));
            bundle.syntheticFileReferences = getReferencedFiles(outputFilePath);
            bundle.syntheticTypeReferences = getTypeReferences();
            bundle.syntheticLibReferences = getLibReferences();
            return bundle;
        }
        // Single source file
        needsDeclare = true;
        needsScopeFixMarker = false;
        resultHasScopeMarker = false;
        enclosingDeclaration = node;
        currentSourceFile = node;
        getSymbolAccessibilityDiagnostic = throwDiagnostic;
        isBundledEmit = false;
        resultHasExternalModuleIndicator = false;
        suppressNewDiagnosticContexts = false;
        lateMarkedStatements = undefined;
        lateStatementReplacementMap = new Map();
        rawReferencedFiles = [];
        rawTypeReferenceDirectives = [];
        rawLibReferenceDirectives = [];
        collectFileReferences(currentSourceFile);
        let combinedStatements;
        if ((0, ts_js_1.isSourceFileJS)(currentSourceFile)) {
            combinedStatements = factory.createNodeArray(transformDeclarationsForJS(node));
        }
        else {
            const statements = (0, ts_js_1.visitNodes)(node.statements, visitDeclarationStatements, ts_js_1.isStatement);
            combinedStatements = (0, ts_js_1.setTextRange)(factory.createNodeArray(transformAndReplaceLatePaintedStatements(statements)), node.statements);
            if ((0, ts_js_1.isExternalModule)(node) && (!resultHasExternalModuleIndicator || (needsScopeFixMarker && !resultHasScopeMarker))) {
                combinedStatements = (0, ts_js_1.setTextRange)(factory.createNodeArray([...combinedStatements, (0, ts_js_1.createEmptyExports)(factory)]), combinedStatements);
            }
        }
        const outputFilePath = (0, ts_js_1.getDirectoryPath)((0, ts_js_1.normalizeSlashes)((0, ts_js_1.getOutputPathsFor)(node, host, /*forceDtsPaths*/ true).declarationFilePath));
        return factory.updateSourceFile(node, combinedStatements, /*isDeclarationFile*/ true, getReferencedFiles(outputFilePath), getTypeReferences(), /*hasNoDefaultLib*/ false, getLibReferences());
        function collectFileReferences(sourceFile) {
            rawReferencedFiles = (0, ts_js_1.concatenate)(rawReferencedFiles, (0, ts_js_1.map)(sourceFile.referencedFiles, f => [sourceFile, f]));
            rawTypeReferenceDirectives = (0, ts_js_1.concatenate)(rawTypeReferenceDirectives, sourceFile.typeReferenceDirectives);
            rawLibReferenceDirectives = (0, ts_js_1.concatenate)(rawLibReferenceDirectives, sourceFile.libReferenceDirectives);
        }
        function copyFileReferenceAsSynthetic(ref) {
            const newRef = { ...ref };
            newRef.pos = -1;
            newRef.end = -1;
            return newRef;
        }
        function getTypeReferences() {
            return (0, ts_js_1.mapDefined)(rawTypeReferenceDirectives, ref => {
                if (!ref.preserve)
                    return undefined;
                return copyFileReferenceAsSynthetic(ref);
            });
        }
        function getLibReferences() {
            return (0, ts_js_1.mapDefined)(rawLibReferenceDirectives, ref => {
                if (!ref.preserve)
                    return undefined;
                return copyFileReferenceAsSynthetic(ref);
            });
        }
        function getReferencedFiles(outputFilePath) {
            return (0, ts_js_1.mapDefined)(rawReferencedFiles, ([sourceFile, ref]) => {
                if (!ref.preserve)
                    return undefined;
                const file = host.getSourceFileFromReference(sourceFile, ref);
                if (!file) {
                    return undefined;
                }
                let declFileName;
                if (file.isDeclarationFile) { // Neither decl files or js should have their refs changed
                    declFileName = file.fileName;
                }
                else {
                    if (isBundledEmit && (0, ts_js_1.contains)(node.sourceFiles, file))
                        return; // Omit references to files which are being merged
                    const paths = (0, ts_js_1.getOutputPathsFor)(file, host, /*forceDtsPaths*/ true);
                    declFileName = paths.declarationFilePath || paths.jsFilePath || file.fileName;
                }
                if (!declFileName)
                    return undefined;
                const fileName = (0, ts_js_1.getRelativePathToDirectoryOrUrl)(outputFilePath, declFileName, host.getCurrentDirectory(), host.getCanonicalFileName, 
                /*isAbsolutePathAnUrl*/ false);
                const newRef = copyFileReferenceAsSynthetic(ref);
                newRef.fileName = fileName;
                return newRef;
            });
        }
    }
    function filterBindingPatternInitializers(name) {
        if (name.kind === 80 /* SyntaxKind.Identifier */) {
            return name;
        }
        else {
            if (name.kind === 208 /* SyntaxKind.ArrayBindingPattern */) {
                return factory.updateArrayBindingPattern(name, (0, ts_js_1.visitNodes)(name.elements, visitBindingElement, ts_js_1.isArrayBindingElement));
            }
            else {
                return factory.updateObjectBindingPattern(name, (0, ts_js_1.visitNodes)(name.elements, visitBindingElement, ts_js_1.isBindingElement));
            }
        }
        function visitBindingElement(elem) {
            if (elem.kind === 233 /* SyntaxKind.OmittedExpression */) {
                return elem;
            }
            if (elem.propertyName && (0, ts_js_1.isComputedPropertyName)(elem.propertyName) && (0, ts_js_1.isEntityNameExpression)(elem.propertyName.expression)) {
                checkEntityNameVisibility(elem.propertyName.expression, enclosingDeclaration);
            }
            return factory.updateBindingElement(elem, elem.dotDotDotToken, elem.propertyName, filterBindingPatternInitializers(elem.name), 
            /*initializer*/ undefined);
        }
    }
    function ensureParameter(p, modifierMask) {
        let oldDiag;
        if (!suppressNewDiagnosticContexts) {
            oldDiag = getSymbolAccessibilityDiagnostic;
            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(p);
        }
        const newParam = factory.updateParameterDeclaration(p, maskModifiers(factory, p, modifierMask), p.dotDotDotToken, filterBindingPatternInitializers(p.name), resolver.isOptionalParameter(p) ? (p.questionToken || factory.createToken(58 /* SyntaxKind.QuestionToken */)) : undefined, ensureType(p, /*ignorePrivate*/ true), // Ignore private param props, since this type is going straight back into a param
        ensureNoInitializer(p));
        if (!suppressNewDiagnosticContexts) {
            getSymbolAccessibilityDiagnostic = oldDiag;
        }
        return newParam;
    }
    function shouldPrintWithInitializer(node) {
        return canHaveLiteralInitializer(node)
            && !!node.initializer
            && resolver.isLiteralConstDeclaration((0, ts_js_1.getParseTreeNode)(node)); // TODO: Make safea
    }
    function ensureNoInitializer(node) {
        if (shouldPrintWithInitializer(node)) {
            const unwrappedInitializer = (0, ts_js_1.unwrapParenthesizedExpression)(node.initializer);
            if (!(0, ts_js_1.isPrimitiveLiteralValue)(unwrappedInitializer)) {
                reportInferenceFallback(node);
            }
            return resolver.createLiteralConstValue((0, ts_js_1.getParseTreeNode)(node, canHaveLiteralInitializer), symbolTracker);
        }
        return undefined;
    }
    function ensureType(node, ignorePrivate) {
        if (!ignorePrivate && (0, ts_js_1.hasEffectiveModifier)(node, 2 /* ModifierFlags.Private */)) {
            // Private nodes emit no types (except private parameter properties, whose parameter types are actually visible)
            return;
        }
        if (shouldPrintWithInitializer(node)) {
            // Literal const declarations will have an initializer ensured rather than a type
            return;
        }
        // Should be removed createTypeOfDeclaration will actually now reuse the existing annotation so there is no real need to duplicate type walking
        // Left in for now to minimize diff during syntactic type node builder refactor
        if (!(0, ts_js_1.isExportAssignment)(node)
            && !(0, ts_js_1.isBindingElement)(node)
            && node.type
            && (!(0, ts_js_1.isParameter)(node) || !resolver.requiresAddingImplicitUndefined(node, enclosingDeclaration))) {
            return (0, ts_js_1.visitNode)(node.type, visitDeclarationSubtree, ts_js_1.isTypeNode);
        }
        const oldErrorNameNode = errorNameNode;
        errorNameNode = node.name;
        let oldDiag;
        if (!suppressNewDiagnosticContexts) {
            oldDiag = getSymbolAccessibilityDiagnostic;
            if ((0, ts_js_1.canProduceDiagnostics)(node)) {
                getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(node);
            }
        }
        let typeNode;
        if ((0, ts_js_1.hasInferredType)(node)) {
            typeNode = resolver.createTypeOfDeclaration(node, enclosingDeclaration, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags, symbolTracker);
        }
        else if ((0, ts_js_1.isFunctionLike)(node)) {
            typeNode = resolver.createReturnTypeOfSignatureDeclaration(node, enclosingDeclaration, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags, symbolTracker);
        }
        else {
            ts_js_1.Debug.assertNever(node);
        }
        errorNameNode = oldErrorNameNode;
        if (!suppressNewDiagnosticContexts) {
            getSymbolAccessibilityDiagnostic = oldDiag;
        }
        return typeNode ?? factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */);
    }
    function isDeclarationAndNotVisible(node) {
        node = (0, ts_js_1.getParseTreeNode)(node);
        switch (node.kind) {
            case 263 /* SyntaxKind.FunctionDeclaration */:
            case 268 /* SyntaxKind.ModuleDeclaration */:
            case 265 /* SyntaxKind.InterfaceDeclaration */:
            case 264 /* SyntaxKind.ClassDeclaration */:
            case 266 /* SyntaxKind.TypeAliasDeclaration */:
            case 267 /* SyntaxKind.EnumDeclaration */:
                return !resolver.isDeclarationVisible(node);
            // The following should be doing their own visibility checks based on filtering their members
            case 261 /* SyntaxKind.VariableDeclaration */:
                return !getBindingNameVisible(node);
            case 272 /* SyntaxKind.ImportEqualsDeclaration */:
            case 273 /* SyntaxKind.ImportDeclaration */:
            case 279 /* SyntaxKind.ExportDeclaration */:
            case 278 /* SyntaxKind.ExportAssignment */:
                return false;
            case 176 /* SyntaxKind.ClassStaticBlockDeclaration */:
                return true;
        }
        return false;
    }
    // If the ExpandoFunctionDeclaration have multiple overloads, then we only need to emit properties for the last one.
    function shouldEmitFunctionProperties(input) {
        if (input.body) {
            return true;
        }
        const overloadSignatures = input.symbol.declarations?.filter(decl => (0, ts_js_1.isFunctionDeclaration)(decl) && !decl.body);
        return !overloadSignatures || overloadSignatures.indexOf(input) === overloadSignatures.length - 1;
    }
    function getBindingNameVisible(elem) {
        if ((0, ts_js_1.isOmittedExpression)(elem)) {
            return false;
        }
        if ((0, ts_js_1.isBindingPattern)(elem.name)) {
            // If any child binding pattern element has been marked visible (usually by collect linked aliases), then this is visible
            return (0, ts_js_1.some)(elem.name.elements, getBindingNameVisible);
        }
        else {
            return resolver.isDeclarationVisible(elem);
        }
    }
    function updateParamsList(node, params, modifierMask) {
        if ((0, ts_js_1.hasEffectiveModifier)(node, 2 /* ModifierFlags.Private */)) {
            return factory.createNodeArray();
        }
        const newParams = (0, ts_js_1.map)(params, p => ensureParameter(p, modifierMask));
        if (!newParams) {
            return factory.createNodeArray();
        }
        return factory.createNodeArray(newParams, params.hasTrailingComma);
    }
    function updateAccessorParamsList(input, isPrivate) {
        let newParams;
        if (!isPrivate) {
            const thisParameter = (0, ts_js_1.getThisParameter)(input);
            if (thisParameter) {
                newParams = [ensureParameter(thisParameter)];
            }
        }
        if ((0, ts_js_1.isSetAccessorDeclaration)(input)) {
            let newValueParameter;
            if (!isPrivate) {
                const valueParameter = (0, ts_js_1.getSetAccessorValueParameter)(input);
                if (valueParameter) {
                    newValueParameter = ensureParameter(valueParameter);
                }
            }
            if (!newValueParameter) {
                newValueParameter = factory.createParameterDeclaration(
                /*modifiers*/ undefined, 
                /*dotDotDotToken*/ undefined, "value");
            }
            newParams = (0, ts_js_1.append)(newParams, newValueParameter);
        }
        return factory.createNodeArray(newParams || ts_js_1.emptyArray);
    }
    function ensureTypeParams(node, params) {
        return (0, ts_js_1.hasEffectiveModifier)(node, 2 /* ModifierFlags.Private */) ? undefined : (0, ts_js_1.visitNodes)(params, visitDeclarationSubtree, ts_js_1.isTypeParameterDeclaration);
    }
    function isEnclosingDeclaration(node) {
        return (0, ts_js_1.isSourceFile)(node)
            || (0, ts_js_1.isTypeAliasDeclaration)(node)
            || (0, ts_js_1.isModuleDeclaration)(node)
            || (0, ts_js_1.isClassDeclaration)(node)
            || (0, ts_js_1.isInterfaceDeclaration)(node)
            || (0, ts_js_1.isFunctionLike)(node)
            || (0, ts_js_1.isIndexSignatureDeclaration)(node)
            || (0, ts_js_1.isMappedTypeNode)(node);
    }
    function checkEntityNameVisibility(entityName, enclosingDeclaration) {
        const visibilityResult = resolver.isEntityNameVisible(entityName, enclosingDeclaration);
        handleSymbolAccessibilityError(visibilityResult);
    }
    function preserveJsDoc(updated, original) {
        if ((0, ts_js_1.hasJSDocNodes)(updated) && (0, ts_js_1.hasJSDocNodes)(original)) {
            updated.jsDoc = original.jsDoc;
        }
        return (0, ts_js_1.setCommentRange)(updated, (0, ts_js_1.getCommentRange)(original));
    }
    function rewriteModuleSpecifier(parent, input) {
        if (!input)
            return undefined; // TODO: GH#18217
        resultHasExternalModuleIndicator = resultHasExternalModuleIndicator || (parent.kind !== 268 /* SyntaxKind.ModuleDeclaration */ && parent.kind !== 206 /* SyntaxKind.ImportType */);
        if ((0, ts_js_1.isStringLiteralLike)(input)) {
            if (isBundledEmit) {
                const newName = (0, ts_js_1.getExternalModuleNameFromDeclaration)(context.getEmitHost(), resolver, parent);
                if (newName) {
                    return factory.createStringLiteral(newName);
                }
            }
        }
        return input;
    }
    function transformImportEqualsDeclaration(decl) {
        if (!resolver.isDeclarationVisible(decl))
            return;
        if (decl.moduleReference.kind === 284 /* SyntaxKind.ExternalModuleReference */) {
            // Rewrite external module names if necessary
            const specifier = (0, ts_js_1.getExternalModuleImportEqualsDeclarationExpression)(decl);
            return factory.updateImportEqualsDeclaration(decl, decl.modifiers, decl.isTypeOnly, decl.name, factory.updateExternalModuleReference(decl.moduleReference, rewriteModuleSpecifier(decl, specifier)));
        }
        else {
            const oldDiag = getSymbolAccessibilityDiagnostic;
            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(decl);
            checkEntityNameVisibility(decl.moduleReference, enclosingDeclaration);
            getSymbolAccessibilityDiagnostic = oldDiag;
            return decl;
        }
    }
    function transformImportDeclaration(decl) {
        if (!decl.importClause) {
            // import "mod" - possibly needed for side effects? (global interface patches, module augmentations, etc)
            return factory.updateImportDeclaration(decl, decl.modifiers, decl.importClause, rewriteModuleSpecifier(decl, decl.moduleSpecifier), tryGetResolutionModeOverride(decl.attributes));
        }
        const phaseModifier = decl.importClause.phaseModifier === 166 /* SyntaxKind.DeferKeyword */ ? undefined : decl.importClause.phaseModifier;
        // The `importClause` visibility corresponds to the default's visibility.
        const visibleDefaultBinding = decl.importClause && decl.importClause.name && resolver.isDeclarationVisible(decl.importClause) ? decl.importClause.name : undefined;
        if (!decl.importClause.namedBindings) {
            // No named bindings (either namespace or list), meaning the import is just default or should be elided
            return visibleDefaultBinding && factory.updateImportDeclaration(decl, decl.modifiers, factory.updateImportClause(decl.importClause, phaseModifier, visibleDefaultBinding, 
            /*namedBindings*/ undefined), rewriteModuleSpecifier(decl, decl.moduleSpecifier), tryGetResolutionModeOverride(decl.attributes));
        }
        if (decl.importClause.namedBindings.kind === 275 /* SyntaxKind.NamespaceImport */) {
            // Namespace import (optionally with visible default)
            const namedBindings = resolver.isDeclarationVisible(decl.importClause.namedBindings) ? decl.importClause.namedBindings : /*namedBindings*/ undefined;
            return visibleDefaultBinding || namedBindings ? factory.updateImportDeclaration(decl, decl.modifiers, factory.updateImportClause(decl.importClause, phaseModifier, visibleDefaultBinding, namedBindings), rewriteModuleSpecifier(decl, decl.moduleSpecifier), tryGetResolutionModeOverride(decl.attributes)) : undefined;
        }
        // Named imports (optionally with visible default)
        const bindingList = (0, ts_js_1.mapDefined)(decl.importClause.namedBindings.elements, b => resolver.isDeclarationVisible(b) ? b : undefined);
        if ((bindingList && bindingList.length) || visibleDefaultBinding) {
            return factory.updateImportDeclaration(decl, decl.modifiers, factory.updateImportClause(decl.importClause, phaseModifier, visibleDefaultBinding, bindingList && bindingList.length ? factory.updateNamedImports(decl.importClause.namedBindings, bindingList) : undefined), rewriteModuleSpecifier(decl, decl.moduleSpecifier), tryGetResolutionModeOverride(decl.attributes));
        }
        // Augmentation of export depends on import
        if (resolver.isImportRequiredByAugmentation(decl)) {
            if (isolatedDeclarations) {
                context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(decl, ts_js_1.Diagnostics.Declaration_emit_for_this_file_requires_preserving_this_import_for_augmentations_This_is_not_supported_with_isolatedDeclarations));
            }
            return factory.updateImportDeclaration(decl, decl.modifiers, 
            /*importClause*/ undefined, rewriteModuleSpecifier(decl, decl.moduleSpecifier), tryGetResolutionModeOverride(decl.attributes));
        }
        // Nothing visible
    }
    function tryGetResolutionModeOverride(node) {
        const mode = (0, ts_js_1.getResolutionModeOverride)(node);
        return node && mode !== undefined ? node : undefined;
    }
    function transformAndReplaceLatePaintedStatements(statements) {
        // This is a `while` loop because `handleSymbolAccessibilityError` can see additional import aliases marked as visible during
        // error handling which must now be included in the output and themselves checked for errors.
        // For example:
        // ```
        // module A {
        //   export module Q {}
        //   import B = Q;
        //   import C = B;
        //   export import D = C;
        // }
        // ```
        // In such a scenario, only Q and D are initially visible, but we don't consider imports as private names - instead we say they if they are referenced they must
        // be recorded. So while checking D's visibility we mark C as visible, then we must check C which in turn marks B, completing the chain of
        // dependent imports and allowing a valid declaration file output. Today, this dependent alias marking only happens for internal import aliases.
        while ((0, ts_js_1.length)(lateMarkedStatements)) {
            const i = lateMarkedStatements.shift();
            if (!(0, ts_js_1.isLateVisibilityPaintedStatement)(i)) {
                return ts_js_1.Debug.fail(`Late replaced statement was found which is not handled by the declaration transformer!: ${ts_js_1.Debug.formatSyntaxKind(i.kind)}`);
            }
            const priorNeedsDeclare = needsDeclare;
            needsDeclare = i.parent && (0, ts_js_1.isSourceFile)(i.parent) && !((0, ts_js_1.isExternalModule)(i.parent) && isBundledEmit);
            const result = transformTopLevelDeclaration(i);
            needsDeclare = priorNeedsDeclare;
            lateStatementReplacementMap.set((0, ts_js_1.getOriginalNodeId)(i), result);
        }
        // And lastly, we need to get the final form of all those indetermine import declarations from before and add them to the output list
        // (and remove them from the set to examine for outter declarations)
        return (0, ts_js_1.visitNodes)(statements, visitLateVisibilityMarkedStatements, ts_js_1.isStatement);
        function visitLateVisibilityMarkedStatements(statement) {
            if ((0, ts_js_1.isLateVisibilityPaintedStatement)(statement)) {
                const key = (0, ts_js_1.getOriginalNodeId)(statement);
                if (lateStatementReplacementMap.has(key)) {
                    const result = lateStatementReplacementMap.get(key);
                    lateStatementReplacementMap.delete(key);
                    if (result) {
                        if ((0, ts_js_1.isArray)(result) ? (0, ts_js_1.some)(result, ts_js_1.needsScopeMarker) : (0, ts_js_1.needsScopeMarker)(result)) {
                            // Top-level declarations in .d.ts files are always considered exported even without a modifier unless there's an export assignment or specifier
                            needsScopeFixMarker = true;
                        }
                        if ((0, ts_js_1.isSourceFile)(statement.parent) && ((0, ts_js_1.isArray)(result) ? (0, ts_js_1.some)(result, ts_js_1.isExternalModuleIndicator) : (0, ts_js_1.isExternalModuleIndicator)(result))) {
                            resultHasExternalModuleIndicator = true;
                        }
                    }
                    return result;
                }
            }
            return statement;
        }
    }
    function visitDeclarationSubtree(input) {
        if (shouldStripInternal(input))
            return;
        if ((0, ts_js_1.isDeclaration)(input)) {
            if (isDeclarationAndNotVisible(input))
                return;
            if ((0, ts_js_1.hasDynamicName)(input)) {
                if (isolatedDeclarations) {
                    // Classes and object literals usually elide properties with computed names that are not of a literal type
                    // In isolated declarations TSC needs to error on these as we don't know the type in a DTE.
                    if (!resolver.isDefinitelyReferenceToGlobalSymbolObject(input.name.expression)) {
                        if ((0, ts_js_1.isClassDeclaration)(input.parent) || (0, ts_js_1.isObjectLiteralExpression)(input.parent)) {
                            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(input, ts_js_1.Diagnostics.Computed_property_names_on_class_or_object_literals_cannot_be_inferred_with_isolatedDeclarations));
                            return;
                        }
                        else if (
                        // Type declarations just need to double-check that the input computed name is an entity name expression
                        ((0, ts_js_1.isInterfaceDeclaration)(input.parent) || (0, ts_js_1.isTypeLiteralNode)(input.parent))
                            && !(0, ts_js_1.isEntityNameExpression)(input.name.expression)) {
                            context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(input, ts_js_1.Diagnostics.Computed_properties_must_be_number_or_string_literals_variables_or_dotted_expressions_with_isolatedDeclarations));
                            return;
                        }
                    }
                }
                else if (!resolver.isLateBound((0, ts_js_1.getParseTreeNode)(input)) || !(0, ts_js_1.isEntityNameExpression)(input.name.expression)) {
                    return;
                }
            }
        }
        // Elide implementation signatures from overload sets
        if ((0, ts_js_1.isFunctionLike)(input) && resolver.isImplementationOfOverload(input))
            return;
        // Elide semicolon class statements
        if ((0, ts_js_1.isSemicolonClassElement)(input))
            return;
        let previousEnclosingDeclaration;
        if (isEnclosingDeclaration(input)) {
            previousEnclosingDeclaration = enclosingDeclaration;
            enclosingDeclaration = input;
        }
        const oldDiag = getSymbolAccessibilityDiagnostic;
        // Setup diagnostic-related flags before first potential `cleanup` call, otherwise
        // We'd see a TDZ violation at runtime
        const canProduceDiagnostic = (0, ts_js_1.canProduceDiagnostics)(input);
        const oldWithinObjectLiteralType = suppressNewDiagnosticContexts;
        let shouldEnterSuppressNewDiagnosticsContextContext = (input.kind === 188 /* SyntaxKind.TypeLiteral */ || input.kind === 201 /* SyntaxKind.MappedType */) && input.parent.kind !== 266 /* SyntaxKind.TypeAliasDeclaration */;
        // Emit methods which are private as properties with no type information
        if ((0, ts_js_1.isMethodDeclaration)(input) || (0, ts_js_1.isMethodSignature)(input)) {
            if ((0, ts_js_1.hasEffectiveModifier)(input, 2 /* ModifierFlags.Private */)) {
                if (input.symbol && input.symbol.declarations && input.symbol.declarations[0] !== input)
                    return; // Elide all but the first overload
                return cleanup(factory.createPropertyDeclaration(ensureModifiers(input), input.name, /*questionOrExclamationToken*/ undefined, /*type*/ undefined, /*initializer*/ undefined));
            }
        }
        if (canProduceDiagnostic && !suppressNewDiagnosticContexts) {
            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(input);
        }
        if ((0, ts_js_1.isTypeQueryNode)(input)) {
            checkEntityNameVisibility(input.exprName, enclosingDeclaration);
        }
        if (shouldEnterSuppressNewDiagnosticsContextContext) {
            // We stop making new diagnostic contexts within object literal types. Unless it's an object type on the RHS of a type alias declaration. Then we do.
            suppressNewDiagnosticContexts = true;
        }
        if (isProcessedComponent(input)) {
            switch (input.kind) {
                case 234 /* SyntaxKind.ExpressionWithTypeArguments */: {
                    if (((0, ts_js_1.isEntityName)(input.expression) || (0, ts_js_1.isEntityNameExpression)(input.expression))) {
                        checkEntityNameVisibility(input.expression, enclosingDeclaration);
                    }
                    const node = (0, ts_js_1.visitEachChild)(input, visitDeclarationSubtree, context);
                    return cleanup(factory.updateExpressionWithTypeArguments(node, node.expression, node.typeArguments));
                }
                case 184 /* SyntaxKind.TypeReference */: {
                    checkEntityNameVisibility(input.typeName, enclosingDeclaration);
                    const node = (0, ts_js_1.visitEachChild)(input, visitDeclarationSubtree, context);
                    return cleanup(factory.updateTypeReferenceNode(node, node.typeName, node.typeArguments));
                }
                case 181 /* SyntaxKind.ConstructSignature */:
                    return cleanup(factory.updateConstructSignature(input, ensureTypeParams(input, input.typeParameters), updateParamsList(input, input.parameters), ensureType(input)));
                case 177 /* SyntaxKind.Constructor */: {
                    // A constructor declaration may not have a type annotation
                    const ctor = factory.createConstructorDeclaration(
                    /*modifiers*/ ensureModifiers(input), updateParamsList(input, input.parameters, 0 /* ModifierFlags.None */), 
                    /*body*/ undefined);
                    return cleanup(ctor);
                }
                case 175 /* SyntaxKind.MethodDeclaration */: {
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    const sig = factory.createMethodDeclaration(ensureModifiers(input), 
                    /*asteriskToken*/ undefined, input.name, input.questionToken, ensureTypeParams(input, input.typeParameters), updateParamsList(input, input.parameters), ensureType(input), 
                    /*body*/ undefined);
                    return cleanup(sig);
                }
                case 178 /* SyntaxKind.GetAccessor */: {
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    return cleanup(factory.updateGetAccessorDeclaration(input, ensureModifiers(input), input.name, updateAccessorParamsList(input, (0, ts_js_1.hasEffectiveModifier)(input, 2 /* ModifierFlags.Private */)), ensureType(input), 
                    /*body*/ undefined));
                }
                case 179 /* SyntaxKind.SetAccessor */: {
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    return cleanup(factory.updateSetAccessorDeclaration(input, ensureModifiers(input), input.name, updateAccessorParamsList(input, (0, ts_js_1.hasEffectiveModifier)(input, 2 /* ModifierFlags.Private */)), 
                    /*body*/ undefined));
                }
                case 173 /* SyntaxKind.PropertyDeclaration */:
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    return cleanup(factory.updatePropertyDeclaration(input, ensureModifiers(input), input.name, input.questionToken, ensureType(input), ensureNoInitializer(input)));
                case 172 /* SyntaxKind.PropertySignature */:
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    return cleanup(factory.updatePropertySignature(input, ensureModifiers(input), input.name, input.questionToken, ensureType(input)));
                case 174 /* SyntaxKind.MethodSignature */: {
                    if ((0, ts_js_1.isPrivateIdentifier)(input.name)) {
                        return cleanup(/*returnValue*/ undefined);
                    }
                    return cleanup(factory.updateMethodSignature(input, ensureModifiers(input), input.name, input.questionToken, ensureTypeParams(input, input.typeParameters), updateParamsList(input, input.parameters), ensureType(input)));
                }
                case 180 /* SyntaxKind.CallSignature */: {
                    return cleanup(factory.updateCallSignature(input, ensureTypeParams(input, input.typeParameters), updateParamsList(input, input.parameters), ensureType(input)));
                }
                case 182 /* SyntaxKind.IndexSignature */: {
                    return cleanup(factory.updateIndexSignature(input, ensureModifiers(input), updateParamsList(input, input.parameters), (0, ts_js_1.visitNode)(input.type, visitDeclarationSubtree, ts_js_1.isTypeNode) || factory.createKeywordTypeNode(133 /* SyntaxKind.AnyKeyword */)));
                }
                case 261 /* SyntaxKind.VariableDeclaration */: {
                    if ((0, ts_js_1.isBindingPattern)(input.name)) {
                        return recreateBindingPattern(input.name);
                    }
                    shouldEnterSuppressNewDiagnosticsContextContext = true;
                    suppressNewDiagnosticContexts = true; // Variable declaration types also suppress new diagnostic contexts, provided the contexts wouldn't be made for binding pattern types
                    return cleanup(factory.updateVariableDeclaration(input, input.name, /*exclamationToken*/ undefined, ensureType(input), ensureNoInitializer(input)));
                }
                case 169 /* SyntaxKind.TypeParameter */: {
                    if (isPrivateMethodTypeParameter(input) && (input.default || input.constraint)) {
                        return cleanup(factory.updateTypeParameterDeclaration(input, input.modifiers, input.name, /*constraint*/ undefined, /*defaultType*/ undefined));
                    }
                    return cleanup((0, ts_js_1.visitEachChild)(input, visitDeclarationSubtree, context));
                }
                case 195 /* SyntaxKind.ConditionalType */: {
                    // We have to process conditional types in a special way because for visibility purposes we need to push a new enclosingDeclaration
                    // just for the `infer` types in the true branch. It's an implicit declaration scope that only applies to _part_ of the type.
                    const checkType = (0, ts_js_1.visitNode)(input.checkType, visitDeclarationSubtree, ts_js_1.isTypeNode);
                    const extendsType = (0, ts_js_1.visitNode)(input.extendsType, visitDeclarationSubtree, ts_js_1.isTypeNode);
                    const oldEnclosingDecl = enclosingDeclaration;
                    enclosingDeclaration = input.trueType;
                    const trueType = (0, ts_js_1.visitNode)(input.trueType, visitDeclarationSubtree, ts_js_1.isTypeNode);
                    enclosingDeclaration = oldEnclosingDecl;
                    const falseType = (0, ts_js_1.visitNode)(input.falseType, visitDeclarationSubtree, ts_js_1.isTypeNode);
                    ts_js_1.Debug.assert(checkType);
                    ts_js_1.Debug.assert(extendsType);
                    ts_js_1.Debug.assert(trueType);
                    ts_js_1.Debug.assert(falseType);
                    return cleanup(factory.updateConditionalTypeNode(input, checkType, extendsType, trueType, falseType));
                }
                case 185 /* SyntaxKind.FunctionType */: {
                    return cleanup(factory.updateFunctionTypeNode(input, (0, ts_js_1.visitNodes)(input.typeParameters, visitDeclarationSubtree, ts_js_1.isTypeParameterDeclaration), updateParamsList(input, input.parameters), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(input.type, visitDeclarationSubtree, ts_js_1.isTypeNode))));
                }
                case 186 /* SyntaxKind.ConstructorType */: {
                    return cleanup(factory.updateConstructorTypeNode(input, ensureModifiers(input), (0, ts_js_1.visitNodes)(input.typeParameters, visitDeclarationSubtree, ts_js_1.isTypeParameterDeclaration), updateParamsList(input, input.parameters), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(input.type, visitDeclarationSubtree, ts_js_1.isTypeNode))));
                }
                case 206 /* SyntaxKind.ImportType */: {
                    if (!(0, ts_js_1.isLiteralImportTypeNode)(input))
                        return cleanup(input);
                    return cleanup(factory.updateImportTypeNode(input, factory.updateLiteralTypeNode(input.argument, rewriteModuleSpecifier(input, input.argument.literal)), input.attributes, input.qualifier, (0, ts_js_1.visitNodes)(input.typeArguments, visitDeclarationSubtree, ts_js_1.isTypeNode), input.isTypeOf));
                }
                default:
                    ts_js_1.Debug.assertNever(input, `Attempted to process unhandled node kind: ${ts_js_1.Debug.formatSyntaxKind(input.kind)}`);
            }
        }
        if ((0, ts_js_1.isTupleTypeNode)(input) && ((0, ts_js_1.getLineAndCharacterOfPosition)(currentSourceFile, input.pos).line === (0, ts_js_1.getLineAndCharacterOfPosition)(currentSourceFile, input.end).line)) {
            (0, ts_js_1.setEmitFlags)(input, 1 /* EmitFlags.SingleLine */);
        }
        return cleanup((0, ts_js_1.visitEachChild)(input, visitDeclarationSubtree, context));
        function cleanup(returnValue) {
            if (returnValue && canProduceDiagnostic && (0, ts_js_1.hasDynamicName)(input)) {
                checkName(input);
            }
            if (isEnclosingDeclaration(input)) {
                enclosingDeclaration = previousEnclosingDeclaration;
            }
            if (canProduceDiagnostic && !suppressNewDiagnosticContexts) {
                getSymbolAccessibilityDiagnostic = oldDiag;
            }
            if (shouldEnterSuppressNewDiagnosticsContextContext) {
                suppressNewDiagnosticContexts = oldWithinObjectLiteralType;
            }
            if (returnValue === input) {
                return returnValue;
            }
            return returnValue && (0, ts_js_1.setOriginalNode)(preserveJsDoc(returnValue, input), input);
        }
    }
    function isPrivateMethodTypeParameter(node) {
        return node.parent.kind === 175 /* SyntaxKind.MethodDeclaration */ && (0, ts_js_1.hasEffectiveModifier)(node.parent, 2 /* ModifierFlags.Private */);
    }
    function visitDeclarationStatements(input) {
        if (!isPreservedDeclarationStatement(input)) {
            // return undefined for unmatched kinds to omit them from the tree
            return;
        }
        if (shouldStripInternal(input))
            return;
        switch (input.kind) {
            case 279 /* SyntaxKind.ExportDeclaration */: {
                if ((0, ts_js_1.isSourceFile)(input.parent)) {
                    resultHasExternalModuleIndicator = true;
                }
                resultHasScopeMarker = true;
                // Rewrite external module names if necessary
                return factory.updateExportDeclaration(input, input.modifiers, input.isTypeOnly, input.exportClause, rewriteModuleSpecifier(input, input.moduleSpecifier), tryGetResolutionModeOverride(input.attributes));
            }
            case 278 /* SyntaxKind.ExportAssignment */: {
                // Always visible if the parent node isn't dropped for being not visible
                if ((0, ts_js_1.isSourceFile)(input.parent)) {
                    resultHasExternalModuleIndicator = true;
                }
                resultHasScopeMarker = true;
                if (input.expression.kind === 80 /* SyntaxKind.Identifier */) {
                    return input;
                }
                else {
                    const newId = factory.createUniqueName("_default", 16 /* GeneratedIdentifierFlags.Optimistic */);
                    getSymbolAccessibilityDiagnostic = () => ({
                        diagnosticMessage: ts_js_1.Diagnostics.Default_export_of_the_module_has_or_is_using_private_name_0,
                        errorNode: input,
                    });
                    errorFallbackNode = input;
                    const type = ensureType(input);
                    const varDecl = factory.createVariableDeclaration(newId, /*exclamationToken*/ undefined, type, /*initializer*/ undefined);
                    errorFallbackNode = undefined;
                    const statement = factory.createVariableStatement(needsDeclare ? [factory.createModifier(138 /* SyntaxKind.DeclareKeyword */)] : [], factory.createVariableDeclarationList([varDecl], 2 /* NodeFlags.Const */));
                    preserveJsDoc(statement, input);
                    (0, ts_js_1.removeAllComments)(input);
                    return [statement, factory.updateExportAssignment(input, input.modifiers, newId)];
                }
            }
        }
        const result = transformTopLevelDeclaration(input);
        // Don't actually transform yet; just leave as original node - will be elided/swapped by late pass
        lateStatementReplacementMap.set((0, ts_js_1.getOriginalNodeId)(input), result);
        return input;
    }
    function stripExportModifiers(statement) {
        if ((0, ts_js_1.isImportEqualsDeclaration)(statement) || (0, ts_js_1.hasEffectiveModifier)(statement, 2048 /* ModifierFlags.Default */) || !(0, ts_js_1.canHaveModifiers)(statement)) {
            // `export import` statements should remain as-is, as imports are _not_ implicitly exported in an ambient namespace
            // Likewise, `export default` classes and the like and just be `default`, so we preserve their `export` modifiers, too
            return statement;
        }
        const modifiers = factory.createModifiersFromModifierFlags((0, ts_js_1.getEffectiveModifierFlags)(statement) & (131071 /* ModifierFlags.All */ ^ 32 /* ModifierFlags.Export */));
        return factory.replaceModifiers(statement, modifiers);
    }
    function updateModuleDeclarationAndKeyword(node, modifiers, name, body) {
        const updated = factory.updateModuleDeclaration(node, modifiers, name, body);
        if ((0, ts_js_1.isAmbientModule)(updated) || updated.flags & 32 /* NodeFlags.Namespace */) {
            return updated;
        }
        const fixed = factory.createModuleDeclaration(updated.modifiers, updated.name, updated.body, updated.flags | 32 /* NodeFlags.Namespace */);
        (0, ts_js_1.setOriginalNode)(fixed, updated);
        (0, ts_js_1.setTextRange)(fixed, updated);
        return fixed;
    }
    function transformTopLevelDeclaration(input) {
        if (lateMarkedStatements) {
            while ((0, ts_js_1.orderedRemoveItem)(lateMarkedStatements, input))
                ;
        }
        if (shouldStripInternal(input))
            return;
        switch (input.kind) {
            case 272 /* SyntaxKind.ImportEqualsDeclaration */: {
                return transformImportEqualsDeclaration(input);
            }
            case 273 /* SyntaxKind.ImportDeclaration */: {
                return transformImportDeclaration(input);
            }
        }
        if ((0, ts_js_1.isDeclaration)(input) && isDeclarationAndNotVisible(input))
            return;
        if ((0, ts_js_1.isJSDocImportTag)(input))
            return;
        // Elide implementation signatures from overload sets
        if ((0, ts_js_1.isFunctionLike)(input) && resolver.isImplementationOfOverload(input))
            return;
        let previousEnclosingDeclaration;
        if (isEnclosingDeclaration(input)) {
            previousEnclosingDeclaration = enclosingDeclaration;
            enclosingDeclaration = input;
        }
        const canProdiceDiagnostic = (0, ts_js_1.canProduceDiagnostics)(input);
        const oldDiag = getSymbolAccessibilityDiagnostic;
        if (canProdiceDiagnostic) {
            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(input);
        }
        const previousNeedsDeclare = needsDeclare;
        switch (input.kind) {
            case 266 /* SyntaxKind.TypeAliasDeclaration */: {
                needsDeclare = false;
                const clean = cleanup(factory.updateTypeAliasDeclaration(input, ensureModifiers(input), input.name, (0, ts_js_1.visitNodes)(input.typeParameters, visitDeclarationSubtree, ts_js_1.isTypeParameterDeclaration), ts_js_1.Debug.checkDefined((0, ts_js_1.visitNode)(input.type, visitDeclarationSubtree, ts_js_1.isTypeNode))));
                needsDeclare = previousNeedsDeclare;
                return clean;
            }
            case 265 /* SyntaxKind.InterfaceDeclaration */: {
                return cleanup(factory.updateInterfaceDeclaration(input, ensureModifiers(input), input.name, ensureTypeParams(input, input.typeParameters), transformHeritageClauses(input.heritageClauses), (0, ts_js_1.visitNodes)(input.members, visitDeclarationSubtree, ts_js_1.isTypeElement)));
            }
            case 263 /* SyntaxKind.FunctionDeclaration */: {
                // Generators lose their generator-ness, excepting their return type
                const clean = cleanup(factory.updateFunctionDeclaration(input, ensureModifiers(input), 
                /*asteriskToken*/ undefined, input.name, ensureTypeParams(input, input.typeParameters), updateParamsList(input, input.parameters), ensureType(input), 
                /*body*/ undefined));
                if (clean && resolver.isExpandoFunctionDeclaration(input) && shouldEmitFunctionProperties(input)) {
                    const props = resolver.getPropertiesOfContainerFunction(input);
                    if (isolatedDeclarations) {
                        reportExpandoFunctionErrors(input);
                    }
                    // Use parseNodeFactory so it is usable as an enclosing declaration
                    const fakespace = ts_js_1.parseNodeFactory.createModuleDeclaration(/*modifiers*/ undefined, clean.name || factory.createIdentifier("_default"), factory.createModuleBlock([]), 32 /* NodeFlags.Namespace */);
                    (0, ts_js_1.setParent)(fakespace, enclosingDeclaration);
                    fakespace.locals = (0, ts_js_1.createSymbolTable)(props);
                    fakespace.symbol = props[0].parent;
                    const exportMappings = [];
                    let declarations = (0, ts_js_1.mapDefined)(props, p => {
                        if (!(0, ts_js_1.isExpandoPropertyDeclaration)(p.valueDeclaration)) {
                            return undefined;
                        }
                        const nameStr = (0, ts_js_1.unescapeLeadingUnderscores)(p.escapedName);
                        if (!(0, ts_js_1.isIdentifierText)(nameStr, 99 /* ScriptTarget.ESNext */)) {
                            return undefined; // unique symbol or non-identifier name - omit, since there's no syntax that can preserve it
                        }
                        getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(p.valueDeclaration);
                        const type = resolver.createTypeOfDeclaration(p.valueDeclaration, fakespace, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags | 2 /* InternalNodeBuilderFlags.NoSyntacticPrinter */, symbolTracker);
                        getSymbolAccessibilityDiagnostic = oldDiag;
                        const isNonContextualKeywordName = (0, ts_js_1.isStringANonContextualKeyword)(nameStr);
                        const name = isNonContextualKeywordName ? factory.getGeneratedNameForNode(p.valueDeclaration) : factory.createIdentifier(nameStr);
                        if (isNonContextualKeywordName) {
                            exportMappings.push([name, nameStr]);
                        }
                        const varDecl = factory.createVariableDeclaration(name, /*exclamationToken*/ undefined, type, /*initializer*/ undefined);
                        return factory.createVariableStatement(isNonContextualKeywordName ? undefined : [factory.createToken(95 /* SyntaxKind.ExportKeyword */)], factory.createVariableDeclarationList([varDecl]));
                    });
                    if (!exportMappings.length) {
                        declarations = (0, ts_js_1.mapDefined)(declarations, declaration => factory.replaceModifiers(declaration, 0 /* ModifierFlags.None */));
                    }
                    else {
                        declarations.push(factory.createExportDeclaration(
                        /*modifiers*/ undefined, 
                        /*isTypeOnly*/ false, factory.createNamedExports((0, ts_js_1.map)(exportMappings, ([gen, exp]) => {
                            return factory.createExportSpecifier(/*isTypeOnly*/ false, gen, exp);
                        }))));
                    }
                    const namespaceDecl = factory.createModuleDeclaration(ensureModifiers(input), input.name, factory.createModuleBlock(declarations), 32 /* NodeFlags.Namespace */);
                    if (!(0, ts_js_1.hasEffectiveModifier)(clean, 2048 /* ModifierFlags.Default */)) {
                        return [clean, namespaceDecl];
                    }
                    const modifiers = factory.createModifiersFromModifierFlags(((0, ts_js_1.getEffectiveModifierFlags)(clean) & ~2080 /* ModifierFlags.ExportDefault */) | 128 /* ModifierFlags.Ambient */);
                    const cleanDeclaration = factory.updateFunctionDeclaration(clean, modifiers, 
                    /*asteriskToken*/ undefined, clean.name, clean.typeParameters, clean.parameters, clean.type, 
                    /*body*/ undefined);
                    const namespaceDeclaration = factory.updateModuleDeclaration(namespaceDecl, modifiers, namespaceDecl.name, namespaceDecl.body);
                    const exportDefaultDeclaration = factory.createExportAssignment(
                    /*modifiers*/ undefined, 
                    /*isExportEquals*/ false, namespaceDecl.name);
                    if ((0, ts_js_1.isSourceFile)(input.parent)) {
                        resultHasExternalModuleIndicator = true;
                    }
                    resultHasScopeMarker = true;
                    return [cleanDeclaration, namespaceDeclaration, exportDefaultDeclaration];
                }
                else {
                    return clean;
                }
            }
            case 268 /* SyntaxKind.ModuleDeclaration */: {
                needsDeclare = false;
                const inner = input.body;
                if (inner && inner.kind === 269 /* SyntaxKind.ModuleBlock */) {
                    const oldNeedsScopeFix = needsScopeFixMarker;
                    const oldHasScopeFix = resultHasScopeMarker;
                    resultHasScopeMarker = false;
                    needsScopeFixMarker = false;
                    const statements = (0, ts_js_1.visitNodes)(inner.statements, visitDeclarationStatements, ts_js_1.isStatement);
                    let lateStatements = transformAndReplaceLatePaintedStatements(statements);
                    if (input.flags & 33554432 /* NodeFlags.Ambient */) {
                        needsScopeFixMarker = false; // If it was `declare`'d everything is implicitly exported already, ignore late printed "privates"
                    }
                    // With the final list of statements, there are 3 possibilities:
                    // 1. There's an export assignment or export declaration in the namespace - do nothing
                    // 2. Everything is exported and there are no export assignments or export declarations - strip all export modifiers
                    // 3. Some things are exported, some are not, and there's no marker - add an empty marker
                    if (!(0, ts_js_1.isGlobalScopeAugmentation)(input) && !hasScopeMarker(lateStatements) && !resultHasScopeMarker) {
                        if (needsScopeFixMarker) {
                            lateStatements = factory.createNodeArray([...lateStatements, (0, ts_js_1.createEmptyExports)(factory)]);
                        }
                        else {
                            lateStatements = (0, ts_js_1.visitNodes)(lateStatements, stripExportModifiers, ts_js_1.isStatement);
                        }
                    }
                    const body = factory.updateModuleBlock(inner, lateStatements);
                    needsDeclare = previousNeedsDeclare;
                    needsScopeFixMarker = oldNeedsScopeFix;
                    resultHasScopeMarker = oldHasScopeFix;
                    const mods = ensureModifiers(input);
                    return cleanup(updateModuleDeclarationAndKeyword(input, mods, (0, ts_js_1.isExternalModuleAugmentation)(input) ? rewriteModuleSpecifier(input, input.name) : input.name, body));
                }
                else {
                    needsDeclare = previousNeedsDeclare;
                    const mods = ensureModifiers(input);
                    needsDeclare = false;
                    (0, ts_js_1.visitNode)(inner, visitDeclarationStatements);
                    // eagerly transform nested namespaces (the nesting doesn't need any elision or painting done)
                    const id = (0, ts_js_1.getOriginalNodeId)(inner); // TODO: GH#18217
                    const body = lateStatementReplacementMap.get(id);
                    lateStatementReplacementMap.delete(id);
                    return cleanup(updateModuleDeclarationAndKeyword(input, mods, input.name, body));
                }
            }
            case 264 /* SyntaxKind.ClassDeclaration */: {
                errorNameNode = input.name;
                errorFallbackNode = input;
                const modifiers = factory.createNodeArray(ensureModifiers(input));
                const typeParameters = ensureTypeParams(input, input.typeParameters);
                const ctor = (0, ts_js_1.getFirstConstructorWithBody)(input);
                let parameterProperties;
                if (ctor) {
                    const oldDiag = getSymbolAccessibilityDiagnostic;
                    parameterProperties = (0, ts_js_1.compact)((0, ts_js_1.flatMap)(ctor.parameters, param => {
                        if (!(0, ts_js_1.hasSyntacticModifier)(param, 31 /* ModifierFlags.ParameterPropertyModifier */) || shouldStripInternal(param))
                            return;
                        getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(param);
                        if (param.name.kind === 80 /* SyntaxKind.Identifier */) {
                            return preserveJsDoc(factory.createPropertyDeclaration(ensureModifiers(param), param.name, param.questionToken, ensureType(param), ensureNoInitializer(param)), param);
                        }
                        else {
                            // Pattern - this is currently an error, but we emit declarations for it somewhat correctly
                            return walkBindingPattern(param.name);
                        }
                        function walkBindingPattern(pattern) {
                            let elems;
                            for (const elem of pattern.elements) {
                                if ((0, ts_js_1.isOmittedExpression)(elem))
                                    continue;
                                if ((0, ts_js_1.isBindingPattern)(elem.name)) {
                                    elems = (0, ts_js_1.concatenate)(elems, walkBindingPattern(elem.name));
                                    continue;
                                }
                                elems = elems || [];
                                elems.push(factory.createPropertyDeclaration(ensureModifiers(param), elem.name, 
                                /*questionOrExclamationToken*/ undefined, ensureType(elem), 
                                /*initializer*/ undefined));
                            }
                            return elems;
                        }
                    }));
                    getSymbolAccessibilityDiagnostic = oldDiag;
                }
                const hasPrivateIdentifier = (0, ts_js_1.some)(input.members, member => !!member.name && (0, ts_js_1.isPrivateIdentifier)(member.name));
                // When the class has at least one private identifier, create a unique constant identifier to retain the nominal typing behavior
                // Prevents other classes with the same public members from being used in place of the current class
                const privateIdentifier = hasPrivateIdentifier ? [
                    factory.createPropertyDeclaration(
                    /*modifiers*/ undefined, factory.createPrivateIdentifier("#private"), 
                    /*questionOrExclamationToken*/ undefined, 
                    /*type*/ undefined, 
                    /*initializer*/ undefined),
                ] : undefined;
                const lateIndexes = resolver.createLateBoundIndexSignatures(input, enclosingDeclaration, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags, symbolTracker);
                const memberNodes = (0, ts_js_1.concatenate)((0, ts_js_1.concatenate)((0, ts_js_1.concatenate)(privateIdentifier, lateIndexes), parameterProperties), (0, ts_js_1.visitNodes)(input.members, visitDeclarationSubtree, ts_js_1.isClassElement));
                const members = factory.createNodeArray(memberNodes);
                const extendsClause = (0, ts_js_1.getEffectiveBaseTypeNode)(input);
                if (extendsClause && !(0, ts_js_1.isEntityNameExpression)(extendsClause.expression) && extendsClause.expression.kind !== 106 /* SyntaxKind.NullKeyword */) {
                    // We must add a temporary declaration for the extends clause expression
                    const oldId = input.name ? (0, ts_js_1.unescapeLeadingUnderscores)(input.name.escapedText) : "default";
                    const newId = factory.createUniqueName(`${oldId}_base`, 16 /* GeneratedIdentifierFlags.Optimistic */);
                    getSymbolAccessibilityDiagnostic = () => ({
                        diagnosticMessage: ts_js_1.Diagnostics.extends_clause_of_exported_class_0_has_or_is_using_private_name_1,
                        errorNode: extendsClause,
                        typeName: input.name,
                    });
                    const varDecl = factory.createVariableDeclaration(newId, /*exclamationToken*/ undefined, resolver.createTypeOfExpression(extendsClause.expression, input, declarationEmitNodeBuilderFlags, declarationEmitInternalNodeBuilderFlags, symbolTracker), /*initializer*/ undefined);
                    const statement = factory.createVariableStatement(needsDeclare ? [factory.createModifier(138 /* SyntaxKind.DeclareKeyword */)] : [], factory.createVariableDeclarationList([varDecl], 2 /* NodeFlags.Const */));
                    const heritageClauses = factory.createNodeArray((0, ts_js_1.mapDefined)(input.heritageClauses, clause => {
                        if (clause.token === 96 /* SyntaxKind.ExtendsKeyword */) {
                            const firstType = clause.types[0];
                            if (!firstType)
                                return undefined;
                            const oldDiag = getSymbolAccessibilityDiagnostic;
                            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNode)(firstType);
                            const newClause = factory.updateHeritageClause(clause, (0, ts_js_1.map)(clause.types, t => factory.updateExpressionWithTypeArguments(t, newId, (0, ts_js_1.visitNodes)(t.typeArguments, visitDeclarationSubtree, ts_js_1.isTypeNode))));
                            getSymbolAccessibilityDiagnostic = oldDiag;
                            return newClause;
                        }
                        return factory.updateHeritageClause(clause, (0, ts_js_1.visitNodes)(factory.createNodeArray((0, ts_js_1.filter)(clause.types, t => (0, ts_js_1.isEntityNameExpression)(t.expression) || t.expression.kind === 106 /* SyntaxKind.NullKeyword */)), visitDeclarationSubtree, ts_js_1.isExpressionWithTypeArguments));
                    }));
                    return [
                        statement,
                        cleanup(factory.updateClassDeclaration(input, modifiers, input.name, typeParameters, heritageClauses, members)),
                    ]; // TODO: GH#18217
                }
                else {
                    const heritageClauses = transformHeritageClauses(input.heritageClauses);
                    return cleanup(factory.updateClassDeclaration(input, modifiers, input.name, typeParameters, heritageClauses, members));
                }
            }
            case 244 /* SyntaxKind.VariableStatement */: {
                return cleanup(transformVariableStatement(input));
            }
            case 267 /* SyntaxKind.EnumDeclaration */: {
                return cleanup(factory.updateEnumDeclaration(input, factory.createNodeArray(ensureModifiers(input)), input.name, factory.createNodeArray((0, ts_js_1.mapDefined)(input.members, m => {
                    if (shouldStripInternal(m))
                        return;
                    // Rewrite enum values to their constants, if available
                    const enumValue = resolver.getEnumMemberValue(m);
                    const constValue = enumValue?.value;
                    if (isolatedDeclarations && m.initializer && enumValue?.hasExternalReferences &&
                        // This will be its own compiler error instead, so don't report.
                        !(0, ts_js_1.isComputedPropertyName)(m.name)) {
                        context.addDiagnostic((0, ts_js_1.createDiagnosticForNode)(m, ts_js_1.Diagnostics.Enum_member_initializers_must_be_computable_without_references_to_external_symbols_with_isolatedDeclarations));
                    }
                    const newInitializer = constValue === undefined ? undefined
                        : typeof constValue === "string" ? factory.createStringLiteral(constValue)
                            : constValue < 0 ? factory.createPrefixUnaryExpression(41 /* SyntaxKind.MinusToken */, factory.createNumericLiteral(-constValue))
                                : factory.createNumericLiteral(constValue);
                    return preserveJsDoc(factory.updateEnumMember(m, m.name, newInitializer), m);
                }))));
            }
        }
        // Anything left unhandled is an error, so this should be unreachable
        return ts_js_1.Debug.assertNever(input, `Unhandled top-level node in declaration emit: ${ts_js_1.Debug.formatSyntaxKind(input.kind)}`);
        function cleanup(node) {
            if (isEnclosingDeclaration(input)) {
                enclosingDeclaration = previousEnclosingDeclaration;
            }
            if (canProdiceDiagnostic) {
                getSymbolAccessibilityDiagnostic = oldDiag;
            }
            if (input.kind === 268 /* SyntaxKind.ModuleDeclaration */) {
                needsDeclare = previousNeedsDeclare;
            }
            if (node === input) {
                return node;
            }
            errorFallbackNode = undefined;
            errorNameNode = undefined;
            return node && (0, ts_js_1.setOriginalNode)(preserveJsDoc(node, input), input);
        }
    }
    function transformVariableStatement(input) {
        if (!(0, ts_js_1.forEach)(input.declarationList.declarations, getBindingNameVisible))
            return;
        const nodes = (0, ts_js_1.visitNodes)(input.declarationList.declarations, visitDeclarationSubtree, ts_js_1.isVariableDeclaration);
        if (!(0, ts_js_1.length)(nodes))
            return;
        const modifiers = factory.createNodeArray(ensureModifiers(input));
        let declList;
        if ((0, ts_js_1.isVarUsing)(input.declarationList) || (0, ts_js_1.isVarAwaitUsing)(input.declarationList)) {
            declList = factory.createVariableDeclarationList(nodes, 2 /* NodeFlags.Const */);
            (0, ts_js_1.setOriginalNode)(declList, input.declarationList);
            (0, ts_js_1.setTextRange)(declList, input.declarationList);
            (0, ts_js_1.setCommentRange)(declList, input.declarationList);
        }
        else {
            declList = factory.updateVariableDeclarationList(input.declarationList, nodes);
        }
        return factory.updateVariableStatement(input, modifiers, declList);
    }
    function recreateBindingPattern(d) {
        return (0, ts_js_1.flatten)((0, ts_js_1.mapDefined)(d.elements, e => recreateBindingElement(e)));
    }
    function recreateBindingElement(e) {
        if (e.kind === 233 /* SyntaxKind.OmittedExpression */) {
            return;
        }
        if (e.name) {
            if (!getBindingNameVisible(e))
                return;
            if ((0, ts_js_1.isBindingPattern)(e.name)) {
                return recreateBindingPattern(e.name);
            }
            else {
                return factory.createVariableDeclaration(e.name, /*exclamationToken*/ undefined, ensureType(e), /*initializer*/ undefined);
            }
        }
    }
    function checkName(node) {
        let oldDiag;
        if (!suppressNewDiagnosticContexts) {
            oldDiag = getSymbolAccessibilityDiagnostic;
            getSymbolAccessibilityDiagnostic = (0, ts_js_1.createGetSymbolAccessibilityDiagnosticForNodeName)(node);
        }
        errorNameNode = node.name;
        ts_js_1.Debug.assert((0, ts_js_1.hasDynamicName)(node)); // Should only be called with dynamic names
        const decl = node;
        const entityName = decl.name.expression;
        checkEntityNameVisibility(entityName, enclosingDeclaration);
        if (!suppressNewDiagnosticContexts) {
            getSymbolAccessibilityDiagnostic = oldDiag;
        }
        errorNameNode = undefined;
    }
    function shouldStripInternal(node) {
        return !!stripInternal && !!node && (0, ts_js_1.isInternalDeclaration)(node, currentSourceFile);
    }
    function isScopeMarker(node) {
        return (0, ts_js_1.isExportAssignment)(node) || (0, ts_js_1.isExportDeclaration)(node);
    }
    function hasScopeMarker(statements) {
        return (0, ts_js_1.some)(statements, isScopeMarker);
    }
    function ensureModifiers(node) {
        const currentFlags = (0, ts_js_1.getEffectiveModifierFlags)(node);
        const newFlags = ensureModifierFlags(node);
        if (currentFlags === newFlags) {
            return (0, ts_js_1.visitArray)(node.modifiers, n => (0, ts_js_1.tryCast)(n, ts_js_1.isModifier), ts_js_1.isModifier);
        }
        return factory.createModifiersFromModifierFlags(newFlags);
    }
    function ensureModifierFlags(node) {
        let mask = 131071 /* ModifierFlags.All */ ^ (1 /* ModifierFlags.Public */ | 1024 /* ModifierFlags.Async */ | 16 /* ModifierFlags.Override */); // No async and override modifiers in declaration files
        let additions = (needsDeclare && !isAlwaysType(node)) ? 128 /* ModifierFlags.Ambient */ : 0 /* ModifierFlags.None */;
        const parentIsFile = node.parent.kind === 308 /* SyntaxKind.SourceFile */;
        if (!parentIsFile || (isBundledEmit && parentIsFile && (0, ts_js_1.isExternalModule)(node.parent))) {
            mask ^= 128 /* ModifierFlags.Ambient */;
            additions = 0 /* ModifierFlags.None */;
        }
        return maskModifierFlags(node, mask, additions);
    }
    function transformHeritageClauses(nodes) {
        return factory.createNodeArray((0, ts_js_1.filter)((0, ts_js_1.map)(nodes, clause => factory.updateHeritageClause(clause, (0, ts_js_1.visitNodes)(factory.createNodeArray((0, ts_js_1.filter)(clause.types, t => {
            return (0, ts_js_1.isEntityNameExpression)(t.expression) || (clause.token === 96 /* SyntaxKind.ExtendsKeyword */ && t.expression.kind === 106 /* SyntaxKind.NullKeyword */);
        })), visitDeclarationSubtree, ts_js_1.isExpressionWithTypeArguments))), clause => clause.types && !!clause.types.length));
    }
}
function isAlwaysType(node) {
    if (node.kind === 265 /* SyntaxKind.InterfaceDeclaration */) {
        return true;
    }
    return false;
}
// Elide "public" modifier, as it is the default
function maskModifiers(factory, node, modifierMask, modifierAdditions) {
    return factory.createModifiersFromModifierFlags(maskModifierFlags(node, modifierMask, modifierAdditions));
}
function maskModifierFlags(node, modifierMask = 131071 /* ModifierFlags.All */ ^ 1 /* ModifierFlags.Public */, modifierAdditions = 0 /* ModifierFlags.None */) {
    let flags = ((0, ts_js_1.getEffectiveModifierFlags)(node) & modifierMask) | modifierAdditions;
    if (flags & 2048 /* ModifierFlags.Default */ && !(flags & 32 /* ModifierFlags.Export */)) {
        // A non-exported default is a nonsequitor - we usually try to remove all export modifiers
        // from statements in ambient declarations; but a default export must retain its export modifier to be syntactically valid
        flags ^= 32 /* ModifierFlags.Export */;
    }
    if (flags & 2048 /* ModifierFlags.Default */ && flags & 128 /* ModifierFlags.Ambient */) {
        flags ^= 128 /* ModifierFlags.Ambient */; // `declare` is never required alongside `default` (and would be an error if printed)
    }
    return flags;
}
function canHaveLiteralInitializer(node) {
    switch (node.kind) {
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
            return !(0, ts_js_1.hasEffectiveModifier)(node, 2 /* ModifierFlags.Private */);
        case 170 /* SyntaxKind.Parameter */:
        case 261 /* SyntaxKind.VariableDeclaration */:
            return true;
    }
    return false;
}
function isPreservedDeclarationStatement(node) {
    switch (node.kind) {
        case 263 /* SyntaxKind.FunctionDeclaration */:
        case 268 /* SyntaxKind.ModuleDeclaration */:
        case 272 /* SyntaxKind.ImportEqualsDeclaration */:
        case 265 /* SyntaxKind.InterfaceDeclaration */:
        case 264 /* SyntaxKind.ClassDeclaration */:
        case 266 /* SyntaxKind.TypeAliasDeclaration */:
        case 267 /* SyntaxKind.EnumDeclaration */:
        case 244 /* SyntaxKind.VariableStatement */:
        case 273 /* SyntaxKind.ImportDeclaration */:
        case 279 /* SyntaxKind.ExportDeclaration */:
        case 278 /* SyntaxKind.ExportAssignment */:
            return true;
    }
    return false;
}
function isProcessedComponent(node) {
    switch (node.kind) {
        case 181 /* SyntaxKind.ConstructSignature */:
        case 177 /* SyntaxKind.Constructor */:
        case 175 /* SyntaxKind.MethodDeclaration */:
        case 178 /* SyntaxKind.GetAccessor */:
        case 179 /* SyntaxKind.SetAccessor */:
        case 173 /* SyntaxKind.PropertyDeclaration */:
        case 172 /* SyntaxKind.PropertySignature */:
        case 174 /* SyntaxKind.MethodSignature */:
        case 180 /* SyntaxKind.CallSignature */:
        case 182 /* SyntaxKind.IndexSignature */:
        case 261 /* SyntaxKind.VariableDeclaration */:
        case 169 /* SyntaxKind.TypeParameter */:
        case 234 /* SyntaxKind.ExpressionWithTypeArguments */:
        case 184 /* SyntaxKind.TypeReference */:
        case 195 /* SyntaxKind.ConditionalType */:
        case 185 /* SyntaxKind.FunctionType */:
        case 186 /* SyntaxKind.ConstructorType */:
        case 206 /* SyntaxKind.ImportType */:
            return true;
    }
    return false;
}
