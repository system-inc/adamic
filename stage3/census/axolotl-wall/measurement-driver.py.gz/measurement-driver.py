import pathlib, subprocess, json, time, os
run=pathlib.Path('/workspace/scratch/wall-run')
tree=pathlib.Path('/workspace/scratch/wall-adapted')
roots=sorted(str(p) for p in (tree/'src/compiler').rglob('*') if p.is_file() and p.suffix in ('.ts','.a'))
assert len(roots)==79, len(roots)
(run/'roots.json').write_text(json.dumps(roots,indent=2)+'\n')
commands=[]
def measure(label,args,env=None,timeout=None):
    start=time.time()
    with (run/(label+'.stdout')).open('w') as out, (run/(label+'.stderr')).open('w') as err:
        p=subprocess.run(args,stdout=out,stderr=err,env=env)
    row=dict(label=label,args=args,returncode=p.returncode,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start)
    commands.append(row)
    (run/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    return p.returncode
assert measure('types',['/workspace/scratch/wall-adamic','types',*roots]) in (0,1)
assert measure('census',['/workspace/scratch/wall-census',str(tree/'src/compiler'),str(run/'census.jsonl')])==0
assert measure('meter-report',['python3','stage3/meter/report.py',str(tree),str(run),time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())])==0
env=dict(os.environ,LATENT_FULL='0',LATENT_ASSERT_NO_OUTPUT='1',LATENT_TIMES=str(run/'latent-times.jsonl'),LATENT_PROGRESS_FILE=str(run/'latent-progress.json'))
# GNU timeout bounds the entire census process group to 90 minutes.
measure('latent',['timeout','--kill-after=60s','5400','/workspace/scratch/wall-latent-census',str(tree/'src/compiler'),str(run/'latent.jsonl')],env)
subprocess.run(['python3','stage3/meter/box.py',str(run/'box.json'),'end'],check=True)
