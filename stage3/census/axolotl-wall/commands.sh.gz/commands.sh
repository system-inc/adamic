#!/usr/bin/env bash
# Material command record, not a one-command rerun script. Logs remain under scratch.
cd /workspace/adamic
export GOPROXY='https://proxy.golang.org|direct'
timeout --kill-after=60s 1800 bash cloud/setup.sh > /workspace/scratch/setup.log 2>&1
# Read stage3/meter/twice-daily.sh in full before preparing the measurement.
git fetch origin > /workspace/scratch/wall-fetch.log 2>&1
git fetch origin refs/heads/typescript/axolotl-wave-7:refs/remotes/origin/typescript/axolotl-wave-7 refs/heads/typescript/axolotl-99a:refs/remotes/origin/typescript/axolotl-99a refs/heads/typescript/axolotl-classify:refs/remotes/origin/typescript/axolotl-classify > /workspace/scratch/wall-fetch-waves.log 2>&1
git worktree add --detach /workspace/scratch/axolotl-composed 24b1bab92a0214c344a293fefff2cdfc62eaeae4 > /workspace/scratch/wall-worktree.log 2>&1
cd /workspace/scratch/axolotl-composed
git merge origin/main > /workspace/scratch/wall-merge.log 2>&1
# Merge conflicts were confined to these generated outputs, unused by the measurement.
git checkout --ours stage3/lane/shard-plan.json stage3/lane/shards.json stage3/lane/shards_generated_test.go > /workspace/scratch/wall-conflict-resolution.log 2>&1
git add stage3/lane/shard-plan.json stage3/lane/shards.json stage3/lane/shards_generated_test.go
git -c core.hooksPath=/dev/null commit -m 'Compose wave 7 with main for scratch wall measurement' > /workspace/scratch/wall-merge-commit.log 2>&1
git clone --depth 1 --branch v6.0.3 https://github.com/microsoft/TypeScript.git /workspace/scratch/wall-upstream > /workspace/scratch/wall-upstream.log 2>&1
source /workspace/adamic-tools/env.sh
(cd stage3/api && npm ci --ignore-scripts --no-audit --no-fund > /workspace/scratch/wall-packages.log 2>&1)
ADAMIC_TYPESCRIPT_SOURCE=/workspace/scratch/wall-upstream bash stage3/apply.sh /workspace/scratch/wall-adapted > /workspace/scratch/wall-apply.log 2>&1
git -c protocol.file.allow=always -c url.file:///workspace/adamic/cohere.insteadOf=https://github.com/system-inc/cohere.git -c url.file:///workspace/adamic/cohere/TypeScript.insteadOf=https://github.com/system-inc/TypeScript.git submodule update --init --recursive --depth 1 > /workspace/scratch/wall-submodules.log 2>&1
# The local-cache attempt failed on absent promisor objects. The recorded-origin retry succeeded.
git submodule sync --recursive > /workspace/scratch/wall-submodules-retry.log 2>&1
git -c protocol.file.allow=always submodule update --init --recursive --depth 1 >> /workspace/scratch/wall-submodules-retry.log 2>&1
go build -o /workspace/scratch/wall-adamic ./cmd/adamic > /workspace/scratch/wall-build-adamic.log 2>&1
go build -o /workspace/scratch/wall-census ./stage3/census/tool > /workspace/scratch/wall-build-census.log 2>&1
python3 stage3/census/latent/make_overlay.py "$PWD" /workspace/scratch/wall-latent-overlay > /workspace/scratch/wall-latent-overlay.log 2>&1
gofmt -w /workspace/scratch/wall-latent-overlay/*.go
go build -buildvcs=false -overlay=/workspace/scratch/wall-latent-overlay/overlay.json -o /workspace/scratch/wall-latent-census ./stage3/census/latent/tool > /workspace/scratch/wall-latent-build.log 2>&1
git worktree add -b typescript/axolotl-wall /workspace/scratch/axolotl-wall origin/main > /workspace/scratch/wall-report-worktree.log 2>&1
# freeze.py checks all adapter refs, saves the patch table, and hashes every source file.
python3 /workspace/scratch/wall-freeze.py > /workspace/scratch/wall-freeze.log 2>&1
# The retained driver invokes types with an argument array, census, report.py, then latent census.
# commands.json records exact argument arrays and durations. Its latent command is bounded at 5400 seconds.
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/scratch/wall-measure.py > /workspace/scratch/wall-measure.log 2>&1
# Analyze and publish only after the complete census exists. An early diagnostic-only inspection
# reached the expected 'latent census coverage incomplete' guard; final analysis checks full coverage.
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/scratch/wall-analyze.py > /workspace/scratch/wall-analyze.log 2>&1
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/scratch/wall-write-report.py > /workspace/scratch/wall-write-report.log 2>&1
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/scratch/wall-validate.py > /workspace/scratch/wall-validation.log 2>&1
