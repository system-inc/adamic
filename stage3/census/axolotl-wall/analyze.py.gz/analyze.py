import pathlib,json,re,importlib.util,collections
run=pathlib.Path('/workspace/scratch/wall-run'); tree=pathlib.Path('/workspace/scratch/wall-adapted'); repo=pathlib.Path('/workspace/scratch/axolotl-composed')
spec=importlib.util.spec_from_file_location('meter',repo/'stage3/meter/report.py'); meter=importlib.util.module_from_spec(spec); spec.loader.exec_module(meter)
rows=json.loads((run/'classification.json').read_text())
pat=re.compile(r'^(.+?):(\d+):(\d+): error TS(\d+): (.*)',re.S)
def parse(s):
 m=pat.match(s); assert m,s
 f,l,c,code,msg=m.groups(); f=meter.site_where(str(pathlib.Path(f).resolve()))
 return dict(file=f,line=int(l),column=int(c),code=int(code),message=msg)
def norm(s):
 d=parse(s); return (d['file'],d['line'],d['column'],d['code'],d['message'])
records=[json.loads(s) for s in (run/'census.jsonl').read_text().splitlines()]
raw=(run/'types.stderr').read_text(); starts=list(re.finditer(r'^.+?:\d+:\d+: error TS\d+:',raw,re.M))
direct=[raw[m.start():starts[i+1].start() if i+1<len(starts) else len(raw)].rstrip('\n') for i,m in enumerate(starts)]
assert collections.Counter(map(norm,direct))==collections.Counter(map(norm,records[-1].get('diagnostics',[]))), 'CLI and aggregate disagree'
union={norm(s):s for rec in records for s in rec.get('diagnostics',[])}
diags=[]
for k,s in sorted(union.items()):
 d=parse(s); source=(tree/d['file']).read_text().splitlines()[d['line']-1]; d['source_line']=source
 matches=[r for r in rows if (r['file'],r['code'],r['source_line'].strip())==(d['file'],d['code'],source.strip())]
 # Source text can occur more than once. Retain every candidate instead of guessing a row.
 d['source_key_candidates']=[r['id'] for r in matches]
 resolution='unique file/code/source-text key'
 if len(matches)>1:
  exact=[r for r in matches if r['message']==d['message']]
  if exact: matches=exact; resolution='source-text key plus exact full message'
 if len(matches)>1 and len({r['line'] for r in matches})==len(matches):
  # Distinct identical lines retain their relative occurrence order. Require a complete bijection.
  locations=[i+1 for i,text in enumerate((tree/d['file']).read_text().splitlines()) if text.strip()==source.strip()]
  original=sorted(matches,key=lambda r:r['line'])
  assert len(locations)==len(original), (d,locations,original)
  matches=[original[locations.index(d['line'])]]
  resolution='source-text key plus occurrence order (complete bijection)'
 d['match_resolution']=resolution
 assert len(matches)<=1, ('ambiguous classification',d,matches)
 d['row_ids']=[r['id'] for r in matches]; d['classification']=[{k:r[k] for k in ('id','line','column','cause','reason')} for r in matches]
 d['new']=not matches; d['whole_program']=k in set(map(norm,direct))
 diags.append(d)
(run/'diagnostics-matched.json').write_text(json.dumps(diags,indent=2)+'\n')
latent_records=[json.loads(line) for line in (run/'latent.jsonl').read_text().splitlines()]
assert latent_records[0]['checker_rejected'] is True
assert collections.Counter(map(norm,latent_records[0]['diagnostics']))==collections.Counter(map(norm,direct)), 'latent and CLI diagnostics disagree'
latent=meter.latent_summary(tree,run)
assert latent['latent_mode']=='first-error' and latent['source_files']==79
(run/'latent-summary.json').write_text(json.dumps(latent,indent=2)+'\n')
print(json.dumps({'diagnostics':len(diags),'whole_program':len(direct),'new':sum(d['new'] for d in diags),'ambiguous':sum(len(d['row_ids'])>1 for d in diags),'meter':json.loads((run/'report.json').read_text())['totals'],'latent':{k:latent[k] for k in ('totals','source_files','latent_mode','recorded_events','reason_rows')}},indent=2))
