from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/scratch/axolotl-composed'); tree=Path('/workspace/scratch/wall-adapted'); run=Path('/workspace/scratch/wall-run')
names=sorted(p.name for p in (repo/'stage3/adapt').iterdir() if p.is_dir())
refs=subprocess.check_output(['git','-C',str(tree),'for-each-ref','--format=%(refname)','refs/stage3'],text=True).splitlines()
assert sorted(refs)==sorted('refs/stage3/'+n+s for n in names for s in ('-before','-after'))
assert (tree/'patch-set.md').is_file()
source_hashes={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
(run/'frozen-source-sha256.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
(run/'adapter-coverage.json').write_text(json.dumps({'count':len(names),'all_applied':True,'adapters':names,'refs':refs},indent=2)+'\n')
(run/'patch-set.md').write_bytes((tree/'patch-set.md').read_bytes())
print('All',len(names),'adapters applied;',len(source_hashes),'source files frozen.')
