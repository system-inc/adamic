const fs = require('fs');
const counts = Object.create(null);
globalThis.__orCensus = function(site, funcs) {
 const row = counts[site] ||= {factories:0,calls:0,completed:0,returns:[],predicates:{},differences:0,otherTypes:{},argumentCounts:{}};
 row.factories++;
 return (...args) => {
  row.calls++;
  row.argumentCounts[args.length]=(row.argumentCounts[args.length]||0)+1;
  let lastResult, candidate;
  for(let i=0;i<funcs.length;i++) {
   const f = funcs[i];
   lastResult = f(...args);
   const bucket = row.returns[i] ||= {true:0,false:0,other:0};
   const kind=lastResult===true?'true':lastResult===false?'false':'other';
   bucket[kind]++;
   const named=row.predicates[i+':'+f.name] ||= {true:0,false:0,other:0};
   named[kind]++;
   if(typeof lastResult!=='boolean') {const key=i+':'+typeof lastResult;row.otherTypes[key]=(row.otherTypes[key]||0)+1;}
   candidate = i===0 ? lastResult : candidate || lastResult;
   if(lastResult) break;
  }
  row.completed++;
  if(!Object.is(lastResult,candidate)) row.differences++;
  return lastResult;
 };
};
function flush(){if(process.env.OR_CENSUS_DIR) fs.writeFileSync(process.env.OR_CENSUS_DIR+'/'+process.pid+'.json',JSON.stringify({pid:process.pid,counts}));}
process.on('exit',flush);
// Workers are sometimes killed immediately after reporting. Persist before IPC sends.
if(process.send) {const send=process.send;process.send=function(...args){flush();return Reflect.apply(send,this,args);};}
