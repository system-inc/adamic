import json,collections,hashlib
from pathlib import Path
w=Path('/workspace/scratch/or-calls');repo=Path('/workspace/adamic')
plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text())['units']
reports=[];merged={};files=[];locations={}
for p in sorted(w.glob('piece-*/results.json')):
 piece=json.loads(p.read_text());reports.extend(piece['units']);locations.update({r['name']:p.parent for r in piece['units']})
 for f in sorted(f for r in piece['units'] for f in (p.parent/r['name']/'counts').glob('*.json')):
  d=json.loads(f.read_text());files.append({'path':str(f.relative_to(w)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
  for site,r in d['counts'].items():
   out=merged.setdefault(site,dict(factories=0,calls=0,completed=0,differences=0,returns=[],predicates={},otherTypes={},argumentCounts={}))
   for k in ['factories','calls','completed','differences']:out[k]+=r[k]
   for i,v in enumerate(r['returns']):
    while len(out['returns'])<=i:out['returns'].append(dict(true=0,false=0,other=0))
    for k,n in v.items():out['returns'][i][k]+=n
   for k,v in r['predicates'].items():
    target=out['predicates'].setdefault(k,dict(true=0,false=0,other=0))
    for kind,n in v.items():target[kind]+=n
   for field in ['otherTypes','argumentCounts']:
    for k,n in r[field].items():out[field][k]=out[field].get(k,0)+n
names=[r['name'] for r in reports];expected=[u['name'] for u in plan]
assert len(set(names))==len(names),'duplicate units'
assert set(names)<=set(expected)
for r in reports:
 assert r['exit']==0 and r['report']['status']=='pass' and not r['report']['errors'],r['name']
 assert r['report']['upstream_exit'] in [0,1]
byname={u['name']:u for u in plan}
plandata=json.loads((repo/'stage3/lane/shard-plan.json').read_text())
for r in reports:
 raw=locations[r['name']]/'units'/r['name']
 assert json.loads((raw/'report.json').read_text())==r['report'],r['name']
 records=json.loads((raw/'observations.json').read_text())
 actual=collections.Counter(x['status'] for x in records)
 assert {k:actual[status] for k,status in [('pass','pass'),('fail','fail'),('skip','pending')]}==r['report']['counts'],r['name']
 inputs=dict(artifact='stage3-adapted-tree',api=plandata['api_digest'],runtime=plandata['runtime'],unit=byname[r['name']])
 digest=hashlib.sha256(json.dumps(inputs,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert r['report']['inputs_hash']==digest,r['name']
counts=collections.Counter()
for r in reports:counts.update(r['report']['counts'])
for s,r in merged.items():
 assert r['calls']==r['completed'],('incomplete closure',s,r)
 assert (sum(r['returns'][0].values()) if r['returns'] else 0)==r['calls'],s
 assert r['differences']==0,(s,r)
for site,r in merged.items():
 assert sum(x['other'] for x in r['returns'])==sum(r['otherTypes'].values()),site
 assert sum(sum(x.values()) for x in r['predicates'].values())==sum(sum(x.values()) for x in r['returns']),site
summary=dict(completed_units=len(names),planned_units=len(expected),complete=set(names)==set(expected),counts=dict(counts),missing=sorted(set(expected)-set(names)),sites=merged,process_count_files=files)
(w/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['completed_units','planned_units','complete','counts']}))
