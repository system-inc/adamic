const fs=require('fs'),path=require('path'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const root=process.argv[2], known=JSON.parse(fs.readFileSync(process.argv[3])).rows;
const rows=[];
for(const file of ts.sys.readDirectory(root+'/built/local',['.js'],undefined,['**/*'])) {
 const text=fs.readFileSync(file,'utf8');
 if(!/function or\(/.test(text))continue;
 const sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS), mapFile=file+'.map';
 if(!fs.existsSync(mapFile))throw Error('missing map '+file);
 const map=JSON.parse(fs.readFileSync(mapFile)), byLine=new Map();
 for(const m of ts.decodeMappings(map.mappings)) {let a=byLine.get(m.generatedLine);if(!a)byLine.set(m.generatedLine,a=[]);a.push(m);}
 function source(n){const p=sf.getLineAndCharacterOfPosition(n.getStart(sf)),maps=byLine.get(p.line)||[];let best;for(const m of maps)if(m.generatedCharacter<=p.character)best=m; if(!best||best.sourceIndex===undefined)throw Error('unmapped '+n.getText(sf));const f=map.sources[best.sourceIndex].replace(/\\/g,'/'); const rel=f.slice(f.indexOf('src/')); return {file:rel,line:best.sourceLine+1};}
 const edits=[];
 function visit(n){
  if(ts.isFunctionDeclaration(n)&&n.name?.text==='or'&&n.body){
   const s=source(n);if(s.file!=='src/compiler/core.ts')throw Error('wrong or '+JSON.stringify(s));
   edits.push({start:n.body.getStart(sf),end:n.body.end,text:'{ const __orSite = '+n.parameters[0].name.text+'.shift(); return globalThis.__orCensus(__orSite, '+n.parameters[0].name.text+'); }'});
  }
  if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='or') {
   const s=source(n),matches=known.filter(r=>r.site===s.file+':'+s.line);
   if(matches.length!==1)throw Error('unknown call '+file+' '+JSON.stringify(s)+' '+n.getText(sf));
   edits.push({start:n.arguments.pos,end:n.arguments.pos,text:JSON.stringify(matches[0].site)+', '});
   rows.push({bundle:path.relative(root,file),site:matches[0].site});
  }
  ts.forEachChild(n,visit);
 }visit(sf);
 let changed=text;for(const e of edits.sort((a,b)=>b.start-a.start))changed=changed.slice(0,e.start)+e.text+changed.slice(e.end);
 fs.writeFileSync(file+'.uninstrumented',text);fs.writeFileSync(file,changed);
}
fs.writeFileSync(root+'/or-instrumentation.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows));
