from pathlib import Path
import json,hashlib,subprocess,datetime
w=Path('/workspace/scratch/or-calls');repo=Path('/workspace/adamic');tree=w/'tree'
s=json.loads((w/'summary.json').read_text());plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());assert s['complete'] and s['counts']==plan['counts']
a=json.loads((w/'adapted-census.json').read_text());audit=json.loads((w/'reference-audit.json').read_text());assert a['rows']==audit['rows']
assert set(s['sites'])<=set(r['site'] for r in a['rows'])
pred=[r for r in a['rows'] if r['site'].startswith('src/compiler/') and r['overload']<3];assert len(pred)==7
for r in pred:
 v=s['sites'][r['site']];assert v['calls']>0 and len(v['returns'])==len(r['arguments']);assert all(sum(p.values())>0 and p['other']==0 for p in v['returns'])
original={};instrumented={}
for f in sorted((tree/'built/local').rglob('*.js.uninstrumented')):
 dest=Path(str(f).removesuffix('.uninstrumented'));name=str(dest.relative_to(tree));original[name]=hashlib.sha256(f.read_bytes()).hexdigest();instrumented[name]=hashlib.sha256(dest.read_bytes()).hexdigest();dest.write_bytes(f.read_bytes());f.unlink();assert hashlib.sha256(dest.read_bytes()).hexdigest()==original[name]
assert len(original)==3
(w/'instrumentation-map.json').write_bytes((tree/'or-instrumentation.json').read_bytes());(tree/'or-instrumentation.json').unlink()
assert not any('__orCensus' in p.read_text() for p in (tree/'built/local').rglob('*.js'))
after={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
assert after==json.loads((w/'source-before-lane.json').read_text());(w/'source-after-lane.json').write_text(json.dumps(after,indent=2)+'\n')
modules=repo/'stage3/typescript/node_modules';assert modules.is_symlink() and modules.resolve()==(tree/'node_modules').resolve();modules.unlink()
provenance=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),typescript_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/typescript-source',text=True).strip(),node=subprocess.check_output(['node','--version'],text=True).strip(),checker_version=a['version'],checker_sha256=hashlib.sha256((repo/'stage3/api/node_modules/typescript/lib/typescript.js').read_bytes()).hexdigest(),completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_bundle_sha256=original,instrumented_bundle_sha256=instrumented,source_files=len(after),source_unchanged=True,observers_removed=True,phase_exits=dict(setup=0,api_install=0,source_clone=0,apply=0,tree_install=0,build=0,harness=0,census=0,instrument=0,smoke=0,seeds=0,piece_00=0,remaining=0))
(w/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');print(json.dumps({'restored_bundles':len(original),'source_files':len(after),'complete':True}))
