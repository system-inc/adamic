const assert=require('assert/strict');require('./observer.cjs');
const root='/workspace/scratch/or-calls/tree/built/local/';
const plain=require(root+'typescript.js.uninstrumented'),observed=require(root+'typescript.js');
function compile(ts){const outputs={};const options={module:ts.ModuleKind.ESNext,moduleDetection:ts.ModuleDetectionKind.Auto,target:ts.ScriptTarget.ES2020,noLib:true,noResolve:true};const host=ts.createCompilerHost(options);host.getSourceFile=(f,l)=>f==='/case.ts'?ts.createSourceFile(f,'export const x: number = 1;',l):undefined;host.writeFile=(f,s)=>outputs[f]=s;const p=ts.createProgram(['/case.ts'],options,host);p.emit();return {outputs,diagnostics:ts.getPreEmitDiagnostics(p).map(d=>[d.code,ts.flattenDiagnosticMessageText(d.messageText,'\n')])};}
assert.deepEqual(compile(observed),compile(plain));console.log(JSON.stringify({pass:true}));
