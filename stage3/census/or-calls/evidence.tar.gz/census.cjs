const ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const fs=require('fs'),path=require('path');
const root=process.argv[2];
const files=ts.sys.readDirectory(root+'/src',['.ts'],undefined,['**/*']);
const config=ts.readConfigFile(root+'/src/tsconfig-base.json',ts.sys.readFile);
const options=ts.parseJsonConfigFileContent(config.config,ts.sys,root+'/src').options;
Object.assign(options,{noEmit:true,types:['node','mocha','chai'],typeRoots:[root+'/node_modules/@types']});
const program=ts.createProgram(files,options);
const c=program.getTypeChecker(), rows=[];
for(const sf of program.getSourceFiles()) if(sf.fileName.startsWith(root+'/src/')) {
 function visit(n){
  if(ts.isCallExpression(n)) {
   let s=c.getSymbolAtLocation(n.expression); if(s?.flags&ts.SymbolFlags.Alias)s=c.getAliasedSymbol(s);
   if(s?.declarations?.some(d=>ts.isFunctionDeclaration(d)&&d.name?.text==='or'&&d.getSourceFile().fileName.endsWith('/compiler/core.ts'))) {
    const sig=c.getResolvedSignature(n),d=sig?.declaration, decls=s.declarations.filter(x=>ts.isFunctionDeclaration(x)&&!x.body);
    const lc=sf.getLineAndCharacterOfPosition(n.getStart(sf));
    rows.push({site:path.relative(root,sf.fileName)+':'+(lc.line+1),start:n.getStart(sf),end:n.end,overload:decls.indexOf(d)+1,signature:c.signatureToString(sig,n,ts.TypeFormatFlags.NoTruncation),arguments:n.arguments.map(a=>({text:a.getText(sf),type:c.typeToString(c.getTypeAtLocation(ts.isSpreadElement(a)?a.expression:a),a,ts.TypeFormatFlags.NoTruncation)})),parent:n.parent.getText(sf).slice(0,1200),declaration:d?.getText()});
   }
  }
  ts.forEachChild(n,visit);
 } visit(sf);
}
console.log(JSON.stringify({version:ts.version,options,files:files.length,rows},null,2));
