from concurrent.futures import ThreadPoolExecutor,as_completed
import json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/workspace/adamic');work=Path('/workspace/scratch/or-calls');piece=int(sys.argv[1]);size=20
units=json.loads((repo/'stage3/lane/shard-plan.json').read_text())['units'][piece*size:(piece+1)*size]
assert units
out=work/f'piece-{piece:02d}';out.mkdir();rows=[];start=time.monotonic()
def run(u):
 env=dict(os.environ,STAGE3_ADAPTED_TREE=str(work/'product'),OR_CENSUS_DIR=str(out/u['name']/'counts'))
 (out/u['name']/'counts').mkdir(parents=True)
 env['NODE_OPTIONS']=env.get('NODE_OPTIONS','')+' --require='+str(work/'observer.cjs')
 with (out/(u['name']+'.log')).open('w') as log:
  child=subprocess.run(['python3',str(repo/'stage3/lane/shard.py'),u['name'],str(out/'units')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 report=out/'units'/u['name']/'report.json'
 r=dict(name=u['name'],exit=child.returncode,report=json.loads(report.read_text()) if report.exists() else None)
 if child.returncode==0:
  import shutil
  shutil.rmtree(out/'units'/u['name']/'adapted-tree')
 return r
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,u) for u in units]):
  r=f.result();rows.append(r);print(json.dumps({'name':r['name'],'exit':r['exit']}),flush=True)
  (out/'results.json').write_text(json.dumps(dict(piece=piece,seconds=time.monotonic()-start,units=rows),indent=2))
sys.exit(1 if any(r['exit'] for r in rows) else 0)
