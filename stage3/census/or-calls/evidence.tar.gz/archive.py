from pathlib import Path
import tarfile,hashlib,json,subprocess
w=Path('/workspace/scratch/or-calls');out=Path('/workspace/adamic/stage3/census/or-calls');files={}
for p in w.iterdir():
 if p.is_file() and p.name not in ['evidence-members.json','pack.log'] and p.suffix in ['.py','.cjs','.json','.log']:files[p.name]=p
for directory in sorted(w.iterdir()):
 if not directory.is_dir() or 'piece-' not in directory.name:continue
 for p in directory.rglob('*'):
  rel=p.relative_to(directory)
  if 'adapted-tree' in rel.parts:continue
  if p.is_file() and not p.is_symlink() and p.suffix in ['.log','.json','.jsonl','.txt','.md','.diff']:files[str(p.relative_to(w))]=p
for n,p in [('lane-shard-plan.json',Path('/workspace/adamic/stage3/lane/shard-plan.json')),('source-pin.json',Path('/workspace/adamic/stage3/source.json'))]:files[n]=p
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(files.items())}
(w/'evidence-members.json').write_text(json.dumps(manifest,indent=2)+'\n');files['evidence-members.json']=w/'evidence-members.json'
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'evidence.sha256').write_text(digest+'  evidence.tar.gz\n')
with tarfile.open(archive) as t:
 for name,d in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==d,name
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':digest}))
