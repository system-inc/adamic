'use strict';
const assert=require('assert/strict'); require('./observer.cjs');
function original(...fs){return (...args)=>{let lastResult;for(const f of fs){lastResult=f(...args);if(lastResult)return lastResult;}return lastResult;};}
const values=[true,false,undefined,null,0,-0,NaN,'',7,'yes',{},[]];let checked=0;
for(const a of values)for(const b of values)for(const c of values){
 let log=[]; const make=v=>function(...args){assert.equal(this,undefined);assert.deepEqual(args,[19,'x']);log.push(v);return v;};
 const fs=[a,b,c].map(make);const x=original(...fs)(19,'x'),calls=log.slice();log=[];
 const y=globalThis.__orCensus('seed',fs)(19,'x');assert.ok(Object.is(x,y));assert.deepEqual(log,calls);checked++;
}
console.log(JSON.stringify({checked,pass:true}));
