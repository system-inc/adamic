import subprocess,json,sys,time
from pathlib import Path
w=Path('/workspace/scratch/or-calls');rows=[]
for i in range(1,20):
 start=time.monotonic()
 with (w/f'piece-{i:02d}.log').open('w') as log:r=subprocess.run(['python3',str(w/'piece.py'),str(i)],stdout=log,stderr=subprocess.STDOUT)
 row=dict(piece=i,exit=r.returncode,seconds=time.monotonic()-start);rows.append(row)
 (w/'remaining-phases.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:sys.exit(r.returncode)
sys.exit(0)
