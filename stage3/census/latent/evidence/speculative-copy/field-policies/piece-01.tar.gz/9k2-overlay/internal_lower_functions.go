// Functions and declarations moved unchanged from lower.go.
package lower

import (
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/microsoft/TypeScript/tsc/shim/scanner"
	"github.com/system-inc/adamic/internal/ir"
)

// functionBody lowers a module function declaration's parameters and body.
func (l *lowering) functionBody(declaration *ast.Node) error {
	return l.lowerFunction(l.functions[l.symbol(declaration.Name())], declaration, -1)
}

// defaulted is a parameter with a default: the local the body declares, the one the argument arrives
// in, and the default.
type defaulted struct {
	local, incoming int
	initializer     *ast.Node
}

// signed is what a function whose signature is written still needs to lower its body: the local its
// this is, or -1, its parameters' defaults, and its destructured parameters.
type signed struct {
	this     int
	defaults []defaulted
	patterns []patterned
}

// patterned is a destructured parameter, ([key, value]) or ({ x, y }): the pattern, the parameter,
// and the local it arrives in whole.
type patterned struct {
	pattern   *ast.Node
	parameter *ast.Node
	incoming  int
}

// lowerFunction lowers a function-like declaration into the function at index: its signature, unless
// signature has written it already, then its body. this, when not -1, is the local a method's or
// constructor's this is, passed first.
//
// It works on a copy and writes it back by index: lowering a body can instantiate a class, which
// appends functions, and a pointer into the slice would be left pointing at the old one.
func (l *lowering) lowerFunction(index int, declaration *ast.Node, this int) error {
	if latentConcreteCallDepth > 0 && latentInstantiated != nil {
		latentInstantiated[l.program.Where(declaration)] = true
	}
	if !latentSpeculativeEnabled() && len(l.latentBodyDiagnostics(declaration.Body())) > 0 {
		return &LatentDependencySkipped{Where: l.program.Where(declaration)}
	}
	if implementation := l.censusImplementation(declaration); implementation != nil {
		declaration = implementation
	}
	if _, isSigned := l.signed[index]; !isSigned {
		if err := l.signature(index, declaration, this); err != nil {
			return err
		}
	}
	if latentPieceSkipBody(declaration) {
		return nil
	}
	pending := l.signed[index]
	delete(l.signed, index)
	return l.lowerBody(index, declaration, pending.this, pending.defaults, pending.patterns)
}

// signature writes the function at index's parameters and result, from the checker, without lowering
// its body, so a call to it lowers whether or not its body has been. this is as for lowerFunction.
func (l *lowering) latentMainSignatureRaw(index int, declaration *ast.Node, this int) error {
	if implementation := l.censusImplementation(declaration); implementation != nil {
		declaration = implementation
	}
	if err := l.censusOverloads(declaration); err != nil {
		return err
	}
	function := l.result.Functions[index]
	function.SourceLength = sourceFunctionLength(declaration)
	name := declaration.Name()
	if name == nil {
		name = declaration
	}
	source := ast.GetSourceFileOfNode(name)
	line, column := scanner.GetLineAndCharacterOfPosition(source, scanner.GetTokenPosOfNode(name, source, false))
	function.Position = ir.SourcePosition{File: l.program.FileName(source), Line: line + 1, Column: column + 1}
	if this >= 0 && declaration.Kind != ast.KindConstructor {
		// A method receives this; a constructor makes it.
		function.Parameters = append(function.Parameters, this)
		function.Boundary.Parameters = append(function.Boundary.Parameters, ir.BoundaryParameter{})
		function.Receiver = true
	}
	if implementation := generatorImplementation(declaration); implementation != nil {
		// A class writes each overload's signature into its implementation's function before the
		// implementation's own (class.go), so the gate reads the implementation from the first one,
		// before an overload could write it as an ordinary function's.
		return l.generatorNotYet(implementation, generatorForm(implementation))
	}
	if generatorDeclaration(declaration) {
		// Every function body is lowered after its signature is written, here, so this is where a
		// generator of a form this slice doesn't lower stops, before its body could be lowered as an
		// ordinary function's (a function* that only returns would return undefined, not a generator).
		if !loweredGenerator(declaration) {
			return l.generatorNotYet(declaration, generatorForm(declaration))
		}
		if err := l.generatorSignature(&function, declaration); err != nil {
			return err
		}
	} else if declaration.Kind != ast.KindConstructor {
		signature := l.checker.GetSignatureFromDeclaration(declaration)
		returns := l.concrete(l.checker.GetReturnTypeOfSignature(signature))
		function.Boundary.Return = l.boundarySchema(declaration, returns)
		// A function that never returns (it panics on every path, as (why) => panic(why) does) has no
		// result to hold, as one returning void hasn't. An arrow whose expression is never for another
		// reason, a variable the checker narrowed to nothing, isn't one.
		neverArrow := returns.Flags()&checker.TypeFlagsNever != 0 && declaration.Body() != nil && declaration.Body().Kind != ast.KindBlock && declaration.Body().Kind != ast.KindCallExpression && !l.isPanicCall(declaration.Body())
		if returns.Flags()&(checker.TypeFlagsVoid|checker.TypeFlagsNever) == 0 || neverArrow {
			valueType, isKnown := l.representation(returns)
			if returns.Flags()&checker.TypeFlagsUndefined != 0 {
				valueType, isKnown = ir.Object, true
			}
			if function.Closure && l.regexReplacementArgument(declaration) {
				if returns.Flags()&checker.TypeFlagsUndefined != 0 {
					valueType, isKnown = ir.String, true
				}
				if returns.Flags()&checker.TypeFlagsNull != 0 {
					valueType, isKnown = ir.Object, true
				}
			}
			if !isKnown {
				valueType, isKnown = l.clockGenericReturnsT01(returns)
			}
			if !isKnown {
				// An arrow function has no name to point at, so it's pointed at whole.
				where := declaration.Name()
				if where == nil {
					where = declaration
				}
				return l.notYet(where, "a function returning "+l.checker.TypeToString(returns))
			}
			function.Returns = valueType
		}
	}
	if ast.HasSyntacticModifier(declaration, ast.ModifierFlagsAsync) {
		returns := l.checker.GetReturnTypeOfSignature(l.checker.GetSignatureFromDeclaration(declaration))
		if !l.isLibraryType(returns, "Promise") {
			return l.notYet(declaration, "an async result other than the library Promise")
		}
		arguments := l.checker.GetTypeArguments(returns)
		if len(arguments) != 1 {
			return l.notYet(declaration, "full Promise compatibility")
		}
		function.Async = true
		function.AsyncSite = l.asyncSite(declaration)
		function.Returns = ir.Promise
		if arguments[0].Flags()&(checker.TypeFlagsVoid|checker.TypeFlagsUndefined|checker.TypeFlagsNever) == 0 {
			var known bool
			function.AsyncReturns, known = l.representation(arguments[0])
			if !known {
				return l.notYet(declaration, "an async payload of "+l.checker.TypeToString(arguments[0]))
			}
		}
	}
	outerIndexForParameters := l.functionIndex
	l.functionIndex = index
	defer func() { l.functionIndex = outerIndexForParameters }()
	// A parameter with a default arrives as what may be missing, and the body begins by declaring the
	// parameter itself: the argument, or the default when it's undefined, as JavaScript decides.
	defaults := []defaulted{}
	// A destructured parameter, ([key, value]) or ({ x, y }), arrives whole in a parameter of its own,
	// and its names are declared from it before the body runs.
	patterns := []patterned{}
	for position, parameter := range declaration.Parameters() {
		declared := parameter.AsParameterDeclaration()
		function.Boundary.Parameters = append(function.Boundary.Parameters, ir.BoundaryParameter{Schema: l.boundarySchema(parameter, l.checker.GetTypeAtLocation(parameter))})
		if name := parameter.Name(); (name.Kind == ast.KindArrayBindingPattern || name.Kind == ast.KindObjectBindingPattern) && declared.DotDotDotToken == nil && declared.Initializer == nil && declared.QuestionToken == nil {
			incoming := len(l.result.Locals)
			heldAs := ir.Object
			if represented, _ := l.representation(l.checker.GetTypeAtLocation(parameter)); represented == ir.String {
				heldAs = ir.String
			}
			l.result.Locals = append(l.result.Locals, ir.Local{Name: "destructured", Type: heldAs, Function: index})
			function.Parameters = append(function.Parameters, incoming)
			patterns = append(patterns, patterned{pattern: name, parameter: parameter, incoming: incoming})
			continue
		}
		if !ast.IsIdentifier(parameter.Name()) {
			return l.notYet(parameter, "a parameter that isn't a plain name")
		}
		// A this parameter names the receiver's type and takes no argument: f(this: void, n) is called
		// as f(1). Declared here as a local it shifts every argument after it by one, so a function
		// declaration printed NaN where Node prints 2, and a method, whose receiver is already its first
		// parameter, shifts the same way (#j8mt4pr). Every declaration's parameters pass through this
		// loop, so it stops here when another parameter follows, until this is dropped from the lowered
		// parameters, the real fix. With nothing after it nothing shifts, and the body's this is the
		// receiver, so an object literal's value(this: { flags: number }) lowers and agrees with Node
		// (namespace_method_receiver.a). A function expression, a nested declaration, a namespace
		// function and a function used as a value stop sooner, in their own words.
		if parameter.Name().Text() == "this" && position < len(declaration.Parameters())-1 {
			return l.notYet(parameter, "a function or method with a this parameter followed by another parameter (dynamic receivers are not implemented)")
		}
		local, err := l.declareLocal(parameter.Name())
		if err != nil {
			return err
		}
		if parameterProperty(parameter) {
			// The binder gives a parameter property both a field symbol and a lexical parameter
			// symbol. Reads and assignments in the body refer to the latter.
			parameters := l.checker.GetSignatureFromDeclaration(declaration).Parameters()
			l.locals[parameters[position]] = local
		}
		if declared.DotDotDotToken != nil {
			proven := l.concrete(l.checker.GetTypeAtLocation(parameter.Name()))
			// Only an array reference has type arguments to read. The checker dereferences nil for
			// anything else, such as the union of tuples tsc's createConstructorTypeNode takes as
			// Parameters<typeof createConstructorTypeNode1 | typeof createConstructorTypeNode2> (#egxccg8).
			if !l.isArrayType(proven) {
				return l.notYet(parameter, "a rest parameter that isn't an array")
			}
			elements := l.checker.GetTypeArguments(proven)
			if len(elements) != 1 {
				return l.notYet(parameter, "a rest parameter that isn't an array")
			}
			element, known := l.representation(elements[0])
			if !known || slotless(element) && element != ir.Union {
				return l.notYet(parameter, "a rest parameter whose elements cannot be packed")
			}
			function.RestElement = element
		}
		if function.Closure && censusCallableSlotless(l.result.Locals[local].Type) && !(l.result.Locals[local].Type == ir.Union && l.regexReplacementArgument(declaration)) {
			// Its arguments are each one adamic_value.
			return l.notYet(parameter, "a function value taking "+l.checker.TypeToString(l.checker.GetTypeAtLocation(parameter.Name())))
		}
		if declared.Initializer == nil {
			function.Parameters = append(function.Parameters, local)
			continue
		}
		missing := ir.Maybe(l.result.Locals[local].Type)
		if !missing.IsMaybe() && !missing.IsReference() {
			return l.notYet(parameter, "a default for a "+typeName(missing)+" parameter")
		}
		incoming := len(l.result.Locals)
		l.result.Locals = append(l.result.Locals, ir.Local{Name: parameter.Name().Text(), Type: missing, Function: index})
		function.Parameters = append(function.Parameters, incoming)
		defaults = append(defaults, defaulted{local: local, incoming: incoming, initializer: declared.Initializer})
	}
	if function.Closure && censusCallableSlotless(function.Returns) && !(function.Returns == ir.Union && l.regexReplacementArgument(declaration)) {
		// A function value's arguments and result must each fit one adamic_value.
		return l.notYet(declaration, "a function value returning "+typeName(function.Returns))
	}
	if declaration.Body() == nil && !ast.HasSyntacticModifier(declaration, ast.ModifierFlagsAbstract) {
		return l.notYet(declaration, "a function without a body")
	}
	function.OptionalParameters = map[int]bool{}
	offset := 0
	if function.Receiver {
		offset = 1
	}
	for i, node := range declaration.Parameters() {
		parameter := node.AsParameterDeclaration()
		if parameter.QuestionToken != nil || parameter.Initializer != nil {
			function.OptionalParameters[function.Parameters[i+offset]] = true
		}
	}
	if function.Source.Module == "" {
		function.Source = l.functionSource(declaration)
	}
	l.result.Functions[index] = function
	if !function.Closure && declaration.Kind != ast.KindConstructor && declaration.Name() != nil {
		l.closureRecords = append(l.closureRecords, closureRecord{proven: l.concrete(l.checker.GetTypeAtLocation(declaration.Name())), function: index, node: declaration})
	}
	// A declared constructor also supplies the public allocator's signature.
	// The initializer's receiver is internal and the class result is not data.
	if declaration.Kind == ast.KindConstructor && l.instance != nil && l.instance.constructor >= 0 {
		allocator := &l.result.Functions[l.instance.constructor]
		allocator.Position = function.Position
		allocator.Boundary.Parameters = append([]ir.BoundaryParameter(nil), function.Boundary.Parameters...)
	}
	if l.signed == nil {
		l.signed = map[int]signed{}
	}
	l.signed[index] = signed{this: this, defaults: defaults, patterns: patterns}
	if l.latentReady == nil {
		l.latentReady = map[int]bool{}
	}
	l.latentReady[index] = true
	return nil
}

// lowerBody lowers the body of the function at index, whose signature is written.
func (l *lowering) lowerBody(index int, declaration *ast.Node, this int, defaults []defaulted, patterns []patterned) error {
	if declaration.Body() == nil {
		return l.notYet(declaration, "a function without a body")
	}
	if l.functionNodes == nil {
		l.functionNodes = map[int]*ast.Node{}
	}
	l.functionNodes[index] = declaration
	// Every call in a body is judged when the body is lowered, under its own mapper (predicates_branded.go).
	if err := l.judgeBrandedCalls(declaration); err != nil {
		return err
	}
	function := l.result.Functions[index]
	if !function.Closure {
		// A function declaration, a method or a constructor has its body lowered where a use of it is first met,
		// a closure's body included, but it's declared at the top level and captures nothing from
		// the closures being lowered there: a local of its own read in a closure of its own must not
		// land in their environments.
		outerClosures := l.closures
		l.closures = nil
		defer func() { l.closures = outerClosures }()
	}
	body := declaration.Body()
	outer, outerThis, outerIndex := l.function, l.this, l.functionIndex
	l.function, l.functionIndex = &function, index
	if this >= 0 {
		l.this = this
	}
	// Defaults run before the body, in order, after a constructor's fields, as JavaScript runs them.
	var prologue, lowered []ir.Statement
	var err error
	// Signature allocates incoming locals in source parameter order. Merge the two
	// prologues by that order: a default can read an earlier destructured name,
	// and a later destructuring must observe any mutation made by a default.
	for patternIndex, defaultIndex := 0, 0; patternIndex < len(patterns) || defaultIndex < len(defaults); {
		if err != nil {
			break
		}
		if patternIndex < len(patterns) && (defaultIndex == len(defaults) || patterns[patternIndex].incoming < defaults[defaultIndex].incoming) {
			parameter := patterns[patternIndex]
			patternIndex++
			patternType := l.checker.GetTypeAtLocation(parameter.parameter)
			heldAs, _ := l.representation(patternType)
			var destructured []ir.Statement
			destructured, err = l.destructureFrom(parameter.pattern, patternType, heldAs, parameter.incoming)
			prologue = append(prologue, destructured...)
			continue
		}
		parameter := defaults[defaultIndex]
		defaultIndex++
		if declaration.Kind == ast.KindConstructor {
			if err = l.parameterPropertyDefault(declaration, parameter.initializer); err != nil {
				break
			}
		}
		if l.uninitializedInitializer(parameter.initializer) {
			l.result.Locals[parameter.local].Uninitialized = true
			incoming := ir.Read{Local: parameter.incoming, Of: l.result.Locals[parameter.incoming].Type}
			prologue = append(prologue, ir.Declare{Local: parameter.local, Value: l.placeholderInitialValue(parameter.initializer, l.result.Locals[parameter.local].Type), Uninitialized: true}, ir.If{Condition: ir.Unary{Operator: ir.Not, Operand: ir.IsUndefined{Value: incoming}}, Then: []ir.Statement{ir.Assign{Local: parameter.local, Value: fit(incoming, l.result.Locals[parameter.local].Type)}}})
			continue
		}

		var fallback ir.Expression
		if fallback, err = l.expression(parameter.initializer); err != nil {
			break
		}
		of := l.result.Locals[parameter.local].Type
		if fallback = fit(fallback, of); fallback.Type() != of {
			err = l.notYet(parameter.initializer, "a default of another type than its parameter")
			break
		}
		incoming := ir.Read{Local: parameter.incoming, Of: l.result.Locals[parameter.incoming].Type}
		prologue = append(prologue, ir.Declare{Local: parameter.local, Value: ir.Coalesce{Value: incoming, Fallback: fallback, Of: of}})
	}
	if err != nil {
		l.function, l.this, l.functionIndex = outer, outerThis, outerIndex
		return err
	}
	if declaration.Kind == ast.KindConstructor && l.instance.base == nil {
		assigned, assignErr := l.parameterPropertyStores(declaration.Parent, this)
		if assignErr != nil {
			l.function, l.this, l.functionIndex = outer, outerThis, outerIndex
			return assignErr
		}
		prologue = append(prologue, assigned...)
	}
	if body.Kind == ast.KindBlock {
		lowered, err = l.statements(body.AsBlock().Statements.Nodes)
	} else if function.BodyReturns() == 0 || l.isPanicCall(body) {
		// An arrow function's expression body, when it returns nothing or never returns (() =>
		// panic('why')), is a statement.
		lowered, err = l.expressionStatement(body)
	} else {
		// Otherwise its value is what it returns.
		var value ir.Expression
		if value, err = l.expression(body); err == nil {
			if err = l.checkAsyncReturn(body, value); err == nil {
				lowered, err = l.checkedPredicateReturn(declaration, body, fit(value, function.BodyReturns()))
			}
		}
	}
	l.function, l.this, l.functionIndex = outer, outerThis, outerIndex
	if err != nil {
		return err
	}
	if body.Kind == ast.KindBlock && declaration.Kind != ast.KindConstructor && declaration.Flags&ast.NodeFlagsHasImplicitReturn != 0 && l.permitsImplicitReturn(declaration) {
		// The checker permits an end that is reachable only when the result can be undefined
		// (or void). Put that exit in the IR so every backend and ownership pass sees it.
		returned := ir.Return{}
		if function.BodyReturns() != 0 {
			returned.Value = fit(ir.Undefined{}, function.BodyReturns())
		}
		lowered = append(lowered, returned)
	}
	// The environment may have grown while the body was lowered (captures are found as they're
	// read), so it's taken from what's recorded, not from this copy.
	function.Environment = l.result.Functions[index].Environment
	function.ForwardedNestedParent = l.result.Functions[index].ForwardedNestedParent
	function.ReferenceParents = l.result.Functions[index].ReferenceParents
	function.Body = append(function.Body, prologue...)
	function.Body = append(function.Body, lowered...)
	l.finishNestedEnvironment(&function, index)
	l.result.Functions[index] = function
	return l.checkGeneratorBody(index, declaration)
}

// Descriptor construction must not intern boundary-only literals into codegen's
// string table. The same builder runs against a private table and reports no errors.
func (l *lowering) boundarySchema(node *ast.Node, proven *checker.Type) *ir.JSONDecodeSchema {
	schema, err := l.jsonDecodeSchema(node, proven, jsonSchemaBoundary, l.result.BoundaryStrings.Intern)
	if err != nil {
		return nil
	}
	return &schema
}

// The binder marks a syntactic end even for a switch the checker proved exhaustive. Only the
// checker's result type can authorize returning undefined at that end.
func (l *lowering) permitsImplicitReturn(declaration *ast.Node) bool {
	result := l.checker.GetReturnTypeOfSignature(l.checker.GetSignatureFromDeclaration(declaration))
	if l.isLibraryType(result, "Promise") {
		arguments := l.checker.GetTypeArguments(result)
		if len(arguments) == 1 {
			result = arguments[0]
		}
	}
	if result.Flags()&checker.TypeFlagsUnion != 0 {
		for _, member := range result.Types() {
			if member.Flags() == checker.TypeFlagsVoid {
				return true
			}
		}
	}
	return result.Flags()&checker.TypeFlagsVoid != 0 || l.includesUndefined(result)
}

func (l *lowering) signature(index int, declaration *ast.Node, this int) error {
	return l.signatureReturn(index, declaration, this, nil)
}

func (l *lowering) latentSignatureReturnRaw(index int, declaration *ast.Node, this int, returns *checker.Type) error {
	return l.latentMainSignatureRaw(index, declaration, this)
}

func (l *lowering) signatureReturn(index int, declaration *ast.Node, this int, returns *checker.Type) error {
	return l.latentSpecSignatureReturn(index, declaration, this, returns)
}
