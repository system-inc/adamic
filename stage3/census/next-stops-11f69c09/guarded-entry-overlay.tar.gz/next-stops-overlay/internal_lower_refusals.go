package lower

import (
	"fmt"
	"strings"

	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/microsoft/TypeScript/tsc/shim/scanner"
)

type refusal struct {
	what string
	fix  string
}

var refusals = map[ast.Kind]refusal{
	ast.KindNonNullExpression: {"the non-null assertion !", "write ?? panic('why it can't be missing'), or narrow and handle the missing case"},
	ast.KindDecorator:         {"a decorator", "write the behavior where it applies; 0.1 doesn't rewrite classes at runtime"},
	ast.KindWithStatement:     {"with", "name the object you mean"},
	ast.KindExportAssignment:  {"export default", "export by name: one name for one thing"},
}

var refusedOperators = map[ast.Kind]refusal{
	ast.KindEqualsEqualsToken:      {"==", "use ===, which doesn't coerce"},
	ast.KindExclamationEqualsToken: {"!=", "use !==, which doesn't coerce"},
}

func (l *lowering) refuse(module *ast.SourceFile) error {
	l.notePlaceholderSlots()

	if len(module.CommentDirectives) > 0 {
		directive := module.CommentDirectives[0]
		name := "@ts-ignore"
		if directive.Kind == ast.CommentDirectiveKindExpectError {
			name = "@ts-expect-error"
		}
		line, column := scanner.GetLineAndCharacterOfPosition(module, directive.Loc.Pos())
		return &Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: name + " suppression directive", Fix: "remove it and fix the type error"}
	}

	for _, pragma := range module.Pragmas {
		if pragma.Name == "ts-nocheck" || pragma.Name == "ts-check" {
			line, column := scanner.GetLineAndCharacterOfPosition(module, pragma.Pos())
			return &Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: "@" + pragma.Name + " checking pragma", Fix: "remove it and fix any type errors"}
		}
	}

	if err := l.referenceRefusal(module); err != nil {
		return err
	}
	if err := l.parallelPreflight(module); err != nil {
		return err
	}
	if err := l.mergedFieldRulings(module); err != nil {
		return err
	}
	if err := l.functionAnnotations(module); err != nil {
		return err
	}

	if err := l.predicateFalseReads(module); err != nil {
		return err
	}

	var contractError error
	var contracts ast.Visitor
	contracts = func(node *ast.Node) bool {
		if contractError != nil {
			return true
		}
		if node.Kind == ast.KindCallExpression {
			contractError = l.predicateArguments(node)
		}
		if contractError == nil {
			node.ForEachChild(contracts)
		}
		return contractError != nil
	}
	module.AsNode().ForEachChild(contracts)
	if contractError != nil {
		return contractError
	}
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if found != nil {
			return true
		}
		if branch := l.literalCallableBranch(node); branch != nil {
			return visit(branch)
		}

		for _, rule := range refusalRules.rules {
			prune, err := rule.check(l, node)
			if err != nil {
				found = err
				return true
			}
			if prune {
				return false
			}
		}
		node.ForEachChild(visit)
		return false
	}
	l.refusal.deferred = nil
	module.AsNode().ForEachChild(visit)
	if found == nil {
		found = l.refusal.deferred
	}
	return found
}

func (l *lowering) refuseNode(root *ast.Node) error {
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if found != nil {
			return true
		}
		if branch := l.literalCallableBranch(node); branch != nil {
			return visit(branch)
		}

		for _, rule := range refusalRules.rules {
			prune, err := rule.check(l, node)
			if err != nil {
				found = err
				return true
			}
			if prune {
				return false
			}
		}
		node.ForEachChild(visit)
		return false
	}
	visit(root)
	return found
}

func (l *lowering) refuseInSlot(value *ast.Node, slot *checker.Type) error {
	if l.slots.explicit == nil {
		l.slots.explicit = map[*ast.Node]*checker.Type{}
	}
	previous, had := l.slots.explicit[value]
	l.slots.explicit[value] = slot
	defer func() {
		if had {
			l.slots.explicit[value] = previous
		} else {
			delete(l.slots.explicit, value)
		}
	}()
	var stop error
	var read ast.Visitor
	read = func(node *ast.Node) bool {
		_, carried, readable := l.carriedSlot(node)
		switch {
		case !carried:
		case node.Kind == ast.KindArrowFunction || node.Kind == ast.KindFunctionExpression || node.Kind == ast.KindClassExpression || node.Kind == ast.KindMethodDeclaration || node.Kind == ast.KindGetAccessor || node.Kind == ast.KindSetAccessor:
			stop = l.notYet(node, "a function written in place in a value written where the checker gives it no slot (lib types it any, so its parameters were typed any); bind it to a typed const first")
			return true
		case !readable && l.isExpression(node):
			stop = l.notYet(node, "a part of a value written where the checker gives it no slot, whose own slot can't be read off the one it's written into")
			return true
		}
		return node.ForEachChild(read)
	}
	if read(value) {
		return stop
	}
	deferred := l.refusal.deferred
	l.refusal.deferred = nil
	err := l.refuseNode(value)
	if err == nil {
		err = l.refusal.deferred
	}
	l.refusal.deferred = deferred
	return err
}

func (l *lowering) syntaxRefusal(node *ast.Node) error {

	if refused, isRefused := refusals[node.Kind]; isRefused && !(node.Kind == ast.KindIndexSignature && l.enumerationIndexSignature(node)) && (node.Kind != ast.KindNonNullExpression || !l.placeholderDeclaration(node) && !l.checkedAssertionSource(node)) {
		return &Refused{Where: l.program.Where(node), What: refused.what, Fix: refused.fix}
	}
	return nil
}

func init() { refusalRules.register(1400, "syntaxRefusal", (*lowering).syntaxRefusal) }

func (l *lowering) operatorRefusal(node *ast.Node) error {
	if node.Kind == ast.KindBinaryExpression {

		if refused, isRefused := refusedOperators[node.AsBinaryExpression().OperatorToken.Kind]; isRefused && !(node.AsBinaryExpression().OperatorToken.Kind == ast.KindInKeyword && l.recordElement(l.checker.GetTypeAtLocation(node.AsBinaryExpression().Right)) != nil) && !l.placeholderNullishTest(node) {
			return &Refused{Where: l.program.Where(node.AsBinaryExpression().OperatorToken), What: refused.what, Fix: refused.fix}
		}
	}
	return nil
}

func init() { refusalRules.register(2300, "operatorRefusal", (*lowering).operatorRefusal) }

func (l *lowering) asyncGeneratorRefusal(node *ast.Node) error {
	if asyncGenerator(node) {
		return &Refused{Where: l.program.Where(node), What: "an async generator function", Fix: "use synchronous iteration; async generators need a separate ownership and cancellation ruling"}
	}
	return nil
}

func init() { refusalRules.register(2400, "asyncGeneratorRefusal", (*lowering).asyncGeneratorRefusal) }

func (l *lowering) shorthandLibraryMethodGap(node *ast.Node) error {
	if node.Kind == ast.KindShorthandPropertyAssignment {
		if symbol := l.checker.GetShorthandAssignmentValueSymbol(node); symbol != nil && len(symbol.Declarations) == 1 && symbol.Declarations[0].Kind == ast.KindVariableDeclaration {
			if initializer := symbol.Declarations[0].AsVariableDeclaration().Initializer; initializer != nil {
				if _, known := l.libraryMethod(initializer, map[*ast.Symbol]bool{}); known {
					return l.notYet(node, "a library method value outside a const alias (an object field erases its receiver and callable ABI); use an arrow")
				}
			}
		}
	}
	return nil
}

func init() {
	refusalRules.register(2800, "shorthandLibraryMethodGap", (*lowering).shorthandLibraryMethodGap)
}

func (l *lowering) methodValueRefusal(node *ast.Node) error {
	if l.directBindMethodRead(node) {
		return nil
	}
	if node.Kind == ast.KindPropertyAccessExpression && !called(node) && !assertedCallee(node) && !l.libraryNumberBoundMethod(node) && !l.stringMethodObservation(node) && !l.libraryArrayObservedMethod(node) && !l.libraryMethodReadAllowed(node) && !l.detachedOwnMethod(node) && !l.nodeProcessMethodObservation(node) && !l.methodPresenceTest(node) {

		access := node.AsPropertyAccessExpression()
		if access.Name().Text() == "isPrototypeOf" && l.libraryMember(node) {
			return l.prototypeRead(node, "isPrototypeOf")
		}

		isRandom := l.isLibraryGlobal(access.Expression, "Math") && access.Name().Text() == "random"
		if symbol := l.checker.GetSymbolAtLocation(node); symbol != nil && symbol.Flags&ast.SymbolFlagsMethod != 0 && !isRandom {
			object := "its object"
			if ast.IsIdentifier(access.Expression) || access.Expression.Kind == ast.KindThisKeyword {
				object = scannedText(access.Expression)
			}
			parameters := "value"
			if signatures := l.checker.GetSignaturesOfType(l.checker.GetTypeOfSymbol(symbol), checker.SignatureKindCall); len(signatures) > 0 {
				names := []string{}
				for _, parameter := range signatures[0].Parameters() {
					names = append(names, parameter.Name)
				}
				parameters = strings.Join(names, ", ")
			}
			return &Refused{Where: l.program.Where(node), What: "a method read as a value (" + symbol.Name + " would lose its object, and this with it)", Fix: "call it in an arrow that keeps the object: (" + parameters + ") => " + object + "." + symbol.Name + "(" + parameters + ") (unbound-method)"}
		}
	}
	return nil
}

func init() { refusalRules.register(2900, "methodValueRefusal", (*lowering).methodValueRefusal) }

func called(node *ast.Node) bool {
	for node.Parent != nil && node.Parent.Kind == ast.KindParenthesizedExpression {
		node = node.Parent
	}
	return node.Parent != nil && node.Parent.Kind == ast.KindCallExpression && node.Parent.AsCallExpression().Expression == node
}

func assertedCallee(node *ast.Node) bool {
	for node.Parent != nil && node.Parent.Kind == ast.KindParenthesizedExpression {
		node = node.Parent
	}
	return node.Parent != nil && node.Parent.Kind == ast.KindNonNullExpression && called(node.Parent)
}

func scannedText(node *ast.Node) string {
	if node.Kind == ast.KindThisKeyword {
		return "this"
	}
	return node.Text()
}

func asyncGenerator(node *ast.Node) bool {
	if !ast.HasSyntacticModifier(node, ast.ModifierFlagsAsync) {
		return false
	}
	switch node.Kind {
	case ast.KindFunctionDeclaration:
		return node.AsFunctionDeclaration().AsteriskToken != nil
	case ast.KindFunctionExpression:
		return node.AsFunctionExpression().AsteriskToken != nil
	case ast.KindMethodDeclaration:
		return node.AsMethodDeclaration().AsteriskToken != nil
	}
	return false
}

func (l *lowering) dynamicImportGap(module *ast.SourceFile) error {
	if module.AsNode().Flags&ast.NodeFlagsPossiblyContainsDynamicImport == 0 {
		return nil
	}
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if node.Kind == ast.KindCallExpression && node.AsCallExpression().Expression.Kind == ast.KindImportKeyword {
			found = l.notYet(node, "a dynamic import()")
			return true
		}
		return node.ForEachChild(visit)
	}
	module.AsNode().ForEachChild(visit)
	return found
}
func (l *lowering) latentRefuse(module *ast.SourceFile) error {
	l.notePlaceholderSlots()
	for _, directive := range module.
		CommentDirectives {
		name := "@ts-ignore"
		if directive.Kind == ast.CommentDirectiveKindExpectError {
			name = "@ts-expect-error"
		}
		line, column := scanner.GetLineAndCharacterOfPosition(module, directive.Loc.Pos())
		latentRecord(&Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: name + " suppression directive", Fix: "remove it and fix the type error"})
	}

	for _, pragma := range module.Pragmas {
		if pragma.Name == "ts-nocheck" || pragma.Name == "ts-check" {
			line, column := scanner.GetLineAndCharacterOfPosition(module, pragma.Pos())
			latentRecord(&Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: "@" + pragma.Name + " checking pragma", Fix: "remove it and fix any type errors"})
		}
	}

	if err := l.referenceRefusal(module); err != nil {
		latentRecord(err)
	}
	if err := l.parallelPreflight(module); err != nil {
		latentRecord(err)
	}
	if err := l.mergedFieldRulings(module); err != nil {
		latentRecord(err)
	}
	if err := l.functionAnnotations(module); err != nil {
		latentRecord(err)
	}

	if err := l.predicateFalseReads(module); err != nil {
		latentRecord(err)
	}

	var contractError error
	var contracts ast.Visitor
	contracts = func(node *ast.Node) (latentStop bool) {
		latentProgressScan(node, "contract_scan")
		if latentFullEnabled() && node.Kind == ast.KindFunctionDeclaration {
			outerOwner := latentFindingOwner
			latentFindingOwner = l.program.Where(node)
			defer func() {
				latentFindingOwner = outerOwner
			}()
			if len(l.latentBodyDiagnostics(node.Body())) > 0 {
				latentNestedDeclarations(node.
					Body(), contracts)
				return false
			}
		} else {

			if node.Parent != nil && node.Parent.Kind == ast.KindSourceFile {
				latentFindingOwner = l.program.
					Where(node)
			}
			if node.Kind == ast.KindFunctionDeclaration && node.Parent !=
				nil && node.Parent.Kind == ast.KindSourceFile &&
				len(l.program.LatentDiagnosticsIn(node.Body())) > 0 {
				return false
			}
		}
		defer func() {
			latentRecordNode(contractError, node)
			contractError = nil
			node.ForEachChild(contracts)
			latentStop = false
		}()

		if contractError != nil {
			return true
		}
		if node.Kind == ast.KindCallExpression {
			contractError = l.predicateArguments(node)
		}
		if contractError == nil {

		}
		return contractError != nil
	}
	module.AsNode().ForEachChild(contracts)
	if contractError != nil {
		latentRecord(contractError)
	}
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) (latentStop bool) {
		latentProgressScan(node, "refusal_scan")
		if latentFullEnabled() && node.Kind == ast.KindFunctionDeclaration {
			outerOwner := latentFindingOwner
			latentFindingOwner = l.program.Where(node)
			defer func() {
				latentFindingOwner = outerOwner
			}()
			if len(l.latentBodyDiagnostics(node.Body())) > 0 {
				latentNestedDeclarations(node.
					Body(), visit)
				return false
			}
		} else {
			if node.
				Parent != nil && node.Parent.Kind == ast.KindSourceFile {
				latentFindingOwner = l.program.Where(node)
			}
			if node.Kind == ast.KindFunctionDeclaration && node.Parent !=
				nil && node.Parent.Kind == ast.KindSourceFile &&
				len(l.program.LatentDiagnosticsIn(node.Body())) > 0 {
				return false
			}
		}
		defer func() {
			latentRecordNode(found, node)
			found = nil
			node.ForEachChild(visit)
			latentStop = false
		}()

		if found != nil {
			return true
		}
		if branch := l.literalCallableBranch(node); branch != nil {
			return visit(branch)
		}

		for _, rule := range refusalRules.rules {
			prune, err := rule.check(l, node)
			if err != nil {
				found = err
				return true
			}
			if prune {
				return false
			}
		}

		return false
	}
	l.refusal.deferred = nil
	module.AsNode().ForEachChild(visit)
	latentRecord(found)
	return nil
}
