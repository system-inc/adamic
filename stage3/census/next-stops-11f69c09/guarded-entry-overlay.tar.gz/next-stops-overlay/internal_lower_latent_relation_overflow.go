// Compiled only through the measurement overlay. No checker-owned state is copied.
package lower

import (
	"context"
	"encoding/json"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/system-inc/adamic/internal/load"
	"os"
	"reflect"
	"time"
)

// Per-unit probing is opt-in after its cost measurement on checker.ts.
var latentRelationPerUnit bool

type LatentRelationReport struct {
	PerUnit           bool             `json:"per_unit"`
	AfterLoad         string           `json:"after_load"`
	End               string           `json:"end"`
	FirstAffectedUnit string           `json:"first_affected_unit,omitempty"`
	Attribution       string           `json:"attribution"`
	CacheSizes        map[string]int64 `json:"cache_sizes,omitempty"`
	Findings          []LatentFinding  `json:"-"`
}

// latentRelationCaches name the checker's relation caches by field, in load.RelationOverflowMarked's order.
var latentRelationCaches = []struct{ field, name string }{
	{"subtypeRelation", "subtype"}, {"strictSubtypeRelation", "strictSubtype"}, {"assignableRelation", "assignable"},
	{"comparableRelation", "comparable"}, {"identityRelation", "identity"},
}

// latentRelationCacheSizes is how many pairs each relation cache holds at the end of the run, the daily meter's
// relation budget (#ny0c3gb, #ferqs8v), and beside them two counts: flaggedPairs, the pairs across every cache
// marked as having spent their budget, and ts2859, the TS2859 diagnostics the checker holds. The caches and the
// diagnostics are unexported, so they're read by name as load.RelationOverflowMarked and load.RelationOverflow read
// them, and only read. Anything that isn't where it's expected is -1, which the meter reads as over budget, so it
// fails closed.
func latentRelationCacheSizes(ctx context.Context, program *load.Program) map[string]int64 {
	files := program.Files()
	if len(files) == 0 {
		return nil // No checker to read: the report has no sizes, which the meter reads as unknown.
	}
	typeChecker, release := program.Checker(ctx, files[0])
	defer release()
	sizes := map[string]int64{}
	value := reflect.ValueOf(typeChecker).Elem()
	flagged := int64(0)
	// size counts a cache's pairs and adds its flagged ones to flagged; a cache it can't read makes both -1.
	size := func(results reflect.Value) int64 {
		if !results.IsValid() || results.Kind() != reflect.Map {
			flagged = -1
			return -1
		}
		switch results.Type().Elem().Kind() {
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		default:
			flagged = -1
			return -1
		}
		for iterator := results.MapRange(); iterator.Next() && flagged >= 0; {
			if iterator.Value().Uint()&latentRelationOverflowMark != 0 {
				flagged++
			}
		}
		return int64(results.Len())
	}
	for _, cache := range latentRelationCaches {
		relation := value.FieldByName(cache.field)
		switch {
		case !relation.IsValid() || relation.Kind() != reflect.Pointer:
			sizes[cache.name] = -1
			flagged = -1
		case relation.IsNil():
			sizes[cache.name] = 0 // A relation the checker never made holds no pairs.
		default:
			sizes[cache.name] = size(relation.Elem().FieldByName("results"))
		}
	}
	sizes["enum"] = size(value.FieldByName("enumRelation"))
	sizes["flaggedPairs"] = flagged
	sizes["ts2859"] = -1
	if field := value.FieldByName("diagnostics"); field.IsValid() && field.Type() == reflect.TypeOf(ast.DiagnosticsCollection{}) {
		sizes["ts2859"] = 0
		for _, diagnostic := range (*ast.DiagnosticsCollection)(field.Addr().UnsafePointer()).GetDiagnostics() {
			if diagnostic.Code() == latentRelationOverflowCode {
				sizes["ts2859"]++
			}
		}
	}
	return sizes
}

// latentRelationOverflowMark and latentRelationOverflowCode are load's relationOverflowMark (relater.go:72's
// RelationComparisonResultComplexityOverflow) and relationOverflowCode (TS2859), which load keeps unexported.
const (
	latentRelationOverflowMark = 1 << 5
	latentRelationOverflowCode = 2859
)

func latentReadCheckedRelation(program *load.Program, typeChecker *checker.Checker, where string) string {
	started := time.Now()
	answer := program.RelationOverflow(typeChecker)
	elapsed := time.Since(started).Seconds()
	// Costs are observations in a separate stream, never nondeterministic findings.
	if path := os.Getenv("LATENT_RELATION_TIMES"); path != "" {
		output, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if err != nil {
			panic(err)
		}
		err = json.NewEncoder(output).Encode(map[string]any{"where": where, "wall_seconds": elapsed, "answer": answer})
		closeErr := output.Close()
		if err != nil {
			panic(err)
		}
		if closeErr != nil {
			panic(closeErr)
		}
	}
	return answer
}

func latentReadRelationOverflow(ctx context.Context, program *load.Program) string {
	files := program.Files()
	if len(files) == 0 {
		return ""
	}
	typeChecker, release := program.Checker(ctx, files[0])
	defer release()
	return latentReadCheckedRelation(program, typeChecker, "program")
}

func latentOverflowFinding(where, phase, answer string) LatentFinding {
	failure := &NotYet{Where: where, What: "a type relation the checker gave up on as too complex, whose answer lowering read (" + answer + ")"}
	return LatentFinding{Measurement: LatentMeasurementLabel, Unit: where, Phase: phase, Kind: "NotYet", Where: where, Reason: failure.What, Text: failure.Error()}
}

func latentRelationReport(ctx context.Context, program *load.Program) LatentRelationReport {
	report := LatentRelationReport{PerUnit: latentRelationPerUnit, AfterLoad: latentReadRelationOverflow(ctx, program), Attribution: "endpoints only; any overflow conservatively marks every attempted unit because its onset is unknown", Findings: []LatentFinding{}}
	if report.PerUnit {
		report.Attribution = "per attempted unit, checked after lowering; includes the unit that first exposes overflow"
	}
	return report
}

func latentCheckUnitRelation(program *load.Program, typeChecker *checker.Checker, unit *LatentUnit) {
	if !latentRelationPerUnit {
		return
	}
	answer := latentReadCheckedRelation(program, typeChecker, unit.Where)
	unit.RelationOverflow = &answer
	if answer != "" {
		finding := latentOverflowFinding(unit.Where, "relation_overflow", answer)
		finding.PieceAtom = latentPieceOrigin
		latentFindings = append(latentFindings, finding)
	}
}

// Complete attributes endpoint observations to the buffered census records.
func (report *LatentRelationReport) Complete(records []LatentFile) {
	answer := report.AfterLoad
	if answer == "" {
		answer = report.End
	}
	for _, record := range records {
		for _, unit := range record.Units {
			if unit.RelationOverflow != nil && *unit.RelationOverflow != "" {
				if answer == "" {
					answer = *unit.RelationOverflow
				}
				if report.FirstAffectedUnit == "" {
					report.FirstAffectedUnit = unit.Where
				}
			}
		}
	}
	if answer == "" {
		return
	}
	phase := "relation_overflow"
	// A final speculative file walk can query the checker outside a unit. If only
	// the endpoint sees it, its first unit is unknown: label every attempted unit.
	if report.AfterLoad == "" && report.FirstAffectedUnit == "" {
		report.Attribution = "overflow discovered only at run end; every attempted unit conservatively marked because the first affected unit is unknown"
		phase = "relation_overflow_conservative_all_units"
		for index := range records {
			for _, unit := range records[index].Units {
				if unit.Status == "attempted" || unit.Status == "panic" || unit.Status == "speculative" {
					records[index].Findings = append(records[index].Findings, latentOverflowFinding(unit.Where, phase, answer))
				}
			}
		}
	}
	if report.AfterLoad != "" && !report.PerUnit {
		report.Attribution = "overflow present after load; every attempted unit was lowered under an overflowed checker"
		for index := range records {
			for _, unit := range records[index].Units {
				if unit.Status == "attempted" || unit.Status == "panic" || unit.Status == "speculative" {
					if report.FirstAffectedUnit == "" {
						report.FirstAffectedUnit = unit.Where
					}
					finding := latentOverflowFinding(unit.Where, "relation_overflow", answer)
					if records[index].Piece != nil {
						finding.PieceAtom = "prepass"
					}
					records[index].Findings = append(records[index].Findings, finding)
				}
			}
		}
	}
	report.Findings = append(report.Findings, latentOverflowFinding("program", phase, answer))
}
