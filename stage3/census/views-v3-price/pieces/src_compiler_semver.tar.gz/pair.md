# Paired latent census

| Measure | Raw findings | Distinct reads |
| --- | ---: | ---: |
| Lowered (no remaining finding) | 0 | 0 |
| Moved by reason | 0 | 0 |
| New findings | 0 | 0 |
| New sites | 0 | 0 |
| Units whose first stop moved | 0 | 0 |
| Regressions | 0 | 0 |
| before Boundary | 13 | 11 |
| before NotYet | 10 | 10 |
| before Refused | 2 | 2 |
| after Boundary | 13 | 11 |
| after NotYet | 10 | 10 |
| after Refused | 2 | 2 |

| Reason | Raw before | Raw after | Reads before | Reads after | Reads lowered |
| --- | ---: | ---: | ---: | ---: | ---: |
| a case whose type differs from the switch's | 1 | 1 | 1 | 1 | 0 |
| a cast the runtime can't check | 1 | 1 | 1 | 1 | 0 |
| a constructor object escaping before static fields are initialized | 1 | 1 | 1 | 1 | 0 |
| a destructured name that isn't plain | 1 | 1 | 1 | 1 | 0 |
| a narrowed union member whose object tag cannot be checked with typeof; keep differently held object kinds in separately typed variables | 1 | 1 | 1 | 1 | 0 |
| a template interpolating an object, an array, a map, a function or undefined | 1 | 1 | 1 | 1 | 0 |
| a value of type T | 1 | 1 | 1 | 1 | 0 |
| a value of type never | 1 | 1 | 1 | 1 | 0 |
| checked predicate overload target Comparator[][] | 1 | 1 | 1 | 1 | 0 |
| checked predicate overload target never | 1 | 1 | 1 | 1 | 0 |
| checked predicate overload target { major: number; minor: number; patch: number; prerelease: string; build: string; } | 1 | 1 | 1 | 1 | 0 |
| failed statement; state rolled back; continued at next statement or declaration | 13 | 13 | 11 | 11 | 0 |
| reading major | 1 | 1 | 1 | 1 | 0 |

## Raw Findings

Moved by reason:


New findings:

None.

Units whose first stop moved:

None.

Panics: 0 before, 0 after.

## Distinct Reads

Moved by reason:


New findings:

None.

Units whose first stop moved:

None.

Panics: 0 before, 0 after.

The JSON retains every lowered site, move, new finding, unit stop and panic.
