# Paired latent census

| Measure | Raw findings | Distinct reads |
| --- | ---: | ---: |
| Lowered (no remaining finding) | 0 | 0 |
| Moved by reason | 0 | 0 |
| New findings | 0 | 0 |
| New sites | 0 | 0 |
| Units whose first stop moved | 0 | 0 |
| Regressions | 0 | 0 |
| before Boundary | 1 | 1 |
| before NotYet | 1 | 1 |
| before Refused | 2 | 2 |
| after Boundary | 1 | 1 |
| after NotYet | 1 | 1 |
| after Refused | 2 | 2 |

| Reason | Raw before | Raw after | Reads before | Reads after | Reads lowered |
| --- | ---: | ---: | ---: | ---: | ---: |
| a literal method through a view that erases its receiver | 1 | 1 | 1 | 1 | 0 |
| a method read as a value (setBlocking would lose its object, and this with it) | 1 | 1 | 1 | 1 | 0 |
| a method read as a value (tryEnableSourceMapsForHost would lose its object, and this with it) | 1 | 1 | 1 | 1 | 0 |
| failed statement; state rolled back; continued at next statement or declaration | 1 | 1 | 1 | 1 | 0 |

## Raw Findings

Moved by reason:


New findings:

None.

Units whose first stop moved:

None.

Panics: 0 before, 0 after.

## Distinct Reads

Moved by reason:


New findings:

None.

Units whose first stop moved:

None.

Panics: 0 before, 0 after.

The JSON retains every lowered site, move, new finding, unit stop and panic.
