/** @internal */
export function filterNarrowed<T, U extends T>(array: readonly T[], f: (x: T) => x is U): U[] {
    const result: U[] = [];
    for (const value of array) {
        if (f(value)) {
            result.push(value);
        }
    }
    return result;
}
/** @internal */
export function filterNarrowedOptional<T, U extends T>(array: readonly T[] | undefined, f: (x: T) => x is U): U[] | undefined {
    if (array === undefined) return undefined;
    const result: U[] = [];
    for (const value of array) {
        if (f(value)) {
            result.push(value);
        }
    }
    return result;
}
const values: (string | null | undefined)[] = ["keep", null, undefined];
export const first = filterNarrowed(values, v => v !== undefined);
export const second = filterNarrowedOptional(values, v => v !== undefined);
export const third = filterNarrowedOptional<string | null | undefined, string | null>(undefined, v => v !== undefined);
