import json,os,signal,time
from pathlib import Path
s=Path('/workspace/scratch/elementat-declaration');out=Path('/workspace/adamic/stage3/census/elementat-declaration');pid=13631
summary=json.loads((out/'lane-summary.json').read_text());nextPiece=len(summary['pieces'])+1
while not (out/f'lane-{nextPiece:02d}.sha256').exists():
 if not Path('/proc/'+str(pid)).exists():raise SystemExit('runner exited before boundary')
 time.sleep(.01)
os.kill(pid,signal.SIGSTOP)
children=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  a=(p/'stat').read_text().split()
  if int(a[3])==pid:children.append(int(p.name))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
if children:
 os.kill(pid,signal.SIGCONT);raise SystemExit('did not stop at a clean boundary: '+str(children))
os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
(s/'namespace-coverage-restart.json').write_text(json.dumps({'reason':'namespace audit found three namespace escapes; add export-getter read coverage before accepting a full inventory','stoppedAtCompletedPiece':nextPiece,'runner':pid,'liveChildrenAtStop':children,'completedPiecesRetainedAsPreliminary':True},indent=2)+'\n')
print('stopped preliminary lane at clean completed piece '+str(nextPiece),flush=True)
