# Extend only our initial supervisor's short total bound while retaining its waitpid status.
# The child itself is unmodified. A separate 30-minute silence bound remains enforced.
import os,signal,time,json
from pathlib import Path
s=Path('/workspace/scratch/elementat-declaration');supervisor=2065;child=2091;paused=False;start=time.monotonic();previous=None;last=start
try:
 while Path('/proc/'+str(child)).exists():
  state=Path('/proc/'+str(child)+'/stat').read_text().split()[2]
  if state=='Z':break
  log=s/'apply.log';signature=(log.stat().st_size,log.stat().st_mtime_ns)
  now=time.monotonic()
  if signature!=previous:previous=signature;last=now
  # Child elapsed comes from proc uptime, independent of local watcher start.
  ticks=os.sysconf(os.sysconf_names['SC_CLK_TCK']);born=float(Path('/proc/'+str(child)+'/stat').read_text().split()[21])/ticks;uptime=float(Path('/proc/uptime').read_text().split()[0]);elapsed=uptime-born
  if elapsed>1300 and not paused:
   os.kill(supervisor,signal.SIGSTOP);paused=True
   (s/'apply-supervision-extension.json').write_text(json.dumps({'reason':'full apply is progressing; extend initial 1400-second total bound','supervisor':supervisor,'child':child,'silenceLimit':1800,'totalLimit':3600})+'\n')
  if now-last>1800 or elapsed>3600:
   os.killpg(child,signal.SIGKILL)
   (s/'apply-external-stop.json').write_text(json.dumps({'reason':'30 minutes without log progress' if now-last>1800 else 'one-hour full apply bound','child':child})+'\n');break
  time.sleep(1)
finally:
 if paused:
  try:os.kill(supervisor,signal.SIGCONT)
  except ProcessLookupError:pass
print('apply child supervision finished; original supervisor retains child exit code',flush=True)
