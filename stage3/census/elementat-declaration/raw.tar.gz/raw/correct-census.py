import sys,time,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/elementat-declaration')
from run import run
s=Path('/workspace/scratch/elementat-declaration')
while not any(json.loads(l)['name']=='build-latent' for l in (s/'commands.jsonl').read_text().splitlines()):time.sleep(1)
r=run('build-core-latent',['go','build','-overlay',str(s/'latent-overlay/overlay.json'),'-o',str(s/'bin/core-latent'),'./stage3/census/latent/tool']);assert r['exit']==0,r
# The first preparation built the entry driver, whose input is a file. P3 uses the directory driver.
code=Path('/workspace/adamic/stage3/census/elementat-declaration/census.py').read_text().replace("'build-latent'","'build-core-latent'").replace("s/'bin/latent'","s/'bin/core-latent'").replace("'census-'", "'core-census-'")
exec(compile(code,'correct-core-census','exec'),{'__name__':'__main__'})
