import sys,os,time
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/elementat-declaration')
from run import run
s=Path('/workspace/scratch/elementat-declaration')
while not (s/'commands.jsonl').exists() or not any('"name": "source-checkout"' in l for l in (s/'commands.jsonl').read_text().splitlines()):time.sleep(1)
import json
r=[json.loads(l) for l in (s/'commands.jsonl').read_text().splitlines() if '"name": "source-checkout"' in l][-1]
assert r['exit']==0,r
os.environ['ADAMIC_TYPESCRIPT_SOURCE']='/workspace/typescript-source'
r=run('apply',['bash','stage3/apply.sh','--build-product',str(s/'baseline')]);assert r['exit']==0,r
r=run('checkpoint-push',['git','push','origin','HEAD:refs/heads/typescript/elementat-declaration']);assert r['exit']==0,r
