const ts=require('/workspace/scratch/ax97-counted/built/local/typescript.js');
const values=[new Error('sentinel'),'sentinel',17,null,undefined,{}, {message:17}];
for(const value of values){
 ts.sys.readFile=()=>{throw value};
 ts.sys.writeFile=()=>{throw value};
 ts.sys.directoryExists=()=>true;
 const host=ts.createCompilerHost({});
 try{host.getSourceFile('sentinel.ts',ts.ScriptTarget.Latest,()=>{});}catch{}
 try{host.writeFile('sentinel.js','',false,()=>{});}catch{}
}
