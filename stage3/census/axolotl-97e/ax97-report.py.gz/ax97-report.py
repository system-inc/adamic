import pathlib,json,re,gzip,hashlib,collections,subprocess
S=pathlib.Path('/workspace/scratch');R=pathlib.Path('/workspace/adamic');out=R/'stage3/census/axolotl-97e';out.mkdir(parents=True,exist_ok=True)
cmds=json.loads((S/'ax97-commands.json').read_text())
text='# axochk: two onError measurements\n\n'
text+='Main tip and branch base: `80c2d3282e44b527555d59690bb413cc883d2bf2`. Branch: `typescript/axolotl-97e-measure`. Upstream TypeScript v6.0.3: `050880ce59e30b356b686bd3144efe24f875ebc8`. Only this census directory is delivered. No adaptation is written.\n\n'
text+='Setup used `GOPROXY=https://proxy.golang.org|direct` and `timeout --kill-after=60s 1800 bash cloud/setup.sh > /workspace/scratch/setup.log 2>&1`. A preliminary scratch apply overlapped the submodule fetch; the measured tree was restored afresh with stage3/apply.sh after setup succeeded. Upstream builds and oracle attempts ran serially after setup; all output went to files.\n\n'
text+='## Measurement (a)\n\nOnly WriteFileCallback.onError (types.ts:4584) and CompilerHost.getSourceFile.onError (types.ts:8142) change from `(message: string) => void` to `(message: unknown) => void`. The function-type syntax is retained. getSourceFileByPath is unchanged. `ax97-widen.diff.gz` retains the exact source change.\n\n'
text+='Upstream locks its build compiler to 5.9.3. The widened scratch package and lockfile pin stock TypeScript 6.0.3 so npm run build and the oracle build use 6.0.3. A matched unmodified control uses the same installed compiler. No tsconfig options are changed. build:tests runs explicitly as well, because npm run build short-circuits if build:compiler fails. Every requested tsc -p runs regardless of prior exits.\n\n'
text+='| Check | Control exit | Widened exit |\n| --- | ---: | ---: |\n'
by={c['name']:c for c in cmds}
for label,control,after in [('npm run build','control-build','a-build'),('npm run build:tests',None,'a-build-tests')]+[(f'tsc -p src/{p}','control-tsc-'+p,'a-tsc-'+p) for p in ['compiler','services','server','harness','testRunner']]:
 text+=f"| {label} | {by[control]['exit'] if control else 'included in control build'} | {by[after]['exit']} |\n"
def diagnostics(name):
 s=(S/('ax97-'+name+'.log')).read_text(errors='replace');s=re.sub(r'\x1b\[[0-9;]*m','',s)
 lines=s.splitlines();result=[];current=[]
 for line in lines:
  if re.search(r'error TS\d+:',line):
   if current:result.append('\n'.join(current))
   current=[line]
  elif current and line.startswith(' '):current.append(line)
  elif current: result.append('\n'.join(current));current=[]
 if current:result.append('\n'.join(current))
 return [re.sub(r'^(\S+):(\d+):(\d+) - error ', r'\1:\2:\3: error ', re.sub(r'^(\S+)\((\d+),(\d+)\): error ', r'\1:\2:\3: error ', d)) for d in result]
control=set(diagnostics('control-build'))
for p in ['compiler','services','server','harness','testRunner']:control.update(diagnostics('control-tsc-'+p))
new={}
for n in ['a-build','a-build-tests']+['a-tsc-'+p for p in ['compiler','services','server','harness','testRunner']]:
 for d in diagnostics(n):
  if d not in control:new.setdefault(d,[]).append(n)
text+=f'\nNew unique diagnostics relative to the matched control: **{len(new)}**. Full continuation messages and project occurrences follow.\n\n'
for d,names in new.items():text+='```text\n'+re.sub(r'([^\s]+\.tsx?)\((\d+),(\d+)\)',r'\1:\2:\3',d)+'\n```\n\nSeen in: '+', '.join(names)+'.\n\n'
if not new:text+='None.\n\n'
for label in ['a','b']:
 p=S/('ax97-oracle-'+label)/'report.json'
 if p.exists():
  rep=json.loads(p.read_text())
  if label=='a':
   text+='Oracle command: `bash stage3/oracle/run.sh /workspace/scratch/ax97-widened /workspace/scratch/ax97-oracle-a --workers 4 --limit-seconds 1800`.\n\n'
   if 'counts' in rep:text+='Full oracle counts: '+json.dumps(rep['counts'])+'. Baselines moving besides api/typescript.d.ts: '+(', '.join(x for x in rep.get('baseline_diffs',[]) if x!='api/typescript.d.ts') or 'none')+'.\n\n'
   else:text+='**Stopped at the oracle build gate. The full suite did not run. Moved baselines are unmeasured, not zero.** Oracle phases: '+json.dumps(rep['phases'])+'. The widening is not buildable under the requested checks; no workaround or typecheck bypass was introduced.\n\n'
text+='## Measurement (b): runtime\n\nThe counted copy starts from the original adapted tree, without widening. It keeps upstream\'s lockfile and uses the full oracle procedure from adaptation 91: all runners, no filter, four workers, 1,800-second suite limit. The two temporary counters run at entry to each catch, before the onError guard. The preload records typeof e, typeof e?.message, process ID, stack and active Mocha runnable. Observation files from every process are retained, including preload activation records.\n\n'
rep=json.loads((S/'ax97-oracle-b/report.json').read_text());text+='Oracle counts: '+json.dumps(rep.get('counts',{}))+'. Phase exits: '+json.dumps({n:v['exit'] for n,v in rep['phases'].items()})+'. Baselines moving besides api/typescript.d.ts: '+(', '.join(x for x in rep.get('baseline_diffs',[]) if x!='api/typescript.d.ts') or ('none' if 'counts' in rep else 'unmeasured'))+'.\n\n'
rows=[]
for p in sorted((S/'ax97-observations').glob('*.jsonl')):
 rows.extend(json.loads(l) for l in p.read_text().splitlines())
with (S/'ax97-observations.jsonl').open('w') as f:
 for r in rows:f.write(json.dumps(r)+'\n')
caught=[r for r in rows if r['event']=='caught'];counts=collections.Counter((r['site'],r['type'],r['messageType']) for r in caught)
summary={site:{'total':sum(v for (s,t,m),v in counts.items() if s==site),'pairs':{t+','+m:v for (s,t,m),v in counts.items() if s==site}} for site in ['read-406','write-441']}
(S/'ax97-counts.json').write_text(json.dumps(summary,indent=2)+'\n')
text+='| Site (original adapted line) | typeof e | typeof e?.message | Count |\n| --- | --- | --- | ---: |\n'
for site in ['read-406','write-441']:
 pairs=[(t,m,v) for (s,t,m),v in sorted(counts.items()) if s==site]
 if not pairs:text+=f'| {site} | no caught value | no caught value | 0 |\n'
 for t,m,v in pairs:text+=f'| {site} | {t} | {m} | {v} |\n'
text+='\nTotals: '+json.dumps({s:v['total'] for s,v in summary.items()})+'. Every unlisted pair has count zero.\n\n'
nonstring=[r for r in caught if r['messageType']!='string']
if nonstring:
 text+='Non-string-message catches and producing tests:\n\n'
 for r in nonstring:text+='- '+r['site']+': '+r['type']+'/'+r['messageType']+'; '+str(r['test'])+'\n'
else:text+='There were zero caught values with non-string messages in this run. Neither catch was exercised. This does not show that caught values were all Error objects. No producing test exists for a nonzero non-string pair.\n'
text+='\nThe isolated smoke check uses the actual built compiler and the same observer, with a separate output directory excluded from suite counts. It drives each catch with Error, string, number, null, undefined, {}, and {message:17}. Both sites recorded exactly seven smoke catches: (object,string) 1, (string,undefined) 1, (number,undefined) 1, (object,undefined) 2, (undefined,undefined) 1 and (object,number) 1. Raw smoke observations and summary are retained.\n\n'
text+=(S/'ax97-static-review.md').read_text()+'\n'
text+='## Raw evidence and reproduction\n\nAll raw outputs are gzip files beside this report. ax97-commands.json.gz records each preparation, build, project check and oracle attempt with cwd, exit and elapsed seconds. ax97-measure.py.gz reproduces their serial order. ax97-inventory.cjs.gz, ax97-host-inventory.json.gz, ax97-throws.json.gz and occurrence logs preserve the static review inputs. ax97-observe.cjs.gz and ax97-instrument.diff.gz describe the temporary counters. setup.log.gz is the complete required setup output. Oracle report, build, tests and baseline outputs retain their full original bytes.\n'
# Save raw evidence, including scripts. Nested paths are flattened with explicit prefixes.
files=[(p,p.name) for p in S.glob('ax97-*') if p.is_file() and p.name!='ax97-report-summary.log']+[(S/'setup.log','setup.log'),(S/'fetch.log','fetch.log')]
for label in ['a','b']:
 base=S/('ax97-oracle-'+label)
 for p in base.rglob('*'):
  if p.is_file():files.append((p,'oracle-'+label+'-'+str(p.relative_to(base)).replace('/','--')))
for p in (S/'ax97-smoke-observations').glob('*.jsonl'):files.append((p,'smoke-'+p.name))
manifest=[]
for p,name in files:
 data=p.read_bytes();target=out/(name+'.gz');target.write_bytes(gzip.compress(data,mtime=0));manifest.append(dict(file=target.name,raw_bytes=len(data),raw_sha256=hashlib.sha256(data).hexdigest()))
(out/'MANIFEST.json.gz').write_bytes(gzip.compress((json.dumps(manifest,indent=2)+'\n').encode(),mtime=0))
assert '\u2014' not in text and '\u2013' not in text
(out/'REPORT.md').write_text(text)
print(json.dumps({'diagnostics':len(new),'counts':summary,'files':len(manifest)},indent=2))
