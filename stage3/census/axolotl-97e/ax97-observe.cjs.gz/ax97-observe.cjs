const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const out=process.env.AX97_OBSERVATIONS;
if(out){
 let current=null;
 const write=row=>fs.appendFileSync(path.join(out,process.pid+'.jsonl'),JSON.stringify({pid:process.pid,...row})+'\n');
 write({event:'loaded',argv:process.argv});
 globalThis.__ax97Catch=(site,e)=>write({event:'caught',site,type:typeof e,messageType:typeof e?.message,test:current,stack:new Error().stack});
 try {
 const Mocha=createRequire(path.join(process.cwd(),'package.json'))('mocha');
 const original=Mocha.Runnable.prototype.run;
 Mocha.Runnable.prototype.run=function(...args){current=this.fullTitle();return Reflect.apply(original,this,args);};
 write({event:'mocha-hooked'});
 }catch(e){write({event:'mocha-unavailable',message:e.message});}
}
