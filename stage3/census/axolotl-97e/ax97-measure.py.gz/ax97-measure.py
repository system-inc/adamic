import pathlib,subprocess,json,time,os,shutil,difflib
S=pathlib.Path('/workspace/scratch'); R=pathlib.Path('/workspace/adamic'); C=S/'ax97-final-control'; A=S/'ax97-widened'; B=S/'ax97-counted'
assert 'setup: done on' in (S/'setup.log').read_text(), 'setup did not finish successfully'
commands=[]
def run(name,cmd,cwd=R,env=None,limit=2400):
 t=time.monotonic()
 with (S/('ax97-'+name+'.log')).open('w') as f:
  try: code=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired: code=124
 commands.append(dict(name=name,command=cmd,cwd=str(cwd),exit=code,seconds=time.monotonic()-t))
 (S/'ax97-commands.json').write_text(json.dumps(commands,indent=2)+'\n');return code
assert run('final-apply',['bash','stage3/apply.sh',str(C)],env=dict(os.environ,ADAMIC_TYPESCRIPT_SOURCE=str(S/'ax97-upstream')),limit=900)==0
assert (C/'patch-set.md').exists()
for target in [A,B]: shutil.copytree(C,target,ignore=shutil.ignore_patterns('.git'))
p=A/'src/compiler/types.ts';a=p.read_bytes(); lines=a.splitlines(keepends=True);changes=0
for i,line in enumerate(lines):
 if b'onError?: (message: string) => void' in line and (line.lstrip().startswith(b'onError?') or line.lstrip().startswith(b'getSourceFile(')):
  lines[i]=line.replace(b'onError?: (message: string) => void',b'onError?: (message: unknown) => void');changes+=1
assert changes==2
p.write_bytes(b''.join(lines));(S/'ax97-widen.diff').write_text(''.join(difflib.unified_diff(a.decode().splitlines(True),p.read_bytes().decode().splitlines(True),fromfile='control/types.ts',tofile='widened/types.ts')))
# A scratch dependency pin makes upstream's npm scripts and the full oracle build use stock 6.0.3.
assert run('a-pin',['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund','--save-dev','--save-exact','typescript@6.0.3'],A,limit=300)==0
assert run('a-install',['npm','ci','--no-audit','--no-fund'],A,limit=300)==0
run('a-build',['npm','run','build'],A,limit=600)
run('a-build-tests',['npm','run','build:tests'],A,limit=600)
os.symlink(A/'node_modules',C/'node_modules',target_is_directory=True)
run('control-build',['npm','run','build'],C,limit=600)
# Run every requested project regardless of earlier compiler exit.
for project in ['compiler','services','server','harness','testRunner']:
 run('control-tsc-'+project,['node',str(A/'node_modules/typescript/lib/tsc.js'),'-p','src/'+project],C,limit=600)
 run('a-tsc-'+project,['node',str(A/'node_modules/typescript/lib/tsc.js'),'-p','src/'+project],A,limit=600)
run('memory-before-a',['free','-m'])
run('a-oracle',['bash','stage3/oracle/run.sh',str(A),str(S/'ax97-oracle-a'),'--workers','4','--limit-seconds','1800'])
# Instrument BEFORE onError guards, so every catch is counted even with no callback.
p=B/'src/compiler/program.ts';a=p.read_bytes();needle=b'catch (e) {\r\n            if (onError) {';assert a.count(needle)==2
for site in ['read-406','write-441']:
 replacement=b'catch (e) {\r\n            (globalThis as any).__ax97Catch("'+site.encode()+b'", e);\r\n            if (onError) {'
 a=a.replace(needle,replacement,1)
p.write_bytes(a)
(S/'ax97-instrument.diff').write_text(''.join(difflib.unified_diff((C/'src/compiler/program.ts').read_text().splitlines(True),p.read_text().splitlines(True),fromfile='control/program.ts',tofile='counted/program.ts')))
observations=S/'ax97-observations';observations.mkdir()
env=dict(os.environ,AX97_OBSERVATIONS=str(observations),NODE_OPTIONS=os.environ.get('NODE_OPTIONS','')+' --require=/workspace/scratch/ax97-observe.cjs')
run('memory-before-b',['free','-m'])
run('b-oracle',['bash','stage3/oracle/run.sh',str(B),str(S/'ax97-oracle-b'),'--workers','4','--limit-seconds','1800'],env=env)
print('finished')
