from pathlib import Path
import json,re
w=Path('/workspace/scratch/ev19main');repo=Path('/workspace/enum-views-19-main');debug=[json.loads(x) for x in (w/'debug-latent.jsonl').read_text().splitlines()][1];emitter=json.loads((w/'emitter-unit.json').read_text());old={r['rule']:r for r in json.loads((w/'reference-b2-unit-results.json').read_text())};locations=json.loads((w/'site-locations.json').read_text());rows=[]
for site in locations:
 record=debug if site['id']!=91 else emitter;unit=next(u for u in record['units'] if u.get('name')==site['after']['owner']);all_findings=[f for f in record['findings'] if f['phase']=='lowering' and f['unit']==unit['where']];stops=[f for f in all_findings if f['kind'] in ['Refused','NotYet','panic','SkippedDependency']]
 rows.append({'rule':site['id'],'key':site['key'],'site':site['after'],'earlier_main':old[site['id']]['main'],'casts_alone':old[site['id']]['adaptation_only'],'b2_first_stop':old[site['id']]['b2_unit_first_stop'],'main_unit':unit,'main_lowering_findings':all_findings,'main_first_stop':stops[0] if stops else None,'isolated_unit_completed_without_findings':unit['status']=='attempted' and not all_findings})
assert sum(r['isolated_unit_completed_without_findings'] for r in rows)==17
helpers=[]
for name in ['formatEnum','getEnumMembers']:
 unit=next(u for u in debug['units'] if u.get('name')==name);fs=[f for f in debug['findings'] if f['phase']=='lowering' and f['unit']==unit['where']];helpers.append({'name':name,'unit':unit,'findings':fs})
(w/'unit-results.json').write_text(json.dumps(rows,indent=2)+'\n');(w/'helper-results.json').write_text(json.dumps(helpers,indent=2)+'\n')
origins=[('K1','debug.ts:412:27','internal/lower/reflect_get.go',111,'checkDynamicKeyedGetterSyntax','readonly runtime-key read encounters the program-wide class-getter syntax guard'),('K2','debug.ts:413:24','internal/lower/expression.go',660,'enumNeverValue','reading value after the failed initializer was rolled back'),('K3','core.ts:1049:82','internal/lower/object.go',2065,'arraySort','comparator is not held as a closure with one call signature'),('U1','debug.ts:496:15','internal/lower/unknown.go',46,'inProperty','in narrows multiple object members'),('U2','emitter.ts:5769:30','internal/lower/expression.go',53,'typeOf','representation of the EmitNode intersection union is not known'),('U3','emitter.ts:5770:48,5771:48,5772:17,5790:84','internal/lower/expression.go',660,'enumNeverValue','reading autoGenerate after its initializer was rolled back'),('O1','core.ts:1326:26','internal/lower/cast_proof.go',188,'castProof','uncheckable-cast diagnostic construction, propagated through castRefusal')]
records=[];excerpts=[]
for code,where,file,line,function,reason in origins:
 source=(repo/file).read_text().splitlines();assert 'notYet' in source[line-1] or 'Refused' in source[line-1]
 start=max(i for i in range(line) if source[i].startswith('func '));assert function+'(' in source[start]
 records.append({'id':code,'source':where,'lowering_file':file,'lowering_line':line,'lowering_function':function,'function_start':start+1,'emitting_line':source[line-1],'explanation':reason,'origin_method':'unique source emitter; trace confirmation follows separately'})
 excerpts+=['// '+file+':'+str(line)+' '+function,'// '+source[start],*source[max(start,line-8):min(len(source),line+5)],'']
(w/'stop-origins.json').write_text(json.dumps(records,indent=2)+'\n');(w/'lowering-guards.go.txt').write_text('\n'.join(excerpts))
report=repo/'stage3/census/enum-views-19-main/REPORT.md';s=report.read_text();s=s.replace('The exact frozen SHA is recorded in 01-setup.tar.gz/provenance.json and will be\nused in the completed result below.','The exact frozen SHA and tool hashes are recorded in 01-setup.tar.gz/provenance.json.')
s=s[:s.index('The target\'s full apply is running.')]+'''The target's full apply passes. The full debug.ts census and the emitter replay
have completed and are packed in 02-latent-units.tar.gz. The ordinary 79-root
comparison and source-emitter trace confirmations are still running.

## Nineteen-site comparison

The 17 formatter units now finish their isolated lowering attempts with zero
lowering findings. This corrects the Map-at-399 prediction for this method:
they do not stop at the Map. formatEnum's own isolated unit also has no findings.
This is not a whole-program/native acceptance claim: the unit driver registers
callee signatures independently and does not close over all callee bodies and
global initializers as one production program.

R0 below is the earlier main cast scan Refused at invariance.go:673. N0 is the
casts-only namespace-value scan NotYet at module_namespace.go:27. N1 is B2's
unit NotYet, "an enum read through its namespace without a lowered binding".
L means attempted isolated unit completed with no lowering findings.

| Rule | Owner / enum | Earlier main | Casts alone | B2 at 9bdbe75e | Main now |
| --- | --- | --- | --- | --- | --- |
'''
for r in rows:
 b=r['b2_first_stop'];new=r['main_first_stop'];b_label='N1' if b and 'without a lowered binding' in b['reason'] else b['kind']+' at '+b['where'].split('/src/compiler/')[-1] if b else 'no stop';label='L' if r['isolated_unit_completed_without_findings'] else new['kind']+' at '+new['where'].split('/src/compiler/')[-1]
 s+=f"| {r['rule']} | {r['site']['owner']} / {r['key']} | R0 | N0 | {b_label} | {label} |\n"
s+='''
Rule 89 still stops earlier at debug.ts:496:15 (U1), before its getter cast at
519:56. Rule 91 still stops first at emitter.ts:5769:30 (U2), before its cast at
5790:141. Its subsequent autoGenerate reads remain recovery findings (U3).
The emitter replay exits 1 because the deliberately requested old namespace
signature no longer reproduces; it still returns the complete makeName unit.
Every actual finding is retained, including rollback boundaries.

## The shared helper and the Map prediction

getEnumMembers now reaches the runtime-key read `enumObject[name]` at
**debug.ts:412:27**, then stops at K1, the class-getter syntax guard. It does not
report a Map constructor stop at debug.ts:399 in this measurement. The Map is a
namespace-level initializer and is not a separate function unit in this census;
absence of a constructor finding does not prove whole-program initialization.

The full debug record contains no diagnostic at line 399. After rollback, the
same helper unit records K2, `reading value` at 413:24, and K3, `a comparator
that isn't a function` at core.ts:1049:82 during toSorted's generic body. These
are later recovery findings, not replacements for K1 as its first stop. The
corresponding source expressions are `typeof value` and `array.slice().sort(comparer)`.

## Exact source and lowering emitters

The following locations are on the frozen main. Source snippets and Go guard
excerpts are packed in the raw evidence. Refused/NotYet is preserved, rather
than describing every stop as a type-system refusal.

| ID | Source stop | Lowering file:line | Lowering function | Meaning |
| --- | --- | --- | --- | --- |
'''
for r in records:s+=f"| {r['id']} | `{r['source']}` | `{r['lowering_file']}:{r['lowering_line']}` | `{r['lowering_function']}` | {r['explanation']} |\n"
s+='''
K1 is called by `viewKeyedRead` at element_access_fields.go:134; its emitting
return is reflect_get.go:111 in checkDynamicKeyedGetterSyntax. The diagnostic
prefix is named by dynamicKeyedRead, and the syntax reason by dynamicKeyedGetterBody.
The program-wide guard can reject a view read because another module class has
a getter whose effects would be hidden inside that read. It is not a Map-key
storage diagnostic. O1 is the newly exposed ordinary core cast observed so far;
the complete per-root comparison will follow.

All raw records are packed in numbered tar.gz archives. SHA256SUMS hashes the
archives, and every archive has an inner raw-file SHA256SUMS. Runs are bounded
below 25 minutes and pieces are committed and plainly pushed as completed.
'''
report.write_text(s)
