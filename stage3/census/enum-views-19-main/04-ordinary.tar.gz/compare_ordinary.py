from pathlib import Path
import json,collections
w=Path('/workspace/scratch/ev19main');records={}
for label,file,root in [('before','reference-main-ordinary.jsonl','/workspace/scratch/ro-before/'),('now','ordinary.jsonl','/workspace/scratch/ev19main/applied/')]:
 rows=[json.loads(line) for line in (w/file).read_text().splitlines()];selected=[r for r in rows if len(r['roots'])==1 and r['roots'][0].endswith('.ts')];assert len(selected)==79
 def norm(v):
  if isinstance(v,str):return v.replace(root,'')
  if isinstance(v,list):return [norm(x) for x in v]
  if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k!='seconds'}
  return v
 records[label]={norm(r['roots'][0]):norm(r) for r in selected}
assert records['before'].keys()==records['now'].keys()
changes=[{'root':root,'before':a,'now':records['now'][root]} for root,a in records['before'].items() if a!=records['now'][root]]
result={'baseline':'63e14a0b2b61cf251ad74292e42d5fd09af804b3','target':(w/'target.sha').read_text().strip(),'roots_each':79,'normalization':'remove tree prefix from all embedded strings; omit seconds only','kinds':{label:dict(collections.Counter(r['kind'] for r in rows.values())) for label,rows in records.items()},'changed_first_stops':changes,'records':records}
assert len(changes)==73
assert {(r['now']['kind'],r['now'].get('where'),r['now'].get('reason')) for r in changes}=={('Refused','src/compiler/core.ts:1326:26',"a cast the runtime can't check")}
(w/'ordinary-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
p=Path('/workspace/enum-views-19-main/stage3/census/enum-views-19-main/REPORT.md');s=p.read_text();s=s.replace('# Nineteen enum-view sites on main after Lower\'s binding fix\n','# Nineteen enum-view sites on main after Lower\'s binding fix\n\n**Result:** 17 formatter units now complete isolated lowering with no findings.\nThe getter-owner and emitter-owner units retain their earlier stops. The shared\ngetEnumMembers unit first stops at debug.ts:412:27, the class-getter guard, not\nat the Map at line 399. In the ordinary census, 73 first stops move to\ncore.ts:1326:26; outcome counts remain 73 Refused, 4 NotYet and 2 accepted.\n',1)
s=s.replace('comparison is still running. Source-emitter trace confirmations are complete','comparison is complete in 04-ordinary.tar.gz. Source-emitter trace confirmations are complete')
s=s.replace('the complete per-root comparison will follow.','the complete per-root comparison is below.')
s=s.replace('The helper\'s six findings and emitter\'s ten findings are byte-for-byte identical\nas parsed records','The helper\'s six findings and emitter\'s ten findings are identical parsed records')
s+='\n## Ordinary 79-root census against the earlier main\n\nAll 79 TypeScript compiler roots were measured independently with the ordinary\nproduction compiler. Three non-TypeScript records and the driver\'s whole-program\nrecord are retained raw but excluded from this per-file comparison.\n\n| Outcome | Earlier main | Main now |\n| --- | ---: | ---: |\n'
for kind in sorted(set(result['kinds']['before'])|set(result['kinds']['now'])):s+=f"| {kind} | {result['kinds']['before'].get(kind,0)} | {result['kinds']['now'].get(kind,0)} |\n"
s+='''
**73 changed first stops.** All 73 retain Refused with `a cast the runtime can't
check`, but move from core.ts:810:89 to core.ts:1326:26. The new source is
`values.push((collection as MapLike<T>)[key]!);` in getOwnValues, whose collection
parameter is MapLike<T> | T[]. Diagnostic O1 is constructed at
internal/lower/cast_proof.go:188 in castProof and propagated by castRefusal.
This is the next unproven cast, not a new enum-view failure. The six other roots
retain their exact first stop or accepted outcome. Every changed entry is listed:

| Entry root under src/compiler | Earlier first stop | Main first stop | New emitter |
| --- | --- | --- | --- |
'''
for c in changes:
 old=c['before']['where'].replace('src/compiler/','');new=c['now']['where'].replace('src/compiler/','');root=c['root'].replace('src/compiler/','');s+=f"| `{root}` | Refused `{old}` | Refused `{new}` | O1: castProof, cast_proof.go:188 |\n"
s+='''
The raw census and ordinary-comparison.json preserve every root's complete kind,
source location, reason, fix and diagnostics. Only paths and timing are normalized.
Intervening main adaptations 99r and 99z remove other earlier core stops; this
comparison reports the whole main snapshot and does not attribute the ordinary
movement exclusively to Lower's enum-binding fix.
'''
p.write_text(s);print(json.dumps({'roots_each':79,'changed_first_stops':len(changes),'kinds':result['kinds']},indent=2))
