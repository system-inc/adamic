// Compiled only with the measurement overlay. No backend or usable IR output.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"github.com/system-inc/adamic/internal/load"
	"github.com/system-inc/adamic/internal/lower"
)

var entryMeasurement = "measured on a checker-clean entry-root program"

// The old measurement API labels its records checker-rejected unconditionally.
// Relabel only this separately checked, diagnostic-free observation stream.
func entryLabels(value any) {
	switch value := value.(type) {
	case map[string]any:
		for key, child := range value {
			if key == "measurement" {
				value[key] = entryMeasurement
			} else {
				entryLabels(child)
			}
		}
	case []any:
		for _, child := range value {
			entryLabels(child)
		}
	}
}

func main() {
	if len(os.Args) != 3 {
		panic("usage: entry-census entry-file output.jsonl")
	}
	entry, err := filepath.Abs(os.Args[1])
	if err != nil {
		panic(err)
	}
	paths := []string{entry}
	program, err := load.LatentLoad(paths)
	if err != nil {
		panic(err)
	}
	if os.Getenv("LATENT_ASSERT_NO_OUTPUT") == "" {
		panic("entry census requires LATENT_ASSERT_NO_OUTPUT")
	}
	output, failure := lower.Lower(context.Background(), program)
	if output != nil || failure == nil || failure.Error() != "latent census: measurement only; no IR output" {
		panic("measurement returned usable IR")
	}
	exposed, failure := load.Load(paths)
	if exposed != nil || failure == nil {
		panic("measurement loader exposed an output program")
	}
	stream, err := os.Create(os.Args[2])
	if err != nil {
		panic(err)
	}
	defer stream.Close()
	encoder := json.NewEncoder(stream)
	diagnostics := program.LatentDiagnostics()
	if diagnostics == nil {
		diagnostics = []string{}
	}
	if len(diagnostics) != 0 && os.Getenv("LATENT_FULL") != "1" {
		if err := encoder.Encode(map[string]any{"roots": paths, "status": "blocked", "checker_rejected": true,
			"diagnostics": diagnostics}); err != nil {
			panic(err)
		}
		return
	}
	if len(diagnostics) > 0 {
		entryMeasurement = "measured on a checker-rejected entry-root program"
	}
	program.LatentEntryReach()
	sources := []string{}
	for _, source := range program.Files() {
		sources = append(sources, program.FileName(source))
	}
	sort.Strings(sources)
	diagnosticSites := program.LatentDiagnosticSites()
	for i := range diagnosticSites {
		diagnosticSites[i].Measurement = entryMeasurement
	}
	if err := encoder.Encode(map[string]any{"roots": paths, "status": "measurement", "latent_mode": map[bool]string{true: "full", false: "first-error"}[os.Getenv("LATENT_FULL") == "1"], "checker_rejected": len(diagnostics) > 0,
		"measurement": entryMeasurement, "diagnostics": diagnostics, "sources": sources, "diagnostic_sites": diagnosticSites}); err != nil {
		panic(err)
	}
	if err := stream.Sync(); err != nil {
		panic(err)
	}
	relations := lower.Latent(context.Background(), program, func(record lower.LatentFile) {
		data, err := json.Marshal(record)
		if err != nil {
			panic(err)
		}
		var value any
		if err := json.Unmarshal(data, &value); err != nil {
			panic(err)
		}
		entryLabels(value)
		if err := encoder.Encode(value); err != nil {
			panic(err)
		}
		fmt.Fprintln(os.Stderr, record.File, len(record.Findings), entryMeasurement)
	})
	data, err := json.Marshal(map[string]any{"measurement": entryMeasurement, "status": "relation_report", "relation_overflow": relations, "findings": relations.Findings})
	if err != nil {
		panic(err)
	}
	var trailer any
	if err := json.Unmarshal(data, &trailer); err != nil {
		panic(err)
	}
	entryLabels(trailer)
	if err := encoder.Encode(trailer); err != nil {
		panic(err)
	}
	if err := stream.Sync(); err != nil {
		panic(err)
	}
}
