package lower

import (
	"fmt"
	"strings"

	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/microsoft/TypeScript/tsc/shim/scanner"
)

type refusal struct {
	what string
	fix  string
}

var refusals = map[ast.Kind]refusal{
	ast.KindNonNullExpression: {"the non-null assertion !", "write ?? panic('why it can't be missing'), or narrow and handle the missing case"},
	ast.KindAwaitExpression:   {"await", "0.1 has no async; it arrives with the concurrency model"},
	ast.KindYieldExpression:   {"yield (generators)", "build an array, or call a function per item"},
	ast.KindDecorator:         {"a decorator", "write the behavior where it applies; 0.1 doesn't rewrite classes at runtime"},
	ast.KindWithStatement:     {"with", "name the object you mean"},
	ast.KindDeleteExpression:  {"delete", "an object's shape is fixed; use a Map for keys that come and go"},
	ast.KindIndexSignature:    {"an index signature", "use a Map, which keeps keys in the order they were added"},
	ast.KindExportAssignment:  {"export default", "export by name: one name for one thing"},
}

var refusedOperators = map[ast.Kind]refusal{
	ast.KindEqualsEqualsToken:      {"==", "use ===, which doesn't coerce"},
	ast.KindExclamationEqualsToken: {"!=", "use !==, which doesn't coerce"},
}

func (l *lowering) refuse(module *ast.SourceFile) error {

	if len(module.CommentDirectives) > 0 {
		directive := module.CommentDirectives[0]
		name := "@ts-ignore"
		if directive.Kind == ast.CommentDirectiveKindExpectError {
			name = "@ts-expect-error"
		}
		line, column := scanner.GetLineAndCharacterOfPosition(module, directive.Loc.Pos())
		return &Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: name + " suppression directive", Fix: "remove it and fix the type error"}
	}

	for _, pragma := range module.Pragmas {
		if pragma.Name == "ts-nocheck" || pragma.Name == "ts-check" {
			line, column := scanner.GetLineAndCharacterOfPosition(module, pragma.Pos())
			return &Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: "@" + pragma.Name + " checking pragma", Fix: "remove it and fix any type errors"}
		}
	}

	var contractError error
	var contracts ast.Visitor
	contracts = func(node *ast.Node) bool {
		if contractError != nil {
			return true
		}
		if node.Kind == ast.KindCallExpression {
			contractError = l.predicateArguments(node)
		}
		if contractError == nil {
			node.ForEachChild(contracts)
		}
		return contractError != nil
	}
	module.AsNode().ForEachChild(contracts)
	if contractError != nil {
		return contractError
	}
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if found != nil {
			return true
		}
		if branch := l.literalCallableBranch(node); branch != nil {
			return visit(branch)
		}
		if node.Kind == ast.KindTypePredicate {
			found = l.predicateRefusal(node)
			return found != nil
		}
		if err := l.enumerationIndexedWriteRefusal(node); err != nil {
			found = err
			return true
		}
		if err := l.enumerationDescriptorRefusal(node); err != nil {
			found = err
			return true
		}
		if err := l.nodeLibraryRefusal(node); err != nil {
			found = err
			return true
		}
		if refused, isRefused := refusals[node.Kind]; isRefused && !(node.Kind == ast.KindIndexSignature && l.enumerationIndexSignature(node)) && (node.Kind != ast.KindNonNullExpression || !l.checkedAssertionSource(node)) {
			found = &Refused{Where: l.program.Where(node), What: refused.what, Fix: refused.fix}
			return true
		}
		if err := l.typedArrayUnsupported(node); err != nil {
			found = err
			return true
		}
		if node.Kind == ast.KindCallExpression {
			if err := l.predicateArguments(node); err != nil {
				found = err
				return true
			}
		}
		if err := l.enumRefusal(node); err != nil {
			found = err
			return true
		}
		checkedCast := false
		if node.Kind == ast.KindAsExpression {
			proof, err := l.castProof(node)
			if err != nil {
				found = err
				return true
			}
			checkedCast = proof.interfaceView || len(proof.allowed) > 0 || len(proof.classes) > 0
		}
		if err := l.namespaceRefusal(node); err != nil {
			found = err
			return true
		}
		if node.Kind == ast.KindBinaryExpression {
			if refused, isRefused := refusedOperators[node.AsBinaryExpression().OperatorToken.Kind]; isRefused {
				found = &Refused{Where: l.program.Where(node.AsBinaryExpression().OperatorToken), What: refused.what, Fix: refused.fix}
				return true
			}
		}
		generator := false
		switch node.Kind {
		case ast.KindFunctionDeclaration:
			generator = node.AsFunctionDeclaration().AsteriskToken != nil
		case ast.KindFunctionExpression:
			generator = node.AsFunctionExpression().AsteriskToken != nil
		case ast.KindMethodDeclaration:
			generator = node.AsMethodDeclaration().AsteriskToken != nil
		}
		if generator {
			found = &Refused{Where: l.program.Where(node), What: "a generator function", Fix: "use an explicit iterator object; suspended frames need ownership and cancellation rules before generators can be compiled without a collector (docs/user-iterators.md)"}
			return true
		}
		if ast.IsFunctionLike(node) && ast.HasSyntacticModifier(node, ast.ModifierFlagsAsync) {
			found = &Refused{Where: l.program.Where(node), What: "an async function", Fix: "0.1 has no async; it arrives with the concurrency model"}
			return true
		}
		if node.Kind == ast.KindIdentifier && node.Text() == "arguments" {

			if symbol := l.checker.GetSymbolAtLocation(node); symbol != nil && len(symbol.Declarations) == 0 {
				if err := l.argumentsRefusal(node); err != nil {
					found = err
					return true
				}
			}
		}
		if (node.Kind == ast.KindPropertyAccessExpression || node.Kind == ast.KindElementAccessExpression) && !called(node) {
			if err := l.nodeBufferUnsupportedUse(node); err != nil {
				found = err
				return true
			}
		}
		if node.Kind == ast.KindShorthandPropertyAssignment {
			if symbol := l.checker.GetShorthandAssignmentValueSymbol(node); symbol != nil && len(symbol.Declarations) == 1 && symbol.Declarations[0].Kind == ast.KindVariableDeclaration {
				if initializer := symbol.Declarations[0].AsVariableDeclaration().Initializer; initializer != nil {
					if _, known := l.libraryMethod(initializer, map[*ast.Symbol]bool{}); known {
						found = l.notYet(node, "a library method value outside a const alias (an object field erases its receiver and callable ABI); use an arrow")
						return true
					}
				}
			}
		}
		if node.Kind == ast.KindPropertyAccessExpression && !called(node) && !l.libraryNumberBoundMethod(node) && !l.stringMethodObservation(node) && !l.libraryArrayObservedMethod(node) && !l.libraryMethodReadAllowed(node) {

			access := node.AsPropertyAccessExpression()
			if access.Name().Text() == "isPrototypeOf" && l.libraryMember(node) {
				found = l.prototypeRead(node, "isPrototypeOf")
				return true
			}

			isRandom := l.isLibraryGlobal(access.Expression, "Math") && access.Name().Text() == "random"
			if symbol := l.checker.GetSymbolAtLocation(node); symbol != nil && symbol.Flags&ast.SymbolFlagsMethod != 0 && !isRandom {
				object := "its object"
				if ast.IsIdentifier(access.Expression) || access.Expression.Kind == ast.KindThisKeyword {
					object = scannedText(access.Expression)
				}
				parameters := "value"
				if signatures := l.checker.GetSignaturesOfType(l.checker.GetTypeOfSymbol(symbol), checker.SignatureKindCall); len(signatures) > 0 {
					names := []string{}
					for _, parameter := range signatures[0].Parameters() {
						names = append(names, parameter.Name)
					}
					parameters = strings.Join(names, ", ")
				}
				found = &Refused{Where: l.program.Where(node), What: "a method read as a value (" + symbol.Name + " would lose its object, and this with it)", Fix: "call it in an arrow that keeps the object: (" + parameters + ") => " + object + "." + symbol.Name + "(" + parameters + ") (unbound-method)"}
				return true
			}
		}
		if node.Kind == ast.KindClassDeclaration {
			if err := l.checkOverrides(node, l.checker.GetTypeAtLocation(node.Name())); err != nil {
				found = err
				return true
			}
		}

		if !checkedCast {
			if err := l.refuseStringWidening(node); err != nil {
				found = err
				return true
			}
		}
		if err := l.refuseOptionalWidening(node); err != nil {
			found = err
			return true
		}
		if err := l.classViewRefusal(node); err != nil {
			found = err
			return true
		}
		node.ForEachChild(visit)
		return false
	}
	module.AsNode().ForEachChild(visit)
	return found
}

func called(node *ast.Node) bool {
	for node.Parent != nil && node.Parent.Kind == ast.KindParenthesizedExpression {
		node = node.Parent
	}
	return node.Parent != nil && node.Parent.Kind == ast.KindCallExpression && node.Parent.AsCallExpression().Expression == node
}

func scannedText(node *ast.Node) string {
	if node.Kind == ast.KindThisKeyword {
		return "this"
	}
	return node.Text()
}
func (l *lowering) latentRefuse(module *ast.SourceFile) error {
	for _, directive := range module.
		CommentDirectives {
		name := "@ts-ignore"
		if directive.Kind == ast.CommentDirectiveKindExpectError {
			name = "@ts-expect-error"
		}
		line, column := scanner.GetLineAndCharacterOfPosition(module, directive.Loc.Pos())
		latentRecord(&Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: name + " suppression directive", Fix: "remove it and fix the type error"})
	}

	for _, pragma := range module.Pragmas {
		if pragma.Name == "ts-nocheck" || pragma.Name == "ts-check" {
			line, column := scanner.GetLineAndCharacterOfPosition(module, pragma.Pos())
			latentRecord(&Refused{Where: fmt.Sprintf("%s:%d:%d", l.program.FileName(module), line+1, column+1), What: "@" + pragma.Name + " checking pragma", Fix: "remove it and fix any type errors"})
		}
	}

	var contractError error
	var contracts ast.Visitor
	contracts = func(node *ast.Node) (latentStop bool) {
 latentProgressScan(node, "contract_scan")
		if latentFullEnabled() && node.Kind == ast.KindFunctionDeclaration {
			outerOwner := latentFindingOwner
			latentFindingOwner = l.program.Where(node)
			defer func() {
				latentFindingOwner = outerOwner
			}()
			if len(l.latentBodyDiagnostics(node.Body())) > 0 {
				latentNestedDeclarations(node.
					Body(), contracts)
				return false
			}
		} else {

			if node.Parent != nil && node.Parent.Kind == ast.KindSourceFile {
				latentFindingOwner = l.program.
					Where(node)
			}
			if node.Kind == ast.KindFunctionDeclaration && node.Parent !=
				nil && node.Parent.Kind == ast.KindSourceFile &&
				len(l.program.LatentDiagnosticsIn(node.Body())) > 0 {
				return false
			}
		}
		defer func() {
			latentRecordNode(contractError, node)
			contractError = nil
			node.ForEachChild(contracts)
			latentStop = false
		}()
		if contractError != nil {
			return true
		}
		if node.Kind == ast.KindCallExpression {
			contractError = l.predicateArguments(node)
		}
		if contractError == nil {

		}
		return contractError != nil
	}
	module.AsNode().ForEachChild(contracts)
	if contractError != nil {
		latentRecord(contractError)
	}
	var found error
	var visit ast.Visitor
	visit = func(node *ast.Node) (latentStop bool) {
 latentProgressScan(node, "refusal_scan")
		if latentFullEnabled() && node.Kind == ast.KindFunctionDeclaration {
			outerOwner := latentFindingOwner
			latentFindingOwner = l.program.Where(node)
			defer func() {
				latentFindingOwner = outerOwner
			}()
			if len(l.latentBodyDiagnostics(node.Body())) > 0 {
				latentNestedDeclarations(node.
					Body(), visit)
				return false
			}
		} else {
			if node.
				Parent != nil && node.Parent.Kind == ast.KindSourceFile {
				latentFindingOwner = l.program.Where(node)
			}
			if node.Kind == ast.KindFunctionDeclaration && node.Parent !=
				nil && node.Parent.Kind == ast.KindSourceFile &&
				len(l.program.LatentDiagnosticsIn(node.Body())) > 0 {
				return false
			}
		}
		defer func() {
			latentRecordNode(found, node)
			found = nil
			node.ForEachChild(visit)
			latentStop = false
		}()

		if found != nil {
			return true
		}
		if branch := l.literalCallableBranch(node); branch != nil {
			return visit(branch)
		}
		if node.Kind == ast.KindTypePredicate {
			found = l.predicateRefusal(node)
			return found != nil
		}
		if err := l.enumerationIndexedWriteRefusal(node); err != nil {
			found = err
			return true
		}
		if err := l.enumerationDescriptorRefusal(node); err != nil {
			found = err
			return true
		}
		if err := l.nodeLibraryRefusal(node); err != nil {
			found = err
			return true
		}
		if refused, isRefused := refusals[node.Kind]; isRefused && !(node.Kind == ast.KindIndexSignature && l.enumerationIndexSignature(node)) && (node.Kind != ast.KindNonNullExpression || !l.checkedAssertionSource(node)) {
			found = &Refused{Where: l.program.Where(node), What: refused.what, Fix: refused.fix}
			return true
		}
		if err := l.typedArrayUnsupported(node); err != nil {
			found = err
			return true
		}
		if node.Kind == ast.KindCallExpression {
			if err := l.predicateArguments(node); err != nil {
				found = err
				return true
			}
		}
		if err := l.enumRefusal(node); err != nil {
			found = err
			return true
		}
		checkedCast := false
		if node.Kind == ast.KindAsExpression {
			proof, err := l.castProof(node)
			if err != nil {
				found = err
				return true
			}
			checkedCast = proof.interfaceView || len(proof.allowed) > 0 || len(proof.classes) > 0
		}
		if err := l.namespaceRefusal(node); err != nil {
			found = err
			return true
		}
		if node.Kind == ast.KindBinaryExpression {
			if refused, isRefused := refusedOperators[node.AsBinaryExpression().OperatorToken.Kind]; isRefused {
				found = &Refused{Where: l.program.Where(node.AsBinaryExpression().OperatorToken), What: refused.what, Fix: refused.fix}
				return true
			}
		}
		generator := false
		switch node.Kind {
		case ast.KindFunctionDeclaration:
			generator = node.AsFunctionDeclaration().AsteriskToken != nil
		case ast.KindFunctionExpression:
			generator = node.AsFunctionExpression().AsteriskToken != nil
		case ast.KindMethodDeclaration:
			generator = node.AsMethodDeclaration().AsteriskToken != nil
		}
		if generator {
			found = &Refused{Where: l.program.Where(node), What: "a generator function", Fix: "use an explicit iterator object; suspended frames need ownership and cancellation rules before generators can be compiled without a collector (docs/user-iterators.md)"}
			return true
		}
		if ast.IsFunctionLike(node) && ast.HasSyntacticModifier(node, ast.ModifierFlagsAsync) {
			found = &Refused{Where: l.program.Where(node), What: "an async function", Fix: "0.1 has no async; it arrives with the concurrency model"}
			return true
		}
		if node.Kind == ast.KindIdentifier && node.Text() == "arguments" {

			if symbol := l.checker.GetSymbolAtLocation(node); symbol != nil && len(symbol.Declarations) == 0 {
				if err := l.argumentsRefusal(node); err != nil {
					found = err
					return true
				}
			}
		}
		if (node.Kind == ast.KindPropertyAccessExpression || node.Kind == ast.KindElementAccessExpression) && !called(node) {
			if err := l.nodeBufferUnsupportedUse(node); err != nil {
				found = err
				return true
			}
		}
		if node.Kind == ast.KindShorthandPropertyAssignment {
			if symbol := l.checker.GetShorthandAssignmentValueSymbol(node); symbol != nil && len(symbol.Declarations) == 1 && symbol.Declarations[0].Kind == ast.KindVariableDeclaration {
				if initializer := symbol.Declarations[0].AsVariableDeclaration().Initializer; initializer != nil {
					if _, known := l.libraryMethod(initializer, map[*ast.Symbol]bool{}); known {
						found = l.notYet(node, "a library method value outside a const alias (an object field erases its receiver and callable ABI); use an arrow")
						return true
					}
				}
			}
		}
		if node.Kind == ast.KindPropertyAccessExpression && !called(node) && !l.libraryNumberBoundMethod(node) && !l.stringMethodObservation(node) && !l.libraryArrayObservedMethod(node) && !l.libraryMethodReadAllowed(node) {

			access := node.AsPropertyAccessExpression()
			if access.Name().Text() == "isPrototypeOf" && l.libraryMember(node) {
				found = l.prototypeRead(node, "isPrototypeOf")
				return true
			}

			isRandom := l.isLibraryGlobal(access.Expression, "Math") && access.Name().Text() == "random"
			if symbol := l.checker.GetSymbolAtLocation(node); symbol != nil && symbol.Flags&ast.SymbolFlagsMethod != 0 && !isRandom {
				object := "its object"
				if ast.IsIdentifier(access.Expression) || access.Expression.Kind == ast.KindThisKeyword {
					object = scannedText(access.Expression)
				}
				parameters := "value"
				if signatures := l.checker.GetSignaturesOfType(l.checker.GetTypeOfSymbol(symbol), checker.SignatureKindCall); len(signatures) > 0 {
					names := []string{}
					for _, parameter := range signatures[0].Parameters() {
						names = append(names, parameter.Name)
					}
					parameters = strings.Join(names, ", ")
				}
				found = &Refused{Where: l.program.Where(node), What: "a method read as a value (" + symbol.Name + " would lose its object, and this with it)", Fix: "call it in an arrow that keeps the object: (" + parameters + ") => " + object + "." + symbol.Name + "(" + parameters + ") (unbound-method)"}
				return true
			}
		}
		if node.Kind == ast.KindClassDeclaration {
			if err := l.checkOverrides(node, l.checker.GetTypeAtLocation(node.Name())); err != nil {
				found = err
				return true
			}
		}

		if !checkedCast {
			if err := l.refuseStringWidening(node); err != nil {
				found = err
				return true
			}
		}
		if err := l.refuseOptionalWidening(node); err != nil {
			found = err
			return true
		}
		if err := l.classViewRefusal(node); err != nil {
			found = err
			return true
		}

		return false
	}
	module.AsNode().ForEachChild(visit)
	latentRecord(found)
	return nil
}
