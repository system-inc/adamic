// Scratch measurement access only. Production Load remains inaccessible in this binary.
package load

import (
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"os"
)

func (p *Program) LatentDiagnostics() []string { return p.latentDiagnostics }

// Use byte ranges from the checker, not parsed display lines or string matching.
func (p *Program) LatentDiagnosticsIn(node *ast.Node) []string {
	if node == nil {
		return nil
	}
	file := ast.GetSourceFileOfNode(node)
	start := node.Pos()
	if os.Getenv("LATENT_MUTANT_BODY_SCOPE") != "" {
		start = node.Parent.Pos()
	}
	var result []string
	for _, diagnostic := range p.latentSites {
		if diagnostic.File() == file && diagnostic.Pos() < node.End() && (diagnostic.End() > start || diagnostic.Pos() >= start) {
			result = append(result, p.formatDiagnostic(diagnostic))
		}
	}
	return result
}

// Preserve raw checker spans so the independent recount can verify eligibility.
type LatentDiagnosticSite struct {
	Measurement string `json:"measurement"`
	File        string `json:"file"`
	Start       int    `json:"start"`
	End         int    `json:"end"`
	Text        string `json:"text"`
}

func (p *Program) LatentDiagnosticSites() []LatentDiagnosticSite {
	result := []LatentDiagnosticSite{}
	for _, diagnostic := range p.latentSites {
		file := ""
		if diagnostic.File() != nil {
			file = p.FileName(diagnostic.File())
		}
		result = append(result, LatentDiagnosticSite{Measurement: "measured on a checker-rejected program", File: file, Start: diagnostic.Pos(), End: diagnostic.End(), Text: p.formatDiagnostic(diagnostic)})
	}
	return result
}

// Direct body ownership excludes nested declarations, including their signatures.
// Diagnostics overlapping a declaration boundary remain conservatively owned.
func (p *Program) LatentOwnDiagnosticsIn(body *ast.Node) []string {
	if body == nil {
		return nil
	}
	type span struct{ start, end int }
	nested := []span{}
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if node.Kind == ast.KindFunctionDeclaration {
			nested = append(nested, span{node.Pos(), node.End()})
			return false
		}
		node.ForEachChild(visit)
		return false
	}
	body.ForEachChild(visit)
	result := []string{}
	file := ast.GetSourceFileOfNode(body)
	for _, diagnostic := range p.latentSites {
		if diagnostic.File() != file || diagnostic.Pos() >= body.End() || (diagnostic.End() <= body.Pos() && diagnostic.Pos() < body.Pos()) {
			continue
		}
		childOwned := false
		for _, child := range nested {
			if diagnostic.Pos() >= child.start && diagnostic.End() <= child.end {
				childOwned = true
				break
			}
		}
		if !childOwned {
			result = append(result, p.formatDiagnostic(diagnostic))
		}
	}
	return result
}

// Entry replay uses the same resolved graph as the entry census.
func (p *Program) LatentReplayEntryReach() {
	p.files = nil
	for _, source := range p.compiler.GetSourceFiles() {
		if !source.IsDeclarationFile && !IsLibrary(source) {
			p.files = append(p.files, source)
		}
	}
}
