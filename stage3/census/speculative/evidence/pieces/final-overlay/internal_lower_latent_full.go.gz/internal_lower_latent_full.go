// Compiled only in the no-output measurement overlay.
package lower

import (
	"fmt"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/system-inc/adamic/internal/ir"
	"os"
	"reflect"
)

func (l *lowering) latentBodyDiagnostics(body *ast.Node) []string {
	if latentSpeculativeEnabled() {
		return nil
	}
	if latentFullEnabled() {
		return l.program.LatentOwnDiagnosticsIn(body)
	}
	return l.program.LatentDiagnosticsIn(body)
}

func latentFullEnabled() bool { return os.Getenv("LATENT_FULL") == "1" || latentSpeculativeEnabled() }

// IR fields are exported. Compiler/checker identities remain shared; all mutable
// lowering-owned state is copied by the generated typed state copier.
func latentCopyIR[T any](value T, seen map[any]any) T {
	speculative := latentSpeculativeEnabled()
	shareScalarSlice := os.Getenv("LATENT_MUTANT_SHARE_SCALAR_SLICE") == "1"
	functionSlice := reflect.TypeFor[[]ir.Function]()
	var copyValue func(reflect.Value) reflect.Value
	copyValue = func(v reflect.Value) reflect.Value {
		if speculative && latentSpecImmutable(v.Type()) {
			return v
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return reflect.Zero(v.Type())
			}
			if v.Type().Elem().PkgPath() != "github.com/system-inc/adamic/internal/ir" {
				panic("latent state copy: unsupported foreign IR pointer " + v.Type().String())
			}
			key := v.Interface()
			if previous, ok := seen[key]; ok {
				return reflect.ValueOf(previous)
			}
			result := reflect.New(v.Type().Elem())
			seen[key] = result.Interface()
			result.Elem().Set(copyValue(v.Elem()))
			return result
		case reflect.Interface:
			if v.IsNil() {
				return reflect.Zero(v.Type())
			}
			result := reflect.New(v.Type()).Elem()
			result.Set(copyValue(v.Elem()))
			return result
		case reflect.Struct:
			result := reflect.New(v.Type()).Elem()
			if speculative {
				result.Set(v)
				for _, index := range latentSpecMutableFields(v.Type()) {
					if latentEmptyArgumentCache(v, index) { continue }
					if !result.Field(index).CanSet() {
						panic("latent state copy: unexported IR field " + v.Type().Field(index).Name)
					}
					result.Field(index).Set(copyValue(v.Field(index)))
				}
				return result
			}
			for i := 0; i < v.NumField(); i++ {
				if latentEmptyArgumentCache(v, i) { continue }
				if !result.Field(i).CanSet() {
					panic("latent state copy: unexported IR field " + v.Type().Field(i).Name)
				}
				result.Field(i).Set(copyValue(v.Field(i)))
			}
			return result
		case reflect.Array:
			result := reflect.New(v.Type()).Elem()
			for i := 0; i < v.Len(); i++ {
				result.Index(i).Set(copyValue(v.Index(i)))
			}
			return result
		case reflect.Slice:
			if v.IsNil() {
				return reflect.Zero(v.Type())
			}
			if speculative && v.Type() == functionSlice {
				latentSpecFunctionSchema(reflect.TypeFor[ir.Function]())
				original := v.Interface().([]ir.Function)
				cloned := make([]ir.Function, len(original))
				copy(cloned, original)
				for i, function := range original {
					if function.Parameters != nil { cloned[i].Parameters = copyValue(reflect.ValueOf(function.Parameters)).Interface().([]int) }
					if function.OptionalParameters != nil { cloned[i].OptionalParameters = copyValue(reflect.ValueOf(function.OptionalParameters)).Interface().(map[int]bool) }
					if function.Body != nil { cloned[i].Body = copyValue(reflect.ValueOf(function.Body)).Interface().([]ir.Statement) }
					if function.Environment != nil { cloned[i].Environment = copyValue(reflect.ValueOf(function.Environment)).Interface().([]int) }
					if function.FrameEnvironment != nil { cloned[i].FrameEnvironment = copyValue(reflect.ValueOf(function.FrameEnvironment)).Interface().([]int) }
					if function.ReferenceParents != nil { cloned[i].ReferenceParents = copyValue(reflect.ValueOf(function.ReferenceParents)).Interface().([]int) }
				}
				return reflect.ValueOf(cloned)
			}
			result := reflect.MakeSlice(v.Type(), v.Len(), v.Len())
			if speculative && latentSpecImmutable(v.Type().Elem()) {
				if shareScalarSlice {
					return v
				}
				reflect.Copy(result, v)
				return result
			}
			for i := 0; i < v.Len(); i++ {
				result.Index(i).Set(copyValue(v.Index(i)))
			}
			return result
		case reflect.Map:
			if v.IsNil() {
				return reflect.Zero(v.Type())
			}
			result := reflect.MakeMapWithSize(v.Type(), v.Len())
			iterator := v.MapRange()
			for iterator.Next() {
				result.SetMapIndex(iterator.Key(), copyValue(iterator.Value()))
			}
			return result
		case reflect.Chan, reflect.Func, reflect.UnsafePointer:
			panic("latent state copy: unsupported mutable IR kind " + v.Kind().String())
		default:
			return v
		}
	}
	if !reflect.ValueOf(value).IsValid() {
		var zero T
		return zero
	}
	return copyValue(reflect.ValueOf(value)).Interface().(T)
}

func (l *lowering) latentSnapshot() *lowering {
	copy := latentCopyPointer_lowering(l, map[any]any{})
	for i := range l.result.Functions {
		if l.function == &l.result.Functions[i] {
			copy.function = &copy.result.Functions[i]
		}
	}
	return copy
}

func (l *lowering) latentStatement(node *ast.Node) (result []ir.Statement, failure error) {
	if latentSpeculativeEnabled() && latentSpec != nil {
		return l.latentSpecStatement(node)
	}
	if !latentFullEnabled() {
		return l.latentStatementRaw(node)
	}
	if os.Getenv("LATENT_MUTANT_FIRST_ERROR_ONLY") == "1" {
		return l.latentStatementRaw(node)
	}
	var checkpoint *lowering
	defer func() {
		if crash := recover(); crash != nil {
			failure = fmt.Errorf("statement panic: %v", crash)
			latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: l.program.Where(node), Reason: failure.Error(), Text: failure.Error()})
		}
		if failure == nil && l.unlowerable != nil {
			failure = l.unlowerable
		}
		if failure != nil {
			latentRecord(failure)
			boundary := "failed statement; state rolled back; continued at next statement or declaration"
			if checkpoint == nil {
				boundary = "state snapshot failed; cannot safely continue this unit"
			}
			latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "Boundary", Where: l.program.Where(node), Reason: boundary, Text: failure.Error(), Start: node.Pos(), End: node.End()})
			if checkpoint != nil {
				if os.Getenv("LATENT_MUTANT_KEEP_FAILED_STATE") != "1" {
					*l = *checkpoint
				}
				result = nil
				failure = nil
			}
		}
	}()
	checkpoint = l.latentSnapshot()
	return l.latentStatementRaw(node)
}

// A diagnosed container contributes no unsafe body lowering. Its nested
// declarations remain independently eligible and are visited exactly once.
func latentNestedDeclarations(body *ast.Node, visit ast.Visitor) {
	if body == nil {
		return
	}
	var walk ast.Visitor
	walk = func(node *ast.Node) bool {
		if node.Kind == ast.KindFunctionDeclaration {
			visit(node)
			return false
		}
		node.ForEachChild(walk)
		return false
	}
	body.ForEachChild(walk)
}

// Main added a private backend derivation cache. A census has not run the
// backend derivation; accept its nil state only, and reject a populated cache.
func latentEmptyArgumentCache(v reflect.Value, index int) bool {
    return v.Type() == reflect.TypeFor[ir.Program]() && v.Type().Field(index).Name == "argumentFacts" && v.Field(index).IsNil()
}
