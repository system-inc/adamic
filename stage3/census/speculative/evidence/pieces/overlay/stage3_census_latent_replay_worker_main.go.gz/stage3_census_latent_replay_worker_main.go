// Compiled only with the no-output census overlay.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/system-inc/adamic/internal/load"
	"github.com/system-inc/adamic/internal/lower"
	"os"
	"path/filepath"
	"sort"
	"time"
)

func main() {
	started := time.Now()
	project := flag.String("project", "", "same source directory or entry file used by the census")
	where := flag.String("where", "", "exact census diagnostic node position: file:line:column")
	kind := flag.String("kind", "", "exact census kind: NotYet or Refused")
	reason := flag.String("reason", "", "exact census refusal reason")
	flag.Parse()
	if *project == "" || *where == "" || (*kind != "NotYet" && *kind != "Refused") || *reason == "" || flag.NArg() != 0 {
		flag.Usage()
		os.Exit(2)
	}
	if err := os.Setenv("LATENT_FULL", "1"); err != nil {
		panic(err)
	}
	paths := []string{}
	info, err := os.Stat(*project)
	if err != nil {
		panic(err)
	}
	if info.IsDir() {
		err = filepath.WalkDir(*project, func(path string, entry os.DirEntry, failure error) error {
			if failure != nil {
				return failure
			}
			if !entry.IsDir() && (filepath.Ext(path) == ".ts" || filepath.Ext(path) == ".a") {
				paths = append(paths, path)
			}
			return nil
		})
		if err != nil {
			panic(err)
		}
		sort.Strings(paths)
	} else {
		entry, err := filepath.Abs(*project)
		if err != nil {
			panic(err)
		}
		paths = append(paths, entry)
	}
	program, err := load.LatentLoad(paths)
	if err != nil {
		panic(err)
	}
	if !info.IsDir() {
		program.LatentReplayEntryReach()
	}
	// The replay worker always checks the census output guards.
	output, failure := lower.Lower(context.Background(), program)
	if output != nil || failure == nil || failure.Error() != "latent census: measurement only; no IR output" {
		panic("measurement returned usable IR")
	}
	exposed, failure := load.Load(paths)
	if exposed != nil || failure == nil {
		panic("measurement loader exposed an output program")
	}
	record, failure := lower.LatentReplay(context.Background(), program, *where, *kind, *reason)
	if !info.IsDir() {
		label := "measured on a checker-clean entry-root program"
		if len(program.LatentDiagnostics()) > 0 {
			label = "measured on a checker-rejected entry-root program"
		}
		record.Measurement = label
		for index := range record.Declarations {
			record.Declarations[index].Measurement = label
		}
		for index := range record.Units {
			record.Units[index].Measurement = label
		}
		for index := range record.Findings {
			record.Findings[index].Measurement = label
		}
	}
	if err := json.NewEncoder(os.Stdout).Encode(record); err != nil {
		panic(err)
	}
	fmt.Fprintf(os.Stderr, "replay load/register/lower: %s\n", time.Since(started))
	if failure != nil {
		fmt.Fprintln(os.Stderr, failure)
		os.Exit(1)
	}
	fmt.Fprintf(os.Stderr, "reproduced %s: %s at %s\n", *kind, *reason, *where)
}
