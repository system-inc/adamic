// This file is compiled only through a scratch Go overlay.
package lower

import (
	"context"
	"errors"
	"fmt"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/system-inc/adamic/internal/ir"
	"github.com/system-inc/adamic/internal/load"
	"os"
)

// A checker-diagnosed dependency is a measurement boundary, not a compiler blocker.
type LatentDependencySkipped struct{ Where string }

func (e *LatentDependencySkipped) Error() string {
	return "latent census: skipped checker-diagnosed dependency at " + e.Where
}

type LatentFinding struct {
 PieceAtom string `json:"piece_atom,omitempty"`
	SiteWhere     string `json:"site_where,omitempty"`
	SiteKind      string `json:"site_kind,omitempty"`
	SiteStart     int    `json:"site_start,omitempty"`
	SiteEnd       int    `json:"site_end,omitempty"`
	RootKind      string `json:"root_kind"`
	Depth         int    `json:"depth"`
	BoundaryWhere string `json:"boundary_where,omitempty"`
	Measurement   string `json:"measurement"`
	Unit          string `json:"unit"`
	Phase         string `json:"phase"`
	Kind          string `json:"kind"`
	Where         string `json:"where"`
	Reason        string `json:"reason"`
	Text          string `json:"text"`
	Start         int    `json:"start,omitempty"`
	End           int    `json:"end,omitempty"`
}

// The measurement driver is sequential. Nothing returns usable IR.
var latentFindings []LatentFinding
var latentFindingOwner, latentFindingPhase string

func latentRecord(err error) {
	if err == nil {
		return
	}
	finding := LatentFinding{PieceAtom: latentPieceOrigin, Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "error", Text: err.Error()}
	var refused *Refused
	var notYet *NotYet
	var skipped *LatentDependencySkipped
	switch {
	case errors.As(err, &skipped):
		finding.Kind, finding.Where, finding.Reason = "SkippedDependency", skipped.Where, "a dependency function whose body has checker diagnostics (measurement skipped)"
	case errors.As(err, &refused):
		finding.Kind, finding.Where, finding.Reason = "Refused", refused.Where, refused.What
	case errors.As(err, &notYet):
		finding.Kind, finding.Where, finding.Reason = "NotYet", notYet.Where, notYet.What
	default:
		finding.Reason = err.Error()
	}
	latentFindings = append(latentFindings, finding)
}

const LatentMeasurementLabel = "measured on a checker-rejected program"

type LatentUnit struct {
	Measurement        string   `json:"measurement"`
	Where              string   `json:"where"`
	Kind               string   `json:"kind"`
	BodyStart          int      `json:"body_start,omitempty"`
	BodyEnd            int      `json:"body_end,omitempty"`
	Status             string   `json:"status"`
	CheckerDiagnostics []string `json:"checker_diagnostics"`
	Name               string   `json:"name,omitempty"`
	Parent             string   `json:"parent,omitempty"`
	Top                string   `json:"top,omitempty"`
	Depth              int      `json:"depth,omitempty"`
}

// Declaration spans add attribution only; they never change lowering eligibility.
type LatentDeclaration struct {
	Measurement string `json:"measurement"`
	Where       string `json:"where"`
	Name        string `json:"name"`
	Kind        string `json:"kind"`
	Start       int    `json:"start"`
	End         int    `json:"end"`
}

func latentDeclarations(program *load.Program, file *ast.SourceFile) []LatentDeclaration {
	result := []LatentDeclaration{}
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		switch node.Kind {
		case ast.KindFunctionDeclaration, ast.KindFunctionExpression, ast.KindMethodDeclaration,
			ast.KindVariableDeclaration, ast.KindParameter, ast.KindPropertyDeclaration,
			ast.KindPropertySignature, ast.KindMethodSignature, ast.KindTypeAliasDeclaration,
			ast.KindInterfaceDeclaration, ast.KindClassDeclaration, ast.KindEnumDeclaration,
			ast.KindModuleDeclaration, ast.KindGetAccessor, ast.KindSetAccessor:
			if name := node.Name(); name != nil {
				text := file.Text()[name.Pos():name.End()]
				result = append(result, LatentDeclaration{Measurement: LatentMeasurementLabel, Where: program.Where(node), Name: text, Kind: node.Kind.String(), Start: node.Pos(), End: node.End()})
			}
		}
		node.ForEachChild(visit)
		return false
	}
	file.AsNode().ForEachChild(visit)
	return result
}

type LatentFile struct {
 Piece *latentPieceRecord `json:"piece,omitempty"`
	ProjectFailedBoundaries map[string][]LatentBoundary `json:"project_failed_boundaries,omitempty"`
	FailedBoundaries []LatentBoundary `json:"failed_boundaries,omitempty"`
	SpeculativeCoverage *LatentSpeculativeCoverage `json:"speculative_coverage,omitempty"`
	Measurement         string                     `json:"measurement"`
	File                string                     `json:"file"`
	Declarations        []LatentDeclaration        `json:"declarations"`
	Units               []LatentUnit               `json:"units"`
	Findings            []LatentFinding            `json:"findings"`
}

func (l *lowering) latentSignature(index int) error {
	declaration := l.latentDeclarations[index]
	if declaration == nil || l.latentReady[index] {
		return nil
	}
	return l.signature(index, declaration, -1)
}

// Register project symbols without lowering another function's body. Signatures are
// prepared on use; failed global representations are rediscovered at actual reads.
func (l *lowering) latentRegister(files []*ast.SourceFile) {
	l.functions = map[*ast.Symbol]int{}
	l.generics = map[*ast.Symbol]*ast.Node{}
	l.classes = map[*ast.Symbol]*ast.Node{}
	l.latentDeclarations = map[int]*ast.Node{}
	var register func(*ast.Node)
	register = func(node *ast.Node) {
		switch node.Kind {
		case ast.KindModuleDeclaration:
			node.ForEachChild(func(child *ast.Node) bool { register(child); return false })
		case ast.KindModuleBlock:
			node.ForEachChild(func(child *ast.Node) bool { register(child); return false })
		case ast.KindFunctionDeclaration:
			if node.Name() == nil {
				return
			}
			symbol := l.symbol(node.Name())
			if len(node.TypeParameters()) > 0 {
				l.generics[symbol] = node
				return
			}
			index := len(l.result.Functions)
			l.functions[symbol] = index
			l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
			l.latentDeclarations[index] = node
		case ast.KindEnumDeclaration:
        if !ast.HasSyntacticModifier(node, ast.ModifierFlagsConst) {
            func() {
                defer func() { _ = recover() }()
                if local, err := l.enumLocal(node); err == nil { l.result.Locals[local].Global = true }
            }()
        }
		case ast.KindClassDeclaration:
			if node.Name() != nil {
				l.classes[l.symbol(node.Name())] = node
				func() {
					defer func() { _ = recover() }()
					if l.needsStatics(node) {
						if l.staticGlobals == nil {
							l.staticGlobals = map[*ast.Symbol]int{}
						}
						if local, err := l.declareLocal(node.Name()); err == nil {
							l.result.Locals[local].Global = true
							l.staticStorage(node)
						}
					}
				}()
			}
		case ast.KindVariableStatement:
			for _, declaration := range node.AsVariableStatement().DeclarationList.AsVariableDeclarationList().Declarations.Nodes {
				names := []*ast.Node{declaration.Name()}
				if declaration.Name().Kind == ast.KindArrayBindingPattern || declaration.Name().Kind == ast.KindObjectBindingPattern {
					names = nil
					for _, binding := range declaration.Name().AsBindingPattern().Elements.Nodes {
						if !skipped(binding) {
							names = append(names, binding.Name())
						}
					}
				}
				for _, name := range names {
					if ast.IsIdentifier(name) {
						// Registration errors are contextual, not a finding in every unrelated unit.
						func() {
							defer func() { _ = recover() }()
							if local, err := l.declareLocal(name); err == nil {
								l.result.Locals[local].Global = true
							}
						}()
					}
				}
			}
		}
	}
	for _, file := range files {
		for _, node := range file.Statements.Nodes {
			register(node)
		}
	}
}

// Latent attempts each eligible top-level unit independently. A returned error never
// stops the next unit. No function with a checker diagnostic in its body is lowered.
func Latent(ctx context.Context, program *load.Program, emit func(LatentFile)) {
	if latentSpeculativeEnabled() {
		latentSpeculative(ctx, program, emit)
		return
	}
	if latentFullEnabled() {
		latentFull(ctx, program, emit)
		return
	}
	for _, file := range program.Files() {
		latentFindings = nil
		latentFindingOwner, latentFindingPhase = program.Where(file.AsNode()), "refusal_scan"
		record := LatentFile{Measurement: LatentMeasurementLabel, File: program.FileName(file), Declarations: latentDeclarations(program, file), Units: []LatentUnit{}}
		checker, release := program.Checker(ctx, file)
		fresh := func() *lowering {
			return &lowering{program: program, checker: checker, result: &ir.Program{}, this: -1, functionIndex: -1}
		}
		func() {
			defer func() {
				if failure := recover(); failure != nil {
					latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(file.AsNode()), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
				}
			}()
			latentRecord(fresh().latentRefuse(file))
		}()
		for _, node := range file.Statements.Nodes {
			latentFindingOwner, latentFindingPhase = program.Where(node), "lowering"
			unit := LatentUnit{Measurement: LatentMeasurementLabel, Where: program.Where(node), Kind: node.Kind.String(), Status: "attempted", CheckerDiagnostics: []string{}}
			if node.Kind == ast.KindFunctionDeclaration {
				if body := node.Body(); body != nil {
					unit.BodyStart, unit.BodyEnd = body.Pos(), body.End()
					unit.CheckerDiagnostics = program.LatentDiagnosticsIn(body)
					if unit.CheckerDiagnostics == nil {
						unit.CheckerDiagnostics = []string{}
					}
					if len(unit.CheckerDiagnostics) > 0 {
						unit.Status = "skipped_checker_body"
						record.Units = append(record.Units, unit)
						continue
					}
				}
			}
			func() {
				defer func() {
					if failure := recover(); failure != nil {
						unit.Status = "panic"
						latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(node), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
					}
				}()
				l := fresh()
				l.noteInheritance(program.Files())
				l.noteAccessorNames(program.Files())
				l.latentRegister(program.Files())
				if node.Kind == ast.KindFunctionDeclaration && node.Name() != nil && node.Name().Text() == os.Getenv("LATENT_MUTANT_FUNCTION") && (os.Getenv("LATENT_MUTANT_WHERE") == "" || program.Where(node) == os.Getenv("LATENT_MUTANT_WHERE")) {
					latentRecord(l.notYet(node, "latent planted extra NotYet"))
				}
				if node.Kind == ast.KindFunctionDeclaration {
					if node.Name() == nil {
						latentRecord(l.notYet(node, "an anonymous top-level function"))
						return
					}
					index, found := l.functions[l.symbol(node.Name())]
					if !found {
						index = len(l.result.Functions)
						l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
						l.functions[l.symbol(node.Name())] = index
					}
					// Attempt generic declarations as written, without invented instantiations.
					latentRecord(l.lowerFunction(index, node, -1))
				} else {
					_, err := l.statement(node)
					latentRecord(err)
				}
				latentRecord(l.unlowerable)
			}()
			record.Units = append(record.Units, unit)
		}
		release()
		seen := map[LatentFinding]bool{}
		record.Findings = []LatentFinding{}
		for _, finding := range latentFindings {
			if !seen[finding] {
				record.Findings = append(record.Findings, finding)
				seen[finding] = true
			}
		}
		emit(record)
	}
}
