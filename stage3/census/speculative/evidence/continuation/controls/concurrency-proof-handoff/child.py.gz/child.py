#!/usr/bin/env python3
import fcntl,json,os,sys,time
from pathlib import Path
state=Path(os.environ['RETRY_WITNESS'])
def change(delta):
 with Path(str(state)+'.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  data=json.loads(state.read_text()) if state.exists() else dict(active=0,peak=0,total=0)
  data['active']+=delta
  if delta>0:data['total']+=1
  data['peak']=max(data['peak'],data['active'])
  state.write_text(json.dumps(data))
change(1)
time.sleep(1)
source=Path(os.environ['LATENT_ONLY_FILE'])
Path(sys.argv[2]).write_text(json.dumps(dict(latent_mode='speculative'))+'\n'+json.dumps(dict(file=str(source),findings=[],speculative_coverage=dict(source_bytes=source.stat().st_size,unvisited_nodes=0)))+'\n')
change(-1)
