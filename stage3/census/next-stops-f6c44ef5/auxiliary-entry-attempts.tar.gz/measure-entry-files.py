#!/usr/bin/env python3
"""Checkpoint native full-entry measurement at each selected source file."""
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import threading
import time

out = Path(__file__).resolve().parent
sources = json.loads((out / 'graph-order.json').read_text())
entry = '/tmp/next-stops-f6c44ef5/adapted/src/tsc/tsc.ts'
binary = '/tmp/next-stops-f6c44ef5/entry-census'
root = out / 'tsc-full-files'
root.mkdir(exist_ok=True)
manifest = [{'index':i,'file':name,'directory':f'{i:03d}'} for i,name in enumerate(sources)]
(root / 'selection.json').write_text(json.dumps(manifest,indent=2)+'\n')
work = queue.Queue()
for item in sorted(manifest,key=lambda x:(-Path(x['file']).stat().st_size,x['index'])):
    work.put(item)
lock = threading.Lock()
active = {}
failures = []
stopped = threading.Event()

def event(value):
    with lock:
        print(json.dumps(value),flush=True)

def terminate_all(signum=None, frame=None):
    stopped.set()
    with lock:
        running = list(active.values())
    for proc in running:
        if proc.poll() is None:
            proc.terminate()

def validate(directory, name):
    rows = [json.loads(x) for x in (directory/'latent.jsonl').read_text().splitlines()]
    assert len(rows)==2 and rows[0]['latent_mode']=='full'
    assert not rows[0]['checker_rejected'] and not rows[0]['diagnostics']
    assert set(rows[0]['sources'])==set(sources) and rows[0]['roots']==[entry]
    assert rows[1]['file']==name and rows[1]['measurement']==rows[0]['measurement']


def worker():
    while not stopped.is_set():
        try:
            item=work.get_nowait()
        except queue.Empty:
            return
        directory=root/item['directory']
        directory.mkdir(exist_ok=True)
        name=item['file']
        (directory/'files.txt').write_text(name+'\n')
        if (directory/'exit.txt').exists() and (directory/'exit.txt').read_text().strip()=='0':
            try:
                validate(directory,name)
                event({'file':name,'status':'reused complete record'})
                continue
            except Exception:
                pass
        env=os.environ.copy()
        env.update(LATENT_FULL='1',LATENT_ASSERT_NO_OUTPUT='1',LATENT_ONLY_FILE=name,
                   LATENT_TIMES=str(directory/'times.jsonl'))
        started=time.monotonic()
        (directory/'started.txt').write_text(time.strftime('%FT%TZ',time.gmtime())+'\n')
        with (directory/'latent.log').open('w') as log:
            proc=subprocess.Popen([binary,entry,str(directory/'latent.jsonl')],env=env,stdout=log,stderr=subprocess.STDOUT)
            with lock:
                active[item['index']]=proc
            if stopped.is_set():
                proc.terminate()
            event({'file':name,'pid':proc.pid,'status':'started'})
            try:
                code=proc.wait(timeout=5400)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill();proc.wait()
                code=124
            finally:
                with lock:
                    active.pop(item['index'],None)
        (directory/'exit.txt').write_text(str(code)+'\n')
        status={'file':name,'pid':proc.pid,'exit':code,'wall_seconds':time.monotonic()-started}
        if code==0:
            try:
                validate(directory,name)
                status['complete']=True
            except Exception as error:
                status.update(complete=False,validation_error=repr(error))
        else:
            status['complete']=False
        (directory/'status.json').write_text(json.dumps(status,indent=2)+'\n')
        if not status['complete']:
            with lock:
                failures.append(status)
        event(status)

signal.signal(signal.SIGTERM,terminate_all)
signal.signal(signal.SIGINT,terminate_all)
threads=[threading.Thread(target=worker,daemon=True) for _ in range(3)]
for thread in threads:
    thread.start()
deadline=time.monotonic()+6300
while any(thread.is_alive() for thread in threads):
    if time.monotonic()>=deadline:
        terminate_all()
    for thread in threads:
        thread.join(timeout=0.2)
if stopped.is_set():
    raise SystemExit(124)
if failures:
    raise SystemExit(1)
print('All 81 source-file records complete and validated.',flush=True)
