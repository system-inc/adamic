#!/usr/bin/env python3
"""Validate complete native entry observations and prepare the meter input."""
import json
from pathlib import Path
import sys

out = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ('whole', 'parts', 'files')
if mode == 'whole':
    inputs = [out / 'tsc-full']
elif mode == 'parts':
    inputs = sorted((out / 'tsc-full-parts').glob('part-*'))
else:
    inputs = sorted((out / 'tsc-full-files').glob('[0-9][0-9][0-9]'))
order = json.loads((out / 'graph-order.json').read_text())
header = None
header_line = None
records = {}
coverage = []
for directory in inputs:
    assert (directory / 'exit.txt').read_text().strip() == '0', directory
    lines = (directory / 'latent.jsonl').read_bytes().splitlines(keepends=True)
    h = json.loads(lines[0])
    assert h['status'] == 'measurement' and h['latent_mode'] == 'full' and not h['checker_rejected']
    assert not h['diagnostics'] and h['measurement'] == 'measured on a checker-clean entry-root program'
    if header is None:
        header, header_line = h, lines[0]
    else:
        assert h == header, 'entry graph or measurement headers differ'
    seen = set()
    for line in lines[1:]:
        row = json.loads(line)
        name = row['file']
        assert name not in records and name not in seen, 'duplicate source record'
        assert row['measurement'] == h['measurement']
        records[name] = line
        seen.add(name)
    selected = set((directory / 'files.txt').read_text().splitlines()) if mode != 'whole' else set(h['sources'])
    assert seen == selected, 'incomplete selected-file coverage'
    assert [json.loads(line)['file'] for line in lines[1:]] == [f for f in order if f in selected], 'native file order differs'
    coverage.append({'directory':str(directory.relative_to(out)), 'files':len(seen)})
assert header is not None and len(header['sources']) == 81
assert set(records) == set(header['sources']) == set(order), 'incomplete resolved entry coverage'
legacy_header = json.loads((out / 'tsc/latent.jsonl').read_text().splitlines()[0])
for key in ('roots', 'sources', 'diagnostics', 'checker_rejected'):
    assert legacy_header[key] == header[key], 'legacy and full graph headers differ'
legacy = out / 'tsc-first-error'
legacy.mkdir(exist_ok=True)
for name in ('latent.jsonl', 'latent.log', 'supervision.log'):
    p = out / 'tsc' / name
    if p.exists():
        assert not (legacy / name).exists()
        p.rename(legacy / name)
if mode == 'whole':
    (out / 'tsc/latent.jsonl').write_bytes((inputs[0] / 'latent.jsonl').read_bytes())
else:
    with (out / 'tsc/latent.jsonl').open('wb') as stream:
        stream.write(header_line)
        for name in order:
            stream.write(records[name])
(out / 'entry-preparation.json').write_text(json.dumps({
    'mode':'full', 'source':'unsplit full run' if mode=='whole' else ('native selected-file groups' if mode=='parts' else 'native single-source jobs'),
    'complete':True, 'source_files':81, 'coverage':coverage,
    'merge_order':'native resolved-source order; each original JSONL record is copied byte-for-byte',
    'instantiation_witness_scope':'per selected-file job; metadata not used by the artifact rule',
    'ordinary_census_modified':False,
    'legacy_first_error_status':'stopped at 105-minute bound; incomplete; not used for classification'
},indent=2)+'\n')
print('Validated complete full entry coverage: 81 source records, one identical graph header.')
