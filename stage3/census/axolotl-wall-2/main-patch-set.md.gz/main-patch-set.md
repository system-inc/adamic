# Patch set

Compared with the pinned pristine tree after upstream diagnostic generation.
Rows measure incremental edits; total measures the final tree against pristine.

| Adaptation | Files | Lines added | Lines removed |
|---|---:|---:|---:|
| 00-setup | 0 | 0 | 0 |
| 10-type-imports | 73 | 3720 | 3720 |
| 20-optional-declarations | 25 | 399 | 399 |
| 30-indexed-reads | 11 | 209 | 209 |
| 31-indexed-reads-checker | 1 | 394 | 394 |
| 32-indexed-reads-program | 20 | 132 | 132 |
| 33-indexed-reads-emit | 16 | 119 | 119 |
| 40-explicit-any | 18 | 107 | 107 |
| 41-explicit-any-remaining | 8 | 25 | 22 |
| 42-scanner-any | 1 | 1 | 1 |
| 43-any-returns | 2 | 14 | 9 |
| 44-config-generics | 1 | 16 | 16 |
| 45-regex-captures | 5 | 12 | 10 |
| 46-fix-pragma-empty-argument | 1 | 1 | 1 |
| 47-host-errors | 3 | 16 | 5 |
| 48-memoize | 1 | 2 | 2 |
| 49-honest-optionals | 4 | 147 | 144 |
| 50-temporary-scanner-implicit-returns | 1 | 2 | 0 |
| 51-temporary-scanner-fallthrough | 0 | 0 | 0 |
| 52-json-values | 13 | 268 | 65 |
| 60-temporary-factory-local-symbol | 1 | 1 | 1 |
| 61-temporary-factory-type-expression | 1 | 1 | 1 |
| 62-temporary-tracing-write | 1 | 1 | 1 |
| 63-temporary-tracing-legend | 1 | 1 | 1 |
| 64-temporary-parser-range-read | 1 | 1 | 1 |
| 65-temporary-node-builtins | 2 | 7 | 2 |
| 70-readonly-views | 7 | 22 | 22 |
| 71-writable-views | 20 | 88 | 88 |
| 75-optional-widening | 1 | 16 | 5 |
| 76-truthful-casts | 1 | 1 | 1 |
| 78-variance-marker | 1 | 1 | 1 |
| 79-exit-code | 8 | 9 | 9 |
| 90-void-widening | 7 | 66 | 66 |
| 91-patcher-discard | 2 | 2 | 2 |
| 92-tty-host-results | 1 | 2 | 2 |
| 95-checker-axolotl-a | 1 | 13 | 13 |
| 95-checker-axolotl-b | 1 | 7 | 7 |
| 95-checker-axolotl-c | 2 | 3 | 3 |
| 95-checker-axolotl-d | 1 | 1 | 1 |
| 95-checker-axolotl-e | 1 | 2 | 2 |
| 95-checker-axolotl-f | 1 | 1 | 0 |
| 95-checker-axolotl-g | 1 | 11 | 1 |
| 95-checker-axolotl-h | 1 | 4 | 4 |
| 96-emit-axolotl-a | 1 | 14 | 14 |
| 96-emit-axolotl-b | 1 | 2 | 2 |
| 96-emit-axolotl-c | 1 | 19 | 19 |
| 97-cli-axolotl-a | 1 | 1 | 1 |
| 97-cli-axolotl-b | 3 | 12 | 12 |
| 97-cli-axolotl-c | 1 | 2 | 2 |
| 97-cli-axolotl-d | 4 | 24 | 24 |
| 98-axolotl-a | 2 | 8 | 8 |
| 98-axolotl-b | 1 | 5 | 5 |
| 98-axolotl-d | 5 | 13 | 10 |
| 99-correctness-axolotl-a | 4 | 12 | 12 |
| 99-correctness-axolotl-b | 1 | 1 | 1 |
| 99-correctness-axolotl-e | 1 | 4 | 2 |
| 99-correctness-axolotl-f | 5 | 27 | 8 |
| 99-correctness-axolotl-g | 1 | 4 | 3 |
| 99-correctness-axolotl-h | 1 | 5 | 5 |
| **Total** | 93 | 5984 | 5703 |
