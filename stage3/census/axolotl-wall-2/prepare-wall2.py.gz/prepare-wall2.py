import subprocess,pathlib,json,re,os
base=pathlib.Path('/workspace/scratch'); repo=pathlib.Path('/workspace/adamic')
heads=[('94','8a7cd267b434efa0a60d481529a1256cc3c92a19','94-axolotl-property-read'),('98-c','3fb2903296db936eef4147d19d5d252fa224bb2e','98-axolotl-c'),('98-e','fcce3b29a4bc2fc1b73f73307a1a3a56c3c3a0a977','98-axolotl-e')]
heads[2]=('98-e','fcce3b29a4bc2fc1b73f73307a1a3a56c3a0a977','98-axolotl-e')
heads += [('97e','555addc2d789788866de4c5550ccc5c85be6ec67','97-cli-axolotl-e'),('99d','cc2bfae014073a16ba9c54712f67b372e2c76429','99-correctness-axolotl-d'),('99c','820d57df8395a56359c8eec0c3e109b8d7d27226','99-correctness-axolotl-c')]
(base/'heads.json').write_text(json.dumps(heads,indent=2)+'\n')
def run(args,cwd,label,env=None):
 with (base/(label+'.log')).open('w') as log: subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
for name,sha,d in heads:
 run(['git','checkout',sha,'--','stage3/adapt/'+d],base/'wall2-composed','checkout-'+name)
 (base/('README-'+name+'.md')).write_bytes(subprocess.check_output(['git','show',sha+':stage3/adapt/'+d+'/README.md'],cwd=repo))
p=base/'wall2-composed/stage3/upstream/LEDGER.md'
old=p.read_text(); entry=subprocess.check_output(['git','show','555addc2:stage3/upstream/LEDGER.md'],cwd=repo,text=True).split('\n## 7. ',1)[1]
n=max(map(int,re.findall(r'^## (\d+)\.',old,re.M)))+1
p.write_text(old.rstrip()+'\n\n## '+str(n)+'. '+entry)
run(['git','clone','--depth','1','--branch','v6.0.3','https://github.com/microsoft/TypeScript.git',str(base/'wall2-upstream')],repo,'upstream')
for label in ['main','composed']:
 tree=base/('wall2-'+label)
 if label=='main':
  run(['git','-c','protocol.file.allow=always','submodule','update','--init','--recursive','--depth','1'],tree,'submodules-main')
 run(['npm','ci','--ignore-scripts','--no-audit','--no-fund'],tree/'stage3/api','packages-'+label)
 env=dict(os.environ,ADAMIC_TYPESCRIPT_SOURCE=str(base/'wall2-upstream'),GOPROXY='https://proxy.golang.org|direct')
 run(['bash','stage3/apply.sh',str(base/('wall2-'+label+'-adapted'))],tree,'apply-'+label,env)
print('PREPARATION COMPLETE',flush=True)
