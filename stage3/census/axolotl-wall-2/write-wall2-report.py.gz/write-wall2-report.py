import pathlib,json,gzip,hashlib,subprocess,html,shutil,datetime
b=pathlib.Path('/workspace/scratch'); out=b/'wall2-results'; repo=b/'wall2-report';dest=repo/'stage3/census/axolotl-wall-2';dest.mkdir(parents=True,exist_ok=True)
prov=json.loads((out/'provenance.json').read_text());heads=prov['heads']
def esc(s):return html.escape(str(s),quote=False).replace('|','&#124;').replace('\n','<br>')
lines=['# Axolotl checker wall after waves 1 through 7','', 'Measured '+datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d UTC')+'. Main is pinned at `'+prov['origin_main']+'`. The report branch has that commit as its sole parent.','', '## Headline','', '| Measure | Main | Main plus six accepted heads |','| --- | ---: | ---: |']
for key,title in [('source_files','Sorted compiler roots'),('checker_own_file','Files past checker, own file'),('checker_whole_program','Files past checker, whole program including imports'),('lowering','Ordinary successful lowering roots')]:
 vals=[]
 for label in ['main','composed']:
  report=json.loads((out/label/'report.json').read_text());t=report['totals']; vals.append('not measured: census panic' if t[key] is None else str(t[key]) if key=='source_files' else str(t[key])+'/'+str(t['source_files']))
 lines.append('| '+title+' | '+' | '.join(vals)+' |')
for title,fn in [('Whole-program diagnostics',lambda ds:sum(d['whole_program'] for d in ds)),('Distinct diagnostics across own-root observations',len),('New diagnostics across own-root observations',lambda ds:sum(d['new'] for d in ds))]:
 lines.append('| '+title+' | '+' | '.join(str(fn(json.loads((out/l/'diagnostics-matched.json').read_text()))) for l in ['main','composed'])+' |')
lines += ['', '## Measurement and matching','', 'The CLI passes all 79 sorted `.ts` and `.a` roots recursively under `src/compiler` to `adamic types`, with unmodified stage-0 checker options and prelude. On main the ordinary census loads each file as its own root and the same 79-root aggregate; its full diagnostic multiset agrees with the CLI, including elaboration chains. On the composed tree, the ordinary census panics before producing its first record. The unchanged CLI therefore checks each of the 79 singleton roots to complete the checker-only census; each stdout is retained compressed. The successful 79-root CLI remains the aggregate observation. Own-file attribution follows the meter: primary diagnostic location, deduplicating full strings across roots. JSON inputs fail the extension gate and are excluded from the denominator.','', 'Row IDs come from `typescript/axolotl-classify` at `'+prov['classification_commit']+'`, matched by file, code and source-line text with surrounding whitespace ignored. Duplicate source keys use exact full-message equality, then occurrence order only when original and final sites form a complete bijection. Old coordinates are not match keys. Unmatched rows are marked new.','', '**Owner-data limitation:** the exact pinned classification JSON has no `owner` field, and its Markdown diagnostic table has no Owner column. Therefore every classification owner is recorded as unavailable. The separate Head owner column uses the ownership supplied in this task, not an invented classification value. Head claims are read from each accepted README. 94 is a dependency helper and claims no diagnostic row directly.','']
for label,title in [('main','Main tip remaining diagnostics'),('composed','Composed remaining diagnostics')]:
 ds=json.loads((out/label/'diagnostics-matched.json').read_text()); whole=[d for d in ds if d['whole_program']]
 lines += ['## '+title,'',f'{len(whole)} whole-program diagnostics.','', '| Location | Code | Row id | Classification owner | Head owner | Claiming head | Full message |','| --- | --- | --- | --- | --- | --- | --- |']
 for d in whole:
  lines.append('| '+' | '.join([f"{d['file']}:{d['line']}:{d['column']}",'TS'+str(d['code']),', '.join(d['row_ids']) or 'new','unavailable',', '.join(d['head_owners']) or 'none',', '.join(d['heads']) or 'none',esc(d['message'])])+' |')
 if not whole:lines.append('| none | | | | | | |')
 extra=[d for d in ds if not d['whole_program']]
 if extra:
  lines += ['', 'Additional own-file union variants, absent from the aggregate:','', '| Location | Code | Row id | Head owner | Claiming head | Full message |','| --- | --- | --- | --- | --- | --- |']
  for d in extra:lines.append('| '+' | '.join([f"{d['file']}:{d['line']}:{d['column']}",'TS'+str(d['code']),', '.join(d['row_ids']) or 'new',', '.join(d['head_owners']) or 'none',', '.join(d['heads']) or 'none',esc(d['message'])])+' |')
 lines += ['', 'Matched source lines and resolution evidence are retained in `'+label+'-diagnostics-matched.json.gz`.','']
latentpath=out/'main/latent-summary.json'
lines+=['## Main latent lowering census','']
if latentpath.exists():
 s=json.loads(latentpath.read_text());t=s['totals'];commands=json.loads((out/'commands.json').read_text());cmd=next(r for r in commands if r['label']=='main/latent')
 lines += [f"Completed in {cmd['elapsed_seconds']:.3f} seconds. `LATENT_FULL=0 LATENT_ASSERT_NO_OUTPUT=1`, first-error mode, with a 5400-second timeout and 60-second kill grace. All {s['source_files']} compiler roots are covered. The no-output assertions succeeded.",'', f"Distinct NotYet: **{t['NotYet']}**. Distinct Refused: **{t['Refused']}**. Skipped dependency sites: {t['SkippedDependency']}. Errors: {t['error']}. Panics: {t['panic']}. Recovery boundaries: {s['boundaries']}. Recorded finding events: {s['recorded_events']}.",'','Measured on a checker-rejected program. Counts are unique `(kind, where, reason, text)` sites across attempts, using the pinned main meter\'s `latent_summary`. They do not establish successful lowering or native output.','', '| Reason | Owner | NotYet | Refused | Sites |','| --- | --- | ---: | ---: | ---: |']
 for row in s['reason_rows'][:10]:lines.append('| '+' | '.join([esc(row['reason']),esc(row['owner']),str(row['NotYet']),str(row['Refused']),str(row['count'])])+' |')
 lines += ['', 'Owners use the measured main `stage3/meter/owners.json`, its longest-prefix rule and variance-family override. OWNER BLANK means that mapping has no owner.','']
else:
 lines += ['The latent census did not complete. See `main-latent-progress.json.gz`, its raw JSONL and command return code for the stopping point. No complete latent totals are claimed.','']
lines += ['## Exact composition and adapter application','', '| Head | Commit | Directory |','| --- | --- | --- |']
for name,sha,d in heads:lines.append(f'| {name} | `{sha}` | `stage3/adapt/{d}` |')
lines += ['', '**Composed ordinary-census limitation:** its first root, `src/compiler/_namespaces/ts.moduleSpecifiers.ts`, triggers `panic: interface conversion: ast.nodeData is *ast.ClassExpression, not *ast.ClassDeclaration` in `internal/lower/namespaces.go:271`. Exit status is 2 and no ordinary census rows are emitted. No compiler source is patched. Composed lowering counts are unavailable; the complete checker-only CLI census supplies its diagnostics and checker file counts. The crash and command are retained raw.', '', 'Scratch worktrees were created from the pinned origin/main. Each directory was brought with `git checkout <sha> -- stage3/adapt/<directory>`, with no edits to the heads or their directories. Exact Git tree matches are verified in `composition-verification.json.gz`. 94 is included once. The 97e LEDGER.md entry is appended after main\'s last entry and numbered 7; no ledger or adaptation changes are included in this report commit. The scratch composition is never pushed.','', 'Both adapted trees are built by unmodified `stage3/apply.sh`, with the meter\'s pinned TypeScript v6.0.3 input, `'+prov['upstream_commit']+'`, and lockfile installation via `npm ci --ignore-scripts --no-audit --no-fund`. All adapters must have complete before/after refs and patch-table rows; `adapter-coverage.json.gz` retains the check. No checker, adapter, prelude, or tool source is modified. Both trees use the compiler built from pinned main and its recorded submodule pins.','', 'Setup ran with `GOPROXY=https://proxy.golang.org|direct` and `timeout --kill-after=60s 1800 bash cloud/setup.sh`, exit 0 in 576.935 seconds. Full logs are retained. The cloud runtime skill was used for environment and network readiness.','', '## Per-file census','']
for label in ['main','composed']:
 r=json.loads((out/label/'report.json').read_text());lines += ['### '+label,'','| File | Own file | Whole program | Lowering | Own diagnostics |','| --- | --- | --- | --- | ---: |']
 for row in r['files']:
  if not row['source']:continue
  lines.append('| '+' | '.join([row['file'],'pass' if row['checker_own_file'] else 'fail','pass' if row['checker_whole_program'] else 'fail','not measured' if label=='composed' else 'pass' if row['lowering'] else 'fail' if row['lowering_attempted'] else 'blocked',str(row['own_file_diagnostics'])])+' |')
lines += ['', '## Raw evidence','', 'Raw CLI, census and latent outputs are gzipped beside this report, together with command arguments, statuses, UTC starts, elapsed times, source hashes, matching input/output, adapter coverage, patch tables, submodule pins, binary hashes, build/setup/apply logs, scripts and provenance. Main CLI/aggregate equality, complete 79-root checker coverage on both trees, row matching, source immutability and exact adapter directory matches are checked. Complete latent coverage is verified when that census finishes; an incomplete run is labeled explicitly. `SHA256SUMS` covers every report artifact.','']
report='\n'.join(lines);assert '\u2014' not in report and '\u2013' not in report
(dest/'REPORT.md').write_text(report)
def pack(src,name=None):
 if src.exists() and src.is_file():
  (dest/((name or src.name) if src.suffix=='.gz' else (name or src.name)+'.gz')).write_bytes(src.read_bytes() if src.suffix=='.gz' else gzip.compress(src.read_bytes(),mtime=0))
for p in out.rglob('*'):
 if p.is_file():pack(p,str(p.relative_to(out)).replace('/','-'))
for n in ['setup.log','fetch.log','fetch-heads.log','prepare.log','upstream.log','submodules-main.log','packages-main.log','packages-composed.log','apply-main.log','apply-composed.log','classification.json','classification.md','heads.json','composition-verification.json','prepare-wall2.py','build-wall2.py','measure-main-wall2.py','measure-composed-wall2.py','analyze-wall2.py','write-wall2-report.py','analyze.log','build-driver.log','measure-main-driver.log','measure-composed-driver.log','check-composed-wall2.py','check-composed-driver.log','verify-wall2.py','verify.log']:
 pack(b/n)
for name,sha,d in heads:pack(b/('README-'+name+'.md'))
for l in ['main','composed']:pack(b/('wall2-'+l+'-adapted/patch-set.md'),l+'-patch-set.md')
(dest/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(dest.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(dest/'REPORT.md')
