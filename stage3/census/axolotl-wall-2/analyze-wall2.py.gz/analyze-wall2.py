import pathlib,json,re,importlib.util,collections,sys
b=pathlib.Path('/workspace/scratch'); repo=b/'wall2-main'; out=b/'wall2-results'
spec=importlib.util.spec_from_file_location('meter',repo/'stage3/meter/report.py'); meter=importlib.util.module_from_spec(spec); spec.loader.exec_module(meter)
rows=json.loads((b/'classification.json').read_text())
pat=re.compile(r'^(.+?):(\d+):(\d+): error TS(\d+): (.*)',re.S)
claims={'D032':['99d'],'D033':['99c'],'D034':['99c'],'D035':['99c'],'D041':['97e'],'D042':['97e'],'D054':['98-c'],'D055':['98-c'],'D056':['98-e'],'D057':['98-c']}
headowners={'99d':'Correctness','99c':'Correctness','97e':'CLI','98-c':'Performance','98-e':'Performance','94':'Compiler'}
def parse(s):
 m=pat.match(s); assert m,s
 f,l,c,code,msg=m.groups(); f=meter.site_where(str(pathlib.Path(f).resolve()))
 return dict(file=f,line=int(l),column=int(c),code=int(code),message=msg)
def norm(s):
 d=parse(s);return tuple(d[k] for k in ['file','line','column','code','message'])
for label in ['main','composed']:
 run=out/label; tree=b/('wall2-'+label+'-adapted')
 dataset=run/('checker-only.jsonl' if label=='composed' else 'census.jsonl')
 if not dataset.exists():continue
 records=[json.loads(s) for s in dataset.read_text().splitlines()]
 if len(records)<80:continue
 raw=(run/'types.stderr').read_text(); starts=list(re.finditer(r'^.+?:\d+:\d+: error TS\d+:',raw,re.M))
 direct=[raw[m.start():starts[i+1].start() if i+1<len(starts) else len(raw)].rstrip('\n') for i,m in enumerate(starts)]
 assert collections.Counter(map(norm,direct))==collections.Counter(map(norm,records[-1].get('diagnostics',[]))), 'CLI and aggregate disagree'
 union={norm(s):s for rec in records for s in rec.get('diagnostics',[])}; diags=[]
 for k,s in sorted(union.items()):
  d=parse(s); source=(tree/d['file']).read_text().splitlines()[d['line']-1];d['source_line']=source
  matches=[r for r in rows if (r['file'],r['code'],r['source_line'].strip())==(d['file'],d['code'],source.strip())]
  d['source_key_candidates']=[r['id'] for r in matches];resolution='unique file/code/source-text key'
  if len(matches)>1:
   exact=[r for r in matches if r['message']==d['message']]
   if exact:matches=exact;resolution='source-text key plus exact full message'
  if len(matches)>1 and len({r['line'] for r in matches})==len(matches):
   locations=[i+1 for i,text in enumerate((tree/d['file']).read_text().splitlines()) if text.strip()==source.strip()];original=sorted(matches,key=lambda r:r['line'])
   assert len(locations)==len(original),(d,locations,original)
   matches=[original[locations.index(d['line'])]];resolution='source-text key plus occurrence order (complete bijection)'
  assert len(matches)<=1,('ambiguous classification',d,matches)
  d.update(row_ids=[r['id'] for r in matches],classification=matches,new=not matches,whole_program=k in set(map(norm,direct)),match_resolution=resolution)
  d['classification_owner']=matches[0].get('owner','unavailable: pinned classification has no owner column') if matches else 'new'
  d['heads']=claims.get(matches[0]['id'],[]) if matches else []
  d['head_owners']=[headowners[h] for h in d['heads']]
  diags.append(d)
 (run/'diagnostics-matched.json').write_text(json.dumps(diags,indent=2)+'\n')
 print(label,json.dumps(dict(whole=len(direct),union=len(diags),new=sum(d['new'] for d in diags),rows=[d['row_ids'] for d in diags],totals=json.loads((run/'report.json').read_text())['totals'])))
run=out/'main';tree=b/'wall2-main-adapted'
if (run/'latent.jsonl').exists() and '--latent' in sys.argv:
 latent_records=[json.loads(line) for line in (run/'latent.jsonl').read_text().splitlines()]
 census_records=[json.loads(line) for line in (run/'census.jsonl').read_text().splitlines()]
 assert latent_records[0]['checker_rejected'] is True
 assert collections.Counter(map(norm,latent_records[0]['diagnostics']))==collections.Counter(map(norm,census_records[-1]['diagnostics'])), 'latent and CLI diagnostics disagree'
 latent=meter.latent_summary(tree,run)
 assert latent['latent_mode']=='first-error' and latent['source_files']==79
 (run/'latent-summary.json').write_text(json.dumps(latent,indent=2)+'\n')
 print('latent',json.dumps({k:latent[k] for k in ['totals','source_files','recorded_events','reason_rows']}))
