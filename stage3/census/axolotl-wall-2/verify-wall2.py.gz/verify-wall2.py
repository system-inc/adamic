import pathlib,subprocess,json,hashlib
b=pathlib.Path('/workspace/scratch');out=b/'wall2-results';result={}
for label in ['main','composed']:
 repo=b/('wall2-'+label);tree=b/('wall2-'+label+'-adapted')
 dirs=sorted(p.name for p in (repo/'stage3/adapt').iterdir() if p.is_dir())
 refs=subprocess.check_output(['git','for-each-ref','--format=%(refname) %(objectname)','refs/stage3/'],cwd=tree,text=True).splitlines()
 refs=dict(x.split() for x in refs)
 table=(tree/'patch-set.md').read_text(); coverage=[]
 for d in dirs:
  before=refs['refs/stage3/'+d+'-before'];after=refs['refs/stage3/'+d+'-after'];assert '| '+d+' |' in table
  coverage.append(dict(adapter=d,before=before,after=after,table_row=True))
 hashes=json.loads((out/label/'source-sha256.json').read_text())
 assert hashes=={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()}
 result[label]={'all_adapters_applied':True,'count':len(dirs),'adapters':coverage,'sources_unchanged':True}
assert result['composed']['count']==result['main']['count']+6
(out/'adapter-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:{f:v[f] for f in ['count','all_adapters_applied','sources_unchanged']} for k,v in result.items()})
