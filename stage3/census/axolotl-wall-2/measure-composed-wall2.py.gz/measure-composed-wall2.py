import pathlib,subprocess,json,os,time,hashlib
b=pathlib.Path('/workspace/scratch'); repo=b/'wall2-main'; out=b/'wall2-results'; out.mkdir(exist_ok=True)
commands=[]
def run(label,args,cwd=repo,env=None):
 start=time.time()
 with (out/(label+'.stdout')).open('w') as o,(out/(label+'.stderr')).open('w') as e:
  p=subprocess.run(args,cwd=cwd,stdout=o,stderr=e,env=env)
 commands.append(dict(label=label,args=list(map(str,args)),cwd=str(cwd),returncode=p.returncode,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start))
 (out/'composed-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return p.returncode
def good(label,args,**kw):
 rc=run(label,args,**kw); assert rc==0,(label,rc)
commands=[]
for label in ['composed']:
 tree=b/('wall2-'+label+'-adapted'); dest=out/label; dest.mkdir(exist_ok=True)
 roots=sorted(str(p) for p in (tree/'src/compiler').rglob('*') if p.is_file() and p.suffix in ('.ts','.a'))
 assert len(roots)==79,len(roots)
 (dest/'roots.json').write_text(json.dumps(roots,indent=2)+'\n')
 hashes={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()}
 (dest/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
 assert run(label+'/types',[str(b/'wall2-adamic'),'types',*roots]) in (0,1)
 good(label+'/census',[str(b/'wall2-census'),str(tree/'src/compiler'),str(dest/'census.jsonl')])
 good(label+'/meter-report',['python3','stage3/meter/report.py',str(tree),str(dest),time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())])
 assert hashes=={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()}
print('COMPOSED CHECKS COMPLETE',flush=True)
