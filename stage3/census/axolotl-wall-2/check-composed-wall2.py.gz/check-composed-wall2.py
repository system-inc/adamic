import pathlib,subprocess,gzip,json,time,hashlib
b=pathlib.Path('/workspace/scratch');out=b/'wall2-results';dest=out/'composed';tree=b/'wall2-composed-adapted';roots=json.loads((dest/'roots.json').read_text());records=[];commands=[]
for i,root in enumerate(roots):
 start=time.time();args=[str(b/'wall2-adamic'),'types',root];h=hashlib.sha256();n=0
 with (dest/('own-types-'+str(i).zfill(2)+'.stdout.gz')).open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as z, (dest/'own-types-current.stderr').open('wb') as err:
  p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=err)
  while True:
   chunk=p.stdout.read(1024*1024)
   if not chunk:break
   z.write(chunk);h.update(chunk);n+=len(chunk)
  rc=p.wait()
 stderr=(dest/'own-types-current.stderr').read_text();assert rc in [0,1],(rc,stderr)
 starts=[]
 import re
 starts=list(re.finditer(r'^.+?:\d+:\d+: error TS\d+:',stderr,re.M))
 diagnostics=[stderr[m.start():starts[j+1].start() if j+1<len(starts) else len(stderr)].rstrip('\n') for j,m in enumerate(starts)]
 assert (rc==0)==(len(diagnostics)==0),(rc,stderr)
 record=dict(roots=[root],diagnostics=diagnostics,kind='checker' if rc else 'checker-clean',seconds=time.time()-start,raw_stderr=stderr)
 records.append(record);commands.append(dict(args=args,returncode=rc,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start,stdout_bytes=n,stdout_sha256=h.hexdigest()))
 (dest/'checker-only.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records));(out/'composed-own-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print(i+1,len(roots),rc,root,flush=True)
rows=[];located=set()
for r in records:
 for d in r['diagnostics']:
  m=re.match(r'^(.+?):\d+:\d+: error TS\d+:',d);assert m,d
  located.add(m[1])
for r in records:
 root=r['roots'][0];rows.append(dict(file=str(pathlib.Path(root).relative_to(tree)),source=True,checker=r['kind']=='checker-clean',checker_whole_program=r['kind']=='checker-clean',checker_own_file=root not in located,own_file_diagnostics=sum(d.startswith(root+':') for x in records for d in x['diagnostics']),lowering=False,lowering_attempted=False,outcome='not measured: ordinary census panicked'))
result=dict(totals=dict(files=79,source_files=79,checker=sum(r['checker'] for r in rows),checker_whole_program=sum(r['checker'] for r in rows),checker_own_file=sum(r['checker_own_file'] for r in rows),lowering=None),files=rows,whole_program_diagnostics=0,measurement='CLI checker-only fallback after ordinary census lowering panic')
(dest/'report.json').write_text(json.dumps(result,indent=2)+'\n')
# A distinct checker-only dataset retains each singleton and the successful aggregate.
whole=dict(roots=roots,kind='checker-clean',diagnostics=[],seconds=next(r['elapsed_seconds'] for r in json.loads((out/'composed-commands.json').read_text()) if r['label']=='composed/types'))
(dest/'checker-only.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records+[whole]))
print('COMPOSED OWN-FILE CHECKS COMPLETE',flush=True)
