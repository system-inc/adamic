import pathlib,subprocess,json,os,time,hashlib
b=pathlib.Path('/workspace/scratch'); repo=b/'wall2-main'; out=b/'wall2-results'; out.mkdir(exist_ok=True)
commands=[]
def run(label,args,cwd=repo,env=None):
 start=time.time()
 with (out/(label+'.stdout')).open('w') as o,(out/(label+'.stderr')).open('w') as e:
  p=subprocess.run(args,cwd=cwd,stdout=o,stderr=e,env=env)
 commands.append(dict(label=label,args=list(map(str,args)),cwd=str(cwd),returncode=p.returncode,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start))
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 return p.returncode
def good(label,args,**kw):
 rc=run(label,args,**kw); assert rc==0,(label,rc)
good('build-adamic',['go','build','-o',str(b/'wall2-adamic'),'./cmd/adamic'])
good('build-census',['go','build','-o',str(b/'wall2-census'),'./stage3/census/tool'])
good('latent-overlay',['python3','stage3/census/latent/make_overlay.py',str(repo),str(b/'wall2-latent-overlay')])
good('latent-gofmt',['gofmt','-w',*map(str,(b/'wall2-latent-overlay').glob('*.go'))])
good('entry-overlay',['python3','stage3/meter/entry_overlay.py',str(b/'wall2-latent-overlay'),str(b/'wall2-entry-overlay')])
good('entry-gofmt',['gofmt','-w',*map(str,(b/'wall2-entry-overlay').glob('*.go'))])
good('latent-build',['go','build','-buildvcs=false','-overlay='+str(b/'wall2-latent-overlay/overlay.json'),'-o',str(b/'wall2-latent-census'),'./stage3/census/latent/tool'])
good('entry-build',['go','build','-buildvcs=false','-overlay='+str(b/'wall2-entry-overlay/overlay.json'),'-o',str(b/'wall2-entry-census'),'./stage3/census/latent/tool'])
(out/'binaries.sha256').write_text(''.join(hashlib.sha256((b/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in ['wall2-adamic','wall2-census','wall2-latent-census','wall2-entry-census']))
