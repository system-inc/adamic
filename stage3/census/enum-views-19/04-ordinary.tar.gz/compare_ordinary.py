import collections,json
from pathlib import Path
w=Path('/workspace/scratch/ev19');records={}
for label,file,root in [('main','reference-main-ordinary.jsonl','/workspace/scratch/ro-before/'),('b2','ordinary.jsonl','/workspace/scratch/ev19/applied/')]:
 rows=[json.loads(line) for line in (w/file).read_text().splitlines()]
 selected=[r for r in rows if len(r['roots'])==1 and r['roots'][0].endswith('.ts')]
 assert len(selected)==79,(label,len(selected))
 def normalize(v):
  if isinstance(v,str):return v.replace(root,'')
  if isinstance(v,list):return [normalize(x) for x in v]
  if isinstance(v,dict):return {k:normalize(x) for k,x in v.items() if k!='seconds'}
  return v
 records[label]={normalize(r['roots'][0]):normalize(r) for r in selected}
assert records['main'].keys()==records['b2'].keys()
changes=[{'root':root,'main':a,'b2':records['b2'][root]} for root,a in records['main'].items() if a!=records['b2'][root]]
result={'main':'63e14a0b2b61cf251ad74292e42d5fd09af804b3','target':'9bdbe75ede31d9b18e49ae3a79843eeaa89c63d4','roots_each':79,'normalization':'remove only each tree prefix from all embedded strings; omit seconds','kinds':{label:dict(collections.Counter(r['kind'] for r in rows.values())) for label,rows in records.items()},'changed_first_stops':changes,'records':records}
(w/'ordinary-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
report=Path('/workspace/enum-views-19/stage3/census/enum-views-19/REPORT.md');s=report.read_text();s=s.replace('The separate ordinary 79-root census is still running. The separate B2 emitter','The ordinary 79-root comparison is complete; see below. The separate B2 emitter')
s+='\n## Ordinary 79-root compiler census\n\nThe ordinary production compiler driver ran independently on all 79 .ts roots.\nThree non-TypeScript file records and a whole-program record are preserved raw\nand excluded from this per-file comparison. Only tree prefixes and timings are\nnormalized; kind, location, reason, fix and any diagnostics are compared.\n\n| Kind | Main | B2 |\n| --- | ---: | ---: |\n'
for kind in sorted(set(result['kinds']['main'])|set(result['kinds']['b2'])):s+=f"| {kind} | {result['kinds']['main'].get(kind,0)} | {result['kinds']['b2'].get(kind,0)} |\n"
s+=f"\nChanged first stops: **{len(changes)}**.\n"
for c in changes:
 s+='\n### '+c['root']+'\n\n'
 for label in ['main','b2']:
  row=c[label];s+='- '+label+': '+row['kind']+' at `'+row.get('where','-')+'`: '+row.get('reason','-')+'\n'
if not changes:s+='\nEvery root retains its exact first stop or accepted outcome. There is no\nordinary per-file first-stop movement to attribute to the B2 stack.\n'
s+='\nThe raw census, full normalized per-root comparison and source hash audit are\nin 04-ordinary.tar.gz. The comparison baseline is the earlier pinned main, not\na claim about an unmeasured moving origin/main tip.\n'
report.write_text(s)
print(json.dumps({'roots_each':79,'kinds':result['kinds'],'changed_first_stops':changes},indent=2))
