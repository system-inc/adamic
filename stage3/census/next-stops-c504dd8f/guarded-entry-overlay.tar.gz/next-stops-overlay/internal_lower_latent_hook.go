// This file is compiled only through a scratch Go overlay.
package lower

import (
	"context"
	"errors"
	"fmt"
	"github.com/microsoft/TypeScript/tsc/shim/ast"
	"github.com/microsoft/TypeScript/tsc/shim/checker"
	"github.com/system-inc/adamic/internal/ir"
	"github.com/system-inc/adamic/internal/load"
	"github.com/system-inc/adamic/stage3/census/latent"
	"os"
	"time"
)

// A checker-diagnosed dependency is a measurement boundary, not a compiler blocker.
type LatentDependencySkipped struct{ Where string }

func (e *LatentDependencySkipped) Error() string {
	return "latent census: skipped checker-diagnosed dependency at " + e.Where
}

type LatentFinding struct {
	PieceAtom     string `json:"piece_atom,omitempty"`
	SiteWhere     string `json:"site_where,omitempty"`
	SiteKind      string `json:"site_kind,omitempty"`
	SiteStart     int    `json:"site_start,omitempty"`
	SiteEnd       int    `json:"site_end,omitempty"`
	RootKind      string `json:"root_kind"`
	Depth         int    `json:"depth"`
	BoundaryWhere string `json:"boundary_where,omitempty"`
	Measurement   string `json:"measurement"`
	Unit          string `json:"unit"`
	Phase         string `json:"phase"`
	Kind          string `json:"kind"`
	Where         string `json:"where"`
	Reason        string `json:"reason"`
	Text          string `json:"text"`
	Start         int    `json:"start,omitempty"`
	End           int    `json:"end,omitempty"`
}

// The measurement driver is sequential. Nothing returns usable IR.
var latentFindings []LatentFinding
var latentFindingOwner, latentFindingPhase string

func latentRecord(err error) {
	if err == nil {
		return
	}
	finding := LatentFinding{PieceAtom: latentPieceOrigin, Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "error", Text: err.Error()}
	var deferred *latentDeferredFailure
	if errors.As(err, &deferred) {
		finding.Phase = "deferred"
	}
	var refused *Refused
	var notYet *NotYet
	var skipped *LatentDependencySkipped
	switch {
	case errors.As(err, &skipped):
		finding.Kind, finding.Where, finding.Reason = "SkippedDependency", skipped.Where, "a dependency function whose body has checker diagnostics (measurement skipped)"
	case errors.As(err, &refused):
		finding.Kind, finding.Where, finding.Reason = "Refused", refused.Where, refused.What
	case errors.As(err, &notYet):
		finding.Kind, finding.Where, finding.Reason = "NotYet", notYet.Where, notYet.What
	default:
		finding.Reason = err.Error()
	}
	latentFindings = append(latentFindings, finding)
}

const LatentMeasurementLabel = "measured on a checker-rejected program"

type LatentUnit struct {
	Measurement        string   `json:"measurement"`
	Where              string   `json:"where"`
	Kind               string   `json:"kind"`
	BodyStart          int      `json:"body_start,omitempty"`
	BodyEnd            int      `json:"body_end,omitempty"`
	RelationOverflow   *string  `json:"relation_overflow,omitempty"`
	Instantiated       bool     `json:"instantiated"`
	Status             string   `json:"status"`
	CheckerDiagnostics []string `json:"checker_diagnostics"`
	Name               string   `json:"name,omitempty"`
	Parent             string   `json:"parent,omitempty"`
	Top                string   `json:"top,omitempty"`
	Depth              int      `json:"depth,omitempty"`
}

// Declaration spans add attribution only; they never change lowering eligibility.
type LatentDeclaration struct {
	Measurement string `json:"measurement"`
	Where       string `json:"where"`
	Name        string `json:"name"`
	Kind        string `json:"kind"`
	Start       int    `json:"start"`
	End         int    `json:"end"`
}

func latentDeclarations(program *load.Program, file *ast.SourceFile) []LatentDeclaration {
	result := []LatentDeclaration{}
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		switch node.Kind {
		case ast.KindFunctionDeclaration, ast.KindFunctionExpression, ast.KindMethodDeclaration,
			ast.KindVariableDeclaration, ast.KindParameter, ast.KindPropertyDeclaration,
			ast.KindPropertySignature, ast.KindMethodSignature, ast.KindTypeAliasDeclaration,
			ast.KindInterfaceDeclaration, ast.KindClassDeclaration, ast.KindEnumDeclaration,
			ast.KindModuleDeclaration, ast.KindGetAccessor, ast.KindSetAccessor:
			if name := node.Name(); name != nil {
				text := file.Text()[name.Pos():name.End()]
				result = append(result, LatentDeclaration{Measurement: LatentMeasurementLabel, Where: program.Where(node), Name: text, Kind: node.Kind.String(), Start: node.Pos(), End: node.End()})
			}
		}
		node.ForEachChild(visit)
		return false
	}
	file.AsNode().ForEachChild(visit)
	return result
}

type LatentFile struct {
	Piece                   *latentPieceRecord          `json:"piece,omitempty"`
	ProjectFailedBoundaries map[string][]LatentBoundary `json:"project_failed_boundaries,omitempty"`
	FailedBoundaries        []LatentBoundary            `json:"failed_boundaries,omitempty"`
	SpeculativeCoverage     *LatentSpeculativeCoverage  `json:"speculative_coverage,omitempty"`
	Measurement             string                      `json:"measurement"`
	File                    string                      `json:"file"`
	Declarations            []LatentDeclaration         `json:"declarations"`
	Units                   []LatentUnit                `json:"units"`
	Findings                []LatentFinding             `json:"findings"`
}

func (l *lowering) latentSignature(index int) error {
	declaration := l.latentDeclarations[index]
	if declaration == nil || l.latentReady[index] {
		return nil
	}
	return l.signature(index, declaration, -1)
}

// Register project symbols without lowering another function's body. Signatures are
// prepared on use; failed global representations are rediscovered at actual reads.
func (l *lowering) latentRegister(files []*ast.SourceFile) {
	l.functions = map[*ast.Symbol]int{}
	l.generics = map[*ast.Symbol]*ast.Node{}
	l.classes = map[*ast.Symbol]*ast.Node{}
	l.latentDeclarations = map[int]*ast.Node{}
	var register func(*ast.Node)
	register = func(node *ast.Node) {
		switch node.Kind {
		case ast.KindModuleDeclaration:
			node.ForEachChild(func(child *ast.Node) bool { register(child); return false })
		case ast.KindModuleBlock:
			node.ForEachChild(func(child *ast.Node) bool { register(child); return false })
		case ast.KindFunctionDeclaration:
			if node.Name() == nil {
				return
			}
			symbol := l.symbol(node.Name())
			if len(node.TypeParameters()) > 0 {
				l.generics[symbol] = node
				return
			}
			index := len(l.result.Functions)
			l.functions[symbol] = index
			l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
			l.latentDeclarations[index] = node
		case ast.KindEnumDeclaration:
			if func() bool { built, err := l.enumObjectBuilt(node); return err == nil && built }() {
				func() {
					defer func() { _ = recover() }()
					if local, err := l.enumLocal(node); err == nil {
						l.result.Locals[local].Global = true
					}
				}()
			}
		case ast.KindClassDeclaration:
			if node.Name() != nil {
				l.classes[l.symbol(node.Name())] = node
				func() {
					defer func() { _ = recover() }()
					if l.needsStatics(node) {
						if l.staticGlobals == nil {
							l.staticGlobals = map[*ast.Symbol]int{}
						}
						if local, err := l.declareLocal(node.Name()); err == nil {
							l.result.Locals[local].Global = true
							l.staticStorage(node)
						}
					}
				}()
			}
		case ast.KindVariableStatement:
			for _, declaration := range node.AsVariableStatement().DeclarationList.AsVariableDeclarationList().Declarations.Nodes {
				names := []*ast.Node{declaration.Name()}
				if declaration.Name().Kind == ast.KindArrayBindingPattern || declaration.Name().Kind == ast.KindObjectBindingPattern {
					names = nil
					for _, binding := range declaration.Name().AsBindingPattern().Elements.Nodes {
						if !skipped(binding) {
							names = append(names, binding.Name())
						}
					}
				}
				for _, name := range names {
					if ast.IsIdentifier(name) {
						// Registration errors are contextual, not a finding in every unrelated unit.
						func() {
							defer func() { _ = recover() }()
							if local, err := l.declareLocal(name); err == nil {
								l.result.Locals[local].Global = true
							}
						}()
					}
				}
			}
		}
	}
	for _, file := range files {
		for _, node := range file.Statements.Nodes {
			register(node)
		}
	}
}

// Latent attempts each eligible top-level unit independently. A returned error never
// stops the next unit. No function with a checker diagnostic in its body is lowered.
// Buffer records until all callers have run, including callers in later files.
var latentInstantiated map[string]bool
var latentConcreteCallDepth int

var latentUnitTimer *UnitTimer

func Latent(ctx context.Context, program *load.Program, emit func(LatentFile)) LatentRelationReport {
	return LatentWithRelationChecks(ctx, program, os.Getenv("LATENT_RELATION_PER_UNIT") == "1", emit)
}

// Explicit measurement mode keeps tests parallel without process-wide environment changes.
func LatentWithRelationChecks(ctx context.Context, program *load.Program, perUnit bool, emit func(LatentFile)) LatentRelationReport {
	outerRelationPerUnit := latentRelationPerUnit
	latentRelationPerUnit = perUnit
	defer func() { latentRelationPerUnit = outerRelationPerUnit }()
	relations := latentRelationReport(ctx, program)
	latentUnitTimer = nil
	if path := os.Getenv("LATENT_TIMES"); path != "" {
		output, err := os.Create(path)
		if err != nil {
			panic(err)
		}
		defer func() {
			latentUnitTimer = nil
			if err := output.Close(); err != nil {
				panic(err)
			}
		}()
		latentUnitTimer = NewUnitTimer(output)
	}
	latentInstantiated = map[string]bool{}
	latentConcreteCallDepth = 0
	records := []LatentFile{}
	latentRun(ctx, program, func(record LatentFile) { records = append(records, record) })
	relations.End = latentReadRelationOverflow(ctx, program)
	relations.CacheSizes = latentRelationCacheSizes(ctx, program)
	relations.Complete(records)
	for _, record := range records {
		for index := range record.Units {
			unit := &record.Units[index]
			if unit.Status == "deferred_generic_instantiation" {
				unit.Instantiated = latentInstantiated[unit.Where]
			}
		}
		emit(record)
	}
	return relations
}

func latentRun(ctx context.Context, program *load.Program, emit func(LatentFile)) {
	if latentSpeculativeEnabled() {
		latentSpeculative(ctx, program, emit)
		return
	}
	if latentFullEnabled() {
		latentFull(ctx, program, emit)
		return
	}
	// One map of source identities serves every lowering of the program. An identity is a function of its module and the
	// program alone: sourceIdentity walks the module from its root, and modulePath's import routes start at the program's
	// entry. The one input a lowering brings is its file's checker, read for the symbol of a module specifier, and that is
	// the program's module resolution, the same under every file's checker. A fresh lowering per statement, each
	// registering every file's locals, re-walked all of the program's modules once a statement: 35% of the latent step's
	// CPU on tsc's 79 files (#pv935yw).
	identities := map[*ast.Node]ir.SourceIdentity{}
	// One map of type strings too: a type's TypeToString is a function of the type alone (typeString), and a fresh
	// lowering a statement asked again for every schema node's type, keeping each answer's type nodes live in the checker
	// (#wy2dyf0: the entry census's peak, 7.57 against 5.04 GiB).
	typeStrings := map[*checker.Type]string{}
	// And one map of numeric enums, a function of the enum symbol alone (numericEnum, #e0k9s2t).
	numericEnums := map[*ast.Symbol]bool{}
	var facts *latentProgramFacts
	var modules []*ast.SourceFile
	for _, file := range program.Files() {
		latentFindings = nil
		latentFindingOwner, latentFindingPhase = program.Where(file.AsNode()), "refusal_scan"
		record := LatentFile{Measurement: LatentMeasurementLabel, File: program.FileName(file), Declarations: latentDeclarations(program, file), Units: []LatentUnit{}}
		checker, release := program.Checker(ctx, file)
		fresh := func() *lowering {
			return &lowering{program: program, checker: checker, result: &ir.Program{}, this: -1, functionIndex: -1, sourceIdentities: identities, typeStrings: typeStrings, numericEnums: numericEnums}
		}
		func() {
			defer func() {
				if failure := recover(); failure != nil {
					latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(file.AsNode()), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
				}
			}()
			fresh().latentScan(file)
		}()
		for _, node := range file.Statements.Nodes {
			latentFindingOwner, latentFindingPhase = program.Where(node), "lowering"
			unit := LatentUnit{Measurement: LatentMeasurementLabel, Where: program.Where(node), Kind: node.Kind.String(), Status: "attempted", CheckerDiagnostics: []string{}}
			if node.Name() != nil {
				unit.Name = node.Name().Text()
			}
			if node.Kind == ast.KindFunctionDeclaration {
				if body := node.Body(); body != nil {
					unit.BodyStart, unit.BodyEnd = body.Pos(), body.End()
					unit.CheckerDiagnostics = program.LatentDiagnosticsIn(body)
					if unit.CheckerDiagnostics == nil {
						unit.CheckerDiagnostics = []string{}
					}
					if len(unit.CheckerDiagnostics) > 0 && len(node.TypeParameters()) == 0 {
						unit.Status = "skipped_checker_body"
						record.Units = append(record.Units, unit)
						continue
					}
				}
			}
			// Independent units have no call witness for a generic binder. Keep the
			// declaration in the census, but lower it only through instantiateFunction
			// when a concrete caller reaches it.
			if node.Kind == ast.KindFunctionDeclaration && len(node.TypeParameters()) > 0 {
				unit.Status = "deferred_generic_instantiation"
				record.Units = append(record.Units, unit)
				continue
			}
			func() {
				defer latentUnitTimer.Start(record.File, unit.Where)()
				defer func() {
					if failure := recover(); failure != nil {
						unit.Status = "panic"
						latentFindings = append(latentFindings, LatentFinding{Measurement: LatentMeasurementLabel, Unit: latentFindingOwner, Phase: latentFindingPhase, Kind: "panic", Where: program.Where(node), Reason: fmt.Sprint(failure), Text: fmt.Sprint(failure)})
					}
				}()
				l := fresh()
				if modules == nil {
					var err error
					modules, err = l.latentPrepassModules()
					if err != nil {
						latentRecord(err)
						return
					}
				}
				func() { defer latentPrepassTimer("collectViewedElements")(); l.collectViewedElements(modules) }()
				func() { defer latentPrepassTimer("noteInheritance")(); l.noteInheritance(modules) }()
				func() { defer latentPrepassTimer("noteAccessorNames")(); l.noteAccessorNames(modules) }()
				if facts == nil {
					func() { defer latentPrepassTimer("noteOmittedOptionals")(); l.noteOmittedOptionals(modules) }()
				}
				l.latentRegister(program.Files())
				l.latentUseProgramFacts(&facts)
				if l.latentDeferredUnit(node) {
					return
				}
				if node.Kind == ast.KindFunctionDeclaration && node.Name() != nil && node.Name().Text() == os.Getenv("LATENT_MUTANT_FUNCTION") && (os.Getenv("LATENT_MUTANT_WHERE") == "" || program.Where(node) == os.Getenv("LATENT_MUTANT_WHERE")) {
					latentRecord(l.notYet(node, "latent planted extra NotYet"))
				}
				if node.Kind == ast.KindFunctionDeclaration {
					if node.Name() == nil {
						latentRecord(l.notYet(node, "an anonymous top-level function"))
						return
					}
					index, found := l.functions[l.symbol(node.Name())]
					if !found {
						index = len(l.result.Functions)
						l.result.Functions = append(l.result.Functions, ir.Function{Name: node.Name().Text()})
						l.functions[l.symbol(node.Name())] = index
					}
					// Nongeneric declarations lower directly; generic bodies are reached at calls.
					latentRecord(l.lowerFunction(index, node, -1))
				} else {
					_, err := l.statement(node)
					latentRecord(err)
				}
				latentRecord(l.unlowerable)
			}()
			latentCheckUnitRelation(program, checker, &unit)
			record.Units = append(record.Units, unit)
		}
		release()
		seen := map[LatentFinding]bool{}
		record.Findings = []LatentFinding{}
		for _, finding := range latentFindings {
			if !seen[finding] {
				record.Findings = append(record.Findings, finding)
				seen[finding] = true
			}
		}
		emit(record)
	}
}

// Directory censuses use the union of each root's production module order.
// An entry census retains its single original root even after ledger expansion.
func (l *lowering) latentPrepassModules() ([]*ast.SourceFile, error) {
	var modules []*ast.SourceFile
	seen := map[*ast.SourceFile]bool{}
	for _, root := range l.program.LatentRoots() {
		// Order on a disposable lowering: keep production's refusal, while leaving
		// cycle-read proof effects at their existing first query in each unit.
		probe := &lowering{program: l.program, checker: l.checker, result: &ir.Program{}, this: -1, functionIndex: -1}
		order, err := probe.moduleOrder(root)
		if err != nil {
			return nil, err
		}
		for _, module := range order {
			if !seen[module] {
				seen[module] = true
				modules = append(modules, module)
			}
		}
	}
	return modules, nil
}

// Optional measurement stream, separate from the deterministic finding ledger.
func latentPrepassTimer(method string) func() {
	path := os.Getenv("LATENT_PREPASS_TIMES")
	if path == "" {
		return func() {}
	}
	started := time.Now()
	owner := latentFindingOwner
	return func() {
		output, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if err != nil {
			panic(err)
		}
		_, err = fmt.Fprintf(output, "%s\t%s\t%d\n", method, owner, time.Since(started).Nanoseconds())
		closeErr := output.Close()
		if err != nil {
			panic(err)
		}
		if closeErr != nil {
			panic(closeErr)
		}
	}
}

// A deferred failure retains its phase while returning through instantiated bodies.
type latentDeferredFailure struct{ cause error }

func (e *latentDeferredFailure) Error() string { return e.cause.Error() }
func (e *latentDeferredFailure) Unwrap() error { return e.cause }

// Probe the production registry without changing the unit's refusal state.
func (l *lowering) latentDeferredStop(node *ast.Node) error {
	for _, finding := range latentFindings {
		if (finding.Unit == latentFindingOwner || finding.Unit == l.program.Where(node)) && (finding.Phase == "refusal_scan" || finding.Phase == "contract_scan") && (finding.Kind == "Refused" || finding.Kind == "NotYet") {
			return nil
		}
	}
	probe := *l
	probe.refusal = refusalPass{}
	ordinary := probe.refuseNode(node)
	return latent.DeferredStop(ordinary, probe.refusal.deferred)
}

func (l *lowering) latentDeferredUnit(node *ast.Node) bool {
	stop := l.latentDeferredStop(node)
	if stop == nil {
		return false
	}
	latentRecord(&latentDeferredFailure{cause: stop})
	return true
}

// The continuing scan clears its ordinary error binding after each finding.
// Its deferred state is valid only if no ordinary finding was collected.
func (l *lowering) latentScan(file *ast.SourceFile) {
	first := len(latentFindings)
	err := l.latentRefuse(file)
	latentRecord(err)
	if len(latentFindings) != first {
		return
	}
	owner, phase := latentFindingOwner, latentFindingPhase
	latentFindingOwner, latentFindingPhase = l.program.Where(file.AsNode()), "deferred_scan"
	latentRecord(latent.DeferredStop(err, l.refusal.deferred))
	latentFindingOwner, latentFindingPhase = owner, phase
}
