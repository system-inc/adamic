export {};

declare global {
    namespace NodeJS {
        interface Process {
            recordreplay?: unknown;
        }
    }
}
