// Targeting ES6
export const a = 1; 