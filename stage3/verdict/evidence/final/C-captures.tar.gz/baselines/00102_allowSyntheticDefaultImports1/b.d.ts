export class Foo {
	member: string;
}
