import Backbone = require("./aliasUsageInTypeArgumentOfExtendsClause_backbone");
export class VisualizationModel extends Backbone.Model {
    // interesting stuff here
}
