interface c {
    q3: number;
}
export = c;
