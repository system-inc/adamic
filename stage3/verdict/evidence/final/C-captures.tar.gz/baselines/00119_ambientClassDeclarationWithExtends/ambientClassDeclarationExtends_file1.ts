declare class E {
    public bar;
}
namespace F { var y; }
