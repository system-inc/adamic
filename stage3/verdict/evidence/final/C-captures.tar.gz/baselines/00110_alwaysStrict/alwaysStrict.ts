function f() {
    var arguments = [];
}