/// <reference path="node.d.ts"/>

const fs = require("fs");
const text = fs.readFileSync("/a/b/c");