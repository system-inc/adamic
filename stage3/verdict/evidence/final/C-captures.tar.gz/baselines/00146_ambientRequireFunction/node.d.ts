declare function require(moduleName: string): any;

declare module "fs" {
    export function readFileSync(s: string): string;
}
