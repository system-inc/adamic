import Foo = require("./b");
Foo.default.bar();
Foo.default.default.foo();