export function b(a: any): any { return null; }
