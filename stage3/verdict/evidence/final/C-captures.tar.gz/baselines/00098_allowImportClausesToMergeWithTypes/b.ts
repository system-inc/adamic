export const zzz = 123;
export default zzz;
