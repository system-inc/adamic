type T = { x : number }
export interface I {
    f: T;   
}