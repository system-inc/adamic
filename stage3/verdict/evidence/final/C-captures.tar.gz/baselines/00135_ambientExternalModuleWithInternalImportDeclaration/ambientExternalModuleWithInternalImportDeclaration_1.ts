///<reference path='ambientExternalModuleWithInternalImportDeclaration_0.ts'/>
import A = require('M');
var c = new A();