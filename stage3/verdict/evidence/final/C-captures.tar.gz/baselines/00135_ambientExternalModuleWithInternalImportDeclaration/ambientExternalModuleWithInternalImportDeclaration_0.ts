declare module 'M' {
    namespace C {
        export var f: number;
    }
    class C {
        foo(): void;
    }
    import X = C;
    export = X;

}
