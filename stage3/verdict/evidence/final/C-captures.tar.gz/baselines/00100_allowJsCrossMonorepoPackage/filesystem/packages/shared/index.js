import { pkg } from "./utils.js";
export const x = pkg();
