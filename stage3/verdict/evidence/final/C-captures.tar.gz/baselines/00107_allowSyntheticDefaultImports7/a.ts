import { default as Foo } from "./b";
Foo.bar();
Foo.foo();