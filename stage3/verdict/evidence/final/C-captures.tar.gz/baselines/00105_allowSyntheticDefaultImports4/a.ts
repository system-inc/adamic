import Foo from "./b";
export var x = new Foo();
