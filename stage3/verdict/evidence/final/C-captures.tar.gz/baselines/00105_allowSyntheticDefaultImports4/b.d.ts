declare class Foo {
	member: string;
}
export = Foo;
