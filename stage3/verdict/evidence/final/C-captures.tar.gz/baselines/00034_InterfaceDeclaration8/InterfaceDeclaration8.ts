interface string {
}