import {vextend} from './func';
// hover on vextend
export var a = vextend({
  watch: {
    data1(val) {
      this.data2 = 1;
    },
    data2(val) { },
  }
});