class C {
   constructor();
   foo() { }
}