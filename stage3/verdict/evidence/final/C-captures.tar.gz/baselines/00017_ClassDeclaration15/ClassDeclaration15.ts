class C {
   foo();
   constructor() { }
}