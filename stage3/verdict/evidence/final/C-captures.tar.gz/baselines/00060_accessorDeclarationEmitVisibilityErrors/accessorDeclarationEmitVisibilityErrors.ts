export class Q {
    set bet(arg: DoesNotExist) {}
}