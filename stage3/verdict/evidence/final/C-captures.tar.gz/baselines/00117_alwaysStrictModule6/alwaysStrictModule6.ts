// Targeting ES5
export const a = 1; 