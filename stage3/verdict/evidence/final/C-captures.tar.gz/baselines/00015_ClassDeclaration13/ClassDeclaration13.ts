class C {
   foo();
   bar() { }
}