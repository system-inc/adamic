import ts = require("typescript");
import tsInternal = require("typescript-internal");
import tsserverlibrary = require("tsserverlibrary");
import tsserverlibraryInternal = require("tsserverlibrary-internal");
