class C {
    "foo"();
    "bar"() { }
}