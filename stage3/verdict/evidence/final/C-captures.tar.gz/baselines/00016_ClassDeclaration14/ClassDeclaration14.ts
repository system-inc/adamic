class C {
   foo();
   constructor();
}