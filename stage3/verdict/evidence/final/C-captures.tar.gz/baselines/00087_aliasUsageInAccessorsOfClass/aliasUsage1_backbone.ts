export class Model {
    public someData: string;
}
