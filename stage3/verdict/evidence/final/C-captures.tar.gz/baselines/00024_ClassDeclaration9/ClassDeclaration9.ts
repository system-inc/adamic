class C {
   foo();
}