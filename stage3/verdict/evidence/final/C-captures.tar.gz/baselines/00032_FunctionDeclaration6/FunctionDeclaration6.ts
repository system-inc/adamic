{
    function foo();
    function bar() { }
}