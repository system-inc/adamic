function foo();
function bar() { }