import Color from "./color";
export declare function styled(): Color;