interface Color {
    c: string;
}
export default Color;