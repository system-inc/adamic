import { styled }  from "./file1";
export const A = styled();