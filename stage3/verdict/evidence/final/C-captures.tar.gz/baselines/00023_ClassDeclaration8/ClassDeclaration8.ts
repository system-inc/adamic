class C {
  constructor();
}