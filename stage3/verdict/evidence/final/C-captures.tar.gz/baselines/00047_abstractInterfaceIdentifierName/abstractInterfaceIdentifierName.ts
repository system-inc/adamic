interface abstract {
    abstract(): void;
}
