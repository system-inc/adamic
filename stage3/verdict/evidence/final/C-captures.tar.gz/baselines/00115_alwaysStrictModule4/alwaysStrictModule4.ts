// Module commonjs
export const a = 1