namespace M {
   function foo();
}