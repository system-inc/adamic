export class someClass {
    public someData: string;
}
