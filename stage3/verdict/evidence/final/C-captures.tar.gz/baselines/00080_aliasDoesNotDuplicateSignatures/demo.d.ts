declare namespace demoNS {
    function f(): void;
}
declare module 'demoModule' {
    import alias = demoNS;
    export = alias;
}