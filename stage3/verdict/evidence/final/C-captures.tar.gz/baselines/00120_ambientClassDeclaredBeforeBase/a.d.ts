declare namespace ns {
  class SecondNS extends FirstNS { }
  class FirstNS { }
}
