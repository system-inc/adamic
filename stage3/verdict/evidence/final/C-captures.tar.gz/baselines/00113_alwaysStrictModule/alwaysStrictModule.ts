namespace M {
    export function f() {
        var arguments = [];
    }
}