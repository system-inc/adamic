/// <reference path="./indirection.d.ts" />
/// <reference path="./indirection2.d.ts" />
import "indirect";
import "foo";
import "indirect2";
import "foo2";