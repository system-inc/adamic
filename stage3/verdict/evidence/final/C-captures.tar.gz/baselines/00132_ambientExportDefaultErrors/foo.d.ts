export default 2 + 2;
export as namespace Foo;
