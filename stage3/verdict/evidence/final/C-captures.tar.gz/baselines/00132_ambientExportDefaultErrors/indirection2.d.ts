/// <reference path="./foo2.d.ts" />
declare module "indirect2" {
    export = typeof Foo2;
}
