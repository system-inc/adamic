/// <reference path="./foo.d.ts" />
declare module "indirect" {
    export default typeof Foo.default;
}
