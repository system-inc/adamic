// module ES2015
export const a = 1;