namespace Validation {
    var function1 = function() {
    }
}