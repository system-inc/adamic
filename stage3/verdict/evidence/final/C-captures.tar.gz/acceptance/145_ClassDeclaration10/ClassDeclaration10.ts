class C {
   constructor();
   foo();
}