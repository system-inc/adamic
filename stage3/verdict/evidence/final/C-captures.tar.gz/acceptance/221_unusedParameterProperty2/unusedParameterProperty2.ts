class A {
    constructor(private used) {
        let foge = used;
    }
}
