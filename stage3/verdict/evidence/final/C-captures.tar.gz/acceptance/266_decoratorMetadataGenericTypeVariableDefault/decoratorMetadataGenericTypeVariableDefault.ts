export class C<TypeVariable = string> {
  @Decorate
  member: TypeVariable;
}
