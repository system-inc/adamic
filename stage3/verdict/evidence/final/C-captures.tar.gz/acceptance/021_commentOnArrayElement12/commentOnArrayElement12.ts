const array = [
    ,, /* comment */
];
