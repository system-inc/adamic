export class C<TypeVariable> {
  @Decorate
  member: TypeVariable;
}
