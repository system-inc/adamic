type RoomInterfae = {};

export type {
    RoomInterface
}