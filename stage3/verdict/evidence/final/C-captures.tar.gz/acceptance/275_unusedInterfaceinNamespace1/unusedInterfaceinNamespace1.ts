namespace Validation {
    interface i1 {

    }
}