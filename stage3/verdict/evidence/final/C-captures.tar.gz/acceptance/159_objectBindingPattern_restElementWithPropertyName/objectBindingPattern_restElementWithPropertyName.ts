const { ...a: b } = {};
