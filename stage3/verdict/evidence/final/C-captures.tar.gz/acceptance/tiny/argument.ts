function take(value: number): number { return value; }
take("wrong");
