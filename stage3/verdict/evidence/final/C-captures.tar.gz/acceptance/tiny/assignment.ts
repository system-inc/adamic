export const count: number = "wrong";
