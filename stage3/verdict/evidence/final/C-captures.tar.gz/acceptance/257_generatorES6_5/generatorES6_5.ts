function* foo() {
    yield a ? b : c;
}