const obj = {
    [Symbol.species]: Array
};

type Q = keyof typeof obj;
