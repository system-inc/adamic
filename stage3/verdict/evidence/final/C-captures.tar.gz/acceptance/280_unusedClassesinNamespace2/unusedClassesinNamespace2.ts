namespace Validation {
    class c1 {

    }

    export class c2 {

    }
}