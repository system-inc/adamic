namespace Validation {
    var function1 = function() {
    }

    export function function2() {

    }
}