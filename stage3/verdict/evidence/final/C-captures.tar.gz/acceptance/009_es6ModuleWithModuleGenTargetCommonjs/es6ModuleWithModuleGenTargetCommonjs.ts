export class A
{
    constructor ()
    {
    }

    public B()
    {
        return 42;
    }
}