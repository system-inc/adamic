import importlib.util,json,pathlib,subprocess,sys
spec=importlib.util.spec_from_file_location('gate','/tmp/placeholder-a-check/gate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=pathlib.Path.cwd()
class Harness:
 def __init__(self):self.arguments=type('Args',(),{'tree':str(root)})();self.result={};self.steps={};self.exits={};self.failure=None
 def step(self,name,cmd):
  with open('/tmp/placeholder-a-check/build.log','w') as log:code=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
  return code==0
 def spawn(self,cmd,stdout,stderr):return subprocess.Popen(cmd,cwd=root,stdout=stdout,stderr=stderr,text=True)
 def fail(self,name,detail):self.failure=detail
h=Harness();paths=sorted(set(subprocess.check_output(['git','diff','--name-only','c79c75726375c937f0b18e18040e6769d916ed06','--','*.a'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.a'],text=True).splitlines()));m.Gate.aCheck(h,paths)
print(json.dumps(h.result,indent=2));print(h.failure or 'PASS');sys.exit(h.exits['a-check'])
