### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: multiFile/changes incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: multiFile/changes composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: outFile/changes incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: outFile/changes composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -noEmit noEmit:: when project has strict true
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/syntax errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/syntax errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/syntax errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/syntax errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/syntax errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/syntax errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/semantic errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/semantic errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/semantic errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/semantic errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/semantic errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/semantic errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '3')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: multiFile/dts errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
tsc -p . --noEmit noEmit:: outFile/dts errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
dts errors with declaration enable changes with errors in multiple files
         tsc -p . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with multiple files
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
dts errors with declaration enable changes with errors in multiple files
         tsc -p . --noEmit noEmit:: outFile/dts errors with declaration enable changes with multiple files
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)



file:///workspace/x2jdg33/case-probe/stage3-lane-compiler-no-emit-cases-01/adapted-tree/scripts/build/utils.mjs:42
                        new ExecError(exitCode);
                        ^

ExecError: Process exited with code: 35
    at ChildProcess.<anonymous> (file:///workspace/x2jdg33/case-probe/stage3-lane-compiler-no-emit-cases-01/adapted-tree/scripts/build/utils.mjs:42:25)
    at ChildProcess.emit (node:events:509:28)
    at ChildProcess._handle.onexit (node:internal/child_process:295:12) {
  exitCode: 35
}

Node.js v24.19.0
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: multiFile/changes incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 1582.166 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 85.664 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: multiFile/changes composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 62.698 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 49.447 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: outFile/changes incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 43.999 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 53.593 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: outFile/changes composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 101.539 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 41.881 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -noEmit noEmit:: when project has strict true tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 38.191 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/syntax errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 107.300 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/syntax errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 72.827 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/syntax errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.373 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/syntax errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.594 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/syntax errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.019 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/syntax errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.454 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/semantic errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 76.993 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/semantic errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 169.585 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/semantic errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 22.027 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/semantic errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.398 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/semantic errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 22.413 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/semantic errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.977 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 88.281 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 84.935 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 26.814 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.615 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 24.310 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 21.611 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 86.529 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '3')
```

Elapsed: 81.399 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 23.362 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.467 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: multiFile/dts errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 29.421 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: tsc -p . --noEmit noEmit:: outFile/dts errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 42.999 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: dts errors with declaration enable changes with errors in multiple files tsc -p . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with multiple files tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 23.490 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: dts errors with declaration enable changes with errors in multiple files tsc -p . --noEmit noEmit:: outFile/dts errors with declaration enable changes with multiple files tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 24.516 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
