### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: multiFile/changes incremental declaration
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit incremental declaration
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . noEmit:: outFile/changes incremental declaration
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit incremental declaration
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)



file:///workspace/x2jdg33/case-probe/stage3-lane-compiler-no-emit-cases-00/adapted-tree/scripts/build/utils.mjs:42
                        new ExecError(exitCode);
                        ^

ExecError: Process exited with code: 4
    at ChildProcess.<anonymous> (file:///workspace/x2jdg33/case-probe/stage3-lane-compiler-no-emit-cases-00/adapted-tree/scripts/build/utils.mjs:42:25)
    at ChildProcess.emit (node:events:509:28)
    at ChildProcess._handle.onexit (node:internal/child_process:295:12) {
  exitCode: 4
}

Node.js v24.19.0
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: multiFile/changes incremental declaration tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 1625.657 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: multiFile/changes with initial noEmit incremental declaration tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 31.780 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . noEmit:: outFile/changes incremental declaration tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.052 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsc:: noEmit:: when noEmit changes between compilation tsc --p . --noEmit noEmit:: outFile/changes with initial noEmit incremental declaration tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 25.732 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
