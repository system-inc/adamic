### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . noEmit:: multiFile/changes incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . --noEmit noEmit:: multiFile/changes with initial noEmit incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . noEmit:: multiFile/changes composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . --noEmit noEmit:: multiFile/changes with initial noEmit composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . noEmit:: outFile/changes incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . --noEmit noEmit:: outFile/changes with initial noEmit incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . noEmit:: outFile/changes composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
when noEmit changes between compilation
         tsc -b -v . --noEmit noEmit:: outFile/changes with initial noEmit composite
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/syntax errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/syntax errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/syntax errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/syntax errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/syntax errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/syntax errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/semantic errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/semantic errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/semantic errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/semantic errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/semantic errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/semantic errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors with incremental
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: multiFile/dts errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
tsc --b --v . --noEmit noEmit:: outFile/dts errors with incremental as modules
         tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with incremental
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with incremental as modules
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes
         tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with incremental as modules
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes with errors in multiple files
         tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with multiple files
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit: (exception)

```text
dts errors with declaration enable changes with errors in multiple files
         tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with multiple files
           tsc invocation after edit and clean build correctness:
     TypeError: Cannot read properties of undefined (reading '0')
      at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
      at Context.<anonymous> (src/testRunner/unittests/helpers/tsc.ts:489:33)
      at Test.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
      at processImmediate (node:internal/timers:534:21)



file:///workspace/x2jdg33/case-probe/stage3-lane-build-no-emit-cases-01/adapted-tree/scripts/build/utils.mjs:42
                        new ExecError(exitCode);
                        ^

ExecError: Process exited with code: 40
    at ChildProcess.<anonymous> (file:///workspace/x2jdg33/case-probe/stage3-lane-build-no-emit-cases-01/adapted-tree/scripts/build/utils.mjs:42:25)
    at ChildProcess.emit (node:events:509:28)
    at ChildProcess._handle.onexit (node:internal/child_process:295:12) {
  exitCode: 40
}

Node.js v24.19.0
```

Stack top: at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . noEmit:: multiFile/changes incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 1635.261 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . --noEmit noEmit:: multiFile/changes with initial noEmit incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 57.847 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . noEmit:: multiFile/changes composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 28.494 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . --noEmit noEmit:: multiFile/changes with initial noEmit composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 32.975 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . noEmit:: outFile/changes incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 25.000 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . --noEmit noEmit:: outFile/changes with initial noEmit incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 40.264 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . noEmit:: outFile/changes composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 22.207 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: when noEmit changes between compilation tsc -b -v . --noEmit noEmit:: outFile/changes with initial noEmit composite tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 26.610 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/syntax errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.633 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/syntax errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.402 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/syntax errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.243 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/syntax errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.991 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/syntax errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.729 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/syntax errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.664 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/semantic errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 22.113 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/semantic errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.628 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/semantic errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.421 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/semantic errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.309 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/semantic errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 25.646 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/semantic errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.017 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 25.495 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 17.793 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.071 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.242 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors without dts enabled with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.608 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors without dts enabled with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.790 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 21.503 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.822 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.498 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.970 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: multiFile/dts errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 21.685 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: tsc --b --v . --noEmit noEmit:: outFile/dts errors with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.242 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 27.221 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 18.572 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.571 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with incremental tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 19.530 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 26.976 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with incremental as modules tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 22.724 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes with errors in multiple files tsc -b --v . --noEmit noEmit:: multiFile/dts errors with declaration enable changes with multiple files tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 24.798 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)

### unittests:: tsbuild:: noEmit:: dts errors with declaration enable changes with errors in multiple files tsc -b --v . --noEmit noEmit:: outFile/dts errors with declaration enable changes with multiple files tsc invocation after edit and clean build correctness (exception)

```text
Cannot read properties of undefined (reading '0')
```

Elapsed: 20.816 ms; timeout: 40000 ms.

Stack top:     at verifyTscEditDiscrepancies (src/testRunner/unittests/helpers/tsc.ts:186:36)
