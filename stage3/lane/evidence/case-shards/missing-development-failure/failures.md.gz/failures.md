### unittests:: tsserver:: projects:: assert when removing project (baseline-content)

```text
New baseline created at tests/baselines/local/tsserver/projects/assert-when-removing-project.js
```

Elapsed: 37.109 ms; timeout: 40000 ms.

Stack top:     at writeComparison (built/local/run.js:206577:21)

tsserver/projects/assert-when-removing-project.js (first 40 lines)

```diff
--- reference/tsserver/projects/assert-when-removing-project.js
+++ local/tsserver/projects/assert-when-removing-project.js
@@ -182,13 +182,74 @@
 	  Root file specified for compilation
 
 Info seq  [hh:mm:ss:mss] -----------------------------------------------
-Debug Failure. False expression: Found script Info still attached to project
-Verbose Debug Information: /dev/null/inferredProject1*: ScriptInfos still attached: [
- {
-  "fileName": "/user/username/projects/project/commonFile2.ts",
-  "projects": [
-   "/dev/null/inferredProject1*"
-  ],
-  "hasMixedContent": false
- }
-]+Info seq  [hh:mm:ss:mss] FileWatcher:: Close:: WatchInfo: /user/username/projects/project/commonFile1.ts 500 undefined WatchType: Closed Script info
+Info seq  [hh:mm:ss:mss] FileWatcher:: Close:: WatchInfo: /user/username/projects/project/commonFile2.ts 500 undefined WatchType: Closed Script info
+Info seq  [hh:mm:ss:mss] Project '/dev/null/inferredProject2*' (Inferred)
+Info seq  [hh:mm:ss:mss] 	Files (2)
+
+Info seq  [hh:mm:ss:mss] -----------------------------------------------
+Info seq  [hh:mm:ss:mss] Open files: 
+Info seq  [hh:mm:ss:mss] 	FileName: /home/src/projects/random/random.ts ProjectRootPath: undefined
+Info seq  [hh:mm:ss:mss] 		Projects: /dev/null/inferredProject2*
+Info seq  [hh:mm:ss:mss] response:
+    {
+      "response": true,
+      "responseRequired": true,
+      "performanceData": {
+        "updateGraphDurationMs": *
+      }
+    }
+After request
+
+PolledWatches::
+/home/src/projects/random/jsconfig.json: *new*
+  {"pollingInterval":2000}
+/home/src/projects/random/tsconfig.json: *new*
+  {"pollingInterval":2000}
+

```
