import importlib.util,importlib._bootstrap_external,subprocess,time
from pathlib import Path
root=Path('/workspace/adamic');source=root/'stage3/lane/check.py';cache=Path(importlib.util.cache_from_source(str(source)))
old=cache.read_bytes() if cache.exists() else None
recipe=root/'stage3/lane/products_test.go';original=recipe.read_text()
needle=', "PYTHONPYCACHEPREFIX="+filepath.Join(results, "pycache")'
assert needle in original
stat=source.stat();code=compile('raise RuntimeError("hefhych checkout bytecode mutant")',str(source),'exec')
cache.parent.mkdir(exist_ok=True)
try:
 cache.write_bytes(importlib._bootstrap_external._code_to_timestamp_pyc(code,int(stat.st_mtime),stat.st_size))
 for label,mutant,wanted in [('bytecode-positive',False,0),('bytecode-mutant',True,1)]:
  if mutant:recipe.write_text(original.replace(needle,''))
  log=Path('/workspace/scratch/hefhych-review')/(label+'.log');start=time.monotonic()
  with log.open('w') as output:r=subprocess.run(['go','test','./stage3/lane','-run','^TestShard_Stage3LaneFile001$','-count=1','-timeout','90s','-v'],cwd=root,stdout=output,stderr=subprocess.STDOUT,timeout=90)
  print(label,'exit',r.returncode,'seconds',time.monotonic()-start,flush=True)
  assert r.returncode==wanted
  if mutant:assert 'hefhych checkout bytecode mutant' in log.read_text()
finally:
 recipe.write_text(original)
 if old is None:cache.unlink()
 else:cache.write_bytes(old)
