import ast,os,re,sys
from pathlib import Path
root='/workspace/adamic'; initial=root+'/stage3/lane'
cwd={};fds={};rows=set();unresolved=[]
for line in Path(sys.argv[1]).read_text().splitlines():
 m=re.match(r'(\d+)\s+(.*)',line)
 if not m:continue
 pid=int(m[1]);call=m[2];cwd.setdefault(pid,initial);fds.setdefault(pid,{})
 child=re.search(r'(?:clone3?|fork|vfork)(?:\(| resumed>).*?= (\d+)\s*$',call)
 if child:cwd[int(child[1])]=cwd[pid];fds[int(child[1])]=fds[pid].copy()
 cd=re.search(r'^chdir\(("(?:[^"\\]|\\.)*")\)\s*= 0',call)
 if cd:cwd[pid]=os.path.normpath(os.path.join(cwd[pid],ast.literal_eval(cd[1])))
 op=re.search(r'^openat\(([^,]+), ("(?:[^"\\]|\\.)*"), (.*)',call)
 if op:
  p=ast.literal_eval(op[2]);base=cwd[pid]
  if op[1]!='AT_FDCWD' and not p.startswith('/'):
   try:base=fds[pid][int(op[1])]
   except (ValueError,KeyError):unresolved.append(line);continue
  p=os.path.normpath(os.path.join(base,p))
  status='probe' if '= -1' in call else 'attempt' if 'unfinished ...' in call else 'write' if 'O_WRONLY' in op[3] or 'O_RDWR' in op[3] else 'read'
  fd=re.search(r' = (\d+)\s*$',call)
  if fd:fds[pid][int(fd[1])]=p
 else:
  op=re.search(r'^execve\(("(?:[^"\\]|\\.)*")',call)
  if not op:continue
  p=os.path.normpath(os.path.join(cwd[pid],ast.literal_eval(op[1])));status='exec-probe' if '= -1' in call else 'exec'
 if p==root or p.startswith(root+'/'):rows.add((p[len(root)+1:] or '.',status))
print('path\toperation')
for p,op in sorted(rows):print(p+'\t'+op)
print('unresolved relative dirfd calls:',len(unresolved),file=sys.stderr)
for line in unresolved:print(line,file=sys.stderr)
