import collections,difflib,json,pathlib,re
r=pathlib.Path('/workspace/scratch/or-predicate');before=pathlib.Path('/workspace/or-predicate-before');after=pathlib.Path('/workspace/or-predicate-after')
a=[json.loads(s) for s in (r/'census-before.jsonl').read_text().splitlines()];b=[json.loads(s) for s in (r/'core-after.jsonl').read_text().splitlines()]
assert a[0]['diagnostics']==b[0]['diagnostics']==[];assert a[0]['latent_mode']==b[0]['latent_mode']=='full'
x=(before/'src/compiler/core.ts').read_text().splitlines();y=(after/'src/compiler/core.ts').read_text().splitlines();mapping={}
for tag,i,j,k,l in difflib.SequenceMatcher(None,x,y,autojunk=False).get_opcodes():
 if tag=='equal':mapping.update({v+1:u+1 for u,v in zip(range(i,j),range(k,l))})
proofs=[]
def norm(value,side):
 if isinstance(value,dict):return {k:norm(v,side) for k,v in value.items() if k not in ['start','end','site_start','site_end','body_start','body_end']}
 if isinstance(value,list):return [norm(v,side) for v in value]
 if isinstance(value,str):
  value=value.replace(str(before),'TREE').replace(str(after),'TREE')
  if side=='after':
   def remap(m):
    line=int(m[1]);assert line in mapping,('changed finding line',line);old=mapping[line];assert y[line-1]==x[old-1];proofs.append({'after':line,'before':old,'unchangedCompleteLine':True});return 'core.ts:'+str(old)+':'+m[2]
   value=re.sub(r'core\.ts:(\d+):(\d+)',remap,value)
  return value
 return value
left=next(v for v in a if v.get('file','').endswith('/core.ts'));right=next(v for v in b if v.get('file','').endswith('/core.ts'))
assert collections.Counter(json.dumps(norm(f,'before'),sort_keys=True) for f in left['findings'])==collections.Counter(json.dumps(norm(f,'after'),sort_keys=True) for f in right['findings'])
summary={'beforeCoreUnits':len(left['units']),'afterCoreUnits':len(right['units']),'beforeFindingEventsIncludingBoundaries':len(left['findings']),'afterFindingEventsIncludingBoundaries':len(right['findings']),'newSites':0,'removedRecordedSites':0,'allFindingEventsIdenticalAfterProvenCoordinateMapping':True,'coordinateProofs':proofs,'beforeOrUnits':[u for u in left['units'] if u.get('name')=='or'],'afterHelperAndOrUnits':[u for u in right['units'] if u.get('name') in ['or','orPredicate2','orPredicate3']]}
(r/'core-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,list)}))
