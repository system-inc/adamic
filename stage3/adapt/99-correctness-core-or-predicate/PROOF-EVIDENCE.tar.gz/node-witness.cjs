'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
function constructors(file){const source=fs.readFileSync(file,'utf8'),compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2024,module:ts.ModuleKind.CommonJS}}).outputText;const exports={};new Function('exports',compiled)(exports);return exports;}
const before=constructors('/workspace/scratch/or-predicate/witness-before/core.txt'),after=constructors('/workspace/scratch/or-predicate/witness-after/core.txt');
const sf=ts.createSourceFile('witness.ts',"import x = require('m'); import {y} from 'm'; export {y}; const z=1; /** @import {q} from 'm' */\nlet v;",ts.ScriptTarget.Latest,true);
const doc=ts.createSourceFile('doc.js',"/** @import {q} from 'm' */\nlet v;",ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const tag=ts.getJSDocTags(doc.statements[0]).find(ts.isJSDocImportTag);assert(tag,'parsed JSDoc import node');
const nodes=[...sf.statements,tag],result=[];
for(const [arity,predicates] of [[2,[ts.isImportEqualsDeclaration,ts.isExportDeclaration]],[3,[ts.isImportDeclaration,ts.isJSDocImportTag,ts.isExportDeclaration]]]){
 let firstTrue=0;
 for(const node of nodes){let counts=predicates.map(()=>0);const callbacks=predicates.map((p,i)=>n=>{counts[i]++;return p(n);});
  const original=before.or(...callbacks),candidate=after['orPredicate'+arity](...callbacks);
  const a=original(node),traceA=counts.slice();counts.fill(0);const b=candidate(node),traceB=counts.slice();
  assert.equal(typeof a,'boolean');assert.equal(a,b);assert.deepEqual(traceA,traceB);if(predicates[0](node)){firstTrue++;assert.equal(traceA[1],0);if(arity===3)assert.equal(traceA[2],0);}
  result.push({arity,kind:ts.SyntaxKind[node.kind],result:a,originalCalls:traceA,adaptedCalls:traceB,equal:true});
 }
 assert(firstTrue>0,'first-true short-circuit witnessed');
}
fs.writeFileSync('/workspace/scratch/or-predicate/node-witness.json',JSON.stringify({samePredicateArguments:true,sameNodeObjects:true,shortCircuitSecondNotCalled:true,valueDifferences:0,rows:result},null,2)+'\n');console.log(JSON.stringify({witnesses:result.length,valueDifferences:0,shortCircuitSecondNotCalled:true}));
