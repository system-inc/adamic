import difflib,json,pathlib,re
root=pathlib.Path('/workspace/scratch/or-predicate/replay');before=pathlib.Path('/workspace/or-predicate-before');after=pathlib.Path('/workspace/or-predicate-after')
a=json.loads((root/'before.json').read_text());b=json.loads((root/'after.json').read_text());left={r['adapter']:r for r in a};right={r['adapter']:r for r in b};fingerprint=json.loads((root/'fingerprint-proof.json').read_text());proofs=[];maps={};differences=[]
def line_map(file,line):
 if file not in maps:
  x=(before/file).read_text().splitlines();y=(after/file).read_text().splitlines();mapping={}
  for tag,i,j,k,l in difflib.SequenceMatcher(None,x,y,autojunk=False).get_opcodes():
   if tag=='equal':mapping.update({v+1:u+1 for u,v in zip(range(i,j),range(k,l))})
  maps[file]=(x,y,mapping)
 x,y,mapping=maps[file];assert line in mapping,(file,line,'not an unchanged source line');old=mapping[line];assert x[old-1]==y[line-1];proofs.append({'file':file,'afterLine':line,'beforeLine':old,'unchangedCompleteLine':True});return old

def normalize(x,file=None):
 if isinstance(x,dict):
  file=x.get('file',file);out={k:normalize(v,file) for k,v in x.items()}
  if isinstance(x.get('line'),int):assert file;out['line']=line_map(file,x['line'])
  if 'runtime_sha256' in x and file==fingerprint['file'] and x.get('function')==fingerprint['function']:
   assert x['runtime_sha256']==fingerprint['after'];out['runtime_sha256']=fingerprint['before']
  return out
 if isinstance(x,list):return [normalize(v,file) for v in x]
 if isinstance(x,str):return re.sub(r'(src/[^:\s]+\.ts):(\d+):(\d+)',lambda m:m[1]+':'+str(line_map(m[1],int(m[2])))+':'+m[3],x)
 return x
assert right.keys()-left.keys()=={'99-correctness-core-or-predicate'}
assert not left.keys()-right.keys()
for name,x in left.items():
 y=right[name]
 for key in ['exit','stderr','changedFiles','filesWritten']:assert x[key]==y[key],(name,key)
 if x['stdout']!=y['stdout']:
  old=json.loads(x['stdout']);new=normalize(json.loads(y['stdout']));assert old==new,(name,'unmodeled stdout difference');differences.append(name)
new=right['99-correctness-core-or-predicate'];assert new['exit']==0 and new['changedFiles']==[] and new['filesWritten']==[]
assert json.loads(new['stdout'])=={'files':0,'owners':0,'calls':0,'javascriptChanging':True}
summary={'passed':True,'baselineAdapters':len(a),'candidateAdapters':len(b),'allCommonExitCodesAndWritesIdentical':True,'rawReportsRetained':True,'onlySourceDerivedReportDifferences':differences,'coordinateProofs':proofs,'runtimeFingerprintProof':fingerprint,'newAdapterReplayWrites':0,'baselineRefusalsUnchanged':[r['adapter'] for r in a if r['exit']!=0]}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['coordinateProofs','runtimeFingerprintProof']}))
