function isA(n) { return n.kind === 1; }
function isC(n) { return n.kind === 3; }
export function findAncestor(node, callback) {
    while (node !== undefined) {
        if (callback(node)) {
            return node;
        }
        node = node.parent;
    }
    return undefined;
}
function isB(n) { return n.kind === 2; }
/** @internal */
export function orPredicate2(f1, f2) {
    return p => f1(p) || f2(p);
}
/** @internal */
export function orPredicate3(f1, f2, f3) {
    return p => f1(p) || f2(p) || f3(p);
}
/** @internal */
export function or(...fs) {
    return (...args) => {
        let lastResult;
        for (const f of fs) {
            lastResult = f(...args);
            if (lastResult) {
                return lastResult;
            }
        }
        return lastResult;
    };
}
const root = { kind: 3, parent: undefined, c: "root" };
const middle = { kind: 2, parent: root, b: "middle" };
const leaf = { kind: 9, parent: middle };
const checks = [];
const rest = or(...checks);
console.log(rest(root) === undefined ? "undefined" : "defined");
