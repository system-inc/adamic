'use strict';
const fs=require('node:fs'),path=require('node:path'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const [tree,out,mode='before']=process.argv.slice(2);fs.mkdirSync(out,{recursive:true});
const raw=fs.readFileSync(tree+'/src/compiler/core.ts','utf8'),sf=ts.createSourceFile('core.ts',raw,99,true);
const names=mode==='before'?['or']:['or','orPredicate2','orPredicate3'];
const ds=sf.statements.filter(n=>ts.isFunctionDeclaration(n)&&names.includes(n.name?.text));
assert.equal(ds.length,5);const start=raw.lastIndexOf('/** @internal */',ds[0].getStart(sf)),end=ds.at(-1).end;
assert(start>=0);const core=raw.slice(start,end);fs.writeFileSync(out+'/core.txt',core);
const test=fs.readFileSync('/workspace/adamic/internal/lower/predicates_overload_rest_test.go','utf8');
const shapes=test.match(/const overloadRestNodes = `([\s\S]*?)`/)[1]+'function isB(n: N): n is B { return n.kind === 2; }\n';
for(const arity of [2,3]){
 const dir=out+'/'+arity;fs.mkdirSync(dir,{recursive:true});
 const args=arity===2?'isA, isB':'isA, isB, isC';
 const callee=mode==='before'?'or':'orPredicate'+arity;
 const calls='\nconst root: C = { kind: 3, parent: undefined, c: "root" };\nconst middle: B = { kind: 2, parent: root, b: "middle" };\nconst leaf: N = { kind: 9, parent: middle };\nconst found = findAncestor(leaf, '+callee+'('+args+'));\nconsole.log(found === undefined ? "none" : String(found.kind));\nconst rootFound = findAncestor(root, '+callee+'('+args+'));\nconsole.log(rootFound === undefined ? "none" : String(rootFound.kind));\n';
 fs.writeFileSync(dir+'/main.ts',shapes+core+calls);
 assert(fs.readFileSync(dir+'/main.ts','utf8').includes(core));
}
fs.writeFileSync(out+'/provenance.json',JSON.stringify({tree,mode,coreStart:start,coreEnd:end,coreBytes:Buffer.byteLength(core),coreSha256:crypto.createHash('sha256').update(core).digest('hex'),declarations:ds.map(n=>n.name.text),verbatim:true},null,2)+'\n');
