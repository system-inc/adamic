import concurrent.futures,hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/workspace/scratch/or-predicate');out=root/'replay';out.mkdir(exist_ok=True)
repos={'before':pathlib.Path('/workspace/or-predicate-main'),'after':pathlib.Path('/workspace/adamic')};sources={'before':pathlib.Path('/workspace/or-predicate-before'),'after':pathlib.Path('/workspace/or-predicate-after')}
hook=pathlib.Path('/workspace/adamic/stage3/adapt/95-checker-axolotl-h/replay-hook.cjs')
def snapshot(tree):return {str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()}
def run(side):
 repo=repos[side];source=sources[side];tree=out/side
 shutil.copytree(source,tree,symlinks=True,ignore=lambda d,names:[n for n in names if pathlib.Path(d)==source and n in ['.git','node_modules','built']]);(tree/'node_modules').symlink_to('/workspace/or-predicate-packages/node_modules');logs=out/(side+'-logs');logs.mkdir();rows=[]
 for directory in sorted(p for p in (repo/'stage3/adapt').iterdir() if p.is_dir()):
  name=directory.name;old=snapshot(tree);writes=logs/(name+'.writes.json');env=dict(os.environ,NODE_PATH='/workspace/adamic/stage3/api/node_modules',REPLAY_TREE=str(tree),REPLAY_LOG=str(writes),NODE_OPTIONS='--require='+str(hook));started=time.time()
  with (logs/(name+'.stdout')).open('w') as stdout,(logs/(name+'.stderr')).open('w') as stderr:
   process=subprocess.Popen(['node',str(directory/'adapt.cjs'),str(tree)],cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=process.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,15)
    try:code=process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,9);code=process.wait()
  new=snapshot(tree)
  def normalize(s):return s.replace(str(tree),'TREE').replace(str(repo),'REPO').replace('/workspace/adamic','REPO').replace('/workspace/or-predicate-main','REPO')
  row={'adapter':name,'exit':code,'stdout':normalize((logs/(name+'.stdout')).read_text()),'stderr':normalize((logs/(name+'.stderr')).read_text()),'changedFiles':sorted(k for k in old.keys()|new.keys() if old.get(k)!=new.get(k)),'filesWritten':sorted(item for line in writes.read_text().splitlines() for item in json.loads(line)) if writes.exists() else [],'seconds':time.time()-started}
  rows.append(row);(out/(side+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(side,name,'child exit',code,flush=True)
 return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,side) for side in ['before','after']]
 for f in futures:f.result()
print('both replay stacks finished',flush=True)
