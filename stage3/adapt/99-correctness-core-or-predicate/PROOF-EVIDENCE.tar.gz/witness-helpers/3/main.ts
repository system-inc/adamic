interface N { readonly kind: number; readonly parent: N | undefined; }
interface A extends N { readonly kind: 1; readonly a: string; }
interface B extends N { readonly kind: 2; readonly b: string; }
interface C extends N { readonly kind: 3; readonly c: string; }
function isA(n: N): n is A { return n.kind === 1; }
function isC(n: N): n is C { return n.kind === 3; }
export function findAncestor<T extends N>(node: N | undefined, callback: (element: N) => element is T): T | undefined {
  while (node !== undefined) {
    if (callback(node)) { return node; }
    node = node.parent;
  }
  return undefined;
}
function isB(n: N): n is B { return n.kind === 2; }
export function orPredicate2<P, R1 extends P, R2 extends P>(f1: (p1: P) => p1 is R1, f2: (p2: P) => p2 is R2): (p: P) => p is R1 | R2 {
    return p => f1(p) || f2(p);
}
/** @internal */
export function orPredicate3<P, R1 extends P, R2 extends P, R3 extends P>(f1: (p1: P) => p1 is R1, f2: (p2: P) => p2 is R2, f3: (p3: P) => p3 is R3): (p: P) => p is R1 | R2 | R3 {
    return p => f1(p) || f2(p) || f3(p);
}
const root: C = { kind: 3, parent: undefined, c: "root" };
const middle: B = { kind: 2, parent: root, b: "middle" };
const leaf: N = { kind: 9, parent: middle };
const found = findAncestor(leaf, orPredicate3(isA, isB, isC));
console.log(found === undefined ? "none" : String(found.kind));
const rootFound = findAncestor(root, orPredicate3(isA, isB, isC));
console.log(rootFound === undefined ? "none" : String(rootFound.kind));
