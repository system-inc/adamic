const fs=require('node:fs'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
for(const phase of ['before','after','helpers','mutant'])for(const arity of [2,3]){
 const root='/workspace/scratch/or-predicate/witness-'+phase+'/'+arity,source=fs.readFileSync(root+'/main.ts','utf8');fs.writeFileSync(root+'/node.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2024}}).outputText);
}
const root='/workspace/scratch/or-predicate/witness-after',original=fs.readFileSync(root+'/2/main.ts','utf8'),start=original.indexOf('const found =');
for(const [name,call] of [['nonempty','const rest = or(isA, isB, isC, isA); console.log(rest(root) ? "true" : "false");'],['general','const checks: ((n: N) => boolean)[] = []; const rest = or<[N], boolean>(...checks); console.log(rest(root) === undefined ? "undefined" : "defined");']]){
 const dir='/workspace/scratch/or-predicate/witness-rest-'+name;fs.mkdirSync(dir,{recursive:true});const source=original.slice(0,start)+call+'\n';fs.writeFileSync(dir+'/main.ts',source);fs.writeFileSync(dir+'/node.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2024}}).outputText);
}

{
 const full=fs.readFileSync(root+'/core.txt','utf8'),sf=ts.createSourceFile('core.ts',full,99,true),implementation=sf.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='or'&&n.body);
 const shapes=original.slice(0,original.indexOf('/** @internal */')),declarations=original.slice(original.indexOf('const root: C'),original.indexOf('const found ='));
 const source=shapes+implementation.getText(sf)+'\n'+declarations+'const rest = or(isA, isB, isC, isA); console.log(rest(root) ? "true" : "false");\n';
 const dir='/workspace/scratch/or-predicate/witness-rest-implementation-only';fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(dir+'/main.ts',source);fs.writeFileSync(dir+'/node.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2024}}).outputText);
}
