'use strict';
const fs=require('node:fs'),path=require('node:path'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root='/workspace/or-predicate-before',out='/workspace/adamic/stage3/adapt/99-correctness-core-or-predicate',rows=JSON.parse(fs.readFileSync('/workspace/scratch/or-predicate/calls-before.json')).rows.filter(r=>r.originalOverload<3);
const normalize=s=>s.replace(/\r\n/g,'\n'),hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const pins=[],sites=[],audit=[];
function functionPath(n){let p=[];for(;n;n=n.parent)if(ts.isFunctionLike(n)&&n.name)p.unshift(n.name.getText(n.getSourceFile()));return p;}
for(const file of [...new Set(rows.map(r=>r.file))]){
 const raw=fs.readFileSync(root+'/'+file,'utf8'),sf=ts.createSourceFile(file,raw,99,true),calls=[];
 function visit(n){if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='or')calls.push(n);ts.forEachChild(n,visit);}visit(sf);
 const groups=new Map(),newNames=new Set();
 for(const row of rows.filter(r=>r.file===file)){
  const call=calls.find(n=>n.getStart(sf)===row.start);assert(call,'call position');assert.deepEqual(call.arguments.map(n=>n.getText(sf)),row.arguments);
  const name='orPredicate'+(row.originalOverload+1);newNames.add(name);
  let owner=call.parent;while(owner&&!(ts.isFunctionLike(owner)&&owner.name))owner=owner.parent;
  let kind='function',ownerPath;
  if(owner){ownerPath=functionPath(owner);}else{owner=call;while(owner.parent!==sf)owner=owner.parent;assert(ts.isVariableStatement(owner));assert.equal(owner.declarationList.declarations[0].name.getText(sf),'isImport');kind='variable';ownerPath=['isImport'];}
  const key=owner.getStart(sf);if(!groups.has(key))groups.set(key,{owner,kind,path:ownerPath,edits:[]});groups.get(key).edits.push({start:call.expression.getStart(sf)-key,end:call.expression.end-key,after:name});
  sites.push({file,line:row.line,owner:ownerPath,name,before:call.getText(sf),arguments:row.arguments,originalOverload:row.originalOverload});
 }
 for(const {owner,kind,path:ownerPath,edits} of groups.values()){
  const before=owner.getText(sf);let after=before;
  for(const e of edits.sort((a,b)=>b.start-a.start))after=after.slice(0,e.start)+e.after+after.slice(e.end);
  pins.push({file,kind,path:ownerPath,before:normalize(before),after:normalize(after)});
 }
 const imports=sf.statements.filter(n=>ts.isImportDeclaration(n)&&n.importClause?.namedBindings&&ts.isNamedImports(n.importClause.namedBindings)&&n.importClause.namedBindings.elements.some(e=>e.name.text==='or'));
 assert.equal(imports.length,1);const declaration=imports[0],element=declaration.importClause.namedBindings.elements.find(e=>e.name.text==='or');assert(!element.propertyName&&!element.isTypeOnly);
 const keepOr=calls.some(c=>!rows.some(r=>r.file===file&&r.start===c.getStart(sf)));
 const names=[...(keepOr?['or']:[]),...newNames].sort();
 const before=declaration.getText(sf),offset=element.getStart(sf)-declaration.getStart(sf),after=before.slice(0,offset)+names.join(',\n    ')+before.slice(element.end-declaration.getStart(sf));
 if(file==='src/compiler/checker.ts'){
  const fileName='/workspace/adamic/stage3/adapt/99-correctness-core-multimap/owners.json',all=JSON.parse(fs.readFileSync(fileName)),pin=all.find(p=>p.file===file&&p.kind==='import');assert(pin);assert.equal(pin.after,normalize(before),'original whole checker import pin');
  fs.writeFileSync(out+'/import-amendment.json',JSON.stringify({adaptation:'99-correctness-core-multimap',file,oldAfter:pin.after,newAfter:normalize(after),oldAfterSha256:pin.afterSha256,newAfterSha256:hash(normalize(after)),beforeSha256Unchanged:pin.beforeSha256},null,2)+'\n');
  pin.after=normalize(after);pin.afterSha256=hash(pin.after);fs.writeFileSync(fileName,JSON.stringify(all,null,2)+'\n');
 }else pins.push({file,kind:'import',module:declaration.moduleSpecifier.text,before:normalize(before),after:normalize(after)});
}
{
 const file='src/compiler/core.ts',raw=fs.readFileSync(root+'/'+file,'utf8'),sf=ts.createSourceFile(file,raw,99,true),ds=sf.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='or');assert.equal(ds.length,5);
 const before=normalize(raw.slice(ds[0].getStart(sf),ds.at(-1).end));
 function helper(n,arity){const signature=normalize(n.getText(sf));return signature.replace('function or<','function orPredicate'+arity+'<').slice(0,-1)+' {\n    return p => '+Array.from({length:arity},(_,i)=>'f'+(i+1)+'(p)').join(' || ')+';\n}';}
 const after=helper(ds[0],2)+'\n/** @internal */\n'+helper(ds[1],3)+'\n/** @internal */\n'+normalize(raw.slice(ds[2].getStart(sf),ds.at(-1).end));
 pins.unshift({file,kind:'coreGroup',before,after});
}
for(const pin of pins){pin.beforeSha256=hash(pin.before);pin.afterSha256=hash(pin.after);}
// Retain every required name search, including lexical ancestors; source hits
// are evidence to inspect, rather than an assertion that every hit is a pin.
const names=[...new Set(pins.filter(p=>p.path).flatMap(p=>p.path)),'or'];
for(const directory of fs.readdirSync('/workspace/adamic/stage3/adapt')){
 if(directory==='99-correctness-core-or-predicate')continue;
 const dir='/workspace/adamic/stage3/adapt/'+directory;if(!fs.statSync(dir).isDirectory())continue;
 for(const name of fs.readdirSync(dir))if(name==='adapt.cjs'||/(owners|sites).*\.json$/.test(name)){
  const text=fs.readFileSync(dir+'/'+name,'utf8');
  for(const owner of names)if(new RegExp('\\b'+owner+'\\b').test(text))audit.push({adapter:directory,file:name,owner,sha256:hash(text)});
 }
}
fs.writeFileSync(out+'/owners.json',JSON.stringify(pins,null,2)+'\n');fs.writeFileSync(out+'/sites.json',JSON.stringify(sites,null,2)+'\n');fs.writeFileSync(out+'/owner-search.json',JSON.stringify({names,hits:audit},null,2)+'\n');
assert.equal(sites.length,19);console.log(JSON.stringify({sites:sites.length,pins:pins.length,files:[...new Set(pins.map(p=>p.file))].length,functions:pins.filter(p=>p.kind==='function').length,variables:pins.filter(p=>p.kind==='variable').length}));
