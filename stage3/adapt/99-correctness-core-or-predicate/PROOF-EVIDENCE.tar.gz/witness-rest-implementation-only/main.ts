interface N { readonly kind: number; readonly parent: N | undefined; }
interface A extends N { readonly kind: 1; readonly a: string; }
interface B extends N { readonly kind: 2; readonly b: string; }
interface C extends N { readonly kind: 3; readonly c: string; }
function isA(n: N): n is A { return n.kind === 1; }
function isC(n: N): n is C { return n.kind === 3; }
export function findAncestor<T extends N>(node: N | undefined, callback: (element: N) => element is T): T | undefined {
  while (node !== undefined) {
    if (callback(node)) { return node; }
    node = node.parent;
  }
  return undefined;
}
function isB(n: N): n is B { return n.kind === 2; }
export function or<T extends unknown[], U>(...fs: ((...args: T) => U)[]): (...args: T) => U | undefined {
    return (...args) => {
        let lastResult: U | undefined;
        for (const f of fs) {
            lastResult = f(...args);
            if (lastResult) {
                return lastResult;
            }
        }
        return lastResult;
    };
}
const root: C = { kind: 3, parent: undefined, c: "root" };
const middle: B = { kind: 2, parent: root, b: "middle" };
const leaf: N = { kind: 9, parent: middle };
const rest = or(isA, isB, isC, isA); console.log(rest(root) ? "true" : "false");
