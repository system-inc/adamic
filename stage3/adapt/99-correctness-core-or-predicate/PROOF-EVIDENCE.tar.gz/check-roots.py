import os,pathlib,sys
roots=sorted(str(p) for p in (pathlib.Path(sys.argv[1])/'src/compiler').rglob('*.ts'))
assert len(roots)==79,len(roots)
os.execv('/workspace/scratch/or-predicate/adamic',['adamic','types',*roots])
