import json,pathlib,subprocess
root=pathlib.Path('/workspace/scratch/or-predicate/comparison');root.mkdir(exist_ok=True)
a=pathlib.Path('/workspace/or-predicate-before/built/local');b=pathlib.Path('/workspace/or-predicate-after/built/local');rows=[]
with (root/'all-emitted-hunks.diff').open('wb') as out:
 for p in sorted(a.rglob('*')):
  if not p.is_file() or not (p.suffix in ['.js','.mjs','.cjs'] or p.name in ['typescript.internal.d.ts','typescript.d.ts','tsserverlibrary.d.ts']):continue
  name=p.relative_to(a);q=b/name
  if not q.exists():raise RuntimeError('missing '+str(q))
  command=['diff','-u','--label','before/'+str(name),'--label','after/'+str(name),str(p),str(q)]
  child=subprocess.run(command,stdout=out,stderr=subprocess.PIPE);print(str(name)+' diff child exit '+str(child.returncode),flush=True);assert child.returncode in [0,1],child.stderr.decode()
  rows.append({'file':str(name),'diff_exit_code':child.returncode})
(root/'diff-results.json').write_text(json.dumps(rows,indent=2)+'\n')
