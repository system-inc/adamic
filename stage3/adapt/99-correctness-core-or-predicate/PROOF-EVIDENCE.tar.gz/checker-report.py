import collections,json,pathlib,re
root=pathlib.Path('/workspace/scratch/or-predicate');out=pathlib.Path('/workspace/adamic/stage3/adapt/99-correctness-core-or-predicate');ranges=json.loads((root/'checker-owner-ranges.json').read_text());summary={};lines=['# Full checker.ts census','', 'Each accepted attempt uses LATENT_FULL=1 and LATENT_ONLY_FILE=the completed tree\'s checker.ts, a 90-minute wall cap, and the common 30-minute child-output idle cap. The earlier preview-contaminated baseline attempt is excluded; all 746 baseline source hashes were verified after restoration before the accepted attempt started.','']
def source_line(where):
 m=re.search(r'/compiler/checker\.ts:(\d+):',where or '');return int(m[1]) if m else None
for side in ['before','after']:
 result_path=root/('checker-'+side+'-result.json');result=json.loads(result_path.read_text()) if result_path.exists() else {'status':'running'}
 raw=root/('checker-'+side+'.jsonl');records=[]
 if raw.exists():
  for row in raw.read_text().splitlines():
   try:records.append(json.loads(row))
   except json.JSONDecodeError:pass
 record=next((x for x in records if x.get('file','').endswith('/compiler/checker.ts')),None);complete=result.get('exit_code')==0 and record is not None
 entry={'process':result,'complete':complete,'checkerDiagnostics':records[0].get('diagnostics') if records else None,'owners':[]};summary[side]=entry
 resource_path=root/('checker-'+side+'-resource.json')
 if resource_path.exists():entry['resourceObservation']=json.loads(resource_path.read_text())
 lines+=['## '+side,'', 'Completed: '+str(complete).lower()+'. Child exit: '+str(result.get('exit_code','running'))+'. Seconds: '+str(round(result.get('seconds',0),3))+'. Stop reason: '+str(result.get('stop_reason'))+'.','']
 if not complete:
  if 'resourceObservation' in entry:lines += [entry['resourceObservation']['interpretation'],'Memory limit: '+str(entry['resourceObservation']['memoryLimitBytes'])+' bytes.','']
  entry['owners']=[{**owner,'findingsAvailable':False} for owner in ranges[side]]
  last=result.get('last_completed_unit');times=root/('checker-'+side+'-times.jsonl')
  if not last and times.exists() and times.stat().st_size:last=json.loads(times.read_text().splitlines()[-1])
  entry['lastCompletedUnit']=last;lines+=['Last emitted unit: '+(last['where'] if last else 'none')+'.','No complete finding stream was produced. Missing owner findings must not be interpreted as zero findings.',''];continue
 lines+=['Checker diagnostics: '+str(len(entry['checkerDiagnostics']))+'.','']
 for owner in ranges[side]:
  def inside(where):
   line=source_line(where);return line is not None and owner['startLine']<=line<=owner['endLine']
  units=[u for u in record['units'] if inside(u['where'])]
  direct=[f for f in record['findings'] if inside(f.get('where')) or inside(f.get('site_where'))]
  attributed=[f for f in record['findings'] if inside(f.get('unit')) and f not in direct]
  entry['owners'].append({**owner,'units':units,'directSourceFindings':direct,'additionalAttributedFindings':attributed})
  lines+=['### '+owner['name'],'','Source range: '+str(owner['startLine'])+' through '+str(owner['endLine'])+'. Units: '+str(len(units))+'. Direct events: '+str(len(direct))+'. Additional unit-attributed events elsewhere: '+str(len(attributed))+'.','','| Scope | Kind | Phase | Location | Reason | Count |','| --- | --- | --- | --- | --- | ---: |']
  counted=collections.Counter((scope,f['kind'],f['phase'],f['where'],f['reason']) for scope,rows in [('direct',direct),('attributed',attributed)] for f in rows)
  if not counted:lines.append('| direct | none recorded | none | none | none | 0 |')
  for (scope,kind,phase,where,reason),count in sorted(counted.items()):lines.append('| '+scope+' | '+kind+' | '+phase+' | '+where.replace('/workspace/or-predicate-'+side+'/','')+' | '+reason.replace('|','\\|').replace('\n',' ')+' | '+str(count)+' |')
  lines.append('')
lines+=['The direct table includes every event with a finding or source-site location in each owner. The attributed table additionally includes every event raised while lowering an owner or its nested unit whose physical finding lies elsewhere. Boundary events remain labeled Boundary. All full raw JSONL, unit timings, exact sources and process results are retained in PROOF-EVIDENCE.tar.gz.','','The standalone original/mutant witnesses restore the binder refusal, but both adapted arities remain blocked on main by the exact R1 checked-claim NotYet recorded in README.md. A timed-out checker census does not waive that failed acceptance condition.']
(out/'CHECKER-CENSUS.md').write_text('\n'.join(lines)+'\n');(out/'checker-census-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({side:{'complete':v['complete'],'exit':v['process'].get('exit_code'),'seconds':v['process'].get('seconds')} for side,v in summary.items()}))
