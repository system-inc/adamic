function isA(n) { return n.kind === 1; }
function isC(n) { return n.kind === 3; }
export function findAncestor(node, callback) {
    while (node !== undefined) {
        if (callback(node)) {
            return node;
        }
        node = node.parent;
    }
    return undefined;
}
function isB(n) { return n.kind === 2; }
/** @internal */
export function or(...fs) {
    return (...args) => {
        let lastResult;
        for (const f of fs) {
            lastResult = f(...args);
            if (lastResult) {
                return lastResult;
            }
        }
        return lastResult;
    };
}
const root = { kind: 3, parent: undefined, c: "root" };
const middle = { kind: 2, parent: root, b: "middle" };
const leaf = { kind: 9, parent: middle };
const found = findAncestor(leaf, or(isA, isB));
console.log(found === undefined ? "none" : String(found.kind));
const rootFound = findAncestor(root, or(isA, isB));
console.log(rootFound === undefined ? "none" : String(rootFound.kind));
