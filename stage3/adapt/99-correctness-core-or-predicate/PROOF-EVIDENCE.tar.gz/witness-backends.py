import json,os,pathlib,subprocess
root=pathlib.Path('/workspace/scratch/or-predicate');results=[]
def run(label,command,folder):
 with (folder/(label+'.stdout')).open('wb') as out,(folder/(label+'.stderr')).open('wb') as err:r=subprocess.run(command,stdout=out,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1'))
 record={'label':label,'command':command,'exit_code':r.returncode,'stdout':(folder/(label+'.stdout')).read_text(),'stderr':(folder/(label+'.stderr')).read_text()};print(label+' child exit '+str(r.returncode),flush=True);return record
for phase in ['before','after','helpers','mutant']:
 for arity in [2,3]:
  folder=root/('witness-'+phase)/str(arity);source=str(folder/'main.ts');entry={'phase':phase,'arity':arity}
  entry['node']=run('node',['node',str(folder/'node.mjs')],folder)
  assert entry['node']['exit_code']==0;assert entry['node']['stdout']==('2\nnone\n' if arity==2 else '2\n3\n')
  entry['javascript_compile']=run('javascript-compile',[str(root/'adamic'),'js',source],folder)
  entry['native_compile']=run('native-compile',[str(root/'adamic'),'build',source,'-o',str(folder/'native'),'--sanitize'],folder)
  if entry['javascript_compile']['exit_code']==0:
   (folder/'generated.mjs').write_text(entry['javascript_compile']['stdout']);entry['javascript_run']=run('javascript-run',['node','--disable-warning=ExperimentalWarning','/workspace/adamic/oracle/node.mjs',str(folder/'generated.mjs')],folder)
  if entry['native_compile']['exit_code']==0:entry['native_run']=run('native-run',[str(folder/'native')],folder)
  if phase in ['before','mutant']:
   for backend in ['javascript_compile','native_compile']:assert entry[backend]['exit_code']==1 and 'overload 1 of or type parameter P cannot satisfy implementation parameter T' in entry[backend]['stderr']
  results.append(entry);(root/'witness-backends.json').write_text(json.dumps(results,indent=2)+'\n')
for form in ['nonempty','general','implementation-only']:
 folder=root/('witness-rest-'+form);results.append({'phase':'rest-'+form,'node':run('node',['node',str(folder/'node.mjs')],folder),'javascript_compile':run('javascript-compile',[str(root/'adamic'),'js',str(folder/'main.ts')],folder)})
(root/'witness-backends.json').write_text(json.dumps(results,indent=2)+'\n')
