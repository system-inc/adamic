import json,os,pathlib,signal,subprocess,sys,time
label,tree=sys.argv[1:];root=pathlib.Path('/workspace/scratch/or-predicate');started=time.time();log=root/(label+'.log');times=root/(label+'-times.jsonl');raw=root/(label+'.jsonl')
env={k:v for k,v in os.environ.items() if not k.startswith('LATENT_')};env.update(LATENT_FULL='1',LATENT_ONLY_FILE=tree+'/src/compiler/checker.ts',LATENT_ASSERT_NO_OUTPUT='1',LATENT_TIMES=str(times))
reason=None
with log.open('wb') as output:
 p=subprocess.Popen([str(root/'latent'),tree+'/src/compiler',str(raw)],env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  now=time.time();last=max([started]+[f.stat().st_mtime for f in [log,times,raw] if f.exists()])
  if now-started>=5400:reason='90 minute wall limit'
  elif now-last>=1800:reason='30 minutes without child output'
  if reason:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:pass
 code=p.returncode
 try:os.killpg(p.pid,signal.SIGKILL)
 except ProcessLookupError:pass
last_unit=json.loads(times.read_text().splitlines()[-1]) if times.exists() and times.stat().st_size else None
(root/(label+'-result.json')).write_text(json.dumps(dict(exit_code=code,seconds=time.time()-started,limit_seconds=5400,stop_reason=reason,last_completed_unit=last_unit,raw_bytes=raw.stat().st_size if raw.exists() else 0),indent=2)+'\n')
print(label+' child exit '+str(code),flush=True)
sys.exit(code if code>=0 else 128-code)
