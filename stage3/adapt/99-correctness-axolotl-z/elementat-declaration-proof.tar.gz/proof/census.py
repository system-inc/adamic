import os,sys,json,time,shutil,re
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/elementat-function');from supervise import run
s=Path('/workspace/scratch/elementat-function');repo=Path('/workspace/adamic')
while not (s/'build-proof-ready.json').exists():time.sleep(1)
while not any(json.loads(l)['name']=='build-latent' for l in (s/'commands.jsonl').read_text().splitlines()):time.sleep(1)
rows=[json.loads(l) for l in (s/'commands.jsonl').read_text().splitlines() if json.loads(l)['name']=='build-latent'];assert rows[-1]['exit']==0,rows[-1]
pin=json.loads((repo/'stage3/adapt/99-correctness-axolotl-z/owners.json').read_text())[0]
mutant=s/'mutant';shutil.copytree(s/'after/src',mutant/'src');file=mutant/'src/compiler/core.ts';text=file.read_bytes().decode();newline='\r\n' if '\r\n' in text else '\n';a=pin['after'].replace('\n',newline);b=pin['previous'].replace('\n',newline);assert text.count(a)==1;file.write_bytes(text.replace(a,b).encode());assert file.read_bytes()==(s/'before/src/compiler/core.ts').read_bytes()
result={}
def normalize(where,label):
 m=re.search(r'core\.ts:(\d+):(\d+)$',where)
 if not m:return where.replace(str(s/label),'TREE')
 line=int(m[1]);col=int(m[2])
 if label=='after':
  core=(s/'after/src/compiler/core.ts').read_bytes().decode();start=core[:core.index(a)].count('\n')+1;end=start+pin['after'].count('\n')
  if line>end:line+=pin['previous'].count('\n')-pin['after'].count('\n')
 return f'core.ts:{line}:{col}'
for label in ['before','after','mutant']:
 tree=s/label;env={k:v for k,v in os.environ.items() if not k.startswith('LATENT_')};env.update(LATENT_FULL='1',LATENT_ONLY_FILE=str(tree/'src/compiler/core.ts'),LATENT_ASSERT_NO_OUTPUT='1',LATENT_TIMES=str(s/(label+'-times.jsonl')),GOMAXPROCS='2')
 r=run('census-'+label,[str(s/'bin/latent'),str(tree/'src/compiler'),str(s/(label+'-census.jsonl'))],env=env);assert r['exit']==0,r
 records=[json.loads(l) for l in (s/(label+'-census.jsonl')).read_text().splitlines()];metadata=records[0];assert not metadata['checker_rejected'] and metadata['diagnostics']==[]
 core=next(r for r in records if r.get('file','').endswith('/core.ts'));sites=[r for r in core['findings'] if r['kind'] in ['Refused','NotYet']];keys=sorted(set((normalize(r['where'],label),r['kind'],r['reason'],r['phase']) for r in sites));f9=[r for r in sites if r['reason']=='a function returning T | undefined'];result[label]={'exit':r['exit'],'metadata':metadata,'units':len(core['units']),'sites':sites,'normalizedKeys':keys,'F9':f9}
 if label!='after':assert f9 and all(r['where'].endswith('core.ts:1078:5') for r in f9),f9
 else:
  assert not f9;assert all(u['status']=='deferred_generic_instantiation' for u in core['units'] if u.get('name') in ['elementAt','toOffset']);result[label]['helperUnits']=[u for u in core['units'] if u.get('name') in ['elementAt','toOffset']]
 (s/'census-proof.json').write_text(json.dumps(result,indent=2)+'\n')
assert set(map(tuple,result['after']['normalizedKeys']))<=set(map(tuple,result['before']['normalizedKeys']))
removed=set(map(tuple,result['before']['normalizedKeys']))-set(map(tuple,result['after']['normalizedKeys']));assert len(removed)==1 and next(iter(removed))[2]=='a function returning T | undefined',removed
result['noNewSites']=True;result['removedSites']=[list(r) for r in removed];result['mutantRestoresF9']=True;(s/'census-proof.json').write_text(json.dumps(result,indent=2)+'\n');print('F9 gone, no sites added, const mutant restores F9',flush=True)
