import os,signal,subprocess,time,json,sys
from pathlib import Path
S=Path('/workspace/scratch/elementat-function');S.mkdir(exist_ok=True)
def run(name,args,cwd='/workspace/adamic',env=None,limit=3600):
 start=time.monotonic();last=start;signature=None;reason=None;logfile=S/(name+'.log')
 with logfile.open('wb') as log:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while p.poll() is None:
    now=time.monotonic();current=logfile.stat().st_size
    if current!=signature:signature=current;last=now
    if now-last>1800 or now-start>limit:
     reason='30 minutes without output' if now-last>1800 else 'configured elapsed bound';os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=10)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
     break
    time.sleep(.2)
   p.wait()
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
 row={'name':name,'args':args,'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-start,'stoppingReason':reason,'groupCleaned':True}
 with (S/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True);return row
if __name__=='__main__':
 r=run(sys.argv[1],sys.argv[2:]);raise SystemExit(r['exit'] if r['exit']>=0 else 128-r['exit'])
