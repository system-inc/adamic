import hashlib,json,tarfile
from pathlib import Path
from collections import Counter
s=Path('/workspace/scratch/elementat-function');repo=Path('/workspace/adamic');plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());summary=json.loads((s/'lane-proof.json').read_text());assert summary['complete'];byName={r['name']:r for r in plan['units']};seen=[];counts=Counter()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for entry in summary['pieces']:
 archive=s/'lane-archives'/entry['archive'];assert archive.stat().st_size<20_000_000 and hashlib.sha256(archive.read_bytes()).hexdigest()==entry['sha256'];prefix=f"lane-piece-{entry['number']:02d}/"
 with tarfile.open(archive) as tar:
  for line in tar.extractfile(prefix+'SHA256SUMS').read().decode().splitlines():
   expected,name=line.split('  ',1);assert hashlib.sha256(tar.extractfile(prefix+name).read()).hexdigest()==expected,name
  record=json.load(tar.extractfile(prefix+'piece.json'));assert record['sourceAndBuildFrozen']
  for child in record['children']:
   name=child['name'];report=child['report'];unit=byName[name];assert child['exit']==0 and report['status']=='pass' and report['errors']==[];assert report['counts']==unit['expect'] and report['baseline_diffs']==unit['baseline_diffs'];assert report['inputs_hash']==digest(dict(artifact='stage3-adapted-tree',api=plan['api_digest'],runtime=plan['runtime'],unit=unit))
   observations=json.load(tar.extractfile(prefix+name+'/observations.json'));titles=Counter((r['task']['runner'],r['task']['file'],' '.join(p for p in r['name'] if p)) for r in observations);assert digest(sorted((*key,n) for key,n in titles.items()))==unit['names_digest'];actual={'pass':sum(r['status']=='pass' for r in observations),'fail':sum(r['status']=='fail' for r in observations),'skip':sum(r['status']=='pending' for r in observations)};assert actual==report['counts'];counts.update(actual);seen.append(name)
assert len(seen)==len(set(seen))==len(plan['units']);assert sorted(seen)==sorted(byName);assert counts==plan['counts']==summary['counts']
result={'complete':True,'units':len(seen),'counts':dict(counts),'duplicates':0,'allArchiveAndMemberHashesVerified':True,'allRawTestIdentitiesVerified':True,'allInputHashesVerified':True,'allBaselineGuardsVerified':True};(s/'reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
