import os,json,hashlib,shutil,tarfile,subprocess
from pathlib import Path
s=Path('/workspace/scratch/elementat-function');repo=Path('/workspace/adamic');out=repo/'stage3/adapt/99-correctness-axolotl-z'
read=lambda name:json.loads((s/name).read_text())
commands=[json.loads(l) for l in (s/'commands.jsonl').read_text().splitlines()]
def status(name):
 rows=[r for r in commands if r['name']==name];assert rows and rows[-1]['exit']==0,rows;return rows[-1]
lane=read('lane-proof.json');reconciliation=read('reconciliation.json');assert lane['complete'] and reconciliation['complete'];comparison=read('comparison.log');replay=read('replay.json');census=read('census-proof.json');witness=read('Node-P2.log');contract=read('owner-contract.log')
assert len(replay)==95 and all(r['before']==r['after'] for r in replay if r['adapter']!='99-correctness-axolotl-z');assert census['noNewSites'] and census['mutantRestoresF9'];assert witness['rows']==30 and witness['expectedValueAndIdentityChecks']==30
for name in ['apply-before','apply-after-final','types-before','types-after','build-before','build-after','comparison','Node-P2','owner-contract']:status(name)
for side in ['before','after']:
 expected=read(side+'-source.json');actual={str(p.relative_to(s/side/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((s/side/'src').rglob('*')) if p.is_file()};assert expected==actual,side
for name,digest in read('implementation-sha256.json').items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==digest,name
for side in ['before','after','mutant']:
 records=[json.loads(l) for l in (s/(side+'-census.jsonl')).read_text().splitlines()];core=records[1]
 if side=='after':
  units=[u for u in core['units'] if u.get('name') in ['elementAt','toOffset']];assert {u['name'] for u in units}=={'elementAt','toOffset'};locations={u['where'] for u in units};findings=[f for f in core['findings'] if f['unit'] in locations];assert findings==[],findings;census['after']['helperFindings']=findings
(s/'census-proof.json').write_text(json.dumps(census,indent=2)+'\n')
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip();assert base=='e8f3723bd41abcebedabfcc7546fdf104a9bbf08'
matched=[{'adapter':r['adapter'],'exit':r['before']['exit']} for r in replay if r['before']['exit']]
proof={'task':'k220r1g','base':base,'acceptance':{'actor':'Compiler','delegationTask':'b5w3ycg','delegationTime':'Nov 7 03:20Z','classification':'established-shape','javascriptChanging':True},'typesRoots':79,'ownerContract':contract,'applies':{'before':status('apply-before'),'after':status('apply-after-final')},'types':{'before':status('types-before'),'after':status('types-after')},'comparison':comparison,'replay':{'adapters':len(replay),'only99zDiffers':True,'matchedExistingNonzeroResults':matched},'census':census,'NodeP2':witness,'lane':lane,'reconciliation':reconciliation,'acceptedCounts':read('accepted-count-lineage.json'),'implementationSha256':read('implementation-sha256.json'),'ordinaryCompilerSha256':hashlib.sha256((s/'bin/adamic').read_bytes()).hexdigest(),'censusBinarySha256':hashlib.sha256((s/'bin/latent').read_bytes()).hexdigest(),'sourceOnly99z':True,'ownerByteScope':read('owner-byte-scope.json')}
raw=s/'proof-raw';raw.mkdir()
# Logs, commands, sources and scripts; compiled products and full project trees stay outside the archive.
for p in s.iterdir():
 if p.is_file() and ((p.suffix in ['.log','.json','.jsonl','.py','.cjs','.diff','.txt'] and not p.name.startswith('core-js-')) or p.suffix=='.diff'):
  shutil.copyfile(p,raw/p.name)
shutil.copytree(s/'lane-archives',raw/'lane-pieces')
shutil.copytree(s/'latent-overlay',raw/'latent-overlay')
inputs=raw/'source-inputs';inputs.mkdir()
for side in ['before','after','mutant']:shutil.copyfile(s/side/'src/compiler/core.ts',inputs/(side+'-core.ts.txt'))
for name in ['adapt.cjs','contract.cjs','owners.json']:shutil.copyfile(out/name,inputs/name)
for name in ['functions.go','modules.go']:shutil.copyfile(repo/'internal/lower'/name,inputs/(name+'.txt'))
shutil.copyfile(repo/'stage3/lane/shard-plan.json',raw/'shard-plan.json')
old=raw/'accepted-measurement';old.mkdir()
for name in ['static.json','reconciliation.json','provenance.json']:
 data=subprocess.check_output(['git','show','5ab9992068bb004caacc8637b49a319533b5a002:stage3/census/elementat-declaration/'+name],cwd=repo);(old/name).write_bytes(data)
assert not list(raw.rglob('*.go'))
files=sorted(p for p in raw.rglob('*') if p.is_file());(raw/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(raw))+'\n' for p in files))
archive=out/'elementat-declaration-proof.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:tar.add(raw,arcname='proof')
assert archive.stat().st_size<20_000_000,archive.stat().st_size
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'elementat-declaration-proof.sha256').write_text(sha+'  '+archive.name+'\n');proof['archive']={'file':archive.name,'sha256':sha,'bytes':archive.stat().st_size};(out/'DECLARATION-PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
jsDiffs='\n'.join('### '+name+'\n\n```diff\n'+(s/(name+'.diff')).read_text()+'```\n' for name in ['_tsc.js','typescript.js','core-js-false','core-js-true'])
internal=(s/'typescript.internal.d.ts.diff').read_text();largest=max(p['seconds'] for p in lane['pieces'])
text=f'''# 99z declaration amendment proof, k220r1g

Built on origin/main `{base}`. Compiler accepts this established-shape
amendment under Adamic's delegation, task b5w3ycg, Nov 7 03:20Z.
No compiler or lane-runner source is changed. The adapter remains
javascriptChanging true. The only upstream source change is elementAt's
const-arrow owner becoming the generic function declaration; the fallback
body and attached JSDoc are byte-identical.

## Completed checks

| Check | Result |
| --- | --- |
| Full baseline apply from isolated main checkout | Exit 0 |
| Full amended apply | Exit 0 |
| Owner contract | {contract['passed']} checks pass; pristine and previous const accepted; declaration replay preserves bytes and mtime; half owners refuse without writes; LF/CRLF and JSDoc preserved |
| Paired complete-tree replay | 95 adapters; every other adapter has identical exit and normalized output; only 99z reports one edit before and zero after |
| Ordinary adamic types, all 79 sorted roots together | Before and after exit 0, zero diagnostics |
| Ordinary compiler builds | Both exit 0 |
| Source scope | All 746 files compared; only compiler/core.ts differs |
| All nine emitted compiler JavaScript files | Only _tsc.js and typescript.js differ; their bodies and every other executable statement match after removing only elementAt's owner |
| typescript.d.ts and tsserverlibrary.d.ts | Byte-identical |
| typescript.internal.d.ts | Exactly two hunks, shown below |
| Real amended whole lane | 398 units exactly once in 20 pieces; 106,366 passing, one sanctioned failure, zero skips; every unit report passes |
| Core.ts site census | Before, after and mutant exit 0 with zero checker diagnostics; F9 gone, no new Refused/NotYet sites, no elementAt or toOffset findings |
| Const-restoring mutant | Restores F9, core.ts:1078:5, NotYet: a function returning T \\| undefined |
| Fresh Node P2 witnesses | All 30 rows and 30 expected-value/identity checks pass; extracted before and after owners agree byte for byte |

The complete before source is byte-identical to the source in accepted
measurement commit `5ab9992068bb004caacc8637b49a319533b5a002`.
Its accepted counts remain 11 call sites, 1,936 calls, 0 differences, and
0 each of early reads, new, prototype/name/length reads, value uses,
reassignments, and ts.elementAt reads. This run exercises the actual amended
compiler through the complete lane; it does not substitute a shadow helper.

All lane identity, baseline, API, failure and count guards remain enabled.
The largest piece is {largest:.3f} seconds. Each piece checks frozen src and
built/local bytes, retains each child's own exit code and full unit logs,
and has its own SHA256SUMS. Independent reconciliation reopens every archive,
rebuilds raw test identities and counts, verifies unit input hashes and
baseline guards, and rejects duplicates or missing units.

Paired replay preserves {len(matched)} existing nonzero results on both sides.
These matched refusals are recorded explicitly, not claimed as successful
idempotent replays of those other adapters. Their full outputs and the
95-row comparison are retained in replay.json. 99z itself applies to the
old output and replays the declaration with no write.

The site census uses LATENT_FULL=1, LATENT_ONLY_FILE=core.ts, and
LATENT_ASSERT_NO_OUTPUT=1, with no speculative or replay flags. The guarded
measurement binary cannot return usable IR. Its legacy checker-rejected
label is retained, while actual checker_rejected metadata is false.
Both elementAt and toOffset are deferred generic-instantiation units, with
zero findings. No claim of a concrete native compiler build follows from
that deferral. Site comparison maps later line coordinates across the four
removed owner lines; kind, reason, phase and source locations otherwise
match exactly. The sole removed blocker is F9. Restoring the previous const
makes the mutant's core.ts byte-identical to the baseline and restores F9.

P2 retains interface Item, number and string arrays, offsets -1, 0, 1, 5,
-5, and undefined arrays. The fresh witness sources extract each actual
full-applied owner and toOffset, then reuse the prior P2 driver. Their
90 output lines include a label, value and identity/equality assertion per row.

## Every changed emitted JavaScript hunk

All nine output files are inventoried in comparison.log with both hashes.
_tsc.js and typescript.js each have two hunks. The other seven are identical:
_tsserver.js, _typingsInstaller.js, tsc.js, tsserver.js, tsserverlibrary.js,
typingsInstaller.js and watchGuard.js. Core.ts is also transpiled with
comments retained and removed; all hunks from both modes follow. The AST
comparison proves the elementAt body and the remaining executable program
are unchanged; only its binding form and placement differ.

{jsDiffs}
## Both internal declaration hunks

```diff
{internal}```

## Evidence and reproduction

[DECLARATION-PROOF.json](DECLARATION-PROOF.json) records statuses, compiler
hashes, comparisons, counts and archive identity.
[elementat-declaration-proof.tar.gz](elementat-declaration-proof.tar.gz)
contains the complete commands and child exit codes, source manifests,
source inputs, all JavaScript/declaration diffs, 79-root type logs, paired
replay outputs, census streams and timings, Node witnesses, lane-piece
archives and their independent reconciler. It includes the pinned meter
overlay generator and its physical .go.txt inputs. Internal SHA256SUMS
covers every member; the adjacent .sha256 file covers the outer archive.
The outer archive is {archive.stat().st_size} bytes, below 20 MB; each lane
piece is also below 20 MB. Bulky new proof data adds only four files beside
this directory's existing historical evidence.

The raw commands preserve an early amended-apply preparation run stopped
before finalizing the owner contract. It is excluded from the two accepted
full applies. All accepted transformation inputs are frozen and hashed.
The final source and built-product manifests are rechecked at closeout.
No native binary, compiler binary, node_modules directory or full built
TypeScript product is submitted. The scripts run from the archived scratch
paths after sourcing /workspace/adamic-tools/env.sh and setting
ADAMIC_TYPESCRIPT_SOURCE=/workspace/typescript-source at the pinned
050880ce59e30b356b686bd3144efe24f875ebc8 checkout. No upstream issue was sent.
'''
assert '\u2014' not in text and '\u2013' not in text
(out/'DECLARATION-PROOF.md').write_text(text)
print(json.dumps({'archiveBytes':archive.stat().st_size,'archiveSha256':sha,'laneCounts':lane['counts'],'newProofFiles':4}),flush=True)
