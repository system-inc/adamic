import sys,time,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/elementat-function');from supervise import run
s=Path('/workspace/scratch/elementat-function')
while not (s/'build-proof-ready.json').exists():time.sleep(1)
r=run('Node-P2',['node',str(s/'node-witness.cjs')]);assert r['exit']==0,r
