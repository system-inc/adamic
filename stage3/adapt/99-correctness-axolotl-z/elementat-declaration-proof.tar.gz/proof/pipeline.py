import os,sys,time,json,shutil,hashlib,difflib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'/workspace/scratch/elementat-function');from supervise import run
s=Path('/workspace/scratch/elementat-function');repo=Path('/workspace/adamic');before=s/'before';after=s/'after'
def wait(name):
 while True:
  rows=[json.loads(l) for l in (s/'commands.jsonl').read_text().splitlines() if json.loads(l)['name']==name]
  if rows:assert rows[-1]['exit']==0,rows[-1];return
  time.sleep(1)
def do(name,args,**kw):
 r=run(name,args,**kw);assert r['exit']==0,r;return r
for name in ['apply-before','apply-after-final','build-tools','setup']:wait(name)
do('install-after',['npm','ci','--no-audit','--no-fund'],cwd=after)
(s/'packages').mkdir();shutil.move(str(after/'node_modules'),str(s/'packages/node_modules'))
for tree in [before,after]:(tree/'node_modules').symlink_to(s/'packages/node_modules',target_is_directory=True)
do('build-before',['npm','run','build:compiler'],cwd=before)
do('build-after',['npm','run','build'],cwd=after)
do('harness-after',['npm','exec','hereby','--','tests'],cwd=after)
do('comparison',['node',str(s/'compare.cjs')])
comparisons={}
pairs=[('core-source',before/'src/compiler/core.ts',after/'src/compiler/core.ts')]
for comment in ['false','true']:pairs.append(('core-js-'+comment,s/('core-js-'+comment+'-before.txt'),s/('core-js-'+comment+'-after.txt')))
for row in json.loads((s/'comparison.log').read_text())['emitted']:pairs.append((row['name'],before/'built/local'/row['name'],after/'built/local'/row['name']))
for name in ['typescript.d.ts','tsserverlibrary.d.ts','typescript.internal.d.ts']:pairs.append((name,before/'built/local'/name,after/'built/local'/name))
for name,a,b in pairs:
 old=a.read_text().splitlines(True);new=b.read_text().splitlines(True);diff=''.join(difflib.unified_diff(old,new,fromfile='before/'+name,tofile='after/'+name));(s/(name+'.diff')).write_text(diff);comparisons[name]={'identical':old==new,'hunks':diff.count('\n@@'),'diffFile':name+'.diff'}
(s/'hunks.json').write_text(json.dumps(comparisons,indent=2)+'\n')
# The same ordinary main-tip binary checks each complete set together.
for label,tree in [('before',before),('after',after)]:
 roots=sorted(str(p) for p in (tree/'src/compiler').rglob('*.ts'));assert len(roots)==79,len(roots);(s/(label+'-roots.json')).write_text(json.dumps(roots,indent=2)+'\n');do('types-'+label,[str(s/'bin/adamic'),'types',*roots],env=dict(os.environ,GOMAXPROCS='2'))
(s/'build-proof-ready.json').write_text(json.dumps({'ready':True})+'\n')
# Complete private copies preserve the real replay protocol, including matched existing refusals.
for label,tree in [('before',before),('after',after)]:
 shutil.copytree(tree,s/('replay-'+label),symlinks=True,ignore=shutil.ignore_patterns('node_modules'));(s/('replay-'+label)/'node_modules').symlink_to(s/'packages/node_modules',target_is_directory=True)
rows=[]
for adapter in sorted(p for p in (repo/'stage3/adapt').iterdir() if p.is_dir()):
 def replay(label):
  tree=s/('replay-'+label);name='replay-'+label+'-'+adapter.name;r=run(name,['node',str(adapter/'adapt.cjs'),str(tree)],env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules')));return label,{'exit':r['exit'],'output':(s/(name+'.log')).read_text().replace(str(tree),'TREE')}
 with ThreadPoolExecutor(max_workers=2) as pool:row={'adapter':adapter.name,**dict(pool.map(replay,['before','after']))}
 rows.append(row);(s/'replay.json').write_text(json.dumps(rows,indent=2)+'\n')
 if adapter.name=='99-correctness-axolotl-z':
  assert row['before']['exit']==row['after']['exit']==0;assert json.loads(row['before']['output'])=={'files':1,'edits':1,'javascriptChanging':True};assert json.loads(row['after']['output'])=={'files':0,'edits':0,'javascriptChanging':True}
 else:assert row['before']==row['after'],row
print('Paired replay differs only at 99z',flush=True)
# The lane product leaves dependencies outside its immutable view.
for tree in [before,after]:(tree/'node_modules').unlink()
link=repo/'stage3/typescript/node_modules';assert not link.exists();link.symlink_to(s/'packages/node_modules',target_is_directory=True)
(s/'lane-ready.json').write_text(json.dumps({'ready':True})+'\n')
