import os,signal,subprocess,time,json,hashlib,shutil,tarfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
s=Path('/workspace/scratch/elementat-function');repo=Path('/workspace/adamic')
while not (s/'lane-ready.json').exists():time.sleep(1)
plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());results=s/'lane-results';results.mkdir();archives=s/'lane-archives';archives.mkdir();tree=s/'after'
def snapshot():return {str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for base in ['src','built/local'] for p in sorted((tree/base).rglob('*')) if p.is_file()}
frozen=snapshot();(s/'lane-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n');summary={'inventory':len(plan['units']),'completedUnits':[],'pieces':[],'counts':{'pass':0,'fail':0,'skip':0},'complete':False}
def unit_run(unit,d):
 name=unit['name'];env=dict(os.environ,STAGE3_ADAPTED_TREE=str(tree),STAGE3_SHARD_SECONDS='90',NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('NODE_OPTIONS',None);env.pop('EA_CALL_DIR',None)
 with (d/(name+'.log')).open('wb') as log:
  p=subprocess.Popen(['python3',str(repo/'stage3/lane/shard.py'),name,str(results)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);reason=None
  try:p.wait(timeout=120)
  except subprocess.TimeoutExpired:reason='unit wrapper elapsed bound'
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
 report=json.loads((results/name/'report.json').read_text()) if (results/name/'report.json').exists() else {};return {'name':name,'exit':p.returncode,'stoppingReason':reason,'report':report}
for start in range(0,len(plan['units']),20):
 number=start//20+1;d=s/f'lane-piece-{number:02d}';d.mkdir();started=time.monotonic();subset=plan['units'][start:start+20]
 with ThreadPoolExecutor(max_workers=4) as pool:rows=[f.result() for f in as_completed([pool.submit(unit_run,u,d) for u in subset])]
 record={'number':number,'seconds':time.monotonic()-started,'children':rows,'sourceAndBuildFrozen':frozen==snapshot(),'units':[u['name'] for u in subset]}
 for row in rows:
  p=results/row['name']
  if p.exists():shutil.copytree(p,d/row['name'],ignore=shutil.ignore_patterns('adapted-tree'))
  if row['exit']==0 and row['report'].get('status')=='pass':
   summary['completedUnits'].append(row['name'])
   for k,v in row['report']['counts'].items():summary['counts'][k]+=v
 (d/'piece.json').write_text(json.dumps(record,indent=2)+'\n');files=sorted(p for p in d.rglob('*') if p.is_file());(d/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(d))+'\n' for p in files))
 archive=archives/f'piece-{number:02d}.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:tar.add(d,arcname=d.name)
 assert archive.stat().st_size<20_000_000
 entry={'number':number,'units':record['units'],'seconds':record['seconds'],'sourceAndBuildFrozen':record['sourceAndBuildFrozen'],'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()};summary['pieces'].append(entry);summary['complete']=len(summary['completedUnits'])==len(plan['units']);(s/'lane-proof.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'piece':number,'completed':len(summary['completedUnits']),'counts':summary['counts'],'seconds':entry['seconds']}),flush=True)
 for row in rows:shutil.rmtree(results/row['name']/'adapted-tree',ignore_errors=True)
 assert record['sourceAndBuildFrozen'] and len(summary['completedUnits'])==start+len(subset),record
assert summary['counts']==plan['counts'],summary
