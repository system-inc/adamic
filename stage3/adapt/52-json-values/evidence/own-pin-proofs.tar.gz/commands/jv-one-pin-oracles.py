from pathlib import Path
import json,subprocess,os,hashlib
s=Path('/workspace/scratch');tree=s/'jv-one-pin';fresh=s/'jv-one-pin-full';diff=[]
for p in (fresh/'src').rglob('*'):
 if p.is_file() and (not (tree/p.relative_to(fresh)).exists() or p.read_bytes()!=(tree/p.relative_to(fresh)).read_bytes()):diff.append(str(p.relative_to(fresh)))
(s/'jv-one-pin-evidence/full-apply-source-match.json').write_text(json.dumps({'differences':diff},indent=2)+'\n');assert not diff,diff
for label,name in [('final','jv-one-pin'),('mutant','jv-one-pin-mutant')]:
 tree=s/name
 hashes={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'built').rglob('*')) if p.is_file() and (p.suffix in ['.js','.mjs','.cjs'] or p.name=='typescript.d.ts')}
 key=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
 ready={'key':key,'phases':{'install':{'command':['cp','-a','jv-control/node_modules',name+'/node_modules'],'exit':0},'build':{'command':['npm','run','build'],'exit':0,'typecheck_passed':True}},'hashes':hashes}
 (s/'artifact-ready.json').write_text(json.dumps(ready,indent=2)+'\n');(s/('jv-one-pin-artifact-'+label+'.json')).write_text(json.dumps(ready,indent=2)+'\n')
 cmd=['bash','stage3/oracle/run.sh',str(tree),str(s/('jv-oracle-one-pin-'+label)),'--prepared','--workers','4' if label=='final' else '1','--limit-seconds','1800' if label=='final' else '180']
 if label=='mutant':cmd+=['--runners','compiler','--tests','APISample_parseConfig']
 env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=1400',PYTHONDONTWRITEBYTECODE='1')
 with (s/('jv-oracle-one-pin-'+label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd='/workspace/adamic',env=env,stdout=log,stderr=subprocess.STDOUT)
 report=json.loads((s/('jv-oracle-one-pin-'+label)/'report.json').read_text());(s/('jv-one-pin-oracle-'+label+'.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'report':report},indent=2)+'\n')
