from pathlib import Path
import json,subprocess,os,hashlib
s=Path('/workspace/scratch');tree=s/'jv-repaired';fresh=s/'jv-full-repaired';diff=[]
for p in (fresh/'src').rglob('*'):
 if p.is_file() and (not (tree/p.relative_to(fresh)).exists() or p.read_bytes()!=(tree/p.relative_to(fresh)).read_bytes()):diff.append(str(p.relative_to(fresh)))
(s/'jv-repaired-evidence/full-apply-source-match.json').write_text(json.dumps({'differences':diff},indent=2)+'\n');assert not diff,diff
hashes={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'built').rglob('*')) if p.is_file() and (p.suffix in ['.js','.mjs','.cjs'] or p.name=='typescript.d.ts')}
key=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
ready={'key':key,'phases':{'install':{'command':['cp','-a','jv-control/node_modules','jv-repaired/node_modules'],'exit':0},'build':{'command':['npm','run','build'],'exit':0,'typecheck_passed':True}},'hashes':hashes}
(s/'artifact-ready.json').write_text(json.dumps(ready,indent=2)+'\n');(s/'jv-repaired-artifact.json').write_text(json.dumps(ready,indent=2)+'\n')
cmd=['bash','stage3/oracle/run.sh',str(tree),str(s/'jv-oracle-repaired'),'--prepared','--workers','4','--limit-seconds','1800']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=1400',PYTHONDONTWRITEBYTECODE='1')
with (s/'jv-oracle-repaired.log').open('w') as log:r=subprocess.run(cmd,cwd='/workspace/adamic',env=env,stdout=log,stderr=subprocess.STDOUT)
report=json.loads((s/'jv-oracle-repaired/report.json').read_text());(s/'jv-repaired-oracle-result.json').write_text(json.dumps({'command':cmd,'exit':r.returncode,'report':report},indent=2)+'\n')
