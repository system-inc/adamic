### compiler tests compiler tests for tests/cases/compiler/APISample_parseConfig.ts Correct errors for tests/cases/compiler/APISample_parseConfig.ts (baseline-content)

```text
New baseline created at tests/baselines/local/APISample_parseConfig.errors.txt
```

Elapsed: 1005.459 ms; timeout: 40000 ms.

Stack top:     at writeComparison (src/harness/harnessIO.ts:1490:27)

APISample_parseConfig.errors.txt (first 40 lines)

```diff
--- reference/APISample_parseConfig.errors.txt
+++ local/APISample_parseConfig.errors.txt
@@ -0,0 +1,56 @@
+APISample_parseConfig.ts(27,56): error TS18048: 'config' is possibly 'undefined'.
+APISample_parseConfig.ts(27,56): error TS18049: 'config.config' is possibly 'null' or 'undefined'.
+APISample_parseConfig.ts(27,56): error TS7053: Element implicitly has an 'any' type because expression of type '"compilerOptions"' can't be used to index type 'string | number | boolean | AdamicJsonRecoveryObject | AdamicJsonRecoveryValue[]'.
+  Property 'compilerOptions' does not exist on type 'string | number | boolean | AdamicJsonRecoveryObject | AdamicJsonRecoveryValue[]'.
+
+
+==== APISample_parseConfig.ts (3 errors) ====
+    /*
+     * Note: This test is a public API sample. The sample sources can be found
+     *       at: https://github.com/Microsoft/TypeScript/wiki/Using-the-Compiler-API#a-minimal-compiler
+     *       Please log a "breaking change" issue for any API breaking change affecting this issue
+     */
+    
+    declare var process: any;
+    declare var console: any;
+    declare var os: any;
+    
+    import ts = require("typescript");
+    
+    function printError(error: ts.Diagnostic): void {
+        if (!error) {
+            return;
+        }
+        console.log(`${error.file && error.file.fileName}: ${error.messageText}`);
+    }
+    
+    export function createProgram(rootFiles: string[], compilerOptionsJson: string): ts.Program | undefined {
+        const { config, error } = ts.parseConfigFileTextToJson("tsconfig.json", compilerOptionsJson)
+        if (error) {
+            printError(error);
+            return undefined;
+        }
+        const basePath: string = process.cwd();
+        const settings = ts.convertCompilerOptionsFromJson(config.config["compilerOptions"], basePath);
+                                                           ~~~~~~
+!!! error TS18048: 'config' is possibly 'undefined'.
+                                                           ~~~~~~~~~~~~~

```
