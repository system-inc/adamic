'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),assert=require('assert/strict');
const {spawnSync}=require('child_process');
const ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const tree='/workspace/scratch/jv-wave6-after',out='/workspace/scratch/jv-wave6-evidence';fs.mkdirSync(out,{recursive:true});
const files=['src/compiler/core.ts','src/server/session.ts','src/services/types.ts','src/services/services.ts','src/harness/client.ts'];
const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'json52-import-mutant-'));
for(const f of files){fs.mkdirSync(path.dirname(path.join(scratch,f)),{recursive:true});fs.copyFileSync(path.join(tree,f),path.join(scratch,f));}
const f=path.join(scratch,'src/harness/client.ts');fs.writeFileSync(f,'import * as ts from "./_namespaces/ts.js";\r\n'+fs.readFileSync(f,'utf8'));
const digest=()=>Object.fromEntries(files.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(scratch,f))).digest('hex')]));const before=digest();
const result=spawnSync(process.execPath,['/workspace/scratch/jv-wave6/stage3/adapt/99-correctness-axolotl-f/adapt.cjs',scratch],{encoding:'utf8',env:{...process.env,NODE_PATH:'/workspace/adamic/stage3/api/node_modules'}});
fs.writeFileSync(path.join(out,'mutant-duplicate-import.log'),result.stdout+result.stderr);assert.notEqual(result.status,0);assert.match(result.stderr,/2 !== 1/);assert.deepEqual(digest(),before,'99f refusal wrote files');
const sf=ts.createSourceFile('client.ts',fs.readFileSync(path.join(tree,'src/harness/client.ts'),'utf8'),ts.ScriptTarget.Latest,true);const imports=sf.statements.filter(n=>ts.isImportDeclaration(n)&&n.moduleSpecifier.text==='./_namespaces/ts.js');assert.equal(imports.length,1);assert(ts.isNamedImports(imports[0].importClause.namedBindings));
const names=imports[0].importClause.namedBindings.elements.map(n=>n.name.text);assert(names.includes('HashedSet'));assert.equal(names[names.indexOf('DocumentSpan')+1],'HashedSet');
fs.writeFileSync(path.join(out,'import-composition.json'),JSON.stringify({imports:imports.length,named:true,HashedSetImported:true,DocumentSpanFollowedByHashedSet:true,mutantExit:result.status,mutantRefusal:'2 !== 1',mutantFilesWritten:0},null,2)+'\n');fs.rmSync(scratch,{recursive:true});
