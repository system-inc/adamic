from pathlib import Path
import json,subprocess,os,hashlib
s=Path('/workspace/scratch')
for label,name in [('control','jv-wave6-before'),('after','jv-wave6-after')]:
 tree=s/name
 hashes={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'built').rglob('*')) if p.is_file() and (p.suffix in ['.js','.mjs','.cjs'] or p.name=='typescript.d.ts')}
 key=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
 ready={'key':key,'phases':{'install':{'command':['cp','-a','/workspace/scratch/jv-one-pin/node_modules',str(tree/'node_modules')],'exit':0},'build':{'command':['npm','run','build'],'exit':0,'typecheck_passed':True}},'hashes':hashes}
 (s/'artifact-ready.json').write_text(json.dumps(ready,indent=2)+'\n');(s/('jv-wave6-artifact-'+label+'.json')).write_text(json.dumps(ready,indent=2)+'\n')
 cmd=['bash','stage3/oracle/run.sh',str(tree),str(s/('jv-oracle-wave6-'+label)),'--prepared','--workers','4','--limit-seconds','1800']
 env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=1400',PYTHONDONTWRITEBYTECODE='1')
 with (s/('jv-oracle-wave6-'+label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=str(s/'jv-wave6'),env=env,stdout=log,stderr=subprocess.STDOUT)
 report=json.loads((s/('jv-oracle-wave6-'+label)/'report.json').read_text());(s/('jv-wave6-oracle-'+label+'.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'report':report},indent=2)+'\n')
