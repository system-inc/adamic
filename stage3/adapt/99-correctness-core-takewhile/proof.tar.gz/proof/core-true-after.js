import { CharacterCodes, Comparison, Debug, } from "./_namespaces/ts.js";
export const emptyArray = [];
export const emptyMap = new Map();
export function length(array) {
    return array !== undefined ? array.length : 0;
}
export function forEach(array, callback) {
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const result = callback(array[i], i);
            if (result) {
                return result;
            }
        }
    }
    return undefined;
}
export function forEachRight(array, callback) {
    if (array !== undefined) {
        for (let i = array.length - 1; i >= 0; i--) {
            const result = callback(array[i], i);
            if (result) {
                return result;
            }
        }
    }
    return undefined;
}
export function firstDefined(array, callback) {
    if (array === undefined) {
        return undefined;
    }
    for (let i = 0; i < array.length; i++) {
        const result = callback(array[i], i);
        if (result !== undefined) {
            return result;
        }
    }
    return undefined;
}
export function firstDefinedIterator(iter, callback) {
    for (const value of iter) {
        const result = callback(value);
        if (result !== undefined) {
            return result;
        }
    }
    return undefined;
}
export function reduceLeftIterator(iterator, f, initial) {
    let result = initial;
    if (iterator) {
        let pos = 0;
        for (const value of iterator) {
            result = f(result, value, pos);
            pos++;
        }
    }
    return result;
}
export function zipWith(arrayA, arrayB, callback) {
    const result = [];
    Debug.assertEqual(arrayA.length, arrayB.length);
    for (let i = 0; i < arrayA.length; i++) {
        result.push(callback(arrayA[i], arrayB[i], i));
    }
    return result;
}
export function intersperse(input, element) {
    if (input.length <= 1) {
        return input;
    }
    const result = [];
    for (let i = 0, n = input.length; i < n; i++) {
        if (i !== 0)
            result.push(element);
        result.push(input[i]);
    }
    return result;
}
export function every(array, callback) {
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            if (!callback(array[i], i)) {
                return false;
            }
        }
    }
    return true;
}
export function find(array, predicate, startIndex) {
    if (array === undefined)
        return undefined;
    for (let i = startIndex ?? 0; i < array.length; i++) {
        const value = array[i];
        if (predicate(value, i)) {
            return value;
        }
    }
    return undefined;
}
export function findLast(array, predicate, startIndex) {
    if (array === undefined)
        return undefined;
    for (let i = startIndex ?? array.length - 1; i >= 0; i--) {
        const value = array[i];
        if (predicate(value, i)) {
            return value;
        }
    }
    return undefined;
}
export function findIndex(array, predicate, startIndex) {
    if (array === undefined)
        return -1;
    for (let i = startIndex ?? 0; i < array.length; i++) {
        if (predicate(array[i], i)) {
            return i;
        }
    }
    return -1;
}
export function findLastIndex(array, predicate, startIndex) {
    if (array === undefined)
        return -1;
    for (let i = startIndex ?? array.length - 1; i >= 0; i--) {
        if (predicate(array[i], i)) {
            return i;
        }
    }
    return -1;
}
export function contains(array, value, equalityComparer = equateValues) {
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            if (equalityComparer(array[i], value)) {
                return true;
            }
        }
    }
    return false;
}
export function indexOfAnyCharCode(text, charCodes, start) {
    for (let i = start ?? 0; i < text.length; i++) {
        if (contains(charCodes, text.charCodeAt(i))) {
            return i;
        }
    }
    return -1;
}
export function countWhere(array, predicate) {
    let count = 0;
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const v = array[i];
            if (predicate(v, i)) {
                count++;
            }
        }
    }
    return count;
}
export function filter(array, f) {
    if (array !== undefined) {
        const len = array.length;
        let i = 0;
        while (i < len && f(array[i]))
            i++;
        if (i < len) {
            const result = array.slice(0, i);
            i++;
            while (i < len) {
                const item = array[i];
                if (f(item)) {
                    result.push(item);
                }
                i++;
            }
            return result;
        }
    }
    return array;
}
export function filterMutate(array, f) {
    let outIndex = 0;
    for (let i = 0; i < array.length; i++) {
        if (f(array[i], i, array)) {
            array[outIndex] = array[i];
            outIndex++;
        }
    }
    array.splice(outIndex);
}
export function clear(array) {
    array.splice(0);
}
export function map(array, f) {
    let result;
    if (array !== undefined) {
        result = [];
        for (let i = 0; i < array.length; i++) {
            result.push(f(array[i], i));
        }
    }
    return result;
}
export function* mapIterator(iter, mapFn) {
    for (const x of iter) {
        yield mapFn(x);
    }
}
export function sameMap(array, f) {
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const item = array[i];
            const mapped = f(item, i);
            if (item !== mapped) {
                const result = array.slice(0, i);
                result.push(mapped);
                for (i++; i < array.length; i++) {
                    result.push(f(array[i], i));
                }
                return result;
            }
        }
    }
    return array;
}
export function flatten(array) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        const v = array[i];
        if (v) {
            if (isArray(v)) {
                addRange(result, v);
            }
            else {
                result.push(v);
            }
        }
    }
    return result;
}
export function flatMap(array, mapfn) {
    let result;
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const v = mapfn(array[i], i);
            if (v) {
                if (isArray(v)) {
                    result = addRange(result, v);
                }
                else {
                    result = append(result, v);
                }
            }
        }
    }
    return result ?? emptyArray;
}
export function flatMapToMutable(array, mapfn) {
    const result = [];
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const v = mapfn(array[i], i);
            if (v) {
                if (isArray(v)) {
                    addRange(result, v);
                }
                else {
                    result.push(v);
                }
            }
        }
    }
    return result;
}
export function* flatMapIterator(iter, mapfn) {
    for (const x of iter) {
        const iter2 = mapfn(x);
        if (!iter2)
            continue;
        yield* iter2;
    }
}
export function sameFlatMap(array, mapfn) {
    let result;
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const item = array[i];
            const mapped = mapfn(item, i);
            if (result || item !== mapped || isArray(mapped)) {
                if (!result) {
                    result = array.slice(0, i);
                }
                if (isArray(mapped)) {
                    addRange(result, mapped);
                }
                else {
                    result.push(mapped);
                }
            }
        }
    }
    return result ?? array;
}
export function mapAllOrFail(array, mapFn) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        const mapped = mapFn(array[i], i);
        if (mapped === undefined) {
            return undefined;
        }
        result.push(mapped);
    }
    return result;
}
export function mapDefined(array, mapFn) {
    const result = [];
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const mapped = mapFn(array[i], i);
            if (mapped !== undefined) {
                result.push(mapped);
            }
        }
    }
    return result;
}
export function* mapDefinedIterator(iter, mapFn) {
    for (const x of iter) {
        const value = mapFn(x);
        if (value !== undefined) {
            yield value;
        }
    }
}
export function getOrUpdate(map, key, callback) {
    if (map.has(key)) {
        return map.get(key);
    }
    const value = callback();
    map.set(key, value);
    return value;
}
export function tryAddToSet(set, value) {
    if (!set.has(value)) {
        set.add(value);
        return true;
    }
    return false;
}
export function* singleIterator(value) {
    yield value;
}
export function spanMap(array, keyfn, mapfn) {
    let result;
    if (array !== undefined) {
        result = [];
        const len = array.length;
        let previousKey;
        let key;
        let start = 0;
        let pos = 0;
        while (start < len) {
            while (pos < len) {
                const value = array[pos];
                key = keyfn(value, pos);
                if (pos === 0) {
                    previousKey = key;
                }
                else if (key !== previousKey) {
                    break;
                }
                pos++;
            }
            if (start < pos) {
                const v = mapfn(array.slice(start, pos), previousKey, start, pos);
                if (v) {
                    result.push(v);
                }
                start = pos;
            }
            previousKey = key;
            pos++;
        }
    }
    return result;
}
export function mapEntries(map, f) {
    if (map === undefined) {
        return undefined;
    }
    const result = new Map();
    map.forEach((value, key) => {
        const [newKey, newValue] = f(key, value);
        result.set(newKey, newValue);
    });
    return result;
}
export function some(array, predicate) {
    if (array !== undefined) {
        if (predicate !== undefined) {
            for (let i = 0; i < array.length; i++) {
                if (predicate(array[i])) {
                    return true;
                }
            }
        }
        else {
            return array.length > 0;
        }
    }
    return false;
}
export function getRangesWhere(arr, pred, cb) {
    let start;
    for (let i = 0; i < arr.length; i++) {
        if (pred(arr[i])) {
            start = start === undefined ? i : start;
        }
        else {
            if (start !== undefined) {
                cb(start, i);
                start = undefined;
            }
        }
    }
    if (start !== undefined)
        cb(start, arr.length);
}
export function concatenate(array1, array2) {
    if (array2 === undefined || array2.length === 0)
        return array1;
    if (array1 === undefined || array1.length === 0)
        return array2;
    return [...array1, ...array2];
}
function selectIndex(_, i) {
    return i;
}
export function indicesOf(array) {
    return array.map(selectIndex);
}
function deduplicateRelational(array, equalityComparer, comparer) {
    const indices = indicesOf(array);
    stableSortIndices(array, indices, comparer);
    let last = array[indices[0]];
    const deduplicated = [indices[0]];
    for (let i = 1; i < indices.length; i++) {
        const index = indices[i];
        const item = array[index];
        if (!equalityComparer(last, item)) {
            deduplicated.push(index);
            last = item;
        }
    }
    deduplicated.sort();
    return deduplicated.map(i => array[i]);
}
function deduplicateEquality(array, equalityComparer) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        pushIfUnique(result, array[i], equalityComparer);
    }
    return result;
}
export function deduplicate(array, equalityComparer, comparer) {
    return array.length === 0 ? [] :
        array.length === 1 ? array.slice() :
            comparer ? deduplicateRelational(array, equalityComparer, comparer) :
                deduplicateEquality(array, equalityComparer);
}
function deduplicateSorted(array, comparer) {
    if (array.length === 0)
        return emptyArray;
    let last = array[0];
    const deduplicated = [last];
    for (let i = 1; i < array.length; i++) {
        const next = array[i];
        switch (comparer(next, last)) {
            case true:
            case Comparison.EqualTo:
                continue;
            case Comparison.LessThan:
                return Debug.fail("Array is unsorted.");
        }
        deduplicated.push(last = next);
    }
    return deduplicated;
}
export function createSortedArray() {
    return [];
}
export function insertSorted(array, insert, compare, equalityComparer, allowDuplicates) {
    if (array.length === 0) {
        array.push(insert);
        return true;
    }
    const insertIndex = binarySearch(array, insert, identity, compare);
    if (insertIndex < 0) {
        if (equalityComparer && !allowDuplicates) {
            const idx = ~insertIndex;
            if (idx > 0 && equalityComparer(insert, array[idx - 1])) {
                return false;
            }
            if (idx < array.length && equalityComparer(insert, array[idx])) {
                array.splice(idx, 1, insert);
                return true;
            }
        }
        array.splice(~insertIndex, 0, insert);
        return true;
    }
    if (allowDuplicates) {
        array.splice(insertIndex, 0, insert);
        return true;
    }
    return false;
}
export function sortAndDeduplicate(array, comparer, equalityComparer) {
    return deduplicateSorted(toSorted(array, comparer), equalityComparer ?? comparer ?? compareStringsCaseSensitive);
}
export function arrayIsEqualTo(array1, array2, equalityComparer = equateValues) {
    if (array1 === undefined || array2 === undefined) {
        return array1 === array2;
    }
    if (array1.length !== array2.length) {
        return false;
    }
    for (let i = 0; i < array1.length; i++) {
        if (!equalityComparer(array1[i], array2[i], i)) {
            return false;
        }
    }
    return true;
}
export function compact(array) {
    let result;
    if (array !== undefined) {
        for (let i = 0; i < array.length; i++) {
            const v = array[i];
            if (result ?? !v) {
                result ??= array.slice(0, i);
                if (v) {
                    result.push(v);
                }
            }
        }
    }
    return result ?? array;
}
export function relativeComplement(arrayA, arrayB, comparer) {
    if (!arrayB || !arrayA || arrayB.length === 0 || arrayA.length === 0)
        return arrayB;
    const result = [];
    loopB: for (let offsetA = 0, offsetB = 0; offsetB < arrayB.length; offsetB++) {
        if (offsetB > 0) {
            Debug.assertGreaterThanOrEqual(comparer(arrayB[offsetB], arrayB[offsetB - 1]), Comparison.EqualTo);
        }
        loopA: for (const startA = offsetA; offsetA < arrayA.length; offsetA++) {
            if (offsetA > startA) {
                Debug.assertGreaterThanOrEqual(comparer(arrayA[offsetA], arrayA[offsetA - 1]), Comparison.EqualTo);
            }
            switch (comparer(arrayB[offsetB], arrayA[offsetA])) {
                case Comparison.LessThan:
                    result.push(arrayB[offsetB]);
                    continue loopB;
                case Comparison.EqualTo:
                    continue loopB;
                case Comparison.GreaterThan:
                    continue loopA;
            }
        }
    }
    return result;
}
export function append(to, value) {
    if (value === undefined)
        return to;
    if (to === undefined)
        return [value];
    to.push(value);
    return to;
}
export function combine(xs, ys) {
    if (xs === undefined)
        return ys;
    if (ys === undefined)
        return xs;
    if (isArray(xs))
        return isArray(ys) ? concatenate(xs, ys) : append(xs, ys);
    if (isArray(ys))
        return append(ys, xs);
    return [xs, ys];
}
function toOffset(array, offset) {
    return offset < 0 ? array.length + offset : offset;
}
export function addRange(to, from, start, end) {
    if (from === undefined || from.length === 0)
        return to;
    if (to === undefined)
        return from.slice(start, end);
    start = start === undefined ? 0 : toOffset(from, start);
    end = end === undefined ? from.length : toOffset(from, end);
    for (let i = start; i < end && i < from.length; i++) {
        if (from[i] !== undefined) {
            to.push(from[i]);
        }
    }
    return to;
}
export function pushIfUnique(array, toAdd, equalityComparer) {
    if (contains(array, toAdd, equalityComparer)) {
        return false;
    }
    else {
        array.push(toAdd);
        return true;
    }
}
export function appendIfUnique(array, toAdd, equalityComparer) {
    if (array !== undefined) {
        pushIfUnique(array, toAdd, equalityComparer);
        return array;
    }
    else {
        return [toAdd];
    }
}
function stableSortIndices(array, indices, comparer) {
    indices.sort((x, y) => comparer(array[x], array[y]) || compareValues(x, y));
}
export function toSorted(array, comparer) {
    return (array.length === 0 ? emptyArray : array.slice().sort(comparer));
}
export function* arrayReverseIterator(array) {
    for (let i = array.length - 1; i >= 0; i--) {
        yield array[i];
    }
}
export function rangeEquals(array1, array2, pos, end) {
    while (pos < end) {
        if (array1[pos] !== array2[pos]) {
            return false;
        }
        pos++;
    }
    return true;
}
export const elementAt = (array, offset) => {
    if (array !== undefined) {
        offset = toOffset(array, offset);
        if (offset < array.length) {
            return array[offset];
        }
    }
    return undefined;
};
export function firstOrUndefined(array) {
    return array === undefined || array.length === 0 ? undefined : array[0];
}
export function firstOrUndefinedIterator(iter) {
    if (iter !== undefined) {
        for (const value of iter) {
            return value;
        }
    }
    return undefined;
}
export function first(array) {
    Debug.assert(array.length !== 0);
    return array[0];
}
export function firstIterator(iter) {
    for (const value of iter) {
        return value;
    }
    Debug.fail("iterator is empty");
}
export function lastOrUndefined(array) {
    return array === undefined || array.length === 0 ? undefined : array[array.length - 1];
}
export function last(array) {
    Debug.assert(array.length !== 0);
    return array[array.length - 1];
}
export function singleOrUndefined(array) {
    return array !== undefined && array.length === 1
        ? array[0]
        : undefined;
}
export function single(array) {
    return Debug.checkDefined(singleOrUndefined(array));
}
export function singleOrMany(array) {
    return array !== undefined && array.length === 1
        ? array[0]
        : array;
}
export function replaceElement(array, index, value) {
    const result = array.slice(0);
    result[index] = value;
    return result;
}
export function binarySearch(array, value, keySelector, keyComparer, offset) {
    return binarySearchKey(array, keySelector(value), keySelector, keyComparer, offset);
}
export function binarySearchKey(array, key, keySelector, keyComparer, offset) {
    if (!some(array)) {
        return -1;
    }
    let low = offset ?? 0;
    let high = array.length - 1;
    while (low <= high) {
        const middle = low + ((high - low) >> 1);
        const midKey = keySelector(array[middle], middle);
        switch (Math.sign(keyComparer(midKey, key))) {
            case Comparison.LessThan:
                low = middle + 1;
                break;
            case Comparison.EqualTo:
                return middle;
            case Comparison.GreaterThan:
                high = middle - 1;
                break;
        }
    }
    return ~low;
}
export function reduceLeft(array, f, initial, start, count) {
    if (array && array.length > 0) {
        const size = array.length;
        if (size > 0) {
            let pos = start === undefined || start < 0 ? 0 : start;
            const end = count === undefined || pos + count > size - 1 ? size - 1 : pos + count;
            let result;
            if (arguments.length <= 2) {
                result = array[pos];
                pos++;
            }
            else {
                result = initial;
            }
            while (pos <= end) {
                result = f(result, array[pos], pos);
                pos++;
            }
            return result;
        }
    }
    return initial;
}
const hasOwnProperty = Object.prototype.hasOwnProperty;
export function hasProperty(map, key) {
    return hasOwnProperty.call(map, key);
}
export function getProperty(map, key) {
    return hasOwnProperty.call(map, key) ? map[key] : undefined;
}
export function getOwnKeys(map) {
    const keys = [];
    for (const key in map) {
        if (hasOwnProperty.call(map, key)) {
            keys.push(key);
        }
    }
    return keys;
}
export function getAllKeys(obj) {
    const result = [];
    do {
        const names = Object.getOwnPropertyNames(obj);
        for (const name of names) {
            pushIfUnique(result, name);
        }
    } while (obj = Object.getPrototypeOf(obj));
    return result;
}
export function getOwnValues(collection) {
    const values = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]);
        }
    }
    return values;
}
export function arrayOf(count, f) {
    const result = new Array(count);
    for (let i = 0; i < count; i++) {
        result[i] = f(i);
    }
    return result;
}
export function arrayFrom(iterator, map) {
    const result = [];
    for (const value of iterator) {
        result.push(map ? map(value) : value);
    }
    return result;
}
export function assign(t, ...args) {
    for (const arg of args) {
        if (arg === undefined)
            continue;
        for (const p in arg) {
            if (hasProperty(arg, p)) {
                t[p] = arg[p];
            }
        }
    }
    return t;
}
export function equalOwnProperties(left, right, equalityComparer = equateValues) {
    if (left === right)
        return true;
    if (!left || !right)
        return false;
    for (const key in left) {
        if (hasOwnProperty.call(left, key)) {
            if (!hasOwnProperty.call(right, key))
                return false;
            if (!equalityComparer(left[key], right[key]))
                return false;
        }
    }
    for (const key in right) {
        if (hasOwnProperty.call(right, key)) {
            if (!hasOwnProperty.call(left, key))
                return false;
        }
    }
    return true;
}
export function arrayToMap(array, makeKey, makeValue = identity) {
    const result = new Map();
    for (let i = 0; i < array.length; i++) {
        const value = array[i];
        const key = makeKey(value);
        if (key !== undefined)
            result.set(key, makeValue(value));
    }
    return result;
}
export function arrayToNumericMap(array, makeKey, makeValue = identity) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        const value = array[i];
        result[makeKey(value)] = makeValue(value);
    }
    return result;
}
export function arrayToMultiMap(values, makeKey, makeValue = identity) {
    const result = createMultiMap();
    for (let i = 0; i < values.length; i++) {
        const value = values[i];
        result.add(makeKey(value), makeValue(value));
    }
    return result;
}
export function group(values, getGroupId, resultSelector = identity) {
    return arrayFrom(arrayToMultiMap(values, getGroupId).values(), resultSelector);
}
export function groupBy(values, keySelector) {
    const result = {};
    if (values !== undefined) {
        for (let i = 0; i < values.length; i++) {
            const value = values[i];
            const key = `${keySelector(value)}`;
            const array = result[key] ??= [];
            array.push(value);
        }
    }
    return result;
}
export function clone(object) {
    const result = {};
    for (const id in object) {
        if (hasOwnProperty.call(object, id)) {
            result[id] = object[id];
        }
    }
    return result;
}
export function extend(first, second) {
    const result = {};
    for (const id in second) {
        if (hasOwnProperty.call(second, id)) {
            result[id] = second[id];
        }
    }
    for (const id in first) {
        if (hasOwnProperty.call(first, id)) {
            result[id] = first[id];
        }
    }
    return result;
}
export function copyProperties(first, second) {
    for (const id in second) {
        if (hasOwnProperty.call(second, id)) {
            first[id] = second[id];
        }
    }
}
export function maybeBind(obj, fn) {
    return fn?.bind(obj);
}
export function createMultiMap() {
    const map = new Map();
    map.add = multiMapAdd;
    map.remove = multiMapRemove;
    return map;
}
function multiMapAdd(key, value) {
    let values = this.get(key);
    if (values !== undefined) {
        values.push(value);
    }
    else {
        this.set(key, values = [value]);
    }
    return values;
}
function multiMapRemove(key, value) {
    const values = this.get(key);
    if (values !== undefined) {
        unorderedRemoveItem(values, value);
        if (!values.length) {
            this.delete(key);
        }
    }
}
export function createQueue(items) {
    const elements = items?.slice() ?? [];
    let headIndex = 0;
    function isEmpty() {
        return headIndex === elements.length;
    }
    function enqueue(...items) {
        elements.push(...items);
    }
    function dequeue() {
        if (isEmpty()) {
            throw new Error("Queue is empty");
        }
        const result = elements[headIndex];
        elements[headIndex] = undefined;
        headIndex++;
        if (headIndex > 100 && headIndex > (elements.length >> 1)) {
            const newLength = elements.length - headIndex;
            elements.copyWithin(0, headIndex);
            elements.splice(newLength);
            headIndex = 0;
        }
        return result;
    }
    return {
        enqueue,
        dequeue,
        isEmpty,
    };
}
export function createSet(getHashCode, equals) {
    const multiMap = new Map();
    let size = 0;
    function* getElementIterator() {
        for (const value of multiMap.values()) {
            if (isArray(value)) {
                yield* value;
            }
            else {
                yield value;
            }
        }
    }
    const set = {
        has(element) {
            const hash = getHashCode(element);
            if (!multiMap.has(hash))
                return false;
            const candidates = multiMap.get(hash);
            if (isArray(candidates))
                return contains(candidates, element, equals);
            return equals(candidates, element);
        },
        add(element) {
            const hash = getHashCode(element);
            if (multiMap.has(hash)) {
                const values = multiMap.get(hash);
                if (isArray(values)) {
                    if (!contains(values, element, equals)) {
                        values.push(element);
                        size++;
                    }
                }
                else {
                    const value = values;
                    if (!equals(value, element)) {
                        multiMap.set(hash, [value, element]);
                        size++;
                    }
                }
            }
            else {
                multiMap.set(hash, element);
                size++;
            }
            return this;
        },
        delete(element) {
            const hash = getHashCode(element);
            if (!multiMap.has(hash))
                return false;
            const candidates = multiMap.get(hash);
            if (isArray(candidates)) {
                for (let i = 0; i < candidates.length; i++) {
                    if (equals(candidates[i], element)) {
                        if (candidates.length === 1) {
                            multiMap.delete(hash);
                        }
                        else if (candidates.length === 2) {
                            multiMap.set(hash, candidates[1 - i]);
                        }
                        else {
                            unorderedRemoveItemAt(candidates, i);
                        }
                        size--;
                        return true;
                    }
                }
            }
            else {
                const candidate = candidates;
                if (equals(candidate, element)) {
                    multiMap.delete(hash);
                    size--;
                    return true;
                }
            }
            return false;
        },
        clear() {
            multiMap.clear();
            size = 0;
        },
        get size() {
            return size;
        },
        forEach(action) {
            for (const elements of arrayFrom(multiMap.values())) {
                if (isArray(elements)) {
                    for (const element of elements) {
                        action(element, element, set);
                    }
                }
                else {
                    const element = elements;
                    action(element, element, set);
                }
            }
        },
        keys() {
            return getElementIterator();
        },
        values() {
            return getElementIterator();
        },
        *entries() {
            for (const value of getElementIterator()) {
                yield [value, value];
            }
        },
        [Symbol.iterator]: () => {
            return getElementIterator();
        },
        [Symbol.toStringTag]: multiMap[Symbol.toStringTag],
    };
    return set;
}
export function isArray(value) {
    return Array.isArray(value);
}
export function toArray(value) {
    return isArray(value) ? value : [value];
}
export function isString(text) {
    return typeof text === "string";
}
export function isNumber(x) {
    return typeof x === "number";
}
export function tryCast(value, test) {
    return value !== undefined && test(value) ? value : undefined;
}
export function cast(value, test) {
    if (value !== undefined && test(value))
        return value;
    return Debug.fail(`Invalid cast. The supplied value ${value} did not pass the test '${Debug.getFunctionName(test)}'.`);
}
export function noop(_) { }
export function returnFalse() {
    return false;
}
export function returnTrue() {
    return true;
}
export function returnUndefined() {
    return undefined;
}
export function identity(x) {
    return x;
}
function toLowerCase(x) {
    return x.toLowerCase();
}
const fileNameLowerCaseRegExp = /[^\u0130\u0131\u00DFa-z0-9\\/:\-_. ]+/g;
export function toFileNameLowerCase(x) {
    return fileNameLowerCaseRegExp.test(x) ?
        x.replace(fileNameLowerCaseRegExp, toLowerCase) :
        x;
}
export function notImplemented() {
    throw new Error("Not implemented");
}
export function memoize(callback) {
    let value;
    return () => {
        if (callback) {
            value = callback();
            callback = undefined;
        }
        return value;
    };
}
export function memoizeOne(callback) {
    const map = new Map();
    return (arg) => {
        const key = `${typeof arg}:${arg}`;
        let value = map.get(key);
        if (value === undefined && !map.has(key)) {
            value = callback(arg);
            map.set(key, value);
        }
        return value;
    };
}
export var AssertionLevel;
(function (AssertionLevel) {
    AssertionLevel[AssertionLevel["None"] = 0] = "None";
    AssertionLevel[AssertionLevel["Normal"] = 1] = "Normal";
    AssertionLevel[AssertionLevel["Aggressive"] = 2] = "Aggressive";
    AssertionLevel[AssertionLevel["VeryAggressive"] = 3] = "VeryAggressive";
})(AssertionLevel || (AssertionLevel = {}));
export function equateValues(a, b) {
    return a === b;
}
export function equateStringsCaseInsensitive(a, b) {
    return a === b
        || a !== undefined
            && b !== undefined
            && a.toUpperCase() === b.toUpperCase();
}
export function equateStringsCaseSensitive(a, b) {
    return equateValues(a, b);
}
export function compareComparableValues(a, b) {
    return a === b ? Comparison.EqualTo :
        a === undefined ? Comparison.LessThan :
            b === undefined ? Comparison.GreaterThan :
                a < b ? Comparison.LessThan :
                    Comparison.GreaterThan;
}
export function compareValues(a, b) {
    return compareComparableValues(a, b);
}
export function compareTextSpans(a, b) {
    return compareValues(a?.start, b?.start) || compareValues(a?.length, b?.length);
}
export function maxBy(arr, init, mapper) {
    for (let i = 0; i < arr.length; i++) {
        init = Math.max(init, mapper(arr[i]));
    }
    return init;
}
export function min(items, compare) {
    return reduceLeft(items, (x, y) => compare(x, y) === Comparison.LessThan ? x : y);
}
export function compareStringsCaseInsensitive(a, b) {
    if (a === b)
        return Comparison.EqualTo;
    if (a === undefined)
        return Comparison.LessThan;
    if (b === undefined)
        return Comparison.GreaterThan;
    a = a.toUpperCase();
    b = b.toUpperCase();
    return a < b ? Comparison.LessThan : a > b ? Comparison.GreaterThan : Comparison.EqualTo;
}
export function compareStringsCaseInsensitiveEslintCompatible(a, b) {
    if (a === b)
        return Comparison.EqualTo;
    if (a === undefined)
        return Comparison.LessThan;
    if (b === undefined)
        return Comparison.GreaterThan;
    a = a.toLowerCase();
    b = b.toLowerCase();
    return a < b ? Comparison.LessThan : a > b ? Comparison.GreaterThan : Comparison.EqualTo;
}
export function compareStringsCaseSensitive(a, b) {
    return compareComparableValues(a, b);
}
export function getStringComparer(ignoreCase) {
    return ignoreCase ? compareStringsCaseInsensitive : compareStringsCaseSensitive;
}
const createUIStringComparer = (() => {
    return createIntlCollatorStringComparer;
    function compareWithCallback(a, b, comparer) {
        if (a === b)
            return Comparison.EqualTo;
        if (a === undefined)
            return Comparison.LessThan;
        if (b === undefined)
            return Comparison.GreaterThan;
        const value = comparer(a, b);
        return value < 0 ? Comparison.LessThan : value > 0 ? Comparison.GreaterThan : Comparison.EqualTo;
    }
    function createIntlCollatorStringComparer(locale) {
        const comparer = new Intl.Collator(locale, { usage: "sort", sensitivity: "variant", numeric: true }).compare;
        return (a, b) => compareWithCallback(a, b, comparer);
    }
})();
let uiComparerCaseSensitive;
let uiLocale;
export function getUILocale() {
    return uiLocale;
}
export function setUILocale(value) {
    if (uiLocale !== value) {
        uiLocale = value;
        uiComparerCaseSensitive = undefined;
    }
}
export function compareStringsCaseSensitiveUI(a, b) {
    uiComparerCaseSensitive ??= createUIStringComparer(uiLocale);
    return uiComparerCaseSensitive(a, b);
}
export function compareProperties(a, b, key, comparer) {
    return a === b ? Comparison.EqualTo :
        a === undefined ? Comparison.LessThan :
            b === undefined ? Comparison.GreaterThan :
                comparer(a[key], b[key]);
}
export function compareBooleans(a, b) {
    return compareValues(a ? 1 : 0, b ? 1 : 0);
}
export function getSpellingSuggestion(name, candidates, getName) {
    const maximumLengthDifference = Math.max(2, Math.floor(name.length * 0.34));
    let bestDistance = Math.floor(name.length * 0.4) + 1;
    let bestCandidate;
    for (const candidate of candidates) {
        const candidateName = getName(candidate);
        if (candidateName !== undefined && Math.abs(candidateName.length - name.length) <= maximumLengthDifference) {
            if (candidateName === name) {
                continue;
            }
            if (candidateName.length < 3 && candidateName.toLowerCase() !== name.toLowerCase()) {
                continue;
            }
            const distance = levenshteinWithMax(name, candidateName, bestDistance - 0.1);
            if (distance === undefined) {
                continue;
            }
            Debug.assert(distance < bestDistance);
            bestDistance = distance;
            bestCandidate = candidate;
        }
    }
    return bestCandidate;
}
function levenshteinWithMax(s1, s2, max) {
    let previous = new Array(s2.length + 1);
    let current = new Array(s2.length + 1);
    const big = max + 0.01;
    for (let i = 0; i <= s2.length; i++) {
        previous[i] = i;
    }
    for (let i = 1; i <= s1.length; i++) {
        const c1 = s1.charCodeAt(i - 1);
        const minJ = Math.ceil(i > max ? i - max : 1);
        const maxJ = Math.floor(s2.length > max + i ? max + i : s2.length);
        current[0] = i;
        let colMin = i;
        for (let j = 1; j < minJ; j++) {
            current[j] = big;
        }
        for (let j = minJ; j <= maxJ; j++) {
            const substitutionDistance = s1[i - 1].toLowerCase() === s2[j - 1].toLowerCase()
                ? (previous[j - 1] + 0.1)
                : (previous[j - 1] + 2);
            const dist = c1 === s2.charCodeAt(j - 1)
                ? previous[j - 1]
                : Math.min(previous[j] + 1, current[j - 1] + 1, substitutionDistance);
            current[j] = dist;
            colMin = Math.min(colMin, dist);
        }
        for (let j = maxJ + 1; j <= s2.length; j++) {
            current[j] = big;
        }
        if (colMin > max) {
            return undefined;
        }
        const temp = previous;
        previous = current;
        current = temp;
    }
    const res = previous[s2.length];
    return res > max ? undefined : res;
}
export function endsWith(str, suffix, ignoreCase) {
    const expectedPos = str.length - suffix.length;
    return expectedPos >= 0 && (ignoreCase
        ? equateStringsCaseInsensitive(str.slice(expectedPos), suffix)
        : str.indexOf(suffix, expectedPos) === expectedPos);
}
export function removeSuffix(str, suffix) {
    return endsWith(str, suffix) ? str.slice(0, str.length - suffix.length) : str;
}
export function tryRemoveSuffix(str, suffix) {
    return endsWith(str, suffix) ? str.slice(0, str.length - suffix.length) : undefined;
}
export function removeMinAndVersionNumbers(fileName) {
    let end = fileName.length;
    for (let pos = end - 1; pos > 0; pos--) {
        let ch = fileName.charCodeAt(pos);
        if (ch >= CharacterCodes._0 && ch <= CharacterCodes._9) {
            do {
                --pos;
                ch = fileName.charCodeAt(pos);
            } while (pos > 0 && ch >= CharacterCodes._0 && ch <= CharacterCodes._9);
        }
        else if (pos > 4 && (ch === CharacterCodes.n || ch === CharacterCodes.N)) {
            --pos;
            ch = fileName.charCodeAt(pos);
            if (ch !== CharacterCodes.i && ch !== CharacterCodes.I) {
                break;
            }
            --pos;
            ch = fileName.charCodeAt(pos);
            if (ch !== CharacterCodes.m && ch !== CharacterCodes.M) {
                break;
            }
            --pos;
            ch = fileName.charCodeAt(pos);
        }
        else {
            break;
        }
        if (ch !== CharacterCodes.minus && ch !== CharacterCodes.dot) {
            break;
        }
        end = pos;
    }
    return end === fileName.length ? fileName : fileName.slice(0, end);
}
export function orderedRemoveItem(array, item) {
    for (let i = 0; i < array.length; i++) {
        if (array[i] === item) {
            orderedRemoveItemAt(array, i);
            return true;
        }
    }
    return false;
}
export function orderedRemoveItemAt(array, index) {
    for (let i = index; i < array.length - 1; i++) {
        array[i] = array[i + 1];
    }
    array.pop();
}
function unorderedRemoveItemAt(array, index) {
    array[index] = array[array.length - 1];
    array.pop();
}
export function unorderedRemoveItem(array, item) {
    return unorderedRemoveFirstItemWhere(array, element => element === item);
}
function unorderedRemoveFirstItemWhere(array, predicate) {
    for (let i = 0; i < array.length; i++) {
        if (predicate(array[i])) {
            unorderedRemoveItemAt(array, i);
            return true;
        }
    }
    return false;
}
export function createGetCanonicalFileName(useCaseSensitiveFileNames) {
    return useCaseSensitiveFileNames ? identity : toFileNameLowerCase;
}
export function patternText({ prefix, suffix }) {
    return `${prefix}*${suffix}`;
}
export function matchedText(pattern, candidate) {
    Debug.assert(isPatternMatch(pattern, candidate));
    return candidate.substring(pattern.prefix.length, candidate.length - pattern.suffix.length);
}
export function findBestPatternMatch(values, getPattern, candidate) {
    let matchedValue;
    let longestMatchPrefixLength = -1;
    for (let i = 0; i < values.length; i++) {
        const v = values[i];
        const pattern = getPattern(v);
        if (pattern.prefix.length > longestMatchPrefixLength && isPatternMatch(pattern, candidate)) {
            longestMatchPrefixLength = pattern.prefix.length;
            matchedValue = v;
        }
    }
    return matchedValue;
}
export function startsWith(str, prefix, ignoreCase) {
    return ignoreCase
        ? equateStringsCaseInsensitive(str.slice(0, prefix.length), prefix)
        : str.lastIndexOf(prefix, 0) === 0;
}
export function removePrefix(str, prefix) {
    return startsWith(str, prefix) ? str.substr(prefix.length) : str;
}
export function tryRemovePrefix(str, prefix, getCanonicalFileName = identity) {
    return startsWith(getCanonicalFileName(str), getCanonicalFileName(prefix)) ? str.substring(prefix.length) : undefined;
}
export function isPatternMatch({ prefix, suffix }, candidate) {
    return candidate.length >= prefix.length + suffix.length &&
        startsWith(candidate, prefix) &&
        endsWith(candidate, suffix);
}
export function and(f, g) {
    return (arg) => f(arg) && g(arg);
}
export function or(...fs) {
    return (...args) => {
        let lastResult;
        for (const f of fs) {
            lastResult = f(...args);
            if (lastResult) {
                return lastResult;
            }
        }
        return lastResult;
    };
}
export function not(fn) {
    return (...args) => !fn(...args);
}
export function assertType(_) { }
export function singleElementArray(t) {
    return t === undefined ? undefined : [t];
}
export function enumerateInsertsAndDeletes(newItems, oldItems, comparer, inserted, deleted, unchanged) {
    unchanged ??= noop;
    let newIndex = 0;
    let oldIndex = 0;
    const newLen = newItems.length;
    const oldLen = oldItems.length;
    let hasChanges = false;
    while (newIndex < newLen && oldIndex < oldLen) {
        const newItem = newItems[newIndex];
        const oldItem = oldItems[oldIndex];
        const compareResult = comparer(newItem, oldItem);
        if (compareResult === Comparison.LessThan) {
            inserted(newItem);
            newIndex++;
            hasChanges = true;
        }
        else if (compareResult === Comparison.GreaterThan) {
            deleted(oldItem);
            oldIndex++;
            hasChanges = true;
        }
        else {
            unchanged(oldItem, newItem);
            newIndex++;
            oldIndex++;
        }
    }
    while (newIndex < newLen) {
        inserted(newItems[newIndex++]);
        hasChanges = true;
    }
    while (oldIndex < oldLen) {
        deleted(oldItems[oldIndex++]);
        hasChanges = true;
    }
    return hasChanges;
}
export function cartesianProduct(arrays) {
    const result = [];
    cartesianProductWorker(arrays, result, undefined, 0);
    return result;
}
function cartesianProductWorker(arrays, result, outer, index) {
    for (const element of arrays[index]) {
        let inner;
        if (outer) {
            inner = outer.slice();
            inner.push(element);
        }
        else {
            inner = [element];
        }
        if (index === arrays.length - 1) {
            result.push(inner);
        }
        else {
            cartesianProductWorker(arrays, result, inner, index + 1);
        }
    }
}
export function takeWhile(array, predicate) {
    if (array !== undefined) {
        const result = [];
        const len = array.length;
        let index = 0;
        while (index < len) {
            const element = array[index];
            if (!predicate(element))
                break;
            result.push(element);
            index++;
        }
        return result;
    }
}
export function skipWhile(array, predicate) {
    if (array !== undefined) {
        const len = array.length;
        let index = 0;
        while (index < len && predicate(array[index])) {
            index++;
        }
        return array.slice(index);
    }
}
export function isNodeLikeSystem() {
    return typeof process !== "undefined"
        && !!process.nextTick
        && !process.browser
        && typeof require !== "undefined";
}
