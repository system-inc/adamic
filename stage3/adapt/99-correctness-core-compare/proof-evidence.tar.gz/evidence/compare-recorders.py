from pathlib import Path
import tarfile,hashlib,json
from collections import defaultdict
s=Path('/workspace/scratch/core-compare')
def digest(archive):
 result=defaultdict(list);rows=0
 with tarfile.open(archive) as tar:
  for m in tar.getmembers():
   if not m.isfile() or '/calls/' not in m.name or not m.name.endswith('.jsonl'):continue
   unit=m.name.rsplit('/',1)[1].rsplit('.',2)[0];h=hashlib.sha256();count=0
   for line in tar.extractfile(m):
    for version in [2,3]:
     prefix=('{"recorderVersion":'+str(version)+',').encode()
     if line.startswith(prefix):line=b'{'+line[len(prefix):];break
    h.update(line);count+=1
   result[unit].append({'rows':count,'sha256':h.hexdigest()});rows+=count
 for value in result.values():value.sort(key=lambda x:(x['rows'],x['sha256']))
 return dict(result),rows
old,n=digest(s/'excluded-first-attempt.tar.gz');new,m=digest(s/'json-piece-01-passed.tar.gz');report={'callsBefore':n,'callsAfter':m,'everyOrderedOperandAndResultRecordIdentical':old==new,'old':old,'new':new};(s/'RECORDER-REAL-CALLS.json').write_text(json.dumps(report,indent=2)+'\n');assert old==new and n==m==16586589;print(json.dumps({k:v for k,v in report.items() if k not in ['old','new']}),flush=True)
