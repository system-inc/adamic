'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
function encode(v){return v===undefined?{type:'undefined'}:typeof v==='number'?(Number.isNaN(v)?{type:'number',value:'NaN'}:Object.is(v,-0)?{type:'number',value:'-0'}:!Number.isFinite(v)?{type:'number',value:String(v)}:{type:'number',value:v}):{type:typeof v,value:v};}
function record(a,b,original,adapted){const dir=process.env.COMPARE_CALL_DIR;if(!dir)return;fs.appendFileSync(path.join(dir,(process.env.COMPARE_SHARD||'whole')+'.'+process.pid+'.jsonl'),JSON.stringify({a:encode(a),b:encode(b),typeofA:typeof a,typeofB:typeof b,original,adapted,mixed:(typeof a==='string'&&typeof b==='number')||(typeof a==='number'&&typeof b==='string'),same:Object.is(original,adapted)})+'\n');}
globalThis.__compareCensus=record;
function inject(context){if(context&&typeof context==='object')Object.defineProperty(context,'__compareCensus',{value:record,configurable:true});return context;}
const create=vm.createContext;vm.createContext=function(context={},...rest){return Reflect.apply(create,this,[inject(context),...rest]);};
const run=vm.runInNewContext;vm.runInNewContext=function(code,context={},...rest){return Reflect.apply(run,this,[code,inject(context),...rest]);};
const script=vm.Script.prototype.runInNewContext;vm.Script.prototype.runInNewContext=function(context={},...rest){return Reflect.apply(script,this,[inject(context),...rest]);};
