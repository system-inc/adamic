import json,os,shutil,hashlib,tarfile,subprocess
from pathlib import Path
s=Path('/workspace/scratch/core-compare');repo=Path('/workspace/adamic');out=repo/'stage3/adapt/99-correctness-core-compare';e=s/'evidence';e.mkdir();assert json.loads((s/'FINAL-CHECKS.json').read_text())['docs-final']['exit']==0
# Retain every task log and standalone measurement/proof metadata file.
for p in sorted(s.iterdir()):
 if p.is_file() and p.suffix in ['.log','.json','.jsonl','.cjs','.py','.sh','.exit']:
  shutil.copyfile(p,e/p.name)
for name in ['census-before','census-after','census-mutant','census-final-after','comparison','final-comparison','replay','excluded-seeds','excluded-recorder-v1','excluded-recorder-v2','excluded-recorder-v3','excluded-recorder-v4','overlay']:
 if (s/name).is_dir():shutil.copytree(s/name,e/name,symlinks=True)
shutil.copytree(s/'control',e/'control',ignore=shutil.ignore_patterns('adapted-tree','node_modules'))
shutil.copyfile(repo/'internal/lower/expression.go',e/'expression.go.txt')
# Bind exact source, toolchain, and transformation inputs without archiving whole upstream trees.
def output(*args):return subprocess.check_output(args,cwd=repo,text=True).strip()
prov={'baseCommit':'f0271c6a7b2e92900eb7046d8246cfb89f52cfb6','upstreamCommit':output('git','-C','/workspace/typescript-source','rev-parse','HEAD'),'branch':output('git','branch','--show-current'),'node':output('node','--version'),'go':output('go','version'),'cpuMax':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'binaries':{name:hashlib.sha256((s/name).read_bytes()).hexdigest() for name in ['adamic','latent']},'ownerPinsSha256':hashlib.sha256((out/'owners.json').read_bytes()).hexdigest(),'adapterSha256':hashlib.sha256((out/'adapt.cjs').read_bytes()).hexdigest(),'ordinaryCompilerSourceUnmodified':not output('git','diff','--name-only','--','cmd','internal','go.mod','go.sum'),'allProofPhases':json.loads((s/'FINAL-CHECKS.json').read_text()),'filesBeforeEvidencePackaging':len(list(out.iterdir()))}
assert prov['upstreamCommit']=='050880ce59e30b356b686bd3144efe24f875ebc8';assert prov['ordinaryCompilerSourceUnmodified'];(out/'PROVENANCE.json').write_text(json.dumps(prov,indent=2)+'\n');shutil.copyfile(out/'PROVENANCE.json',e/'PROVENANCE.json')
for name in ['before','after','final-after','mutant']:
 file=s/name/'src/compiler/core.ts'
 if file.exists():shutil.copyfile(file,e/(name+'-core.ts'))
# Every Go source retained in evidence must use the required text suffix.
assert not list(e.rglob('*.go'))
paths=sorted(p for p in e.rglob('*') if p.is_file());(e/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(e))+'\n' for p in paths))
archive=out/'proof-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:tar.add(e,arcname='evidence')
for p in sorted(out.glob('*.tar.gz')):(out/(p.name+'.sha256')).write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
paths=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n' for p in paths))
files=[p for p in out.rglob('*') if p.is_file()];assert len(files)+1<120,len(files)+1;assert all(p.stat().st_size<95*1024*1024 for p in files)
print(json.dumps({'directoryFiles':len(files),'totalChangedFilesIncludingLedger':len(files)+1,'bytes':sum(p.stat().st_size for p in files),'allArtifactsUnder95MiB':True}),flush=True)
