require(process.argv[2]);
const values=[undefined,NaN,-Infinity,Infinity,-0,0,1,2,-1,100,0.5,'','A','a','B','b','1','2','NaN','undefined','\u{10000}','\uffff','a'.repeat(100),'Z','z',42];
function old(a,b){return a===b?0:a===undefined?-1:b===undefined?1:a<b?-1:1;}
function next(a,b){return a===b?0:a===undefined?-1:b===undefined?1:typeof a==='number'&&typeof b==='number'?(a<b?-1:1):typeof a==='string'&&typeof b==='string'?(a<b?-1:1):1;}
for(const a of values)for(const b of values)globalThis.__compareCensus(a,b,old(a,b),next(a,b));
