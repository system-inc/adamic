import json,subprocess,sys
from pathlib import Path
child=subprocess.run([sys.executable,'-c','raise SystemExit(7)'])
result={'childExitCode':child.returncode,'wrapperExitCode':child.returncode}
Path('/workspace/scratch/core-compare-amend/EXIT-CANARY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
sys.exit(child.returncode)
