### fourslash tests tests/cases/fourslash/codeFixClassImplementInterfaceNoTruncation.ts fourslash test codeFixClassImplementInterfaceNoTruncation.ts runs correctly (timeout)

```text
Timeout of 40000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves.
```

Elapsed: 84905.813 ms; timeout: 40000 ms.

Stack top:     at Test2.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
