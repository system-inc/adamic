### fourslash tests tests/cases/fourslash/codeFixClassImplementInterfaceNoTruncationProperties.ts fourslash test codeFixClassImplementInterfaceNoTruncationProperties.ts runs correctly (timeout)

```text
Timeout of 40000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves.
```

Elapsed: 40839.034 ms; timeout: 40000 ms.

Stack top:     at Test2.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
