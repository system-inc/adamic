import hashlib,json,os,shutil,subprocess,tarfile
from pathlib import Path
s=Path('/workspace/scratch/levenshtein');repo=Path('/workspace/adamic');env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules'))
def run_pair(kind,trees):
 rows=[]
 for label,tree in trees:
  manifest=lambda:{str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
  a=manifest();r=subprocess.run(['node',str(repo/'stage3/adapt/30-indexed-reads/adapt.cjs'),str(tree)],cwd=repo,env=env,capture_output=True,text=True);b=manifest()
  (s/(kind+'-replay30-'+label+'.log')).write_text(r.stdout+r.stderr)
  rows.append({'side':label,'exit':r.returncode,'stdout':r.stdout.replace(str(tree),'TREE'),'stderr':r.stderr.replace(str(tree),'TREE'),'sourceUnchanged':a==b})
 comparable=lambda row:{k:v for k,v in row.items() if k!='side'}
 assert comparable(rows[0])==comparable(rows[1]),'STOP: initializer changes adapter 30 outcome'
 assert all(r['sourceUnchanged'] for r in rows)
 return rows
for label in ['before','candidate']:
 tree=s/('replay30-'+label)
 if not tree.exists():shutil.copytree(s/label/'src',tree/'src')
full=run_pair('full',[(label,s/('replay30-'+label)) for label in ['before','candidate']])
assert full[0]['exit']==1 and full[0]['stderr']=='declined site changed: core.ts:992:21\n'
archive=s/'checkpoint30-src.tar';ref='refs/stage3/30-indexed-reads-after'
with archive.open('wb') as output:subprocess.run(['git','-C',str(s/'before'),'archive',ref,'src'],stdout=output,check=True)
checkpoint=s/'checkpoint30-before';checkpoint.mkdir()
with tarfile.open(archive) as tar:tar.extractall(checkpoint,filter='data')
shutil.copytree(checkpoint,s/'checkpoint30-candidate');p=s/'checkpoint30-candidate/src/compiler/core.ts';raw=p.read_bytes();assert raw.count(b'new Array(s2.length + 1)')==2;p.write_bytes(raw.replace(b'new Array(s2.length + 1)',b'new Array<number>(s2.length + 1).fill(0)'))
stage=run_pair('checkpoint',[(label,s/('checkpoint30-'+label)) for label in ['before','candidate']]);assert stage[0]['exit']==0
result={'identical':True,'fullTreeIdentical':True,'fullTreeRows':full,'fullTreeRefusalSite':{'file':'core.ts','siteLabel':'992:21','owner':'addRange','expression':'from[i]','action':'decline','causedByCandidate':False},'checkpointRef':ref,'checkpointTree':subprocess.check_output(['git','-C',str(s/'before'),'rev-parse',ref],text=True).strip(),'checkpointIdentical':True,'checkpointRows':stage}
(s/'replay30.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
