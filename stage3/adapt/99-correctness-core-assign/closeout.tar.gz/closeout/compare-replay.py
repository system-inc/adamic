from pathlib import Path
import json,re,time
s=Path('/workspace/scratch/core-assign');repo=Path('/workspace/adamic');begin=time.monotonic();last=begin
while True:
 try:
  before=json.loads((s/'REPLAY-before.json').read_text());after=json.loads((s/'REPLAY-after.json').read_text())
  if len(after['rows'])==84:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()-begin>1400:raise SystemExit('accepted replay not complete within bounded wait')
 if time.monotonic()-last>50:print('waiting for accepted replay',flush=True);last=time.monotonic()
 time.sleep(5)
assert len(before['rows'])==83 and before['sourceUnchanged'] and after['sourceUnchanged']
def normalize(text):
 for root in [s/'replay-before',s/'replay-after']:text=re.sub(re.escape(str(root))+r'(?=/|$|:)', 'TREE',text)
 for root in [s/'baseline-code',repo]:text=re.sub(re.escape(str(root))+r'(?=/|$|:)', 'CODE',text)
 return text
b={r['adapter']:r for r in before['rows']};a={r['adapter']:r for r in after['rows']};assert set(a)-set(b)=={'99-correctness-core-assign'};assert not set(b)-set(a);differences=[];pairs=[]
for name in sorted(b):
 left,right=b[name],a[name];assert not left['sourceFilesChanged'] and not right['sourceFilesChanged'];same=left['exit']==right['exit'] and normalize(left['output'])==normalize(right['output']);pairs.append({'adapter':name,'beforeExit':left['exit'],'afterExit':right['exit'],'normalizedOutputIdentical':same})
 if not same:differences.append({'adapter':name,'beforeExit':left['exit'],'afterExit':right['exit'],'beforeOutput':normalize(left['output']),'afterOutput':normalize(right['output'])})
new=a['99-correctness-core-assign'];assert new['exit']==0 and not new['sourceFilesChanged'];assert json.loads(new['output'])=={'files':0,'edits':0,'javascriptChanging':False}
result={'baselineAdapters':83,'acceptedAdapters':84,'pairedAdapters':83,'sourceBytesUnchangedBothSides':True,'normalization':'Only source/code root paths; elapsed timings are retained separately, not compared.','beforeNonzero':sum(r['exit']!=0 for r in b.values()),'afterNonzero':sum(r['exit']!=0 for r in a.values()),'allowedOwnedAdapter':'40-explicit-any','differences':differences,'pairs':pairs,'newFinalPhaseReplay':{'files':0,'edits':0,'javascriptChanging':False}}
(s/'REPLAY-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');assert all(d['adapter']=='40-explicit-any' for d in differences),'Non-owner replay outcome changed';print(json.dumps({k:v for k,v in result.items() if k not in ['pairs','differences']}),flush=True)
