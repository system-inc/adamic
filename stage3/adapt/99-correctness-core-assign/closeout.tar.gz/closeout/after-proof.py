from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,os,signal,time,hashlib,shutil
s=Path('/workspace/scratch/core-assign');repo=Path('/workspace/adamic');out=repo/'stage3/adapt/99-correctness-core-assign';phases={}
def save():
 (s/'AFTER-PHASES.json').write_text(json.dumps(phases,indent=2)+'\n')
def run(name,args,cwd=repo,limit=1400):
 start=time.monotonic()
 with (s/(name+'.log')).open('w') as log:
  child=subprocess.Popen(args,cwd=cwd,stdout=log,stderr=log,start_new_session=True)
  try:code=child.wait(timeout=limit)
  finally:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait()
 record={'exit':code,'seconds':time.monotonic()-start};return record
expected=json.loads((s/'SOURCE-MANIFESTS.json').read_text());actual={str(p.relative_to(s/'after/src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((s/'after/src').rglob('*')) if p.is_file()};assert actual==expected['measuredGeneric'];assert len(actual)==746
phases['freshAfterSourceEqualsMeasuredCandidate']={'files':746,'byteIdentical':True};state=json.loads((s/'CONSTRUCTION-CHECKPOINT.json').read_text())
for file,wanted in state['transformSha256'].items():assert hashlib.sha256((repo/file).read_bytes()).hexdigest()==wanted,file
phases['frozenTransformationUnchanged']=True;save();print('Fresh full apply equals all 746 measured source files',flush=True)
modules=s/'after/node_modules';assert not modules.exists();modules.symlink_to(repo/'stage3/typescript/node_modules',target_is_directory=True)
phases['after-compiler-build']=run('after-compiler-build',['npm','run','build:compiler'],s/'after');save();assert phases['after-compiler-build']['exit']==0;print('After compiler build passed',flush=True)
def types(side):
 roots=sorted((s/side/'src/compiler').rglob('*.ts'));assert len(roots)==79;return run(side+'-types-after-build',[str(s/'bin/adamic'),'types',*[str(p) for p in roots]])
with ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(types,['before','after']))
for side,record in zip(['before','after'],results):phases[side+'-types-after-build']=record;assert record['exit']==0
save();print('Both 79-root types checks passed',flush=True)
with (s/'comparison.json').open('w') as result,(s/'comparison.log').open('w') as log:r=subprocess.run(['node',repo/'stage3/adapt/99-correctness-core-assign/compare.cjs',s/'before',s/'after',s/'trials/generic-own-helper'],stdout=result,stderr=log,env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules')),timeout=120)
phases['comparison']={'exit':r.returncode};save();assert r.returncode==0;print('Public declarations and all emitted JavaScript identical',flush=True)
mutant=s/'mutant';shutil.copytree(s/'after',mutant,symlinks=True,ignore=lambda directory,names:[n for n in ['.git','built','tests'] if n in names] if Path(directory)==s/'after' else [])
env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules'))
with (s/'mutant-restore.log').open('w') as log:r=subprocess.run(['node',repo/'stage3/adapt/99-correctness-core-assign/mutant.cjs',mutant],stdout=log,stderr=log,env=env,timeout=120)
assert r.returncode==0
restored={str(p.relative_to(mutant/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((mutant/'src').rglob('*')) if p.is_file()};assert restored==expected['before'];phases['mutantSourceEqualsBaseline']={'files':746,'byteIdentical':True}
phases['mutant-types']=run('mutant-types',[str(s/'bin/adamic'),'types',*[str(p) for p in sorted((mutant/'src/compiler').rglob('*.ts'))]]);assert phases['mutant-types']['exit']==0
phases['mutant-census']=run('mutant-census',[str(s/'bin/census'),str(mutant/'src/compiler/binder.ts'),str(s/'mutant-binder.jsonl'),'0','1']);save();assert phases['mutant-census']['exit']==0
rows=[json.loads(l) for l in (s/'mutant-binder.jsonl').read_text().splitlines()];assert len(rows)==1 and rows[0]['kind']=='NotYet' and rows[0]['where'].endswith('core.ts:1364:29') and rows[0]['reason']=='a non-object representation passed through an opaque object parameter';phases['restorationMutant']=rows[0];save();print('Restoration mutant returns to core.ts:1364:29',flush=True)
