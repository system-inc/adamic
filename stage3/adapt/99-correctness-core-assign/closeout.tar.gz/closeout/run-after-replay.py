from pathlib import Path
import json,time,subprocess
s=Path('/workspace/scratch/core-assign');begin=time.monotonic();last=begin
while True:
 try:
  data=json.loads((s/'AFTER-PHASES.json').read_text())
  if 'after-compiler-build' in data:
   assert data['after-compiler-build']['exit']==0;break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()-begin>1400:raise SystemExit('After build not ready within bounded wait')
 if time.monotonic()-last>50:print('waiting for accepted compiler build',flush=True);last=time.monotonic()
 time.sleep(5)
subprocess.run(['python3',s/'replay.py','after'],check=True)
