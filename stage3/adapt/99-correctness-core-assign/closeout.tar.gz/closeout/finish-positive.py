from pathlib import Path
import json,hashlib,subprocess,tarfile,io,os
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/core-assign');out=repo/'stage3/adapt/99-correctness-core-assign'
phases=json.loads((s/'AFTER-PHASES.json').read_text());comparison=json.loads((s/'comparison.json').read_text());replay=json.loads((s/'REPLAY-COMPARISON.json').read_text());removal=json.loads((s/'observer-removal.json').read_text());assert removal['temporaryObservedTreeDeleted'] and not (s/'observed').exists();assert replay['pairedAdapters']==83 and replay['beforeNonzero']==replay['afterNonzero']==14;assert all(x['adapter']=='40-explicit-any' for x in replay['differences']);assert phases['restorationMutant']['where'].endswith('core.ts:1364:29')
for key in ['after-compiler-build','before-types-after-build','after-types-after-build','mutant-types','mutant-census']:assert phases[key]['exit']==0
nativePaths=['internal','cmd','cohere','go.mod','go.sum','stage3/census/tool'];base=json.loads((out/'provenance.json').read_text())['stackCherryPick']
with (s/'native-source-diff.log').open('w') as log:r=subprocess.run(['git','diff','--exit-code',base,'--',*nativePaths],cwd=repo,stdout=log,stderr=log);assert r.returncode==0
normal=(repo/'stage3/census/tool/main.go').read_text();bounded=(s/'census.go.txt').read_text();assert normal[:normal.index('func main() {')]==bounded[:bounded.index('func main() {')]
trials=json.loads((out/'TRIALS.json').read_text());candidate=next(t for t in trials if t['name']=='generic-own-helper');assert candidate['types']['exit']==0 and all(e['byteIdentical'] for e in candidate['emission']) and candidate['former73Summary']==[{'roots':73,'kind':'Refused','where':'core.ts:1484:12','reason':"a cast the runtime can't check"}]
baseline=json.loads((out/'CENSUS.json').read_text())['baseline'];name=lambda row:row['roots'][0].split('/src/compiler/')[1];stop=lambda row:(row['kind'],row.get('where','-').split('/src/compiler/')[-1],row.get('reason','-'));b={name(r):r for r in baseline};a={name(r):r for g in candidate['groups'] for r in g['rows']};others=[k for k,v in b.items() if not v.get('where','').endswith('core.ts:1364:29')];assert len(others)==6 and all(stop(b[k])==stop(a[k]) for k in others)
provenance=json.loads((out/'provenance.json').read_text());provenance.update(nativeCompilerSourceUnchanged=True,ordinaryInspectPrefixByteIdentical=True,binaries={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted((s/'bin').iterdir())},transformation=json.loads((s/'CONSTRUCTION-CHECKPOINT.json').read_text())['transformSha256'])
for path,wanted in provenance['transformation'].items():assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==wanted
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
(out/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');(out/'REPLAY-COMPARISON.json').write_text(json.dumps(replay,indent=2)+'\n');(out/'AFTER-PHASES.json').write_text(json.dumps(phases,indent=2)+'\n');(out/'observer-removal.json').write_text(json.dumps(removal,indent=2)+'\n')
(out/'TRIALS-CHECKPOINT.json').unlink(missing_ok=True);state=json.loads((out/'CONSTRUCTION-CHECKPOINT.json').read_text());state.update(afterFullApply='pass',pairedReplay='pass: 83 pairs, only owner difference, 14 inherited nonzero each',publicDeclarations='both byte-identical',restorationMutant='NotYet core.ts:1364:29',complete=True);(out/'CONSTRUCTION.json').write_text(json.dumps(state,indent=2)+'\n');(out/'CONSTRUCTION-CHECKPOINT.json').unlink()
text=(out/'MEASURE.md').read_text();text=text.replace('Construction\nis in progress; final results belong in PROOF.md.','Construction\nis complete; every required check passes. See PROOF.md.');text=text.replace('Observer removal is required before final closeout.','The temporary observer was removed and its scratch build deleted; no observer process remains.');text=text.replace('The final full apply, paired replay, both public declaration comparisons and\noriginal-helper restoration mutant are required before completion. Their\nresults will be recorded in PROOF.md.','Both full applies, both ordinary builds, both public declaration comparisons,\npaired replay and the original-helper restoration mutant pass. PROOF.md and\ncomparison.json retain the results. All 746 fresh accepted source files equal\nthe measured candidate; all six other root outcomes are unchanged.');(out/'MEASURE.md').write_text(text)
p=out/'README.md';text=p.read_text().replace('Construction and composition results are recorded in PROOF.md when complete.\nThe complete source/build comparisons, paired adapter replay and restoration\nmutant are required before this branch is considered finished.','Construction and composition pass. PROOF.md records both full applies, both\nordinary builds, exact source and emitted-byte comparisons, the paired adapter\nreplay, and the restoration mutant. The two public declarations and all nine\nemitted JavaScript files are byte-identical.');p.write_text(text)
(out/'PROOF.md').write_text('''# Core assign ownership-helper proof

The generic helper is implemented in the existing owner, adaptation 40, with a
shared final entrypoint in 99-correctness-core-assign. assign and all callers are
unchanged. No compiler, checker, refusal rule or backend source is modified.

| Check | Result |
| --- | --- |
| Before and accepted full apply, --build-product | Both exit 0 |
| Fresh accepted source versus measured candidate | All 746 files byte-identical |
| Source delta versus baseline | Only hasProperty's pinned header in core.ts |
| assign and every caller | Byte-identical |
| Ordinary compiler builds before and after | Both exit 0 |
| Adamic types, all 79 sorted roots before and after | Both exit 0; zero diagnostics |
| Core JavaScript, comments kept and removed | Byte-identical |
| All nine emitted compiler JavaScript files | Byte-identical |
| typescript.d.ts and tsserverlibrary.d.ts | Both byte-identical |
| typescript.internal.d.ts | Only the hasProperty generic signature changes |
| Whole-owner contract | 12 no-write refusals; foreign edit and LF/CRLF preserved |
| Owner replay | Zero writes; source bytes and mtime preserved |
| Paired adapter replay | 83 pairs; only amended owner output differs |
| Inherited replay failures | Same 14 nonzero exits before and after |
| Replay source trees | Zero changed source bytes on both sides |
| New shared final phase replay | Zero files, edits and writes |
| Original-helper mutant types | All 79 roots, exit 0 |
| Original-helper mutant source | All 746 files equal baseline |
| Original-helper mutant ordinary binder census | NotYet core.ts:1364:29 |
| Accepted per-file census | All 73 wall roots reach Refused core.ts:1484:12 |
| Other six root outcomes | Unchanged per file |
| Temporary observer | Removed; scratch build deleted; no live observer process |

The accepted helper's body is unchanged. Its T extends object parameter keeps
the actual caller type at the existing own-property library operation. The
object-only helper previously required the opaque parameter's native Object
storage, which an abstract assign T did not prove. No dictionary cast or new
string index signature is introduced.

Both full applies use the pinned TypeScript 6.0.3 checkout. The baseline adapter
set was frozen at the clean getownvalues cherry-pick before implementation.
The accepted apply keeps every early adapter input stable: 40 retains its
original early object output, and its shared owner planner introduces the
final generic spelling at the requested late entrypoint. Whole-owner pins
cover the upstream, object and generic states and reject partial/foreign owners.

The ordinary per-file census uses the same unmodified inspect function as
stage3/census/tool: Load, checking, then Lower. Its only Go overlay enumerates
bounded root groups. The fresh accepted tree equals every measured candidate
source byte, not a partial-root fallback. All authored Go evidence is .go.txt.

The paired replay runs each frozen baseline adapter on the completed baseline
copy and each accepted adapter on the completed accepted copy. All source
hashes are checked after every adapter. Only source/code root paths are
normalized in output comparison; elapsed timings remain raw and are not
compared. The amended owner's output is the sole common-adapter difference.
Its 14 inherited nonzero outcomes are retained, not waived or claimed passes.

The mutant restores exactly hasProperty(map: object, key: string), with its
original body. Every source file then equals baseline and the real binder
census returns the original opaque-object-parameter NotYet at core.ts:1364:29.
The new cast refusal at 1484:12 is an existing next wall, not a native compiler
acceptance claim or a new cast.

MEASURE.md reports all four spelling results and complete caller types.
The whole oracle passes its original guards: 106366 passes, the same one
expected failure and zero skips. It records 30782 calls and 61568 argument
appearances in the accepted traversal. A retained hook-timeout attempt adds
one call and two appearances, for 30783 calls and 61570 appearances across
all actual attempts. The only accessor is inherited Object.prototype.__proto__;
there are no inherited enumerable properties, own accessors or symbol keys.

comparison.json, AFTER-PHASES.json, REPLAY-COMPARISON.json, CENSUS.json and the
archives retain complete hashes, diagnostics, commands, raw logs and mutants.
Each archive has an internal SHA256SUMS and an adjacent SHA256. Transformation
file hashes stayed frozen through the accepted apply; later proof metadata
changes product keys without changing the transformation. No Loom product is
published and no force-push or main push is used.
''')
# Record process cleanup before packing. All worker processes have completed.
control=os.getpid();ancestors={control};at=control
while at>1:
 try:at=int((Path('/proc')/str(at)/'stat').read_text().split(') ')[1].split()[1]);ancestors.add(at)
 except (OSError,ValueError,IndexError):break
live=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name) in ancestors:continue
 try:
  stat=(p/'stat').read_text().split(') ')[1].split();args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]
 except OSError:continue
 if stat[0]=='Z':continue
 if args and any(arg.startswith(str(s)+'/') for arg in args):live.append({'pid':int(p.name),'args':args})
assert not live,live
(s/'process-cleanup.json').write_text(json.dumps({'liveTaskProcesses':live,'allStartedWorkersStopped':True,'temporaryObserverDeleted':True},indent=2)+'\n');(out/'process-cleanup.json').write_bytes((s/'process-cleanup.json').read_bytes())
# All proof producers are now stopped. Keep progress/private notes out of final proof.
files=[p for p in sorted(s.iterdir()) if p.is_file() and p.name not in ['STATE.json','trials-progress.json','finish-positive.log'] and p.suffix in ['.json','.jsonl','.log','.py','.cjs','.sh','.txt']]
a=out/'closeout.tar.gz';manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files)
with tarfile.open(a,'w:gz') as tf:
 for p in files:tf.add(p,arcname='closeout/'+p.name)
 b=manifest.encode();i=tarfile.TarInfo('closeout/SHA256SUMS');i.size=len(b);tf.addfile(i,io.BytesIO(b))
(out/'closeout.sha256').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  '+a.name+'\n')
verified=[]
for archive in sorted(out.glob('*.tar.gz')):
 external=archive.with_name(archive.name.removesuffix('.tar.gz')+'.sha256');assert hashlib.sha256(archive.read_bytes()).hexdigest()==external.read_text().split()[0]
 with tarfile.open(archive) as tf:
  manifests=[m for m in tf.getmembers() if m.name.endswith('/SHA256SUMS')];assert len(manifests)==1
  m=manifests[0];prefix=m.name.rsplit('/',1)[0]+'/'
  for line in tf.extractfile(m).read().decode().splitlines():
   digest,name=line.split('  ',1);assert hashlib.sha256(tf.extractfile(prefix+name).read()).hexdigest()==digest,(archive.name,name)
 verified.append(archive.name)
(out/'ARCHIVES-VERIFIED.json').write_text(json.dumps({'archives':verified,'allExternalAndInternalHashesVerified':True,'newEvidenceFileCount':len([p for p in out.rglob('*') if p.is_file()])},indent=2)+'\n');assert len([p for p in out.rglob('*') if p.is_file()])<150
for file in ['MEASURE.md','PROOF.md','README.md']:assert not any(ch in (out/file).read_text() for ch in ['\u2013','\u2014'])
print(json.dumps({'built':True,'archivesVerified':len(verified),'evidenceFiles':len([p for p in out.rglob('*') if p.is_file()]),'pairedAdapters':83,'newWall':'core.ts:1484:12','allWorkersStopped':True}),flush=True)
