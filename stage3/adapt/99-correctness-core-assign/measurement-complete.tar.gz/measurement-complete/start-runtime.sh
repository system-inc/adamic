set -euo pipefail
source /workspace/adamic-tools/env.sh
while kill -0 1167 2>/dev/null; do sleep 5; done
test -f /workspace/scratch/core-assign/before/patch-set.md
node /workspace/scratch/core-assign/callers.cjs /workspace/scratch/core-assign/before > /workspace/scratch/core-assign/callers.json 2> /workspace/scratch/core-assign/callers.log
python3 /workspace/scratch/core-assign/prepare-runtime.py > /workspace/scratch/core-assign/prepare-runtime.log 2>&1
python3 /workspace/scratch/core-assign/runtime.py > /workspace/scratch/core-assign/runtime.log 2>&1
