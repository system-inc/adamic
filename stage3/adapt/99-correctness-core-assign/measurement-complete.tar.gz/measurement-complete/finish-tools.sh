set -euo pipefail
source /workspace/adamic-tools/env.sh
started=$SECONDS
while kill -0 822 2>/dev/null; do
 if (( SECONDS - started > 1400 )); then exit 124; fi
 sleep 5
done
GOMAXPROCS=4 go build -o /workspace/scratch/core-assign/bin/ ./cmd/adamic ./stage3/census/tool > /workspace/scratch/core-assign/build-tools-retry.log 2>&1
GOMAXPROCS=4 go build -overlay /workspace/scratch/core-assign/census-overlay.json -o /workspace/scratch/core-assign/bin/census ./stage3/census/tool > /workspace/scratch/core-assign/build-census-retry.log 2>&1
