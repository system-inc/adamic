from pathlib import Path
import subprocess,json,time,os,hashlib,collections,re
from concurrent.futures import ThreadPoolExecutor,as_completed
s=Path('/workspace/scratch/core-assign');repo=Path('/workspace/adamic');out=repo/'stage3/adapt/99-correctness-core-assign'
assert json.loads((out/'RUNTIME.json').read_text())['complete'],'Runtime measurement must finish before type-only trials'
with (s/'trials-prepare.log').open('w') as log:subprocess.run(['node',s/'prepare-trials.cjs'],stdout=log,stderr=log,check=True,timeout=120)
trials=json.loads((s/'trials-plan.json').read_text());results=[]
for trial in trials:
 name=trial['name'];tree=s/'trials'/name;roots=sorted((tree/'src/compiler').rglob('*.ts'));assert len(roots)==79
 original={str(p.relative_to(s/'before/src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (s/'before/src').rglob('*') if p.is_file()};changed={str(p.relative_to(tree/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()};assert original.keys()==changed.keys();assert [k for k in original if original[k]!=changed[k]]==['compiler/core.ts']
 start=time.monotonic()
 with (s/f'{name}-types.log').open('w') as log:r=subprocess.run([s/'bin/adamic','types',*roots],stdout=log,stderr=log,timeout=1400)
 trial['types']={'exit':r.returncode,'roots':79,'seconds':time.monotonic()-start,'log':f'{name}-types.log','diagnostics':len(re.findall(r'error TS[0-9]+:',(s/f'{name}-types.log').read_text()))};trial['sourceFiles']=len(original);trial['changedSources']=['compiler/core.ts'];trial['groups']=[]
 def group(start,count):
  begin=time.monotonic();stem=f'{name}-census-{start:02d}'
  with (s/(stem+'.log')).open('w') as log:r=subprocess.run([s/'bin/census',tree/'src/compiler',s/(stem+'.jsonl'),str(start),str(count)],stdout=log,stderr=log,timeout=1400)
  assert r.returncode==0;rows=[json.loads(l) for l in (s/(stem+'.jsonl')).read_text().splitlines()];assert len(rows)==count
  return {'start':start,'count':count,'seconds':time.monotonic()-begin,'rows':rows}
 with ThreadPoolExecutor(max_workers=2) as pool:
  for f in as_completed([pool.submit(group,start,count) for start,count in [(0,20),(20,20),(40,20),(60,19)]]):
   g=f.result();trial['groups'].append(g);print(name,'census group',g['start'],g['count'],'completed',flush=True);(s/'trials-progress.json').write_text(json.dumps({'completed':results,'current':trial},indent=2)+'\n')
 trial['groups'].sort(key=lambda g:g['start'])
 trial['allCallersUntouched']=True;results.append(trial);(s/'TRIALS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,'complete types exit',trial['types']['exit'],flush=True)
print('TRIALS COMPLETE',flush=True)
