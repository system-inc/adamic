from pathlib import Path
import json,hashlib,subprocess,os,signal,time,shutil,sys,re
s=Path('/workspace/scratch/core-assign');repo=Path('/workspace/adamic');side=sys.argv[1];assert side in ['before','after'];source=s/side;tree=s/('replay-'+side);code=s/'baseline-code' if side=='before' else repo;adapters=code/'stage3/adapt';logs=s/('replay-'+side+'-logs');logs.mkdir()
shutil.copytree(source,tree,symlinks=True,ignore=lambda directory,names:['built'] if Path(directory)==source else [])
def snapshot():return {str(p.relative_to(tree/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
frozen=snapshot();rows=[];env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules'))
for directory in sorted(p for p in adapters.iterdir() if p.is_dir()):
 start=time.monotonic();log=logs/(directory.name+'.log')
 with log.open('w') as stream:
  child=subprocess.Popen(['node',directory/'adapt.cjs',tree],cwd=repo,env=env,stdout=stream,stderr=stream,start_new_session=True)
  try:status=child.wait(timeout=1400)
  finally:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait()
 current=snapshot();changed=[k for k in frozen if frozen[k]!=current.get(k)]+[k for k in current if k not in frozen];row={'adapter':directory.name,'exit':status,'seconds':time.monotonic()-start,'sourceFilesChanged':changed,'output':log.read_text(errors='backslashreplace')};rows.append(row);(s/('REPLAY-'+side+'.json')).write_text(json.dumps({'side':side,'sourceFiles':len(frozen),'sourceUnchanged':not changed,'rows':rows},indent=2)+'\n');print(side,directory.name,status,'changed',len(changed),flush=True);assert not changed,'Replay changed source: '+directory.name
print('REPLAY COMPLETE',side,flush=True)
