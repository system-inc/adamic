from pathlib import Path
import json,collections,hashlib,tarfile,re,shutil,subprocess
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/core-assign');out=repo/'stage3/adapt/99-correctness-core-assign'
runtime=json.loads((out/'RUNTIME-RECONCILED.json').read_text());assert runtime['complete']
trials=json.loads((s/'TRIALS.json').read_text());assert len(trials)==3
trials.append(json.loads((s/'GENERIC-HELPER.json').read_text()));assert len(trials)==4
baseline=[]
for start in [0,20,40,60]:baseline += [json.loads(l) for l in (s/f'baseline-census-{start:02d}.jsonl').read_text().splitlines()]
assert len(baseline)==79
baseTree=str(s/'before')
def rootName(row):
 root=row['roots'][0];i=root.index('/src/compiler/');return root[i+len('/src/compiler/'):]
def stop(row):
 where=row.get('where','-');reason=row.get('reason','-')
 if row['kind']=='checker' and row.get('diagnostics'):
  first=row['diagnostics'][0];match=re.match(r'^(.*?\.ts:[0-9]+:[0-9]+): (error TS[0-9]+:.*)',first,re.S)
  if match:where,reason=match.groups()
  else:reason=first
 i=where.find('/src/compiler/');where=where[i+len('/src/compiler/'):] if i>=0 else where
 return (row['kind'],where,reason)
base={rootName(r):r for r in baseline};assert len(base)==79
wall={k for k,r in base.items() if stop(r)[1]=='core.ts:1364:29'};assert len(wall)==73
eligible=[];tables=[]
for t in trials:
 rows=[r for g in t['groups'] for r in g['rows']];assert len(rows)==79;byRoot={rootName(r):r for r in rows};assert byRoot.keys()==base.keys();t['censusSummary']=[{'roots':n,'kind':key[0],'where':key[1],'reason':key[2]} for key,n in collections.Counter(stop(r) for r in rows).items()];t['former73Summary']=[{'roots':n,'kind':key[0],'where':key[1],'reason':key[2]} for key,n in collections.Counter(stop(byRoot[k]) for k in wall).items()];t['namedWallCleared']=t['types']['exit']==0 and all(byRoot[k]['kind']!='checker' and stop(byRoot[k])[1]!='core.ts:1364:29' for k in wall)
 t['regressesEarlierWithinCore']=any(stop(byRoot[k])[1].startswith('core.ts:') and int(stop(byRoot[k])[1].split(':')[1])<1364 for k in wall)
 if not t.get('exploratoryOnly') and t['types']['exit']==0 and all(e['byteIdentical'] for e in t['emission']) and t['namedWallCleared']:eligible.append(t['name'])
 tables.append(t)
(s/'MEASUREMENT-DECISION.json').write_text(json.dumps({'eligibleSpellings':eligible,'buildRequired':bool(eligible)},indent=2)+'\n')
(out/'TRIALS.json').write_text(json.dumps(tables,indent=2)+'\n');(out/'CENSUS.json').write_text(json.dumps({'baseline':baseline,'trials':tables,'baseline73Roots':sorted(wall)},indent=2)+'\n')
lines=['# assign ordinary compiler census','','Unmodified Adamic compiler sources on the frozen main plus getownvalues stack.','The only Go overlay changes the census main enumeration into bounded root groups.','Its ordinary Load/check/Lower inspect function is unchanged. Each row measures one','root independently, with all checking enabled. No source fallback or refusal','suppression is used. All 79 roots are measured for baseline and each spelling.','','Baseline groups are 20, 20, 20 and 19 sorted compiler roots.','']
def cell(s):return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('|','\\|').replace('\n','<br>')
def summary(rows):
 out=[]
 for key,n in collections.Counter(stop(r) for r in rows).items():out.append(f'| {n} | {key[0]} | `{key[1]}` | {cell(key[2])} |')
 return out
lines+=['| Baseline roots | Kind | First stop | Exact reason |','| ---: | --- | --- | --- |',*summary(baseline),'']
for t in tables:
 lines += [f"## {t['name']}",'',f"Spelling: `{t['description']}`.",'',f"Types over all 79 roots: exit {t['types']['exit']}, {t['types']['diagnostics']} diagnostics. Core JavaScript byte-identical with comments kept: {t['emission'][0]['byteIdentical']}; removed: {t['emission'][1]['byteIdentical']}. All caller source bytes unchanged.",'','| Former 73 roots | Kind | First stop | Exact reason |','| ---: | --- | --- | --- |']
 for r in t['former73Summary']:lines.append(f"| {r['roots']} | {r['kind']} | `{r['where']}` | {cell(r['reason'])} |")
 for g in t['groups']:
  lines += ['',f"Group {g['start']+1} through {g['start']+g['count']} ({g['seconds']:.3f} seconds):",'','| Roots | Kind | First stop | Exact reason |','| ---: | --- | --- | --- |',*summary(g['rows'])]
 lines+=['']
lines += ['CENSUS.json and TRIALS.json retain every root and exact diagnostics.','Raw grouped output and type-command logs are in the closeout archive.','A checker result stops before lowering; no later lowering stop is claimed for','a checker-rejected spelling.','']
(out/'CENSUS.md').write_text('\n'.join(lines))
print('Build required: '+', '.join(eligible) if eligible else 'No qualifying type-only spelling; measurement-only closeout ready',flush=True)
