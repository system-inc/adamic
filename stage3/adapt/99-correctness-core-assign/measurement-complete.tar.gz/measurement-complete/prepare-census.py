from pathlib import Path
import json
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/core-assign');original=(repo/'stage3/census/tool/main.go').read_text();prefix=original[:original.index('func main() {')]
main='''func main() {
 if len(os.Args) != 5 { panic("usage: census source-directory output.jsonl start count") }
 var paths []string
 err := filepath.WalkDir(os.Args[1], func(path string, entry os.DirEntry, err error) error {
  if err != nil { return err }
  if !entry.IsDir() && filepath.Ext(path) == ".ts" { paths = append(paths, path) }
  return nil
 })
 if err != nil { panic(err) }
 sort.Strings(paths)
 var start, count int
 if _, err := fmt.Sscanf(os.Args[3], "%d", &start); err != nil { panic(err) }
 if _, err := fmt.Sscanf(os.Args[4], "%d", &count); err != nil { panic(err) }
 if start < 0 || count < 0 || start+count > len(paths) { panic("invalid root group") }
 output, err := os.Create(os.Args[2]); if err != nil { panic(err) }; defer output.Close()
 encoder := json.NewEncoder(output)
 for index, path := range paths[start:start+count] {
  result := inspect([]string{path})
  if err := encoder.Encode(result); err != nil { panic(err) }
  fmt.Fprintf(os.Stderr, "%d/%d %s %s %.3fs\\n", start+index+1, len(paths), path, result.Kind, result.Seconds)
 }
}
'''
(s/'census.go.txt').write_text(prefix+main);(s/'census-overlay.json').write_text(json.dumps({'Replace':{str(repo/'stage3/census/tool/main.go'):str(s/'census.go.txt')}},indent=2)+'\n')
