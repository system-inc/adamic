from pathlib import Path
import json,time,subprocess
s=Path('/workspace/scratch/core-assign');out=Path('/workspace/adamic/stage3/adapt/99-correctness-core-assign');begin=time.monotonic()
lastHeartbeat=time.monotonic()
while True:
 try:
  d=json.loads((out/'RUNTIME.json').read_text())
  if d['complete']:break
  if any(p['failures'] for p in d['pieces']):raise SystemExit('Runtime failed; caller audit deferred')
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()-begin>5400:raise SystemExit('Caller audit bounded wait expired')
 if time.monotonic()-lastHeartbeat>=50:
  print(json.dumps({'event':'waiting-for-runtime','completedUnits':len(d.get('completedUnits',[]))}),flush=True);lastHeartbeat=time.monotonic()
 time.sleep(5)
with (s/'callers-audit.log').open('w') as log,(s/'callers-audit.json').open('w') as result:subprocess.run(['node',s/'callers.cjs',s/'before'],stdout=result,stderr=log,check=True,timeout=180)
a=json.loads((out/'callers.json').read_text());b=json.loads((s/'callers-audit.json').read_text());assert a['callers']==b['callers']
unexpected=[r for r in b['references'] if not r['metadata'] and not r['directCall']]
result={'callCount':b['callCount'],'directCallListUnchanged':True,'unexpectedValueReferences':unexpected,'references':b['references']};(out/'caller-references.json').write_text(json.dumps(result,indent=2)+'\n');assert not unexpected,'Indirect assign reference requires investigation';print('Caller reference audit passed',flush=True)
