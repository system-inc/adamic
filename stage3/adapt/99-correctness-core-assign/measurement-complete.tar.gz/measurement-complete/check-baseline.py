from pathlib import Path
import subprocess,os,json,time,hashlib
s=Path('/workspace/scratch/core-assign');start=time.monotonic()
while not (s/'before/patch-set.md').exists() or not (s/'bin/adamic').exists() or not (s/'bin/census').exists():
 if time.monotonic()-start>1400:raise SystemExit('Prerequisites not ready within bounded wait')
 time.sleep(5)
roots=sorted((s/'before/src/compiler').rglob('*.ts'));assert len(roots)==79
(s/'roots.json').write_text(json.dumps([str(p.relative_to(s/'before')) for p in roots],indent=2)+'\n')
with (s/'baseline-types.log').open('w') as log:r=subprocess.run([s/'bin/adamic','types',*roots],stdout=log,stderr=log,timeout=1400)
(s/'baseline-types.json').write_text(json.dumps({'exit':r.returncode,'roots':len(roots)},indent=2)+'\n');assert r.returncode==0
for start,count in [(0,20),(20,20),(40,20),(60,19)]:
 with (s/f'baseline-census-{start:02d}.log').open('w') as log:r=subprocess.run([s/'bin/census',s/'before/src/compiler',s/f'baseline-census-{start:02d}.jsonl',str(start),str(count)],stdout=log,stderr=log,timeout=1400)
 assert r.returncode==0;print('baseline census group',start,count,'completed',flush=True)
