from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time
s=Path('/workspace/scratch/core-assign');roots=sorted((s/'before/src/compiler').rglob('*.ts'));assert len(roots)==79;groups=[(0,20),(20,20),(40,20),(60,19)];ledger=[]
def read(p):
 rows=[]
 if p.exists():
  for line in p.read_text().splitlines():
   try:rows.append(json.loads(line))
   except json.JSONDecodeError:break
 return rows
retained={}
for start,count in groups:
 candidates=[s/f'baseline-census-{start:02d}.jsonl',s/f'baseline-census-{start:02d}-remaining.jsonl']
 byRoot={}
 for p in candidates:
  if p.exists():
   (s/(p.name+'.retained.txt')).write_bytes(p.read_bytes())
   for row in read(p):byRoot.setdefault(row['roots'][0],row)
 rows=[byRoot[str(p)] for p in roots[start:start+count] if str(p) in byRoot];assert [r['roots'][0] for r in rows]==[str(p) for p in roots[start:start+len(rows)]];retained[start]=rows

def run(start,count):
 rows=retained[start];remaining=count-len(rows);begin=time.monotonic()
 if remaining:
  stem=f'baseline-parallel-{start:02d}'
  with (s/(stem+'.log')).open('w') as log:r=subprocess.run([s/'bin/census',s/'before/src/compiler',s/(stem+'.jsonl'),str(start+len(rows)),str(remaining)],stdout=log,stderr=log,timeout=1400)
  assert r.returncode==0;fresh=read(s/(stem+'.jsonl'));assert len(fresh)==remaining;rows=rows+fresh
 (s/f'baseline-census-{start:02d}.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows));return {'start':start,'count':count,'retainedCompletedRoots':len(retained[start]),'freshRoots':remaining,'freshSeconds':time.monotonic()-begin}
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(run,start,count) for start,count in groups]):
  record=f.result();ledger.append(record);(s/'baseline-resume.json').write_text(json.dumps(sorted(ledger,key=lambda r:r['start']),indent=2)+'\n');print('baseline group complete',record['start'],record['count'],flush=True)
