from pathlib import Path
import time,json,subprocess,os
s=Path('/workspace/scratch/core-assign');out=Path('/workspace/adamic/stage3/adapt/99-correctness-core-assign');begun=time.monotonic()
lastHeartbeat=time.monotonic()
while True:
 try:
  d=json.loads((out/'RUNTIME.json').read_text())
  if d['complete']:break
  if any(p['failures'] for p in d['pieces']):raise SystemExit('Runtime failed; no spelling trial started')
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()-begun>5400:raise SystemExit('Runtime not complete within bounded waiting window')
 if time.monotonic()-lastHeartbeat>=50:
  print(json.dumps({'event':'waiting-for-runtime','completedUnits':len(d.get('completedUnits',[]))}),flush=True);lastHeartbeat=time.monotonic()
 time.sleep(5)
with (s/'baseline-resume.log').open('w') as log:subprocess.run(['python3',s/'finish-baseline.py'],stdout=log,stderr=log,check=True)
with (s/'runtime-reconcile.log').open('w') as log:subprocess.run(['python3',s/'reconcile-runtime.py'],stdout=log,stderr=log,check=True,timeout=120)
subprocess.run(['python3',s/'trials.py'],check=True)
