from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import json,hashlib,os,subprocess,signal,time,tarfile,shutil
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/core-assign');out=repo/'stage3/adapt/99-correctness-core-assign';out.mkdir(exist_ok=True)
plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());units=plan['units'];summary={'complete':False,'units':len(units),'completedUnits':[],'pieces':[],'calls':0,'arguments':0,'objects':0,'undefined':0,'plain':0,'Object.prototype':0,'nullPrototype':0,'nonPlain':0,'inheritedEnumerable':0,'ownAccessors':0,'inheritedAccessors':0,'ownSymbols':0,'inheritedSymbols':0,'oracleCounts':{'pass':0,'fail':0,'skip':0}}
if (out/'RUNTIME.json').exists():summary=json.loads((out/'RUNTIME.json').read_text())
def snapshot():return {str(p.relative_to(s/'observed')):hashlib.sha256(p.read_bytes()).hexdigest() for base in ['src','built/local'] for p in sorted((s/'observed'/base).rglob('*')) if p.is_file()}
frozen=snapshot();(s/'runtime-frozen.json').write_text(json.dumps(frozen,indent=2)+'\n')
def run(unit,directory):
 name=unit['name'];calls=directory/'calls'/name;calls.mkdir(parents=True);results=directory/'results'
 old=s/'runtime-01-first-attempt';prior=old/'results'/name/'report.json'
 if directory.name=='runtime-01' and prior.exists() and json.loads(prior.read_text())['status']=='pass':
  shutil.copytree(old/'calls'/name,calls,dirs_exist_ok=True);shutil.copytree(old/'results'/name,results/name);shutil.copyfile(old/(name+'.log'),directory/(name+'.log'));return name,0,json.loads(prior.read_text())
 env=dict(os.environ,STAGE3_ADAPTED_TREE=str(s/'observed'),ASSIGN_DIR=str(calls),STAGE3_SHARD_SECONDS='90',NODE_OPTIONS='--require='+str(s/'preload.cjs'),NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1')
 with (directory/(name+'.log')).open('w') as log:
  child=subprocess.Popen(['python3',str(repo/'stage3/lane/shard.py'),name,str(results)],cwd=repo,env=env,stdout=log,stderr=log,start_new_session=True)
  try:code=child.wait(timeout=120)
  finally:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait()
 report=json.loads((results/name/'report.json').read_text());return name,code,report
for start in range(0,len(units),20):
 if start<len(summary['completedUnits']):continue
 begun=time.monotonic();piece=start//20+1;directory=s/f'runtime-{piece:02d}';directory.mkdir();subset=units[start:start+20]
 with ThreadPoolExecutor(max_workers=1 if piece==1 and (s/'runtime-01-first-attempt').exists() else 3) as pool:observations=[f.result() for f in as_completed([pool.submit(run,u,directory) for u in subset])]
 assert time.monotonic()-begun<1400
 assert frozen==snapshot()
 packed=directory/'packed';packed.mkdir();stats=Counter();oracle=Counter();failures=[]
 with (packed/'events.jsonl').open('w') as events,(packed/'shard-evidence.jsonl').open('w') as evidence:
  for name,code,report in sorted(observations):
   if code!=0 or report['status']!='pass':failures.append({'unit':name,'exit':code,'report':report})
   oracle.update(report['counts'])
   for p in sorted((directory/'results'/name).rglob('*')):
    if p.is_file() and 'adapted-tree' not in p.relative_to(directory/'results'/name).parts:evidence.write(json.dumps({'unit':name,'path':str(p.relative_to(directory/'results'/name)),'text':p.read_text(errors='backslashreplace')})+'\n')
   evidence.write(json.dumps({'unit':name,'path':'driver.log','text':(directory/(name+'.log')).read_text()})+'\n')
   for file in sorted((directory/'calls'/name).glob('*.jsonl')):
    for line in file.read_text().splitlines():
     row=json.loads(line);events.write(json.dumps({'unit':name,'process':file.stem,**row})+'\n');stats['calls']+=1
     for arg in row['arguments']:
      stats['arguments']+=1
      if arg['kind']=='undefined':stats['undefined']+=1;continue
      if arg['kind'] in ['object','array','function'] and not arg.get('null'):
       stats['objects']+=1;stats['plain']+=arg['plain'];stats['Object.prototype']+=arg['prototype']=='Object.prototype';stats['nullPrototype']+=arg['prototype']=='null';stats['nonPlain']+=not arg['plain'];stats['inheritedEnumerable']+=bool(arg['inheritedEnumerable']);stats['ownAccessors']+=any(a['level']==0 for a in arg['accessors']);stats['inheritedAccessors']+=any(a['level']>0 for a in arg['accessors']);stats['ownSymbols']+=any(a['level']==0 for a in arg['symbols']);stats['inheritedSymbols']+=any(a['level']>0 for a in arg['symbols'])
      else:stats['other']+=1
 record={'piece':piece,'units':[u['name'] for u in subset],'seconds':time.monotonic()-begun,'stats':dict(stats),'oracleCounts':dict(oracle),'failures':failures,'frozenInputsUnchanged':True}
 (packed/'piece.json').write_text(json.dumps(record,indent=2)+'\n')
 (packed/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(packed.iterdir()) if p.name!='SHA256SUMS'))
 archive=out/f'runtime-{piece:02d}.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  for p in sorted(packed.iterdir()):tf.add(p,arcname=f'runtime-{piece:02d}/'+p.name)
 (out/f'runtime-{piece:02d}.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
 summary['pieces'].append(record)
 if not failures:
  summary['completedUnits']+=record['units']
  for k,n in stats.items():summary[k]=summary.get(k,0)+n
  for k,n in oracle.items():summary['oracleCounts'][k]+=n
 summary['complete']=len(summary['completedUnits'])==len(units)
 (out/'RUNTIME.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'piece':piece,'completed':len(summary['completedUnits']),'calls':summary['calls'],'seconds':record['seconds'],'failures':len(failures)}),flush=True)
 for name,_,_ in observations:shutil.rmtree(directory/'results'/name/'adapted-tree',ignore_errors=True)
 if failures:raise SystemExit('Runtime piece failed; evidence retained, no build.')
assert summary['oracleCounts']==plan['counts'];assert len(summary['completedUnits'])==len(set(summary['completedUnits']))==398
print('COMPLETE',flush=True)
