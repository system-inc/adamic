from pathlib import Path
import subprocess,json,time,os,hashlib
s=Path('/workspace/scratch/core-assign');tree=s/'observed';records={}
subprocess.run(['cp','-a',s/'before',tree],check=True)
p=tree/'src/compiler/core.ts';raw=p.read_bytes();before=raw.decode();needle='export function assign<T extends object>(t: T, ...args: (T | undefined)[]): T {';assert before.count(needle)==1
p.write_bytes(before.replace(needle,needle+'\r\n    (globalThis as any).__assignMeasure(t, args, Object.prototype);').encode())
(tree/'node_modules').symlink_to('/workspace/adamic/stage3/typescript/node_modules',target_is_directory=True)
for phase,args in [('build',['npm','run','build']),('harness',['npm','exec','hereby','--','tests'])]:
 start=time.monotonic()
 with (s/('observed-'+phase+'.log')).open('w') as log:r=subprocess.run(args,cwd=tree,stdout=log,stderr=log,timeout=1400)
 records[phase]={'exit':r.returncode,'seconds':time.monotonic()-start};(s/'observed-preparation.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
(tree/'node_modules').unlink()
(s/'observed-core.ts.txt').write_bytes(p.read_bytes())
(s/'baseline-core.ts.txt').write_bytes(raw)
print('runtime observer and harness prepared',flush=True)
