from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib,tarfile
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/core-assign');out=repo/'stage3/adapt/99-correctness-core-assign';d=json.loads((out/'RUNTIME.json').read_text());assert d['complete'];plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());wanted={u['name']:u for u in plan['units']};units=[];reports={};totals=Counter();positions=defaultdict(Counter);sites=Counter();details=Counter();sequences={};acceptedEvents={};kinds=Counter()
def add(stats,arg):
 stats['arguments']+=1
 if arg['kind']=='undefined':stats['undefined']+=1;return
 if arg['kind'] in ['object','array','function'] and not arg.get('null'):
  stats['objects']+=1;stats['plain']+=arg['plain'];stats['Object.prototype']+=arg['prototype']=='Object.prototype';stats['nullPrototype']+=arg['prototype']=='null';stats['nonPlain']+=not arg['plain'];stats['inheritedEnumerable']+=bool(arg['inheritedEnumerable']);stats['ownAccessors']+=any(a['level']==0 for a in arg['accessors']);stats['inheritedAccessors']+=any(a['level']>0 for a in arg['accessors']);stats['ownSymbols']+=any(a['level']==0 for a in arg['symbols']);stats['inheritedSymbols']+=any(a['level']>0 for a in arg['symbols'])
  assert arg['plain']==(arg['prototype'] in ['Object.prototype','null'])
 else:stats['other']+=1
for piece in d['pieces']:
 assert not piece['failures'] and piece['seconds']<1400;units+=piece['units'];n=piece['piece'];archive=out/f'runtime-{n:02d}.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==(out/f'runtime-{n:02d}.sha256').read_text().split()[0];pstats=Counter();oracle=Counter()
 with tarfile.open(archive) as tf:
  prefix=f'runtime-{n:02d}/'
  for line in tf.extractfile(prefix+'SHA256SUMS').read().decode().splitlines():
   digest,name=line.split('  ',1);assert hashlib.sha256(tf.extractfile(prefix+name).read()).hexdigest()==digest
  assert json.loads(tf.extractfile(prefix+'piece.json').read())==piece
  for line in tf.extractfile(prefix+'events.jsonl'):
   row=json.loads(line);acceptedEvents[(row['unit'],row['process'],row['sequence'])]=hashlib.sha256(json.dumps(row,sort_keys=True).encode()).hexdigest();key=(row['unit'],row['process']);sequences[key]=sequences.get(key,0)+1;assert row['sequence']==sequences[key];pstats['calls']+=1;sites['\n'.join(row['stack'][1:3])]+=1
   for i,arg in enumerate(row['arguments']):
    kinds['null' if arg.get('null') else arg['kind']]+=1;add(pstats,arg);add(positions[i],arg)
    for a in arg.get('accessors',[]):details['accessor:'+str(a['level'])+':'+a['key']]+=1
    for a in arg.get('symbols',[]):details['symbol:'+str(a['level'])+':'+a['key']]+=1
  for line in tf.extractfile(prefix+'shard-evidence.jsonl'):
   row=json.loads(line)
   if row['path']=='report.json':
    assert row['unit'] not in reports;report=json.loads(row['text']);assert report['status']=='pass' and not report['errors'];assert report['counts']==wanted[row['unit']]['expect'];reports[row['unit']]=report;oracle.update(report['counts'])
 assert dict(pstats)==piece['stats'];assert dict(oracle)==piece['oracleCounts'];totals.update(pstats)
assert units==d['completedUnits']==[u['name'] for u in plan['units']];assert len(set(units))==len(reports)==398
for k,n in totals.items():assert d[k]==n
oracle=Counter()
for r in reports.values():oracle.update(r['counts'])
assert dict(oracle)==d['oracleCounts']==plan['counts']
extra=Counter();firstAttempts=[]
for first in d.get('firstAttempts',[]):
 n=first['piece'];archive=out/f'runtime-{n:02d}-first-attempt.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()==(out/f'runtime-{n:02d}-first-attempt.sha256').read_text().split()[0];failed={f['unit'] for f in first['failures']};reused=0;extraCalls=0
 with tarfile.open(archive) as tf:
  prefix=f'runtime-{n:02d}/'
  for line in tf.extractfile(prefix+'SHA256SUMS').read().decode().splitlines():
   digest,name=line.split('  ',1);assert hashlib.sha256(tf.extractfile(prefix+name).read()).hexdigest()==digest
  for line in tf.extractfile(prefix+'events.jsonl'):
   row=json.loads(line);key=(row['unit'],row['process'],row['sequence'])
   if key in acceptedEvents:assert acceptedEvents[key]==hashlib.sha256(json.dumps(row,sort_keys=True).encode()).hexdigest();reused+=1
   else:
    assert row['unit'] in failed;extra['calls']+=1;extraCalls+=1
    for arg in row['arguments']:add(extra,arg)
 firstAttempts.append({'piece':n,'failedUnits':sorted(failed),'reusedCalls':reused,'additionalFailedAttemptCalls':extraCalls,'archiveVerified':True})
allActual={k:totals.get(k,0)+extra.get(k,0) for k in sorted(set(totals)|set(extra))}
result={'complete':True,'unitsExactlyOnce':398,'rawProcessTraces':len(sequences),'counts':dict(totals),'byArgumentPosition':{str(k):dict(v) for k,v in positions.items()},'argumentKinds':dict(kinds),'accessorAndSymbolDetails':dict(details),'oracleCounts':dict(oracle),'maximumPieceSeconds':max(p['seconds'] for p in d['pieces']),'runtimeCallSites':dict(sites),'firstAttempts':firstAttempts,'additionalFailedAttemptCounts':dict(extra),'uniqueCallsAcrossAllAttempts':totals['calls']+extra['calls'],'allActualAttemptCounts':allActual,'uniqueArgumentAppearancesAcrossAllAttempts':allActual['arguments']}
(out/'RUNTIME-RECONCILED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='runtimeCallSites'},indent=2))
