'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');let sequence=0,active=null;const objectPrototypes=new Set([Object.prototype]);const realmPrototype=c=>{if(vm.isContext(c))objectPrototypes.add(Object.getPrototypeOf(vm.runInContext('({})',c)));};
function argument(value,prototype){
 if(value===undefined)return {kind:'undefined'};if(value===null||!['object','function'].includes(typeof value))return {kind:typeof value,null:value===null};
 objectPrototypes.add(prototype);const proto=Object.getPrototypeOf(value),own=Object.getOwnPropertyDescriptors(value),ownKeys=Reflect.ownKeys(own),inheritedEnumerable=[];
 for(const k in value)if(!Object.hasOwn(value,k))inheritedEnumerable.push(k);
 const accessors=[],symbols=[];let level=0;
 for(let at=value;at!==null;at=Object.getPrototypeOf(at),level++)for(const k of Reflect.ownKeys(at)){const d=Object.getOwnPropertyDescriptor(at,k);if(!Object.hasOwn(d,'value'))accessors.push({key:String(k),level,enumerable:d.enumerable});if(typeof k==='symbol')symbols.push({key:String(k),level,enumerable:d.enumerable});}
 return {kind:Array.isArray(value)?'array':typeof value,plain:proto===null||objectPrototypes.has(proto),prototype:proto===null?'null':objectPrototypes.has(proto)?'Object.prototype':'other',ownKeys:ownKeys.map(String),inheritedEnumerable,accessors,symbols};
}
function measure(t,args,prototype){if(!process.env.ASSIGN_DIR)return;const row={sequence:++sequence,role:path.basename(process.argv[1]||''),test:active,arguments:[t,...args].map(v=>argument(v,prototype)),stack:new Error().stack.split('\n').slice(2,7)};fs.appendFileSync(path.join(process.env.ASSIGN_DIR,process.pid+'.jsonl'),JSON.stringify(row)+'\n');}
globalThis.__assignMeasure=measure;
function inject(c){if(c&&typeof c==='object')Object.defineProperty(c,'__assignMeasure',{value:measure,configurable:true});return c;}
const create=vm.createContext;vm.createContext=function(c={},...rest){const result=Reflect.apply(create,this,[inject(c),...rest]);realmPrototype(result);return result;};const run=vm.runInNewContext;vm.runInNewContext=function(code,c={},...rest){try{return Reflect.apply(run,this,[code,inject(c),...rest]);}finally{realmPrototype(c);}};const script=vm.Script.prototype.runInNewContext;vm.Script.prototype.runInNewContext=function(c={},...rest){try{return Reflect.apply(script,this,[inject(c),...rest]);}finally{realmPrototype(c);}};
if(['run.js','_mocha','mocha.js'].includes(path.basename(process.argv[1]||''))){const Mocha=require('/workspace/adamic/stage3/typescript/node_modules/mocha');const run=Mocha.Runnable.prototype.run;Mocha.Runnable.prototype.run=function(...args){active=this.titlePath().filter(Boolean).join(' ');return Reflect.apply(run,this,args);};const emit=Mocha.Runner.prototype.emit;Mocha.Runner.prototype.emit=function(...args){if(args[0]==='test end'||args[0]==='hook end')active=null;return Reflect.apply(emit,this,args);};}
module.exports={argument,measure};
