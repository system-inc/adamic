from pathlib import Path
import json,subprocess,time,hashlib,shutil
s=Path('/workspace/scratch/core-assign');repo=Path('/workspace/adamic');out=repo/'stage3/adapt/99-correctness-core-assign'
# Run after the already scheduled assign-only trials, keeping census CPU bounded.
begin=time.monotonic();last=begin
while True:
 try:
  done=json.loads((s/'TRIALS.json').read_text())
  if len(done)==3:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 if time.monotonic()-begin>3600:raise SystemExit('bounded wait for assign-only trials expired')
 if time.monotonic()-last>50:print('waiting for assign-only trials',flush=True);last=time.monotonic()
 time.sleep(5)
name='generic-own-helper';tree=s/'trials'/name
shutil.copytree(s/'before',tree,ignore=shutil.ignore_patterns('.git','node_modules','tests','built'))
p=tree/'src/compiler/core.ts';before=p.read_bytes();needle=b'hasProperty(map: object, key: string)';assert before.count(needle)==1;after=before.replace(needle,b'hasProperty<T extends object>(map: T, key: string)');p.write_bytes(after);(s/f'trial-{name}.core.ts.txt').write_bytes(after)
sourceBefore={str(p.relative_to(s/'before/src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (s/'before/src').rglob('*') if p.is_file()};sourceAfter={str(p.relative_to(tree/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (tree/'src').rglob('*') if p.is_file()};assert sourceBefore.keys()==sourceAfter.keys();assert [k for k in sourceBefore if sourceBefore[k]!=sourceAfter[k]]==['compiler/core.ts']
with (s/f'{name}-emission.json').open('w') as result,(s/f'{name}-emission.log').open('w') as log:subprocess.run(['node',s/'generic-helper-emission.cjs',tree],stdout=result,stderr=log,check=True,timeout=120)
emission=json.loads((s/f'{name}-emission.json').read_text());roots=sorted((tree/'src/compiler').rglob('*.ts'));assert len(roots)==79;start=time.monotonic()
with (s/f'{name}-types.log').open('w') as log:r=subprocess.run([s/'bin/adamic','types',*roots],stdout=log,stderr=log,timeout=1400)
import re
trial={'name':name,'description':'hasProperty<T extends object>(map: T, key: string)','owner':'40-explicit-any / hasProperty','coreBeforeSha256':hashlib.sha256(before).hexdigest(),'coreAfterSha256':hashlib.sha256(after).hexdigest(),'emission':emission,'types':{'exit':r.returncode,'roots':79,'seconds':time.monotonic()-start,'diagnostics':len(re.findall(r'error TS[0-9]+:',(s/f'{name}-types.log').read_text())),'log':f'{name}-types.log'},'sourceFiles':len(sourceBefore),'changedSources':['compiler/core.ts'],'allCallersUntouched':True,'groups':[]}
(s/'generic-helper-progress.json').write_text(json.dumps(trial,indent=2)+'\n');print('generic helper types',trial['types'],flush=True)
from concurrent.futures import ThreadPoolExecutor,as_completed
def group(start,count):
 begin=time.monotonic();stem=f'{name}-census-{start:02d}'
 with (s/(stem+'.log')).open('w') as log:r=subprocess.run([s/'bin/census',tree/'src/compiler',s/(stem+'.jsonl'),str(start),str(count)],stdout=log,stderr=log,timeout=1400)
 assert r.returncode==0;rows=[json.loads(l) for l in (s/(stem+'.jsonl')).read_text().splitlines()];assert len(rows)==count;return {'start':start,'count':count,'seconds':time.monotonic()-begin,'rows':rows}
with ThreadPoolExecutor(max_workers=2) as pool:
 for f in as_completed([pool.submit(group,start,count) for start,count in [(0,20),(20,20),(40,20),(60,19)]]):
  g=f.result();trial['groups'].append(g);(s/'generic-helper-progress.json').write_text(json.dumps(trial,indent=2)+'\n');print('generic helper census group',g['start'],g['count'],'complete',flush=True)
trial['groups'].sort(key=lambda g:g['start']);(s/'GENERIC-HELPER.json').write_text(json.dumps(trial,indent=2)+'\n');print('GENERIC HELPER COMPLETE',flush=True)
