import json,time,subprocess
from pathlib import Path
s=Path('/workspace/scratch/core-extend')
while True:
 control=s/'whole-control-result.json';rows=s/'paired-replay.json'
 ready=control.exists() and rows.exists() and len(json.loads(rows.read_text()))==84
 active=any(line.strip().split(None,1)[1]=='python3 /workspace/scratch/core-extend/replay.py' for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines()[1:])
 if ready and not active:break
 print('waiting for whole control and complete paired replay before uncontended count',flush=True);time.sleep(20)
assert json.loads(control.read_text())['exit']==0
with (s/'reconcile-replay.log').open('w') as log:subprocess.run(['python3',str(s/'reconcile-replay.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
(s/'count-workers.txt').write_text('4\n')
with (s/'count-pieces.log').open('w') as log:r=subprocess.run(['python3',str(s/'count-pieces.py')],stdout=log,stderr=subprocess.STDOUT)
print('uncontended count exit',r.returncode,flush=True);raise SystemExit(r.returncode)
