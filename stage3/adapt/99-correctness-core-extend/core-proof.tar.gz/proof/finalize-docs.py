import json,shutil
from pathlib import Path
s=Path('/workspace/scratch/core-extend');out=Path('/workspace/adamic/stage3/adapt/99-correctness-core-extend');r=json.loads((s/'count-reconciled.json').read_text());assert r['complete'];assert json.loads((s/'measurement-scope.json').read_text())['pass'];assert not json.loads((s/'complete-count-input-check-after.json').read_text())['differentOutsideInstrumentedOwner']
shutil.copyfile(s/'count-reconciled.json',out/'COUNT.json');shutil.copyfile(s/'runtime-callers.json',out/'RUNTIME-CALLERS.json')
(out/'COUNT.md').write_text('''# Complete lane count on main 698965fe6

One bounded run of the unchanged whole-lane oracle passed in 604.846 seconds.
The normal API, test-count, baseline and failure guards all passed: 106366 passes,
one sanctioned API failure, zero skips. Its complete test-identity multiset and
raw baseline diff match the independently passing uninstrumented whole-lane
control exactly. No timeout or baseline guard was relaxed.

| Owner | Calls | First argument plain | Second argument plain | Counterexamples |
| --- | ---: | ---: | ---: | ---: |
| extend | 10169 | 10169 | 10169 | 0 |
| copyProperties | 490 | 490 | 490 | 0 |

For each argument of each owner: non-plain objects, inherited enumerable strings,
user accessors, own symbol keys, null-prototype objects, arrays and sparse arrays
all have count 0. All invocations returned normally. The observer records throws
as well, preserves exact exception identity, and does not invoke getters.
The standard inherited Object.prototype __proto__ accessor is excluded from the
user-accessor category. Node witnesses agree on all 14 owner/class pairs,
including inherited properties, accessors, symbols and sparse arrays.

| Runtime caller | Calls |
| --- | ---: |
| commandLineParser.ts:3095, extend | 9902 |
| commandLineParser.ts:3101, extend | 0 |
| harness/fourslashImpl.ts:352, extend | 267 |
| watch.ts:873, copyProperties | 408 |
| tsbuildPublic.ts:326, copyProperties | 82 |

Every recorded stack resolves to a listed caller. The unexercised WatchOptions
merge call is covered by byte-identical JavaScript, as are all other inputs.
This is a type-only adaptation: equality follows from exact emitted-code identity,
not from a shadow alternative implementation. There is no JavaScript-changing
road, off-count semantic difference, new cast, caller edit or ledger amendment.

The complete 81504 non-build inputs, including all 80520 fixture files, were
verified before and after counting. The measurement tree differs only by two
wrappers that forward the exact original bodies once and preserve their returns
and exceptions. Full raw records are in lane-count.tar.gz. COUNT.json and
RUNTIME-CALLERS.json are independently reconstructed summaries. Its internal
SHA256SUMS and adjacent SHA-256 cover all retained evidence.

Earlier setup, fixture-copy and contention attempts are explicitly excluded.
Historical f027 data is in historical-f027.tar.gz; current-main contention data
is in core-proof.tar.gz. Accepted totals contain only the passing bounded run.
''')
p=out/'CALLERS.md';t=p.read_text().replace('watch.ts:874','watch.ts:873').replace('tsbuildPublic.ts:327','tsbuildPublic.ts:326');p.write_text(t)
p=out/'PROOF.md';t=p.read_text().replace('| Every-adapter paired replay | Recut in progress; completed earlier-base results are historical only |','| Every-adapter paired replay | Pass, all 85 paired outcomes match apart from this adapter; 14 existing refusals match |').replace('| Unchanged whole stage3/lane/run.sh control | Recut in progress |','| Unchanged whole stage3/lane/run.sh control | Pass, 106366 passes, 1 sanctioned failure, 0 skips |').replace('| Final whole-inventory runtime shape count | In progress, bounded pieces with frozen observer/source/harness |','| Final whole-inventory runtime shape count | Pass, 10169 extend and 490 copyProperties calls; all arguments plain; 0 counterexamples |');a=t.index('The whole control uses');b=t.index('The observer adds',a);t=t[:a]+'''The whole control uses an isolated checkout of exactly the frozen main and
restores the baseline keyed product produced by the first full apply. It runs
the unchanged lane script and all normal API, baseline, count and identity
guards. The accepted count uses one bounded invocation of the unchanged oracle
with those same normal guards. Its complete identity multiset and raw baseline
diff match that control exactly. The source corpus is verified before and after.
See COUNT.md for every argument shape and caller count.

'''+t[b:];t=t.replace('Bulky lane pieces are packed separately before final closeout.','The complete bounded lane count is packed separately in lane-count.tar.gz.');t=t.replace('packed separately before final closeout.','packed in lane-count.tar.gz.');p.write_text(t)
p=out/'README.md';t=p.read_text().replace('Type-only candidate on origin/main\n698965fe6. Runtime shape measurement and complete proof are in progress.','Type-only adaptation on origin/main\n698965fe66aed945d18efa320a594a8a8b4df2f8. All requested proofs pass.');t+='''
Adamic, task b5w3ycg, Nov 7 03:20Z: established-shape adaptations, Compiler accepts.
The full count records 10169 extend and 490 copyProperties calls, all with plain
arguments and no inherited enumerable properties, accessors or symbols. Zero
counterexamples follow from byte-identical JavaScript, also checked by witnesses.
See CALLERS.md, COUNT.md, CENSUS.md and PROOF.md. Both generic bodies remain
uninstantiated in the site meter; this is not a whole-program lowering claim.

Both full applies and all 85 paired replay outcomes pass their required comparison.
All 79-root type checks have zero diagnostics; all nine emitted JavaScript files
and both public declarations are byte-identical. Exactly F6-F11 disappear, no
new core finding appears, and the original-owner mutant restores them all.
''';p.write_text(t)
for p in out.glob('*.log.gz'):p.unlink()
for name in ['contract.json.gz','prior-owner-search.log.gz']:
 p=out/name
 if p.exists():p.unlink()
