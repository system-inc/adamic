import hashlib,tarfile,shutil
from pathlib import Path
s=Path('/workspace/scratch/core-extend');out=Path('/workspace/adamic/stage3/adapt/99-correctness-core-extend');raw=s/'lane-count-evidence';shutil.copytree(s/'full-count',raw,symlinks=True,ignore=shutil.ignore_patterns('adapted-tree'))
for n in ['count-reconciled.json','runtime-callers.json','complete-count-input-check-after.json','verify-count-inputs-after.log','measurement-scope.json']:shutil.copyfile(s/n,raw/n)
(raw/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(raw))+'\n' for p in sorted(raw.rglob('*')) if p.is_file()))
a=out/'lane-count.tar.gz'
with tarfile.open(a,'w:gz') as tar:tar.add(raw,arcname='lane-count')
(out/'lane-count.sha256').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  '+a.name+'\n');print(a.stat().st_size)
