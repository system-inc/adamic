### compiler tests compiler tests for tests/cases/compiler/relationComplexityError.ts "before all" hook for "Correct errors for tests/cases/compiler/relationComplexityError.ts" (timeout)

```text
Timeout of 40000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves.
```

Elapsed: 66344.455 ms; timeout: 40000 ms.

Stack top:     at Hook.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
