### unittests:: tsbuildWatch:: watchMode:: publicAPI:: Public API with custom transformers (timeout)

```text
Timeout of 2000ms exceeded. For async tests and hooks, ensure "done()" is called; if returning a Promise, ensure it resolves.
```

Elapsed: 3251.212 ms; timeout: 2000 ms.

Stack top:     at Test2.Mocha.Runnable.run (/workspace/adamic/stage3/oracle/observe-errors.cjs:11:24)
