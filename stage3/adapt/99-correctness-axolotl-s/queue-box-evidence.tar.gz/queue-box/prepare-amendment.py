import json,pathlib,hashlib
p=pathlib.Path('/workspace/adamic/stage3/adapt/99-correctness-axolotl-s')
source=(p/'adapt.cjs').read_text();pins=json.loads((p/'owners.json').read_text());q=next(x for x in pins if x['owner']=='createQueue')
q['previousAfter']=q['after'];q['previousAfterSha256']=q['ownerAfterSha256']
q['after']=(p/'queue-box-proposed.ts').read_text().split('\n',1)[1].rstrip('\n')
q['after']=q['after'].replace('    let headIndex = 0;\n\n    function isEmpty()', '    let headIndex = 0;\n    function isEmpty()').replace('        }\n\n        const box = elements[headIndex];','        }\n        const box = elements[headIndex];')
assert q['after'].count('\n')==q['previousAfter'].count('\n')
q['ownerAfterSha256']=hashlib.sha256(q['after'].encode()).hexdigest();q['siteEdits']=4
start=source.index('const owners = [');end=source.index('\nconst digest =',start)
source=source[:start]+'const owners = '+json.dumps(pins,indent=2)+';'+source[end:]
start=source.index('        assert([pin.ownerBeforeSha256, pin.ownerAfterSha256].includes(hash)')
end=source.index('\n    return {adapted: states[0], edits};',start)+len('\n    return {adapted: states[0], edits};')
source=source[:start]+'''        const state = hash === pin.ownerBeforeSha256 ? 'before'
            : hash === pin.ownerAfterSha256 ? 'after'
            : pin.previousAfterSha256 && hash === pin.previousAfterSha256 ? 'previous' : undefined;
        assert(state, `${pin.owner}: changed or half-adapted owner`);
        assert.equal(spelling, state === 'before' ? pin.before : state === 'after' ? pin.after : pin.previousAfter, `${pin.owner}: exact text drift`);
        states.push({owner: pin.owner, state});
        if (state !== 'after') edits.push({start, end, after: pin.after});
    }
    const pristine = states.every(row => row.state === 'before');
    const adapted = states.every(row => row.state === 'after');
    const previous = states.every(row => row.state === (row.owner === 'createQueue' ? 'previous' : 'after'));
    assert(pristine || adapted || previous, `${file}: half-adapted file`);
    return {adapted, edits};''' + source[end:]
(p/'adapt.cjs').write_text(source);(p/'owners.json').write_text(json.dumps(pins,indent=2)+'\n')
