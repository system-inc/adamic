import pathlib,subprocess,sys
repo=pathlib.Path('/workspace/adamic');root=pathlib.Path('/workspace/scratch/queue-box');branch='typescript/core-queue-box-checkpoint';ref='refs/heads/'+branch
with (root/'checkpoint-git.log').open('a') as log:
 def git(*args,capture=False):
  r=subprocess.run(['git',*args],cwd=repo,stdout=subprocess.PIPE if capture else log,stderr=log,text=True,check=True)
  return r.stdout.strip() if capture else None
 git('add','stage3/adapt/99-correctness-axolotl-s')
 if subprocess.run(['git','diff','--quiet','--','stage3/upstream/LEDGER.md'],cwd=repo).returncode:git('add','stage3/upstream/LEDGER.md')
 names=git('diff','--cached','--name-only',capture=True).splitlines();assert all(n.startswith('stage3/adapt/99-correctness-axolotl-s/') or n=='stage3/upstream/LEDGER.md' for n in names),names
 old=subprocess.run(['git','rev-parse','--verify',ref],cwd=repo,capture_output=True,text=True)
 parent=old.stdout.strip() if old.returncode==0 else (root/'base.txt').read_text().strip()
 tree=git('write-tree',capture=True);message=root/'checkpoint-message.txt';message.write_text(sys.argv[1]+'\n')
 sha=git('commit-tree',tree,'-p',parent,'-F',str(message),capture=True)
 git('update-ref',ref,sha,parent if old.returncode==0 else '0'*40);git('push','origin',branch)
 (root/'checkpoint-sha.txt').write_text(sha+'\n');print(sha)
