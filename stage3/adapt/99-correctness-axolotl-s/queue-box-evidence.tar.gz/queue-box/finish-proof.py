import hashlib,json,pathlib,subprocess,time
r=pathlib.Path('/workspace/scratch/queue-box');repo=pathlib.Path('/workspace/adamic');p=repo/'stage3/adapt/99-correctness-axolotl-s'
read=lambda name:json.loads((r/name).read_text())
whole=read('count-summary.json');bounded=read('physical-count/count-summary.json');admission=read('admission.json');comparison=read('checks/comparison.json');census=read('census-summary.json');lane=read('after-lane/progress.json');replay=read('replay/replay.json');contract=read('contract-migration.json');pristine=read('contract-pristine.json')
assert whole['counterexamples']==bounded['counterexamples']==0 and whole['operations']==bounded['operations']
assert lane['complete'] and len(lane['completedUnits'])==398 and not any(x['failed'] for x in lane['pieces'])
assert lane['counts']=={'pass':106366,'fail':1,'skip':0}
adapters=sorted(x.name for x in (repo/'stage3/adapt').iterdir() if x.is_dir());assert [x['adapter'] for x in replay]==adapters
for row in replay:
 if row['adapter']!='99-correctness-axolotl-s':assert row['before']==row['after']
 else:
  assert row['before']['exit']==row['after']['exit']==0
  assert json.loads(row['before']['stdout'])=={'files':1,'edits':1,'javascriptChanging':True}
  assert json.loads(row['after']['stdout'])=={'files':0,'edits':0,'javascriptChanging':True}
assert comparison['sourceFiles']==746 and comparison['changed']==['compiler/core.ts']
assert all(x['byteIdentical'] for x in comparison['declarations']) and all(x['onlyCreateQueue'] for x in comparison['emitted'])
assert len(census['removed'])==3 and not census['added'] and census['mutantRestoresAllBeforeSites']
assert read('types-before-result.json')['exit']==read('types-after-result.json')['exit']==0
assert read('types-diagnostics.json')['before']['diagnostics']==read('types-diagnostics.json')['after']['diagnostics']==0
assert hashlib.sha256((p/'adapt.cjs').read_bytes()).hexdigest()==admission['adapterAfter']
assert contract['afterCasts']==0 and contract['measuredAndAppliedJavascriptTokensIdentical'] and contract['isEmptyUnchanged'] and contract['truncationUnchanged']
base=(r/'base.txt').read_text().strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==base
changedJS=[x['name'] for x in comparison['emitted'] if not x['identical']]
results={'base':base,'typescript':'050880ce59e30b356b686bd3144efe24f875ebc8','owner':'createQueue','amends':'99-correctness-axolotl-s','wholeLaneCount':whole['operations'],'boundedLaneCount':bounded['operations'],'counterexamples':0,'boundedUnits':398,'beforeAndAfterApply':read('apply-results.json'),'types':read('types-diagnostics.json'),'sourceFiles':746,'sourceChanges':['compiler/core.ts:createQueue'],'emittedJavascriptFiles':len(comparison['emitted']),'changedJavascript':changedJS,'publicDeclarationsByteIdentical':True,'pairedAdapters':len(adapters),'onlyAmendmentReplayDiffers':True,'pristineContractRefusals':len(pristine['refusals']),'legacyContractRefusals':contract['legacyRefusals'],'castCount':0,'censusRemoved':census['removed'],'newCoreSites':0,'wholeOwnerMutantRestoresThreeSites':True,'actualAdaptedLane':{'units':398,'counts':lane['counts'],'maxPieceSeconds':max(x['seconds'] for x in lane['pieces'])},'genericCoverage':census['genericCoverage'],'allRequestedProofsPass':True}
(p/'queue-box-results.json').write_text(json.dumps(results,indent=2)+'\n');(r/'final-results.json').write_text(json.dumps(results,indent=2)+'\n')
operations=whole['operations'];countRows='\n'.join('| '+label+' | '+format(operations[key],',')+' | 0 |' for label,key in [('createQueue','init'),('enqueue','enqueue'),('dequeue','dequeue'),('Public isEmpty','isEmpty'),('Extra post-operation isEmpty','postOperationIsEmpty')])
proof=f'''# Queue box amendment, wave row 8

Task b5w3ycg. Base: `{base}`. TypeScript 6.0.3 source: `050880ce59e30b356b686bd3144efe24f875ebc8`.
99s pins the entire createQueue owner, including its nested functions. The pin is not narrower than the owner, so this is an amendment to 99s, with no new adaptation directory.

Rule class: JavaScript-changing, count-authorized established shape. Ruling: "Adamic, task b5w3ycg, Nov 7 03:20Z: established-shape adaptations, Compiler accepts". The ledger contains one new entry.

## Representation and owner contract

The buffer starts as an empty array of boxes or undefined slots. for...of pushes a box for each initial value, visiting a sparse hole as undefined. enqueue pushes fresh boxes. dequeue checks occupancy, clears the slot, runs the existing compaction and returns box.value. Payload undefined is valid. No cast or non-null assertion is introduced. isEmpty and the complete copyWithin/splice truncation fragment are byte-identical owner fragments.

Complete pristine, previous accepted and new owner texts and hashes are pinned in adapt.cjs and owners.json. The previous accepted state is recognized only when all other 99s owners are also in their complete accepted state. Changed, mixed and partially adapted owners refuse before writing. The pristine contract catches {len(pristine['refusals'])} fixtures; the migration contract catches {contract['legacyRefusals']} additional legacy fixtures. Legacy migration changes one owner; replay changes zero files, edits or writes and preserves bytes and mtime. LF/CRLF and foreign edits remain covered by the original contract.

Two blank lines are removed inside the new owner to keep every subsequent core.ts coordinate unchanged. The counted candidate and applied owner have identical executable JavaScript tokens; queue-box-contract.cjs verifies this, zero casts, unchanged isEmpty and unchanged truncation.

## Measurement before construction

The full stage3/lane/run.sh control and all 398 normal lane units have identical operation totals and zero counterexamples. The count checkpoint was pushed before adapt.cjs changed; admission.json records both completed gates and the adapter hashes before and after construction.

| Operation | Calls in each run | Differences |
| --- | ---: | ---: |
{countRows}

There are 5888 undefined initial inputs and 37 dense initial arrays; empty and sparse initial arrays each count 0. Own iterator overrides count 0. Dequeued values are 2871 strings and 7252 objects. Every dequeue uses Object.is, preserving reference identity; every enqueue result and public emptiness answer is compared, with additional emptiness comparisons after operations. Original results drive the oracle.

The physical count embeds the shadow in all three emitted copies: _tsc.js, typescript.js and run.js. Every copy has the same original-owner and wrapper hashes. Its missing-recorder check fails visibly; raw records identify all 398 units, including units with zero calls. Each 20-unit piece preserves the ordinary test identity, API, baseline and count guards. The whole lane uses its unchanged default upstream timeout. The bounded runner uses the established 90-second unit wall limit; its largest piece is {max(x['seconds'] for x in read('physical-count/lane-pieces/progress.json')['pieces']):.3f} seconds.

Node witnesses record before and after results for undefined initialization, empty arrays, explicit undefined payloads, sparse arrays, mixed holes, dense strings, dense objects and compaction. The original dequeue-draft-witness.cjs is rerun against the new fill by queue-box-draft-witness.cjs: both rows match stock, including the sparse row. The original rejected map draft and its historical negative witness are retained. The original 99s witness also passes, including immediate consumed-slot clearing.

A payload mutant on the observed dense-string class is caught by the value comparison. A separate changed-iterator input seed also differs and is caught; it is excluded from counts, and the real own-iterator class has count 0. No real-call counterexample was found.

Initial scratch setup failures are retained under embed*.log, lane-pieces-initial and lane-pieces-fixture-missing. They are excluded from admitted counts. The final physical tree restores every nested fixture dependency byte for byte; root build dependencies are kept outside the immutable shard input tree.

## Required proofs

| Check | Result |
| --- | --- |
| Full main apply and main plus amendment apply | Both exit 0 |
| Exact source comparison | All 746 files; only the pinned createQueue owner differs |
| Paired replay of every adapter | {len(adapters)} adapters; only the amendment differs, applying once before and zero times after |
| Adamic types over all 79 sorted roots | Both exit 0; 0 diagnostics; ordinary declaration inventories retained |
| Fresh builds | Main compiler, whole-lane harness and amended compiler/harness exit 0 |
| Emitted JavaScript | All {len(comparison['emitted'])} files checked; only {', '.join(changedJS)} differ, entirely at createQueue |
| Every JavaScript hunk | [QUEUE-BOX-JAVASCRIPT.md](QUEUE-BOX-JAVASCRIPT.md) |
| Public typescript.d.ts and tsserverlibrary.d.ts | Byte-identical in lib and freshly built output |
| Full core.ts site census | {census['beforeFindingEvents']} to {census['afterFindingEvents']} Refused/NotYet events; exactly F15/F16/F17 removed; 0 new sites anywhere in core.ts |
| Whole-owner mutant | Restores the full previous accepted owner, retaining 99s's splice; all three sites return and all before sites match |
| Uninstrumented amended lane | All 398 units pass normal guards; 106366 passes, the same 1 sanctioned API failure, 0 skips |

The census uses the same full guarded tool workflow as core-sites-4186581e: LATENT_FULL=1, LATENT_ONLY_FILE set to the entire core.ts path and LATENT_ASSERT_NO_OUTPUT=1. All three runs have zero checker diagnostics and clean process groups. The raw historical measurement label is retained. createQueue remains deferred with instantiated=false; the measurements establish the three findings' removal. Boundary markers remain in the raw stream and are not counted as Refused/NotYet sites.

## Reproduction and retained proof

Setup follows 99w: source /workspace/adamic-tools/env.sh, bash cloud/setup.sh, npm ci --prefix stage3/api and ADAMIC_TYPESCRIPT_SOURCE set to the source pin. Setup, both fresh applies and all command output are retained as logs.

Step A runs on the frozen base with measurement files only, before editing the built adapter. The whole control uses queue-box-lane-preload.cjs. queue-box-embed.cjs materializes that exact wrapper in a scratch copy of the built control, preserving all fixture folders and emitted line counts. queue-box-physical-preload.cjs supplies its required recorder. queue-box-after-lane.py runs the complete unchanged unit inventory in bounded pieces. queue-box-count.py requires a passing whole lane, complete guarded units, all unit identities represented in the raw count files and zero counterexamples.

Step B runs both full applies, then the original contract.cjs, queue-box-contract.cjs, witness.cjs and the new witness drivers. queue-box-compare.cjs verifies all source, JavaScript and declaration bytes. queue-box-replay.py compares independent full copies. queue-box-census.py runs before, after and restored-owner measurements; queue-box-census-compare.py reconciles every site. The same bounded runner checks the fresh uninstrumented amended build. No lane test, selection or guard is modified.

queue-box-evidence.tar.gz retains raw counts, all per-unit reports and traces, exact source manifests, owner snapshots, every hunk, types inventories, compiler hashes, overlay text and logs. Internal SHA256SUMS and queue-box-evidence.sha256 cover the archive. Every retained Go source is .go.txt. Later evidence files change product keys without changing the frozen transformation; full source comparisons and admission's adapter hash identify the exact measured code.
'''
(p/'QUEUE-BOX-PROOF.md').write_text(proof)
original=subprocess.check_output(['git','show',base+':stage3/adapt/99-correctness-axolotl-s/README.md'],cwd=repo).decode()
intro='''# 99s: boxed queue amendment, wave row 8

Task b5w3ycg. Finished. This amends 99s because its pin covers the entire createQueue owner; no new adaptation directory is created.

Rule class: JavaScript-changing, count-authorized established shape. Adamic, task b5w3ycg, Nov 7 03:20Z: established-shape adaptations, Compiler accepts.

The buffer holds boxes or cleared slots. for...of boxes sparse holes as undefined payloads. enqueue boxes each payload; dequeue checks box occupancy, clears the slot and returns box.value without a cast. isEmpty and 99s's splice truncation are unchanged. Explicit undefined remains a valid payload.

The whole lane and all 398 bounded units each compare 10041 enqueues, 10123 dequeues and 13660 public isEmpty calls, plus 20164 post-operation emptiness comparisons, with zero differences. Sparse initial arrays and own iterator overrides each count zero. Node sparse and undefined-payload witnesses match stock. A deliberately changed iterator detector seed differs outside the observed own-iterator class, whose real count is zero.

Both full applies, paired replay of every adapter, all 79 roots of adamic types, both public declaration comparisons, owner-only JavaScript checks and the uninstrumented complete lane pass. The full core.ts census removes exactly F15/F16/F17, adds no site and restores all three under the whole-owner mutant. Generic body coverage remains deferred.

See [QUEUE-BOX-PROOF.md](QUEUE-BOX-PROOF.md), [the count table](queue-box-count-table.json), [all hunks](QUEUE-BOX-JAVASCRIPT.md) and [structured results](queue-box-results.json). Raw evidence is packed with SHA-256 manifests. The original record below is historical, including its rejected map-based draft.

'''
(p/'README.md').write_text(intro+original.replace('# 99s: truthful skipWhile and array truncation','## Original 99s record (historical)',1))
(r/'checkpoint-status.json').write_text(json.dumps({'epoch':time.time(),'allRequestedProofsPass':True,'builtAdapterChanged':True,'beforeApply':0,'afterApply':0},indent=2)+'\n')
print(json.dumps({'pairedAdapters':len(adapters),'changedJS':changedJS,'allRequestedProofsPass':True}))
