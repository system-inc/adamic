### projects tests Compiling project for Verify that JavaScript modules are not resolved if too many hops: testcase tests/cases/project/nodeModulesMaxDepthExceeded.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/nodeModulesMaxDepthExceeded.json (baseline-missing)

```text
New baseline created at tests/baselines/local/project/nodeModulesMaxDepthExceeded/node/nodeModulesMaxDepthExceeded.json
```

Elapsed: 2012.039 ms; timeout: 40000 ms.

Stack top:     at writeComparison (src/harness/harnessIO.ts:1490:27)

### projects tests Compiling project for Verify that JavaScript modules are not resolved if too many hops: testcase tests/cases/project/nodeModulesMaxDepthExceeded.json (@module: commonjs) Correct errors for tests/cases/project/nodeModulesMaxDepthExceeded.json (baseline-content)

```text
New baseline created at tests/baselines/local/project/nodeModulesMaxDepthExceeded/node/nodeModulesMaxDepthExceeded.errors.txt
```

Elapsed: 3.458 ms; timeout: 40000 ms.

Stack top:     at writeComparison (src/harness/harnessIO.ts:1490:27)

project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt (first 40 lines)

```diff
--- reference/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt
+++ local/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt
@@ -1,8 +1,7 @@
 maxDepthExceeded/tsconfig.json(2,3): error TS5107: Option 'module=AMD' is deprecated and will stop functioning in TypeScript 7.0. Specify compilerOption '"ignoreDeprecations": "6.0"' to silence this error.
 maxDepthExceeded/tsconfig.json(2,3): error TS5107: Option 'moduleResolution=node10' is deprecated and will stop functioning in TypeScript 7.0. Specify compilerOption '"ignoreDeprecations": "6.0"' to silence this error.
   Visit https://aka.ms/ts6 for migration information.
-maxDepthExceeded/root.ts(3,1): error TS2322: Type 'string' is not assignable to type 'number'.
-maxDepthExceeded/root.ts(4,4): error TS2540: Cannot assign to 'rel' because it is a read-only property.
+maxDepthExceeded/root.ts(1,21): error TS2307: Cannot find module 'm1' or its corresponding type declarations.
 
 
 ==== maxDepthExceeded/tsconfig.json (2 errors) ====
@@ -21,42 +20,13 @@
       "exclude": ["node_modules/m2/**/*"]
     }
     
-==== index.js (0 errors) ====
-    var m2 = require('m2');
-    var rel = require('./relative');
-    
-    /**
-     * @param {string} p1 The first param
-     */
-    exports.f1 = function(p1) {
-    	return 42;
-    };
-    
-    exports.f2 = m2;
-    
-    exports.rel = rel.relativeProp;
-    
-==== maxDepthExceeded/root.ts (2 errors) ====
+==== maxDepthExceeded/root.ts (1 errors) ====
     import * as m1 from "m1";
+                        ~~~~
+!!! error TS2307: Cannot find module 'm1' or its corresponding type declarations.
     m1.f1("test");
     m1.f2.a = "10"; // Error: Should be number
-    ~~~~~~~
-!!! error TS2322: Type 'string' is not assignable to type 'number'.

```

### projects tests Compiling project for Verify that JavaScript modules are not resolved if too many hops: testcase tests/cases/project/nodeModulesMaxDepthExceeded.json (@module: amd) Correct module resolution tracing for tests/cases/project/nodeModulesMaxDepthExceeded.json (baseline-missing)

```text
New baseline created at tests/baselines/local/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.json
```

Elapsed: 2.197 ms; timeout: 40000 ms.

Stack top:     at writeComparison (src/harness/harnessIO.ts:1490:27)

### projects tests Compiling project for Verify that JavaScript modules are not resolved if too many hops: testcase tests/cases/project/nodeModulesMaxDepthExceeded.json (@module: amd) Correct errors for tests/cases/project/nodeModulesMaxDepthExceeded.json (baseline-content)

```text
New baseline created at tests/baselines/local/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt
```

Elapsed: 1.652 ms; timeout: 40000 ms.

Stack top:     at writeComparison (src/harness/harnessIO.ts:1490:27)

project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt (first 40 lines)

```diff
--- reference/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt
+++ local/project/nodeModulesMaxDepthExceeded/amd/nodeModulesMaxDepthExceeded.errors.txt
@@ -1,8 +1,7 @@
 maxDepthExceeded/tsconfig.json(2,3): error TS5107: Option 'module=AMD' is deprecated and will stop functioning in TypeScript 7.0. Specify compilerOption '"ignoreDeprecations": "6.0"' to silence this error.
 maxDepthExceeded/tsconfig.json(2,3): error TS5107: Option 'moduleResolution=node10' is deprecated and will stop functioning in TypeScript 7.0. Specify compilerOption '"ignoreDeprecations": "6.0"' to silence this error.
   Visit https://aka.ms/ts6 for migration information.
-maxDepthExceeded/root.ts(3,1): error TS2322: Type 'string' is not assignable to type 'number'.
-maxDepthExceeded/root.ts(4,4): error TS2540: Cannot assign to 'rel' because it is a read-only property.
+maxDepthExceeded/root.ts(1,21): error TS2307: Cannot find module 'm1' or its corresponding type declarations.
 
 
 ==== maxDepthExceeded/tsconfig.json (2 errors) ====
@@ -21,42 +20,13 @@
       "exclude": ["node_modules/m2/**/*"]
     }
     
-==== index.js (0 errors) ====
-    var m2 = require('m2');
-    var rel = require('./relative');
-    
-    /**
-     * @param {string} p1 The first param
-     */
-    exports.f1 = function(p1) {
-    	return 42;
-    };
-    
-    exports.f2 = m2;
-    
-    exports.rel = rel.relativeProp;
-    
-==== maxDepthExceeded/root.ts (2 errors) ====
+==== maxDepthExceeded/root.ts (1 errors) ====
     import * as m1 from "m1";
+                        ~~~~
+!!! error TS2307: Cannot find module 'm1' or its corresponding type declarations.
     m1.f1("test");
     m1.f2.a = "10"; // Error: Should be number
-    ~~~~~~~
-!!! error TS2322: Type 'string' is not assignable to type 'number'.

```
