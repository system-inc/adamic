export function clear<T>(array: T[]): void {
    array.splice(0);
}
const values: number[] = [1, 2, 3];
const alias = values;
clear(values);
console.log(`${values.length}:${alias.length}`);
values.push(4);
console.log(`${values.length}:${values[0]!}`);
clear(values);
console.log(`${values.length}`);
