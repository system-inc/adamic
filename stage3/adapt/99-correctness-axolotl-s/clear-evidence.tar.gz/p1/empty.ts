export function clear<T>(array: T[]): void {
    array.splice(0);
}
const values: number[] = [];
clear(values);
console.log(`${values.length}`);
clear(values);
console.log(`${values.length}`);
