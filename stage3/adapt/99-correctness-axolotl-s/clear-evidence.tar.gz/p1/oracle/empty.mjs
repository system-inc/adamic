export function clear(array) {
    array.splice(0);
}
const values = [];
clear(values);
console.log(`${values.length}`);
clear(values);
console.log(`${values.length}`);
