export function clear(array) {
    array.splice(0);
}
class Item {
    value;
    constructor(value) { this.value = value; }
}
function exercise() {
    const values = [new Item(1), new Item(2), new Item(3)];
    const alias = values;
    clear(values);
    console.log(`${values.length}:${alias.length}`);
    values.push(new Item(4));
    console.log(`${values.length}:${values[0].value}`);
    clear(values);
    console.log(`${values.length}`);
}
exercise();
