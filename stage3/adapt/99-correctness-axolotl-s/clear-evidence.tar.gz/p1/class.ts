export function clear<T>(array: T[]): void {
    array.splice(0);
}
class Item { value: number; constructor(value: number) { this.value = value; } }
function exercise(): void {
    const values: Item[] = [new Item(1), new Item(2), new Item(3)];
    const alias = values;
    clear(values);
    console.log(`${values.length}:${alias.length}`);
    values.push(new Item(4));
    console.log(`${values.length}:${values[0]!.value}`);
    clear(values);
    console.log(`${values.length}`);
}
exercise();
