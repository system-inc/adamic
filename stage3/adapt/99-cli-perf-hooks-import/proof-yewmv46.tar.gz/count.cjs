'use strict';
const fs=require('node:fs'),path=require('node:path'),ts=require('typescript'),assert=require('node:assert/strict');
const tree=process.argv[2], files=ts.sys.readDirectory(path.join(tree,'src'),['.ts'],['**/lib/**','**/node_modules/**']);
const opts={target:ts.ScriptTarget.ES2024,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,strict:true,noUncheckedIndexedAccess:true,exactOptionalPropertyTypes:true,verbatimModuleSyntax:true,noEmit:true,skipLibCheck:true,types:['node'],typeRoots:['/workspace/adamic/stage3/api/node_modules/@types']};
const host={getScriptFileNames:()=>files,getScriptVersion:()=> '0',getScriptSnapshot:f=>{try{return ts.ScriptSnapshot.fromString(fs.readFileSync(f,'utf8'));}catch{return undefined;}},getCurrentDirectory:()=>tree,getCompilationSettings:()=>opts,getDefaultLibFileName:o=>ts.getDefaultLibFilePath(o),fileExists:ts.sys.fileExists,readFile:ts.sys.readFile,readDirectory:ts.sys.readDirectory,directoryExists:ts.sys.directoryExists,getDirectories:ts.sys.getDirectories,realpath:ts.sys.realpath,useCaseSensitiveFileNames:()=>true};
const ls=ts.createLanguageService(host),program=ls.getProgram(),checker=program.getTypeChecker(),file=program.getSourceFile(path.join(tree,'src/compiler/performanceCore.ts'));
const iface=file.statements.find(n=>ts.isInterfaceDeclaration(n)&&n.name.text==='PerformanceTime'),target=checker.getTypeAtLocation(iface),member=iface.members.find(n=>n.name?.getText(file)==='timeOrigin');
const seeds=new Map(),typed=[],providers=[],named=[],mutators=[],compatibleMemberAccesses=[];
function at(n){const s=n.getSourceFile(),p=s.getLineAndCharacterOfPosition(n.getStart(s));return {file:path.relative(tree,s.fileName),line:p.line+1,column:p.character+1,text:n.getText(s)};}
function addSeed(decl){if(decl.name){const s=decl.getSourceFile();seeds.set(s.fileName+':'+decl.name.getStart(s),{file:s.fileName,position:decl.name.getStart(s),...at(decl)});}}
addSeed(member);
for(const s of program.getSourceFiles()){
 if(!s.fileName.startsWith(tree+'/src/'))continue;
 function visit(n){
  if((ts.isIdentifier(n)||ts.isStringLiteral(n))&&n.text==='timeOrigin')named.push(at(n));
  if(ts.isExpression(n)||ts.isInterfaceDeclaration(n)||ts.isClassDeclaration(n)||ts.isTypeAliasDeclaration(n)){
   let t=checker.getTypeAtLocation(n),p=t.getProperty('timeOrigin');
   if(p&&!(t.flags&ts.TypeFlags.Any)&&checker.isTypeAssignableTo(t,target)){
    for(const d of p.declarations||[])addSeed(d);
    if(ts.isInterfaceDeclaration(n)||ts.isClassDeclaration(n)||ts.isTypeAliasDeclaration(n))typed.push(at(n));
    if(ts.isObjectLiteralExpression(n)||ts.isClassExpression(n)||ts.isClassDeclaration(n))providers.push({...at(n),timeOrigin:p.declarations?.map(at)});
   }
  }
  if(ts.isPropertyAccessExpression(n)||ts.isElementAccessExpression(n)){
   const receiver=checker.getTypeAtLocation(n.expression);
   if(!(receiver.flags&ts.TypeFlags.Any)&&receiver.getProperty('timeOrigin')&&checker.isTypeAssignableTo(receiver,target)){
    const parent=n.parent;
    const write=ts.isBinaryExpression(parent)&&parent.left===n&&parent.operatorToken.kind>=ts.SyntaxKind.FirstAssignment&&parent.operatorToken.kind<=ts.SyntaxKind.LastAssignment || (ts.isPrefixUnaryExpression(parent)||ts.isPostfixUnaryExpression(parent))&&[ts.SyntaxKind.PlusPlusToken,ts.SyntaxKind.MinusMinusToken].includes(parent.operator);
    compatibleMemberAccesses.push({...at(n),write:!!write});
   }
  }
  if(ts.isCallExpression(n)&&['Object.defineProperty','Reflect.defineProperty','Reflect.set','Object.assign'].includes(n.expression.getText(s)))mutators.push(at(n));
  ts.forEachChild(n,visit);
 }visit(s);
}
const refs=new Map();
for(const seed of seeds.values())for(const group of ls.findReferences(seed.file,seed.position)||[])for(const r of group.references){if(!r.fileName.startsWith(tree+'/src/'))continue;const s=program.getSourceFile(r.fileName),pos=s.getLineAndCharacterOfPosition(r.textSpan.start);refs.set(r.fileName+':'+r.textSpan.start,{file:path.relative(tree,r.fileName),line:pos.line+1,column:pos.character+1,text:s.text.slice(r.textSpan.start,r.textSpan.start+r.textSpan.length),isWriteAccess:r.isWriteAccess,isDefinition:r.isDefinition||false});}
// Declaration/initialization entries are providers, rather than subsequent writes.
const references=[...refs.values()],writes=references.filter(r=>r.isWriteAccess&&!r.isDefinition),reads=references.filter(r=>!r.isWriteAccess&&!r.isDefinition);
assert.equal(writes.length,0,JSON.stringify(writes));
const report={typescript:ts.version,roots:files.length,loadedSourceFiles:program.getSourceFiles().length,scope:'All src roots, including harness/testRunner; all tests separately scanned for every timeOrigin/PerformanceTime spelling',referenceSeeds:[...seeds.values()],compatibleDeclaredTypes:typed,objectLiteralOrClassProviders:providers,allNamedSites:named,compatibleMemberAccesses,references,reads,writes,writeCount:writes.length,mutatorCandidates:mutators};
console.log(JSON.stringify(report,null,2));
