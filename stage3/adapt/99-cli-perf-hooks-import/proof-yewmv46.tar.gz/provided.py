from pathlib import Path
import json,subprocess,os,time,hashlib
s=Path('/workspace/scratch/yewmv46');r=Path('/workspace/adamic')
while not (s/'build-census-provided-result.json').exists():time.sleep(2)
assert json.loads((s/'build-census-provided-result.json').read_text())['exit']==0
for side in ['without','after','mutant']:
 tree=s/side;source=tree/'src/compiler/performanceCore.ts';before=hashlib.sha256(source.read_bytes()).hexdigest();env=dict(os.environ,GOMAXPROCS='2',GOMEMLIMIT='5GiB',LATENT_FULL='1',LATENT_ONLY_FILE=str(source),LATENT_ASSERT_NO_OUTPUT='1',LATENT_TIMES=str(s/('census-provided-'+side+'-times.jsonl')),LATENT_YEWMV46_PROVIDED='1')
 result=subprocess.run(['python3',str(s/'run.py'),'census-provided-'+side,str(s/'census-provided'),str(tree/'src/compiler'),str(s/('census-provided-'+side+'.jsonl'))],cwd=r,env=env);assert result.returncode==0
 assert before==hashlib.sha256(source.read_bytes()).hexdigest()
text=(s/'analyze-census.py').read_text().replace("'census-'+side","'census-provided-'+side").replace("'census-mutant-result.json'","'census-provided-mutant-result.json'").replace("'timeOrigin' in f['reason'] and 'writable' in f['reason']","'timeOrigin' in f['reason'] and 'is writable where its model export' in f['reason'] and f['kind']=='NotYet'").replace("'census-summary.json'","'census-provided-summary.json'").replace("'hostTable':'ordinary pending rows'","'hostTable':'exact routedPerformanceRows fixture from cd42fd21 host_binding_route_test.go'")
(s/'analyze-provided.py').write_text(text)
result=subprocess.run(['python3',str(s/'run.py'),'census-provided-analysis','python3',str(s/'analyze-provided.py')],cwd=r,env=os.environ);assert result.returncode==0
