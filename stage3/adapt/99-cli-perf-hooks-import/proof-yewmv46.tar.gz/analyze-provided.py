import json,time
from pathlib import Path
s=Path('/workspace/scratch/yewmv46')
while not (s/'census-provided-mutant-result.json').exists():time.sleep(2)
rows={};sets={};targets={}
for side in ['without','after','mutant']:
 assert json.loads((s/('census-provided-'+side+'-result.json')).read_text())['exit']==0
 data=[json.loads(line) for line in (s/('census-provided-'+side+'.jsonl')).read_text().splitlines()];header=data[0];files=data[1:];assert header['latent_mode']=='full' and not header['checker_rejected'],header
 assert len(files)==1,len(files);row=files[0];rows[side]=row
 def norm(value):return value.replace(str(s/side),'TREE') if isinstance(value,str) else value
 sets[side]={tuple(norm(f.get(k,'')) for k in ['unit','phase','kind','where','reason']) for f in row['findings']}
 targets[side]=[f for f in row['findings'] if 'timeOrigin' in f['reason'] and 'is writable where its model export' in f['reason'] and f['kind']=='NotYet']
assert targets['without'] and targets['mutant'] and not targets['after'],targets
assert sets['after']<=sets['without'],sets['after']-sets['without']
assert sets['mutant']==sets['without']
report={'compiler':'cd42fd2126b63e1647f6ee2e6c3dd2c87bdda2fe','mode':'LATENT_FULL=1','hostTable':'exact routedPerformanceRows fixture from cd42fd21 host_binding_route_test.go','selectedFile':'src/compiler/performanceCore.ts','all79RootsCheckerClean':True,'counts':{side:{'units':len(row['units']),'findings':len(row['findings'])} for side,row in rows.items()},'withoutReadonlyStops':targets['without'],'afterReadonlyStops':targets['after'],'mutantStops':targets['mutant'],'noNewFindings':True,'removedRows':[list(x) for x in sorted(sets['without']-sets['after'])],'mutantRestoresExactFindingSet':True}
(s/'census-provided-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
