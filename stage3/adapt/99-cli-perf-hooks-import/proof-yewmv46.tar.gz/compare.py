import json,hashlib,difflib,time
from pathlib import Path
s=Path('/workspace/scratch/yewmv46')
while not (s/'build-after-result.json').exists():time.sleep(2)
assert json.loads((s/'build-after-result.json').read_text())['exit']==0
names=['_tsc.js','_tsserver.js','_typingsInstaller.js','tsc.js','tsserver.js','tsserverlibrary.js','typescript.js','typingsInstaller.js','watchGuard.js']
rows=[]
for name in names+['typescript.d.ts','tsserverlibrary.d.ts','typescript.internal.d.ts']:
 a=(s/'without/built/local'/name).read_bytes();b=(s/'after/built/local'/name).read_bytes()
 row={'name':name,'beforeSha256':hashlib.sha256(a).hexdigest(),'afterSha256':hashlib.sha256(b).hexdigest(),'identical':a==b}
 if name in ['typescript.d.ts','tsserverlibrary.d.ts']:
  row['PerformanceTimePublic']=b'PerformanceTime' in b
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='without/'+name,tofile='after/'+name))
  (s/(name+'.diff')).write_text(diff)
  assert a==b, 'PUBLIC_DIFF_STOP: '+name
  assert not row['PerformanceTimePublic'],name+' exposes PerformanceTime'
 elif name.endswith('.js'):assert a==b,name+' emitted JavaScript changed'
 else:
  diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='without/'+name,tofile='after/'+name));(s/(name+'.diff')).write_text(diff)
  assert a.replace(b'    timeOrigin: number;',b'    readonly timeOrigin: number;')==b,'internal declaration changes outside readonly'
  row['changedLines']=[{'line':i,'text':line} for i,line in enumerate(b.decode().splitlines(),1) if 'timeOrigin' in line or 'interface PerformanceTime' in line]
 rows.append(row)
(s/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n');print('nine JS byte-identical, public declarations byte-identical; internal readonly-only',flush=True)
