import subprocess,os,signal,time,json,sys
from pathlib import Path
root=Path('/workspace/scratch/yewmv46');name=sys.argv[1];args=sys.argv[2:];log=root/(name+'.log');begin=time.monotonic();reason=None
with log.open('w') as out:
 p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while p.poll() is None:
   if time.time()-log.stat().st_mtime>1800: reason='30-minute output idle cap';break
   if time.monotonic()-begin>5400: reason='90-minute wall cap';break
   time.sleep(1)
 finally:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
  p.wait()
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
result={'args':args,'exit':p.returncode,'seconds':round(time.monotonic()-begin,3),'reason':reason,'processGroupCleaned':True}
(root/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,'child_exit='+str(p.returncode),flush=True);sys.exit(p.returncode if p.returncode>=0 else 128-p.returncode)
