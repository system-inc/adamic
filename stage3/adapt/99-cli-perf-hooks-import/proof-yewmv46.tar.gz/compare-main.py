import json,time,hashlib
from pathlib import Path
s=Path('/workspace/scratch/yewmv46')
while not (s/'build-main-result.json').exists():time.sleep(2)
assert json.loads((s/'build-main-result.json').read_text())['exit']==0
rows=[]
for row in json.loads((s/'comparison.json').read_text()):
 name=row['name'];a=(s/'main-tree/built/local'/name).read_bytes();b=(s/'after/built/local'/name).read_bytes();assert a==b,name
 rows.append({'name':name,'identical':True,'sha256':hashlib.sha256(a).hexdigest()})
(s/'baseline-comparison.json').write_text(json.dumps({'base':'cd42fd21','allNineJavascriptFilesIdentical':True,'publicDeclarationsIdentical':True,'internalDeclarationsIdentical':True,'rows':rows},indent=2)+'\n');print('Actual baseline: all nine JS and all three declarations byte-identical')
