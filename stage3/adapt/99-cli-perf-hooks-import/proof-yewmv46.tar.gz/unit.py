import os,subprocess,json,re,time
from pathlib import Path
s=Path('/workspace/scratch/yewmv46');r=Path('/workspace/adamic');name='TestPerformanceTimeYewmv46AdaptedProductMatchesLowerPin'
env=dict(os.environ,ADAMIC_TYPESCRIPT_SOURCE=str(s/'upstream'),ADAMIC_BUILD_CACHE_DIR=str(s/'product-cache'),GOMAXPROCS='2',GOMEMLIMIT='5GiB',NODE_DISABLE_COMPILE_CACHE='1')
def run(label,args,cwd,mode):
 c=subprocess.run(['python3',str(s/'run.py'),label,*map(str,args)],cwd=cwd,env=dict(env,ADAMIC_BUILD_CACHE=mode));return c.returncode
assert run('product-build',[s/'adaptedtree.test','-test.run=^TestProduct_Stage3AdaptedTree$','-test.v','-test.timeout=25m'],r/'stage3/lane/adaptedtree','')==0
args=[s/'lane.test','-test.run=^'+name+'$','-test.v','-test.timeout=30s']
assert run('unit-green',['strace','-f','-e','trace=process','-o',s/'unit-execs.log',*args],r/'stage3/lane','read')==0
execs=(s/'unit-execs.log').read_text();execPaths=re.findall(r'execve\("([^"]+)"',execs);forbidden=[exe for exe in execPaths if Path(exe).name in ['go','compile','link','adamic','tsc']];forbidden += [line for line in execs.splitlines() if 'execve(' in line and any(word in line for word in ['/tsc.js', '/hereby', '/esbuild'])];assert not forbidden,forbidden
log=(s/'unit-green.log').read_text();m=re.search(r'adapted tree: (.+)',log);assert m,log;tree=Path(m.group(1));pin=r/'internal/lower/testdata/host_binding/performance_core_adapted.txt';source=tree/'src/compiler/performanceCore.ts';originalPin=pin.read_bytes();originalSource=source.read_bytes();rows=[]
for label,target,before,after in [('pin-byte',pin,originalPin,originalPin.replace(b'PerformanceTime',b'QerformanceTime',1)),('readonly-undone',source,originalSource,originalSource.replace(b'readonly timeOrigin: number;',b'timeOrigin: number;',1)),('single-space',source,originalSource,originalSource.replace(b'    now(): number;',b'   now(): number;',1))]:
 assert before!=after
 try:
  target.write_bytes(after);code=run('unit-mutant-'+label,args,r/'stage3/lane','read');output=(s/('unit-mutant-'+label+'.log')).read_text();assert code==1,(label,code,output);assert 'disagree with Lower\'s pin' in output,output;rows.append({'mutant':label,'exit':code,'test':name,'equalityMismatch':True})
 finally:target.write_bytes(before)
assert pin.read_bytes()==originalPin and source.read_bytes()==originalSource
assert run('unit-restored',args,r/'stage3/lane','read')==0
report={'test':name,'product':str(tree),'productBuildOutsideUnit':True,'unitProductMode':'read','unitTimeout':'30s','noGoOrCompilerSubprocess':True,'execPaths':execPaths,'mutants':rows,'restoredGreen':True}
(s/'unit-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
