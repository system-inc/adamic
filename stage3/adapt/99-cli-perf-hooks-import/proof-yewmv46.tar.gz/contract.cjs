'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict');
const repo='/workspace/adamic',root='/workspace/scratch/yewmv46',tree=root+'/after',name='src/compiler/performanceCore.ts',adapter=require(repo+'/stage3/adapt/99-cli-perf-hooks-import/adapt.cjs');
const before=cp.execFileSync('git',['-C',tree,'show','refs/stage3/99-cli-perf-hooks-import-before:'+name],{encoding:'utf8'}),after=fs.readFileSync(tree+'/'+name,'utf8'),pin=require(repo+'/stage3/adapt/99-cli-perf-hooks-import/owners.json')[0];
const file=tree+'/'+name,write=fs.writeFileSync;const result={};
try{
 write(file,before);result.first=adapter.adapt(tree,require('typescript'));assert.equal(fs.readFileSync(file,'utf8'),after);
 const stamp=fs.statSync(file,{bigint:true}).mtimeNs;let writes=0;fs.writeFileSync=(...a)=>{writes++;return write(...a);};result.second=adapter.adapt(tree,require('typescript'));fs.writeFileSync=write;assert.equal(writes,0);assert.equal(fs.statSync(file,{bigint:true}).mtimeNs,stamp);result.noWriteIdempotence=true;
 result.refusals=[];
 for(const [label,text]of [['drifted-before',before.replace('now(): number;','now(): string;')],['drifted-after',after.replace('now(): number;','now(): string;')],['half-applied',after.replace(pin.after,pin.before)],['before-readonly-only',before.replace(pin.before,pin.after)],['owner-space',after.replace('now(): number;','now():  number;')]]){
  write(file,text);writes=0;fs.writeFileSync=(...a)=>{writes++;return write(...a);};let message;try{adapter.adapt(tree,require('typescript'));}catch(e){message=e.message;}finally{fs.writeFileSync=write;}assert(message,label);assert.equal(writes,0);assert.equal(fs.readFileSync(file,'utf8'),text);result.refusals.push({label,message,noWrites:true});
 }
 const unrelated=after+'\r\nfunction unrelatedYewmv46() { return 1; }\r\n';write(file,unrelated);result.unrelated=adapter.adapt(tree,require('typescript'));assert.equal(fs.readFileSync(file,'utf8'),unrelated);assert.equal(result.unrelated.files,0);
}finally{fs.writeFileSync=write;write(file,after);}
console.log(JSON.stringify(result,null,2));
