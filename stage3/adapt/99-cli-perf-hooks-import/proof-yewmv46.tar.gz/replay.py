import os,subprocess,json,shutil,hashlib
from pathlib import Path
r=Path('/workspace/adamic');s=Path('/workspace/scratch/yewmv46');env=dict(os.environ,NODE_PATH=str(r/'stage3/api/node_modules'))
for side,source in [('main',s/'main-tree'),('after',s/'after')]:
 dest=s/('replay-'+side);
 if dest.exists():shutil.rmtree(dest)
 shutil.copytree(source/'src',dest/'src');shutil.copy2(source/'package.json',dest/'package.json');shutil.copytree(source/'scripts',dest/'scripts');(dest/'node_modules').symlink_to(r/'stage3/typescript/node_modules',target_is_directory=True)
rows=[]
for directory in sorted(p for p in (r/'stage3/adapt').iterdir() if p.is_dir()):
 row={'adapter':directory.name}
 for side,code in [('main',s/'base'),('after',r)]:
  tree=s/('replay-'+side)
  child=subprocess.run(['node',str(code/'stage3/adapt'/directory.name/'adapt.cjs'),str(tree)],env=env,capture_output=True,text=True,timeout=1200)
  row[side]={'exit':child.returncode,'stdout':child.stdout.replace(str(tree),'TREE').replace(str(code),'REPO'),'stderr':child.stderr.replace(str(tree),'TREE').replace(str(code),'REPO')}
 assert row['main']==row['after'],row
 rows.append(row);(s/'replay.json').write_text(json.dumps(rows,indent=2)+'\n');print(directory.name,'child_exit='+str(child.returncode),flush=True)
manifest=lambda tree:{str(p.relative_to(tree/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
a=manifest(s/'replay-main');b=manifest(s/'replay-after');assert [n for n in a if a[n]!=b[n]]==['compiler/performanceCore.ts']
x=(s/'replay-main/src/compiler/performanceCore.ts').read_bytes();y=(s/'replay-after/src/compiler/performanceCore.ts').read_bytes();assert x.replace(b'import * as perfHooks from "node:perf_hooks";\r\n\r\n',b'import * as perfHooks from "node:perf_hooks";\r\n')==y
(s/'replay-summary.json').write_text(json.dumps({'adapters':len(rows),'allOutcomesIdentical':True,'finalSourceOnlyOwnImportSeparatorDiffers':True,'nonzeroPairedAdapters':[row['adapter'] for row in rows if row['main']['exit']]},indent=2)+'\n')
