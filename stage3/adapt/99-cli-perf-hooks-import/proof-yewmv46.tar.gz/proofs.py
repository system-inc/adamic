import os,subprocess,time,json,shutil,hashlib
from pathlib import Path
s=Path('/workspace/scratch/yewmv46');r=Path('/workspace/adamic');env=dict(os.environ,NODE_PATH=str(r/'stage3/api/node_modules'),GOMAXPROCS='2',GOMEMLIMIT='5GiB',NODE_DISABLE_COMPILE_CACHE='1')
def wait(name):
 while not (s/(name+'-result.json')).exists():time.sleep(2)
 result=json.loads((s/(name+'-result.json')).read_text());assert result['exit']==0,(name,result)
def run(name,args,cwd=r,extra={}):
 c=subprocess.run(['python3',str(s/'run.py'),name,*map(str,args)],cwd=cwd,env=dict(env,**extra));assert c.returncode==0,(name,c.returncode)
wait('apply-main');wait('apply-after')
def manifest(tree):return {str(p.relative_to(tree/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((tree/'src').rglob('*')) if p.is_file()}
a=manifest(s/'main-tree');b=manifest(s/'after');changed=[name for name in a if a[name]!=b[name]];assert changed==['compiler/performanceCore.ts'],changed
old=(s/'main-tree/src/compiler/performanceCore.ts').read_bytes();now=(s/'after/src/compiler/performanceCore.ts').read_bytes();assert old.replace(b'import * as perfHooks from "node:perf_hooks";\r\n\r\n',b'import * as perfHooks from "node:perf_hooks";\r\n')==now
(s/'apply-comparison.json').write_text(json.dumps({'files':len(a),'changedFiles':changed,'onlyConsumedImportBlankLine':True,'baseline':'cd42fd21','amendment':'whole-owner pins; existing readonly output preserved'},indent=2)+'\n');print('Both full applies exited 0; only import separator line differs',flush=True)
for side in ['without','mutant']:
 dest=s/side;shutil.copytree(s/'after',dest,symlinks=True,ignore=shutil.ignore_patterns('.git','built','node_modules'))
 p=dest/'src/compiler/performanceCore.ts';raw=p.read_bytes();assert raw.count(b'readonly timeOrigin: number;')==1;p.write_bytes(raw.replace(b'readonly timeOrigin: number;',b'timeOrigin: number;'))
for side in ['main-tree','after','without','mutant']:
 p=s/side/'node_modules';p.symlink_to(r/'stage3/typescript/node_modules',target_is_directory=True)
run('contract',['node',s/'contract.cjs'])
run('count-after',['node',s/'count.cjs',s/'after'])
for side in ['without','after']:
 for mode in ['adamic','upstream']:run('stock-'+side+'-'+mode,['node',s/'stock.cjs',s/side,mode])
 run('build-'+side,['npm','run','build'],s/side)
wait('build-census')
roots={}
for side in ['without','after','mutant']:
 tree=s/side;rootfiles=sorted((tree/'src/compiler').rglob('*.ts'));assert len(rootfiles)==79,len(rootfiles);roots[side]=list(map(str,rootfiles))
 if side!='mutant':run('types-'+side,[s/'adamic','types',*rootfiles])
 run('census-'+side,[s/'census',tree/'src/compiler',s/('census-'+side+'.jsonl')],extra={'LATENT_FULL':'1','LATENT_ONLY_FILE':str(tree/'src/compiler/performanceCore.ts'),'LATENT_ASSERT_NO_OUTPUT':'1','LATENT_TIMES':str(s/('census-'+side+'-times.jsonl'))})
(s/'roots.json').write_text(json.dumps(roots,indent=2)+'\n')
run('replay',['python3',s/'replay.py'])
print('Proof phases completed',flush=True)
