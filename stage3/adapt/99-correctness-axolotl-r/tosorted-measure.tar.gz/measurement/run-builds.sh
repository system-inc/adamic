#!/bin/bash
set -euo pipefail
source /workspace/adamic-tools/env.sh
mkdir -p /workspace/scratch/tosorted/bin-current /workspace/scratch/tosorted/bin-base
cd /workspace/adamic
go build -o /workspace/scratch/tosorted/bin-current/ ./cmd/adamic ./stage3/census/tool > /workspace/scratch/tosorted/raw/build-current.log 2>&1
cd /workspace/scratch/tosorted-base
# The worktree gitlink directory is empty until connected to the initialized dependency.
rmdir cohere
ln -s /workspace/adamic/cohere cohere
go build -o /workspace/scratch/tosorted/bin-base/ ./cmd/adamic ./stage3/census/tool > /workspace/scratch/tosorted/raw/build-base.log 2>&1
