import json,gzip
from pathlib import Path
repo=Path('/workspace/adamic')
rows={}
for line in gzip.open(repo/'stage3/census/latent/data/unmerged4/main-unmerged.jsonl.gz','rt'):
 for f in json.loads(line).get('findings',[]):
  if f['kind']=='Refused' and 'a value of type never' in f['reason'] and 'adamic/invariant-mutable' in f['text']:
   rows[f['where'],f['reason']]=f
print(json.dumps(list(rows.values()),indent=2))
