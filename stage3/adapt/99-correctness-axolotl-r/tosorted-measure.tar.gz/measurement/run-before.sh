#!/bin/bash
set -euo pipefail
source /workspace/adamic-tools/env.sh
export ADAMIC_TYPESCRIPT_SOURCE=/workspace/typescript-source
npm ci --prefix /workspace/scratch/tosorted-base/stage3/api > /workspace/scratch/tosorted/raw/api-before.log 2>&1
/workspace/scratch/tosorted-base/stage3/apply.sh --build-product /workspace/scratch/tosorted/before > /workspace/scratch/tosorted/raw/apply-before.log 2>&1
NODE_PATH=/workspace/adamic/stage3/api/node_modules node /workspace/adamic/stage3/adapt/99-correctness-axolotl-r/measure-tosorted.cjs /workspace/scratch/tosorted/before > /workspace/scratch/tosorted/raw/measure.json 2> /workspace/scratch/tosorted/raw/measure.log
