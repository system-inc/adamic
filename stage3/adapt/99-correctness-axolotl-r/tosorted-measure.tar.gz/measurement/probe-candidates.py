import json,shutil,subprocess
from pathlib import Path
s=Path('/workspace/scratch/tosorted');raw=s/'raw';results={}
for label,needle,replacement in [
 ('upcast','array.length === 0 ? emptyArray : array.slice().sort(comparer)','array.length === 0 ? emptyArray as readonly T[] : array.slice().sort(comparer)'),
 ('satisfies','array.slice().sort(comparer)) as unknown as SortedReadonlyArray<T>','array.slice().sort(comparer)) satisfies readonly T[] as unknown as SortedReadonlyArray<T>')]:
 tree=s/('candidate-'+label);shutil.copytree(s/'before/src',tree/'src',symlinks=True)
 p=tree/'src/compiler/core.ts';text=p.read_bytes();assert text.count(needle.encode())==1;p.write_bytes(text.replace(needle.encode(),replacement.encode()))
 with (raw/('candidate-'+label+'.log')).open('w') as log:r=subprocess.run([s/'bin-base/tool',tree/'src/compiler/binder.ts',raw/('candidate-'+label+'.jsonl')],stdout=log,stderr=log)
 assert r.returncode==0
 results[label]=[json.loads(line) for line in (raw/('candidate-'+label+'.jsonl')).read_text().splitlines()]
 print(label,results[label][0],flush=True)
(raw/'candidate-lowering.json').write_text(json.dumps(results,indent=2)+'\n')
