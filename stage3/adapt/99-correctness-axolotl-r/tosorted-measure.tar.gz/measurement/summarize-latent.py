import json,gzip
from pathlib import Path
s=Path('/workspace/scratch/tosorted');reads=json.loads((s/'raw/empty-reads.json').read_text());findings=json.loads((s/'raw/latent-never.json').read_text())
for r in findings:
 file,line,col=r['where'].rsplit(':',2);line=int(line);col=int(col)
 same=[n for n in reads if n['file']==file]
 close=sorted(same,key=lambda n:(abs(n['line']-line),abs(n['column']-col)))[:1]
 if close:
  n=close[0]
  print(r['where'],'=>',f"{file}:{n['line']}:{n['column']}",'.'.join(n['owners']),n['lineText'])
