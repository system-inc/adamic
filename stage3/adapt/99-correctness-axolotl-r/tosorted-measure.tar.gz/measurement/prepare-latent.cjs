'use strict';
const fs=require('fs'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const {compiler,nodes}=require('/workspace/adamic/stage3/adapt/47-host-errors/adapt.cjs');
const tree='/workspace/scratch/tosorted/before',rows=[];
const path=require('path');
const files=fs.readdirSync(tree+'/src/compiler',{recursive:true}).filter(n=>n.endsWith('.ts')).map(n=>tree+'/src/compiler/'+n);
for(const name of files){const file=ts.createSourceFile(name,fs.readFileSync(name,'utf8'),ts.ScriptTarget.Latest,true);
 for(const n of nodes(ts,file,n=>ts.isIdentifier(n)&&n.text==='emptyArray'&&!ts.isImportSpecifier(n.parent)&&!ts.isVariableDeclaration(n.parent))){
  const p=file.getLineAndCharacterOfPosition(n.getStart(file));let owners=[];
  for(let a=n.parent;a;a=a.parent)if(ts.isFunctionLike(a))owners.unshift(a.name?.getText(file)??'<anonymous>');
  rows.push({file:file.fileName.slice(tree.length+1),line:p.line+1,column:p.character+1,owners,lineText:file.text.split(/\r?\n/)[p.line].trim()});
 }
}
console.log(JSON.stringify(rows,null,2));
