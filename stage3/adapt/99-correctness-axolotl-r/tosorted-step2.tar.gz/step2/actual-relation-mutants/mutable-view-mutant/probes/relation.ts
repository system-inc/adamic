export const emptyArray: never[] = [] as never[];
function probe<T>(): readonly T[] { return emptyArray satisfies T[]; }
console.log(String(probe<number>().length));
console.log(String(probe<string>().length));
