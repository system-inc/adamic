import os,pathlib,subprocess,signal,time,json
R=pathlib.Path('/workspace/scratch/core-wave')
rows=[r.split(None,3) for r in subprocess.check_output(['ps','-eo','pid,ppid,stat,args'],text=True).splitlines()[1:]];parents={int(p):int(q) for p,q,_,_ in rows};skip={os.getpid()};p=os.getpid()
while p in parents and parents[p] not in skip:p=parents[p];skip.add(p)
def matches():
 found=[]
 for path in pathlib.Path('/proc').iterdir():
  if not path.name.isdigit() or int(path.name) in skip:continue
  try:
   stat=(path/'stat').read_text();state=stat[stat.rfind(')')+2:].split()[0]
   if state=='Z':continue
   args=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace');cwd=os.readlink(path/'cwd')
  except (OSError,ValueError):continue
  owned=str(R) in args or cwd.startswith(str(R)) or cwd.startswith('/workspace/core-') or cwd.startswith('/tmp/adamic-gate/ts-tests')
  if owned:found.append({'pid':int(path.name),'args':args,'cwd':cwd})
 return found
found=matches()
for row in found:
 try:os.kill(row['pid'],signal.SIGTERM)
 except ProcessLookupError:pass
if found:time.sleep(1)
for row in matches():
 try:os.kill(row['pid'],signal.SIGKILL)
 except ProcessLookupError:pass
remaining=matches();assert not remaining,remaining
(R/'process-cleanup.json').write_text(json.dumps({'terminated':found,'remainingTaskProcesses':remaining,'pass':True},indent=2)+'\n');print('remaining task processes',len(remaining))
