'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const upstream=fs.readFileSync('/workspace/typescript-source/src/compiler/core.ts','utf8').replace(/\r\n/g,'\n'),source=ts.createSourceFile('core.ts',upstream,ts.ScriptTarget.Latest,true);
for(const [name,repo] of [['clone','/workspace/adamic'],['groupby','/workspace/adamic-groupby']]){
 const owner=name==='groupby'?'groupBy':name,decls=source.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text===owner);
 let before=upstream.slice(decls[0].getStart(source),decls.at(-1).end),after;
 if(name==='clone')after=before.replace('(object as any)[id]','object[id]');
 else {before=before.replace('const value = values[i];','const value = values[i]!;');let at=before.lastIndexOf('export function groupBy');after=before.slice(0,at)+before.slice(at).replace(': { [P in K as `${P}`]?: T[]; } {',': Record<string, T[]> {').replace('return result as { [P in K as `${P}`]?: T[]; };','return result;');}
 if(before===after)throw Error('no edit');const digest=t=>crypto.createHash('sha256').update(t).digest('hex');
 const dir=repo+'/stage3/adapt/99-correctness-core-'+name;fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(dir+'/owners.json',JSON.stringify([{file:'core.ts',owner,beforeDeclarations:decls.length,afterDeclarations:decls.length,before,after,ownerBeforeSha256:digest(before),ownerAfterSha256:digest(after),siteEdits:name==='clone'?1:2}],null,2)+'\n');
 let adapter=fs.readFileSync('/workspace/adamic/stage3/adapt/99-correctness-axolotl-w/adapt.cjs','utf8');const start=adapter.indexOf('const owners = ['),end=adapter.indexOf('\nconst digest',start);adapter=adapter.slice(0,start)+"const owners = require('./owners.json');"+adapter.slice(end);fs.writeFileSync(dir+'/adapt.cjs',adapter);
 let compare=fs.readFileSync('/workspace/adamic/stage3/adapt/99-correctness-axolotl-w/compare.cjs','utf8');fs.writeFileSync(dir+'/compare.cjs',compare);
}
