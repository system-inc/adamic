import pathlib,subprocess,json,hashlib,tarfile,shutil
R=pathlib.Path('/workspace/scratch/core-wave')
for name,repo in [('clone',pathlib.Path('/workspace/adamic')),('groupby',pathlib.Path('/workspace/adamic-groupby'))]:
 d=repo/('stage3/adapt/99-correctness-core-'+name);e=R/('checkpoint-'+name);e.mkdir(exist_ok=True)
 for f in ['apply-before.log','apply-'+name+'.log','setup.log','npm-api.log','owner-search.log','type-trials.json','contract-'+name+'.log','witness-'+name+'.json','types-before.log','types-'+name+'.log']:
  shutil.copyfile(R/f,e/f)
 (e/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(e.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 archive=d/'apply-checkpoint.tar.gz'
 with tarfile.open(archive,'w:gz') as t:t.add(e,arcname='apply-checkpoint')
 (d/'apply-checkpoint.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
 (d/'PROOF.md').write_text('# Apply checkpoint\n\nBoth complete applies exit 0: main and main plus this directory.\nBoth exact before-pins match the completed baseline owners. The owner contract\nand Node witnesses pass. Type-only trial results and raw apply logs are packed\nin apply-checkpoint.tar.gz with SHA256SUMS.\n\nThe ordinary 79-root types checks pass before and after with zero diagnostics.\nEmitted declarations and JavaScript, paired replay,\nfull core.ts census, mutants, and complete lane call count are pending.\nThis checkpoint does not claim those proofs.\n')
 def git(*args):
  with (R/('git-checkpoint-'+name+'.log')).open('a') as log:subprocess.run(['git',*args],cwd=repo,stdout=log,stderr=log,check=True)
 git('add',str(d.relative_to(repo)));git('commit','-m','stage3: checkpoint type-only core '+name+' after both full applies')
 git('push','origin','HEAD:refs/heads/typescript/core-'+name+'-checkpoint')
 print(name,subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),flush=True)
