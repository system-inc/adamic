import pathlib,json,subprocess,hashlib,tarfile,shutil
R=pathlib.Path('/workspace/scratch/core-wave');progress={'fullApplies':'both exit 0','types':'79 roots, zero diagnostics before and after','emission':'all 9 JS files and both public declarations byte-identical','census':'exact target gone, zero new core.ts sites, both mutants restore baseline','wholeLaneControl':json.loads((R/'lane-result.json').read_text()),'completeCopyPairedReplay':'in progress','countedLaneUnion':'in progress'}
for name,repo in [('clone',pathlib.Path('/workspace/adamic')),('groupby',pathlib.Path('/workspace/adamic-groupby'))]:
 d=repo/('stage3/adapt/99-correctness-core-'+name);folder=R/('proof-progress-'+name);folder.mkdir(exist_ok=True)
 for stem in ['census-before','census-'+name,'census-mutant-'+name]:
  for suffix in ['.jsonl','.log','-result.json','-times.jsonl']:shutil.copyfile(R/(stem+suffix),folder/(stem+suffix))
 for f in ['census-summary.json','compare-'+name+'.log','types-before-result.json','types-'+name+'-result.json','declarations.json','untouched-site.json','references.json','mutants.json','lane-result.json','provenance.json']:shutil.copyfile(R/f,folder/f)
 (folder/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(folder.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 archive=d/'proof-progress.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:tar.add(folder,arcname='proof-progress')
 (d/'proof-progress.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n');(d/'PROGRESS.json').write_text(json.dumps(progress,indent=2)+'\n')
 (d/'PROOF.md').write_text('# Proof checkpoint\n\nBoth full applies pass. Ordinary Adamic types passes all 79 roots before and\nafter with zero diagnostics. All nine emitted JavaScript files and both public\ndeclarations are byte-identical. The full core.ts census removes exactly the\ntarget site and adds none. Restoring the original owner restores main core.ts\nbytes and the complete baseline site set. The whole-lane control passes with\n106,366 passing tests, one sanctioned API failure and zero skipped.\n\nThe full paired replay on complete copies and the 398-shard counted lane union\nare still in progress. The reduced-copy replay attempt is excluded.\nProof-progress.tar.gz retains completed native and emission checks with an\ninternal SHA256SUMS manifest. Final proof and count reports will replace this\ncheckpoint before the requested branch is published.\n')
 shutil.copyfile(R/('source-'+name+'.patch'),d/'source.patch')
 with (R/('git-proof-progress-'+name+'.log')).open('w') as log:
  for args in [['add',str(d.relative_to(repo))],['commit','-m','stage3: checkpoint core '+name+' types, emission, census and lane control'],['push','origin','HEAD:refs/heads/typescript/core-'+name+'-checkpoint']]:subprocess.run(['git',*args],cwd=repo,stdout=log,stderr=log,check=True)
 print(name,'proof progress pushed',flush=True)
