import pathlib,json,re,hashlib
R=pathlib.Path('/workspace/scratch/core-wave');refs=json.loads((R/'references.json').read_text());declarations={}
for name in ['before','clone','groupby']:
 tree=pathlib.Path('/workspace/core-'+name);declarations[name]={}
 for f in ['typescript.d.ts','tsserverlibrary.d.ts','typescript.internal.d.ts']:
  p=tree/'built/local'/f;raw=p.read_bytes();lines=raw.decode().splitlines();matches=[{'line':i+1,'text':s.strip()} for i,s in enumerate(lines) if re.search(r'\bfunction (groupBy|clone)\b',s)]
  declarations[name][f]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'definitions':matches}
  assert bool(matches)==(f=='typescript.internal.d.ts')
for f in declarations['before']:
 assert len({declarations[n][f]['sha256'] for n in declarations})==1
(R/'declarations.json').write_text(json.dumps(declarations,indent=2)+'\n')
for name,repo in [('clone',pathlib.Path('/workspace/adamic')),('groupby',pathlib.Path('/workspace/adamic-groupby'))]:
 d=repo/('stage3/adapt/99-correctness-core-'+name)
 text='# Adapted source references\n\nThe TypeScript checker resolves identifiers and import aliases to the two core\nfunction symbols across all 711 adapted src TypeScript roots. references.json\nretains every matching identifier and every resolved core-function reference.\nThe raw rg search, including comments, local variables called clone, library\nfeature-name strings groupBy, and the unrelated typesMap.json package name, is\nretained in evidence/all-name-hits.log. Those are distinguished from references\nto these core functions. Star namespace exports expose the same symbols.\n\n'
 for target,rows in refs['functions'].items():
  text+='## '+target+'\n\n| File | Line | Use |\n| --- | ---: | --- |\n'
  for row in rows:text+='| '+row['file']+' | '+str(row['line'])+' | '+row['use']+' |\n'
  text+='\n'
 text+='''The compiler's only groupBy call, legacyDecorators.ts:538, resolves to the\nkey-selector overload with K = boolean. isSyntheticMetadataDecorator returns\nboolean, not a type predicate. The false and true optional arrays are destructured\nas decorators and metadata. The caller maps ordinary decorators, appends mapped\nparameter decorators, and maps metadata last. Undefined buckets are accepted by\nmap. The services call at organizeImports.ts:427 uses the same overload with\nstring keys. It iterates groups by import attributes before categorizing and\ncoalescing imports.\n\nclone has no compiler caller. cloneCompilerOptions in services makes a shallow\ncopy and restores the configFile option. The harness copies format options.\nThe virtual file-system helper clones entries directly and passes clone as a\nmap callback for folder entries. There is no server reference to either core\nfunction; server/typesMap.json's clone string is a package mapping.\n\nBoth functions occur only in typescript.internal.d.ts, not typescript.d.ts or\ntsserverlibrary.d.ts. All three declaration files are byte-identical before\nand after either adaptation. Exact definition lines and hashes are retained\nin evidence/declarations.json.\n'''
 (d/'REFERENCES.md').write_text(text)
