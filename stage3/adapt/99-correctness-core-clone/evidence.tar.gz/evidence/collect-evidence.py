import pathlib,hashlib,json,shutil,tarfile,subprocess
R=pathlib.Path('/workspace/scratch/core-wave')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,repo in [('clone',pathlib.Path('/workspace/adamic')),('groupby',pathlib.Path('/workspace/adamic-groupby'))]:
 d=repo/('stage3/adapt/99-correctness-core-'+name);out=R/('evidence-'+name);out.mkdir(exist_ok=True)
 for p in sorted(R.iterdir()):
  if p.is_file() and p.suffix in ['.log','.json','.jsonl','.txt','.py','.cjs','.patch'] and not p.name.startswith('git-'):
   if p.name.startswith(('compare-','contract-','types-','witness-','replay-','census-','build-','apply-','roots-')) and any(other in p.name for other in (['groupby'] if name=='clone' else ['clone'])):continue
   shutil.copyfile(p,out/p.name)
 for folder in ['overlay','calls','count-preparation','replay-reduced-copy-attempt','count-failed-view-attempt','count-failed-git-attempt']:
  if (R/folder).exists():shutil.copytree(R/folder,out/folder,dirs_exist_ok=True)
 for p in sorted(R.glob('count-piece-*')):shutil.copytree(p,out/p.name,dirs_exist_ok=True)
 for folder in ['lane']:
  src=R/folder
  if src.exists():
   for f in src.rglob('*'):
    if f.is_file() and 'adapted-tree' not in f.parts and 'mocha-errors' not in f.parts:
     dest=out/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
 for label in ['before',name]:
  tree=pathlib.Path('/workspace/core-'+label);dest=out/('source-'+label);dest.mkdir(exist_ok=True)
  files=sorted(p for p in (tree/'src').rglob('*') if p.is_file());manifest={str(p.relative_to(tree)):digest(p) for p in files};(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copyfile(tree/'src/compiler/core.ts',dest/'core.ts');shutil.copyfile(tree/'patch-set.md',dest/'patch-set.md')
 # All retained generated Go source must use .go.txt.
 assert not list(out.rglob('*.go'))
 files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(out/'SHA256SUMS').write_text(''.join(digest(p)+'  '+str(p.relative_to(out))+'\n' for p in files))
 archive=d/'evidence.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:tar.add(out,arcname='evidence')
 (d/'evidence.sha256').write_text(digest(archive)+'  '+archive.name+'\n')
 for f in ['comparison','census-summary','count-summary','provenance','references','type-trials']:
  src=R/((('compare-'+name) if f=='comparison' else f)+('.log' if f=='comparison' else '.json'))
  if src.exists():shutil.copyfile(src,d/(f+'.json'))
 for f in ['references.cjs','type-trials.cjs','witness.cjs','count-preload.cjs','count-pieces.py','run-lane.py','proofs.py','replay.py','summarize-census.py']:
  shutil.copyfile(R/f,d/f)
 print(name,'packed',len(files),'files',archive.stat().st_size,'bytes',flush=True)
