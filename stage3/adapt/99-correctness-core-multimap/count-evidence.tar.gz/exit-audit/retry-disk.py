import concurrent.futures,json,os,pathlib,subprocess
repo=pathlib.Path('/workspace/adamic');s=pathlib.Path('/workspace/scratch/multimap/exit-audit');units=json.loads((repo/'stage3/lane/shards.json').read_text())['units'];indexes={u['name']:i for i,u in enumerate(units)};summary=json.loads((s/'count-240/summary.json').read_text());bad=[r['unit'] for r in summary['units'] if r['exit']];excluded=s/'excluded-disk-errors';excluded.mkdir()
for name in bad:
 p=s/'results'/name
 if p.exists():p.rename(excluded/name)
def run(name):
 index=indexes[name]
 with (s/(name+'-disk-retry.log')).open('w') as log:r=subprocess.run(['python3',str(s/'measure-v3.py'),str(index),'1'],cwd=repo,env=dict(os.environ,MM_ATTEMPT_SUFFIX='-disk-retry'),stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:codes=list(pool.map(run,bad))
assert not any(codes)
with (s/'resume-280.log').open('w') as log:r=subprocess.run(['python3',str(s/'count-all-v3.py'),'280'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(r.returncode)
