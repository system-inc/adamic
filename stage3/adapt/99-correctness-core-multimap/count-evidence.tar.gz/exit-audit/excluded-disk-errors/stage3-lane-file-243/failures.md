### fourslash-server tests tests/cases/fourslash/server/autoImportFileExcludePatterns_windowsPaths.ts fourslash-server test autoImportFileExcludePatterns_windowsPaths.ts tsserver log (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/tsserver'
```

Elapsed: 2730.285 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for privacy Check on imported module - import statement in parent module: testcase tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 2.034 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for privacy Check on imported module - import statement in parent module: testcase tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (@module: commonjs) Correct errors for tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.046 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for privacy Check on imported module - import statement in parent module: testcase tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (@module: amd) Correct module resolution tracing for tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.243 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for privacy Check on imported module - import statement in parent module: testcase tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (@module: amd) Correct errors for tests/cases/project/privacyCheckOnImportedModuleImportStatementInParentModule.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.111 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)
