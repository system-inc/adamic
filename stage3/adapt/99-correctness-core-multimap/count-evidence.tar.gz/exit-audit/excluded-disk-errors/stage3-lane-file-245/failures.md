### fourslash-server tests tests/cases/fourslash/server/pasteEdits_revertUpdatedFile.ts fourslash-server test pasteEdits_revertUpdatedFile.ts tsserver log (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/tsserver'
```

Elapsed: 2946.827 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 2.462 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: commonjs) Correct errors for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 2.320 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: commonjs) Correct JS output for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.544 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: amd) Correct module resolution tracing for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.363 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: amd) Correct errors for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 6.241 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]: outputdir_singleFile: specify outputDirectory: testcase tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (@module: amd) Correct JS output for tests/cases/project/maprootUrlSingleFileSpecifyOutputDirectory.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.504 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)
