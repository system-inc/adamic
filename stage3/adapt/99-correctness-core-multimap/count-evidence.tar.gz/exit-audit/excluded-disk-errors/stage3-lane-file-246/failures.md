### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1436.049 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: commonjs) Correct errors for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.585 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: commonjs) Correct JS output for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.744 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: amd) Correct module resolution tracing for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.286 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: amd) Correct errors for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.877 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-AbsolutePath]: outputdir_subfolder: specify outputDirectory: testcase tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (@module: amd) Correct JS output for tests/cases/project/mapRootAbsolutePathSubfolderSpecifyOutputDirectory.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.183 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.806 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: commonjs) Correct errors for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.838 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: commonjs) Correct JS output for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.995 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: amd) Correct module resolution tracing for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.766 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: amd) Correct errors for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.702 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for [Sourcemap]/[Maproot-Url]/[Sourceroot-Url]: outputdir_simple: no outdir: testcase tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (@module: amd) Correct JS output for tests/cases/project/maprootUrlsourcerootUrlSimpleNoOutdir.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.182 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: commonjs) Correct module resolution tracing for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 1.727 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: commonjs) Correct errors for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.811 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: commonjs) Correct JS output for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.555 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: amd) Correct module resolution tracing for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.794 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: amd) Correct errors for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.760 ms; timeout: 40000 ms.

Stack top:     at Object.mkdirSync (node:fs:1411:26)

### projects tests Compiling project for Verify exclude property without using relative path: testcase tests/cases/project/specifyExcludeUsingRelativepath.json (@module: amd) Correct JS output for tests/cases/project/specifyExcludeUsingRelativepath.json (baseline-missing)

```text
Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
     Error: ENOSPC: no space left on device, mkdir 'tests/baselines/local/project'
```

Elapsed: 0.660 ms; timeout: 40000 ms.

Stack top:     at ProjectTestCase.verifyJavaScriptOutput (src/testRunner/projectsRunner.ts:293:23)
