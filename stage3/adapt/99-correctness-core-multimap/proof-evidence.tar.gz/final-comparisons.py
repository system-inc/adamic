import json,os,subprocess,time,pathlib,difflib,hashlib
s=pathlib.Path('/workspace/scratch/multimap');r=pathlib.Path('/workspace/adamic');d=r/'stage3/adapt/99-correctness-core-multimap';begin=time.monotonic()
while not (s/'whole-control-result.json').exists():
 assert time.monotonic()-begin<1550
 time.sleep(5)
while not json.loads((s/'whole-control-result.json').read_text()).get('shardUnionIdentical'):
 x=json.loads((s/'whole-control-result.json').read_text());assert x['exit']==0
 assert time.monotonic()-begin<1550
 time.sleep(5)
a=pathlib.Path('/workspace/multimap-base');b=s/'whole/adapted-tree';env=dict(os.environ,NODE_PATH=str(r/'stage3/api/node_modules'))
for name,cmd in [('comparison',['node',str(d/'compare.cjs'),str(a),str(b),str(s/'comparison.json')]),('javascript-scope',['node',str(d/'javascript-scope.cjs'),str(a),str(b),str(s/'javascript-scope.json')]),('body',['node',str(d/'body-proof.cjs'),str(b),str(s/'bodies.json'),str(s/'final-body-proof.json')])]:
 with (s/(name+'-final.log')).open('w') as log:subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
files=list((pathlib.Path('/workspace/multimap-after')/'src').rglob('*'));rows=[]
for p in files:
 if p.is_file():
  rel=p.relative_to('/workspace/multimap-after');q=b/rel;assert p.read_bytes()==q.read_bytes();rows.append(str(rel))
(s/'whole-source-equality.json').write_text(json.dumps({'sourceFiles':len(rows),'allByteIdenticalToFullApply':True},indent=2)+'\n')
comparison=json.loads((s/'comparison.json').read_text());hunks=[]
for row in comparison['javascript']:
 if not row['identical']:
  name=row['name'];hunks.extend(difflib.unified_diff((a/'built/local'/name).read_text().splitlines(True),(b/'built/local'/name).read_text().splitlines(True),fromfile='before/built/local/'+name,tofile='after/built/local/'+name))
(s/'javascript-hunks.diff').write_text(''.join(hunks));print('All final source, declaration, JavaScript scope and body comparisons passed',flush=True)
