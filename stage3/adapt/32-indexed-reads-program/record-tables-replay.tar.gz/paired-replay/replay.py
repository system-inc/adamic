from stepb_common import *
from concurrent.futures import ThreadPoolExecutor
import shutil,time
for label,tree in [('before',before),('after',after)]:
 shutil.copytree(tree,s/('replay-'+label),symlinks=True,ignore=shutil.ignore_patterns('node_modules'));(s/('replay-'+label)/'node_modules').symlink_to(repo/'stage3/typescript/node_modules',target_is_directory=True)
frozen={label:snapshot(s/('replay-'+label)) for label in ['before','after']};rows=[]
def run(label):
 tree=s/('replay-'+label)
 with (s/'raw'/('replay-'+label+'.stdout')).open('w') as outlog,(s/'raw'/('replay-'+label+'.stderr')).open('w') as errlog:
  p=subprocess.Popen(['node',str(directory/'adapt.cjs'),str(tree)],env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules')),stdout=outlog,stderr=errlog,start_new_session=True)
  try:code=p.wait(timeout=240)
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
 result={'exit':code,'stdout':(s/'raw'/('replay-'+label+'.stdout')).read_text().replace(str(tree),'TREE'),'stderr':(s/'raw'/('replay-'+label+'.stderr')).read_text().replace(str(tree),'TREE')}
 with (s/'raw'/('replay-'+label+'.log')).open('a') as log:log.write(directory.name+'\n'+result['stdout']+result['stderr'])
 return label,result
for directory in sorted(p for p in (repo/'stage3/adapt').iterdir() if p.is_dir()):
 with ThreadPoolExecutor(max_workers=2) as pool:row={'adapter':directory.name,**dict(pool.map(run,['before','after']))}
 rows.append(row);(s/'raw/replay.json').write_text(json.dumps(rows,indent=2)+'\n');print(directory.name,row['before']['exit'],row['after']['exit'],flush=True)
 if directory.name not in ['30-indexed-reads','32-indexed-reads-program']:assert row['before']==row['after'],row
 # Inspectors/rewriters may only produce the approved two source file changes.
for label in ['before','after']:
 current=snapshot(s/('replay-'+label));delta=[p for p in current if current[p]!=frozen[label].get(p)];assert not(set(current)-set(frozen[label]));assert all(p in ['src/compiler/core.ts','src/compiler/symbolWalker.ts'] for p in delta),delta
 different=[r['adapter'] for r in rows if r['before']!=r['after']]
(s/'raw/replay-summary.json').write_text(json.dumps({'pass':True,'adapters':len(rows),'different':different,'allowedDifferences':['30-indexed-reads','32-indexed-reads-program'],'sourceChangesConfinedToApprovedOwners':True},indent=2)+'\n');print('COMPLETE only amended adaptations may differ',flush=True)
