from stepb_common import *
from concurrent.futures import ThreadPoolExecutor,as_completed
import time,shutil,base64
plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());units=plan['units'];assert len(units)==398
results=s/'lane-results';results.mkdir(exist_ok=True);frozen=snapshot(after);(s/'raw/lane-source-manifest.json').write_text(json.dumps(frozen,indent=2)+'\n');progress={'units':398,'completedUnits':[],'counts':{'pass':0,'fail':0,'skip':0},'pieces':[],'complete':False}
receipt=out/'record-tables-after-lane.json'
if receipt.exists():
 progress=json.loads(receipt.read_text());assert all(not p['failed'] for p in progress['pieces']);assert progress['completedUnits']==[u['name'] for u in units[:len(progress['completedUnits'])]]
 for name in progress['completedUnits']:shutil.rmtree(results/name/'adapted-tree',ignore_errors=True)
def run(item):
 unit,directory=item;env=dict(os.environ,STAGE3_ADAPTED_TREE=str(after),STAGE3_RESULTS=str(results),STAGE3_SHARD_SECONDS='90',NODE_OPTIONS='',NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('GOVB_DIR',None)
 code=child_run(['python3',str(repo/'stage3/lane/shard.py'),unit['name'],str(results)],directory/(unit['name']+'.log'),env,120);report=json.loads((results/unit['name']/'report.json').read_text());return unit,code,report
for start in range(0,398,20):
 if start<len(progress['completedUnits']):continue
 begin=time.monotonic();number=start//20+1;directory=s/f'lane-piece-{number:02d}';directory.mkdir();subset=units[start:start+20]
 workers=4 if (s/'census-finished.json').exists() and (s/'raw/replay-summary.json').exists() else 2
 with ThreadPoolExecutor(max_workers=workers) as pool:got=[f.result() for f in as_completed([pool.submit(run,(u,directory)) for u in subset])]
 failed=[{'unit':u['name'],'exit':code,'report':report} for u,code,report in got if code or report['status']!='pass' or report['errors']];assert frozen==snapshot(after)
 packed=directory/'packed';packed.mkdir()
 with (packed/'evidence.jsonl').open('w') as f:
  for unit,code,report in sorted(got,key=lambda r:r[0]['name']):
   for p in sorted((results/unit['name']).rglob('*')):
    if not p.is_file() or 'adapted-tree' in p.relative_to(results/unit['name']).parts:continue
    raw=p.read_bytes();row={'unit':unit['name'],'path':str(p.relative_to(results/unit['name'])),'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)}
    try:row['text']=raw.decode('utf8')
    except UnicodeDecodeError:row['base64']=base64.b64encode(raw).decode('ascii')
    f.write(json.dumps(row)+'\n')
   f.write(json.dumps({'unit':unit['name'],'path':'driver.log','text':(directory/(unit['name']+'.log')).read_text()})+'\n')
 record={'piece':number,'units':[u['name'] for u in subset],'seconds':time.monotonic()-begin,'failed':failed,'frozenSourceAndBuildUnchanged':True,'workers':workers};assert record['seconds']<1500;(packed/'piece.json').write_text(json.dumps(record,indent=2)+'\n')
 if not failed:
  progress['completedUnits']+=record['units']
  for _,_,report in got:
   for k,v in report['counts'].items():progress['counts'][k]+=v
 progress['pieces'].append(record);progress['complete']=len(progress['completedUnits'])==398;p=out/'record-tables-after-lane.json';p.write_text(json.dumps(progress,indent=2)+'\n');publish(pack(packed,f'record-tables-after-lane-{number:02d}')+[p],f'Checkpoint record-table whole-lane piece {number}, {len(subset)} ordinary shards; all identity, API, baseline and count guards retained.')
 print(json.dumps({'piece':number,'completed':len(progress['completedUnits']),'counts':progress['counts'],'seconds':record['seconds'],'failed':len(failed)}),flush=True)
 for unit,_,_ in got:shutil.rmtree(results/unit['name']/'adapted-tree',ignore_errors=True)
 if failed:raise SystemExit('Lane failure checkpoint pushed; stop and inspect.')
assert progress['counts']==plan['counts'];assert len(set(progress['completedUnits']))==398;print('COMPLETE all 398 normal shards',flush=True)
