from stepb_common import *
import time,base64,shutil
progress=json.loads((out/'record-tables-after-lane.json').read_text());assert len(progress['pieces'])==2 and len(progress['completedUnits'])==20;original=progress['pieces'][1];assert len(original['failed'])==1 and original['failed'][0]['unit']=='stage3-lane-file-013';assert original['failed'][0]['report']['failures'][0]['cause']=='timeout'
results=s/'lane-retry-results';results.mkdir();directory=s/'lane-piece-02-retry';directory.mkdir();name='stage3-lane-file-013';frozen=snapshot(after);assert frozen==json.loads((s/'raw/lane-source-manifest.json').read_text());begin=time.monotonic()
env=dict(os.environ,STAGE3_ADAPTED_TREE=str(after),STAGE3_RESULTS=str(results),STAGE3_SHARD_SECONDS='90',NODE_OPTIONS='',NODE_DISABLE_COMPILE_CACHE='1',PYTHONDONTWRITEBYTECODE='1');code=child_run(['python3',str(repo/'stage3/lane/shard.py'),name,str(results)],directory/'retry.log',env,120);report=json.loads((results/name/'report.json').read_text());assert code==0 and report['status']=='pass' and not report['errors'],report;assert snapshot(after)==frozen
with (directory/'evidence.jsonl').open('w') as f:
 for p in sorted((results/name).rglob('*')):
  if not p.is_file() or 'adapted-tree' in p.relative_to(results/name).parts:continue
  raw=p.read_bytes();row={'unit':name,'path':str(p.relative_to(results/name)),'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)}
  try:row['text']=raw.decode('utf8')
  except UnicodeDecodeError:row['base64']=base64.b64encode(raw).decode('ascii')
  f.write(json.dumps(row)+'\n')
record={'piece':2,'units':original['units'],'seconds':original['seconds']+time.monotonic()-begin,'failed':[],'frozenSourceAndBuildUnchanged':True,'firstAttempt':original,'retryOnly':name,'retrySeconds':time.monotonic()-begin,'timeoutUnchanged':{'mochaHookSeconds':40,'shardSeconds':90},'nineteenOriginalPassingShardsRetained':True};assert record['seconds']<1500
(directory/'piece.json').write_text(json.dumps(record,indent=2)+'\n');progress['pieces'][1]=record;progress['completedUnits']+=record['units']
for unit in record['units']:
 root=results if unit==name else s/'lane-results'
 r=json.loads((root/unit/'report.json').read_text());assert r['status']=='pass' and not r['errors']
 for k,v in r['counts'].items():progress['counts'][k]+=v
p=out/'record-tables-after-lane.json';p.write_text(json.dumps(progress,indent=2)+'\n');publish(pack(directory,'record-tables-after-lane-02-retry')+[p],'Retain the piece-2 40-second hook timeout receipt, retry only shard file-013 with the same timeouts and guards, and retain all 19 original passing shards. All 20 now pass; reduce subsequent lane concurrency while replay/census run.')
shutil.rmtree(results/name/'adapted-tree',ignore_errors=True);print('PASS retry; 40 completed lane shards; original timeout retained, no timeout waiver',flush=True)
