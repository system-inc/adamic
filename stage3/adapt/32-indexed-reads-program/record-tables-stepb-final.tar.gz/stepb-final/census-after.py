from stepb_common import *
from concurrent.futures import ThreadPoolExecutor
import time,re
roots=sorted(p.relative_to(after/'src/compiler') for p in (after/'src/compiler').rglob('*.ts'));assert len(roots)==79
baseline={r['roots'][0]:r for r in json.loads((s/'raw/census-before.json').read_text())};assert len(baseline)==79
frozen={str(p.relative_to(after/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((after/'src').rglob('*')) if p.is_file()};allrows=[]
def run(item):
 directory,n,paths=item;inp=directory/f'after-{n}-roots.json';dst=directory/f'after-{n}.jsonl';inp.write_text(json.dumps([str(after/'src/compiler'/p) for p in paths],indent=2)+'\n');code=child_run([str(b/'census-batch'),str(inp),str(dst)],directory/f'after-{n}.log',dict(os.environ,GOMAXPROCS='1',GOMEMLIMIT='3GiB'));assert code==0;rows=[json.loads(l) for l in dst.read_text().splitlines()];assert {r['roots'][0] for r in rows}=={str(after/'src/compiler'/p) for p in paths};return rows
for start in range(0,79,20):
 begin=time.monotonic();number=start//20+1;directory=s/f'paired-census-{number}';directory.mkdir();subset=roots[start:start+20]
 with ThreadPoolExecutor(max_workers=2) as pool:got=[r for part in pool.map(run,[(directory,n,subset[n::2]) for n in range(2)]) for r in part]
 indexed={r['roots'][0]:r for r in got};pairs=[{'root':str(p),'before':baseline[str(before/'src/compiler'/p)],'after':indexed[str(after/'src/compiler'/p)]} for p in subset];allrows+=pairs
 assert frozen=={str(p.relative_to(after/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((after/'src').rglob('*')) if p.is_file()}
 record={'group':number,'roots':len(subset),'seconds':time.monotonic()-begin,'pairs':pairs,'afterSourceManifest':frozen};assert record['seconds']<1500;(directory/'group.json').write_text(json.dumps(record,indent=2)+'\n')
 for pair in pairs:
  old,new=pair['before'],pair['after'];is73=old.get('where','').endswith('core.ts:1326:26')
  if is73:assert new['kind']=='NotYet' and new['where'].endswith('core.ts:1364:29') and new['reason']=='a non-object representation passed through an opaque object parameter',pair
  else:
   norm=lambda row,tree:{k:(v.replace(str(tree),'TREE') if isinstance(v,str) else [x.replace(str(tree),'TREE') for x in v] if isinstance(v,list) else v) for k,v in row.items() if k!='seconds'}
   assert norm(old,before)==norm(new,after),pair
 report=out/'record-tables-census.json';report.write_text(json.dumps(allrows,indent=2)+'\n');publish(pack(directory,f'record-tables-census-{number}')+[report],f'Checkpoint record-table paired census group {number}, {len(subset)} independent roots per side; ordinary load and lower, source manifests unchanged.')
 print('PUSHED census group',number,'roots',len(subset),'seconds',record['seconds'],flush=True)
assert len(allrows)==79;changed=[x['root'] for x in allrows if x['before'].get('where','').endswith('core.ts:1326:26')];assert len(changed)==73
(s/'raw/census-summary.json').write_text(json.dumps({'roots':79,'groups':[20,20,20,19],'moved73':changed,'otherSixUnchanged':True,'nextStop':'core.ts:1364:29','lowering':'internal/lower/detached_own.go:94, (*lowering).detachedOwnRefusal'},indent=2)+'\n');(s/'census-finished.json').write_text('{"pass":true}\n');print('COMPLETE 79 paired roots; 73 move to 1364:29; other 6 unchanged',flush=True)
