from pathlib import Path
import subprocess,fcntl,hashlib,tarfile,json,os,signal
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/gov-build');out=repo/'stage3/adapt/32-indexed-reads-program';b=Path('/workspace/scratch/gov-b');before=b/'full-before';after=s/'full-after';prefix='never cut alone: lands with chg_yj14ddxz, because the census reads its stop'
def publish(paths,message):
 with (s/'git.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with (s/'raw/publish.log').open('a') as log:
   assert subprocess.run(['git','diff','--cached','--quiet'],cwd=repo,stdout=log,stderr=log).returncode==0, 'checkpoint index must start clean'
   relative=[str(p.relative_to(repo)) for p in paths]
   try:
    for args in [['add',*relative],['diff','--cached','--check'],['commit','-m',prefix,'-m',message],['push','origin','typescript/getownvalues']]:subprocess.run(['git',*args],cwd=repo,stdout=log,stderr=log,check=True)
   except BaseException:
    subprocess.run(['git','restore','--staged','--',*relative],cwd=repo,stdout=log,stderr=log,check=True)
    raise

def pack(directory,name):
 manifest=directory/'SHA256SUMS';manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(directory))+'\n' for p in sorted(directory.rglob('*')) if p.is_file() and p!=manifest));archive=out/(name+'.tar.gz');tmp=s/(name+'.tar.gz')
 with tarfile.open(tmp,'w:gz') as tf:tf.add(directory,arcname=directory.name)
 tmp.replace(archive);sha=out/(name+'.sha256');sha.write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n');return [archive,sha]
def snapshot(tree):return {str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for base in ['src','built/local'] for p in sorted((tree/base).rglob('*')) if p.is_file()}
def child_run(command,log,env=None,timeout=1300):
 with log.open('w') as f:
  p=subprocess.Popen(command,stdout=f,stderr=f,cwd=repo,env=env,start_new_session=True)
  try:code=p.wait(timeout=timeout)
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
 return code
