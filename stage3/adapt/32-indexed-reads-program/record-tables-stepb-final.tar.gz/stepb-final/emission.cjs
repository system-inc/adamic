'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),ts=require('/workspace/adamic/stage3/api/node_modules/typescript');
const before='/workspace/scratch/gov-b/full-before',after='/workspace/scratch/gov-build/full-after',scratch='/workspace/scratch/gov-build',hash=t=>crypto.createHash('sha256').update(t).digest('hex');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const changed=[];for(const p of files(before+'/src')){const rel=path.relative(before,p),a=fs.readFileSync(p),b=fs.readFileSync(path.join(after,rel));if(!a.equals(b))changed.push(rel);}
assert.deepEqual(changed.sort(),['src/compiler/core.ts','src/compiler/symbolWalker.ts']);for(const f of changed)assert.equal(fs.readFileSync(after+'/'+f,'utf8'),fs.readFileSync(scratch+'/port/'+f,'utf8'));
const output={sourceFiles:files(before+'/src').length,sourceChanges:changed,stock:[],compiler:[],declarations:[]};
for(const file of ['core.ts','symbolWalker.ts'])for(const removeComments of [false,true]){
 const a=fs.readFileSync(before+'/src/compiler/'+file,'utf8'),b=fs.readFileSync(after+'/src/compiler/'+file,'utf8'),options={target:ts.ScriptTarget.ES2024,module:ts.ModuleKind.ESNext,removeComments};
 const original=ts.transpileModule(a,{fileName:file,compilerOptions:options}).outputText,actual=ts.transpileModule(b,{fileName:file,compilerOptions:options}).outputText;
 const expected=file==='core.ts'?original:ts.transpileModule(require('/workspace/adamic/stage3/adapt/32-indexed-reads-program/record-tables-proof.cjs').expected(a),{fileName:file,compilerOptions:options}).outputText;
 assert.equal(actual,expected);const stem=file+'.comments-'+!removeComments;fs.writeFileSync(scratch+'/raw/'+stem+'.before.js',original);fs.writeFileSync(scratch+'/raw/'+stem+'.after.js',actual);output.stock.push({file,removeComments,beforeHash:hash(original),afterHash:hash(actual),onlyApprovedPort:true,identical:original===actual});
}
const names=['_tsc.js','_tsserver.js','_typingsInstaller.js','tsc.js','tsserver.js','tsserverlibrary.js','typescript.js','typingsInstaller.js','watchGuard.js'];
for(const name of names){
 const a=fs.readFileSync(before+'/built/local/'+name,'utf8'),b=fs.readFileSync(after+'/built/local/'+name,'utf8');let expected=a,owners=[];
 const sf=ts.createSourceFile(name,a,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);function visit(n){if(ts.isFunctionDeclaration(n)&&n.name?.text==='getSymbolWalker')owners.push(n);ts.forEachChild(n,visit);}visit(sf);
 if(owners.length){assert.equal(owners.length,1);const owner=owners[0];let text=owner.getText(sf);for(const [from,to,count] of [['const visitedTypes = [];','const visitedTypes = {};',1],['const visitedSymbols = [];','const visitedSymbols = {};',1],['clear(visitedTypes);','for (const key in visitedTypes) delete visitedTypes[key];',2],['clear(visitedSymbols);','for (const key in visitedSymbols) delete visitedSymbols[key];',2]]){assert.equal(text.split(from).length,count+1);text=text.replaceAll(from,to);}expected=a.slice(0,owner.getStart(sf))+text+a.slice(owner.end);}
 assert.equal(b,expected,'unexpected JavaScript scope change: '+name);output.compiler.push({file:name,beforeHash:hash(a),afterHash:hash(b),identical:a===b,approvedOwners:owners.length});
}
for(const p of files(before+'/built/local').filter(p=>path.dirname(p)===before+'/built/local'&&p.endsWith('.d.ts'))){const name=path.basename(p),a=fs.readFileSync(p,'utf8'),b=fs.readFileSync(after+'/built/local/'+name,'utf8');let expected=a;if(name==='typescript.internal.d.ts'){const from='function getOwnValues<T>(collection: MapLike<T> | T[]): T[];',to='function getOwnValues<T>(collection: MapLike<T>): T[];';assert.equal(a.split(from).length,2);expected=a.replace(from,to);}assert.equal(b,expected,'unexpected declaration change: '+name);output.declarations.push({file:name,beforeHash:hash(a),afterHash:hash(b),identical:a===b});}
assert(output.declarations.find(r=>r.file==='typescript.d.ts').identical);assert(output.declarations.find(r=>r.file==='tsserverlibrary.d.ts').identical);
fs.writeFileSync(scratch+'/raw/emission.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify({pass:true,sourceChanges:changed,nineCompilerFiles:output.compiler.map(r=>({file:r.file,identical:r.identical})),declarationChanges:output.declarations.filter(r=>!r.identical).map(r=>r.file)}));
