from stepb_common import *
import base64,collections
plan=json.loads((repo/'stage3/lane/shard-plan.json').read_text());lane=json.loads((out/'record-tables-after-lane.json').read_text());assert lane['complete'] and len(lane['completedUnits'])==398 and lane['completedUnits']==[u['name'] for u in plan['units']];assert lane['counts']==plan['counts'];totals=collections.Counter();reports=set();maxSeconds=0

def open_checked(name,folder):
 archive=out/(name+'.tar.gz');assert hashlib.sha256(archive.read_bytes()).hexdigest()==(out/(name+'.sha256')).read_text().split()[0];tf=tarfile.open(archive)
 for line in tf.extractfile(folder+'/SHA256SUMS').read().decode().splitlines():
  h,name=line.split('  ',1);assert hashlib.sha256(tf.extractfile(folder+'/'+name).read()).hexdigest()==h
 return tf
for piece in lane['pieces']:
 n=piece['piece'];assert not piece['failed'] and piece['seconds']<1500;maxSeconds=max(maxSeconds,piece['seconds'])
 sources=[(f'record-tables-after-lane-{n:02d}','packed',piece.get('firstAttempt',piece))]
 if n==2 and 'firstAttempt' in piece:sources.append(('record-tables-after-lane-02-retry','lane-piece-02-retry',piece))
 for archive,folder,expected in sources:
  with open_checked(archive,folder) as tf:
   assert json.loads(tf.extractfile(folder+'/piece.json').read())==expected
   for line in tf.extractfile(folder+'/evidence.jsonl'):
    row=json.loads(line);raw=row['text'].encode('utf8') if 'text' in row else base64.b64decode(row['base64'])
    if 'sha256' in row:assert hashlib.sha256(raw).hexdigest()==row['sha256'] and len(raw)==row['size']
    if row['path']=='report.json':
     report=json.loads(raw)
     if report['status']!='pass':
      assert n==2 and folder=='packed' and row['unit']=='stage3-lane-file-013' and expected['failed'][0]['report']==report and report['failures'][0]['cause']=='timeout';continue
     assert row['unit'] not in reports;reports.add(row['unit']);assert not report['errors'];totals.update(report['counts'])

assert len(reports)==398 and dict(totals)==plan['counts']
census=json.loads((out/'record-tables-census.json').read_text());allpairs=[]
for n,size in enumerate([20,20,20,19],1):
 with open_checked(f'record-tables-census-{n}',f'paired-census-{n}') as tf:
  group=json.loads(tf.extractfile(f'paired-census-{n}/group.json').read());assert group['roots']==size and len(group['pairs'])==size and group['seconds']<1500;allpairs+=group['pairs']
assert allpairs==census and len(census)==79 and len({r['root'] for r in census})==79
moved=[r for r in census if r['before'].get('where','').endswith('core.ts:1326:26')];assert len(moved)==73 and all(r['after']['kind']=='NotYet' and r['after']['where'].endswith('core.ts:1364:29') and r['after']['reason']=='a non-object representation passed through an opaque object parameter' for r in moved)
for pair in census:
 if pair in moved:continue
 def normal(row,tree):
  return {k:(v.replace(str(tree),'TREE') if isinstance(v,str) else [x.replace(str(tree),'TREE') for x in v] if isinstance(v,list) else v) for k,v in row.items() if k!='seconds'}
 assert normal(pair['before'],before)==normal(pair['after'],after)
replay=json.loads((s/'raw/replay.json').read_text());summary=json.loads((s/'raw/replay-summary.json').read_text());assert summary['pass'] and summary['adapters']==len(replay)==len([p for p in (repo/'stage3/adapt').iterdir() if p.is_dir()]);assert all(r['before']==r['after'] for r in replay if r['adapter'] not in ['30-indexed-reads','32-indexed-reads-program'])
assert snapshot(after)==json.loads((s/'raw/lane-source-manifest.json').read_text())
wall=json.loads((s/'raw/lane-piece2-wall-time.json').read_text());assert wall['under25Minutes'] and wall['wallSecondsIncludingInspectionAndRetry']<1500
result={'allPass':True,'lane':{'units':398,'pieces':20,'counts':dict(totals),'maxPieceSeconds':maxSeconds,'allArchiveAndRawEvidenceHashesPass':True,'unexpectedTimeoutsRetained':1,'retriedUnits':['stage3-lane-file-013'],'noTimeoutWaiver':True,'retryPieceWallSeconds':wall['wallSecondsIncludingInspectionAndRetry']},'census':{'roots':79,'groups':[20,20,20,19],'moved73':len(moved),'next':'core.ts:1364:29','otherSixUnchanged':True},'replay':summary,'immutableFreshSourceAndBuild':True};(s/'raw/reconciled.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
