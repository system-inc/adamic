from stepb_common import *
import shutil,collections
proof=json.loads((s/'raw/reconciled.json').read_text());assert proof['allPass'];emission=json.loads((s/'raw/emission.json').read_text());replay=json.loads((s/'raw/replay-summary.json').read_text());census=json.loads((s/'raw/census-summary.json').read_text());measure=json.loads((repo/'stage3/adapt/32-indexed-reads-program/record-tables-reconciled.json').read_text());types=json.loads((s/'raw/types-after.json').read_text());assert types['exit']==0
proof.update(ruling='b5w3ycg, Nov 7 00:55Z, road (b)',originMain='61880be6dd7884dec15cf17c73fd9d56ee760ee4',elementAtDependency='efa9c7dd7ffd4504068e6beeae26a2365eb145f1',owners={'symbolWalker':'32-indexed-reads-program','getOwnValues':'30-indexed-reads'},bothFullAppliesExit0=True,bothOwnerVerifiersPass=True,types79BeforeAndAfterExit0=True,measurement={k:v for k,v in measure.items() if k!='units'},publicDeclarationsIdentical=['typescript.d.ts','tsserverlibrary.d.ts'],internalDeclarationsOnlyApprovedGetOwnValuesLine=True,internalTableTypesDoNotSurface=True,nineJavaScriptFilesOnlyTablePort=True,coreJavaScriptIdenticalBothCommentModes=True,witnessFreshness=json.loads((s/'raw/witness-freshness.json').read_text()),bothSourceMutantsRed=True,mutantFreshScope=json.loads((s/'raw/mutant-fresh-scope.json').read_text()),adamicCompilerSourceModified=False,loomSubmitted=False)
(out/'PROOF-RECORD-TABLES-STEP-B.json').write_text(json.dumps(proof,indent=2)+'\n');shutil.copyfile(s/'raw/contracts.json',out/'record-tables-contracts.json');shutil.copyfile(s/'contracts.cjs',out/'record-tables-contracts.cjs')
p=out/'record-tables-composition.json';composition=json.loads(p.read_text());composition.update(pairedReplay='passed; all outcomes identical',amendedCensus='passed; 73 reach 1364:29, six unchanged',normalLane='passed; all 398 units, one original timeout retained with guarded retry');p.write_text(json.dumps(composition,indent=2)+'\n')
stop=json.loads((s/'raw/next-stop-source.json').read_text());source=stop['source'].replace('\r\n','\n');lane=proof['lane'];wall=json.loads((s/'raw/lane-piece2-wall-time.json').read_text())
text=f'''# Record table amendment, step B: PASS

Ledger: Adamic ruling **task b5w3ycg, Nov 7 00:55Z, road (b)**.
JavaScript-changing. Base: origin/main 61880be6dd7884dec15cf17c73fd9d56ee760ee4,
with exact 99z efa9c7dd7ffd4504068e6beeae26a2365eb145f1 retained. Every new
commit has the required chg_yj14ddxz dependency line. No Adamic compiler change or
Loom submission is part of this work.

## Owners and exact change

32 pins symbolWalker's visitedTypes[type.id] and visitedSymbols[symbolId]
test/store pairs. Its amendment makes both private tables const MapLike
records, replaces all four array-clear calls with in-place for-in deletion,
removes clear's import and adds a type-only MapLike import. The complete
nested getSymbolWalker owner and import are pinned before and after, at both
pre-43 void and completed undefined return phases. The original four id
reads/tests/stores keep their evaluation points and declines; four pure-delete
operands join the complete indexed-expression inventory. Container identity,
accept callbacks, traversal and finally cleanup remain in place.

30 owns getOwnValues's read. Its whole-owner pins accept the exact raw,
asserted-before and record-only-after forms. The parameter is MapLike<T>
and the read is collection[key]!, with the existing loud presence check and
no cast. Both planners validate all their files before writing. Eight
half-adapted/foreign-body owner mutants require the owning validator's exact
refusal reason. No 99ab or compatibility overload is introduced.

The fresh output matches the measured source, with only the measurement
walker's LF normalized to production CRLF. Native witness freshness checks
match the complete helper, both table declarations, the exact id read/test/store
operations and both cleanup blocks. The existing Node, sanitized native
(--sanitize --explain-checks) and JavaScript witness results are retained:
id 5, ids inserted 4468, 2, 10, and empty/reused tables all match byte for byte.
Already-assigned positive witness ids take getSymbolId's unchanged return path.

## Measurement first

The complete measurement was pushed at 87027cdf7 before any amendment.
All 398 paired lane shards and 1109 calls matched, including all 445 sparse
calls. Baseline arrays: 692; candidate arrays: 0. Returned elements: 1985;
id stores: 734 per side. Non-integer ids, noncanonical keys, order/value
differences and within-run identity failures: all 0. The measured service
action records have complete primitive payload comparisons; Type/Symbol
values preserve ids and own primitive/reference metadata. The independent
reconciler verifies every raw trace, archive hash and all 796 reports.

## Composition and emission

Both full applies pass on the same frozen base. The baseline full apply and
build are retained from measurement; the amended full apply and compiler/harness
build are fresh. Exactly core.ts and symbolWalker.ts differ across all 746
source files. Full-apply patch accounting changes only rows 30 and 32 plus
its total. Both normal owner verifiers pass at their actual immutable
before/after apply snapshots. Adamic types over all 79 compiler roots exits 0
before and after.

All {replay['adapters']} paired replay outcomes are exactly identical, including
{replay['inheritedNonzeroOutcomesPerSide']} inherited nonzero outcomes per side.
Neither copied source tree changes. Completed-tree replay still refuses 30
at the later addRange assertion and 32 at appendSourceMap's later runtime
change; these are identical baseline outcomes. They are distinguished from
the passing normal verifiers at the owning phases.

Core JavaScript is byte-identical with comments kept and removed. An
independent literal port produces exactly the symbolWalker JavaScript in
both modes. Of nine compiler JavaScript products, seven are byte-identical;
only _tsc.js and typescript.js change, solely in the two table initializers
and four cleanup statements within getSymbolWalker. A full-file byte comparison
checks that no other emitted byte changes. [All exact source and emitted
hunks](record-tables-hunks.patch) are shown as valid zero-context patches.

Both public declarations, typescript.d.ts and tsserverlibrary.d.ts, are
byte-identical. Every other declaration is also identical except this one
user-approved hunk in typescript.internal.d.ts; private table types do not
surface there:

```diff
-function getOwnValues<T>(collection: MapLike<T> | T[]): T[];
+function getOwnValues<T>(collection: MapLike<T>): T[];
```

## Normal whole lane and mutants

All 398 ordinary shards pass, in 20 pieces, each committed and plainly pushed.
Final counts: 106366 passes, the same 1 expected failure, 0 skips. The unchanged
identity, API, baseline, count and source/build guards remain enabled.
No measurement observers are present. The independent reconciler reopens every
archive, checks all hashes and every unique report, and verifies the frozen
source and build after completion.

One hook timeout during concurrent checks is retained, not waived:
file-013/templateLiteralTypes1's before-all hook exceeded its existing 40-second
limit in piece 2. The other 19 passing shards were retained. Only file-013 was
retried, in a fresh output directory, with the same 40-second hook and
90-second shard limits; it passed in {wall['retrySeconds']:.3f} seconds. The
complete piece including inspection and retry took
{wall['wallSecondsIncludingInspectionAndRetry']:.3f} seconds, below 25 minutes.
Lane concurrency was reduced while replay/census ran, then restored when both
finished. Final lane counts include the successful guarded run; the original
failed report remains in the first piece-2 archive and firstAttempt ledger.
A retry-wrapper output-directory collision ran no tests and is also retained.

The first passing lane checkpoint was briefly blocked by whitespace-only
context lines in the review patch. The corrected zero-context patch and that
checkpoint were plainly pushed together. The writer now checks a clean index
and unstages its own paths after a failed check. No source, test, guard or
limit changed. The raw publication and failure logs remain archived.

Restoring the complete sparse-table owner produces four TS2345 errors at the
now record-only helper calls. Restoring the original helper union and cast
passes checking and both ordinary binder rows return Refused at
core.ts:1326:26, a cast the runtime cannot check. A cast restored alone with
the new parameter is also rejected by the whole-owner contract; it is not
misrepresented as a downcast. Each source mutant differs from the fresh
output only in its intended restored file; all other source bytes match.

## Ordinary census and next group

All 79 roots are paired in groups of 20, 20, 20 and 19, each committed and
plainly pushed. The baseline retains 47 exact ordinary observations and measures
the remaining 32; the retained source manifest is unchanged. All amended roots
are measured on the fresh full apply. The driver's inspect function is
byte-for-byte the normal stage3/census/tool implementation: ordinary Load,
then ordinary Lower only if checking succeeds. Its one-file Go overlay changes
only main's enumeration to bounded independent roots; no compiler, checker,
refusal, or backend code is overlaid. All authored Go is .go.txt.

All 73 roots formerly refused at 1326:26 now reach **NotYet
core.ts:1364:29**, assign's argument arg in hasProperty(arg, p). The other
six root outcomes are unchanged. The exact next source is:

```ts
{source}
```

The unchanged rule is (*lowering).detachedOwnRefusal, declared at
internal/lower/detached_own.go:69, constructing this NotYet at line 94:
`a non-object representation passed through an opaque object parameter`.
It is registered as ordinal 900 at line 144. The opaque object slot requires
an Object representation; this branch stops when representation is unknown
or different. [Exact source, rule and line](record-tables-next-stop.json),
[every paired root](record-tables-census.json) and the four archives retain
the complete evidence. assign and elementAt are untouched by this amendment.

## Evidence

PROOF-RECORD-TABLES-STEP-B.json is the final machine-readable result.
record-tables-composition, owner-mutants, replay, census and after-lane archives
retain raw evidence with internal SHA256SUMS and adjacent archive hashes.
record-tables-stepb-final retains all drivers, final reconciliation and raw
closeout logs. Historical measurement and earlier-road artifacts remain
unchanged. This continuation's changes stay inside adaptations 30 and 32 and
under 200 files relative to its frozen base. No started process is left running.
'''
(out/'RECORD-TABLES-PROOF.md').write_text(text)
p=out/'MEASURE-RECORD-TABLES.md';old=p.read_text();old+='''
## Continuation after the declaration clarification

The user accepted the single internal signature hunk and clarified that the
two public files are typescript.d.ts and tsserverlibrary.d.ts. The original
measurement stop above is historical. Step B is now complete and passes;
see [the final amendment proof](RECORD-TABLES-PROOF.md) and
PROOF-RECORD-TABLES-STEP-B.json for the current result.
''';p.write_text(old)
# Preserve exact closeout input bytes and complete driver code; large per-piece
# evidence is already independently archived rather than duplicated here.
provenance={'headBeforeFinal':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip(),'scopedPaths':subprocess.check_output(['git','diff','--name-only','36ab92279','--','stage3/adapt'],cwd=repo,text=True).splitlines(),'dependencyLines':subprocess.check_output(['git','log','--format=%s','36ab92279..HEAD'],cwd=repo,text=True).splitlines()}
assert all(x==prefix for x in provenance['dependencyLines']);assert subprocess.run(['git','diff','--quiet','36ab92279','--','internal','cmd','runtime','stage3/api','stage3/apply.py'],cwd=repo).returncode==0
(s/'raw/provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
d=s/'stepb-final';d.mkdir();shutil.copytree(s/'raw',d/'raw')
for name in ['contracts.cjs','mutants.cjs','probe-mutants.py','stepb_common.py','lane.py','replay.py','census-after.py','resume-before.py','verify-owners.py','emission.cjs','next-stop.cjs','witness-freshness.cjs','reconcile.py','retry-lane-piece2.py','finalize.py']:shutil.copyfile(s/name,d/name)
shutil.copyfile(b/'census-batch.go.txt',d/'census-batch.go.txt')
shutil.copyfile(s/'lane-retry-output-collision/retry.log',d/'retry-output-collision-child.log')
for label,tree in [('before',before),('after',after)]:
 for name in ['core.ts','symbolWalker.ts']:
  p=d/label/name;p.parent.mkdir(exist_ok=True);shutil.copyfile(tree/'src/compiler'/name,p)
# Normal driver prefix is unchanged; no compiler overlay was introduced.
assert (repo/'stage3/census/tool/main.go').read_text().split('func main() {')[0]==(d/'census-batch.go.txt').read_text().split('func main() {')[0]
paths=pack(d,'record-tables-stepb-final')+[out/n for n in ['PROOF-RECORD-TABLES-STEP-B.json','RECORD-TABLES-PROOF.md','MEASURE-RECORD-TABLES.md','record-tables-composition.json','record-tables-contracts.json','record-tables-contracts.cjs']]
changed=subprocess.check_output(['git','diff','--name-only','36ab92279','--','stage3/adapt'],cwd=repo,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','stage3/adapt'],cwd=repo,text=True).splitlines();allpaths=set(changed+untracked);assert len(allpaths)<200 and all(p.startswith(('stage3/adapt/30-indexed-reads/','stage3/adapt/32-indexed-reads-program/')) for p in allpaths)
publish(paths,'Complete road (b): all full-apply, owner, replay, type, emission, declaration, native/JS witness, mutant, whole-lane and paired-census checks pass. Retain the unchanged-limit hook timeout and guarded retry; all 73 roots advance to core.ts:1364:29.')
print(json.dumps({'pass':True,'filesThisContinuation':len(allpaths),'lane':lane,'replayAdapters':replay['adapters'],'nextStop':'core.ts:1364:29'},indent=2))
