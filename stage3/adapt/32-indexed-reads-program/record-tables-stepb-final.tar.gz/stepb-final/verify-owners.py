from pathlib import Path
import subprocess,tarfile,io,json,os,time
s=Path('/workspace/scratch/gov-build');repo=Path('/workspace/adamic');tree=s/'full-after';rows=[]
for owner in ['30-indexed-reads','32-indexed-reads-program']:
 dirs={}
 for phase in ['before','after']:
  ref='refs/stage3/'+owner+'-'+phase;target=s/(owner+'-'+phase);target.mkdir();data=subprocess.check_output(['git','-C',str(tree),'archive',ref,'src'])
  with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(target,filter='data')
  (target/'node_modules').symlink_to(repo/'stage3/typescript/node_modules',target_is_directory=True);dirs[phase]=target
 start=time.monotonic()
 with (s/'raw'/(owner+'-verify.log')).open('w') as log:r=subprocess.run(['node',repo/'stage3/adapt'/owner/'verify.cjs',dirs['before'],dirs['after']],env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules')),stdout=log,stderr=log,timeout=240)
 rows.append({'owner':owner,'exit':r.returncode,'seconds':time.monotonic()-start,'refs':{phase:subprocess.check_output(['git','-C',str(tree),'rev-parse','refs/stage3/'+owner+'-'+phase],text=True).strip() for phase in dirs}});(s/'raw/owner-verification.json').write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0,owner
print('PASS both owner verifiers at actual full-apply phases',flush=True)
