from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,os,time,signal
s=Path('/workspace/scratch/gov-build');b=Path('/workspace/scratch/gov-b');tree=b/'full-before/src/compiler';roots=sorted(str(p) for p in tree.rglob('*.ts'));rows={}
for p in b.glob('census-before-*/rows-*.jsonl'):
 for line in p.read_text().splitlines():
  r=json.loads(line);assert len(r['roots'])==1;rows[r['roots'][0]]=r
assert len(rows)==47
missing=[p for p in roots if p not in rows];(s/'raw/census-before-reused.json').write_text(json.dumps({'reused':list(rows.values()),'missing':missing},indent=2)+'\n')
def run(item):
 n,paths=item;inp=s/'raw'/f'before-missing-{n}-roots.json';out=s/'raw'/f'before-missing-{n}.jsonl';inp.write_text(json.dumps(paths,indent=2)+'\n')
 with (s/'raw'/f'before-missing-{n}.log').open('w') as log:
  p=subprocess.Popen([b/'census-batch',inp,out],stdout=log,stderr=log,env=dict(os.environ,GOMAXPROCS='1',GOMEMLIMIT='3GiB'),start_new_session=True)
  try:code=p.wait(timeout=1400)
  finally:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
 assert code==0;return [json.loads(l) for l in out.read_text().splitlines()]
# Each inspector accepts <=20 independent roots. Four chunks balance two workers.
with ThreadPoolExecutor(max_workers=2) as pool:
 for got in pool.map(run,[(i,missing[i::4]) for i in range(4)]):
  rows.update({r['roots'][0]:r for r in got});(s/'raw/census-before.json').write_text(json.dumps(list(rows.values()),indent=2)+'\n')
assert set(rows)==set(roots) and len(rows)==79
print('COMPLETE 79 baseline roots, 47 retained exact ordinary observations plus 32 missing roots',flush=True)
