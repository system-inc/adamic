from pathlib import Path
import subprocess,json,time
s=Path('/workspace/scratch/gov-build');b=Path('/workspace/scratch/gov-b');r={}
for name in ['sparse','cast']:
 tree=s/('mutant-'+name);roots=sorted(str(p) for p in (tree/'src/compiler').rglob('*.ts'));assert len(roots)==79
 start=time.monotonic()
 with (s/'raw'/f'mutant-{name}-types.stdout').open('wb') as out,(s/'raw'/f'mutant-{name}-types.stderr').open('wb') as err:p=subprocess.run([b/'adamic','types',*roots],stdout=out,stderr=err,timeout=240)
 r[name]={'typesExit':p.returncode,'seconds':time.monotonic()-start};assert (p.returncode!=0)==(name=='sparse')
 if name=='cast':
  with (s/'raw/mutant-cast-binder.log').open('w') as log:p=subprocess.run([b/'tool',tree/'src/compiler/binder.ts',s/'raw/mutant-cast-binder.jsonl'],stdout=log,stderr=log,timeout=240)
  assert p.returncode==0;rows=[json.loads(l) for l in (s/'raw/mutant-cast-binder.jsonl').read_text().splitlines()];assert len(rows)==2 and all(x['kind']=='Refused' and x['where'].endswith('core.ts:1326:26') and x['reason']=="a cast the runtime can't check" for x in rows);r[name]['ordinaryBinder']=rows
 (s/'raw/mutants.json').write_text(json.dumps(r,indent=2)+'\n')
print('BOTH RED: sparse parameter violations; cast restored at 1326:26',flush=True)
