from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil
repo=Path('/workspace/adamic');s=Path('/workspace/scratch/gov-b');out=repo/'stage3/adapt/32-indexed-reads-program';base='36ab92279';d=json.loads((s/'raw/measure-reconciled.json').read_text());assert d['wholeOraclePairPassed']
production=['30-indexed-reads/'+n for n in ['adapt.cjs','sites.json','whole-files.cjs','verify.cjs']]+['32-indexed-reads-program/'+n for n in ['adapt.cjs','sites.json','verify.cjs']]
unchanged={}
for name in production:
 p=repo/'stage3/adapt'/name;old=subprocess.check_output(['git','show',base+':stage3/adapt/'+name],cwd=repo);assert old==p.read_bytes();unchanged[name]=hashlib.sha256(old).hexdigest()
(s/'raw/implementation-unchanged.json').write_text(json.dumps(unchanged,indent=2)+'\n')
shutil.copyfile(s/'reconcile-measure.py',out/'record-tables-reconcile.py');shutil.copyfile(s/'census-before.py',out/'record-tables-census-before.py');shutil.copyfile(s/'census-batch.go.txt',out/'record-tables-census-batch.go.txt');shutil.copyfile(s/'raw/measure-reconciled.json',out/'record-tables-reconciled.json')
proof={'status':'MEASUREMENT PASSED; CONSTRUCTION STOPPED AT DECLARATION CONSTRAINT','ruling':'b5w3ycg, Nov 7 00:55Z, road (b)','originMain':'61880be6dd7884dec15cf17c73fd9d56ee760ee4','elementAtDependency':'efa9c7dd7ffd4504068e6beeae26a2365eb145f1','owners':{'symbolWalker':'32-indexed-reads-program','getOwnValues':'30-indexed-reads'},'measurement':{k:v for k,v in d.items() if k!='units'},'nodeWitnessesEqual':True,'sanitizedNativeWitnessesEqual':True,'javascriptBackendWitnessesEqual':True,'baselineFullApplyExit0':True,'baselineSourceFilesExactlyMatchUninstrumentedMeasurement':746,'types79BaselineExit':0,'types79CandidateExit':0,'ordinaryBinderBefore':'Refused core.ts:1326:26, a cast the runtime cannot check','ordinaryBinderCandidate':'NotYet core.ts:1364:29, a non-object representation passed through an opaque object parameter','declarations':json.loads((s/'raw/measured-declarations.json').read_text()),'constructionBlockedBecause':'The explicitly requested MapLike<T>-only parameter necessarily changes the internal declaration, conflicting with the requirement that both declaration files remain byte-identical. Clarification remains pending.','adapterImplementationUnchanged':True,'notPerformed':['adapter amendments and owner mutants','fresh amended full apply','amended paired replay','amended whole lane','amended per-file census'],'baselineCensusPrework':json.loads((s/'raw/census-stop.json').read_text())}
(out/'PROOF-RECORD-TABLES.json').write_text(json.dumps(proof,indent=2)+'\n')
p=out/'MEASURE-RECORD-TABLES.md';text=p.read_text();text=text.replace('# Record id tables, measurement first\n','# Record id tables, measurement first\n\nThe 73-root stop at core.ts:1326:26 requires elementAt\'s earlier wall to be\npast. Exact 99z is retained here; the ordinary baseline binder probe confirms\n1326:26 on this base.\n',1);text+='''
## Final measurement gate and stopping point

PASS: all 398 lane units ran exactly once on each side, in 20 pieces, each
committed and plain-pushed before adapter construction. The largest piece was
201.761 seconds. Every shard report passes its ordinary identity, API,
baseline and count guards. Each side has 106366 passes, the same 1 expected
failure and 0 skips. The independent reconciliation reopens every archive,
checks both layers of hashes, reconstructs all ordered process traces from
raw rows, and checks all 796 reports against the unchanged lane plan.

All 1109 calls match element for element and in order, including all 445
formerly sparse calls. The baseline has 692 array calls; the candidate has
zero. There are 1985 returned elements and 734 id stores per side, zero
non-integer ids, zero noncanonical own keys, zero order/value differences,
and zero within-run reference identity failures. The service action records'
complete primitive fields are compared; Type and Symbol values retain their
ids and own primitive/reference metadata. No returned value order is sorted.
The generator assigns type ids by incrementing typeCount in createType and
symbol ids by incrementing nextSymbolId in getSymbolId (checker.ts).

The fresh unchanged full apply exits 0 and its 746 source files match the
uninstrumented baseline measurement exactly. Both the baseline and an
uninstrumented candidate source copy pass adamic types over all 79 compiler
roots, exit 0. Both ordinary binder rows agree on each side: baseline is
Refused at core.ts:1326:26; the measured candidate reaches NotYet at
core.ts:1364:29, assign's hasProperty(arg, p). The exact source is recorded in
record-tables-candidate-probe.json. (*lowering).detachedOwnRefusal constructs
this NotYet in internal/lower/detached_own.go:94. This is a binder observation,
not a claim that the amended 73-root census has been completed.

STOP before construction: the public declaration is byte-identical, but the
internal declaration has exactly the required parameter hunk documented
above. The record-only signature and byte-identical internal declaration
cannot both hold. No compatibility overload, false public signature or new
cast was introduced to conceal this. Clarification on that single internal
hunk was requested while measurement continued and remains pending.

The implementation files and site ledgers of 30 and 32 are unchanged. The
table port belongs in 32 and the helper amendment in 30; no 99ab was created.
No amended full apply, replay, lane, owner mutants or after census is claimed.
Optional baseline census prework completed and archived groups of 20 and 20
roots; its third group was stopped with 7 observations when construction was
blocked. The partial rows and stop ledger are retained, not counted as a
completed group. All started background measurement processes are stopped.

PROOF-RECORD-TABLES.json records this exact status. record-tables-final-measure
tarball retains the final raw logs, source bytes, manifests, provenance,
independent reconciler, ordinary census driver and partial prework. Its
adjacent SHA256 and internal SHA256SUMS cover the archive and every member.
No source change or result is submitted to Loom.
''';p.write_text(text)
pack=s/'final-measure';pack.mkdir();
for source in [s/'raw',s/'census-before-3']:
 if source.exists():shutil.copytree(source,pack/source.name)
for name in ['reconcile-measure.py','census-before.py','census-batch.go.txt','finalize-measure.py']:shutil.copyfile(s/name,pack/name)
for side in ['full-before','candidate-probe']:
 for name in ['core.ts','symbolWalker.ts']:
  q=pack/side/name;q.parent.mkdir(exist_ok=True);shutil.copyfile(s/side/'src/compiler'/name,q)
(pack/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(pack))+'\n' for p in sorted(pack.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
archive=out/'record-tables-final-measure.tar.gz';temp=s/'final-measure.tar.gz'
with tarfile.open(temp,'w:gz') as tf:tf.add(pack,arcname='final-measure')
temp.replace(archive);(out/'record-tables-final-measure.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print(json.dumps({'status':proof['status'],'measurement':proof['measurement'],'implementationUnchanged':True},indent=2))
