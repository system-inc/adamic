const hasOwnProperty = Object.prototype.hasOwnProperty;
function getSymbolId(symbol) { return symbol.id; }
export function getOwnValues(collection) {
    const values = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]);
        }
    }
    return values;
}
function makeWalker() {
    const visitedTypes = {};
    const visitedSymbols = {};
    function visitType(type) {
        if (!type) {
            return;
        }
        if (visitedTypes[type.id]) {
            return;
        }
        visitedTypes[type.id] = type;
    }
    function visitSymbol(symbol) {
        if (!symbol) {
            return false;
        }
        const symbolId = getSymbolId(symbol);
        if (visitedSymbols[symbolId]) {
            return false;
        }
        visitedSymbols[symbolId] = symbol;
        return false;
    }
    return (types, symbols) => {
        try {
            for (const type of types)
                visitType(type);
            for (const symbol of symbols)
                visitSymbol(symbol);
            return { visitedTypes: getOwnValues(visitedTypes), visitedSymbols: getOwnValues(visitedSymbols) };
        }
        finally {
            for (const key in visitedTypes)
                delete visitedTypes[key];
            for (const key in visitedSymbols)
                delete visitedSymbols[key];
        }
    };
}
function show(pair) { console.log('types=' + String(pair.visitedTypes.length)); for (const item of pair.visitedTypes)
    console.log(String(item.id) + ':' + item.name); console.log('symbols=' + String(pair.visitedSymbols.length)); for (const item of pair.visitedSymbols)
    console.log(String(item.id) + ':' + item.name); }
const walk = makeWalker();
show(walk([{ id: 4468, name: 'Tlarge' }, { id: 2, name: 'Ttwo' }, { id: 10, name: 'Tten' }], [{ id: 4468, name: 'Slarge' }, { id: 2, name: 'Stwo' }, { id: 10, name: 'Sten' }]));
show(walk([], []));
