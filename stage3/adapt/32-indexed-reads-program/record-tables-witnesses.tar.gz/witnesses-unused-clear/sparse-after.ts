export interface MapLike<T>{[key:string]:T;}
interface Type{readonly id:number;name:string;}
interface Symbol{readonly id:number;name:string;}
interface Pair{visitedTypes:Type[];visitedSymbols:Symbol[];}
const hasOwnProperty=Object.prototype.hasOwnProperty;
function getSymbolId(symbol:Symbol):number{return symbol.id;}
export function clear(array: unknown[]): void {
    array.splice(0);
}
export function getOwnValues<T>(collection: MapLike<T>): T[] {
    const values: T[] = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]!);
        }
    }

    return values;
}
function makeWalker(){const visitedTypes: MapLike<Type> = {};
const visitedSymbols: MapLike<Symbol> = {};
function visitType(type:Type|undefined):undefined{if (!type) {
                return;
            }
if (visitedTypes[type.id]) {
                return;
            }
visitedTypes[type.id] = type;}
function visitSymbol(symbol:Symbol|undefined):boolean{if (!symbol) {
                return false;
            }
const symbolId = getSymbolId(symbol);
if (visitedSymbols[symbolId]) {
                return false;
            }
visitedSymbols[symbolId] = symbol;return false;}
return (types:readonly Type[],symbols:readonly Symbol[]):Pair=>{try{for(const type of types)visitType(type);for(const symbol of symbols)visitSymbol(symbol);return {visitedTypes:getOwnValues(visitedTypes),visitedSymbols:getOwnValues(visitedSymbols)};}finally{
                    for (const key in visitedTypes) delete visitedTypes[key];
                    for (const key in visitedSymbols) delete visitedSymbols[key];
                }};}
function show(pair:Pair){console.log('types='+String(pair.visitedTypes.length));for(const item of pair.visitedTypes)console.log(String(item.id)+':'+item.name);console.log('symbols='+String(pair.visitedSymbols.length));for(const item of pair.visitedSymbols)console.log(String(item.id)+':'+item.name);}
const walk=makeWalker();
show(walk([{id:5,name:'type-x'}],[{id:5,name:'symbol-x'}]));
show(walk([],[]));
