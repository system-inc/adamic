const hasOwnProperty = Object.prototype.hasOwnProperty;
function getSymbolId(symbol) { return symbol.id; }
export function clear(array) {
    array.splice(0);
}
export function getOwnValues(collection) {
    const values = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]);
        }
    }
    return values;
}
function makeWalker() {
    const visitedTypes = [];
    const visitedSymbols = [];
    function visitType(type) {
        if (!type) {
            return;
        }
        if (visitedTypes[type.id]) {
            return;
        }
        visitedTypes[type.id] = type;
    }
    function visitSymbol(symbol) {
        if (!symbol) {
            return false;
        }
        const symbolId = getSymbolId(symbol);
        if (visitedSymbols[symbolId]) {
            return false;
        }
        visitedSymbols[symbolId] = symbol;
        return false;
    }
    return (types, symbols) => {
        try {
            for (const type of types)
                visitType(type);
            for (const symbol of symbols)
                visitSymbol(symbol);
            return { visitedTypes: getOwnValues(visitedTypes), visitedSymbols: getOwnValues(visitedSymbols) };
        }
        finally {
            clear(visitedTypes);
            clear(visitedSymbols);
        }
    };
}
function show(pair) { console.log('types=' + String(pair.visitedTypes.length)); for (const item of pair.visitedTypes)
    console.log(String(item.id) + ':' + item.name); console.log('symbols=' + String(pair.visitedSymbols.length)); for (const item of pair.visitedSymbols)
    console.log(String(item.id) + ':' + item.name); }
const walk = makeWalker();
show(walk([{ id: 5, name: 'type-x' }], [{ id: 5, name: 'symbol-x' }]));
show(walk([], []));
