"""Transfer the progressing apply from a generic 25-minute cap to a 15-minute finishing cap."""
import os,signal,time,json
from pathlib import Path
s=Path('/workspace/scratch/debug-messages');parent=16038;child=16061;start=time.monotonic();os.kill(parent,signal.SIGSTOP);last=start;size=-1;reason='child completed';last_tick=start
try:
 while True:
  try:state=Path(f'/proc/{child}/stat').read_text().split()[2]
  except FileNotFoundError:break
  if state=='Z':break
  p=s/'raw/after-apply.log';current=p.stat().st_size
  if current!=size:size=current;last=time.monotonic()
  if time.monotonic()-start>900 or time.monotonic()-last>1800:
   reason='finishing controller limit';os.killpg(child,signal.SIGTERM);time.sleep(5)
   try:os.killpg(child,signal.SIGKILL)
   except ProcessLookupError:pass
   break
  if time.monotonic()-last_tick>30:print('apply progressing under finishing controller, log bytes',current,flush=True);last_tick=time.monotonic()
  time.sleep(2)
finally:
 os.kill(parent,signal.SIGCONT)
 (s/'raw/apply-controller-transfer.json').write_text(json.dumps({'parent':parent,'child':child,'initialParentTemporarilyPaused':True,'parentResumedForOwnChildExit':True,'additionalLimitSeconds':900,'seconds':time.monotonic()-start,'endReason':reason},indent=2)+'\n')
print('apply parent resumed to record its own child exit',flush=True)
