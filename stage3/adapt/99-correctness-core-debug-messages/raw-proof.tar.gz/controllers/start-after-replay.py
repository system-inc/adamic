import sys,time,json
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/scratch/debug-messages')
from work import run,s,repo
start=time.monotonic()
while not (s/'raw/after-apply.json').exists():
 if time.monotonic()-start>1490:raise SystemExit('apply wait bound')
 time.sleep(2)
assert json.loads((s/'raw/after-apply.json').read_text())['exit']==0
run('after-replay',['python3',repo/'stage3/adapt/99-correctness-core-debug-messages/replay.py','after'])
