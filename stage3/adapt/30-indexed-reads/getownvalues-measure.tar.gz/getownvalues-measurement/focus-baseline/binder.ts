import { getOwnValues } from "./core";
console.log(String(getOwnValues({ a: 1 }).length));
