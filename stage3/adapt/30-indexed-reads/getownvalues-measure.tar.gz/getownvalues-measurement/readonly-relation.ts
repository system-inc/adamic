export interface MapLike<T> { [index: string]: T; }
export function view<T>(collection: MapLike<T> | T[]): Readonly<MapLike<T>> | readonly T[] {
    return collection as Readonly<MapLike<T>> | readonly T[];
}
console.log(String(view<number>([1]).length));
