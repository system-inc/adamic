export interface MapLike<T> { [index: string]: T; }
const hasOwnProperty = Object.prototype.hasOwnProperty;
export function getOwnValues<T>(collection: Readonly<MapLike<T>> | readonly T[]): T[] {
    const values: T[] = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]!);
        }
    }

    return values;
}
