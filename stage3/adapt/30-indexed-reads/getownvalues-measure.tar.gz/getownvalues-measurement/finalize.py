from pathlib import Path
import json,hashlib,shutil,tarfile,collections,re
s=Path('/workspace/scratch/gov');repo=Path('/workspace/adamic');unit=repo/'stage3/adapt/30-indexed-reads';raw=s/'evidence'
labels=['baseline','direct','readonly-view','readonly-parameter','readonly-record','record-parameter','generic-collection','keyof']
modes=['declared','adamic']
read=lambda name:json.loads((s/(name+'.json')).read_text())
key=lambda d:(d['code'],d['where'],d['message'])
summary={'qualification':'No candidate qualifies; stop after Step 1.','base':'8f4efea05dbe2183cd7347ad1bdbec409c016f2d','stock':{},'services':{},'ordinary':{},'focused':{}}
for mode in modes:
 base=read(mode+'-baseline');prior={key(d) for d in base['diagnostics']};summary['stock'][mode]={}
 assert len(base['roots'])==79
 for label in labels:
  d=read(mode+'-'+label)
  assert all(j['identical'] for j in d['javascript'])
  assert d['coreSourceSha256']==base['coreSourceSha256']
  summary['stock'][mode][label]={**{x:d[x] for x in ['collection','key','receiver','access','argument','casts','javascript']},'diagnosticCount':len(d['diagnostics']),'addedDiagnostics':[x for x in d['diagnostics'] if key(x) not in prior],'removedDiagnostics':[x for x in base['diagnostics'] if key(x) not in {key(y) for y in d['diagnostics']}],'callers':d['callers']}
 for label in ['baseline','readonly-parameter','readonly-record','record-parameter']:
  d=read('services-'+mode+'-'+label);base=read('services-'+mode+'-baseline');prior={key(x) for x in base['diagnostics']}
  summary['services'][mode+'-'+label]={'diagnosticCount':len(d['diagnostics']),'addedDiagnostics':[x for x in d['diagnostics'] if key(x) not in prior],'callers':d['callers'],'roots':len(d['roots'])}
 assert len(summary['services'][mode+'-baseline']['callers'])==7
 added=summary['services'][mode+'-readonly-parameter']['addedDiagnostics'];assert len(added)==1 and added[0]['code']==7053 and added[0]['where']=='src/compiler/core.ts:1326:25'
for kind,suffix in [('ordinary','binder'),('focused','focus')]:
 for label in labels:
  rows=[json.loads(line) for line in (s/(label+'-'+suffix+'.jsonl')).read_text().splitlines()]
  assert len(rows)==2
  canonical=lambda d:{k:v for k,v in d.items() if k not in ['seconds','roots']}
  assert canonical(rows[0])==canonical(rows[1])
  summary[kind][label]=rows[0]
assert summary['ordinary']['baseline']['where'].endswith('/core.ts:1076:100')
assert summary['focused']['baseline']['where'].endswith('/core.ts:7:26')
assert summary['focused']['record-parameter']['kind']=='accepted'
summary['readonlyRelation']=[json.loads(x) for x in (s/'relation.jsonl').read_text().splitlines()][0]
summary['callers']=read('services-declared-baseline')['callers']
(unit/'getownvalues-results.json').write_text(json.dumps(summary,indent=2)+'\n')
# Copy only evidence, not complete candidate trees or installed dependencies.
for mode in modes:
 for label in labels:shutil.copyfile(s/f'{mode}-{label}.json',raw/f'{mode}-{label}.json')
 for label in ['baseline','readonly-parameter','readonly-record','record-parameter']:
  name=f'services-{mode}-{label}.json';shutil.copyfile(s/name,raw/name)
for suffix in ['binder','focus']:
 for label in labels:
  for ext in ['jsonl','log']:
   name=f'{label}-{suffix}.{ext}';shutil.copyfile(s/name,raw/name)
for label in labels:
 for name in ['core.ts','binder.ts']:
  target=raw/('focus-'+label);target.mkdir(exist_ok=True);shutil.copyfile(s/('focus-'+label)/name,target/name)
for name in ['run-measure.py','services.py','probe.py','focus.py','summarize.py','finalize.py','relation.jsonl','relation.log','checker-driver.log','services-driver.log','probe-driver.log','focus-driver.log','apply-before-ready.log','apply-before.log','build-tool-final.log','build-tool.log','upstream-npm.log']:
 shutil.copyfile(s/name,raw/name)
shutil.copyfile(s/'relation/core.ts',raw/'readonly-relation.ts')
for source,name in [('/workspace/scratch/gov-setup.log','setup.log'),('/workspace/scratch/gov-npm.log','api-install.log'),('/workspace/scratch/gov-clone-shallow.log','upstream-clone.log'),('/workspace/scratch/getownvalues-fetch.log','fetch-main.log')]:shutil.copyfile(source,raw/name)
# Final scope and tool environment provenance.
prov=json.loads((raw/'provenance.json').read_text());prov['candidateBinderGOMAXPROCS']=2;prov['stockCompilerRootCount']=79;prov['rawServiceDiagnosticsAreNotAServiceBuild']=True;(raw/'provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
# Human report.
code=lambda v:'`'+str(v).replace('|','\\|')+'`'
lines=[(s/'report-static.md').read_text(),'## Checker types and candidates\n']
lines += ['All spellings retain the existing `!`. The candidate definitions are:\n',
'* baseline: `(collection as MapLike<T>)[key]!`\n* direct: `collection[key]!`\n* readonly-view: `(collection as Readonly<MapLike<T>> | readonly T[])[key]!`\n* readonly-parameter: parameter `Readonly<MapLike<T>> | readonly T[]`, read `collection[key]!`\n* readonly-record: parameter `Readonly<MapLike<T>>`, read `collection[key]!`\n* record-parameter: parameter `MapLike<T>`, read `collection[key]!`\n* generic-collection: `<T, C extends MapLike<T> | T[]>(collection: C)`, read `collection[key]!`\n* keyof: `collection[key as keyof typeof collection]!`, a non-qualifying assertion control\n',
'| Candidate | collection at read | key at read | Indexed type, es2020 | Indexed type, es2024 | Type after !, es2024 |\n| --- | --- | --- | --- | --- | --- |']
for label in labels:
 a=read('declared-'+label);b=read('adamic-'+label)
 lines.append('| '+' | '.join([label,code(a['collection']['type']),code(a['key']['type']),code(a['access']['type']),code(b['access']['type']),code(b['argument']['type'])])+' |')
lines+=['\nThe `any` entries are checker error types accompanied by TS7053. They are not admitted `any` bridges. In the keyof control the variable itself remains string; the asserted index type is recorded in the raw casts array. The readonly receiver view is TypeScript-assignable from the original union; the original member cast and keyof assertion are not upcasts.\n',
'| Candidate | New diagnostics relative to each stock baseline | Qualification |\n| --- | --- | --- |']
qual={'baseline':'Original refused member downcast','direct':'No string index common to both members','readonly-view':'Same TS7053; separate storage-view gate also stops it','readonly-parameter':'All seven calls retain compatible arguments, but body fails','readonly-record':'All four sparse-array compiler calls fail','record-parameter':'All four sparse-array compiler calls fail','generic-collection':'Precise key, value not proven T','keyof':'Still TS7053; adds an assertion rather than a proof'}
for label in labels:
 added=summary['stock']['declared'][label]['addedDiagnostics'];desc='none' if not added else '; '.join(f"TS{d['code']} at {d['where'].removeprefix('src/compiler/')}" for d in added)
 lines.append('| '+label+' | '+desc+' | '+qual[label]+' |')
lines+=['\nStock baseline totals: compiler declared options 0, compiler Adamic options 60; services source probe declared options 145, services Adamic options 2825. The exact diagnostics are retained. The strict source-service probe imports compiler source directly without building project-reference outputs. Its existing file-list, Node-global and strictness findings are not a successful service build. Stock TypeScript with the exact Adamic options also lacks Adamic\'s native Node/library overlay. These are distinct from the real Adamic loader, whose ordinary baseline binder probe passes checking and reaches Lower.\n',
'## Every source caller\n',
'`rg getOwnValues` over the complete adapted src tree finds exactly the following seven calls, plus imports and the definition. Each argument type is the same under both measured option sets.\n',
'| Call | Argument | Argument type |\n| --- | --- | --- |']
for c in summary['callers']:
 a=c['arguments'][0];lines.append('| '+c['where'].removeprefix('src/')+' | '+code(a['text'])+' | '+code(a['type'])+' |')
lines+=['\nThe four compiler calls use arrays explicitly documented as sparse id-to-value tables in symbolWalker.ts:45-46. A record-only signature rejects all four with TS2345 at argument columns 57 and 101 on lines 52 and 62. All three actions-object service calls continue to fit the record-only alternatives.\n',
'For the readonly union parameter, the full seven-call source probe adds exactly one diagnostic under either option set: TS7053 in getOwnValues at core.ts:1326:25. It adds no diagnostic at any caller and leaves the resolved element/result types unchanged. This checks call compatibility, while the body still fails; it does not claim a successful service build.\n',
'## Complete JavaScript bytes\n',
'All eight spellings are byte-identical to the baseline complete core.ts JavaScript in both comment modes and both target/lib measurements. Invalid candidates still fail their checker gates. The raw files retain source hashes, output sizes, hashes and equality results per candidate. Baseline hashes follow.\n',
'| Target | removeComments | Bytes | SHA-256 |\n| --- | --- | ---: | --- |']
for mode in modes:
 for j in read(mode+'-baseline')['javascript']:lines.append(f"| {mode} ({'ES2020' if mode=='declared' else 'ES2024'}) | {j['removeComments']} | {j['bytes']} | `{j['baselineHash']}` |")
def stop(d):
 if d['kind']=='checker':return 'checker: '+ '; '.join((lambda m:m.group(1)+' (TS'+m.group(2)+')')(re.search(r'([^/]+\.ts:\d+:\d+): error TS(\d+)',x)) for x in d['diagnostics'])
 return d['kind']+(': '+d.get('where','').split('/')[-1] if d.get('where') else '')+(': '+d.get('reason','') if d.get('reason') else '')
lines+=['\n## Ordinary binder and extracted-owner results\n',
'Each ordinary candidate probe uses the full completed src tree. Only its pinned function spelling differs. Both rows from the ordinary tool agree in every case apart from timing. No elementAt edit, substituted compiler, refusal scan or unchecked lowering of a rejected program is used.\n',
'| Candidate | Ordinary binder first stop | Extracted-owner first stop |\n| --- | --- | --- |']
for label in labels:lines.append('| '+label+' | '+stop(summary['ordinary'][label]).replace('|','\\|')+' | '+stop(summary['focused'][label]).replace('|','\\|')+' |')
lines+=['\nThe baseline ordinary binder stops at elementAt, core.ts:1076:100. Checker-rejected candidates stop before Lower, at their own diagnostics. No ordinary full-tree result here reaches 1326:26. The extracted baseline independently reproduces the same member-cast refusal at fixture core.ts:7:26. The mutable dictionary-only body lowers, but its full-tree callers fail. The readonly dictionary-only fixture stops NotYet at its parameter, core.ts:3:33, `a value of type Readonly<MapLike<T>>`.\n',
'The separate read-free readonly relation control passes the cast rule but stops at core.ts:3:12 in recordStorageView: `a T[] | MapLike<T> seen as Readonly<MapLike<T>> | readonly T[] (fixed objects and records have different storage; copy explicitly)`. The cast rule has ordinal 1900 and the storage-view rule ordinal 2000. TypeScript assignability alone therefore does not make this an admitted erased view.\n',
'## Why Lower refuses, and what it currently accepts\n',
'The reason text is constructed by castProof at internal/lower/cast_proof.go:188. castRefusal, lines 156-172, calls it and is registered at ordinal 1900. refuse in internal/lower/refusals.go:104 visits the registered rules. The upcast branch at cast_proof.go:219 asks provenRelation. The checked-interface fallback at lines 270-278 is restricted to a non-union source. For a union, the remaining path requires matching members, safe union writes and a common distinguishing literal/enum property (lines 294-335). MapLike<T> and T[] have no such discriminant, so the final refusal remains; an own-property test on the enumerated key does not distinguish those receiver representations.\n',
'The readonly relation control reaches recordStorageView, internal/lower/records.go:446-459, through the rule registered at line 503. sameRecordStorage at line 553 preserves the native storage kind. It cannot erase a mutable record into a readonly fixed-object representation just because TypeScript accepts the type relation.\n',
'For enumeration, forIn in internal/lower/library_for_in.go:13 rejects arrays at line 17 and requires a record, a supported readonly object view, a construction, or a proven fixed plain-object origin at lines 22-29. recordElement in records.go:12 requires an object with a pure mutable string index signature and excludes arrays. readonlyObjectView in records_entries.go:67 likewise requires an object view, not this array/dictionary union. There is no existing for-in read rule that turns this union and an arbitrary string key into T. A true mutable dictionary parameter admits the read, as the focused positive control shows, but the actual array calls preclude that contract.\n',
'The governing rulings are docs/rulings.md:9-18 (checked member casts, unchecked assertions, proven upcasts and checked views), :92 (mutable invariance and readonly covariance), :170 (enumeration over proven objects/records, arrays still NotYet), and :271 (record declared-key reads and writes). The existing `!` is the separately owned required-value check; it proves neither a dictionary receiver nor an enumerable array-key type. The older for-in statement at :260 must be read with the explicit Nov 1 ruling at :170.\n',
'## Decision and options requiring a ruling\n',
'No measured spelling satisfies all three gates: a true type with compatible callers, no new downcast, and an ordinary Adamic admission with byte-identical JavaScript. Stop after Step 1. No adapter amendment or Step 2 proof, mutant, paired replay, 79-root types gate, declaration comparison, nine-file emission comparison or grouped census is claimed.\n',
'1. Request an explicit language/lowering ruling for own-enumerable string-key reads over an array/dictionary union, including sparse holes, key order, named own enumerable array properties and the existing required-value check. The checker-facing type and native storage behavior both need a true contract.\n2. Ask Adamic to rule on a runtime implementation such as Object.values or explicit receiver/key checks. These change emitted JavaScript and may need new lowering support; no equivalence or admission is asserted here.\n3. Split the dictionary contract from sparse-array collection, with separately reviewed symbolWalker caller changes and a sparse-array implementation preserving own-key behavior. Removing arrays from the signature alone is already disproved by the four measured calls.\n\nNumeric key conversion, extra string index signatures on arrays and further key/member assertions are not type-only proofs of the original contract. Numeric conversion and Object.values were not measured or built in this run.\n',
'## Reproduction and retained evidence\n',
'Setup and the completed full apply both exited 0. The initial full-history clone was cancelled and replaced by the exact shallow v6.0.3 clone. An early apply attempted before checkout finished refused the missing pin; it made no accepted baseline. A duplicate probe build was stopped, then rebuilt successfully after sourcing setup\'s final build flags. The retained logs distinguish these attempts.\n',
'```sh\nsource /workspace/adamic-tools/env.sh\nbash cloud/setup.sh > /workspace/scratch/gov-setup.log 2>&1\nsource /workspace/adamic-tools/env.sh\nnpm ci --prefix stage3/api\nexport ADAMIC_TYPESCRIPT_SOURCE=/workspace/typescript-source\nstage3/apply.sh --build-product /workspace/scratch/gov/before\nnpm ci --prefix /workspace/scratch/gov/before\ngo build -o /workspace/scratch/gov/tool ./stage3/census/tool\n# Extract the evidence scripts into /workspace/scratch/gov, then:\npython3 /workspace/scratch/gov/run-measure.py\npython3 /workspace/scratch/gov/services.py\n/workspace/scratch/gov/tool /workspace/scratch/gov/before/src/compiler/binder.ts /workspace/scratch/gov/baseline-binder.jsonl\nGOMAXPROCS=2 python3 /workspace/scratch/gov/probe.py\npython3 /workspace/scratch/gov/focus.py\n```\n',
'Actual command outputs were written to files. The evidence archive includes the exact scripts, raw checker results, all ordinary/focused rows, source inventory, relevant Lower source as .go.txt, complete baseline core.ts, compiler provenance and logs. getownvalues-results.json is the readable aggregate. The archive has an external SHA-256 and an internal SHA256SUMS list. Measurement evidence changes product keys but introduces no adapter transformation. All processes started for this task have completed or were explicitly stopped.\n']
text='\n'.join(lines).rstrip()+'\n';assert '\u2013' not in text and '\u2014' not in text;(unit/'MEASURE.md').write_text(text)
(raw/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(raw).as_posix()+'\n' for p in sorted(raw.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
archive=unit/'getownvalues-measure.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tf.add(p,arcname='getownvalues-measurement/'+p.relative_to(raw).as_posix())
(unit/'getownvalues-measure.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
print('evidence files',sum(p.is_file() for p in raw.rglob('*')),'archive bytes',archive.stat().st_size)
