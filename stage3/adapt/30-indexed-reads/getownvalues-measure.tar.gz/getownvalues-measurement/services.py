from pathlib import Path
import subprocess,os
s=Path('/workspace/scratch/gov');repo=Path('/workspace/adamic')
env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules'),GETOWNVALUES_CONFIG='src/services/tsconfig.json')
for mode in ['declared','adamic']:
 for label in ['baseline','readonly-parameter','readonly-record','record-parameter']:
  with (s/f'services-{mode}-{label}.log').open('w') as log:
   r=subprocess.run(['node',repo/'stage3/adapt/30-indexed-reads/getownvalues-measure.cjs',s/'before',mode,label,s/f'services-{mode}-{label}.json'],env=env,stdout=log,stderr=log)
  assert r.returncode==0
  print(mode,label,flush=True)
