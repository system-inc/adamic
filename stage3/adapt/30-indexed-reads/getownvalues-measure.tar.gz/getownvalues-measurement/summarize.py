import json
from pathlib import Path
s=Path('/workspace/scratch/gov')
labels=['baseline','direct','readonly-view','readonly-parameter','readonly-record','record-parameter','generic-collection','keyof']
for mode in ['declared','adamic']:
 for label in labels:
  p=s/f'{mode}-{label}.json'
  if not p.exists():continue
  d=json.loads(p.read_text());owner=[x for x in d['diagnostics'] if x['where'] and x['where'].startswith('src/compiler/core.ts:') and (1300<=int(x['where'].split(':')[1])<=1345)]
  print(mode,label,'collection',d['collection']['type'],'key',d['key']['type'],'access',d['access']['type'],'diagnostics',len(d['diagnostics']),'owner',owner,'JS',[x['identical'] for x in d['javascript']])
  if label=='baseline':print('CALLERS',json.dumps(d['callers'],indent=2))
