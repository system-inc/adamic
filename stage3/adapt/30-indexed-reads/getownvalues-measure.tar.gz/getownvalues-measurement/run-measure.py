from pathlib import Path
import subprocess,json,shutil,os
repo=Path('/workspace/adamic'); s=Path('/workspace/scratch/gov'); unit=repo/'stage3/adapt/30-indexed-reads'; tree=s/'before'
env=dict(os.environ,NODE_PATH=str(repo/'stage3/api/node_modules'))
labels=['baseline','direct','readonly-view','readonly-parameter','readonly-record','record-parameter','generic-collection','keyof']
for mode in ['declared','adamic']:
 for label in labels:
  with (s/f'{mode}-{label}.log').open('w') as log:
   r=subprocess.run(['node',unit/'getownvalues-measure.cjs',tree,mode,label,s/f'{mode}-{label}.json'],env=env,stdout=log,stderr=log)
  if r.returncode:raise RuntimeError((mode,label,r.returncode))
  print(mode,label,flush=True)
