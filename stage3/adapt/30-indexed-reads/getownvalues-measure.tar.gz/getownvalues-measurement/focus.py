from pathlib import Path
import json,subprocess
s=Path('/workspace/scratch/gov')
for label in ['baseline','direct','readonly-view','readonly-parameter','readonly-record','record-parameter','generic-collection','keyof']:
 result=json.loads((s/f'declared-{label}.json').read_text())
 tree=s/('focus-'+label);tree.mkdir(exist_ok=True)
 header='export interface MapLike<T> { [index: string]: T; }\nconst hasOwnProperty = Object.prototype.hasOwnProperty;\n'
 (tree/'core.ts').write_text(header+result['ownerAfter']+'\n')
 (tree/'binder.ts').write_text('import { getOwnValues } from "./core";\nconsole.log(String(getOwnValues({ a: 1 }).length));\n')
 with (s/(label+'-focus.log')).open('w') as log:
  r=subprocess.run([s/'tool',tree/'binder.ts',s/(label+'-focus.jsonl')],stdout=log,stderr=log)
 assert r.returncode==0
 print(label,(s/(label+'-focus.jsonl')).read_text(),flush=True)
