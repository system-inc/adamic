from pathlib import Path
import json,shutil,subprocess
s=Path('/workspace/scratch/gov')
labels=['baseline','direct','readonly-view','readonly-parameter','readonly-record','record-parameter','generic-collection','keyof']
for label in labels:
 if label=='baseline' and (s/'baseline-binder.jsonl').exists():continue
 tree=s/('candidate-'+label)
 shutil.copytree(s/'before/src',tree/'src',symlinks=True)
 result=json.loads((s/('declared-'+label+'.json')).read_text())
 core=tree/'src/compiler/core.ts'; original=core.read_bytes(); before=result['ownerBefore'].encode(); after=result['ownerAfter'].encode()
 assert original.count(before)==1
 core.write_bytes(original.replace(before,after))
 with (s/(label+'-binder.log')).open('w') as log:
  r=subprocess.run([s/'tool',tree/'src/compiler/binder.ts',s/(label+'-binder.jsonl')],stdout=log,stderr=log)
 assert r.returncode==0
 print(label,(s/(label+'-binder.jsonl')).read_text(),flush=True)
