export interface MapLike<T> { [index: string]: T; }
const hasOwnProperty = Object.prototype.hasOwnProperty;
export function getOwnValues<T>(collection: MapLike<T>): T[] {
    const values: T[] = [];
    for (const key in collection) {
        if (hasOwnProperty.call(collection, key)) {
            values.push(collection[key]!);
        }
    }

    return values;
}
