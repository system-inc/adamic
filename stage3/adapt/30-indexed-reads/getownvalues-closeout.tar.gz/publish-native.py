from pathlib import Path
import json,hashlib,tarfile,shutil,fcntl,subprocess
s=Path('/workspace/scratch/gov-a');repo=Path('/workspace/adamic');u=repo/'stage3/adapt/30-indexed-reads';d=json.loads((s/'raw/backend-witnesses.json').read_text())
for n in ['arrayArm','recordArm','arrayPresent','arrayEmpty']:
 for b in ['native','javascript']:assert d[n][b]['compileExit']==d[n][b]['runExit']==0 and d[n][b]['stdoutMatchesNode']
for b in ['native','javascript']:
 assert d['sparseWrite'][b]['compileExit']==0 and d['sparseWrite'][b]['runExit']==70
 assert d['sparseWrite'][b]['stdout']=='before-write-length=0\n' and d['sparseWrite'][b]['stderr']=='adamic: panic: index 5 is outside an array of length 0\n'
for n in ['sparse-adapted','presentUndefined-adapted','empty-adapted','record-adapted','recordBranch']:
 for b in ['native','javascript']:assert d[n][b]['compileExit']==1 and 'narrowed union member whose object tag cannot be checked' in d[n][b]['diagnostic']
folder=s/'native-evidence';folder.mkdir(exist_ok=True)
for name in ['backend-witnesses.json','backend-setup-attempt.json','adamic-build.txt','build-adamic.log']:shutil.copyfile(s/'raw'/name,folder/name)
files={p.name:p.read_text() for p in (s/'witnesses').iterdir() if p.is_file() and not p.name.endswith('.native')}
(folder/'witness-files.json').write_text(json.dumps(files,indent=2)+'\n')
for name in ['witness.cjs','extra-witnesses.cjs','run-native.py','run-extra.py']:shutil.copyfile(s/name,folder/name)
for name in ['locals','library_array_predicate']:shutil.copyfile(repo/f'internal/lower/{name}.go',folder/(name+'.go.txt'))
shutil.copyfile(repo/'internal/native/runtime/array.c',folder/'array.c')
js=repo/'internal/javascript/javascript.go';(folder/'javascript.go.txt').write_text(''.join(js.read_text().splitlines(keepends=True)[:130]))
(folder/'provenance.json').write_text(json.dumps({'base':json.loads((s/'raw/base.json').read_text()),'adamicSha256':hashlib.sha256((s/'adamic').read_bytes()).hexdigest(),'sanitize':True,'javascriptRunner':'oracle/node.mjs, the normal oracle host runtime','sourceHashes':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [repo/'internal/lower/locals.go',repo/'internal/lower/library_array_predicate.go',repo/'internal/native/runtime/array.c',js]}},indent=2)+'\n')
(folder/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(folder.iterdir()) if p.name!='SHA256SUMS'))
with (s/'git.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for name in ['extra-witnesses.cjs','run-extra.py']:shutil.copyfile(s/name,u/('getownvalues-'+name))
 archive=u/'getownvalues-native.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  for p in sorted(folder.iterdir()):tf.add(p,arcname='native/'+p.name)
 (u/'getownvalues-native.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
 with (u/'ROAD-A.md').open('a') as f:f.write('''\n## Checked native and JavaScript backends, completed\n\nAll four full proposed-body witnesses fail compilation identically on both\nbackends at fixture line 8:37, the narrowed collection read at filter.\nLower's localRead, internal/lower/locals.go:318, asks arrayPredicateDomain\n(internal/lower/library_array_predicate.go:97) about every original union\nmember. That predicate does not accept the structural MapLike member.\nA separate control replaces only the array return with [] so the record\nbranch can be measured: both backends stop at its for-in collection read,\nfixture line 10:23, localRead at locals.go:341. Neither full arm currently\nlowers in this union. No compiler rule was changed or suppressed.\n\nThe independently typed array filter and dictionary loop both compile and\nmatch Node byte for byte, on native --sanitize and the JavaScript backend.\nThe array controls also match Node for [undefined, 'x'] and the empty array:\nfilter keeps the present undefined and returns an empty array respectively.\nThe dictionary control returns b then a for {'1':'a','0':'b'}.\n\nThe independent sparse-write control compiles on both backends. Both print\n`before-write-length=0`, then exit 70 at a[5] = 'x', with exact stderr:\n\n```text\nadamic: panic: index 5 is outside an array of length 0\n```\n\nThere is no length growth, gap fill or filter execution. Native\ninternal/native/runtime/array.c:504, adamic_array_set, rejects the absent\nslot; the panic is at line 512's bounds message. The JavaScript backend's\nadamicSetIndex helper, internal/javascript/javascript.go:111, makes the\nsame check before assignment. Node instead grows to length 6 with five\nholes, then filter returns one element, x. Thus native cannot hold this\nhole. If the full count finds any sparse arrays, Step B's explicit sparse\ncondition fails. The lane count is still being completed.\n\ngetownvalues-native.tar.gz retains all source, generated JavaScript, compile\nand run output bytes, build provenance and relevant lowering/runtime source.\nThe JavaScript cases use the normal oracle/node.mjs runtime. An initial\ninvocation without that host runtime could not resolve package adamic; it\nis retained as a setup attempt and excluded from backend verdicts.\n''')
 paths=['ROAD-A.md','getownvalues-native.tar.gz','getownvalues-native.sha256','getownvalues-extra-witnesses.cjs','getownvalues-run-extra.py','getownvalues-run-native.py']
 with (s/'git-native.log').open('a') as log:
  for args in [['add',*[str(u.relative_to(repo)/n) for n in paths]],['diff','--cached','--check'],['commit','-m','never cut alone: lands with chg_yj14ddxz, because the census reads its stop\n\ngetOwnValues Step A: push both backend verdicts, checked sparse-write stop, and positive isolated arm controls.'],['push','origin','typescript/getownvalues']]:subprocess.run(['git',*args],cwd=repo,stdout=log,stderr=log,check=True)
print('native part committed and pushed')
