'use strict';
const vm=require('node:vm');
__getOwnValuesCensus([]);
const sparse=[];sparse[5]='x';__getOwnValuesCensus(sparse);
__getOwnValuesCensus([undefined]);
const named=[1];named.note='extra';__getOwnValuesCensus(named);
__getOwnValuesCensus({a:1});__getOwnValuesCensus(Object.create(null));__getOwnValuesCensus(new Date());
vm.runInNewContext('__getOwnValuesCensus({a:1}); __getOwnValuesCensus([undefined]);');
