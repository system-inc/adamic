Whole program: main: 0/2; area: 0/2
Own file: main: 1/2; area: 1/2
tsc entry: main: fail; area: fail
tsc entry diagnostics: main: 1; area: 1

Stage 3 meter 20pb346-completed-fixture
Box: not recorded.

Main: origin/main at 31d7a244808fa8092643926d21ab9d310a54cce3. Area compatibility label at 31d7a244808fa8092643926d21ab9d310a54cce3.
Both measured with Adamic 31d7a244808fa8092643926d21ab9d310a54cce3 and ordinary stage 0 options.

| File | Main whole program | Main own file | Area whole program | Area own file |
| --- | --- | --- | --- | --- |
| src/compiler/a.ts | fail | fail | fail | fail |
| src/compiler/z.ts | fail | pass | fail | pass |

Lowering, main: 0/2; root-order artifacts: 0.

| Root | Stop | Reason | Node result | Classification | Program result from entry census |
| --- | --- | --- | --- | --- | --- |
| No qualifying readiness stops | | | | | |

tsc entry lowering, main: measured on a checker-rejected entry-root program.
Resolved source files: 3; NotYet: 0; Refused: 0.
Errors: 0; panics: 0; skipped dependencies: 0.

| Reason | Owner | NotYet | Refused | Total |
| --- | --- | ---: | ---: | ---: | ---: |
| No NotYet or Refused findings | | 0 | 0 | 0 |

Counts cover the entry root and its resolved implementation dependencies, excluding declarations.
Errors and panics are retained separately in JSON. This census does not establish native output.

Lowering, area: 0/2; root-order artifacts: 0.

| Root | Stop | Reason | Node result | Classification | Program result from entry census |
| --- | --- | --- | --- | --- | --- |
| No qualifying readiness stops | | | | | |

tsc entry lowering, area: measured on a checker-rejected entry-root program.
Resolved source files: 3; NotYet: 0; Refused: 0.
Errors: 0; panics: 0; skipped dependencies: 0.

| Reason | Owner | NotYet | Refused | Total |
| --- | --- | ---: | ---: | ---: | ---: |
| No NotYet or Refused findings | | 0 | 0 | 0 |

Counts cover the entry root and its resolved implementation dependencies, excluding declarations.
Errors and panics are retained separately in JSON. This census does not establish native output.

### Unowned

measured on a checker-rejected program.
OWNER BLANK rows go to @system_adamic. Counts are grouped by exact reason.

No unowned reasons with at least 10 sites on either tree.

0 more unowned reasons, 0 sites in all

Latent lowering, main: measured on a checker-rejected program.
NotYet: 0; Refused: 0.
Recovery boundaries: 0; named nested checker exclusions: 0.
Errors: 0; panics: 0.

| Reason | Owner | NotYet | Refused | Total |
| --- | --- | ---: | ---: | ---: |
| No NotYet or Refused findings | | 0 | 0 | 0 |

Counts are unique finding sites, not attempt events. Skipped dependencies, errors and panics
are retained separately in JSON. This measurement does not establish successful lowering or native output.

This box's times, not comparable across boxes: 0.001 wall seconds; 0.001 CPU seconds.

| Slowest files | Wall seconds | CPU seconds |
| --- | ---: | ---: |
| src/compiler/z.ts | 0.001 | 0.001 |
| src/compiler/a.ts | 0.000 | 0.000 |

Latent lowering, area: measured on a checker-rejected program.
NotYet: 0; Refused: 0.
Recovery boundaries: 0; named nested checker exclusions: 0.
Errors: 0; panics: 0.

| Reason | Owner | NotYet | Refused | Total |
| --- | --- | ---: | ---: | ---: |
| No NotYet or Refused findings | | 0 | 0 | 0 |

Counts are unique finding sites, not attempt events. Skipped dependencies, errors and panics
are retained separately in JSON. This measurement does not establish successful lowering or native output.

This box's times, not comparable across boxes: 0.001 wall seconds; 0.001 CPU seconds.

| Slowest files | Wall seconds | CPU seconds |
| --- | ---: | ---: |
| src/compiler/z.ts | 0.001 | 0.001 |
| src/compiler/a.ts | 0.000 | 0.000 |

Whole program includes imported diagnostics. Own file uses the primary diagnostic location.
Global and external diagnostics are counted separately in JSON; they have no compiler-file location.
Non-source inputs fail the extension gate and are excluded from source denominators.
