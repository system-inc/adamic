import os,pathlib,subprocess,time,json
root=pathlib.Path('/workspace/adamic'); out=pathlib.Path('/workspace/stage3-tier-isolated');out.mkdir(exist_ok=True)
install='mkdir -p "$STAGE3_CACHE/api" && cp ../api/package.json ../api/package-lock.json "$STAGE3_CACHE/api/" && npm ci --prefix "$STAGE3_CACHE/api" --ignore-scripts --no-audit --no-fund'
commands=[('stage3-apply-tests',['python3','stage3/test_apply.py'],root),('stage3-lane-tests',['bash','-c',install+' && python3 -m unittest test_check test_table'],root/'stage3/lane'),('stage3-lane',['bash','stage3/lane/run.sh',str(out/'lane-results')],root)]
rows=[]
for name,command,cwd in commands:
 cache=out/(name+'-cache');cache.mkdir();mirror=pathlib.Path.home()/'.cache/adamic-stage3/typescript.git'
 if mirror.is_dir():(cache/'typescript.git').symlink_to(mirror)
 env=dict(os.environ,STAGE3_CACHE=str(cache),GOMAXPROCS='4',ADAMIC_GATE_UNCACHED='1',PYTHONDONTWRITEBYTECODE='1')
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(unit=name,command=command,cwd=str(cwd),seconds=round(time.monotonic()-start,3),exit=p.returncode,cache=str(cache)))
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
