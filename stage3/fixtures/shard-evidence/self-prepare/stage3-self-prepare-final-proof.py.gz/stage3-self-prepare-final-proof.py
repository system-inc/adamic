import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/adamic-fixture-self-prepare');out=pathlib.Path('/workspace/stage3-self-prepare-final-evidence');out.mkdir(exist_ok=True)
store=out/'products';store.mkdir(exist_ok=True)
env=dict(os.environ,GOMAXPROCS='4',ADAMIC_GATE_UNCACHED='1',ADAMIC_STAGE3_BUILD_STORE=str(store),PYTHONDONTWRITEBYTECODE='1',GOPROXY='https://proxy.golang.org|direct')
with (out/'fixture-build.log').open('w') as log:
 p=subprocess.run(['go','test','-c','-o',str(out/'fixtures.test'),'./stage3/fixtures'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(out/'fixture-build.log').read_text()
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
assert not list(store.glob('*.json'))
rows=[]
def run(name,cmd,extra=None):
 subprocess.run(['go','clean','-testcache'],cwd=root,env=env,check=True)
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root/'stage3/fixtures' if cmd[0]==str(out/'fixtures.test') else root,env=dict(env,**(extra or {})),stdout=log,stderr=subprocess.STDOUT)
 row=dict(unit=name,command=cmd,seconds=round(time.monotonic()-start,3),exit=p.returncode);rows.append(row)
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
 return p.returncode
command=['go','test','./stage3/fixtures/...']
assert run('clean-empty-store',command)==0
manifests=list(store.glob('*.json'));assert len(manifests)==1
manifest=manifests[0];data=json.loads(manifest.read_text());product=store/data['sha256'];original=product.read_bytes()
assert hashlib.sha256(original).hexdigest()==data['sha256']
product.unlink();assert manifest.exists() and not product.exists()
assert run('deleted-product-manifest-retained',command)==0
mtime=product.stat().st_mtime_ns
assert run('warm-product',command)==0
assert product.stat().st_mtime_ns==mtime,'warm product rebuilt'
product.write_bytes(b'corrupted product mutant\n')
assert run('corrupt-product',command)!=0
assert 'oracle build product hash mismatch' in (out/'corrupt-product.log').read_text()
assert product.read_bytes()==b'corrupted product mutant\n','mutant overwritten rather than rejected'
product.write_bytes(original)
assert hashlib.sha256(product.read_bytes()).hexdigest()==data['sha256']
# The preparation-only action is measured separately after deleting the product.
product.unlink()
assert run('preparation-unit',[str(out/'fixtures.test'),'-test.run=^TestPrepareFixtureOracleHook$','-test.count=1','-test.v'])==0
(out/'action.json').write_text(manifest.read_text())
# Fresh observations in each named shard; each must work with a missing product.
for index in range(8):
 product.unlink()
 assert run('cold-shard-'+str(index),[str(out/'fixtures.test'),'-test.run=^TestFixtures$','-test.count=1','-test.parallel=4'],{'ADAMIC_TEST_SHARD':f'{index}/8'})==0
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''

assert all(row["seconds"] < 30 for row in rows), "unit exceeds 30 second budget"
