import json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/adamic-fixture-self-prepare');out=pathlib.Path('/workspace/stage3-self-prepare-final-evidence');store=out/'products'
manifest=next(store.glob('*.json'));data=json.loads(manifest.read_text());product=store/data['sha256'];product.unlink()
wrapper=out/'fake-go';wrapper.mkdir(exist_ok=True)
real=subprocess.check_output(['which','go'],text=True).strip()
script=wrapper/'go';script.write_text('#!/bin/sh\nif [ "$1" = "test" ] && [ "$2" = "-buildvcs=false" ] && [ "$3" = "-c" ]; then\n echo "planted oracle hook build failure" >&2\n exit 42\nfi\nexec '+real+' "$@"\n');script.chmod(0o755)
env=dict(os.environ,GOMAXPROCS='4',ADAMIC_GATE_UNCACHED='1',ADAMIC_STAGE3_BUILD_STORE=str(store),PYTHONDONTWRITEBYTECODE='1')
rows=[]
for label,mutation in [('preparation-failure',True),('recovery-after-build-failure',False)]:
 subprocess.run(['go','clean','-testcache'],cwd=root,env=env,check=True)
 start=time.monotonic()
 command=[str(out/'fixtures.test'),'-test.run=^TestPrepareFixtureOracleHook$','-test.count=1'] if mutation else ['go','test','./stage3/fixtures/...']
 with (out/(label+'.log')).open('w') as log:p=subprocess.run(command,cwd=root/'stage3/fixtures' if mutation else root,env=dict(env,PATH=str(wrapper)+os.pathsep+env['PATH']) if mutation else env,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(unit=label,command=command,seconds=round(time.monotonic()-start,3),exit=p.returncode));print(rows[-1],flush=True)
 (out/'failure-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 if mutation:
  assert p.returncode!=0
  text=(out/(label+'.log')).read_text();assert 'oracle hook preparation failed (exit 42)' in text and 'planted oracle hook build failure' in text
 else:assert p.returncode==0
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
