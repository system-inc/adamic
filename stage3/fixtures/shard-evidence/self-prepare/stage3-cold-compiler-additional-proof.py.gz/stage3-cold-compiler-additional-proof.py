import importlib.util,json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/adamic-fixture-self-prepare');out=pathlib.Path('/workspace/stage3-cold-compiler-evidence');out.mkdir(exist_ok=True)
env=dict(os.environ,GOMAXPROCS='4',ADAMIC_GATE_UNCACHED='1',PYTHONDONTWRITEBYTECODE='1')
spec=importlib.util.spec_from_file_location('hook',root/'stage3/fixtures/build-hook.py');hook=importlib.util.module_from_spec(spec);spec.loader.exec_module(hook)
listing=(out/'exports.json').read_text()
original_cache=pathlib.Path(subprocess.check_output(['go','env','GOCACHE'],env=env,text=True).strip());cache=out/'go-cache'
exports=[pathlib.Path(record['Export']).relative_to(original_cache) for record in hook.records(listing) if record.get('Export')]
store=out/'products';store.mkdir(exist_ok=True);env.update(GOCACHE=str(cache),ADAMIC_STAGE3_BUILD_STORE=str(store),GOFLAGS='-x')
binary='/workspace/stage3-self-prepare-final-evidence/fixtures.test';rows=json.loads((out/'results.json').read_text())
for name,selector,index in [('fixtures-all-cold-compiler','TestFixtures',None),('fixture-paths','TestFixturePaths',None),('fixture-manifest','TestFixtureShardManifest',None),('runner-guard','TestTransformedNodeRunnerGuard',None),('runner-guard-hook','TestTransformedNodeRunnerGuardHook',None)]:
 for relative in exports:
  (cache/relative).unlink(missing_ok=True)
 for manifest in store.glob('*.json'):
  (store/json.loads(manifest.read_text())['sha256']).unlink(missing_ok=True)
 start=time.monotonic()
 command=[binary,'-test.run=^'+selector+'$','-test.count=1','-test.parallel=4','-test.v']
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(command,cwd=root/'stage3/fixtures',env=dict(env,**({'ADAMIC_TEST_SHARD':f'{index}/8'} if index is not None else {})),stdout=log,stderr=subprocess.STDOUT)
 seconds=round(time.monotonic()-start,3)
 build=next(store.glob('*.build.log')).read_text();compiled=any('/compile ' in line and ' -p github.com/system-inc/adamic/internal/oracle ' in line for line in build.splitlines())
 row=dict(unit=name,command=command,seconds=seconds,exit=p.returncode,recompiled_oracle_tests=compiled if selector=='TestFixtures' else False);rows.append(row)
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
 assert p.returncode==0 and (selector!='TestFixtures' or compiled),name
 assert seconds<30,name
