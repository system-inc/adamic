import ast,gzip,re,sys
from pathlib import Path
root='/workspace/adamic'
rows=set()
for source in sys.argv[1:]:
 for line in Path(source).read_text().splitlines():
  m=re.search(r'openat\(([^,]+), ("(?:[^"\\]|\\.)*"), (.*)',line)
  if m:
   try: p=ast.literal_eval(m[2])
   except Exception: continue
   if not p.startswith('/'):
    cwd=re.search(r'<([^>]+)>',m[1])
    if not cwd: continue
    p=str(Path(cwd[1])/p)
   p=__import__('os').path.normpath(p)
   status='probe' if '= -1' in line else 'write' if 'O_WRONLY' in m[3] or 'O_RDWR' in m[3] else 'read'
  else:
   m=re.search(r'execve\(("(?:[^"\\]|\\.)*")',line)
   if not m: continue
   p=ast.literal_eval(m[1]); status='exec-probe' if '= -1' in line else 'exec'
  if p==root or p.startswith(root+'/'):
   rows.add((p[len(root)+1:] or '.',status))
print('path\toperation')
for p,status in sorted(rows): print(p+'\t'+status)
