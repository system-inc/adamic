from pathlib import Path
import subprocess
p=Path('stage3/applyproducts/products.go'); original=p.read_text()
for name,before,after,test,message in [
 ('parent','syscall.Kill(-command.Process.Pid, syscall.SIGKILL)','syscall.Kill(command.Process.Pid, syscall.SIGKILL)','TestProductDeadlineKillsDescendants',"deadline left the worker's child running"),
 ('metadata','index == len(boundaries)-1 || entry.IsDir()','entry.IsDir()','TestStage3Adapted99TracksMetadata','changed source pin reused product key')]:
 try:
  assert before in original
  p.write_text(original.replace(before,after,1))
  log=Path('/tmp/hefhych-2-mutant-'+name+'.log')
  with log.open('w') as f:
   r=subprocess.run(['go','test','./stage3/applyproducts','-run','^'+test+'$','-count=1','-timeout','90s','-v'],stdout=f,stderr=subprocess.STDOUT,timeout=95)
  assert r.returncode==1 and message in log.read_text(),log.read_text()
  print(name, 'exit=1 caught:',message,flush=True)
 finally: p.write_text(original)
