from pathlib import Path
import subprocess,time,json
for boundary in ['10','20','40','65','70','99']:
 command=['go','test','./stage3/applyproducts','-run',f'^TestProduct_Stage3Adapted{boundary}$','-count=1','-timeout','90s','-v']
 log=Path(f'/tmp/hefhych-2-cold-{boundary}.log')
 start=time.monotonic()
 with log.open('w') as f:
  result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=95)
 print(json.dumps(dict(boundary=boundary,wall=time.monotonic()-start,exit=result.returncode,command=command)),flush=True)
 assert result.returncode==0,log.read_text()
