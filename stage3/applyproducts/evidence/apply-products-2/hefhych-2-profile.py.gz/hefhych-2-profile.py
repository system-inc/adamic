from pathlib import Path
import subprocess,sys,time
sys.dont_write_bytecode=True
root=Path('/workspace/adamic')
sys.path.insert(0,str(root/'stage3'))
namespace=dict(__file__=str(root/'stage3/apply.py'),__name__='profile')
exec(compile(subprocess.check_output(['git','show','origin/main:stage3/apply.py'],cwd=root),namespace['__file__'],'exec'),namespace)
run=namespace['run']
def timed(*args,**kwargs):
    start=time.monotonic()
    try: return run(*args,**kwargs)
    finally: print('MEASURE',round(time.monotonic()-start,3),repr(args),flush=True)
namespace['run']=timed
namespace['build_product'](Path('/workspace/hefhych-2-reference'))
