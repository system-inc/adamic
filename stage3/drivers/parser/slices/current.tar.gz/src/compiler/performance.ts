import "./_namespaces/ts.ts";
import { timestamp } from "./_namespaces/ts.ts";
import type { Performance } from "./performanceCore.ts";


/** Performance measurements for the compiler. */

// NOTE: declared global is injected by ts-perf to monitor profiler marks to generate heap snapshots.
declare let onProfilerEvent: ((eventName: string) => void) | undefined;
// when set, indicates the implementation of `Performance` to use for user timing.
// when unset, indicates user timing is unavailable or disabled.
let performanceImpl: Performance | undefined;

let enabled = false;
let timeorigin = timestamp();
const marks = new Map<string, number>();
const counts = new Map<string, number>();
const durations = new Map<string, number>();

/**
 * Marks a performance event.
 *
 * @param markName The name of the mark.
 *
 * @internal
 */
export function mark(markName: string): void {
    if (enabled) {
        const count = counts.get(markName) ?? 0;
        counts.set(markName, count + 1);
        marks.set(markName, timestamp());
        performanceImpl?.mark(markName);
        if (typeof onProfilerEvent === "function") {
            onProfilerEvent(markName);
        }
    }
}

/**
 * Adds a performance measurement with the specified name.
 *
 * @param measureName The name of the performance measurement.
 * @param startMarkName The name of the starting mark. If not supplied, the point at which the
 *      profiler was enabled is used.
 * @param endMarkName The name of the ending mark. If not supplied, the current timestamp is
 *      used.
 *
 * @internal
 */
export function measure(measureName: string, startMarkName?: string, endMarkName?: string): void {
    if (enabled) {
        const end = (endMarkName !== undefined ? marks.get(endMarkName) : undefined) ?? timestamp();
        const start = (startMarkName !== undefined ? marks.get(startMarkName) : undefined) ?? timeorigin;
        const previousDuration = durations.get(measureName) || 0;
        durations.set(measureName, previousDuration + (end - start));
        performanceImpl?.measure(measureName, startMarkName, endMarkName);
    }
}