import "../moduleSpecifiers.ts";
/* Generated file to emulate the ts.moduleSpecifiers namespace. */

export * from "../moduleSpecifiers.js";