import "../_namespaces/ts.ts";
import type { Node, StringLiteral, ImportEqualsDeclaration, ExternalModuleReference, ImportDeclaration, ExportAssignment, ExportDeclaration, JSDoc, JsxText, NumericLiteral, Identifier, QuestionToken, ExclamationToken, ComputedPropertyName, OmittedExpression, SuperExpression, ImportExpression, ObjectLiteralExpression, ArrayLiteralExpression, PrivateIdentifier, CommaListExpression, BinaryExpression, Token, SourceFile, ParenthesizedExpression, LabeledStatement, PropertyAccessExpression, ElementAccessExpression, TypeParameterDeclaration, ParameterDeclaration, ConstructorTypeNode, PropertySignature, PropertyDeclaration, MethodSignature, MethodDeclaration, ConstructorDeclaration, GetAccessorDeclaration, SetAccessorDeclaration, IndexSignatureDeclaration, FunctionExpression, ArrowFunction, ClassExpression, VariableStatement, FunctionDeclaration, ClassDeclaration, InterfaceDeclaration, TypeAliasDeclaration, EnumDeclaration, ModuleDeclaration, NotEmittedStatement, VariableDeclaration, JsxOpeningElement, AsyncKeyword, ExportKeyword, TaggedTemplateExpression, TypeReferenceNode, JSDocReturnTag, JSDocTypeTag, MetaProperty, CallExpression, Block, JSDocNullableType, NamedTupleMember, FunctionTypeNode, TypeOperatorNode, ConditionalTypeNode, UnionTypeNode, IntersectionTypeNode, InferTypeNode, DefaultKeyword, BindingElement, ObjectBindingPattern, ArrayBindingPattern, JsxNamespacedName, NoSubstitutionTemplateLiteral, NonNullExpression, JSDocTypeExpression, JSDocFunctionType, SpreadElement, PropertyAssignment, JsxOpeningFragment, BigIntLiteral, CallSignatureDeclaration, ConstructSignatureDeclaration, TypePredicateNode, TypeQueryNode, TypeLiteralNode, ArrayTypeNode, TupleTypeNode, OptionalTypeNode, RestTypeNode, ParenthesizedTypeNode, ThisTypeNode, IndexedAccessTypeNode, MappedTypeNode, LiteralTypeNode, ImportTypeNode, DefaultClause, VoidExpression, ExpressionWithTypeArguments, PrefixUnaryExpression, JSDocPublicTag, JSDocPrivateTag, JSDocProtectedTag, JSDocReadonlyTag, JSDocOverrideTag, JSDocDeprecatedTag, JSDocOverloadTag, JSDocSatisfiesTag, JSDocParameterTag, JSDocTemplateTag, ExpressionStatement } from "../types.ts";
import { SyntaxKind } from "../_namespaces/ts.ts";


// Literals

export function isNumericLiteral(node: Node): node is NumericLiteral {
    return node.kind === SyntaxKind.NumericLiteral;
}

export function isBigIntLiteral(node: Node): node is BigIntLiteral {
    return node.kind === SyntaxKind.BigIntLiteral;
}

export function isStringLiteral(node: Node): node is StringLiteral {
    return node.kind === SyntaxKind.StringLiteral;
}

export function isJsxText(node: Node): node is JsxText {
    return node.kind === SyntaxKind.JsxText;
}

export function isNoSubstitutionTemplateLiteral(node: Node): node is NoSubstitutionTemplateLiteral {
    return node.kind === SyntaxKind.NoSubstitutionTemplateLiteral;
}

/** @internal */
export function isCommaToken(node: Node): node is Token<SyntaxKind.CommaToken> {
    return node.kind === SyntaxKind.CommaToken;
}

export function isExclamationToken(node: Node): node is ExclamationToken {
    return node.kind === SyntaxKind.ExclamationToken;
}

export function isQuestionToken(node: Node): node is QuestionToken {
    return node.kind === SyntaxKind.QuestionToken;
}

// Identifiers

export function isIdentifier(node: Node): node is Identifier {
    return node.kind === SyntaxKind.Identifier;
}

export function isPrivateIdentifier(node: Node): node is PrivateIdentifier {
    return node.kind === SyntaxKind.PrivateIdentifier;
}

// Reserved Words

/** @internal */
export function isExportModifier(node: Node): node is ExportKeyword {
    return node.kind === SyntaxKind.ExportKeyword;
}

/** @internal */
export function isDefaultModifier(node: Node): node is DefaultKeyword {
    return node.kind === SyntaxKind.DefaultKeyword;
}

/** @internal */
export function isAsyncModifier(node: Node): node is AsyncKeyword {
    return node.kind === SyntaxKind.AsyncKeyword;
}

/** @internal */
export function isSuperKeyword(node: Node): node is SuperExpression {
    return node.kind === SyntaxKind.SuperKeyword;
}

/** @internal */
export function isImportKeyword(node: Node): node is ImportExpression {
    return node.kind === SyntaxKind.ImportKeyword;
}

export function isComputedPropertyName(node: Node): node is ComputedPropertyName {
    return node.kind === SyntaxKind.ComputedPropertyName;
}

// Signature elements

export function isTypeParameterDeclaration(node: Node): node is TypeParameterDeclaration {
    return node.kind === SyntaxKind.TypeParameter;
}

// TODO(rbuckton): Rename to 'isParameterDeclaration'
export function isParameter(node: Node): node is ParameterDeclaration {
    return node.kind === SyntaxKind.Parameter;
}

// TypeMember

export function isPropertySignature(node: Node): node is PropertySignature {
    return node.kind === SyntaxKind.PropertySignature;
}

export function isPropertyDeclaration(node: Node): node is PropertyDeclaration {
    return node.kind === SyntaxKind.PropertyDeclaration;
}

export function isMethodSignature(node: Node): node is MethodSignature {
    return node.kind === SyntaxKind.MethodSignature;
}

export function isMethodDeclaration(node: Node): node is MethodDeclaration {
    return node.kind === SyntaxKind.MethodDeclaration;
}

export function isConstructorDeclaration(node: Node): node is ConstructorDeclaration {
    return node.kind === SyntaxKind.Constructor;
}

export function isGetAccessorDeclaration(node: Node): node is GetAccessorDeclaration {
    return node.kind === SyntaxKind.GetAccessor;
}

export function isSetAccessorDeclaration(node: Node): node is SetAccessorDeclaration {
    return node.kind === SyntaxKind.SetAccessor;
}

export function isCallSignatureDeclaration(node: Node): node is CallSignatureDeclaration {
    return node.kind === SyntaxKind.CallSignature;
}

export function isConstructSignatureDeclaration(node: Node): node is ConstructSignatureDeclaration {
    return node.kind === SyntaxKind.ConstructSignature;
}

export function isIndexSignatureDeclaration(node: Node): node is IndexSignatureDeclaration {
    return node.kind === SyntaxKind.IndexSignature;
}

// Type

export function isTypePredicateNode(node: Node): node is TypePredicateNode {
    return node.kind === SyntaxKind.TypePredicate;
}

export function isTypeReferenceNode(node: Node): node is TypeReferenceNode {
    return node.kind === SyntaxKind.TypeReference;
}

export function isFunctionTypeNode(node: Node): node is FunctionTypeNode {
    return node.kind === SyntaxKind.FunctionType;
}

export function isConstructorTypeNode(node: Node): node is ConstructorTypeNode {
    return node.kind === SyntaxKind.ConstructorType;
}

export function isTypeQueryNode(node: Node): node is TypeQueryNode {
    return node.kind === SyntaxKind.TypeQuery;
}

export function isTypeLiteralNode(node: Node): node is TypeLiteralNode {
    return node.kind === SyntaxKind.TypeLiteral;
}

export function isArrayTypeNode(node: Node): node is ArrayTypeNode {
    return node.kind === SyntaxKind.ArrayType;
}

export function isTupleTypeNode(node: Node): node is TupleTypeNode {
    return node.kind === SyntaxKind.TupleType;
}

export function isNamedTupleMember(node: Node): node is NamedTupleMember {
    return node.kind === SyntaxKind.NamedTupleMember;
}

export function isOptionalTypeNode(node: Node): node is OptionalTypeNode {
    return node.kind === SyntaxKind.OptionalType;
}

export function isRestTypeNode(node: Node): node is RestTypeNode {
    return node.kind === SyntaxKind.RestType;
}

export function isUnionTypeNode(node: Node): node is UnionTypeNode {
    return node.kind === SyntaxKind.UnionType;
}

export function isIntersectionTypeNode(node: Node): node is IntersectionTypeNode {
    return node.kind === SyntaxKind.IntersectionType;
}

export function isConditionalTypeNode(node: Node): node is ConditionalTypeNode {
    return node.kind === SyntaxKind.ConditionalType;
}

export function isInferTypeNode(node: Node): node is InferTypeNode {
    return node.kind === SyntaxKind.InferType;
}

export function isParenthesizedTypeNode(node: Node): node is ParenthesizedTypeNode {
    return node.kind === SyntaxKind.ParenthesizedType;
}

export function isThisTypeNode(node: Node): node is ThisTypeNode {
    return node.kind === SyntaxKind.ThisType;
}

export function isTypeOperatorNode(node: Node): node is TypeOperatorNode {
    return node.kind === SyntaxKind.TypeOperator;
}

export function isIndexedAccessTypeNode(node: Node): node is IndexedAccessTypeNode {
    return node.kind === SyntaxKind.IndexedAccessType;
}

export function isMappedTypeNode(node: Node): node is MappedTypeNode {
    return node.kind === SyntaxKind.MappedType;
}

export function isLiteralTypeNode(node: Node): node is LiteralTypeNode {
    return node.kind === SyntaxKind.LiteralType;
}

export function isImportTypeNode(node: Node): node is ImportTypeNode {
    return node.kind === SyntaxKind.ImportType;
}

// Binding patterns

export function isObjectBindingPattern(node: Node): node is ObjectBindingPattern {
    return node.kind === SyntaxKind.ObjectBindingPattern;
}

export function isArrayBindingPattern(node: Node): node is ArrayBindingPattern {
    return node.kind === SyntaxKind.ArrayBindingPattern;
}

export function isBindingElement(node: Node): node is BindingElement {
    return node.kind === SyntaxKind.BindingElement;
}

// Expression

export function isArrayLiteralExpression(node: Node): node is ArrayLiteralExpression {
    return node.kind === SyntaxKind.ArrayLiteralExpression;
}

export function isObjectLiteralExpression(node: Node): node is ObjectLiteralExpression {
    return node.kind === SyntaxKind.ObjectLiteralExpression;
}

export function isPropertyAccessExpression(node: Node): node is PropertyAccessExpression {
    return node.kind === SyntaxKind.PropertyAccessExpression;
}

export function isElementAccessExpression(node: Node): node is ElementAccessExpression {
    return node.kind === SyntaxKind.ElementAccessExpression;
}

export function isCallExpression(node: Node): node is CallExpression {
    return node.kind === SyntaxKind.CallExpression;
}

export function isTaggedTemplateExpression(node: Node): node is TaggedTemplateExpression {
    return node.kind === SyntaxKind.TaggedTemplateExpression;
}

export function isParenthesizedExpression(node: Node): node is ParenthesizedExpression {
    return node.kind === SyntaxKind.ParenthesizedExpression;
}

export function isFunctionExpression(node: Node): node is FunctionExpression {
    return node.kind === SyntaxKind.FunctionExpression;
}

export function isArrowFunction(node: Node): node is ArrowFunction {
    return node.kind === SyntaxKind.ArrowFunction;
}

export function isVoidExpression(node: Node): node is VoidExpression {
    return node.kind === SyntaxKind.VoidExpression;
}

export function isPrefixUnaryExpression(node: Node): node is PrefixUnaryExpression {
    return node.kind === SyntaxKind.PrefixUnaryExpression;
}

export function isBinaryExpression(node: Node): node is BinaryExpression {
    return node.kind === SyntaxKind.BinaryExpression;
}

export function isSpreadElement(node: Node): node is SpreadElement {
    return node.kind === SyntaxKind.SpreadElement;
}

export function isClassExpression(node: Node): node is ClassExpression {
    return node.kind === SyntaxKind.ClassExpression;
}

export function isOmittedExpression(node: Node): node is OmittedExpression {
    return node.kind === SyntaxKind.OmittedExpression;
}

export function isExpressionWithTypeArguments(node: Node): node is ExpressionWithTypeArguments {
    return node.kind === SyntaxKind.ExpressionWithTypeArguments;
}

export function isNonNullExpression(node: Node): node is NonNullExpression {
    return node.kind === SyntaxKind.NonNullExpression;
}

export function isMetaProperty(node: Node): node is MetaProperty {
    return node.kind === SyntaxKind.MetaProperty;
}

export function isCommaListExpression(node: Node): node is CommaListExpression {
    return node.kind === SyntaxKind.CommaListExpression;
}

// Elements

export function isBlock(node: Node): node is Block {
    return node.kind === SyntaxKind.Block;
}

export function isVariableStatement(node: Node): node is VariableStatement {
    return node.kind === SyntaxKind.VariableStatement;
}

export function isExpressionStatement(node: Node): node is ExpressionStatement {
    return node.kind === SyntaxKind.ExpressionStatement;
}

export function isLabeledStatement(node: Node): node is LabeledStatement {
    return node.kind === SyntaxKind.LabeledStatement;
}

export function isVariableDeclaration(node: Node): node is VariableDeclaration {
    return node.kind === SyntaxKind.VariableDeclaration;
}

export function isFunctionDeclaration(node: Node): node is FunctionDeclaration {
    return node.kind === SyntaxKind.FunctionDeclaration;
}

export function isClassDeclaration(node: Node): node is ClassDeclaration {
    return node.kind === SyntaxKind.ClassDeclaration;
}

export function isInterfaceDeclaration(node: Node): node is InterfaceDeclaration {
    return node.kind === SyntaxKind.InterfaceDeclaration;
}

export function isTypeAliasDeclaration(node: Node): node is TypeAliasDeclaration {
    return node.kind === SyntaxKind.TypeAliasDeclaration;
}

export function isEnumDeclaration(node: Node): node is EnumDeclaration {
    return node.kind === SyntaxKind.EnumDeclaration;
}

export function isModuleDeclaration(node: Node): node is ModuleDeclaration {
    return node.kind === SyntaxKind.ModuleDeclaration;
}

export function isImportEqualsDeclaration(node: Node): node is ImportEqualsDeclaration {
    return node.kind === SyntaxKind.ImportEqualsDeclaration;
}

export function isImportDeclaration(node: Node): node is ImportDeclaration {
    return node.kind === SyntaxKind.ImportDeclaration;
}

export function isExportAssignment(node: Node): node is ExportAssignment {
    return node.kind === SyntaxKind.ExportAssignment;
}

export function isExportDeclaration(node: Node): node is ExportDeclaration {
    return node.kind === SyntaxKind.ExportDeclaration;
}

export function isNotEmittedStatement(node: Node): node is NotEmittedStatement {
    return node.kind === SyntaxKind.NotEmittedStatement;
}

// Module References

export function isExternalModuleReference(node: Node): node is ExternalModuleReference {
    return node.kind === SyntaxKind.ExternalModuleReference;
}

export function isJsxOpeningElement(node: Node): node is JsxOpeningElement {
    return node.kind === SyntaxKind.JsxOpeningElement;
}

export function isJsxOpeningFragment(node: Node): node is JsxOpeningFragment {
    return node.kind === SyntaxKind.JsxOpeningFragment;
}

export function isJsxNamespacedName(node: Node): node is JsxNamespacedName {
    return node.kind === SyntaxKind.JsxNamespacedName;
}

export function isDefaultClause(node: Node): node is DefaultClause {
    return node.kind === SyntaxKind.DefaultClause;
}

// Property assignments

export function isPropertyAssignment(node: Node): node is PropertyAssignment {
    return node.kind === SyntaxKind.PropertyAssignment;
}

// Top-level nodes
export function isSourceFile(node: Node): node is SourceFile {
    return node.kind === SyntaxKind.SourceFile;
}

// TODO(rbuckton): isInputFiles

// JSDoc Elements

export function isJSDocTypeExpression(node: Node): node is JSDocTypeExpression {
    return node.kind === SyntaxKind.JSDocTypeExpression;
}

export function isJSDocNullableType(node: Node): node is JSDocNullableType {
    return node.kind === SyntaxKind.JSDocNullableType;
}

export function isJSDocFunctionType(node: Node): node is JSDocFunctionType {
    return node.kind === SyntaxKind.JSDocFunctionType;
}

export function isJSDoc(node: Node): node is JSDoc {
    return node.kind === SyntaxKind.JSDoc;
}

export function isJSDocPublicTag(node: Node): node is JSDocPublicTag {
    return node.kind === SyntaxKind.JSDocPublicTag;
}

export function isJSDocPrivateTag(node: Node): node is JSDocPrivateTag {
    return node.kind === SyntaxKind.JSDocPrivateTag;
}

export function isJSDocProtectedTag(node: Node): node is JSDocProtectedTag {
    return node.kind === SyntaxKind.JSDocProtectedTag;
}

export function isJSDocReadonlyTag(node: Node): node is JSDocReadonlyTag {
    return node.kind === SyntaxKind.JSDocReadonlyTag;
}

export function isJSDocOverrideTag(node: Node): node is JSDocOverrideTag {
    return node.kind === SyntaxKind.JSDocOverrideTag;
}

export function isJSDocOverloadTag(node: Node): node is JSDocOverloadTag {
    return node.kind === SyntaxKind.JSDocOverloadTag;
}

export function isJSDocDeprecatedTag(node: Node): node is JSDocDeprecatedTag {
    return node.kind === SyntaxKind.JSDocDeprecatedTag;
}

export function isJSDocParameterTag(node: Node): node is JSDocParameterTag {
    return node.kind === SyntaxKind.JSDocParameterTag;
}

export function isJSDocReturnTag(node: Node): node is JSDocReturnTag {
    return node.kind === SyntaxKind.JSDocReturnTag;
}

export function isJSDocTypeTag(node: Node): node is JSDocTypeTag {
    return node.kind === SyntaxKind.JSDocTypeTag;
}

export function isJSDocTemplateTag(node: Node): node is JSDocTemplateTag {
    return node.kind === SyntaxKind.JSDocTemplateTag;
}

export function isJSDocSatisfiesTag(node: Node): node is JSDocSatisfiesTag {
    return node.kind === SyntaxKind.JSDocSatisfiesTag;
}