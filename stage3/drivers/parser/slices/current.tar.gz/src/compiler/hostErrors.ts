

/** @internal */
export function errorMessage(error: unknown): string | undefined {
    return typeof error === "object" && error !== null && "message" in error && typeof error.message === "string" ? error.message : undefined;
}