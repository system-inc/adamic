const fs=require('fs'),ts=require('/home/agent/.cache/adamic-stage3/api/node_modules/typescript');
const file=process.argv[2],text=fs.readFileSync(file,'utf8'),source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true),edits=[];
for(const n of source.statements)if(ts.isFunctionDeclaration(n)&&n.name?.text===(process.argv[3] || 'every')){
 for(const p of n.parameters)if(p.type){function visit(x){if(ts.isTypePredicateNode(x))edits.push({start:x.getStart(source),end:x.end,value:'boolean'});else ts.forEachChild(x,visit);}visit(p.type);}
 if(n.body)edits.push({start:n.body.getStart(source),end:n.body.end,value:'{ throw "discovery-only every overload implementation";'+ '\n'.repeat((n.body.getText(source).match(/\n/g)||[]).length)+'}'});
}
let result=text;for(const e of edits.sort((a,b)=>b.start-a.start))result=result.slice(0,e.start)+e.value+result.slice(e.end);fs.writeFileSync(file,result);console.log(JSON.stringify(edits));
