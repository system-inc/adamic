import subprocess,re
from pathlib import Path
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines()
for name in paths:
 p=Path(name);s=p.read_text()
 def resolve(m):
  a,b=m[1],m[2]
  if name=='internal/oracle/counts.md':return a+b
  if name=='internal/fresh/library_language.go':return a[:a.index('\tswitch')]+b
  if name=='internal/lower/refusals.go':
   if 'KindVoidExpression' in a:return ''
   return a+b
  if name=='internal/lower/object.go':
   if 'TypeFlagsNever' in a:return a+'\t}\n'+b
   return a+'\t\treturn value, true, err\n\t}\n'+b
  if name=='internal/lower/locals.go':
   if 'inferred :=' in b:return '\tinferred := l.evolvingObject(name)\n'+a
   return a+'\t}\n'+b
  if name=='internal/lower/expression.go':
   if 'finitePartialRecordElement' in a or 'typedArrayKind(from)' in a:return a+'\t}\n'+b
   if 'recordOrdinaryPredicateChecks' in a:return a+'\t}\n'+b
   if 'case ast.KindPostfixUnaryExpression' in a:return a+b
   if 'typedArrayExpression' in a:return a+'\t}\n'+b
   if 'genericSignature(proven)' in a:return a[:a.index('\t\tif l.includesNull')]+b
   if 'typedArraySetArgument' in a:return b.replace('!l.nodeBufferReadArgument(node) && !l.nodeFSFileBufferArgument(node) && !l.sameKeeping','!l.typedArraySetArgument(node) && !l.nodeBufferReadArgument(node) && !l.nodeFSFileBufferArgument(node) && !l.sameKeeping')
  if name=='internal/javascript/javascript.go':
   if 'recordRuntime' in a or 'case ir.' in a:return a+b
   if 'receiver)' in a or 'Uninitialized' in a:return a
  if name=='internal/native/emit_expressions.go' and 'case ir.TypedArrayNew' in a:return a+b
  if name=='internal/native/emit_locals.go':return a
  if name=='internal/native/runtime/adamic.h':
   if 'adamic_kind_typed_array' in a:return '#endif\n'+a
   if 'uint8_t boolean' in a:return a
  if name=='internal/native/from.go':return b.replace('zero(from.First)','absent(from.First)')
  return b
 s=re.sub(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);p.write_text(s)
subprocess.run(['git','add',*paths],check=True)
