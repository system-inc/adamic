import subprocess,re
from pathlib import Path
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines()
for name in paths:
 p=Path(name);s=p.read_text()
 def resolve(m):
  a,b=m[1],m[2]
  if name=='internal/oracle/counts.md':return a+b
  if name in ['internal/lower/cast.go','internal/lower/cast_proof.go']:return b
  if name=='internal/lower/refusals.go':
   if not a or 'checkedCast =' in b:return b
   if 'refuseNodeRequire' in b:return a+b
  return a
 s=re.sub(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);p.write_text(s)
subprocess.run(['git','add',*paths],check=True)
