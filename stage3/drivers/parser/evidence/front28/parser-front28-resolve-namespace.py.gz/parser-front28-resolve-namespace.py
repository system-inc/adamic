from pathlib import Path
import re,subprocess
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).decode().splitlines()
for name in paths:
 p=Path(name);s=p.read_text()
 def resolve(m):
  a,b=m[1],m[2]
  if 'assertionVarList' in a:return a.replace('!assertionVarList(list)','!assertionVarList(list) && !namespaceVariable(list)')
  if name.endswith('modules.go'):return a+b
  if name.endswith('functions.go'):
   if 'argumentSlotless' in a:return b[:b.index('\t\tif parameter.Initializer()')] + a if '\t\tif parameter.Initializer()' in b else a
   return a+'\t\t}\n'+b
  if name.endswith('statements.go') and 'namespaceReturnAssignment' in b:return a+'\t}\n'+b
  if name.endswith('refusals.go'):return a+'\t\t\tfound = err\n\t\t\treturn true\n\t\t}\n'+b
  if name.endswith('expression.go'):
   if 'return l.localRead' in b:return a.replace('Checked: l.checkedModuleRead(node, local)', 'Checked: l.checkedModuleRead(node, local) || l.result.Locals[local].NamespaceState')
   if 'qualified :=' in b:
    return a[:a.rfind('\tif declaration, isGeneric :=')]+b
   if 'namespaceReadyCall' in b:return a.replace('return l.callFunction(call, instance)', 'value, err := l.callFunction(call, instance)\n\t\tif err == nil { value = l.namespaceReadyCall(callee, value) }; return value, err')
  if name.endswith('locals.go'):
   if 'initializeLocal' in a:return '\t\tif l.result.Locals[local].NamespaceVar && value != nil {\n\t\t\tstatements = append(statements, ir.Assign{Local: local, Value: fit(value, l.result.Locals[local].Type)})\n\t\t} else {\n'+a+'\t\t}\n'
   return a.replace('return ', 'return l.result.Locals[local].NamespaceState || ',1)
  if name.endswith('emit_statements.go') or name.endswith('javascript.go'):
   if 'statement.Uninitialized' in a and '_declared' in a:return a.replace('!statement.Uninitialized)', '!statement.Uninitialized && (!e.program.Locals[statement.Local].NamespaceState || statement.Value != nil))')
   return a+'\t\t}\n'+b
  raise Exception(name)
 s=re.sub(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);p.write_text(s)
subprocess.run(['git','add',*paths],check=True)
