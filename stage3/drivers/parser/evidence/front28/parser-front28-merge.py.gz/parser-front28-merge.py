import subprocess,json
from pathlib import Path
refs=['47a6fabe','b788e96e','51761b0','16cb9b10','456c981b','0f722679','37fa06d3','7d2cbc89','c898009b','d90994da','24a2b287'];rows=[]
for ref in refs:
 row={'ref':ref,'ancestor_before':subprocess.run(['git','merge-base','--is-ancestor',ref,'HEAD']).returncode==0};rows.append(row)
 if not row['ancestor_before']:
  with Path('/workspace/scratch/parser-front28-'+ref+'-merge.log').open('wb') as log:row['merge_exit']=subprocess.run(['git','merge','--no-edit',ref],stdout=log,stderr=log).returncode
  if row['merge_exit']:break
Path('/workspace/scratch/parser-front28-merges.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
