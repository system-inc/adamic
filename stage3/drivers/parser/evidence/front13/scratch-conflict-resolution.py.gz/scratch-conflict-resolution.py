from pathlib import Path
import re,subprocess
root=Path('/tmp/parser-front7-scratch')
def blocks(s,fn):
 return re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>>[^\n]*\n',lambda m:fn(m.group(1),m.group(2)),s,flags=re.S)
# Preserve both historical documentation sections; retain each fixture row once.
for name in ['docs/escape-hatches.md','internal/oracle/counts.md']:
 p=root/name
 def combine(a,b):
  if name.startswith('docs/'):return a+b
  keys={line.split('|')[1].strip() for line in a.splitlines() if line.startswith('|')}
  return a+''.join(line for line in b.splitlines(keepends=True) if not line.startswith('|') or line.split('|')[1].strip() not in keys)
 p.write_text(blocks(p.read_text(),combine))
p=root/'internal/native/runtime/adamic.h';p.write_text(blocks(p.read_text(),lambda a,b:a+'#include "view_callables.h"\n'))
p=root/'internal/native/emit_statements.go';p.write_text(blocks(p.read_text(),lambda a,b:a))
p=root/'internal/native/emit_arrays.go';p.write_text(blocks(p.read_text(),lambda a,b:b+'\t} else '+a.lstrip()))
p=root/'internal/javascript/javascript.go'
def js(a,b):
 if 'setter :=' in a:
  return '\t\tif ir.HasArrayViews(e.program) {\n\t\t\te.line("adamicArrayWriteCheck(%s, %d);", e.value(statement.Array), statement.Element)\n\t\t}\n'+a
 return b+'\t\t}\n'+a
p.write_text(blocks(p.read_text(),js))
p=root/'internal/native/emit_expressions.go'
def native(a,b):
 if 'argument :=' in b:return b.replace('{.reference = %s}});','{.reference = %s}}, 3);')
 return '\t\tif e.hasArrayHoles() {\n\t\t\treturn e.arrayHolesMap(expression)\n\t\t}\n'+b
p.write_text(blocks(p.read_text(),native))
# Use checked-view dispatch before the previous literal/nominal proof fallback.
p=root/'internal/lower/cast.go';s=p.read_text();before=s[:s.index('func (l *lowering) cast(')];after=s[s.index('// fieldLiteral'):];incoming=subprocess.check_output(['git','-C',str(root),'show','0b141c26:internal/lower/cast.go'],text=True);body=incoming[incoming.index('func (l *lowering) cast('):incoming.index('// fieldLiteral')]
body=body.replace('as := node.AsAsExpression()','as := node.AsAsExpression()\n\tif l.nodeRequirePerformanceProjection(node) { return l.expression(as.Expression) }',1).replace('as.Type.Kind == ast.KindTypeReference && as.Type.AsTypeReferenceNode().TypeName.Text()', 'as.Type.Kind == ast.KindTypeReference && ast.IsIdentifier(as.Type.AsTypeReferenceNode().TypeName) && as.Type.AsTypeReferenceNode().TypeName.Text()').replace('source := l.checker.GetTypeAtLocation(as.Expression)','source := l.concrete(l.checker.GetTypeAtLocation(as.Expression))').replace('target := l.checker.GetTypeAtLocation(node)','target := l.concrete(l.checker.GetTypeAtLocation(node))')
start=body.index('\tmembers := source.Types()')
old=subprocess.check_output(['git','-C',str(root),'show','HEAD:internal/lower/cast.go'],text=True);tail=old[old.index('\tmessage := "cast failed:'):old.index('// fieldLiteral')]
body=body[:start]+'''\tproof, err := l.castProof(node)
\tif err != nil { return nil, err }
'''+tail
p.write_text(before+body+after)
