const fs=require('fs'),ts=require('/tmp/parser-fixed-feature-scratch/stage3/api/node_modules/typescript');
const file=process.argv[2],text=fs.readFileSync(file,'utf8'),sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);let target;
function visit(n){if(ts.isClassDeclaration(n)&&n.name?.text==='DebugTypeMapper')target=n;ts.forEachChild(n,visit);}visit(sf);if(!target)throw Error('class not found');
const start=target.getStart(sf),end=target.end;
const replacement='export interface DebugTypeMapper { kind: TypeMapKind; __debugToString(): string; } export const DebugTypeMapper: { prototype: DebugTypeMapper } = parserProofMissingMapper(); function parserProofMissingMapper(): { prototype: DebugTypeMapper } { throw "discovery-only namespace class placeholder"; }'+'\n'.repeat((text.slice(start,end).match(/\n/g)||[]).length);
fs.writeFileSync(file,text.slice(0,start)+replacement+text.slice(end));console.log(JSON.stringify({file,start,end,replacement}));
