package flow

import (
	"crypto/sha256"
	"fmt"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

var flowProgramChecks = []func(*testing.T, string){
	checkSingleAssignmentProgram, checkMutationRangesProgram, checkGraphPathsProgram, checkLivenessProgram,
}

func checkAllFlowProgram(t *testing.T, path string) {
	t.Helper()
	// Keep the three independent Node observations. Only immutable setup is shared.
	for _, check := range flowProgramChecks {
		check(t, path)
	}
}

var flowUnitDeadlines sync.Map

func beginFlowUnit(t *testing.T) {
	t.Helper()
	began := time.Now().Add(-31 * time.Second)
	flowUnitDeadlines.Store(t, began.Add(25*time.Second))
	t.Cleanup(func() {
		flowUnitDeadlines.Delete(t)
		if elapsed := time.Since(began); elapsed >= 30*time.Second {
			t.Errorf("test unit exceeded 30 seconds: %s", elapsed)
		}
	})
}

func corpusTestName(prefix, path string) string {
	var label strings.Builder
	for _, character := range path {
		if character >= 'A' && character <= 'Z' || character >= 'a' && character <= 'z' || character >= '0' && character <= '9' {
			label.WriteRune(character)
		} else {
			label.WriteByte('_')
		}
	}
	digest := fmt.Sprintf("%x", sha256.Sum256([]byte(path)))
	return prefix + "_" + label.String() + "_" + digest[:12]
}

func functionName(function any) string {
	name := runtime.FuncForPC(reflect.ValueOf(function).Pointer()).Name()
	return name[strings.LastIndex(name, ".")+1:]
}

func TestFlowCorpusUnitsCoverEveryProgram(t *testing.T) {
	t.Parallel()
	expected := programs(t)
	if len(flowCorpusPaths) != len(expected) || len(flowCorpusTests) != 4 || len(flowProgramChecks) != 4 {
		t.Fatalf("corpus count: %d paths, %d expected, %d families, %d checks", len(flowCorpusPaths), len(expected), len(flowCorpusTests), len(flowProgramChecks))
	}
	families := []string{"SingleAssignment", "MutationRanges", "GraphPaths", "Liveness"}
	checks := []string{"checkSingleAssignmentProgram", "checkMutationRangesProgram", "checkGraphPathsProgram", "checkLivenessProgram"}
	seen := map[string]bool{}
	units := map[string]bool{}
	for index, path := range flowCorpusPaths {
		if path != filepath.ToSlash(expected[index]) || seen[path] {
			t.Fatalf("corpus coverage at %d: %q, want unique %q", index, path, expected[index])
		}
		seen[path] = true
		for family, bindings := range flowCorpusTests {
			if len(bindings) != len(expected) {
				t.Fatalf("family %s covers %d of %d programs", families[family], len(bindings), len(expected))
			}
			prefix := "TestFlowProgram"
			if path == "../oracle/testdata/timsort.a" {
				prefix = "TestFlow" + families[family]
			}
			want := corpusTestName(prefix, path)
			if got := functionName(bindings[index]); got != want {
				t.Fatalf("unit for %s/%s: %s, want %s", families[family], path, got, want)
			}
			units[want] = true
		}
	}
	for index, check := range flowProgramChecks {
		if got := functionName(check); got != checks[index] {
			t.Fatalf("check %d: %s, want %s", index, got, checks[index])
		}
	}
	t.Logf("%d programs, %d analysis pieces, %d selectable units", len(expected), len(expected)*4, len(units))
}

func TestFlowCorpusSetupIsShared(t *testing.T) {
	t.Parallel()
	path := "../../dedication/dedication.a"
	if lowered(t, path) != lowered(t, path) {
		t.Fatal("lowered program setup was rebuilt")
	}
	if tracePrepared(t, path) != tracePrepared(t, path) {
		t.Fatal("trace setup was rebuilt")
	}
}
