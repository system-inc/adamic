trap 'if [[ -n ${run-} && -d ${run-} && ! -e $run/gate-archive.log ]]; then : > "$run/gate-archive.log"; fi' DEBUG
