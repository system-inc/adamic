import pathlib,json
root=pathlib.Path('/workspace/adamic'); out=pathlib.Path('/workspace/gate-affinity-evidence/oracle-once-47b8b8d5')
s=(root/'internal/oracle/cache_test.go').read_text();s=s.replace('\n\t"testing"','\n\t"testing"\n\t"time"',1)
a=s.index('func identity(');b=s.index('\n// Reuse import',a);part=s[a:b]
part=part.replace('\tgateOnce.Do(func() {','''	profileCall := time.Now()
	profileOwner := false
	gateOnce.Do(func() {
		profileOwner = true
		profileTotal := time.Now()
		defer func() { fmt.Fprintf(os.Stderr, "GATE_PROFILE {\\"test\\":%q,\\"step\\":\\"callback\\",\\"seconds\\":%.9f}\\n", t.Name(), time.Since(profileTotal).Seconds()) }()
		profileStep := time.Now()
		profileMark := func(name string) {
			elapsed := time.Since(profileStep).Seconds()
			fmt.Fprintf(os.Stderr, "GATE_PROFILE {\\"test\\":%q,\\"step\\":%q,\\"seconds\\":%.9f}\\n", t.Name(), name, elapsed)
			profileStep = time.Now()
		}''',1)
marks=[('gate.cache = &resultCache{directory: filepath.Join(directory, "adamic", "gate")}','cache-directory'),('gate.nodeVersion = string(version)','node-version'),('gate.libraries[index] = filepath.Base(filepath.Dir(library))','RUNTIME'),('runners, err := filepath.Glob', 'BEFORE_RUNNERS'),('files = append(files, runners...)','BEFORE_FILES'),('parts = append(parts, root)','repository-context'),('parts = append(parts, fmt.Sprint(stack.Cur, stack.Max))','stack-limit'),('for _, file := range files {','BEFORE_READS'),('gate.context = jsonTypesContext(cacheKey(parts...), jsonTypesDigest)','DIGEST')]
for needle,name in marks:
 if name=='RUNTIME':part=part.replace(needle,needle+'\n\t\t\tprofileMark(fmt.Sprintf("runtime-%d", index))',1)
 elif name.startswith('BEFORE_'):
  label={'BEFORE_RUNNERS':'go-harness-glob','BEFORE_FILES':'runner-glob','BEFORE_READS':'environment-capture'}[name]
  part=part.replace(needle,'profileMark("'+label+'")\n\t\t'+needle,1)
 elif name=='DIGEST':part=part.replace(needle,'profileMark("harness-reads")\n\t\t'+needle+'\n\t\tprofileMark("context-digest")',1)
 else:part=part.replace(needle,needle+'\n\t\tprofileMark("'+name+'")',1)
part=part.replace('\n\tif gateError != nil {','\n\tfmt.Fprintf(os.Stderr, "GATE_PROFILE {\\"test\\":%q,\\"step\\":\\"identity-call\\",\\"owner\\":%t,\\"seconds\\":%.9f}\\n", t.Name(), profileOwner, time.Since(profileCall).Seconds())\n\tif gateError != nil {',1)
s=s[:a]+part+s[b:];(out/'cache_test.instrumented.go').write_text(s)
(out/'overlay.json').write_text(json.dumps({'Replace':{str(root/'internal/oracle/cache_test.go'):str(out/'cache_test.instrumented.go')}}))
