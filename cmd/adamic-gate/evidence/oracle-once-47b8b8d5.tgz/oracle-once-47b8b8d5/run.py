import subprocess,time,json,pathlib,os
out=pathlib.Path('/workspace/gate-affinity-evidence/oracle-once-47b8b8d5');env=os.environ.copy();env['ADAMIC_GATE_UNCACHED']='1'
def command(*a):return subprocess.check_output(a,text=True).strip()
args=['go','test','-overlay',str(out/'overlay.json'),'-count=1','-json','-timeout','60m','-parallel','5','./internal/oracle']
for n in range(1,4):
 m={'commit':command('git','rev-parse','HEAD'),'nproc':command('nproc'),'cpu.max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'go':command('go','version'),'clang':command('clang','--version').splitlines()[0],'node':command('node','--version'),'uncached':1,'native_build_cache':'warm existing fully keyed runtime cache','instrument':args,'load_before':pathlib.Path('/proc/loadavg').read_text().strip()};start=time.monotonic()
 with open(out/f'run-{n}.jsonl','w') as log:m['exit']=subprocess.call(args,stdout=log,stderr=subprocess.STDOUT,env=env,cwd='/workspace/adamic')
 m['wall']=time.monotonic()-start;m['load_after']=pathlib.Path('/proc/loadavg').read_text().strip();(out/f'run-{n}.metadata.json').write_text(json.dumps(m,indent=2));print(json.dumps(m),flush=True)
