import json,pathlib,collections,statistics
out=pathlib.Path(__file__).parent;steps=collections.defaultdict(list);testcalls=collections.defaultdict(dict);tops=collections.defaultdict(list);runs=[]
for n in range(1,4):
 p=out/f'run-{n}.jsonl'
 if not p.exists():continue
 counts=collections.Counter();callcount=0;waitcount=0;maxwait=0;stepcount=0
 for line in p.open():
  try:r=json.loads(line)
  except:continue
  if r.get('Action') in ('pass','fail','skip'):
   counts[r['Action']]+=1
   if r.get('Test') and '/' not in r['Test'] and r['Action']=='pass':tops[r['Test']].append(r.get('Elapsed',0))
  text=r.get('Output','')
  if 'GATE_PROFILE ' not in text:continue
  q=json.loads(text.split('GATE_PROFILE ',1)[1])
  if q['step']=='identity-call':
   callcount+=1
   d=testcalls[q['test']].setdefault(n,{'calls':0,'seconds':0,'maximum':0,'owner':False});d['calls']+=1;d['seconds']+=q['seconds'];d['maximum']=max(d['maximum'],q['seconds']);d['owner']|=q['owner']
   if not q['owner']:maxwait=max(maxwait,q['seconds']);waitcount+=q['seconds']>=.001
  else:steps[q['step']].append(q['seconds']);stepcount+=1
 runs.append({'run':n,'terminals':dict(counts),'identity_calls':callcount,'nonowner_calls_at_least_1ms':waitcount,'maximum_nonowner_seconds':maxwait,'step_records':stepcount})
result={'runs':runs,'steps':{k:{'samples':v,'median':statistics.median(v)} for k,v in steps.items()},'top_level':{k:{'samples':v,'median':statistics.median(v)} for k,v in tops.items()},'identity_callers':{k:{'runs':v,'median_total_seconds':statistics.median([v.get(n,{}).get('seconds',0) for n in range(1,4)]),'median_maximum_seconds':statistics.median([v.get(n,{}).get('maximum',0) for n in range(1,4)])} for k,v in testcalls.items()}}
(out/'analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({'runs':runs,'steps':result['steps'],'largest_top_levels':sorted(result['top_level'].items(),key=lambda p:p[1]['median'],reverse=True)[:10]},indent=2))
