import subprocess,time,json,os,pathlib,sys,threading
half=sys.argv[1]; out=pathlib.Path('/workspace/gate-affinity-evidence/layout-split')/half;out.mkdir(exist_ok=True)
tests={'half-a':['TestMarkdownCodeBlockLayout','TestMarkdownLeafComposition','TestMarkdownListLayout','TestMarkdownWhitespaceLayout'],'half-b':['TestMarkdownHTMLBlockLayout','TestMarkdownQuoteLayout','TestMarkdownRootLayout','TestMarkdownStructureLayout','TestMarkdownTableLayout']}[half]
def command(*args):return subprocess.check_output(args,text=True).strip()
cg=pathlib.Path('/sys/fs/cgroup')
meta={'Half':half,'SourceCommit':command('git','rev-parse','HEAD'),'Nproc':command('nproc'),'CPUMax':(cg/'cpu.max').read_text().strip(),'MemoryLimitBytes':int((cg/'memory.max').read_text()),'Go':command('go','version'),'Clang':command('clang','--version').splitlines()[0],'Node':command('node','--version'),'LoadBefore':pathlib.Path('/proc/loadavg').read_text().strip(),'Uncached':True,'CacheState':'existing content-addressed Go/toolchain cache warm; oracle answers uncached','GOFLAGS':os.getenv('GOFLAGS',''),'CGO_ENABLED':os.getenv('CGO_ENABLED',''),'GOMAXPROCS':os.getenv('GOMAXPROCS',''),'MemoryScope':'fresh dedicated container cgroup, test process and descendants; read after go exits','StartedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
args=['go','test','-count=1','-json','-timeout','60m','-run','|'.join('^'+t+'$' for t in tests),'./stage1/cohere/markdownblocks'];meta['Command']=args
(out/'started.json').write_text(json.dumps(meta,indent=2)+'\n')
start=time.monotonic()
stop=threading.Event()
seen={}
def observe():
 with (out/'native-processes.jsonl').open('w') as evidence:
  while not stop.is_set():
   now=time.time()
   for entry in pathlib.Path('/proc').iterdir():
    if not entry.name.isdigit(): continue
    try:
     argv=(entry/'cmdline').read_bytes().decode(errors='replace').strip('\0').split('\0')
     kind=None
     if argv and pathlib.Path(argv[0]).name=='mutant':kind='native-mutant-run'
     elif argv and pathlib.Path(argv[0]).name in ('clang','clang-20') and any(pathlib.Path(arg).name=='mutant' for arg in argv):kind='native-mutant-build'
     if kind:
      pid=int(entry.name)
      if pid not in seen:seen[pid]={'PID':pid,'Kind':kind,'Args':argv,'FirstSeen':now,'LastSeen':now}
      else:seen[pid]['LastSeen']=now
    except (FileNotFoundError,PermissionError,ProcessLookupError):pass
   stop.wait(.005)
  for record in seen.values():evidence.write(json.dumps(record)+'\n')
observer=threading.Thread(target=observe);observer.start()
with (out/'test.jsonl').open('w') as stdout,(out/'test.stderr').open('w') as stderr:
 run=subprocess.run(args,stdout=stdout,stderr=stderr,env={**os.environ,'ADAMIC_GATE_UNCACHED':'1'})
stop.set();observer.join()
meta['Instrument']='external /proc process sampling every 5 ms; no test source changes; native build/run intervals approximate'
meta['NativeProcessSamples']=len(seen)
meta.update(WallSeconds=time.monotonic()-start,Exit=run.returncode,LoadAfter=pathlib.Path('/proc/loadavg').read_text().strip(),MemoryPeakBytes=int((cg/'memory.peak').read_text()),MemoryEvents=dict(line.split() for line in (cg/'memory.events').read_text().splitlines()),FinishedUTC=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
for line in (out/'test.jsonl').read_text().splitlines():
 e=json.loads(line)
 if e.get('Action')=='pass' and not e.get('Test'):meta['TestSeconds']=e['Elapsed']
(out/'measurement.json').write_text(json.dumps(meta,indent=2)+'\n')
sys.exit(run.returncode)
