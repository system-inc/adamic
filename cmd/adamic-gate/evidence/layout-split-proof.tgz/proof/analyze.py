import json,pathlib,datetime,sys
root=pathlib.Path('/workspace/gate-affinity-evidence/layout-split')
def timestamp(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
def union(intervals):
 total=0.; end=None
 for a,b in sorted(intervals):
  if end is None or a>end:total+=b-a;end=b
  elif b>end:total+=b-end;end=b
 return total
for half in sys.argv[1:] or ['half-a','half-b']:
 out=root/half
 if not (out/'measurement.json').exists():continue
 m=json.loads((out/'measurement.json').read_text());events=[json.loads(line) for line in (out/'test.jsonl').read_text().splitlines()]
 if m['Exit']!=0 or any(e['Action']=='fail' for e in events):raise SystemExit(half+' failed')
 cont=[timestamp(e['Time']) for e in events if e['Action']=='cont' and '/' not in e.get('Test','')]
 childRuns=[timestamp(e['Time']) for e in events if e['Action']=='run' and '/' in e.get('Test','')]
 markers=[e for e in events if 'original fork full Markdown parsing/layout off agrees on all' in e.get('Output','')]
 if len(markers)!=1:raise SystemExit('fixture did not build once: '+half)
 children=[e for e in events if e['Action']=='pass' and '/' in e.get('Test','')]
 if len(children)!=15:raise SystemExit('expected fifteen mutant checks: '+half+' '+str(len(children)))
 records=[json.loads(line) for line in (out/'native-processes.jsonl').read_text().splitlines()]
 builds=[(r['FirstSeen'],r['LastSeen']) for r in records if r['Kind']=='native-mutant-build']
 runs=[(r['FirstSeen'],r['LastSeen']) for r in records if r['Kind']=='native-mutant-run']
 native=union(builds+runs)
 fixture=min(childRuns)-min(cont)
 m.update(FixtureBuilds=len(markers),FixtureBeforeFirstMutantSeconds=fixture,FixtureMarkerSeconds=timestamp(markers[0]['Time'])-min(cont),MutantChecks=len(children),MutantChildSecondsSum=sum(e.get('Elapsed',0) for e in children),NativeMutantBuildProcessCount=len(builds),NativeMutantRunProcessCount=len(runs),NativeMutantBuildSecondsSum=sum(b-a for a,b in builds),NativeMutantRunSecondsSum=sum(b-a for a,b in runs),NativeMutantBuildWallUnionSeconds=union(builds),NativeMutantRunWallUnionSeconds=union(runs),NativeMutantBuildOrRunWallUnionSeconds=native,ResidualTestWallSeconds=m['TestSeconds']-fixture-native,OutsideTestSeconds=m['WallSeconds']-m['TestSeconds'],TimingCaveat='nativeMutant external build/run sampled intervals are lower bounds; residual includes Go lowering/C emission, policy controls, gaps, and sampling error')
 m['BuildFlags']=' '.join(['commit='+m['SourceCommit'],'nproc='+m['Nproc'],'cpu.max='+json.dumps(m['CPUMax']),'go='+json.dumps(m['Go']),'clang='+json.dumps(m['Clang']),'node='+json.dumps(m['Node']),'load_before='+json.dumps(m['LoadBefore']),'load_after='+json.dumps(m['LoadAfter']),'uncached=1','cached_builds=warm','GOFLAGS='+json.dumps(m['GOFLAGS']),'CGO_ENABLED='+json.dumps(m['CGO_ENABLED']),'GOMAXPROCS='+json.dumps(m['GOMAXPROCS']),'instrument='+json.dumps(m['Instrument'])])
 (out/'measurement.json').write_text(json.dumps(m,indent=2)+'\n')
 (out/'analysis.json').write_text(json.dumps(m,indent=2)+'\n')
 print(json.dumps(m,indent=2))
