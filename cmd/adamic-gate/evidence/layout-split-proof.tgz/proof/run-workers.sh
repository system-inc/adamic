#!/bin/bash
set -euo pipefail
worker_docker=(docker --host=unix:///var/run/docker.sock)
worker_flags=(--cpus=4 --memory=16g --memory-swap=16g --user=1000:1000 --env HOME=/home/agent --env ADAMIC_TOOLS=/workspace/adamic-tools --entrypoint=/bin/bash --mount type=bind,src=/usr,dst=/usr,readonly --mount type=bind,src=/lib,dst=/lib,readonly --mount type=bind,src=/lib64,dst=/lib64,readonly --mount type=bind,src=/workspace,dst=/workspace --mount type=bind,src=/home/agent,dst=/home/agent --mount type=bind,src=/etc/ssl/certs,dst=/etc/ssl/certs,readonly --workdir=/workspace/gate-affinity-47fb)
for worker_half in half-a half-b; do
 mkdir -p "/workspace/gate-affinity-evidence/layout-split/$worker_half"
 if [ ! -f "/workspace/gate-affinity-evidence/layout-split/$worker_half/setup.json" ]; then
 worker_start=$(date +%s.%N)
 "${worker_docker[@]}" run --rm --name "adamic-layout-$worker_half-setup" "${worker_flags[@]}" ubuntu:24.04 -c 'mkdir -p /tmp/adamic-gate; chmod 1777 /tmp/adamic-gate; bash cloud/setup.sh --gate-inputs' > "/workspace/gate-affinity-evidence/layout-split/$worker_half/setup.log" 2>&1
 worker_end=$(date +%s.%N)
 python3 - "$worker_start" "$worker_end" "$worker_half" <<'PY'
import json,sys,pathlib
(pathlib.Path('/workspace/gate-affinity-evidence/layout-split')/sys.argv[3]/'setup.json').write_text(json.dumps({'WallSeconds':float(sys.argv[2])-float(sys.argv[1]),'Instrument':'fresh 4-CPU 16-GiB worker setup: bash cloud/setup.sh --gate-inputs; includes docker start/exit overhead'},indent=2)+'\n')
PY
 fi
 "${worker_docker[@]}" run --rm --name "adamic-layout-$worker_half-test" "${worker_flags[@]}" ubuntu:24.04 -c "mkdir -p /tmp/adamic-gate; chmod 1777 /tmp/adamic-gate; source /workspace/adamic-tools/env.sh; python3 /workspace/gate-affinity-evidence/layout-split/measure.py $worker_half" > "/workspace/gate-affinity-evidence/layout-split/$worker_half/container.log" 2>&1
 done
