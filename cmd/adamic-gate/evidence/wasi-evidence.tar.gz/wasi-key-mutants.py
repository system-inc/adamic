import json,subprocess
from pathlib import Path
repo=Path('/workspace/adamic');base=Path('/workspace/gate-evidence/wasi-key-mutants');base.mkdir(exist_ok=True)
cases=[('sdk-key','resume.go','external["wasi-sdk"] = sdk','_ = sdk','TestWASISDKResumeIdentity'),('skip-verdict','wasi.go','var failures []string','return nil\n var failures []string','TestRequiredWASISkips'),('preflight','wasi.go','func wasiReady() error {','func wasiReady() error {\n return nil','TestWASIPreflight'),('unknown-gate','wasi.go','if !valid {','if false && !valid {','TestWASISourceGates')]
cases += [
 ('test-variable','wasi.go','[]string{"ADAMIC_TEST_WASI", "ADAMIC_ORACLE_WASI"}','[]string{"ADAMIC_ORACLE_WASI"}','TestWASIPreflight'),
 ('oracle-variable','wasi.go','[]string{"ADAMIC_TEST_WASI", "ADAMIC_ORACLE_WASI"}','[]string{"ADAMIC_TEST_WASI"}','TestWASIPreflight'),
 ('sdk-header','wasi.go','if !headerFound {','if false && !headerFound {','TestWASIPreflight'),
 ('sdk-library','wasi.go','filepath.Join(sysroot, "lib", "wasm32-wasi", "libc.a"),','', 'TestWASIPreflight'),
 ('sdk-executable','wasi.go','info.Mode().Perm()&0111 == 0','false','TestWASIPreflight'),
 ('sdk-layout','wasi.go',', filepath.Join(sysroot, "include", "wasm32-wasi", "stdlib.h")','', 'TestWASIPreflight')
]
cases += [('sdk-linker','wasi.go',', filepath.Join(filepath.Dir(filepath.Dir(sysroot)), "bin", "wasm-ld")','', 'TestWASIPreflight')]
results=[]
for name,file,old,new,test in cases:
 src=repo/'cmd/adamic-gate'/file;text=src.read_text();assert old in text
 out=base/(name+'.go');out.write_text(text.replace(old,new,1));overlay=base/(name+'.json');overlay.write_text(json.dumps({'Replace':{str(src):str(out)}}))
 with (base/(name+'.log')).open('w') as log: p=subprocess.run(['go','test','-count=1','-overlay='+str(overlay),'-run','^'+test+'$','./cmd/adamic-gate'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 body=(base/(name+'.log')).read_text();assert p.returncode and '--- FAIL: '+test in body,(name,body)
 results.append({'mutant':name,'exit':p.returncode,'caught_by':test})
(base/'results.json').write_text(json.dumps(results,indent=2))
