package gateprobe
import ("os";"testing")
func TestWASIProbe(t *testing.T) { if os.Getenv("ADAMIC_ORACLE_WASI") != "1" { t.Skip("missing WASI variables") } }
func TestOptionalSkip(t *testing.T) { t.Skip("optional") }
