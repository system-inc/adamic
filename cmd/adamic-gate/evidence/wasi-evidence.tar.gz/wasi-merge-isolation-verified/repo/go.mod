module gateprobe

go 1.27.1
