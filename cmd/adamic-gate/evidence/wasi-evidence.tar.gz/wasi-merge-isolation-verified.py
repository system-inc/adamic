import os,json,subprocess
from pathlib import Path
base=Path('/workspace/gate-evidence/wasi-merge-isolation-verified');base.mkdir(exist_ok=True)
repo=base/'repo';repo.mkdir(exist_ok=True)
for name in ['cmd','internal','cmd/adamic-gate']: (repo/name).mkdir(parents=True,exist_ok=True)
(repo/'go.mod').write_text('module gateprobe\n\ngo 1.27.1\n')
(repo/'cmd/adamic-gate/timings.json').write_text('{}\n')
(repo/'probe_test.go').write_text('''package gateprobe
import ("os";"testing")
func TestWASIProbe(t *testing.T) { if os.Getenv("ADAMIC_ORACLE_WASI") != "1" { t.Skip("missing WASI variables") } }
func TestOptionalSkip(t *testing.T) { t.Skip("optional") }
''')
for args in [['git','init'],['git','add','.'],['git','commit','-m','WASI merger isolation fixture']]: subprocess.run(args,cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
sdk=base/'sdk'
for name in ['share/wasi-sysroot/include/stdlib.h','share/wasi-sysroot/lib/wasm32-wasi/libc.a','bin/clang','bin/wasm-ld']:
 p=sdk/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('placeholder\n');p.chmod(0o700)
env=dict(os.environ,ADAMIC_TOOLS='',ADAMIC_TEST_WASI='1',ADAMIC_ORACLE_WASI='1',WASI_SYSROOT=str(sdk/'share/wasi-sysroot'))
def run(label,args,environment=env):
 with (base/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo,env=environment,stdout=log,stderr=subprocess.STDOUT)
 return p.returncode
normal='/workspace/adamic-gate-wasi-final';bypass='/workspace/adamic-gate-wasi-bypass'
assert run('control-shard',[normal,'shard','-index','0','-count','1','-out',str(base/'control')])==0
assert run('control-merge',[normal,'merge','-out',str(base/'control-merged'),str(base/'control')])==0
missing=env.copy()
for k in ['ADAMIC_TEST_WASI','ADAMIC_ORACLE_WASI','WASI_SYSROOT']:missing.pop(k,None)
assert run('skip-shard',[bypass,'shard','-index','0','-count','1','-out',str(base/'skip')],missing)==0
assert run('skip-merge',[normal,'merge','-out',str(base/'skip-merged'),str(base/'skip')],missing)!=0
m=json.loads((base/'skip-merged/merged.json').read_text());assert m['Fail']==0 and m['Skip']==2 and len(m['Errors'])==1 and 'required WASI unit gateprobe::TestWASIProbe skipped' in m['Errors'][0],m['Errors']
(base/'result.json').write_text(json.dumps({'control':'GREEN pass=1 fail=0 skip=1','mutant':'RED pass=0 fail=0 skip=2','errors':m['Errors'],'scope':'miniature merger isolation; placeholder SDK, no wasm execution'},indent=2))
