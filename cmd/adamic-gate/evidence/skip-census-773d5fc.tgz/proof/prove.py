import json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/census-evidence/proof');root.mkdir(exist_ok=True)
p=json.load(open('/workspace/census-plan.json'))
u=next(u for u in p['Units'] if u['Package'].endswith('/stage1/typescript/parser') and u['Test']=='TestWholeCompilerAgrees');index=u['Shard']
source=os.environ['ADAMIC_TYPESCRIPT_SOURCE']
for name in ['absent','present']:
 env=os.environ.copy();env['ADAMIC_GATE_UNCACHED']='1'
 if name=='absent':env.pop('ADAMIC_TYPESCRIPT_SOURCE',None)
 else:env['ADAMIC_TYPESCRIPT_SOURCE']=source
 case=root/name;case.mkdir(exist_ok=True)
 args=['/workspace/adamic-gate-census','shard','-index',str(index),'-count','15','-scratch','/workspace/census-scratch','-out',str(case/'shard')]
 started=time.monotonic()
 with (case/'shard.stdout').open('w') as out,(case/'shard.stderr').open('w') as err:
  result=subprocess.run(args,env=env,stdout=out,stderr=err)
 with (case/'merge.stdout').open('w') as out,(case/'merge.stderr').open('w') as err:
  merge=subprocess.run(['/workspace/adamic-gate-census','merge','-out',str(case/'merged'),str(case/'shard')],env=env,stdout=out,stderr=err)
 m=json.load(open(case/'merged/merged.json'));s=json.load(open(case/'shard/summary.json'))
 if name=='absent':
  assert any('TestWholeCompilerAgrees' in t for t in m['SkipCensus']['RequiredInput']),m['SkipCensus']
  assert 'ADAMIC_TYPESCRIPT_SOURCE' in (case/'merge.stderr').read_text()
 else:
  assert m['SkipCensus']['Status']=='checked' and not m['SkipCensus']['RequiredInput'] and not m['SkipCensus']['Unknown'],m['SkipCensus']
 data={'Case':name,'Commit':p['Commit'],'Index':index,'Command':args,'Exit':result.returncode,'MergeExit':merge.returncode,'Seconds':time.monotonic()-started,'Summary':{k:s[k] for k in ['Pass','Fail','Skip','WallSeconds','BuildFlags','Errors']},'Census':m['SkipCensus'],'Errors':m['Errors']}
 (case/'report.json').write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps({k:data[k] for k in ['Case','Index','Exit','MergeExit','Seconds','Census']}),flush=True)
