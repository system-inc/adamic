import os,subprocess,time,json
from pathlib import Path
p=Path('/workspace/gate-concurrency-measure/two-two/measurement.json')
end=time.monotonic()+3600
while not p.exists():
 if time.monotonic()>end:raise TimeoutError('third trial did not finish')
 time.sleep(1)
assert json.loads(p.read_text())['Exit']==0
raise SystemExit(subprocess.call(['python3','/workspace/gate-concurrency-measure/repeat.py']))
