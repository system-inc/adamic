import json,os,subprocess,time,hashlib
from pathlib import Path
root=Path('/workspace/gate-concurrency-measure')
repo=Path('/workspace/adamic')
fixed='6f61080201f13b84cdec1bc6078b1813d135ac21'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()==fixed
plan=json.load(open('/workspace/gate-concurrency-plan.json'))
heavy=max(plan['Shards'],key=lambda s:s['Seconds'])['Shard']
assert heavy==8
mem=Path('/sys/fs/cgroup/memory.current')
results=[]
for label,setting in [('today','auto'),('four-one','4x1'),('two-two','2x2')]:
 directory=root/label
 directory.mkdir()
 command=['/workspace/gate-concurrency-measure/time-tools/usr/bin/time','-v','-o',str(directory/'time.txt'),'/workspace/adamic-gate-budget','shard','-index',str(heavy),'-count','15','-concurrency',setting,'-scratch','/workspace/gate-concurrency-scratch','-out',str(directory/'shard')]
 before=' '.join(str(x) for x in os.getloadavg())
 began=time.monotonic();peak=0
 with (directory/'stdout.log').open('w') as stdout,(directory/'stderr.log').open('w') as stderr,(directory/'samples.jsonl').open('w') as samples:
  proc=subprocess.Popen(command,cwd=repo,stdout=stdout,stderr=stderr,start_new_session=True)
  last=0
  while proc.poll() is None:
   memory=int(mem.read_text());peak=max(peak,memory)
   now=time.monotonic()-began
   if now-last>=5:
    samples.write(json.dumps({'Seconds':now,'CgroupMemory':memory,'Load':os.getloadavg()})+'\n');samples.flush();last=now
   time.sleep(.1)
  code=proc.returncode
 after=' '.join(str(x) for x in os.getloadavg())
 record={'Setting':setting,'Commit':fixed,'Command':command,'WallSeconds':time.monotonic()-began,'LoadBefore':before,'LoadAfter':after,'SampledCgroupPeakBytes':peak,'Exit':code}
 summary=directory/'shard/summary.json'
 if summary.exists():
  s=json.load(summary.open());record.update({'Pass':s['Pass'],'Fail':s['Fail'],'Skip':s['Skip'],'BuildFlags':s['BuildFlags'],'Concurrency':s['Concurrency'],'SummaryWallSeconds':s['WallSeconds'],'Errors':s['Errors']})
  verdict={r['Package']+'::'+r['Test']:r['Action'] for r in s['Results'] if r['Test']}
  record['Verdicts']=verdict
 (directory/'measurement.json').write_text(json.dumps(record,indent=2)+'\n')
 results.append(record)
 (root/'measurements.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,record['WallSeconds'],code,flush=True)
 if code!=0:break
