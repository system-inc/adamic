from pathlib import Path
import subprocess,json
root=Path('/workspace/adamic');base=Path('/workspace/gate-evidence/ready-mutants');base.mkdir(exist_ok=True)
mutants=[('leader-only-kill','internal/boundedrun/run.go','syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)','syscall.Kill(cmd.Process.Pid, syscall.SIGKILL)'),('arm-before-readiness','internal/boundedrun/run_test.go','WithTimeout = factory','WithTimeout = context.WithTimeout')]
rows=[]
for name,file,before,after in mutants:
 source=(root/file).read_text();assert before in source
 p=base/(name+'.go');p.write_text(source.replace(before,after))
 overlay=base/(name+'.overlay.json');overlay.write_text(json.dumps({'Replace':{str(root/file):str(p)}}))
 with (base/(name+'.jsonl')).open('w') as stdout,(base/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(['go','test','-race','-count=1','-json','-run','^TestReadyDeadlineStartsAfterGrandchild$','-overlay='+str(overlay),'./internal/boundedrun'],cwd=root,stdout=stdout,stderr=stderr)
 events=[json.loads(l) for l in (base/(name+'.jsonl')).open()]
 assert result.returncode!=0 and any(e['Action']=='fail' and e.get('Test')=='TestReadyDeadlineStartsAfterGrandchild' for e in events),(name,result.returncode)
 rows.append({'mutant':name,'caught_by':'TestReadyDeadlineStartsAfterGrandchild','exit':result.returncode})
(base/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
