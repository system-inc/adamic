import subprocess,os,json,time
from pathlib import Path
base=Path('/workspace/gate-evidence/ready-load-final');base.mkdir(exist_ok=True)
workers=[];runs=[];files=[]
try:
 for i in range(40):workers.append(subprocess.Popen(['python3','-c','while True: pass'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
 packages=['./cmd/adamic-gate','./internal/boundedrun','./internal/fuzz','./cmd/adamic-test262']
 argv=['go','test','-race','-count=20','-json','-run','Deadline|ExitedLeader|WaitCannot|CompilerWorkerTimeout',*packages]
 before=Path('/proc/loadavg').read_text().strip()
 for i in range(2):
  out=(base/f'run-{i}.jsonl').open('w');err=(base/f'run-{i}.stderr').open('w');files.extend([out,err])
  runs.append(subprocess.Popen(argv,cwd='/workspace/adamic',stdout=out,stderr=err))
 deadline=time.monotonic()+900
 while any(p.poll() is None for p in runs):
  if time.monotonic()>deadline:raise TimeoutError('load proof exceeded 15-minute supervisor')
  time.sleep(.5)
 codes=[p.returncode for p in runs]
 after=Path('/proc/loadavg').read_text().strip()
 for f in files:f.close()
 records=[]
 for i,code in enumerate(codes):
  events=[json.loads(l) for l in (base/f'run-{i}.jsonl').open()]
  passes=[e for e in events if e['Action']=='pass' and e.get('Test')]
  failures=[e for e in events if e['Action'] in ('fail','build-fail')]
  records.append({'run':i,'exit':code,'passes':len(passes),'failures':failures,'argv':argv})
 (base/'results.json').write_text(json.dumps({'cpu_burners':40,'parallel_go_invocations':2,'load_before':before,'load_after':after,'runs':records},indent=2)+'\n')
 assert all(code==0 for code in codes),codes
finally:
 for p in runs:
  if p.poll() is None:p.kill()
 for p in workers:
  if p.poll() is None:p.terminate()
 for p in [*runs,*workers]:
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for f in files:
  if not f.closed:f.close()
