import os,json,subprocess
from pathlib import Path
base=Path('/workspace/gate-evidence/complement-followup-cli');base.mkdir(exist_ok=True);repo=base/'repo';repo.mkdir(exist_ok=True)
for path in ['cmd/adamic-gate','internal/oracle/testdata']:(repo/path).mkdir(parents=True,exist_ok=True)
(repo/'go.mod').write_text('module coverageprobe\n\ngo 1.27.1\n')
(repo/'cmd/adamic-gate/timings.json').write_text(json.dumps({'coverageprobe/internal/oracle::TestNativeAgreesWithNode/internal/oracle/testdata/base.a':1}))
(repo/'internal/oracle/oracle_test.go').write_text('''package oracle
import "testing"
var fixtures=[]struct{path string;lowers,checked bool}{{"internal/oracle/testdata/base.a",true,false}}
func TestNativeAgreesWithNode(t *testing.T){for _,fixture:=range fixtures{t.Run(fixture.path,func(t *testing.T){})}}
''')
(repo/'internal/oracle/extra_test.go').write_text('''package oracle
func init(){for _,name:=range []string{"planted_init"}{fixtures=append(fixtures,struct{path string;lowers,checked bool}{"internal/oracle/testdata/"+name+".a",true,false})}}
''')
for name in ['base','planted_init']:(repo/f'internal/oracle/testdata/{name}.a').write_text('console.log("fixture");\n')
subprocess.run(['gofmt','-w','internal'],cwd=repo,check=True)
for args in [['git','init'],['git','add','.'],['git','commit','-m','Init registration complement proof']]:subprocess.run(args,cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
env=dict(os.environ,ADAMIC_TOOLS='',ADAMIC_GATE_UNCACHED='1');env.pop('WASI_SYSROOT',None)
mutant='/workspace/adamic-gate-omit-fixture'
def run(name,args,good=True):
 with (base/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=log)
 assert (p.returncode==0)==good,(name,(base/(name+'.log')).read_text()[-4000:])
for i in range(2):run('shard'+str(i),[mutant,'shard','-index',str(i),'-count','2','-jobs','4','-out',str(base/f'shard{i}')])
run('merge',[mutant,'merge','-out',str(base/'merged'),str(base/'shard0'),str(base/'shard1')])
m=json.loads((base/'merged/merged.json').read_text());assert m['Green'] and m['TestEvents']==3 and len(m['Unplanned'])==1 and 'planted_init' in m['Unplanned'][0],m
run('plain',['go','test','-count=1','-json','./...'])
run('compare',[mutant,'compare',str(base/'merged'),str(base/'plain.log')])
# A missing complement invocation must fail independently of child ownership.
s=json.loads((base/'shard1/summary.json').read_text());s['Invocations'][0]['Args']=s['Invocations'][0]['Args'][:-1];(base/'shard1/summary.json').write_text(json.dumps(s));run('missing-complement',[mutant,'merge','-out',str(base/'bad-merged'),str(base/'shard0'),str(base/'shard1')],False)
(base/'result.json').write_text(json.dumps({'green':m['Green'],'test_events':m['TestEvents'],'unplanned':m['Unplanned'],'compare':'empty','missing_complement':'red'},indent=2))
