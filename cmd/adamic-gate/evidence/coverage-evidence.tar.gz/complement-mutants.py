import pathlib,json,subprocess,os
root=pathlib.Path('/workspace/adamic'); out=pathlib.Path('/workspace/gate-evidence/complement-mutants'); out.mkdir(exist_ok=True)
mutants=[
 ('jobs-key','complement.go','return digestJSON([]any{identity, jobs})','return digestJSON(identity)','TestComplementRequiredAndDuplicatesRefused'),
 ('skip-key','complement.go','json.Marshal(s)','json.Marshal(s.Run)','TestComplementRequiredAndDuplicatesRefused'),
 ('skip-flag','complement.go','args = append(args, "-skip", s.Skip)','args = append(args)','TestComplementRunsInitRegisteredFixture'),
 ('parent-terminal','resume.go','if !found {\n\t\t\tproblems = append(problems, "complement parent has no terminal event:', 'if false && !found {\n\t\t\tproblems = append(problems, "complement parent has no terminal event:', 'TestComplementCheckpointRequiresParentTerminal'),
 ('unknown-duplicate','main.go','if previous, ok := seenTest[r.key()]; ok {','if previous, ok := seenTest[r.key()]; false && ok {','TestComplementRequiredAndDuplicatesRefused')]
results=[]
for name,file,before,after,test in mutants:
 source=(root/'cmd/adamic-gate'/file).read_text()
 assert before in source,(name,before)
 # Duplicate mutant changes only the complement branch, retaining the owned-child check.
 if name=='unknown-duplicate':
  pos=source.index('if complementOwns(expected, index, r) {'); source=source[:pos]+source[pos:].replace(before,after,1)
 else: source=source.replace(before,after,1)
 replacement=out/(name+'.go'); replacement.write_text(source)
 overlay=out/(name+'.overlay.json'); overlay.write_text(json.dumps({'Replace':{str(root/'cmd/adamic-gate'/file):str(replacement)}}))
 log=out/(name+'.jsonl')
 with log.open('w') as f:
  result=subprocess.run(['go','test','-count=1','-json','-overlay='+str(overlay),'-run','^'+test+'$','./cmd/adamic-gate'],cwd=root,stdout=f,stderr=f)
 events=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
 assert result.returncode!=0 and any(e.get('Action')=='fail' and e.get('Test')==test for e in events),name
 results.append({'mutant':name,'caught_by':test,'exit':result.returncode})
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
