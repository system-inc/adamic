import os,json,subprocess,time
from pathlib import Path
base=Path('/workspace/gate-evidence/coverage-bench');base.mkdir(exist_ok=True);repo=base/'repo';repo.mkdir(exist_ok=True)
for name in ['cmd/adamic-gate','internal','stage1/cohere/lint']:(repo/name).mkdir(parents=True,exist_ok=True)
(repo/'go.mod').write_text('module benchprobe\n\ngo 1.27.1\n')
weights={}
for i in range(16):
 d=repo/f'package{i:02}';d.mkdir(exist_ok=True);(d/'probe_test.go').write_text('package probe\nimport("testing";"time")\nfunc TestDelay(t *testing.T){time.Sleep(300*time.Millisecond)}\n');weights[f'benchprobe/package{i:02}::TestDelay']=1
names=[f'directory{i:02}/fixture.a' for i in range(32)]
(repo/'stage1/cohere/lint/lint_test.go').write_text('package lint\nimport("testing";"time")\nfunc TestMutants(t *testing.T){time.Sleep(180*time.Millisecond);for _,row:=range []struct{name string}{'+','.join('{'+json.dumps(x)+'}' for x in names)+'}{t.Run(row.name,func(t *testing.T){time.Sleep(30*time.Millisecond)})}}\n')
for name in names:weights['benchprobe/stage1/cohere/lint::TestMutants/'+name]=.1
(repo/'cmd/adamic-gate/timings.json').write_text(json.dumps(weights))
for args in [['git','init'],['git','add','.'],['git','commit','-m','Bounded package and selector scheduling corpus']]:subprocess.run(args,cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
env=dict(os.environ,ADAMIC_TOOLS='',ADAMIC_GATE_UNCACHED='1');env.pop('WASI_SYSROOT',None)
with (base/'warm.log').open('w') as log:subprocess.run(['go','test','-count=1','-run','^$','./...'],cwd=repo,env=env,stdout=log,stderr=log,check=True)
results=[]
for repeat in range(3):
 for index in range(8):
  order=['before','after'] if repeat%2==0 else ['after','before']
  for phase in order:
   tool='/workspace/adamic-gate-wasi-final' if phase=='before' else '/workspace/adamic-gate-complement'
   out=base/f'{phase}-{repeat}-{index}';cmd=[tool,'shard','-index',str(index),'-count','8','-out',str(out)]
   if phase=='after':cmd+=['-jobs','4']
   began=time.monotonic()
   with (base/f'{phase}-{repeat}-{index}.log').open('w') as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=log)
   if p.returncode:raise RuntimeError((phase,repeat,index,(base/f'{phase}-{repeat}-{index}.log').read_text()[-2500:]))
   summary=json.loads((out/'summary.json').read_text());results.append({'phase':phase,'repeat':repeat,'shard':index,'wall':summary['WallSeconds'],'instrument':cmd,'build_flags':summary['BuildFlags'],'invocations':len(summary['Invocations'])})
   (base/'results.json').write_text(json.dumps(results,indent=2))
cmd=['/workspace/adamic-gate-complement','merge','-out',str(base/'merged')]+[str(base/f'after-2-{i}') for i in range(8)]
with (base/'merge.log').open('w') as log:subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=log,check=True)
with (base/'plain.jsonl').open('w') as log:subprocess.run(['go','test','-count=1','-json','./...'],cwd=repo,env=env,stdout=log,stderr=log,check=True)
with (base/'compare.log').open('w') as log:subprocess.run(['/workspace/adamic-gate-complement','compare',str(base/'merged'),str(base/'plain.jsonl')],cwd=repo,env=env,stdout=log,stderr=log,check=True)
