package probe
import("testing";"time")
func TestDelay(t *testing.T){time.Sleep(300*time.Millisecond)}
