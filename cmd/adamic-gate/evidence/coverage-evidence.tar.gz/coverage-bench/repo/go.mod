module benchprobe

go 1.27.1
