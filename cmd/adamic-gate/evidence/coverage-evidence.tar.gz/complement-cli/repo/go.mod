module coverageprobe

go 1.27.1
