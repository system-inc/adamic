package oracle

func init() {
	for _, name := range []string{"planted_init"} {
		fixtures = append(fixtures, struct {
			path            string
			lowers, checked bool
		}{"internal/oracle/testdata/" + name + ".a", true, false})
	}
}
