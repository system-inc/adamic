package oracle

import "testing"

var fixtures = []struct {
	path            string
	lowers, checked bool
}{{"internal/oracle/testdata/base.a", true, false}}

func TestNativeAgreesWithNode(t *testing.T) {
	for _, fixture := range fixtures {
		t.Run(fixture.path, func(t *testing.T) {})
	}
}
