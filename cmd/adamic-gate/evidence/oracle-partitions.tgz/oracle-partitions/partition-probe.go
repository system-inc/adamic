package main
import("encoding/json";"os";"testing")
func TestWriteOraclePartitions(t *testing.T){
 var source plan; if err:=loadJSON(os.Getenv("ADAMIC_PARTITION_PLAN"),&source);err!=nil {t.Fatal(err)}
 var weights map[string]float64;if err:=loadJSON(os.Getenv("ADAMIC_PARTITION_WEIGHTS"),&weights);err!=nil {t.Fatal(err)}
 const pkg="github.com/system-inc/adamic/internal/oracle"
 p:=plan{Count:2};for _,u:=range source.Units {if u.Package==pkg {p.Units=append(p.Units,u)}}
 if err:=assignUnits(&p,weights);err!=nil {t.Fatal(err)};p.Complements=complements(p)
 type half struct{Index int;Units []unit;Commands [][]string;Predicted float64}
 var halves []half
 for index:=0;index<2;index++ {h:=half{Index:index};for _,u:=range p.Units {if u.Shard==index {h.Units=append(h.Units,u)}};for _,s:=range selections(p,index,pkg){h.Commands=append(h.Commands,concurrencyArgs(selectionArgs(pkg,s),5))};for _,r:=range predictions(p,weights){if r.Shard==index {h.Predicted=r.Seconds}};halves=append(halves,h)}
 bytes,err:=json.MarshalIndent(halves,"","  ");if err!=nil{t.Fatal(err)};if err:=os.WriteFile(os.Getenv("ADAMIC_PARTITION_OUTPUT"),bytes,0600);err!=nil{t.Fatal(err)}
}
func TestWrite47Replan(t *testing.T){
 var p plan;if err:=loadJSON(os.Getenv("ADAMIC_PARTITION_PLAN"),&p);err!=nil{t.Fatal(err)}
 var weights map[string]float64;if err:=loadJSON(os.Getenv("ADAMIC_PARTITION_WEIGHTS"),&weights);err!=nil{t.Fatal(err)}
 if err:=assignUnits(&p,weights);err!=nil{t.Fatal(err)};p.Complements=complements(p)
 if err:=assignArchive(&p,weights);err!=nil{t.Fatal(err)}
 p.Shards=predictions(p,weights);p.PackageSeconds=packagePredictions(p,weights);p.Digest=planDigest(p)
 if err:=saveJSON(os.Getenv("ADAMIC_PARTITION_OUTPUT"),p);err!=nil{t.Fatal(err)}
}
