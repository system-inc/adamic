import os,pathlib,json,time,subprocess,statistics
out=pathlib.Path('/workspace/gate-affinity-evidence/oracle-partitions');root='/workspace/adamic';env=os.environ.copy();env['ADAMIC_GATE_UNCACHED']='1'
def probe(*a):return subprocess.check_output(a,env=env,text=True,cwd=root).strip()
flags={'commit':probe('git','rev-parse','HEAD'),'nproc':probe('nproc'),'cpu.max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'go':probe('go','version'),'clang':probe('clang','--version').splitlines()[0],'node':probe('node','--version'),'cached':'Go compilation cache warm; uncached oracle results'}
rows=[]
for n in range(1,4):
 cmd=['go','build','-o',str(out/f'formatter-{n}'),'./command/cohere'];before=pathlib.Path('/proc/loadavg').read_text().strip();start=time.monotonic()
 with (out/f'formatter-{n}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=log,cwd=root+'/cohere',env=env)
 row=dict(flags,command=cmd,wall=time.monotonic()-start,exit=r.returncode,load_before=before,load_after=pathlib.Path('/proc/loadavg').read_text().strip());rows.append(row);assert r.returncode==0,row
(out/'formatter.metadata.json').write_text(json.dumps(rows,indent=2));print('formatter median',statistics.median(r['wall'] for r in rows),flush=True)
