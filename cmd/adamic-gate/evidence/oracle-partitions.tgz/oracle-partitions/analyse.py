import pathlib,json,collections,statistics
r=pathlib.Path('/workspace/gate-affinity-evidence/oracle-partitions')
def verdicts(name):
 result={};times={}
 for p in (r/name).glob('test-*.jsonl'):
  for l in p.read_text().splitlines():
   e=json.loads(l);n=e.get('Test','');action=e.get('Action')
   if n and action in ['pass','fail','skip']:
    assert n not in result or result[n]==action,(name,n,result[n],action)
    result[n]=action;times[n]=e.get('Elapsed',0)
 return result,times
whole,wholeTimes=verdicts('whole');base=json.loads((r/'whole/metadata.json').read_text());rows=[]
for n in [1,2]:
 union={}
 for half in [0,1]:
  name=f'half-{half}-{n}';v,t=verdicts(name);m=json.loads((r/name/'metadata.json').read_text());assert not m['status'],m['status'];assert all(c['exit']==0 for c in m['commands']);assert 'oom 0' in m['memory_events']
  for k,a in v.items():assert k not in union or union[k]==a,(k,a);union[k]=a
  improvement=(1-m['total_seconds']/base['total_seconds'])*100
  row={'case':name,'setup':m['setup_seconds'],'tests':m['test_seconds'],'total':m['total_seconds'],'improvement_percent':improvement,'memory_peak_GiB':int(m['memory_peak'])/2**30,'verdict_counts':dict(collections.Counter(v.values())),'heaviest_parents':sorted([(k,t[k]) for k in v if '/' not in k and v[k]=='pass'],key=lambda x:-x[1])[:6]};rows.append(row)
 assert union==whole,{'repeat':n,'missing':sorted(whole.keys()-union.keys()),'extra':sorted(union.keys()-whole.keys()),'different':[(k,union[k],a) for k,a in whole.items() if k in union and union[k]!=a]}
 (r/f'union-{n}.json').write_text(json.dumps(union,sort_keys=True,separators=(',',':')))
assert all(x['improvement_percent']>=2 for x in rows),rows
(r/'whole-verdicts.json').write_text(json.dumps(whole,sort_keys=True,separators=(',',':')))
answer={'baseline':{k:base[k] for k in ['commit','setup_seconds','test_seconds','total_seconds','memory_peak']},'whole_counts':dict(collections.Counter(whole.values())),'rows':rows,'union_equal':True,'retain_unpin':True,'scope':'fresh 4-CPU/16-GiB containers on one physical 5-core cloud box; identical preinstalled tools/input and Go-cache images, fresh package fixture caches; default ordinary oracle inputs with nine unchanged skips; no fresh independent VMs or fully enabled WASI proof'}
(r/'analysis.json').write_text(json.dumps(answer,indent=2));print(json.dumps(answer,indent=2))
