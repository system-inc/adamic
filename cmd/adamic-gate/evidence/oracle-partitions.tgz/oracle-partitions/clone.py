import pathlib,subprocess,json
source=pathlib.Path('/workspace/adamic');dest=pathlib.Path('/workspace/oracle-partition-isolated')
def git(*a,cwd=None):return subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
def clone(src,dst):
 subprocess.check_call(['git','clone','--no-local','--depth','1','--no-checkout',str(src),str(dst)])
 subprocess.check_call(['git','checkout','--detach',git('rev-parse','HEAD',cwd=src)],cwd=dst)
 if not (src/'.gitmodules').exists():return
 subprocess.check_call(['git','submodule','init'],cwd=dst)
 text=git('config','-f','.gitmodules','--get-regexp',r'^submodule\..*\.path$',cwd=src)
 for line in text.splitlines():
  path=line.split(' ',1)[1];clone(src/path,dst/path)
if not dest.exists():clone(source,dest)
print('checkout',git('rev-parse','HEAD',cwd=dest));print('status',git('status','--porcelain',cwd=dest))
