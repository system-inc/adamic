import pathlib,subprocess,time,json,os
r=pathlib.Path('/workspace/gate-affinity-evidence/oracle-partitions');image=r/'go-cache-image'
cache=subprocess.check_output(['go','env','GOCACHE'],text=True).strip()
if not image.exists():subprocess.check_call(['cp','-al',cache,str(image)])
for name in ['whole','half-0-1','half-1-1','half-0-2','half-1-2']:
 out=r/name;out.mkdir(exist_ok=True)
 if (out/'metadata.json').exists():continue
 if not (out/'go-cache').exists():subprocess.check_call(['cp','-al',str(image),str(out/'go-cache')])
 if (out/'setup.log').exists():
  for file in ['setup.log','container.log']:
   if (out/file).exists():(out/file).rename(out/(file+'.failed-'+str(time.time_ns())))
 cmd=['docker','run','--rm','--name','gate-oracle-'+name,'--cpus','4','--memory','16g','--user','1000:1000','--network','none','--env','HOME','--env','PATH','--env','GOTOOLCHAIN','--env','GOPROXY','--env','ADAMIC_TOOLS=/workspace/adamic-tools']
 for variable in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','SSL_CERT_FILE','SSL_CERT_DIR','REQUESTS_CA_BUNDLE','CURL_CA_BUNDLE','NODE_EXTRA_CA_CERTS']:
  if variable in os.environ:cmd+=['--env',variable]
 for path in ['/usr','/lib','/lib64','/etc/ssl/certs','/etc/passwd','/etc/group']:cmd+=['--mount','type=bind,src='+path+',dst='+path+',readonly']
 for path in ['/workspace','/home/agent']:cmd+=['--mount','type=bind,src='+path+',dst='+path]
 cmd+=['--mount','type=bind,src=/workspace/oracle-partition-isolated,dst=/workspace/adamic','ubuntu:24.04','python3',str(r/'worker.py'),name]
 start=time.monotonic()
 with (out/'container.log').open('w') as log:code=subprocess.call(cmd,stdout=log,stderr=log)
 print(name,'docker wall',time.monotonic()-start,'exit',code,flush=True)
 if code:raise SystemExit('container failed '+name)
