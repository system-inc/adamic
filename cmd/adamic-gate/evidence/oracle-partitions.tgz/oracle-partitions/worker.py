import os,subprocess,pathlib,time,json,sys
name=sys.argv[1];out=pathlib.Path('/workspace/gate-affinity-evidence/oracle-partitions')/name;out.mkdir(exist_ok=True)
env=os.environ.copy();env['GOCACHE']=str(out/'go-cache');env['XDG_CACHE_HOME']=str(out/'xdg');env['TMPDIR']='/tmp/adamic-gate';env.pop('GOFLAGS',None);env.pop('ADAMIC_GATE_UNCACHED',None)
root='/workspace/adamic'
def probe(*a):return subprocess.check_output(a,cwd=root,env=env,text=True).strip()
before=pathlib.Path('/proc/loadavg').read_text().strip();start=time.monotonic()
with (out/'setup.log').open('w') as log:code=subprocess.call(['bash','cloud/setup.sh'],cwd=root,env=env,stdout=log,stderr=log)
setup=time.monotonic()-start
if code:raise SystemExit('setup failed '+str(code))
# Resolve the setup's environment for these child processes without exposing all environment values.
raw=subprocess.check_output(['bash','-c','source /workspace/adamic-tools/env.sh; env -0'],env=env,cwd=root)
env=dict(entry.decode().split('=',1) for entry in raw.split(b'\0') if b'=' in entry);env['ADAMIC_GATE_UNCACHED']='1'
commands=[['test','-count=1','-json','-timeout','60m','-parallel','5','github.com/system-inc/adamic/internal/oracle']]
if name!='whole':commands=json.load(open(out.parent/'halves.json'))[int(name.split('-')[1])]['Commands']
flags={'commit':probe('git','rev-parse','HEAD'),'nproc':probe('nproc'),'cpu.max':pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'go':probe('go','version'),'clang':probe('clang','--version').splitlines()[0],'node':probe('node','--version'),'uncached':1,'Go_build_cache':'preinstalled image cloned for each container','fixture_cache':'fresh XDG cache and fresh /tmp; keyed runtime archives cold','GOFLAGS':env.get('GOFLAGS',''),'GOCACHE':env['GOCACHE'],'XDG_CACHE_HOME':env['XDG_CACHE_HOME'],'setup_seconds':setup,'setup_load_before':before,'setup_load_after':pathlib.Path('/proc/loadavg').read_text().strip()}
rows=[];total=0
for i,args in enumerate(commands):
 before=pathlib.Path('/proc/loadavg').read_text().strip();start=time.monotonic()
 with (out/f'test-{i}.jsonl').open('w') as log,(out/f'test-{i}.stderr').open('w') as err:code=subprocess.call(['go',*args],cwd=root,env=env,stdout=log,stderr=err)
 wall=time.monotonic()-start;total+=wall;rows.append({'command':['go',*args],'wall':wall,'exit':code,'load_before':before,'load_after':pathlib.Path('/proc/loadavg').read_text().strip()})
 if code:break
flags.update(test_seconds=total,total_seconds=setup+total,commands=rows,memory_peak=pathlib.Path('/sys/fs/cgroup/memory.peak').read_text().strip(),memory_events=pathlib.Path('/sys/fs/cgroup/memory.events').read_text().strip(),status=probe('git','status','--porcelain'))
(out/'metadata.json').write_text(json.dumps(flags,indent=2));print(json.dumps({k:v for k,v in flags.items() if k!='commands'}),flush=True)
raise SystemExit(code)
