import os,json,pathlib,subprocess
root=pathlib.Path('/workspace/adamic/cmd/adamic-gate');base=pathlib.Path('/workspace/gate-evidence/stderr-mutants');base.mkdir(exist_ok=True)
mutants=[('mixed-stderr','json_command.go','cmd.Stdout, cmd.Stderr = stdout, stderr','cmd.Stdout, cmd.Stderr = stdout, stdout','TestComplementRunsInitRegisteredFixture'),('combined-stdout','main.go','b, err := cmd.Output()','b, err := exec.Command(name,args...).CombinedOutput()','TestFixtureDiscoveryKeepsGoWarningOffJSON'),('missing-line','main.go','fmt.Errorf("%s:%d: malformed JSON: %w", path, line, err)','fmt.Errorf("%s: malformed JSON at line omitted %d: %w", path, line, err)','TestRawEvidenceKeepsSkipReasonsAndFailures')]
results=[]
for name,file,before,after,test in mutants:
 s=(root/file).read_text();assert before in s;replacement=base/(name+'.go');replacement.write_text(s.replace(before,after))
 overlay=base/(name+'.overlay.json');overlay.write_text(json.dumps({'Replace':{str(root/file):str(replacement)}}))
 log=base/(name+'.jsonl')
 with log.open('w') as stdout,(base/(name+'.stderr')).open('w') as stderr:
  p=subprocess.run(['go','test','-count=1','-json','-overlay='+str(overlay),'-run','^'+test+'$','./cmd/adamic-gate'],cwd=root.parent.parent,stdout=stdout,stderr=stderr)
 events=[json.loads(l) for l in log.open()]
 assert p.returncode!=0 and any(e['Action']=='fail' and e.get('Test')==test for e in events),(name,p.returncode)
 results.append({'mutant':name,'caught_by':test,'exit':p.returncode})
(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
