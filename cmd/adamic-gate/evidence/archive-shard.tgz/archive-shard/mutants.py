import pathlib,json,subprocess,os
root=pathlib.Path('/workspace/adamic');out=pathlib.Path(__file__).parent
cases=[('drop-archive-refusal','cmd/adamic-gate/archive.go','func archiveReady(p plan, index int) error {','func archiveReady(p plan, index int) error {\n return nil\n','TestArchiveLightestAndMissingInput'),('drop-parent-residual','cmd/adamic-gate/archive.go','loads := predictions(without, weights)','loads := predictions(without, nil)','TestArchiveCountsRepeatedParentSetup')]
for name,file,before,after,test in cases:
 source=(root/file).read_text();assert before in source
 path=out/(name+'.go');path.write_text(source.replace(before,after,1));overlay=out/(name+'.overlay.json');overlay.write_text(json.dumps({'Replace':{str(root/file):str(path)}}))
 with (out/(name+'.log')).open('w') as log:code=subprocess.call(['go','test','-overlay',str(overlay),'./cmd/adamic-gate','-run','^'+test+'$','-count=1'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 data=(out/(name+'.log')).read_text();assert code!=0 and '--- FAIL:' in data and 'build failed' not in data,(name,data)
 print(name,'caught',flush=True)
p=root/'cloud/gate/fleet.sh';original=p.read_text()
try:
 p.write_text(original.replace('if [ "$index" = "$archiveShard" ]; then','if true; then',1))
 with (out/'archive-on-every-box.log').open('w') as log:code=subprocess.call(['go','test','./cmd/adamic-gate','-run','^TestFleetTwentyTwoArchiveBriefs$','-count=1'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert code!=0 and '--- FAIL:' in (out/'archive-on-every-box.log').read_text()
 print('archive-on-every-box caught',flush=True)
finally:p.write_text(original)
